# NeuroAltar — instrukcje pracy

Stan instrukcji: 2026-11-09. Pracuj w istniejącym repozytorium
`/Users/dominik/Desktop/Combat Tracker`, na aktualnym 24E Roboczym. Na Windows
używaj checkoutu tego samego projektu i potwierdzonego commitu.
Przed zmianami sprawdź Git, wariant aplikacji i rzeczywiste miejsce dostarczenia.
Nie cofaj ukończonych etapów i nie nadpisuj zmian użytkownika.

## Aktualny zakres

Panel MG, Bestiariusz, Ekwipunek, Pojazdy, Wiedza MG, roller i Karta BG są wdrożone.
Karta obejmuje sześć klas, 18 profesji, poziomy 1–12, rozwój, zasoby,
zdrowie, odpoczynki, inwentarz oraz powiązanie z potyczką.
Pełny odbiór sesyjny 24E pozostaje otwarty. Udany build go nie zastępuje.
Osiem poprawek z 2026-11-09 wdrożono w 0.29.5. Następna praca na Windows
to build i odbiór zgodnie z docs/PRZEKAZANIE_WINDOWS_2026-11-09.md.
Zachowaj działający macOS i wszystkie osiem poprawek.

Truciciel i Pogromca pozostają opisami. Gracz sam rozlicza produkcję, koszty
i dopisuje wynik do ekwipunku. Nie dodawaj dla nich automatycznej produkcji,
kontroli liczby porcji na odpoczynek ani odnawianej puli przedmiotów.
Nie zaliczaj tej przyjętej granicy do braków aplikacji.

## Źródła i decyzje

Najnowsze jawne ustalenia użytkownika mają pierwszeństwo przed dokumentami.
W dokumentacji czytaj kolejno: `docs/DECISIONS.md`, `docs/PRODUCT_SPEC.md`,
`docs/TECH_SPEC.md`, `docs/DATA_MODEL.md`, `docs/ROADMAP.md`,
`docs/ACCEPTANCE_TESTS.md`. Bieżący stan: `docs/STATUS.md`; zadania: `docs/PLAN_DALSZYCH_PRAC.md`;
przygotowanie Windows: `docs/BUILD_WINDOWS.md`.
Nie przywracaj dawnych ograniczeń etapowych z archiwalnych raportów.
Nierozstrzygniętej sprzeczności mechaniki nie zgaduj; opisz ją i zbierz pytania.

Mechanikę sprawdzaj w podręczniku; arkusz jest materiałem pomocniczym i może
pochodzić z wersji beta. `reference/` jest prywatne, tylko do odczytu, poza Git
i dystrybucją. Nie kopiuj surowych PDF/Excela do aplikacji. Zweryfikowane partie
danych i potrzebne opisy mogą być częścią programu zgodnie ze zleceniami MG.
Excel był jednorazowym źródłem danych; bez synchronizacji i reimportu w runtime.

Przed zmianą karty czytaj `docs/KARTA_BG_MECHANIKA.md`,
`docs/KARTA_BG_KATALOG_REGUL.md`, `docs/KARTA_BG_KONTRAKT.md`,
`docs/KARTA_BG_WZORZEC.md` i `docs/KARTA_BG_KOLORY.md`.
Aktualny zakres zdolności: `docs/24E_BRAKI_ZDOLNOSCI.md`,
`docs/POPRAWKI_24E_MECHANIKA_3.md`, `docs/AUDYT_LIMITOW_ZDOLNOSCI_2026-11-05.md`.

## Trwałość i ochrona danych

- Zachowaj identyfikator aplikacji, adres bazy, pięć stałych slotów 1–5,
  istniejące migracje 001–014 oraz odczyt starych danych. Nie kasuj ani nie
  odtwarzaj bazy użytkownika. Zmiana schematu tylko przez bezpieczną nową migrację.
- Testy, prototypy i natywne QA wykonuj na oddzielnych bazach. Nie dołączaj bazy,
  historii użytkownika, prywatnych źródeł ani katalogów roboczych do instalatora.
- Zachowaj kolejki autozapisu, rewizje, atomowe transakcje i logi oraz trwałe
  `operationId`. Ponowienie zapisuje ten sam wynik; nie losuje ponownie i nie
  nadpisuje późniejszych zmian. Nieznany błąd/utrata odpowiedzi zachowują retry.
- `Character.sheet` to zatwierdzona karta, `draft` to niezależny szkic.
  `Character.journal` to opcjonalne notatki/znajomi/spotkania, poza szkicem;
  autosave nie publikuje rozwoju i nie zmienia budżetu potyczki. Stare pola
  sheet/draft są fallbackiem do pierwszego zapisu notatek, bez migracji SQL.
  `inventory` i `condition` są osobne: odrzucenie rozwoju nie cofa zasobów ani
  amunicji. Nie publikuj niepełnego rozwoju. Zapis szkicu działa podczas walki;
  publikacja rozwoju i archiwizacja czekają na zakończenie aktywnego udziału.
- Karta może być przygotowana w wielu slotach, lecz mieć jeden aktywny udział.
  Udział ma inicjatywę i timery; karta ma trwałe PW, rozwój, przedmioty i zasoby.
  Reset/clear nie cofają karty. Nie łącz starego BG z kartą na podstawie nazwy.
- Dokładnie rozpoznane odrzucenie udziału przed transakcją nie może pozostawić
  zablokowanej kolejki. Cofnięcie odrzuconego resetu zachowuje późniejsze edycje.
  Ze szkicem można zakończyć udział po rozliczeniu efektów, bez usuwania BG.
- Katalog, instancja, original/prepared i runtime pozostają niezależne.
  Edycja/usunięcie szablonu nie zmienia istniejących kopii. Tombstone nie usuwa
  powiązanych aktorów, snapshotów i logów. Seed nie nadpisuje edycji ani usunięć MG;
  batch i ledger zapisują się transakcyjnie, bez odtwarzania skasowanych wpisów.
- Tylko jawne przygotowanie zastępuje baseline; reset odtwarza dokładny snapshot,
  w tym częściowo zużyte zasoby. Clear aktualizuje stały slot, nie tworzy go od nowa.
  Potwierdzenia reset/clear tracą ważność po zmianie treści/rewizji.
- Zachowaj ochronę formularzy, nawigacji i zamknięcia (także Cmd+Q/Alt+F4).
  Błąd ujawnia właściwy widok, slot i pole. Przełączanie kart nie gubi szkicu.

## Mechanika i granice automatyzacji

- Logika domenowa poza React; wspólne obliczenia karty i walki. Zapis przez
  repozytoria/usługi, walidacja TypeScript/Zod i Rust. Kod platformowy izoluj.
- Dokładnie pięć potyczek; bez dodatkowego archiwum slotów. Bez automatycznego
  rozstrzygania trafienia i odejmowania PW po rzucie/ataku, bez kości 3D.
- Premie sytuacyjne, m.in. Mój wróg, biom, cel i okoliczności, rozlicza gracz.
  Zdolności fabularne są opisami. Zakres przerzutów jest zaakceptowany; nie
  rozszerzaj go ani nie dodawaj automatycznego łączenia efektów.
- Poza zakresem: automatyczne przerywanie Berserka, dalsza automatyzacja zacięć
  i przegrzania, integracja leków z walką oraz konwersja starego uproszczonego BG
  w pełną kartę. Zachowaj już istniejące ręczne funkcje i powiązanie z kartą.
- Amunicja tylko BG. Atak bronią palną z karty zapisuje rzut i właściwy koszt
  amunicji; sam ogólny rzut kośćmi tego nie robi. Zachowaj przeładowanie przy
  magazynku, alarm pustej broni, transakcje i ochronę przed podwójnym zużyciem.
- `Item` jest wspólnym modelem, `weaponProfile` opcjonalnym rozszerzeniem.
  Zachowaj zakresy cen/dostępności i niezależne N/D w każdym wymiarze handlu;
  none/none/none daje bazę. Stal dotyczy tylko weapon/ammunition.
  Kolor gry jest odrębny od TradeContext; nie przeliczaj dawnych awansów
  bieżącym Kolorem. Braki danych nie są zerem.
- Wyjątki masy: kategorie broni „ok. X kg” mają stałą masę X kg; amunicja nie
  ma parametru masy; leki bez masy źródłowej mają 0 kg. Zestaw startowy to jeden
  przedmiot z masą całego zestawu. Nie nadpisuj jawnej własnej masy użytkownika.
- Zasoby i odpoczynki wynikają z konkretnej reguły; bez odnawiania zegarem
  komputera lub restartem. Długi odnawia również zasoby krótkiego. Saper 1/S+L.
  Pancerz: odzysk KW=min(wydane,floor(maksimum/2)) osobno dla k6/k8. Przerwany
  długi daje krótki dopiero po czasie krótkiego właściwym dla Koloru.
- Zachowaj decyzje MG: minimum 0 PW na awans; Samouk 9; Twardziel 3/7/11;
  procentowe premie sumowane, zaokrąglenia mechaniczne w dół; Fabrykator czas −50%.
  Rtęć blokuje wszystkie Fuksy oraz wskazane leki. Chrom: nieliczony zapas,
  pusta broń przy naturalnej 1, środki leczące cena ×0,5. Gambling +5 pp
  dostępności przed Kolorem. Jeden cios daje najwyżej jedno Zranienie;
  krwawienie łącznie 1 PW/turę. RadOff tylko skutki napromieniowania.
- Zachowaj niezależne budżety akcji/zasobów, odnowienia i ograniczenia stanów.
  Pierwszy start, wybór karty i ręczne ustawienie tury nie odnawiają pul.
  Nie twórz fikcyjnych testów ataku dla ataków wymagających RO celu ani nie
  doliczaj ponownie źródłowych premii końcowych. Nie zgaduj nieznanych formuł.
- Awaria: ręczny wynik i rzut k20; tylko „Zastosuj” zmienia stan. Inicjatywa
  przeciwnika pozostaje klikalnym istniejącym wpisem w Zdolnościach i zasadach,
  z atomowym zapisem wyniku/logu i bez zmiany bieżącej tury.
- Naturalne k20: 20 zielone, 1 czerwone niezależnie od premii. Zachowaj
  jednorazowy krytyk powiązany z postacią i bronią/zdolnością, trwały po restarcie.
  Nie podwajaj premii stałej ani kości niepowiązanej broni.
- Towarzysze to przyszły backlog. Web, konta, synchronizacja, backup GUI,
  import/eksport i publiczna dystrybucja nie wynikają z samego portu Windows.

## Interfejs

- Zachowaj papierową paletę i zieleń; jeden lewy pasek nawigacji, poziome
  parametry BG oraz osiem spójnych zakładek z ikonami. Pięć slotów poziomo.
  Układ ma działać w małych oknach i przy skalowaniu tekstu.
- Nagłówek pokazuje jedną aktualną TT. Cechy/testy w dwóch kolumnach, RO z tarczą.
  Statblock walki stale widoczny przed parametrami/notatkami; ataki przy akcjach.
  Karta potyczki zwijana, trudność w pełnych procentach; obliczenia bez zaokrągleń.
- Nie przywracaj „Korekty MG”, obowiązkowych powodów korekty, PD/awansu,
  nabycia ani masy, pola zapłaconej ceny i usuniętych dopisków administracyjnych.
  Historyczne dane i modyfikatory zachowaj. Usuwanie dodanego poziomu ma być widoczne.
- `InventoryPanel` to jedna zamontowana instancja dla Broń/Ekwipunek.
  Wyszukiwarka jest zwijana; grupy przechowywania czytelne. Sloty melee1–4,
  ranged1–3, handy1–3 oraz shield/pancerz; stare mainHand/offHand/bothHands tylko
  kompatybilność. Slot nie oznacza jednoczesnego dzierżenia wszystkich broni.
- Zasoby wyświetlaj przy zdolnościach jako klikalne pełne/puste kropki.
  Maksimum pochodzi z conditionView/deriveResources: właściwy poziom klasy,
  modyfikator Cechy, PB lub inna reguła. Bez stałej liczby kropek, potwierdzeń
  i powodów. Kropka zmienia jedno użycie, nie uruchamia efektu/leczenia/akcji.
  Zasoby nie wracają do Zdrowia. Zachowaj odrębne obsługi mechaniczne zdolności.
- Ikony FVTT-NOE są lokalnymi dekoracyjnymi maskami CSS w --color-teal.
  Zachowaj oryginalne SVG, NOTICE i manifest/hash; nie stosuj do ikon licencji
  MIT kodu upstream. Brak dedykowanej ikony daje dotychczasowy piktogram.

## Weryfikacja i dostarczenie

Dla samych dokumentów: spójność, poprawne linki, formatowanie i `git diff --check`.
Nie zmieniaj z tego powodu wersji aplikacji ani nie podmieniaj jej użytkownikowi.

Dla kodu/konfiguracji buildu wykonaj właściwe kontrole: `pnpm check`,
`cargo test --manifest-path src-tauri/Cargo.toml --release --lib`,
`cargo fmt --manifest-path src-tauri/Cargo.toml --check`, build odpowiedniej
platformy i natywne QA na osobnej bazie. Sprawdź restart, polskie nazwy,
formularze, skróty, zamknięcie i trwałość. Po udanych kontrolach commit
obejmuje tylko własne zmiany; raport podaje pliki, dane/migracje, testy i ograniczenia.

Przygotowanie Windows nie oznacza jego odbioru: instalator trzeba zbudować,
zainstalować i sprawdzić na Windows, a macOS objąć regresją. Odróżniaj konfigurację
CI, faktyczne uruchomienie, powstały instalator i test na komputerze użytkownika.
Nie publikuj źródeł ani wydania tylko po to, aby uruchomić build.
Brak środowiska zgłoś jako brak weryfikacji. Podpis ad hoc macOS nie jest notaryzacją.

Poprzednia wersja instrukcji jest zachowana w historii Git (commit 1aeab92).
