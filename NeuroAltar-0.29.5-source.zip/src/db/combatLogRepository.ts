import { z } from 'zod';
import { encounterIdSchema } from '../domain/encounter';
import { combatLogEntrySchema, LOG_PAGE_SIZE } from '../domain/combatLog';
import type { SqlConnection } from './connection';
const rowSchema = z.object({
  id: z.number(),
  encounter_id: z.number(),
  round_number: z.number(),
  actor_id: z.string().nullable(),
  event_type: z.string(),
  message: z.string(),
  payload_json: z.string(),
  created_at: z.string(),
});
export function createCombatLogRepository(database: SqlConnection) {
  return {
    async page(encounterId: number, beforeId?: number) {
      encounterIdSchema.parse(encounterId);
      if (beforeId !== undefined) z.number().int().positive().parse(beforeId);
      const rows = z.array(rowSchema).parse(
        await database.selectRows(
          `SELECT id, encounter_id, round_number, actor_id, event_type, message, payload_json, created_at
         FROM combat_log WHERE encounter_id = ? ${beforeId === undefined ? '' : 'AND id < ?'}
         ORDER BY id DESC LIMIT ?`,
          beforeId === undefined
            ? [encounterId, LOG_PAGE_SIZE + 1]
            : [encounterId, beforeId, LOG_PAGE_SIZE + 1],
        ),
      );
      const entries = rows.slice(0, LOG_PAGE_SIZE).map((row) =>
        combatLogEntrySchema.parse({
          id: row.id,
          encounterId: row.encounter_id,
          roundNumber: row.round_number,
          actorId: row.actor_id,
          eventType: row.event_type,
          message: row.message,
          payload: JSON.parse(row.payload_json) as unknown,
          createdAt: row.created_at,
        }),
      );
      if (entries.some((entry) => entry.encounterId !== encounterId))
        throw new Error('Odczytano log innej potyczki.');
      return { entries, hasMore: rows.length > LOG_PAGE_SIZE };
    },
  };
}
