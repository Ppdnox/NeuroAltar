import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';
import { openDatabase } from './connection';
import {
  characterSchema,
  type CharacterMutation,
} from '../domain/character/model';
export async function loadCharacters() {
  const db = await openDatabase();
  const rows = z
    .array(z.object({ payload_json: z.string() }))
    .parse(
      await db.selectRows(
        'SELECT payload_json FROM characters ORDER BY updated_at DESC,id',
      ),
    );
  return rows.map((r) => characterSchema.parse(JSON.parse(r.payload_json)));
}
export async function saveCharacter(change: CharacterMutation) {
  await openDatabase();
  const result = characterSchema.parse(
    await invoke('save_character', { change }),
  );
  window.dispatchEvent(new Event('character-combat-saved'));
  return result;
}
