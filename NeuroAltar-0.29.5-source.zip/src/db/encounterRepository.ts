import { z } from 'zod';
import {
  encounterDetailsSchema,
  type EncounterDetails,
  type SlotId,
} from '../domain/encounterDetails';
import {
  encounterIdSchema,
  encounterSlotsSchema,
  partyLevelsSchema,
  type Encounter,
} from '../domain/encounter';
import type { SqlConnection } from './connection';

const encounterRowSchema = z
  .object({
    id: encounterIdSchema,
    name: z.string(),
    notes: z.string(),
    round_number: z.number(),
    current_turn_actor_id: z.string().nullable(),
    party_levels_json: z.string(),
    created_at: z.string(),
    updated_at: z.string(),
  })
  .strict();

export interface EncounterRepository {
  listSlots(): Promise<Encounter[]>;
  updateDetails(
    id: SlotId,
    details: EncounterDetails,
    expected?: EncounterDetails,
  ): Promise<string>;
}

export function createEncounterRepository(
  database: SqlConnection,
): EncounterRepository {
  return {
    async updateDetails(id, details, expected) {
      encounterIdSchema.parse(id);
      const valid = encounterDetailsSchema.parse(details);
      const updatedAt = new Date().toISOString();
      if (expected) {
        const previous = encounterDetailsSchema.parse(expected);
        const result = await database.execute(
          'UPDATE encounters SET name = ?, notes = ?, party_levels_json = ?, updated_at = ? WHERE id = ? AND name = ? AND notes = ? AND json(party_levels_json) = json(?)',
          [
            valid.name,
            valid.notes,
            JSON.stringify(valid.partyLevels ?? previous.partyLevels ?? []),
            updatedAt,
            id,
            previous.name,
            previous.notes,
            JSON.stringify(previous.partyLevels ?? []),
          ],
        );
        if (result.rowsAffected !== 1) {
          const rows = z
            .array(z.object({ updated_at: z.iso.datetime() }))
            .parse(
              await database.selectRows(
                'SELECT updated_at FROM encounters WHERE id = ? AND name = ? AND notes = ? AND json(party_levels_json) = json(?)',
                [
                  id,
                  valid.name,
                  valid.notes,
                  JSON.stringify(
                    valid.partyLevels ?? previous.partyLevels ?? [],
                  ),
                ],
              ),
            );
          if (rows.length === 1)
            return z.iso.datetime().parse(rows[0]!.updated_at);
          throw new Error(
            'Dane slotu zmieniły się w innym oknie. Zachowano szkic; skopiuj go przed ponownym otwarciem aplikacji.',
          );
        }
        return updatedAt;
      }
      const result = await database.execute(
        valid.partyLevels === undefined
          ? 'UPDATE encounters SET name = ?, notes = ?, updated_at = ? WHERE id = ?'
          : 'UPDATE encounters SET name = ?, notes = ?, party_levels_json = ?, updated_at = ? WHERE id = ?',
        valid.partyLevels === undefined
          ? [valid.name, valid.notes, updatedAt, id]
          : [
              valid.name,
              valid.notes,
              JSON.stringify(valid.partyLevels),
              updatedAt,
              id,
            ],
      );
      if (result.rowsAffected !== 1)
        throw new Error('Nie znaleziono slotu potyczki.');
      return updatedAt;
    },
    async listSlots() {
      const rows = z
        .array(encounterRowSchema)
        .parse(
          await database.selectRows(
            'SELECT id, name, notes, round_number, current_turn_actor_id, party_levels_json, created_at, updated_at FROM encounters ORDER BY id',
          ),
        );
      return encounterSlotsSchema.parse(
        rows.map((row) => ({
          id: row.id,
          name: row.name,
          notes: row.notes,
          roundNumber: row.round_number,
          currentTurnActorId: row.current_turn_actor_id,
          partyLevels: partyLevelsSchema.parse(
            JSON.parse(row.party_levels_json) as unknown,
          ),
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        })),
      );
    },
  };
}
