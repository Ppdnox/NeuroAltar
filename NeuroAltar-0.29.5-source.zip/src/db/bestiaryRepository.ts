import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';
import { openDatabase, type SqlConnection } from './connection';
import { catalogEntrySchema, type CatalogMutation } from '../domain/bestiary';
const rowSchema = z.object({
  id: z.string(),
  name: z.string(),
  category: z.string(),
  size: z.string(),
  tt: z.number(),
  hp_max: z.number(),
  statblock_json: z.string(),
  revision: z.number(),
});
export function createBestiaryRepository(db: SqlConnection) {
  return {
    async list() {
      const rows = z
        .array(rowSchema)
        .parse(
          await db.selectRows(
            'SELECT id,name,COALESCE(official_category,category) AS category,size,tt,hp_max,statblock_json,revision FROM enemy_templates WHERE deleted=0 ORDER BY name,id',
          ),
        );
      return rows.map((row) =>
        catalogEntrySchema.parse({
          revision: row.revision,
          template: {
            ...(JSON.parse(row.statblock_json) as Record<string, unknown>),
            id: row.id,
            name: row.name,
            category: row.category,
            size: row.size,
            tt: row.tt,
            hpMax: row.hp_max,
          },
        }),
      );
    },
  };
}
export async function loadBestiary() {
  return createBestiaryRepository(await openDatabase()).list();
}
export async function saveBestiary(change: CatalogMutation): Promise<number> {
  await openDatabase();
  return z
    .number()
    .int()
    .nonnegative()
    .parse(await invoke('save_bestiary', { change }));
}
