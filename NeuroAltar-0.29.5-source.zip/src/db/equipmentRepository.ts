import { withItemDisplayName } from '../domain/catalogNames';
import { z } from 'zod';
import { itemSchema } from '../domain/item';
import { openDatabase, type SqlConnection } from './connection';
export function createEquipmentRepository(db: SqlConnection) {
  return {
    async list() {
      const rows = z
        .array(z.object({ id: z.uuid(), item_json: z.string() }))
        .parse(
          await db.selectRows(
            'SELECT id,item_json FROM items WHERE deleted=0 ORDER BY id',
          ),
        );
      return rows.map((row) => {
        try {
          const item = itemSchema.parse(JSON.parse(row.item_json));
          if (item.id !== row.id)
            throw new Error('Niezgodna tożsamość przedmiotu.');
          return withItemDisplayName(item);
        } catch (error) {
          throw new Error(`Ekwipunek, wpis ${row.id}: ${String(error)}`, {
            cause: error,
          });
        }
      });
    },
  };
}
export async function loadEquipment() {
  return createEquipmentRepository(await openDatabase()).list();
}
