import { invoke, isTauri } from '@tauri-apps/api/core';
import Database from '@tauri-apps/plugin-sql';

export interface SqlConnection {
  selectRows(query: string, values?: (string | number)[]): Promise<unknown>;
  execute(
    query: string,
    values: (string | number)[],
  ): Promise<{ rowsAffected: number }>;
}

export const DATABASE_URL = 'sqlite:combat-tracker.db';
let connection: Promise<SqlConnection> | undefined;

export function openDatabase(): Promise<SqlConnection> {
  if (!isTauri()) {
    return Promise.reject(
      new Error(
        'Lokalna baza jest dostępna w aplikacji desktopowej. Uruchom pnpm tauri dev.',
      ),
    );
  }
  connection ??= Database.load(DATABASE_URL)
    .then(async (database) => {
      await invoke('seed_bestiary');
      await invoke('seed_equipment');
      return {
        selectRows: (query: string, values?: (string | number)[]) =>
          database.select<unknown>(query, values),
        execute: (query: string, values: (string | number)[]) =>
          database.execute(query, values),
      };
    })
    .catch((error: unknown) => {
      connection = undefined;
      throw error;
    });
  return connection;
}
