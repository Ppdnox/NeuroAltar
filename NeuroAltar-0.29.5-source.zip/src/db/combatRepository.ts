import { statusListSchema } from '../domain/status';
import { z } from 'zod';
import { actorSchema, combatSlotsSchema, type Combat } from '../domain/combat';
import { enemyInstanceSchema } from '../domain/enemy';
import type { SqlConnection } from './connection';

const runtimeSchema = z
  .object({
    manualStatuses: z.array(z.string()),
    enemy: enemyInstanceSchema.optional(),
  })
  .strict();
const rowSchema = z.object({
  encounter_id: z.number(),
  revision: z.number(),
  round_number: z.number(),
  current_turn_actor_id: z.string().nullable(),
  actor_id: z.string().nullable(),
  effects_json: z.string(),
  kind: z.string().nullable(),
  template_id: z.string().nullable(),
  prepared_snapshot_json: z.string().nullable(),
  reset_snapshot_json: z.string().nullable(),
  display_name: z.string().nullable(),
  tt_current: z.number().nullable(),
  hp_current: z.number().nullable(),
  hp_max_current: z.number().nullable(),
  initiative_value: z.number().nullable(),
  initiative_tie_order: z.number().nullable(),
  runtime_overrides_json: z.string().nullable(),
});
export function createCombatRepository(database: SqlConnection) {
  return {
    async listSlots(): Promise<Combat[]> {
      // A single statement reads actors and turn state from one SQLite snapshot.
      const rows = z.array(rowSchema).parse(
        await database.selectRows(`
        SELECT e.id AS encounter_id, e.combat_revision AS revision, e.round_number, e.current_turn_actor_id,
          a.id AS actor_id, a.kind, a.display_name, a.tt_current, a.hp_current, a.hp_max_current,
          a.initiative_value, a.initiative_tie_order, a.runtime_overrides_json,
          a.template_id, a.prepared_snapshot_json, a.reset_snapshot_json,
          (SELECT json_group_array(json(status_json)) FROM
            (SELECT status_json FROM actor_statuses WHERE actor_id=a.id ORDER BY id)) AS effects_json
        FROM encounters e LEFT JOIN encounter_actors a ON a.encounter_id = e.id
        ORDER BY e.id, a.initiative_tie_order, a.id`),
      );
      const slots = new Map<
        number,
        {
          encounterId: number;
          revision: number;
          roundNumber: number;
          currentTurnActorId: string | null;
          actors: unknown[];
        }
      >();
      for (const row of rows) {
        if (!slots.has(row.encounter_id))
          slots.set(row.encounter_id, {
            encounterId: row.encounter_id,
            revision: row.revision,
            roundNumber: row.round_number,
            currentTurnActorId: row.current_turn_actor_id,
            actors: [],
          });
        if (row.actor_id !== null) {
          const runtime = runtimeSchema.parse(
            JSON.parse(row.runtime_overrides_json!) as unknown,
          );
          if (
            (row.kind !== 'pc' && row.kind !== 'enemy') ||
            (row.kind === 'enemy') !== Boolean(runtime.enemy) ||
            (runtime.enemy?.template.id ?? null) !== row.template_id
          )
            throw new Error(
              'Niespójny rodzaj postaci lub szablon przeciwnika.',
            );
          // Legacy snapshots remain unchanged. A malformed snapshot blocks reset until
          // the GM explicitly prepares the currently visible state; never invent stats.
          const source = row.reset_snapshot_json ?? row.prepared_snapshot_json;
          const prepared = source
            ? actorSchema.safeParse(JSON.parse(source) as unknown)
            : null;
          if (row.reset_snapshot_json && !prepared?.success)
            throw new Error('Nieprawidłowy stan przygotowany postaci.');
          const effects = statusListSchema.parse(JSON.parse(row.effects_json));
          slots.get(row.encounter_id)!.actors.push({
            ...(effects.length ? { effects } : {}),
            ...(runtime.enemy ? { enemy: runtime.enemy } : {}),
            ...(prepared?.success ? { prepared: prepared.data } : {}),
            id: row.actor_id,
            displayName: row.display_name,
            ttCurrent: row.tt_current,
            hpCurrent: row.hp_current,
            hpMaxCurrent: row.hp_max_current,
            initiativeValue: row.initiative_value,
            initiativeTieOrder: row.initiative_tie_order,
            statuses: runtime.manualStatuses,
          });
        }
      }
      return combatSlotsSchema.parse([...slots.values()]);
    },
  };
}
