import { create } from 'zustand';
import { useCombatStore } from './combatStore';
import { useEncounterStore } from './encounterStore';
import { useDiceStore } from './diceStore';
import { useCombatLogStore } from './combatLogStore';
import { enemyInitiative } from '../domain/enemyInitiative';
import {
  diceRollSchema,
  rollDice,
  HISTORY_LIMIT,
  type DiceRoll,
} from '../domain/dice';
import { toCombatDraft } from '../domain/combat';
import { loadCombatSlots } from '../services/combat';
import { saveInitiativeRoll } from '../services/initiativeRoll';
import type { SlotId } from '../domain/encounterDetails';
type CharacterInitiativeOptions = {
  mode: 'normal' | 'advantage' | 'disadvantage';
  manual?: number;
  name?: string;
  rerollOf?: string;
  consumedEffects?: string[];
  participationRevision?: number;
};
interface InitiativeState {
  slotId: SlotId | null;
  busy: boolean;
  pending: DiceRoll | null;
  error: string | null;
  roll(
    slotId: SlotId,
    actorId: string,
    characterBonus?: number,
    options?: CharacterInitiativeOptions,
  ): Promise<boolean>;
  retry(): Promise<boolean>;
  reload(): Promise<boolean>;
  prepareClose(): Promise<boolean>;
}
export function createInitiativeStore(
  encounters = useEncounterStore,
  combat = useCombatStore,
  dice = useDiceStore,
  save = saveInitiativeRoll,
  load = loadCombatSlots,
  execute = rollDice,
) {
  let revision = 0;
  let work: Promise<boolean> | undefined;
  return create<InitiativeState>((set, get) => {
    const unlock = () => {
      combat.setState({ closing: false });
      encounters.setState({ closing: false });
      set({ slotId: null, busy: false, pending: null, error: null });
    };
    const refresh = async () => {
      const id = get().slotId!;
      const value = (await load()).find((s) => s.encounterId === id);
      if (!value) throw Error('Nie udało się odczytać potyczki po rzucie.');
      combat.setState((s) => ({
        slots: s.slots.map((slot) => (slot.encounterId === id ? value : slot)),
        drafts: {
          ...s.drafts,
          [id]: { value: toCombatDraft(value), status: 'saved', error: null },
        },
      }));
    };
    const persist = async () => {
      const result = get().pending;
      if (!result) return false;
      try {
        await save(result, revision);
        await refresh();
        if (result.context?.consumedEffects?.length)
          await (
            await import('./participationStore')
          ).useParticipationStore
            .getState()
            .load();
        dice.setState((s) => ({
          history: [
            result,
            ...s.history.filter((r) => r.id !== result.id),
          ].slice(0, HISTORY_LIMIT),
          open: true,
        }));
        void useCombatLogStore.getState().refresh(get().slotId!);
        unlock();
        return true;
      } catch (error) {
        set({
          busy: false,
          error: error instanceof Error ? error.message : String(error),
        });
        return false;
      }
    };
    return {
      slotId: null,
      busy: false,
      pending: null,
      error: null,
      roll(id, actorId, characterBonus, options) {
        const state = combat.getState();
        if (
          get().slotId !== null ||
          state.closing ||
          encounters.getState().closing ||
          state.status !== 'ready' ||
          encounters.getState().status !== 'ready' ||
          state.enemyForm ||
          state.statusForm ||
          state.capabilityForm ||
          state.loadoutForm ||
          state.statblockForm ||
          state.failureForm ||
          dice.getState().busy ||
          dice.getState().pending
        )
          return Promise.resolve(false);
        const actor = state.drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!actor || (characterBonus === undefined && !enemyInitiative(actor)))
          return Promise.resolve(false);
        set({ slotId: id, busy: true, error: null });
        // Lock before draining autosave; nothing may race the expected combat revision.
        combat.setState({ closing: true });
        encounters.setState({ closing: true });
        work = Promise.resolve()
          .then(async () => {
            try {
              const saved = await Promise.all([
                combat.getState().flush(id),
                encounters.getState().flush(id),
              ]);
              if (!saved.every(Boolean)) {
                unlock();
                return false;
              }
              await dice.getState().load();
              if (!dice.getState().loaded) {
                unlock();
                dice.getState().setOpen(true);
                return false;
              }
              const current = combat
                .getState()
                .slots.find((s) => s.encounterId === id)!;
              const actor = combat
                .getState()
                .drafts[id]!.value.actors.find((a) => a.id === actorId)!;
              const bonus =
                characterBonus === undefined
                  ? enemyInitiative(actor)
                  : {
                      formula: `1k20${characterBonus >= 0 ? '+' : ''}${characterBonus}`,
                      penalty: 0,
                    };
              if (!bonus) {
                unlock();
                return false;
              }
              const result = execute(bonus.formula);
              let checkDice;
              if (options?.manual !== undefined) {
                if (
                  !Number.isInteger(options.manual) ||
                  options.manual < 1 ||
                  options.manual > 20
                )
                  throw Error('Ręczny wynik k20: 1–20.');
                result.values = [options.manual];
                result.total = options.manual + result.modifier;
              } else if (options && options.mode !== 'normal') {
                const values: [number, number] = [
                  result.values[0]!,
                  execute(bonus.formula).values[0]!,
                ];
                checkDice = { mode: options.mode, values };
                const face =
                  options.mode === 'advantage'
                    ? Math.max(...values)
                    : Math.min(...values);
                result.values = [face];
                result.total = face + result.modifier;
              }
              revision = current.revision;
              set({
                pending: diceRollSchema.parse({
                  ...result,
                  ...(checkDice ? { checkDice } : {}),
                  id: crypto.randomUUID(),
                  createdAt: new Date().toISOString(),
                  context: {
                    encounterId: id,
                    actorId,
                    actorName:
                      options?.name?.slice(0, 200) ?? actor.displayName.trim(),
                    roundNumber: current.roundNumber,
                    label: `Inicjatywa${bonus.penalty ? ` (Wyczerpanie −${bonus.penalty})` : ''}`,
                    purpose: 'initiative',
                    sourceKey: 'initiative',
                    ...(options?.rerollOf
                      ? {
                          rerollOf: options.rerollOf,
                          consumedEffects: options.consumedEffects,
                          participationRevision: options.participationRevision,
                        }
                      : {}),
                  },
                }),
              });
              return persist();
            } catch (error) {
              set({
                busy: false,
                error: error instanceof Error ? error.message : String(error),
              });
              return false;
            }
          })
          .finally(() => {
            work = undefined;
          });
        return work;
      },
      retry() {
        if (work) return work;
        if (!get().pending) return Promise.resolve(false);
        set({ busy: true, error: null });
        work = Promise.resolve()
          .then(persist)
          .finally(() => {
            work = undefined;
          });
        return work;
      },
      reload() {
        if (work) return work;
        if (get().slotId === null) return Promise.resolve(true);
        set({ busy: true, error: null });
        work = Promise.resolve()
          .then(async () => {
            try {
              await refresh();
              dice.setState({ loaded: false });
              await dice.getState().load();
              if (!dice.getState().loaded)
                throw Error('Nie udało się odczytać historii rzutów.');
              void useCombatLogStore.getState().refresh(get().slotId!);
              unlock();
              return true;
            } catch (error) {
              set({
                busy: false,
                error: error instanceof Error ? error.message : String(error),
              });
              return false;
            }
          })
          .finally(() => {
            work = undefined;
          });
        return work;
      },
      async prepareClose() {
        if (work) return work;
        return get().slotId === null;
      },
    };
  });
}
export const useInitiativeStore = createInitiativeStore();
