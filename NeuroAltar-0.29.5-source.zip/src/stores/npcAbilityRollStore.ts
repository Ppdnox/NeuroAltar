import { create } from 'zustand';
export const useNpcAbilityRollStore = create<{
  selected: Record<string, string>;
  select: (actorId: string, effectId: string) => void;
}>((set) => ({
  selected: {},
  select: (id, effect) =>
    set((s) => ({ selected: { ...s.selected, [id]: effect } })),
}));
