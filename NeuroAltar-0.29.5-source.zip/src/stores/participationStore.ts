import { useEncounterStore } from './encounterStore';
import { useCombatLogStore } from './combatLogStore';
import { loadCharacters } from '../db/characterRepository';
import { create } from 'zustand';
import { invoke } from '@tauri-apps/api/core';
import { openDatabase } from '../db/connection';
import {
  participationSchema,
  type Participation,
} from '../domain/character/participation';
import { useCharacterStore } from './characterStore';
import { useCombatStore } from './combatStore';
import { useNavigationStore } from './navigationStore';
import { toCombatDraft } from '../domain/combat';
import { createCombatRepository } from '../db/combatRepository';
import type { SlotId } from '../domain/encounterDetails';
interface Request {
  operationId: string;
  actorId: string;
  encounterId: SlotId;
  encounterRevision: number;
  expectedRevision: number | null;
  characterId: string;
  characterRevision: number;
  action: Record<string, unknown>;
}
function lock(value: boolean) {
  useCombatStore.setState({ closing: value });
  useEncounterStore.setState({ closing: value });
  useCharacterStore.setState({ locked: value });
}
async function readParticipations(): Promise<Participation[]> {
  const db = await openDatabase();
  const rows = (await db.selectRows(
    'SELECT payload_json FROM character_participations',
  )) as { payload_json: string }[];
  return rows.map((r) => participationSchema.parse(JSON.parse(r.payload_json)));
}

export const useParticipationStore = create<{
  entries: Participation[];
  busy: boolean;
  error: string | null;
  pending: Request | null;
  load: () => Promise<void>;
  send: (
    actorId: string,
    slot: SlotId,
    characterId: string,
    action: Record<string, unknown>,
  ) => Promise<boolean>;
  recover: () => Promise<void>;
  retry: () => Promise<boolean>;
}>((set, get) => ({
  entries: [],
  busy: false,
  error: null,
  pending: null,
  async load() {
    try {
      set({ entries: await readParticipations() });
    } catch (e) {
      set({ error: String(e) });
    }
  },
  async send(actorId, slot, characterId, action) {
    if (get().busy || get().pending) return false;
    const cs = useCharacterStore.getState();
    if (
      cs.locked ||
      Object.keys(cs.invalid).length ||
      useCombatStore.getState().closing ||
      useEncounterStore.getState().closing
    )
      return false;
    set({ busy: true });
    lock(true);
    try {
      if (
        !(await cs.flush()) ||
        !(await useCombatStore.getState().flush(slot)) ||
        !(await useEncounterStore.getState().flush(slot))
      ) {
        lock(false);
        set({
          busy: false,
          error: 'Najpierw popraw i zapisz dane karty BG lub potyczki.',
        });
        return false;
      }
      const c = useCharacterStore
          .getState()
          .records.find((c) => c.id === characterId),
        combat = useCombatStore
          .getState()
          .slots.find((s) => s.encounterId === slot),
        p = get().entries.find((p) => p.actorId === actorId);
      if (!c || !combat) {
        lock(false);
        set({
          busy: false,
          error: 'Nie można znaleźć karty BG lub potyczki. Odśwież podgląd.',
        });
        return false;
      }
      set({
        busy: false,
        pending: {
          operationId: crypto.randomUUID(),
          actorId,
          encounterId: slot,
          encounterRevision: combat.revision,
          expectedRevision: p?.revision ?? null,
          characterId,
          characterRevision: c.revision,
          action,
        },
      });
    } catch (e) {
      lock(false);
      set({
        busy: false,
        error: `Nie udało się przygotować powiązania: ${String(e)}`,
      });
      return false;
    }
    return get().retry();
  },
  async retry() {
    const request = get().pending;
    if (!request || get().busy) return false;
    set({ busy: true, error: null });
    lock(true);
    try {
      await invoke('participation_command', { request });
      // Re-read current values, including historical retries, never install an old result.
      const db = await openDatabase();
      const all = await createCombatRepository(db).listSlots();
      const current = all.find((s) => s.encounterId === request.encounterId);
      if (!current)
        throw new Error('Nie można odczytać potyczki. Ponów odczyt.');
      const entries = await readParticipations();
      const records = await loadCharacters();
      useCombatStore.setState((s) => ({
        slots: s.slots.map((x) =>
          x.encounterId === current.encounterId ? current : x,
        ),
        drafts: {
          ...s.drafts,
          [current.encounterId]: {
            value: toCombatDraft(current),
            status: 'saved',
            error: null,
          },
        },
      }));
      useCharacterStore.setState({ records });
      // Retain the operation ID until every dependent read succeeds. Retrying
      // an already committed operation is idempotent in the backend.
      set({ entries, pending: null });
      void useCombatLogStore.getState().refresh(request.encounterId);
      lock(false);
      return true;
    } catch (e) {
      set({ error: String(e) });
      return false;
    } finally {
      set({ busy: false });
    }
  },
  async recover() {
    if (get().busy) return;
    const request = get().pending;
    if (!request) {
      try {
        set({ entries: await readParticipations(), error: null });
      } catch (e) {
        set({ error: String(e) });
      }
      return;
    }
    set({ busy: true });
    try {
      const db = await openDatabase();
      const committed = await db.selectRows(
        'SELECT operation_id FROM participation_operations WHERE operation_id=?',
        [request.operationId],
      );
      if (Array.isArray(committed) && committed.length) {
        set({ busy: false });
        await get().retry();
        return;
      }
      const all = await createCombatRepository(db).listSlots();
      const current = all.find((s) => s.encounterId === request.encounterId);
      if (!current)
        throw new Error('Nie można odczytać potyczki. Ponów odczyt.');
      const entries = await readParticipations();
      const records = await loadCharacters();
      useCombatStore.setState((s) => ({
        slots: s.slots.map((x) =>
          x.encounterId === current.encounterId ? current : x,
        ),
        drafts: {
          ...s.drafts,
          [current.encounterId]: {
            value: toCombatDraft(current),
            status: 'saved',
            error: null,
          },
        },
      }));
      useCharacterStore.setState({ records });
      set({ entries, pending: null, error: null });
      lock(false);
    } catch (e) {
      set({ error: String(e) });
    } finally {
      set({ busy: false });
    }
  },
}));
export function prepareParticipationClose() {
  const s = useParticipationStore.getState();
  if (s.busy || s.pending) {
    useNavigationStore.getState().revealCloseIssue('gm');
    return false;
  }
  return true;
}
