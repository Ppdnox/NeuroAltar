import { create } from 'zustand';
import type { SlotId } from '../domain/encounterDetails';
import type { CombatLogEntry } from '../domain/combatLog';
import { loadCombatLog } from '../services/combatLog';
interface LogState {
  entries: CombatLogEntry[];
  hasMore: boolean;
  status: 'loading' | 'ready' | 'error';
  error: string | null;
}
interface LogStore {
  slots: Partial<Record<SlotId, LogState>>;
  refresh(id: SlotId): Promise<void>;
  older(id: SlotId): Promise<void>;
}
export function createCombatLogStore(load = loadCombatLog) {
  const requests = new Map<SlotId, number>();
  return create<LogStore>((set, get) => {
    const read = async (id: SlotId, older: boolean) => {
      const old = get().slots[id];
      if (
        older &&
        (!old?.hasMore || old.status === 'loading' || !old.entries.length)
      )
        return;
      const token = (requests.get(id) ?? 0) + 1;
      requests.set(id, token);
      const update = (value: LogState) =>
        set((state) => ({ slots: { ...state.slots, [id]: value } }));
      update({
        entries: old?.entries ?? [],
        hasMore: old?.hasMore ?? false,
        status: 'loading',
        error: null,
      });
      try {
        const page = await load(
          id,
          older ? old!.entries.at(-1)!.id : undefined,
        );
        if (requests.get(id) !== token) return;
        update({
          entries: older ? [...old!.entries, ...page.entries] : page.entries,
          hasMore: page.hasMore,
          status: 'ready',
          error: null,
        });
      } catch (error) {
        if (requests.get(id) !== token) return;
        update({
          entries: old?.entries ?? [],
          hasMore: old?.hasMore ?? false,
          status: 'error',
          error:
            typeof error === 'string'
              ? error
              : error instanceof Error
                ? error.message
                : 'Nie udało się odczytać logu.',
        });
      }
    };
    return {
      slots: {},
      refresh: (id) => read(id, false),
      older: (id) => read(id, true),
    };
  });
}
export const useCombatLogStore = createCombatLogStore();
