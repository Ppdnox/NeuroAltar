import { create } from 'zustand';
import { listKnowledge } from '../data/knowledge/catalog';
import type { KnowledgeEntry } from '../domain/knowledge';
interface KnowledgeStore {
  entries: KnowledgeEntry[];
  loaded: boolean;
  error: string | null;
  query: string;
  category: string;
  selectedId: string | null;
  load(): void;
  search(query: string): void;
  filter(category: string): void;
  select(selectedId: string): void;
}
export function createKnowledgeStore(load = listKnowledge) {
  return create<KnowledgeStore>((set) => ({
    entries: [],
    loaded: false,
    error: null,
    query: '',
    category: '',
    selectedId: null,
    load() {
      try {
        set({ entries: load(), loaded: true, error: null });
      } catch (error) {
        set({ error: `Nie odczytano Wiedzy MG: ${String(error)}` });
      }
    },
    search(query) {
      set({ query, selectedId: null });
    },
    filter(category) {
      set({ category, selectedId: null });
    },
    select(selectedId) {
      set({ selectedId });
    },
  }));
}
export const useKnowledgeStore = createKnowledgeStore();
