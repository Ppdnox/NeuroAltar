import { create } from 'zustand';

export type AppPage = 'home' | 'gm' | 'character';
// Session navigation only. Combat state and persistence belong to their stores.
export const useNavigationStore = create<{
  page: AppPage;
  closeIssue: number;
  navigate: (page: AppPage) => void;
  revealCloseIssue: (page?: AppPage) => void;
}>((set) => ({
  page: 'home',
  closeIssue: 0,
  navigate: (page) => set({ page }),
  revealCloseIssue: (page = 'gm') =>
    set((s) => ({ page, closeIssue: s.closeIssue + 1 })),
}));
