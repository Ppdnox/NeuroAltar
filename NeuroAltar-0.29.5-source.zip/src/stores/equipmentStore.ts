import { create } from 'zustand';
import { loadEquipment } from '../db/equipmentRepository';
import type { Item } from '../domain/item';
import {
  BASE_TRADE_CONTEXT,
  tradeContextSchema,
  type TradeContext,
} from '../domain/market';
interface EquipmentStore {
  items: Item[];
  loading: boolean;
  loaded: boolean;
  error: string | null;
  query: string;
  type: Item['type'] | '';
  category: string;
  selectedId: string | null;
  context: TradeContext;
  load(): Promise<void>;
  setFilters(
    patch: Partial<Pick<EquipmentStore, 'query' | 'type' | 'category'>>,
  ): void;
  select(id: string): void;
  setContext(context: TradeContext): void;
}
export function createEquipmentStore(load = loadEquipment) {
  return create<EquipmentStore>((set, get) => ({
    items: [],
    loading: false,
    loaded: false,
    error: null,
    query: '',
    type: '',
    category: '',
    selectedId: null,
    context: structuredClone(BASE_TRADE_CONTEXT),
    async load() {
      if (get().loading) return;
      set({ loading: true, error: null });
      try {
        set({ items: await load(), loaded: true });
      } catch (error) {
        set({ error: `Nie odczytano Ekwipunku: ${String(error)}` });
      } finally {
        set({ loading: false });
      }
    },
    setFilters(patch) {
      set({ ...patch, selectedId: null });
    },
    select(selectedId) {
      set({ selectedId });
    },
    setContext(context) {
      set({ context: tradeContextSchema.parse(context) });
    },
  }));
}
export const useEquipmentStore = createEquipmentStore();
