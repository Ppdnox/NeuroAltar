import { create } from 'zustand';
import {
  encounterSlotsSchema,
  SLOT_IDS,
  type Encounter,
} from '../domain/encounter';
import {
  parseEncounterDetailsDraft,
  detailsDraftError,
  sameDetails,
  type EncounterDetailsDraft,
  type SlotId,
} from '../domain/encounterDetails';
import { loadEncounterSlots } from '../services/bootstrap';
import { saveEncounterDetails } from '../services/encounters';

export type SaveStatus = 'saved' | 'pending' | 'saving' | 'error' | 'invalid';
interface SlotDraft {
  details: EncounterDetailsDraft;
  status: SaveStatus;
  error: string | null;
}
interface EncounterState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  slots: Encounter[];
  drafts: Partial<Record<SlotId, SlotDraft>>;
  activeId: SlotId;
  error: string | null;
  closing: boolean;
  closeError: string | null;
  initialize(): Promise<void>;
  selectSlot(id: SlotId): void;
  edit(id: SlotId, patch: Partial<EncounterDetailsDraft>): void;
  flush(id: SlotId): Promise<boolean>;
  prepareClose(): Promise<boolean>;
}
export function createEncounterStore(
  load = loadEncounterSlots,
  save = saveEncounterDetails,
  delay = 400,
) {
  const timers = new Map<SlotId, ReturnType<typeof setTimeout>>();
  const writes = new Map<SlotId, Promise<boolean>>();
  const clearTimer = (id: SlotId) => {
    clearTimeout(timers.get(id));
    timers.delete(id);
  };
  return create<EncounterState>((set, get) => {
    const updateDraft = (id: SlotId, patch: Partial<SlotDraft>) =>
      set((state) => ({
        drafts: { ...state.drafts, [id]: { ...state.drafts[id]!, ...patch } },
      }));
    return {
      status: 'idle',
      slots: [],
      drafts: {},
      activeId: 1,
      error: null,
      closing: false,
      closeError: null,
      async initialize() {
        if (get().status === 'loading' || get().status === 'ready') return;
        set({ status: 'loading', error: null });
        try {
          const slots = encounterSlotsSchema.parse(await load());
          const drafts = Object.fromEntries(
            slots.map((slot) => [
              slot.id,
              {
                details: {
                  name: slot.name,
                  notes: slot.notes,
                  partyLevelsText: slot.partyLevels.join('\n'),
                },
                status: 'saved',
                error: null,
              },
            ]),
          );
          set({ status: 'ready', slots, drafts });
        } catch (error) {
          set({
            status: 'error',
            error:
              error instanceof Error
                ? error.message
                : 'Nie udało się otworzyć bazy.',
          });
        }
      },
      selectSlot(id) {
        if (get().closing || !get().drafts[id]) return;
        void get().flush(get().activeId);
        set({ activeId: id });
      },
      edit(id, patch) {
        const draft = get().drafts[id];
        if (!draft || get().closing) return;
        clearTimer(id);
        const details = { ...draft.details, ...patch };
        const error = detailsDraftError(details);
        const valid = error === null;
        updateDraft(id, {
          details,
          status: valid ? 'pending' : 'invalid',
          error,
        });
        set({ closeError: null });
        if (valid)
          timers.set(
            id,
            setTimeout(() => {
              void get().flush(id);
            }, delay),
          );
      },
      flush(id) {
        clearTimer(id);
        const existing = writes.get(id);
        if (existing) return existing;
        // Defer the worker so its promise is registered before it can finish.
        const task = Promise.resolve()
          .then(async () => {
            for (;;) {
              const draft = get().drafts[id];
              if (!draft) return true;
              if (detailsDraftError(draft.details)) return false;
              const snapshot = parseEncounterDetailsDraft(draft.details);
              const saved = get().slots.find((slot) => slot.id === id)!;
              if (sameDetails(snapshot, saved)) {
                updateDraft(id, { status: 'saved', error: null });
                return true;
              }
              updateDraft(id, { status: 'saving', error: null });
              try {
                const updatedAt = await save(id, snapshot, {
                  name: saved.name,
                  notes: saved.notes,
                  partyLevels: saved.partyLevels,
                });
                set((state) => ({
                  slots: state.slots.map((slot) =>
                    slot.id === id ? { ...slot, ...snapshot, updatedAt } : slot,
                  ),
                }));
                // The loop reads the latest draft; a stale response never replaces it.
              } catch (error) {
                updateDraft(id, {
                  status: 'error',
                  error:
                    error instanceof Error
                      ? error.message
                      : 'Nie udało się zapisać zmian.',
                });
                return false;
              }
            }
          })
          .finally(() => {
            writes.delete(id);
          });
        writes.set(id, task);
        return task;
      },
      async prepareClose() {
        if (get().closing) return false;
        set({ closing: true, closeError: null });
        const results = await Promise.all(
          SLOT_IDS.map((id) => get().flush(id)),
        );
        if (results.every(Boolean)) return true;
        const failed = SLOT_IDS.find((id) =>
          ['error', 'invalid'].includes(get().drafts[id]?.status ?? ''),
        );
        set({
          closing: false,
          activeId: failed ?? get().activeId,
          closeError:
            'Aplikacja pozostaje otwarta: popraw dane potyczki lub ponów zapis przed zamknięciem.',
        });
        return false;
      },
    };
  });
}
export const useEncounterStore = createEncounterStore();
