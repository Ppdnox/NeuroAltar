import {
  parseStatblockDraft,
  toStatblockDraft,
  type StatblockDraft,
} from '../domain/statblock';
import { validationMessage } from '../domain/validation';
import {
  applyMachineFailure,
  repairMachineFailure,
} from '../domain/machineFailures';
import {
  newFailureDraft,
  type FailureDraft,
} from '../domain/machineFailureSchema';
import {
  emptyLoadout,
  selectWeaponVariant,
  type EquippedItem,
} from '../domain/item';
import {
  toLoadoutDraft,
  parseLoadoutDraft,
  type LoadoutDraft,
} from '../domain/itemDraft';
import {
  capabilities,
  consumeCapability,
  adjustResource,
  restoreBudget,
  refreshCapabilities,
} from '../domain/capabilities';
import {
  toCapabilityDraft,
  parseCapabilityDraft,
  type CapabilityDraft,
  type ActionKind,
} from '../domain/capabilitySchema';
import {
  applyInjuryLevel,
  changeExhaustion,
  setInjuryEnabled,
} from '../domain/injury';
import {
  newStatusDraft,
  parseStatusDraft,
  statusListSchema,
  type StatusDraft,
} from '../domain/status';
import type { SaveReason } from '../domain/combatLog';
import {
  newEnemyTemplateDraft,
  parseEnemyTemplateDraft,
  type EnemyTemplateDraft,
  type EnemyTemplate,
} from '../domain/enemy';
import { create } from 'zustand';
import { SLOT_IDS } from '../domain/encounter';
import type { SlotId } from '../domain/encounterDetails';
import {
  combatSlotsSchema,
  instantiateEnemy,
  prepareActor,
  prepareCombat,
  resetEncounter,
  nextCombatTurn,
  parseCombatDraft,
  parseActorDraft,
  reorderTie,
  toCombatDraft,
  toActorDraft,
  type Combat,
  type CombatDraft,
  type ActorDraft,
} from '../domain/combat';
import {
  loadCombatSlots,
  saveCombat,
  PARTICIPATION_RESET_REJECTION,
  isParticipationResetRejection,
} from '../services/combat';
import type { SaveStatus } from './encounterStore';
import { useParticipationStore } from './participationStore';

interface DraftState {
  value: CombatDraft;
  status: SaveStatus;
  error: string | null;
}
interface CombatStore {
  failureForm: {
    slotId: SlotId;
    actorId: string;
    fields: FailureDraft;
    error: string | null;
  } | null;
  openFailureForm(id: SlotId, actorId: string): void;
  editFailureForm(patch: Partial<FailureDraft>): void;
  cancelFailureForm(): void;
  submitFailureForm(): void;
  repairFailure(id: SlotId, actorId: string, failureId: string): void;

  statblockForm: {
    slotId: SlotId;
    actorId: string;
    fields: StatblockDraft;
    error: string | null;
  } | null;
  openStatblockForm(id: SlotId, actorId: string): void;
  editStatblockForm(fields: StatblockDraft): void;
  cancelStatblockForm(): void;
  submitStatblockForm(): void;

  loadoutForm: {
    slotId: SlotId;
    actorId: string;
    fields: LoadoutDraft;
    error: string | null;
  } | null;
  openLoadoutForm(id: SlotId, actorId: string): void;
  editLoadoutForm(fields: LoadoutDraft): void;
  cancelLoadoutForm(): void;
  submitLoadoutForm(): void;
  selectWeapon(
    id: SlotId,
    actorId: string,
    itemId: string,
    patch: Partial<
      Pick<EquippedItem, 'damageModeId' | 'fireModeId' | 'ammoVariantId'>
    >,
  ): void;

  capabilityForm: {
    slotId: SlotId;
    actorId: string;
    fields: CapabilityDraft;
    error: string | null;
  } | null;
  openCapabilityForm(id: SlotId, actorId: string): void;
  editCapabilityForm(fields: CapabilityDraft): void;
  cancelCapabilityForm(): void;
  submitCapabilityForm(): void;
  useCapability(
    id: SlotId,
    actorId: string,
    key: string,
    override?: boolean,
  ): void;
  adjustResource(
    id: SlotId,
    actorId: string,
    resourceId: string,
    delta: -1 | 1,
  ): void;
  restoreBudget(id: SlotId, actorId: string, kind: ActionKind): void;
  refreshResources(id: SlotId, event: 'encounter' | 'day'): void;
  status: 'idle' | 'loading' | 'ready' | 'error';
  slots: Combat[];
  drafts: Partial<Record<SlotId, DraftState>>;
  selected: Partial<Record<SlotId, string | null>>;
  statusForm: {
    slotId: SlotId;
    actorId: string;
    statusId: string;
    fields: StatusDraft;
    error: string | null;
  } | null;
  openStatusForm(id: SlotId, actorId: string, statusId?: string): void;
  editStatusForm(patch: Partial<StatusDraft>): void;
  cancelStatusForm(): void;
  submitStatusForm(): void;
  removeStatus(id: SlotId, actorId: string, statusId: string): void;
  setInjuryEnabled(id: SlotId, actorId: string, enabled: boolean): void;
  setInjuryLevel(id: SlotId, actorId: string, level: number): void;
  adjustExhaustion(id: SlotId, actorId: string, delta: -1 | 1): void;
  enemyForm: {
    slotId: SlotId;
    templateId: string;
    fields: EnemyTemplateDraft;
    error: string | null;
  } | null;
  openEnemyForm(id: SlotId): void;
  editEnemyForm(patch: Partial<EnemyTemplateDraft>): void;
  cancelEnemyForm(): void;
  submitEnemyForm(): void;
  error: string | null;
  closing: boolean;
  initialize(): Promise<void>;
  selectActor(id: SlotId, actorId: string): void;
  addActor(id: SlotId): void;
  addEnemy(id: SlotId, template: EnemyTemplate): void;
  addEnemies(id: SlotId, template: EnemyTemplate, count: number): boolean;
  prepareEncounter(id: SlotId): void;
  resetEncounter(id: SlotId): void;
  clearLog(id: SlotId): void;
  editActor(
    id: SlotId,
    actorId: string,
    patch: Partial<
      Omit<ActorDraft, 'id' | 'initiativeTieOrder' | 'prepared' | 'enemy'>
    >,
  ): void;
  removeActor(id: SlotId, actorId: string): void;
  adjustHp(id: SlotId, actorId: string, delta: number): void;
  nextTurn(id: SlotId): void;
  setCurrent(id: SlotId, actorId: string): void;
  moveTie(id: SlotId, actorId: string, direction: -1 | 1): void;
  flush(id: SlotId): Promise<boolean>;
  prepareClose(): Promise<boolean>;
}
const invalidMessage =
  'Uzupełnij nazwę i całkowite wartości TT oraz PW (0 ≤ PW ≤ maks., maks. ≥ 1). Inicjatywa może być pusta lub całkowita. Ruch wpisz jako rodzaj: metry (np. Szybkość: 9), po jednym w wierszu. Tchórzliwość: całkowite 0–100% lub puste pole. Próg awarii: całkowita liczba ≥ 0 albo puste pole. SP: liczba ≥ 0 (np. 2,5) albo puste pole.';
const content = (combat: Combat) =>
  JSON.stringify({
    roundNumber: combat.roundNumber,
    currentTurnActorId: combat.currentTurnActorId,
    actors: combat.actors,
  });

// Undo only the rejected reset. Fields edited afterwards win over the restored
// values; keyed collections retain later additions/removals and per-actor edits.
function restoreRejectedReset(
  current: unknown,
  rejected: unknown,
  before: unknown,
): unknown {
  if (JSON.stringify(current) === JSON.stringify(rejected))
    return structuredClone(before);
  const keyed = (v: unknown): v is { id: string }[] =>
    Array.isArray(v) &&
    v.every(
      (item) => item && typeof item === 'object' && typeof item.id === 'string',
    );
  if (keyed(current) && keyed(rejected) && keyed(before)) {
    return [
      ...current.map((item) => {
        const old = rejected.find((entry) => entry.id === item.id);
        const original = before.find((entry) => entry.id === item.id);
        return old && original
          ? restoreRejectedReset(item, old, original)
          : structuredClone(item);
      }),
      ...before
        .filter(
          (item) =>
            !rejected.some((entry) => entry.id === item.id) &&
            !current.some((entry) => entry.id === item.id),
        )
        .map((item) => structuredClone(item)),
    ];
  }
  const object = (v: unknown): v is Record<string, unknown> =>
    !!v && typeof v === 'object' && !Array.isArray(v);
  if (object(current) && object(rejected) && object(before)) {
    const result: Record<string, unknown> = {};
    for (const key of new Set([
      ...Object.keys(current),
      ...Object.keys(before),
    ])) {
      if (!(key in current)) {
        if (!(key in rejected)) result[key] = structuredClone(before[key]);
      } else {
        result[key] = restoreRejectedReset(
          current[key],
          rejected[key],
          before[key],
        );
      }
    }
    return result;
  }
  return structuredClone(current);
}

export function createCombatStore(
  load = loadCombatSlots,
  save = saveCombat,
  delay = 400,
) {
  const timers = new Map<SlotId, ReturnType<typeof setTimeout>>();
  const writes = new Map<SlotId, Promise<boolean>>();
  const checkpoints = new Map<
    SlotId,
    { value: Combat; reason: SaveReason }[]
  >();
  const clearTimer = (id: SlotId) => {
    clearTimeout(timers.get(id));
    timers.delete(id);
  };
  return create<CombatStore>((set, get) => {
    const updateDraft = (id: SlotId, patch: Partial<DraftState>) =>
      set((state) => ({
        drafts: { ...state.drafts, [id]: { ...state.drafts[id]!, ...patch } },
      }));
    const edit = (
      id: SlotId,
      transform: (draft: CombatDraft) => CombatDraft,
    ) => {
      const current = get().drafts[id];
      if (!current || get().closing) return;
      clearTimer(id);
      const value = transform(current.value);
      let valid = false;
      try {
        parseCombatDraft(
          value,
          get().slots.find((s) => s.encounterId === id)!,
        );
        valid = true;
      } catch {
        /* Retain incomplete input until corrected. */
      }
      updateDraft(id, {
        value,
        status: valid ? 'pending' : 'invalid',
        error: valid ? null : invalidMessage,
      });
      if (valid)
        timers.set(
          id,
          setTimeout(() => {
            void get().flush(id);
          }, delay),
        );
    };
    const checkpoint = (
      id: SlotId,
      value: Combat,
      reason: SaveReason = 'edit',
    ) => {
      const queue = checkpoints.get(id) ?? [];
      const previous =
        queue.at(-1)?.value ?? get().slots.find((s) => s.encounterId === id)!;
      if (reason === 'edit' && content(previous) === content(value)) return;
      queue.push({ value: structuredClone(value), reason });
      checkpoints.set(id, queue);
    };
    const checkpointDraft = (id: SlotId) => {
      try {
        checkpoint(
          id,
          parseCombatDraft(
            get().drafts[id]!.value,
            get().slots.find((s) => s.encounterId === id)!,
          ),
        );
      } catch {
        /* A malformed form stays a draft; never write it as a log event. */
      }
    };
    const action = (
      id: SlotId,
      transform: (combat: Combat) => Combat,
      reason: SaveReason = 'edit',
    ) => {
      if (get().closing || !get().drafts[id]) return;
      try {
        const valid = parseCombatDraft(
          get().drafts[id]!.value,
          get().slots.find((s) => s.encounterId === id)!,
        );
        const next = transform(valid);
        checkpoint(id, valid);
        checkpoint(id, next, reason);
        edit(id, () => toCombatDraft(next));
        void get().flush(id);
      } catch (error) {
        updateDraft(id, {
          status: 'invalid',
          error:
            error instanceof Error &&
            error.message.includes('maksymalny numer rundy')
              ? error.message
              : invalidMessage,
        });
      }
    };
    return {
      failureForm: null,
      openFailureForm(id, actorId) {
        if (
          get().closing ||
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().enemyForm
        )
          return;
        const draft = get().drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!draft || draft.enemy?.template.category !== 'machine') return;
        try {
          parseActorDraft(draft);
          set({
            failureForm: {
              slotId: id,
              actorId,
              fields: newFailureDraft(),
              error: null,
            },
          });
        } catch {
          return;
        }
      },
      editFailureForm(patch) {
        const form = get().failureForm;
        if (form && !get().closing)
          set({
            failureForm: {
              ...form,
              fields: { ...form.fields, ...patch },
              error: null,
            },
          });
      },
      cancelFailureForm() {
        if (!get().closing) set({ failureForm: null });
      },
      submitFailureForm() {
        const form = get().failureForm;
        if (!form || get().closing) return;
        try {
          const current = parseCombatDraft(
            get().drafts[form.slotId]!.value,
            get().slots.find((s) => s.encounterId === form.slotId)!,
          );
          const actor = current.actors.find((a) => a.id === form.actorId);
          if (!actor) throw new Error('Brak postaci.');
          const updated = applyMachineFailure(
            actor,
            form.fields,
            current.currentTurnActorId === actor.id,
          );
          action(form.slotId, (c) => ({
            ...c,
            actors: c.actors.map((a) => (a.id === actor.id ? updated : a)),
          }));
          set({ failureForm: null });
        } catch {
          set({
            failureForm: {
              ...form,
              error:
                'Wpisz całkowity wynik 1–20, poprawne obrażenia (lub puste). Dla 1 wybierz broń, dla 4 rodzaj blokady. Zachowano formularz.',
            },
          });
        }
      },
      repairFailure(id, actorId, failureId) {
        if (
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().enemyForm
        )
          return;
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? repairMachineFailure(a, failureId) : a,
          ),
        }));
      },
      statblockForm: null,
      openStatblockForm(id, actorId) {
        if (
          get().closing ||
          get().failureForm ||
          get().loadoutForm ||
          get().statblockForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().enemyForm
        )
          return;
        const draft = get().drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!draft?.enemy) return;
        try {
          const actor = parseActorDraft(draft);
          set({
            statblockForm: {
              slotId: id,
              actorId,
              fields: toStatblockDraft(actor.enemy!.statblock),
              error: null,
            },
          });
        } catch {
          return;
        }
      },
      editStatblockForm(fields) {
        const form = get().statblockForm;
        if (form && !get().closing)
          set({ statblockForm: { ...form, fields, error: null } });
      },
      cancelStatblockForm() {
        if (!get().closing) set({ statblockForm: null });
      },
      submitStatblockForm() {
        const form = get().statblockForm;
        if (!form || get().closing) return;
        try {
          const statblock = parseStatblockDraft(form.fields);
          const current = parseCombatDraft(
            get().drafts[form.slotId]!.value,
            get().slots.find((s) => s.encounterId === form.slotId)!,
          );
          if (!current.actors.some((a) => a.id === form.actorId && a.enemy))
            throw new Error('Brak postaci.');
          action(form.slotId, (c) => ({
            ...c,
            actors: c.actors.map((a) =>
              a.id === form.actorId
                ? { ...a, enemy: { ...a.enemy!, statblock } }
                : a,
            ),
          }));
          set({ statblockForm: null });
        } catch {
          set({
            statblockForm: {
              ...form,
              error: 'Popraw wskazane pola statblocka. Zachowano formularz.',
            },
          });
        }
      },
      loadoutForm: null,
      openLoadoutForm(id, actorId) {
        if (
          get().closing ||
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().enemyForm
        )
          return;
        const draft = get().drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!draft?.enemy) return;
        try {
          const actor = parseActorDraft(draft);
          set({
            loadoutForm: {
              slotId: id,
              actorId,
              fields: toLoadoutDraft(actor.enemy!.loadout ?? emptyLoadout()),
              error: null,
            },
          });
        } catch {
          return;
        }
      },
      editLoadoutForm(fields) {
        const form = get().loadoutForm;
        if (form && !get().closing)
          set({ loadoutForm: { ...form, fields, error: null } });
      },
      cancelLoadoutForm() {
        if (!get().closing) set({ loadoutForm: null });
      },
      submitLoadoutForm() {
        const form = get().loadoutForm;
        if (!form || get().closing) return;
        try {
          const loadout = parseLoadoutDraft(form.fields);
          const current = parseCombatDraft(
            get().drafts[form.slotId]!.value,
            get().slots.find((s) => s.encounterId === form.slotId)!,
          );
          if (!current.actors.some((a) => a.id === form.actorId && a.enemy))
            throw new Error('Brak postaci.');
          action(form.slotId, (c) => ({
            ...c,
            actors: c.actors.map((a) =>
              a.id === form.actorId
                ? { ...a, enemy: { ...a.enemy!, loadout } }
                : a,
            ),
          }));
          set({ loadoutForm: null });
        } catch {
          set({
            loadoutForm: {
              ...form,
              error:
                'Sprawdź nazwy, liczby, zasięgi, formuły i warianty broni. Zachowano formularz.',
            },
          });
        }
      },
      selectWeapon(id, actorId, itemId, patch) {
        if (
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().enemyForm
        )
          return;
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId && a.enemy?.loadout
              ? {
                  ...a,
                  enemy: {
                    ...a.enemy,
                    loadout: selectWeaponVariant(
                      a.enemy.loadout,
                      itemId,
                      patch,
                    ),
                  },
                }
              : a,
          ),
        }));
      },
      capabilityForm: null,
      openCapabilityForm(id, actorId) {
        if (
          get().closing ||
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().enemyForm ||
          get().statusForm ||
          get().capabilityForm
        )
          return;
        const draft = get().drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!draft?.enemy) return;
        try {
          const actor = parseActorDraft(draft);
          set({
            capabilityForm: {
              slotId: id,
              actorId,
              fields: toCapabilityDraft(capabilities(actor)),
              error: null,
            },
          });
        } catch {
          return;
        }
      },
      editCapabilityForm(fields) {
        const form = get().capabilityForm;
        if (form && !get().closing)
          set({ capabilityForm: { ...form, fields, error: null } });
      },
      cancelCapabilityForm() {
        if (!get().closing) set({ capabilityForm: null });
      },
      submitCapabilityForm() {
        const form = get().capabilityForm;
        if (!form || get().closing) return;
        try {
          const draft = get().drafts[form.slotId]?.value.actors.find(
            (a) => a.id === form.actorId,
          );
          if (!draft?.enemy) throw new Error('Brak przeciwnika.');
          const current = parseActorDraft(draft);
          const next = parseCapabilityDraft(form.fields, capabilities(current));
          action(form.slotId, (c) => ({
            ...c,
            actors: c.actors.map((a) =>
              a.id === form.actorId
                ? { ...a, enemy: { ...a.enemy!, capabilities: next } }
                : a,
            ),
          }));
          set({ capabilityForm: null });
        } catch {
          set({
            capabilityForm: {
              ...form,
              error:
                'Wpisz nazwy, całkowite liczniki 0–999 (maksimum co najmniej 1), poprawne koszty i istniejące zasoby. Koszt nie może przekraczać maksimum. Usuń powiązanie akcji przed usunięciem zasobu.',
            },
          });
        }
      },
      useCapability(id, actorId, key, override = false) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? consumeCapability(a, key, override) : a,
          ),
        }));
      },
      adjustResource(id, actorId, resourceId, delta) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? adjustResource(a, resourceId, delta) : a,
          ),
        }));
      },
      restoreBudget(id, actorId, kind) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? restoreBudget(a, kind) : a,
          ),
        }));
      },
      refreshResources(id, event) {
        action(
          id,
          (c) => ({
            ...c,
            actors: c.actors.map((a) => refreshCapabilities(a, event)),
          }),
          event === 'day' ? 'new_day' : 'renew_encounter',
        );
      },
      statusForm: null,
      openStatusForm(id, actorId, statusId) {
        if (
          get().closing ||
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().enemyForm ||
          get().capabilityForm ||
          get().statusForm
        )
          return;
        const actor = get().drafts[id]?.value.actors.find(
          (a) => a.id === actorId,
        );
        if (!actor) return;
        const effect = actor.effects?.find((s) => s.id === statusId);
        if (statusId && !effect) return;
        set({
          statusForm: {
            slotId: id,
            actorId,
            statusId: effect?.id ?? crypto.randomUUID(),
            error: null,
            fields: effect
              ? {
                  systemKey: effect.systemKey,
                  name: effect.name,
                  description: effect.description,
                  sourceText: effect.sourceText,
                  durationType: effect.durationType,
                  rounds: String(effect.durationValue ?? 1),
                  level: String(effect.level ?? 1),
                }
              : newStatusDraft(),
          },
        });
      },
      editStatusForm(patch) {
        const form = get().statusForm;
        if (form && !get().closing)
          set({
            statusForm: {
              ...form,
              fields: { ...form.fields, ...patch },
              error: null,
            },
          });
      },
      cancelStatusForm() {
        if (!get().closing) set({ statusForm: null });
      },
      submitStatusForm() {
        const form = get().statusForm;
        if (!form || get().closing) return;
        try {
          const saved = get().slots.find((s) => s.encounterId === form.slotId)!;
          const combat = parseCombatDraft(
            get().drafts[form.slotId]!.value,
            saved,
          );
          const actor = combat.actors.find((a) => a.id === form.actorId);
          if (!actor) throw new Error('Brak postaci.');
          const effect = parseStatusDraft(
            form.fields,
            combat.currentTurnActorId === actor.id,
            form.statusId,
          );
          const effects = statusListSchema
            .parse([
              ...(actor.effects ?? []).filter((s) => s.id !== effect.id),
              effect,
            ])
            .sort((a, b) => a.id.localeCompare(b.id));
          action(form.slotId, (c) => ({
            ...c,
            actors: c.actors.map((a) =>
              a.id === actor.id ? { ...a, effects } : a,
            ),
          }));
          set({ statusForm: null });
        } catch {
          set({
            statusForm: {
              ...form,
              error:
                'Sprawdź dane postaci, nazwę statusu, rundy (1–999) i poziom (1–6). Wyczerpanie ma jeden wspólny licznik.',
            },
          });
        }
      },
      removeStatus(id, actorId, statusId) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId
              ? {
                  ...a,
                  effects: (a.effects ?? []).filter((s) => s.id !== statusId),
                }
              : a,
          ),
        }));
      },
      setInjuryEnabled(id, actorId, enabled) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? setInjuryEnabled(a, enabled) : a,
          ),
        }));
      },
      setInjuryLevel(id, actorId, level) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId ? applyInjuryLevel(a, level) : a,
          ),
        }));
      },
      adjustExhaustion(id, actorId, delta) {
        action(id, (c) => ({
          ...c,
          actors: c.actors.map((a) =>
            a.id === actorId
              ? { ...a, effects: changeExhaustion(a.effects ?? [], delta) }
              : a,
          ),
        }));
      },
      enemyForm: null,
      openEnemyForm(id) {
        if (get().closing) return;
        if (
          get().enemyForm ||
          get().capabilityForm ||
          get().statusForm ||
          get().failureForm ||
          get().statblockForm ||
          get().loadoutForm
        )
          return;
        set({
          enemyForm: {
            slotId: id,
            templateId: crypto.randomUUID(),
            fields: newEnemyTemplateDraft(),
            error: null,
          },
        });
      },
      editEnemyForm(patch) {
        const form = get().enemyForm;
        if (!form || get().closing) return;
        set({
          enemyForm: {
            ...form,
            fields: { ...form.fields, ...patch },
            error: null,
          },
        });
      },
      cancelEnemyForm() {
        if (!get().closing) set({ enemyForm: null });
      },
      submitEnemyForm() {
        const form = get().enemyForm;
        if (!form || get().closing) return;
        try {
          const template = parseEnemyTemplateDraft(
            form.fields,
            form.templateId,
          );
          const before = get().drafts[form.slotId]!.value.actors.length;
          get().addEnemy(form.slotId, template);
          if (get().drafts[form.slotId]!.value.actors.length > before)
            set({ enemyForm: null });
        } catch (error) {
          set({
            enemyForm: {
              ...form,
              error: validationMessage(error),
            },
          });
        }
      },
      status: 'idle',
      slots: [],
      drafts: {},
      selected: {},
      error: null,
      closing: false,
      async initialize() {
        if (get().status === 'loading' || get().status === 'ready') return;
        set({ status: 'loading', error: null });
        try {
          const slots = combatSlotsSchema.parse(await load());
          set({
            status: 'ready',
            slots,
            drafts: Object.fromEntries(
              slots.map((s) => [
                s.encounterId,
                { value: toCombatDraft(s), status: 'saved', error: null },
              ]),
            ),
            selected: Object.fromEntries(
              slots.map((s) => [
                s.encounterId,
                s.currentTurnActorId ?? s.actors[0]?.id ?? null,
              ]),
            ),
          });
        } catch (error) {
          set({
            status: 'error',
            error:
              error instanceof Error
                ? error.message
                : 'Nie udało się odczytać postaci.',
          });
        }
      },
      selectActor(id, actorId) {
        if (get().closing) return;
        set((state) => ({ selected: { ...state.selected, [id]: actorId } }));
      },
      addActor(id) {
        if (get().closing || !get().drafts[id]) return;
        checkpointDraft(id);
        const actorId = crypto.randomUUID();
        const order =
          Math.max(
            -1,
            ...get().drafts[id]!.value.actors.map(
              (pc) => pc.initiativeTieOrder,
            ),
          ) + 1;
        edit(id, (draft) => ({
          ...draft,
          actors: [
            ...draft.actors,
            toActorDraft(
              prepareActor({
                id: actorId,
                displayName: 'Nowy BG',
                ttCurrent: 10,
                hpCurrent: 1,
                hpMaxCurrent: 1,
                initiativeValue: null,
                initiativeTieOrder: order,
                statuses: [],
              }),
            ),
          ],
        }));
        checkpointDraft(id);
        get().selectActor(id, actorId);
        void get().flush(id);
      },
      addEnemy(id, template) {
        get().addEnemies(id, template, 1);
      },
      addEnemies(id, template, count) {
        if (!Number.isInteger(count) || count < 1 || count > 100) return false;
        let added: string | null = null;
        action(id, (combat) => {
          const order =
            Math.max(-1, ...combat.actors.map((a) => a.initiativeTieOrder)) + 1;
          const copies = Array.from({ length: count }, (_, i) =>
            instantiateEnemy(template, order + i),
          );
          added = copies[0]!.id;
          return { ...combat, actors: [...combat.actors, ...copies] };
        });
        if (added) get().selectActor(id, added);
        return added !== null;
      },
      prepareEncounter(id) {
        if (
          get().enemyForm ||
          get().statusForm ||
          get().capabilityForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().failureForm
        )
          return;
        action(id, prepareCombat, 'prepare');
      },
      resetEncounter(id) {
        if (
          get().closing ||
          !get().drafts[id] ||
          get().enemyForm ||
          get().statusForm ||
          get().capabilityForm ||
          get().statblockForm ||
          get().loadoutForm ||
          get().failureForm
        )
          return;
        if (
          useParticipationStore
            .getState()
            .entries.some(
              (p) =>
                p.encounterId === id &&
                (p.state === 'active' || p.effects.length > 0),
            )
        ) {
          if (get().drafts[id])
            updateDraft(id, {
              status: 'error',
              error: PARTICIPATION_RESET_REJECTION,
            });
          return;
        }
        action(id, resetEncounter, 'reset');
      },
      clearLog(id) {
        action(id, (combat) => combat, 'clear_log');
      },
      editActor(id, actorId, patch) {
        edit(id, (draft) => ({
          ...draft,
          currentTurnActorId:
            actorId === draft.currentTurnActorId &&
            patch.initiativeValue?.trim() === ''
              ? null
              : draft.currentTurnActorId,
          actors: draft.actors.map((pc) =>
            pc.id === actorId ? { ...pc, ...patch } : pc,
          ),
        }));
      },
      removeActor(id, actorId) {
        if (get().closing) return;
        checkpointDraft(id);
        edit(id, (draft) => ({
          ...draft,
          currentTurnActorId:
            draft.currentTurnActorId === actorId
              ? null
              : draft.currentTurnActorId,
          actors: draft.actors.filter((pc) => pc.id !== actorId),
        }));
        checkpointDraft(id);
        if (get().selected[id] === actorId)
          set((state) => ({
            selected: {
              ...state.selected,
              [id]: state.drafts[id]?.value.actors[0]?.id ?? null,
            },
          }));
        void get().flush(id);
      },
      adjustHp(id, actorId, delta) {
        if (!Number.isSafeInteger(delta)) return;
        action(id, (combat) => ({
          ...combat,
          actors: combat.actors.map((pc) =>
            pc.id === actorId
              ? {
                  ...pc,
                  hpCurrent: Math.max(
                    0,
                    Math.min(pc.hpMaxCurrent, pc.hpCurrent + delta),
                  ),
                }
              : pc,
          ),
        }));
      },
      nextTurn(id) {
        if (get().statblockForm) return;
        action(
          id,
          (combat) => {
            const next = nextCombatTurn(combat);
            if (next.currentTurnActorId)
              get().selectActor(id, next.currentTurnActorId);
            return next;
          },
          'advance',
        );
      },
      setCurrent(id, actorId) {
        action(id, (combat) =>
          combat.actors.some(
            (pc) => pc.id === actorId && pc.initiativeValue !== null,
          )
            ? { ...combat, currentTurnActorId: actorId }
            : combat,
        );
      },
      moveTie(id, actorId, direction) {
        action(id, (combat) => reorderTie(combat, actorId, direction));
      },
      flush(id) {
        clearTimer(id);
        const existing = writes.get(id);
        if (existing) return existing;
        const task = Promise.resolve()
          .then(async () => {
            for (;;) {
              const draft = get().drafts[id];
              if (!draft) return get().status === 'ready';
              const saved = get().slots.find((s) => s.encounterId === id)!;
              let pending = checkpoints.get(id)?.[0];
              let snapshot: Combat;
              try {
                snapshot = pending
                  ? { ...pending.value, revision: saved.revision }
                  : parseCombatDraft(draft.value, saved);
              } catch {
                updateDraft(id, { status: 'invalid', error: invalidMessage });
                return false;
              }
              if (!pending && content(snapshot) === content(saved)) {
                updateDraft(id, { status: 'saved', error: null });
                return true;
              }
              if (!pending) {
                checkpoint(id, snapshot);
                pending = checkpoints.get(id)![0]!;
              }
              updateDraft(id, { status: 'saving', error: null });
              try {
                const revision = await save(snapshot, pending.reason);
                if (revision !== saved.revision + 1)
                  throw new Error(
                    'Nieprawidłowa wersja odpowiedzi zapisu. Zachowano szkic.',
                  );
                checkpoints.get(id)!.shift();
                set((state) => ({
                  slots: state.slots.map((slot) =>
                    slot.encounterId === id ? { ...snapshot, revision } : slot,
                  ),
                }));
              } catch (error) {
                if (
                  pending.reason === 'reset' &&
                  isParticipationResetRejection(error)
                ) {
                  // The transaction was rejected, so dropping this command is safe.
                  // Rebase descendants too, otherwise reset values would leak into
                  // the next ordinary autosave despite the rejected command.
                  const queue = checkpoints.get(id)!;
                  queue.shift();
                  for (const later of queue) {
                    later.value = restoreRejectedReset(
                      later.value,
                      snapshot,
                      saved,
                    ) as Combat;
                  }
                  const current = get().drafts[id]!.value;
                  updateDraft(id, {
                    value: restoreRejectedReset(
                      current,
                      toCombatDraft(snapshot),
                      toCombatDraft(saved),
                    ) as CombatDraft,
                    status: 'error',
                    error: PARTICIPATION_RESET_REJECTION,
                  });
                  return false;
                }
                updateDraft(id, {
                  status: 'error',
                  error:
                    typeof error === 'string'
                      ? error
                      : error instanceof Error
                        ? error.message
                        : 'Nie udało się zapisać postaci.',
                });
                return false;
              }
            }
          })
          .finally(() => {
            writes.delete(id);
          });
        writes.set(id, task);
        return task;
      },
      async prepareClose() {
        if (get().closing) return false;
        const failureForm = get().failureForm;
        if (failureForm) {
          set({
            failureForm: {
              ...failureForm,
              error: 'Zastosuj awarię albo anuluj formularz przed zamknięciem.',
            },
          });
          get().selectActor(failureForm.slotId, failureForm.actorId);
          return false;
        }
        const statblockForm = get().statblockForm;
        if (statblockForm) {
          set({
            statblockForm: {
              ...statblockForm,
              error:
                'Zatwierdź statblock albo anuluj formularz przed zamknięciem.',
            },
          });
          get().selectActor(statblockForm.slotId, statblockForm.actorId);
          return false;
        }
        const loadoutForm = get().loadoutForm;
        if (loadoutForm) {
          set({
            loadoutForm: {
              ...loadoutForm,
              error:
                'Zatwierdź zestaw broni albo anuluj formularz przed zamknięciem.',
            },
          });
          get().selectActor(loadoutForm.slotId, loadoutForm.actorId);
          return false;
        }
        const capabilityForm = get().capabilityForm;
        if (capabilityForm) {
          set({
            capabilityForm: {
              ...capabilityForm,
              error:
                'Zapisz zasoby i akcje albo anuluj formularz przed zamknięciem.',
            },
          });
          get().selectActor(capabilityForm.slotId, capabilityForm.actorId);
          return false;
        }
        const statusForm = get().statusForm;
        if (statusForm) {
          set({
            statusForm: {
              ...statusForm,
              error:
                'Dodaj lub zapisz status albo anuluj formularz przed zamknięciem.',
            },
          });
          get().selectActor(statusForm.slotId, statusForm.actorId);
          return false;
        }
        const form = get().enemyForm;
        if (form) {
          set({
            enemyForm: {
              ...form,
              error:
                'Dodaj przeciwnika albo anuluj formularz przed zamknięciem.',
            },
          });
          return false;
        }
        // A failed initial read has no editable combat draft to lose.
        if (get().status !== 'ready') return true;
        set({ closing: true });
        const saved = await Promise.all(SLOT_IDS.map((id) => get().flush(id)));
        if (saved.every(Boolean)) return true;
        const failed = SLOT_IDS.find((id) =>
          ['error', 'invalid'].includes(get().drafts[id]?.status ?? ''),
        );
        if (failed) {
          const invalid = get().drafts[failed]!.value.actors.find((pc) => {
            try {
              parseActorDraft(pc);
              return false;
            } catch {
              return true;
            }
          });
          if (invalid)
            set((state) => ({
              selected: { ...state.selected, [failed]: invalid.id },
            }));
        }
        set({ closing: false });
        return false;
      },
    };
  });
}
export const useCombatStore = createCombatStore();
