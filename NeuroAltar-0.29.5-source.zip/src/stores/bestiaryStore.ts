import { validationMessage } from '../domain/validation';
import { create } from 'zustand';
import { loadBestiary, saveBestiary } from '../db/bestiaryRepository';
import {
  templateDraft,
  type CatalogEntry,
  type CatalogMutation,
} from '../domain/bestiary';
import {
  newEnemyTemplateDraft,
  parseEnemyTemplateDraft,
  type EnemyTemplateDraft,
} from '../domain/enemy';
interface Form {
  id: string;
  expectedRevision: number | null;
  fields: EnemyTemplateDraft;
}
interface BestiaryStore {
  view: 'combat' | 'bestiary' | 'equipment' | 'vehicles' | 'reference';
  entries: CatalogEntry[];
  form: Form | null;
  loading: boolean;
  busy: boolean;
  error: string | null;
  pending: CatalogMutation | null;
  setView(
    view: 'combat' | 'bestiary' | 'equipment' | 'vehicles' | 'reference',
  ): void;
  load(): Promise<void>;
  open(entry?: CatalogEntry, duplicate?: boolean): void;
  edit(patch: Partial<EnemyTemplateDraft>): void;
  cancel(): void;
  submit(): Promise<void>;
  remove(entry: CatalogEntry): Promise<void>;
  retry(): Promise<void>;
  prepareClose(): Promise<boolean>;
}
export function createBestiaryStore(load = loadBestiary, save = saveBestiary) {
  let operation: Promise<void> | null = null;
  return create<BestiaryStore>((set, get) => {
    const write = (change: CatalogMutation) => {
      if (get().busy) return operation ?? Promise.resolve();
      set({ busy: true, error: null, pending: structuredClone(change) });
      operation = (async () => {
        try {
          const revision = await save(change);
          set((s) => ({
            entries: [
              ...s.entries.filter((e) => e.template.id !== change.template.id),
              ...(change.deleted
                ? []
                : [{ template: structuredClone(change.template), revision }]),
            ],
            form: null,
            pending: null,
          }));
        } catch (e) {
          set({ error: `Nie zapisano zmiany: ${String(e)}` });
        } finally {
          set({ busy: false });
          operation = null;
        }
      })();
      return operation;
    };
    return {
      view: 'combat',
      entries: [],
      form: null,
      loading: false,
      busy: false,
      error: null,
      pending: null,
      setView(view) {
        set({ view });
      },
      async load() {
        if (get().loading || get().busy) return;
        set({ loading: true, error: null });
        try {
          set({ entries: await load() });
        } catch (e) {
          set({ error: `Nie odczytano Bestiariusza: ${String(e)}` });
        } finally {
          set({ loading: false });
        }
      },
      open(entry, duplicate = false) {
        if (get().busy || get().form || get().pending) return;
        set({
          form: {
            id: duplicate || !entry ? crypto.randomUUID() : entry.template.id,
            expectedRevision: duplicate || !entry ? null : entry.revision,
            fields: entry
              ? {
                  ...templateDraft(entry.template),
                  name: entry.template.name + (duplicate ? ' — kopia' : ''),
                }
              : newEnemyTemplateDraft(),
          },
          error: null,
          view: 'bestiary',
        });
      },
      edit(patch) {
        const form = get().form;
        if (form && !get().busy && !get().pending)
          set({
            form: { ...form, fields: { ...form.fields, ...patch } },
            error: null,
          });
      },
      cancel() {
        if (!get().busy) set({ form: null, pending: null, error: null });
      },
      async submit() {
        const form = get().form;
        if (!form || get().busy || get().pending) return;
        try {
          const template = parseEnemyTemplateDraft(form.fields, form.id);
          await write({
            template,
            expectedRevision: form.expectedRevision,
            deleted: false,
          });
        } catch (error) {
          set({ error: validationMessage(error) });
        }
      },
      async remove(entry) {
        if (get().form || get().pending) return;
        await write({
          template: entry.template,
          expectedRevision: entry.revision,
          deleted: true,
        });
      },
      async retry() {
        const p = get().pending;
        if (p) await write(p);
      },
      async prepareClose() {
        if (operation) await operation;
        if (get().form || get().pending) {
          set({
            view: 'bestiary',
            error:
              get().error ??
              'Dokończ lub anuluj formularz Bestiariusza przed zamknięciem.',
          });
          return false;
        }
        return true;
      },
    };
  });
}
export const useBestiaryStore = createBestiaryStore();
