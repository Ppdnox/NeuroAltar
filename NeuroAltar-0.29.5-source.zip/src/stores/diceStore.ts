import { create } from 'zustand';
import {
  HISTORY_LIMIT,
  doubleDamageDice,
  parseDiceFormula,
  diceRollSchema,
  rollDice,
  type DiceRoll,
} from '../domain/dice';
import {
  localDiceHistory,
  type DiceHistoryRepository,
} from '../services/diceHistory';
interface DiceState {
  open: boolean;
  loaded: boolean;
  busy: boolean;
  history: DiceRoll[];
  pending: DiceRoll | null;
  storageError: string | null;
  inputError: string | null;
  mode: 'simple' | 'formula';
  count: string;
  sides: number;
  modifier: string;
  formula: string;
  setOpen(open: boolean): void;
  edit(
    fields: Partial<
      Pick<DiceState, 'mode' | 'count' | 'sides' | 'modifier' | 'formula'>
    >,
  ): void;
  load(): Promise<void>;
  roll(
    formula?: string,
    context?: DiceRoll['context'],
    characterContext?: DiceRoll['characterContext'],
    options?: {
      mode?: 'normal' | 'advantage' | 'disadvantage';
      manual?: number;
      keepWorseThan?: number;
      characterCheck?: DiceRoll['characterCheck'];
      supplement?: DiceRoll['supplement'];
    },
  ): Promise<boolean>;
  retry(): Promise<boolean>;
  prepareClose(): Promise<boolean>;
}
export function createDiceStore(
  repo: DiceHistoryRepository = localDiceHistory,
  execute = rollDice,
) {
  let loading: Promise<void> | undefined,
    writing: Promise<boolean> | undefined,
    rolling: Promise<boolean> | undefined;
  return create<DiceState>((set, get) => ({
    open: false,
    loaded: false,
    busy: false,
    history: [],
    pending: null,
    storageError: null,
    inputError: null,
    mode: 'simple',
    count: '1',
    sides: 20,
    modifier: '0',
    formula: '2k6+3',
    setOpen(open) {
      set({ open });
    },
    edit(fields) {
      set({ ...fields, inputError: null });
    },
    load() {
      if (get().loaded) return Promise.resolve();
      if (loading) return loading;
      loading = Promise.resolve()
        .then(async () => {
          try {
            set({
              history: await repo.read(),
              loaded: true,
              storageError: null,
            });
          } catch {
            set({
              storageError:
                'Nie można odczytać historii rzutów. Ponów odczyt; zachowana historia nie została nadpisana.',
            });
          }
        })
        .finally(() => {
          loading = undefined;
        });
      return loading;
    },
    roll(formula, context = null, characterContext, options) {
      if (get().busy || get().pending) return Promise.resolve(false);
      const s = get();
      set({ busy: true });
      rolling = Promise.resolve()
        .then(async () => {
          await get().load();
          if (!get().loaded) {
            set({ busy: false });
            return false;
          }
          try {
            let input = formula;
            if (input === undefined && s.mode === 'simple') {
              if (
                !/^\d+$/.test(s.count.trim()) ||
                Number(s.count) < 1 ||
                Number(s.count) > 100
              )
                throw Error('Liczba kości musi wynosić od 1 do 100.');
              if (
                !/^[+-]?\d+$/.test(s.modifier.trim()) ||
                Math.abs(Number(s.modifier)) > 10000
              )
                throw Error(
                  'Modyfikator musi być liczbą całkowitą od −10000 do 10000.',
                );
              input = `${Number(s.count)}k${s.sides}${Number(s.modifier) < 0 ? '' : '+'}${Number(s.modifier)}`;
            }
            const originalFormula = parseDiceFormula(
              input ?? s.formula,
            ).formula;
            const attackRollId =
              context?.purpose === 'damage' && repo.criticalAttack
                ? await repo.criticalAttack(context)
                : null;
            const result = execute(
              attackRollId
                ? doubleDamageDice(
                    originalFormula,
                    context?.criticalMultiplier ?? 2,
                  )
                : originalFormula,
            );
            let checkDice;
            if (options?.manual !== undefined) {
              if (
                result.count !== 1 ||
                result.sides !== 20 ||
                !Number.isInteger(options.manual) ||
                options.manual < 1 ||
                options.manual > 20
              )
                throw Error('Ręczny wynik kości musi wynosić 1–20.');
              result.values = [options.manual];
              result.total = options.manual + result.modifier;
            } else if (options?.mode && options.mode !== 'normal') {
              if (result.count !== 1 || result.sides !== 20)
                throw Error('Ułatwienie dotyczy testu k20.');
              const second = execute(originalFormula).values[0]!;
              checkDice = {
                mode: options.mode,
                values: [result.values[0]!, second],
              };
              const kept =
                options.mode === 'advantage'
                  ? Math.max(...checkDice.values)
                  : Math.min(...checkDice.values);
              result.values = [kept];
              result.total = kept + result.modifier;
            }
            if (options?.keepWorseThan !== undefined) {
              if (
                result.count !== 1 ||
                result.sides !== 20 ||
                !Number.isInteger(options.keepWorseThan) ||
                options.keepWorseThan < 1 ||
                options.keepWorseThan > 20
              )
                throw Error('Przerzut wymaga wyniku k20.');
              checkDice = {
                mode: 'disadvantage' as const,
                values: [options.keepWorseThan, result.values[0]!],
              };
              result.values = [Math.min(...checkDice.values)];
              result.total = result.values[0]! + result.modifier;
            }
            set({
              pending: diceRollSchema.parse({
                ...result,
                ...(options?.characterCheck
                  ? { characterCheck: options.characterCheck }
                  : {}),
                ...(options?.supplement
                  ? { supplement: options.supplement }
                  : {}),
                ...(checkDice ? { checkDice } : {}),
                ...(attackRollId
                  ? { critical: { attackRollId, originalFormula } }
                  : {}),
                context,
                ...(characterContext ? { characterContext } : {}),
                id: crypto.randomUUID(),
                createdAt: new Date().toISOString(),
              }),
              inputError: null,
            });
          } catch (e) {
            set({
              busy: false,
              inputError:
                e instanceof Error ? e.message : 'Nie udało się wykonać rzutu.',
            });
            return false;
          }
          return get().retry();
        })
        .finally(() => {
          rolling = undefined;
        });
      return rolling;
    },
    retry() {
      if (writing) return writing;
      const { pending } = get();
      if (!pending) return Promise.resolve(true);
      set({ busy: true });
      writing = Promise.resolve()
        .then(async () => {
          try {
            await repo.write(pending);
            set((s) => ({
              history: [pending, ...s.history].slice(0, HISTORY_LIMIT),
              pending: null,
              storageError: null,
            }));
            return true;
          } catch {
            set({
              storageError:
                'Wynik jest w pamięci, ale zapis historii nie powiódł się. Ponów zapis tego samego wyniku.',
            });
            return false;
          }
        })
        .finally(() => {
          writing = undefined;
          set({ busy: false });
        });
      return writing;
    },
    async prepareClose() {
      // Wait for an in-flight roll, including its initial history read.
      if (rolling) return rolling;
      if (writing) return writing;
      return get().retry();
    },
  }));
}
export const useDiceStore = createDiceStore();
