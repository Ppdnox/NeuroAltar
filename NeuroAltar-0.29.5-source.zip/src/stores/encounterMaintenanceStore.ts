import { create } from 'zustand';
import { useCombatStore } from './combatStore';
import { useEncounterStore } from './encounterStore';
import { clearEncounter, type ClearRequest } from '../services/clearEncounter';
import {
  loadCombatSlots,
  PARTICIPATION_RESET_REJECTION,
  isParticipationResetRejection,
} from '../services/combat';
import { useParticipationStore } from './participationStore';
import { loadEncounterSlots } from '../services/bootstrap';
import { toCombatDraft, type Combat } from '../domain/combat';
import type { Encounter } from '../domain/encounter';
import type { SlotId } from '../domain/encounterDetails';

interface MaintenanceState {
  slotId: SlotId | null;
  busy: boolean;
  error: string | null;
  clear(id: SlotId): Promise<void>;
  retry(): Promise<void>;
  reload(): Promise<void>;
}
export function createEncounterMaintenanceStore(
  encounters = useEncounterStore,
  combat = useCombatStore,
  clear = clearEncounter,
  loadDetails = loadEncounterSlots,
  loadCombat = loadCombatSlots,
) {
  let request: ClearRequest | null = null;
  return create<MaintenanceState>((set, get) => {
    const unlock = () => {
      encounters.setState({ closing: false });
      combat.setState({ closing: false });
      request = null;
      set({ slotId: null, busy: false, error: null });
    };
    const apply = (details: Encounter, value: Combat) => {
      const id = details.id;
      encounters.setState((s) => ({
        slots: s.slots.map((slot) => (slot.id === id ? details : slot)),
        drafts: {
          ...s.drafts,
          [id]: {
            details: {
              name: details.name,
              notes: details.notes,
              partyLevelsText: details.partyLevels.join('\n'),
            },
            status: 'saved',
            error: null,
          },
        },
      }));
      combat.setState((s) => ({
        slots: s.slots.map((slot) => (slot.encounterId === id ? value : slot)),
        drafts: {
          ...s.drafts,
          [id]: { value: toCombatDraft(value), status: 'saved', error: null },
        },
        selected: { ...s.selected, [id]: value.actors[0]?.id ?? null },
      }));
    };
    const fail = (error: unknown) =>
      set({
        busy: false,
        error: error instanceof Error ? error.message : String(error),
      });
    const rejectedParticipation = (id: SlotId) => {
      // The maintenance request is no longer pending. Display its reason through
      // the existing slot error instead of leaving the uncertain-write dialog open.
      combat.setState((state) => {
        const draft = state.drafts[id];
        if (!draft || draft.status === 'invalid') return {};
        return {
          drafts: {
            ...state.drafts,
            [id]: {
              ...draft,
              status: 'error',
              error: PARTICIPATION_RESET_REJECTION,
            },
          },
        };
      });
      fail(PARTICIPATION_RESET_REJECTION);
    };
    const execute = async () => {
      if (!request) return;
      set({ busy: true, error: null });
      try {
        const result = await clear(request);
        if (result.revision !== request.revision + 1)
          throw new Error(
            'Nieprawidłowa odpowiedź czyszczenia. Ponów próbę lub odczytaj slot.',
          );
        const details = encounters
          .getState()
          .slots.find((s) => s.id === request!.encounterId)!;
        const value: Combat = {
          encounterId: request.encounterId,
          revision: result.revision,
          actors: [],
          roundNumber: 1,
          currentTurnActorId: null,
        };
        apply(
          {
            ...details,
            notes: '',
            roundNumber: 1,
            currentTurnActorId: null,
            updatedAt: result.updatedAt,
          },
          value,
        );
        unlock();
      } catch (error) {
        if (isParticipationResetRejection(error)) {
          // This guard rolls back before clearing anything; keep all saved data
          // and release the rejected request so participation can be ended.
          const id = request.encounterId;
          unlock();
          rejectedParticipation(id);
          return;
        }
        fail(error);
      }
    };
    return {
      slotId: null,
      busy: false,
      error: null,
      async clear(id) {
        const state = combat.getState();
        if (
          get().slotId ||
          state.closing ||
          encounters.getState().closing ||
          state.status !== 'ready' ||
          encounters.getState().status !== 'ready' ||
          state.enemyForm ||
          state.statusForm ||
          state.capabilityForm ||
          state.statblockForm ||
          state.loadoutForm ||
          state.failureForm
        )
          return;
        if (
          useParticipationStore
            .getState()
            .entries.some(
              (p) =>
                p.encounterId === id &&
                (p.state === 'active' || p.effects.length > 0),
            )
        ) {
          rejectedParticipation(id);
          return;
        }
        set({ slotId: id, busy: true, error: null });
        // Freeze edits synchronously, then drain both queues before taking the request snapshot.
        encounters.setState({ closing: true });
        combat.setState({ closing: true });
        const results = await Promise.all([
          encounters.getState().flush(id),
          combat.getState().flush(id),
        ]);
        if (!results.every(Boolean)) {
          unlock();
          return;
        }
        const details = encounters.getState().slots.find((s) => s.id === id)!;
        const saved = combat
          .getState()
          .slots.find((s) => s.encounterId === id)!;
        request = {
          encounterId: id,
          revision: saved.revision,
          name: details.name,
          notes: details.notes,
          partyLevels: [...details.partyLevels],
        };
        await execute();
      },
      async retry() {
        if (!get().busy) await execute();
      },
      async reload() {
        const id = get().slotId;
        if (!id || get().busy) return;
        set({ busy: true, error: null });
        try {
          // Target drafts were successfully flushed before the request and remain locked.
          const [details, values] = await Promise.all([
            loadDetails(),
            loadCombat(),
          ]);
          apply(
            details.find((s) => s.id === id)!,
            values.find((s) => s.encounterId === id)!,
          );
          unlock();
        } catch (error) {
          fail(error);
        }
      },
    };
  });
}
export const useEncounterMaintenanceStore = createEncounterMaintenanceStore();
