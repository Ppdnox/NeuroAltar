import { useParticipationStore } from './participationStore';
import {
  previewCondition,
  conditionSheet,
} from '../domain/character/condition';
import type { ConditionAction } from '../domain/character/conditionModel';
import { create } from 'zustand';
import {
  emptyInventory,
  type InventoryAction,
} from '../domain/character/inventoryModel';
import { applyInventoryAction } from '../domain/character/inventory';
import { loadCharacters, saveCharacter } from '../db/characterRepository';
import {
  characterSchema,
  characterJournal,
  type CharacterJournal,
  newCharacter,
  type Character,
  type CharacterMutation,
  type CharacterSheet,
} from '../domain/character/model';
import { deriveCharacter } from '../domain/character/derive';
import { useNavigationStore } from './navigationStore';

const ACTIVE_PARTICIPATION_REJECTION =
  'Najpierw zakończ aktywny udział tej postaci w walce.';
const ACTIVE_PARTICIPATION_HINT =
  'Szkic jest zapisany. Zakończ udział postaci w walce, a następnie zatwierdź kartę. Nie musisz usuwać jej z potyczki.';

interface Repository {
  list: () => Promise<Character[]>;
  save: (m: CharacterMutation) => Promise<Character>;
}
interface State {
  records: Character[];
  selectedId: string | null;
  status: 'idle' | 'loading' | 'ready' | 'error';
  error: string | null;
  dirty: string[];
  saving: boolean;
  locked: boolean;
  invalid: Record<string, string>;
  conflict: Character | null;
  conflictIsInventory: boolean;
  initialize: () => Promise<void>;
  select: (id: string) => void;
  create: () => Promise<void>;
  edit: () => void;
  update: (sheet: CharacterSheet) => void;
  updateJournal: (key: keyof CharacterJournal, value: string) => void;
  invalidInput: (path: string, value: string | null) => void;
  flush: () => Promise<boolean>;
  publish: (correctionReason?: string) => Promise<boolean>;
  discard: () => Promise<boolean>;
  archive: (value: boolean) => Promise<boolean>;
  mutateInventory: (command: InventoryAction) => Promise<boolean>;
  mutateCondition: (
    command: ConditionAction,
    revision: number,
  ) => Promise<boolean>;
  prepareClose: () => Promise<boolean>;
  compareConflict: () => Promise<void>;
  acceptRebase: () => void;
}
export function createCharacterStore(
  repo: Repository = { list: loadCharacters, save: saveCharacter },
) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  let flight: Promise<boolean> | null = null;
  let pending: CharacterMutation | null = null;
  const persisted = new Set<string>();
  return create<State>((set, get) => {
    const selected = () => get().records.find((r) => r.id === get().selectedId);
    const replace = (c: Character) =>
      set((s) => ({
        records: s.records.some((r) => r.id === c.id)
          ? s.records.map((r) => (r.id === c.id ? c : r))
          : [c, ...s.records],
      }));
    const mark = (c: Character) => {
      replace(c);
      set((s) => ({ dirty: [...new Set([...s.dirty, c.id])] }));
      clearTimeout(timer);
      timer = setTimeout(() => {
        void get().flush();
      }, 450);
    };
    async function savePending(): Promise<boolean> {
      if (!pending) return true;
      const mutation = pending;
      set({ saving: true });
      try {
        characterSchema.parse(mutation.character);
        const result = await repo.save(mutation);
        persisted.add(result.id);
        const local = get().records.find((c) => c.id === result.id);
        const newer =
          mutation.kind === 'draft' &&
          local &&
          JSON.stringify(local) !== JSON.stringify(mutation.character);
        replace(
          newer
            ? {
                ...local,
                revision: result.revision,
                createdAt: result.createdAt,
                updatedAt: result.updatedAt,
              }
            : result,
        );
        set((s) => ({
          dirty: newer ? s.dirty : s.dirty.filter((id) => id !== result.id),
          error: null,
          saving: false,
          locked: mutation.kind === 'draft' ? s.locked : false,
        }));
        pending = null;
        return true;
      } catch (error) {
        // This domain rejection is returned before the transaction commits.
        // Do not keep retrying it: that would also block ending participation.
        const message = error instanceof Error ? error.message : String(error);
        if (
          ['publish', 'archive'].includes(mutation.kind) &&
          message === ACTIVE_PARTICIPATION_REJECTION
        ) {
          pending = null;
          set({
            error: ACTIVE_PARTICIPATION_HINT,
            saving: false,
            locked: false,
          });
          return false;
        }
        set({
          error: String(error),
          saving: false,
          locked: mutation.kind !== 'draft',
        });
        return false;
      }
    }
    async function action(
      kind: 'publish' | 'discard' | 'archive' | 'inventory' | 'condition',
      transform: (c: Character) => Character,
      correctionReason?: string,
      inventoryAction?: InventoryAction,
      conditionAction?: ConditionAction,
      expectedRevision?: number,
    ) {
      if (get().locked || Object.keys(get().invalid).length) return false;
      set({ locked: true });
      if (!(await get().flush())) {
        set({ locked: false });
        return false;
      }
      const c = selected();
      if (!c) {
        set({ locked: false });
        return false;
      }
      if (expectedRevision !== undefined && expectedRevision !== c.revision) {
        set({
          locked: false,
          error: 'Podgląd jest nieaktualny. Przygotuj go ponownie.',
        });
        return false;
      }
      const operationId = crypto.randomUUID();
      let conditionContext;
      let transformed: Character;
      try {
        transformed = transform(c);
        if (conditionAction) {
          const preview = previewCondition(c, conditionAction, operationId);
          transformed = {
            ...c,
            condition: preview.state,
            ...(preview.inventory ? { inventory: preview.inventory } : {}),
          };
          conditionContext = preview.context;
        }
      } catch (e) {
        set({ locked: false, error: String(e) });
        return false;
      }
      const participation = useParticipationStore
        .getState()
        .entries.find((p) => p.characterId === c.id && p.state === 'active');
      if (participation && (kind === 'publish' || kind === 'archive')) {
        set({ locked: false, error: ACTIVE_PARTICIPATION_HINT });
        return false;
      }
      pending = {
        ...(participation
          ? { participationRevision: participation.revision }
          : {}),
        operationId,
        expectedRevision: c.revision,
        character: transformed,
        kind,
        ...(correctionReason ? { correctionReason } : {}),
        ...(inventoryAction ? { inventoryAction } : {}),
        ...(conditionAction ? { conditionAction, conditionContext } : {}),
      };
      return savePending();
    }
    return {
      records: [],
      selectedId: null,
      status: 'idle',
      error: null,
      dirty: [],
      saving: false,
      locked: false,
      invalid: {},
      conflict: null,
      conflictIsInventory: false,
      initialize: async () => {
        if (get().status === 'loading' || get().status === 'ready') return;
        set({ status: 'loading' });
        try {
          const records = await repo.list();
          records.forEach((c) => persisted.add(c.id));
          set({
            records,
            selectedId: records.find((c) => !c.archived)?.id ?? null,
            status: 'ready',
            error: null,
          });
        } catch (e) {
          set({ status: 'error', error: String(e) });
        }
      },
      select: (id) => {
        if (get().locked) return;
        set({ selectedId: id });
      },
      create: async () => {
        if (get().locked) return;
        const c = newCharacter();
        set({ selectedId: c.id });
        mark(c);
        await get().flush();
      },
      edit: () => {
        const c = selected();
        if (!c || c.draft || !c.sheet || get().locked) return;
        mark({ ...c, draft: structuredClone(c.sheet) });
      },
      update: (sheet) => {
        const c = selected();
        if (!c || get().locked) return;
        set((s) => ({
          invalid: Object.fromEntries(
            Object.entries(s.invalid).filter(([key]) => {
              if (!key.startsWith(c.id + ':')) return true;
              const path = key.slice(c.id.length + 1);
              if (path.startsWith('xp-'))
                return sheet.xp.some((e) => 'xp-' + e.id === path);
              if (path.startsWith('override-'))
                return sheet.overrides.some((e) => 'override-' + e.id === path);
              return true;
            }),
          ),
        }));
        mark({ ...c, draft: sheet });
      },
      updateJournal: (key, value) => {
        const c = selected();
        if (!c || c.archived || get().locked || value.length > 20000) return;
        mark({ ...c, journal: { ...characterJournal(c), [key]: value } });
      },
      invalidInput: (path, value) =>
        set((s) => {
          const invalid = { ...s.invalid };
          if (value === null) delete invalid[path];
          else invalid[path] = value;
          return { invalid };
        }),
      flush: () => {
        clearTimeout(timer);
        if (flight) return flight;
        flight = (async () => {
          if (!(await savePending())) return false;
          while (get().dirty.length) {
            const id = get().dirty[0]!,
              c = get().records.find((c) => c.id === id)!;
            pending = {
              operationId: crypto.randomUUID(),
              expectedRevision: persisted.has(id) ? c.revision : null,
              character: structuredClone(c),
              kind: 'draft',
            };
            if (!(await savePending())) return false;
          }
          return true;
        })().finally(() => {
          flight = null;
        });
        return flight;
      },
      publish: async (correctionReason) => {
        const c = selected();
        if (!c?.draft) return false;
        const result = deriveCharacter(conditionSheet(c.draft, c.condition));
        if (result.issues.length || Object.keys(get().invalid).length) {
          set({
            error: 'Uzupełnij zaznaczone pola przed zatwierdzeniem karty.',
          });
          return false;
        }
        if (!c.sheet && c.draft.hpCurrent === null) {
          get().update({ ...c.draft, hpCurrent: result.hpMax.value });
        }
        return action(
          'publish',
          (c) => ({
            ...c,
            sheet: c.draft,
            draft: null,
          }),
          correctionReason?.trim(),
        );
      },
      discard: async () => {
        if (!selected()?.sheet) return false;
        const id = selected()!.id;
        set((s) => ({
          invalid: Object.fromEntries(
            Object.entries(s.invalid).filter(([k]) => !k.startsWith(id + ':')),
          ),
        }));
        return action('discard', (c) => ({ ...c, draft: null }));
      },
      archive: (value) => action('archive', (c) => ({ ...c, archived: value })),
      mutateInventory: (command) =>
        action(
          'inventory',
          (c) => {
            if (!c.sheet || c.draft || c.archived)
              throw new Error(
                'Najpierw zatwierdź lub odrzuć szkic rozwoju postaci.',
              );
            return {
              ...c,
              inventory: applyInventoryAction(
                c.inventory ?? emptyInventory(),
                command,
                c.sheet.rulesContext.gameColor,
                deriveCharacter(c.sheet).activeFeats.includes('fingers'),
              ),
            };
          },
          undefined,
          command,
        ),
      mutateCondition: (command, revision) =>
        action('condition', (c) => c, undefined, undefined, command, revision),
      prepareClose: async () => {
        const ok = await get().flush();
        if (ok && !Object.keys(get().invalid).length) return true;
        const id =
          Object.keys(get().invalid)[0]?.split(':')[0] ?? pending?.character.id;
        if (id) set({ selectedId: id });
        useNavigationStore.getState().revealCloseIssue('character');
        return false;
      },
      compareConflict: async () => {
        try {
          const latest = await repo.list();
          const current = latest.find((c) => c.id === get().selectedId);
          if (current)
            set({
              conflict: current,
              conflictIsInventory:
                pending?.kind === 'inventory' || pending?.kind === 'condition',
            });
        } catch (e) {
          set({ error: String(e) });
        }
      },
      acceptRebase: () => {
        const local = selected(),
          remote = get().conflict;
        if (!local || !remote || local.id !== remote.id) return;
        const inventoryConflict =
          pending?.kind === 'inventory' || pending?.kind === 'condition';
        pending = null;
        persisted.add(remote.id);
        set({ locked: false, error: null, conflict: null });
        if (inventoryConflict) replace(remote);
        else
          mark({
            ...remote,
            draft: local.draft ?? remote.draft,
            ...(local.journal ? { journal: local.journal } : {}),
          });
      },
    };
  });
}
export const useCharacterStore = createCharacterStore();
