import { useDiceStore } from '../../stores/diceStore';
import { rollFailure } from '../../services/failureDice';
import { useEffect, useRef } from 'react';
import { useEncounterStore } from '../../stores/encounterStore';
import { useNavigationStore } from '../../stores/navigationStore';
import {
  parseActorDraft,
  type Actor,
  type ActorDraft,
} from '../../domain/combat';
import {
  failureTable,
  failureModifiers,
  effectiveMachineTT,
} from '../../domain/machineFailures';
import {
  parseFailureResult,
  parseFailureThreshold,
} from '../../domain/machineFailureSchema';
import type { SlotId } from '../../domain/encounterDetails';
import { useCombatStore } from '../../stores/combatStore';
export function FailureSummary({ actor }: { actor: Actor }) {
  const fs = actor.enemy?.machineFailures ?? [];
  if (!fs.length) return null;
  const m = failureModifiers(fs);
  return (
    <div className="failure-summary">
      <strong>
        Awarie: {fs.length} · TT po awariach {effectiveMachineTT(actor)}
      </strong>
      <p>
        Kara ataku {m.attack} · mnożnik ruchu {m.speed}
        {m.fewerAttacks > 0
          ? ` · ataków w turze mniej o ${m.fewerAttacks}`
          : ''}
      </p>
      {fs.map((f) => (
        <p key={f.id}>
          {f.result}. {failureTable[f.result - 1]![0]}
          {f.weaponName ? ` — ${f.weaponName}` : ''}
          {f.blockedAction
            ? ` — ${f.blockedAction === 'bonus' ? 'Bonusowe' : 'Legendarne'}`
            : ''}
          {f.remainingEnds !== null
            ? ` · pozostałe końce własnej tury: ${f.remainingEnds}`
            : ''}
        </p>
      ))}
    </div>
  );
}
export function FailurePanel({
  slotId,
  actor,
  parentDisabled = false,
}: {
  slotId: SlotId;
  actor: ActorDraft;
  parentDisabled?: boolean;
}) {
  const state = useCombatStore();
  const closing = useEncounterStore((s) => s.closing);
  if (actor.enemy?.template.category !== 'machine') return null;
  let parsed: Actor | null = null;
  try {
    parsed = parseActorDraft(actor);
  } catch {
    /*retain raw*/
  }
  const disabled =
    parentDisabled ||
    closing ||
    !parsed ||
    state.closing ||
    !!state.failureForm ||
    !!state.statblockForm ||
    !!state.loadoutForm ||
    !!state.capabilityForm ||
    !!state.statusForm ||
    !!state.enemyForm;
  return (
    <section className="failure-panel" aria-label="Awarie maszyny">
      <fieldset disabled={disabled}>
        <h3>Awarie maszyny</h3>
        <label className="stat-field">
          <span>Próg awarii — obrażenia pojedynczego ataku, puste = brak</span>
          <input
            aria-label="Próg awarii instancji"
            inputMode="numeric"
            value={actor.failureThresholdText ?? ''}
            onChange={(e) =>
              state.editActor(slotId, actor.id, {
                failureThresholdText: e.target.value,
              })
            }
            onBlur={() => void state.flush(slotId)}
          />
        </label>
        <p className="editor-hint">
          Awaria po przekroczeniu progu obrażeń jednego ataku. Sam spadek PW jej
          nie uruchamia. MG ocenia warunek i stosowalność wyniku; niepasujący
          wynik może zmienić na kolejną pozycję tabeli.
        </p>
        <button
          type="button"
          className="secondary-button"
          disabled={disabled}
          onClick={() => state.openFailureForm(slotId, actor.id)}
        >
          Wpisz wynik awarii k20
        </button>
        <button
          type="button"
          className="secondary-button"
          disabled={disabled}
          onClick={() => {
            state.openFailureForm(slotId, actor.id);
            void rollFailure(slotId);
          }}
        >
          Rzuć awarię k20
        </button>
      </fieldset>
      {state.failureForm?.slotId === slotId &&
        state.failureForm.actorId === actor.id && (
          <FailureForm slotId={slotId} disabled={closing || state.closing} />
        )}
      <fieldset disabled={disabled}>
        {parsed && <FailureSummary actor={parsed} />}
        {(actor.enemy.machineFailures ?? []).map((f) => (
          <div className="failure-entry" key={f.id}>
            <strong>
              {f.result}. {failureTable[f.result - 1]![0]}
            </strong>
            <p>{failureTable[f.result - 1]![1]}</p>
            {f.note && <p className="bestiary-text">{f.note}</p>}
            <button
              type="button"
              disabled={disabled}
              className="secondary-button"
              onClick={() => state.repairFailure(slotId, actor.id, f.id)}
            >
              Oznacz naprawę / zakończenie: {f.result}
            </button>
          </div>
        ))}
        <p className="editor-hint">
          Naprawa znosi tę awarię i jej status. Nie leczy PW po eksplozji ani
          zniszczeniu. Kolejne zastosowania są osobnymi awariami; kary liczbowe
          kumulują się. Reset odtwarza dokładny stan przygotowany.
        </p>
        <details>
          <summary>Tabela awarii 1–20</summary>
          <ol>
            {failureTable.map(([name, effect]) => (
              <li key={name}>
                <strong>{name}</strong> — {effect}
              </li>
            ))}
          </ol>
        </details>
      </fieldset>
    </section>
  );
}
export function FailureForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore(),
    form = state.failureForm;
  const rolling = useDiceStore((s) => s.busy || !!s.pending);
  const input = useRef<HTMLInputElement>(null);
  const closeIssue = useNavigationStore((s) => s.closeIssue);
  useEffect(() => {
    if (form?.slotId !== slotId || disabled) return;
    input.current?.focus({ preventScroll: true });
    input.current?.scrollIntoView({ block: 'center' });
  }, [form?.actorId, form?.slotId, slotId, disabled, closeIssue]);
  if (!form || form.slotId !== slotId) return null;
  const actor = state.drafts[slotId]?.value.actors.find(
    (a) => a.id === form.actorId,
  );
  let result: number | null = null,
    damage: number | null = null;
  try {
    result = parseFailureResult(form.fields.result);
  } catch {
    /*draft*/
  }
  try {
    damage = parseFailureThreshold(form.fields.damage);
  } catch {
    /*draft*/
  }
  const threshold = actor?.enemy?.failureThreshold;
  return (
    <form
      className="enemy-form"
      aria-label="Zastosowanie awarii"
      onSubmit={(e) => {
        e.preventDefault();
        state.submitFailureForm();
      }}
    >
      <fieldset disabled={disabled || rolling}>
        <legend>Awaria: {actor?.displayName}</legend>
        <p>
          Wpisz wynik lub rzuć k20. Podgląd nie zmienia postaci. Dopiero
          „Zastosuj awarię” zapisze efekt.
        </p>
        <button
          type="button"
          className="secondary-button"
          onClick={() => {
            void rollFailure(slotId);
          }}
        >
          Rzuć k20 do awarii
        </button>
        <div className="enemy-fields">
          <label>
            <span>Wynik k20 (1–20)</span>
            <input
              ref={input}
              aria-label="Wynik awarii k20"
              inputMode="numeric"
              value={form.fields.result}
              onChange={(e) =>
                state.editFailureForm({ result: e.target.value })
              }
            />
          </label>
          <label>
            <span>Obrażenia jednego ataku (opcjonalny podgląd progu)</span>
            <input
              aria-label="Obrażenia do sprawdzenia progu"
              inputMode="numeric"
              value={form.fields.damage}
              onChange={(e) =>
                state.editFailureForm({ damage: e.target.value })
              }
            />
          </label>
        </div>
        <p className="editor-hint">
          Próg: {threshold ?? 'N/D'}.{' '}
          {threshold != null && damage !== null
            ? damage > threshold
              ? 'Próg przekroczony.'
              : 'Próg nieprzekroczony.'
            : ''}{' '}
          To pole nie odejmuje PW.
        </p>
        {result && (
          <div className="failure-preview" aria-live="polite">
            <h3>
              {result}. {failureTable[result - 1]![0]}
            </h3>
            <p>{failureTable[result - 1]![1]}</p>
          </div>
        )}
        {result === 1 && (
          <label>
            <span>Broń do oznaczenia</span>
            <select
              aria-label="Zniszczona broń"
              value={form.fields.weaponId}
              onChange={(e) =>
                state.editFailureForm({ weaponId: e.target.value })
              }
            >
              <option value="">Wybierz broń</option>
              {actor?.enemy?.loadout?.items
                .filter((e) => e.item.type === 'weapon')
                .map((e) => (
                  <option key={e.item.id} value={e.item.id}>
                    {e.item.name}
                  </option>
                ))}
            </select>
          </label>
        )}
        {result === 4 && (
          <label>
            <span>Rodzaj blokady</span>
            <select
              aria-label="Blokowana akcja"
              value={form.fields.blockedAction}
              onChange={(e) =>
                state.editFailureForm({
                  blockedAction: e.target.value as '' | 'bonus' | 'legendary',
                })
              }
            >
              <option value="">Wybierz blokadę</option>
              <option value="bonus">Akcje Bonusowe</option>
              <option value="legendary">Akcje Legendarne</option>
            </select>
          </label>
        )}
        <label>
          <span>Notatka MG</span>
          <textarea
            value={form.fields.note}
            onChange={(e) => state.editFailureForm({ note: e.target.value })}
          />
        </label>
        {form.error && (
          <p role="alert" className="editor-error">
            {form.error}
          </p>
        )}
        <div className="actor-actions">
          <button className="secondary-button" type="submit">
            Zastosuj awarię
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={state.cancelFailureForm}
          >
            Anuluj formularz awarii
          </button>
        </div>
      </fieldset>
    </form>
  );
}
