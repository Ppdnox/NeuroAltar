import { difficultyFromDrafts } from '../../domain/difficulty';
import type { ActorDraft } from '../../domain/combat';
export function SlotDifficulty({
  levels,
  actors,
}: {
  levels: string;
  actors?: ActorDraft[];
}) {
  const { result, error } = difficultyFromDrafts(levels, actors);
  const label = error
    ? 'Popraw dane'
    : result?.percent == null
      ? 'Trudność N/D'
      : `${Math.round(result.percent)}%`;
  return (
    <span className="slot-difficulty" title={error ?? label}>
      <span className="difficulty-track" aria-hidden="true">
        {result?.markerPercent != null && (
          <span
            className="difficulty-marker"
            style={{ left: `${result.markerPercent}%` }}
          />
        )}
      </span>
      <span>{label}</span>
    </span>
  );
}
