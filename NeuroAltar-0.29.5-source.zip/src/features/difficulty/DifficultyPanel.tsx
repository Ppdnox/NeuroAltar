import { difficultyFromDrafts } from '../../domain/difficulty';
import { useEncounterStore } from '../../stores/encounterStore';
import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';
import { ChevronRight, Plus, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

function initialLevels(text: string): string[] {
  return text.trim() ? text.trim().split(/[\s,;]+/) : [''];
}

export function DifficultyPanel({
  slotId,
  open,
  onToggle,
}: {
  slotId: SlotId;
  open: boolean;
  onToggle(open: boolean): void;
}) {
  const details = useEncounterStore();
  const combat = useCombatStore();
  const draft = details.drafts[slotId]!;
  const [levels, setLevels] = useState(() =>
    initialLevels(draft.details.partyLevelsText),
  );
  const levelInputs = useRef<Array<HTMLInputElement | null>>([]);
  const pendingFocus = useRef<number | null>(null);
  useEffect(() => {
    if (pendingFocus.current !== null) {
      levelInputs.current[pendingFocus.current]?.focus();
      pendingFocus.current = null;
    }
  }, [levels]);
  const disabled = details.closing || combat.closing;
  const updateLevels = (next: string[]) => {
    setLevels(next);
    details.edit(slotId, { partyLevelsText: next.join(' ') });
  };
  const addLevel = () => {
    pendingFocus.current = levels.length;
    setLevels([...levels, '']);
  };
  const { result, error } = difficultyFromDrafts(
    draft.details.partyLevelsText,
    combat.drafts[slotId]?.value.actors,
  );
  return (
    <details
      className="difficulty-panel"
      aria-label="Trudność potyczki"
      open={open || !!error}
      onToggle={(e) => onToggle(e.currentTarget.open)}
    >
      <summary>
        <span className="difficulty-summary-title">
          <ChevronRight size={18} aria-hidden="true" />
          Karta potyczki · trudność
        </span>
        <strong className="difficulty-percent">
          {result?.percent == null ? 'N/D' : `${Math.round(result.percent)}%`}
        </strong>
      </summary>
      <div className="difficulty-content">
        <div className="difficulty-party">
          <div className="difficulty-party-heading">
            <div>
              <h3>Poziomy BG</h3>
              <p>Wpisz poziom każdej postaci w tej potyczce.</p>
            </div>
            <span className="difficulty-party-count">
              {levels.filter((value) => value.trim()).length} BG
            </span>
          </div>
          <div className="difficulty-level-grid">
            {levels.map((value, index) => (
              <div className="difficulty-level" key={index}>
                <label htmlFor={`party-level-${slotId}-${index}`}>
                  BG {index + 1}
                </label>
                <div className="difficulty-level-control">
                  <input
                    id={`party-level-${slotId}-${index}`}
                    ref={(element) => {
                      levelInputs.current[index] = element;
                    }}
                    aria-label={`Poziom BG ${index + 1}`}
                    aria-invalid={
                      value !== '' &&
                      (!/^\d+$/.test(value) ||
                        !Number.isSafeInteger(Number(value)) ||
                        Number(value) < 1)
                    }
                    inputMode="numeric"
                    autoComplete="off"
                    value={value}
                    disabled={disabled}
                    onChange={(event) => {
                      const next = [...levels];
                      next[index] = event.target.value;
                      updateLevels(next);
                    }}
                    onKeyDown={(event) => {
                      if (
                        event.key === 'Enter' &&
                        /^\d+$/.test(value) &&
                        Number.isSafeInteger(Number(value)) &&
                        Number(value) > 0
                      ) {
                        event.preventDefault();
                        addLevel();
                      }
                    }}
                    onBlur={() => {
                      void details.flush(slotId);
                    }}
                  />
                  <button
                    type="button"
                    aria-label={`Usuń BG ${index + 1}`}
                    title={`Usuń BG ${index + 1}`}
                    disabled={disabled || levels.length === 1}
                    onClick={() => {
                      pendingFocus.current = Math.max(0, index - 1);
                      updateLevels(levels.filter((_, i) => i !== index));
                    }}
                  >
                    <X size={16} aria-hidden="true" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <button
            className="difficulty-add-bg"
            type="button"
            disabled={disabled}
            onClick={addLevel}
          >
            <Plus size={16} aria-hidden="true" /> Dodaj BG
          </button>
        </div>
        <div className="difficulty-result" aria-live="polite">
          {error ? (
            <p className="editor-error" role="alert">
              {error}
            </p>
          ) : result ? (
            <>
              {result.missingSP > 0 && (
                <p>
                  Brak SP u {result.missingSP} przeciwników. Uzupełnij SP na ich
                  kartach.
                </p>
              )}
              {result.sd === 0 && (
                <p>Dodaj poziomy BG, aby obliczyć trudność.</p>
              )}
            </>
          ) : (
            <p>Wczytywanie składu potyczki…</p>
          )}
        </div>
      </div>
    </details>
  );
}
