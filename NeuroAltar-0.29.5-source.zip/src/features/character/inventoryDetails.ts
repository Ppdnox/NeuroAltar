import type { InventoryEntry } from '../../domain/character/inventoryModel';
import {
  fixedWeaponWeight,
  inventoryWeight,
  weightlessAmmo,
} from '../../domain/medicineWeight';

export type ItemDetailField = {
  kind: 'magazine' | 'range' | 'weight' | 'damage' | 'ammo';
  label: string;
  value: string;
};

/** Presentation only: keep prose and unknown properties intact. */
export function inventoryDetails(entry: InventoryEntry) {
  const fields: ItemDetailField[] = [];
  const properties: string[] = [];
  let description = entry.item.description.trim();

  // Only the catalog's terse magazine/range notation is split into fields.
  // Narrative descriptions and decimal commas are not tokenized.
  if (/^Mag\.\s*[^;\n]+;/.test(description) && !description.includes('\n')) {
    const rest: string[] = [];
    for (const part of description.split(';').map((part) => part.trim())) {
      const magazine = /^Mag\.\s*(.+)$/.exec(part);
      const range = /^Zasięg:\s*(.+)$/.exec(part);
      if (magazine) {
        fields.push({
          kind: 'magazine',
          label: 'Pojemność magazynka',
          value: magazine[1]!,
        });
      } else if (range) {
        fields.push({ kind: 'range', label: 'Zasięg', value: range[1]! });
      } else if (part) rest.push(part);
    }
    description = '';
    if (rest.length) properties.push(rest.join('; '));
  }

  const noWeight = weightlessAmmo(entry);
  const fixedMass = fixedWeaponWeight(entry.item);
  let hasWeight = false;
  for (const property of entry.item.properties) {
    const match = /^(Waga|Obrażenia|Nabój):\s*(.+)$/s.exec(property.trim());
    if (!match) {
      if (property.trim()) properties.push(property);
      continue;
    }
    if (match[1] === 'Waga') {
      if (noWeight) continue;
      hasWeight = true;
      fields.push({
        kind: 'weight',
        label: 'Masa',
        value:
          fixedMass === null ||
          !/^(?:ok\.\s*)?\d+(?:[.,]\d+)?\s*kg\.?$/.test(match[2]!)
            ? match[2]!
            : `${fixedMass.toLocaleString('pl')} kg`,
      });
    } else {
      fields.push({
        kind: match[1] === 'Obrażenia' ? 'damage' : 'ammo',
        label: match[1] === 'Obrażenia' ? 'Obrażenia bazowe' : 'Nabój',
        value: match[2]!,
      });
    }
  }
  const mass = inventoryWeight(entry);
  if (!noWeight && !hasWeight && mass !== null) {
    fields.push({
      kind: 'weight',
      label:
        entry.massMode === 'aggregate'
          ? 'Masa zestawu'
          : `Masa / ${entry.unit}`,
      value: `${(mass / 1_000_000).toLocaleString('pl', { maximumFractionDigits: 2 })} kg`,
    });
  }
  return { fields, description, properties };
}
