import { useDiceStore } from '../../stores/diceStore';
import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';
import { useParticipationStore } from '../../stores/participationStore';
import { useNpcAbilityRollStore } from '../../stores/npcAbilityRollStore';
export function NpcAbilityEffects({
  actorId,
  slotId,
}: {
  actorId: string;
  slotId: number;
}) {
  const entries = useParticipationStore((s) => s.entries),
    settings = useNpcAbilityRollStore();
  const dice = useDiceStore();
  const round = useCombatStore(
    (s) => s.drafts[slotId as SlotId]?.value.roundNumber,
  );
  const effects = entries
    .filter((p) => p.encounterId === slotId && p.state === 'active')
    .flatMap((p) => p.effects.filter((e) => e.recipientActorId === actorId));
  if (!effects.length) return null;
  return (
    <fieldset>
      <legend>Zdolności działające na przeciwnika</legend>
      {effects.map((e) => (
        <p key={e.id}>
          {e.label}: {e.modifier ? `modyfikator ${e.modifier}; ` : ''}
          {e.mode === 'disadvantage'
            ? 'Utrudnienie'
            : e.mode === 'advantage'
              ? 'Ułatwienie'
              : ''}
          {e.phase === 'manual'
            ? ' — do zakończenia'
            : ` — pozostało ${e.remaining} odliczeń`}
        </p>
      ))}
      {effects
        .filter((e) => e.sourceRuleId === 'resource:heckle')
        .map((e) => {
          const original = dice.history.find(
            (r) =>
              r.context?.actorId === actorId &&
              r.context.encounterId === slotId &&
              r.context.roundNumber === round &&
              r.count === 1 &&
              r.sides === 20 &&
              (r.context.purpose === 'attack' ||
                r.context.label.startsWith('RO ')) &&
              !r.context.rerollOf &&
              !dice.history.some((l) => l.context?.rerollOf === r.id),
          );
          const owner = entries.find((p) =>
            p.effects.some((x) => x.id === e.id),
          )!;
          return (
            <button
              key={e.id}
              disabled={dice.busy || !!dice.pending || !original}
              onClick={() => {
                if (original?.context)
                  void dice.roll(
                    original.formula,
                    {
                      ...original.context,
                      label: 'Spieprzysz to! — ' + original.context.label,
                      rerollOf: original.id,
                      consumedEffects: [e.id],
                      effectOwnerActorId: owner.actorId,
                      participationRevision: owner.revision,
                    },
                    undefined,
                    {
                      mode: original.checkDice?.mode ?? 'normal',
                      keepWorseThan: original.values[0],
                    },
                  );
              }}
            >
              Spieprzysz to! — powtórz udany test i zachowaj gorszy wynik
              {original
                ? ` (${original.context?.label}: ${original.total})`
                : ''}
            </button>
          );
        })}
      <label>
        Efekt do następnego rzutu — potwierdź jego warunki
        <select
          value={settings.selected[actorId] ?? ''}
          onChange={(e) => settings.select(actorId, e.target.value)}
        >
          <option value="">Bez dodatkowego efektu</option>
          {effects
            .filter((e) => e.sourceRuleId !== 'resource:heckle')
            .map((e) => (
              <option key={e.id} value={e.id}>
                {e.label}
              </option>
            ))}
        </select>
      </label>
      <small>
        Obelga: wybierz ją tylko przy ataku na kogoś innego niż autor obelgi.
      </small>
    </fieldset>
  );
}
