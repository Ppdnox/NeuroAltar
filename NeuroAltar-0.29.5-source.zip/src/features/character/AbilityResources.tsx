import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import type { Character } from '../../domain/character/model';
import type { ResourceDefinition } from '../../domain/character/resources';
import { refreshNames } from '../../domain/character/resources';
import {
  resourceDotPage,
  resourceDotAvailable,
  toggleResourceDot,
  type ResourceDotLayout,
} from '../../domain/character/resourceRules';
import { manualResourceSchema } from '../../domain/character/conditionModel';
import { useCharacterStore } from '../../stores/characterStore';
import './abilityResources.css';

function ResourceDots({
  record,
  resource,
  disabled = false,
  showLabel,
}: {
  record: Character;
  resource: ResourceDefinition;
  disabled?: boolean;
  showLabel: boolean;
}) {
  const store = useCharacterStore();
  const [requestedPage, setRequestedPage] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [layout, setLayout] = useState<ResourceDotLayout | null>(null);
  const spent = record.condition?.spent[resource.id] ?? 0;
  const dots = resourceDotPage(resource.max, spent, requestedPage);
  const blocked =
    disabled ||
    record.archived ||
    !!record.draft ||
    !record.sheet ||
    store.locked ||
    store.saving ||
    store.dirty.includes(record.id) ||
    Object.keys(store.invalid).length > 0;

  async function step(direction: 'use' | 'restore', index?: number) {
    const currentStore = useCharacterStore.getState();
    const current = currentStore.records.find((r) => r.id === record.id);
    if (
      blocked ||
      currentStore.locked ||
      currentStore.saving ||
      !current ||
      current.archived ||
      current.draft ||
      !current.sheet
    )
      return;
    setError(null);
    currentStore.select(record.id);
    const saved = await currentStore.mutateCondition(
      { type: 'resourceStep', id: resource.id, direction },
      current.revision,
    );
    if (saved) {
      const nextLayout =
        index === undefined
          ? null
          : toggleResourceDot(layout, resource.max, spent, index);
      const updated = useCharacterStore
        .getState()
        .records.find((r) => r.id === record.id);
      setLayout(
        nextLayout?.spent === updated?.condition?.spent[resource.id]
          ? nextLayout
          : null,
      );
      if (index !== undefined) setRequestedPage(dots.page);
    } else
      setError(
        useCharacterStore.getState().error ??
          'Nie zapisano zmiany. Dokończ oczekujący zapis karty.',
      );
  }

  return (
    <div className="ability-resource" aria-label={`Użycia: ${resource.label}`}>
      <div className="ability-resource-meta">
        {showLabel && <strong>{resource.label}</strong>}
        <span>Odnowienie: {refreshNames[resource.refresh]}</span>
      </div>
      <div
        className="ability-resource-dots"
        role="group"
        aria-label={resource.label}
      >
        {Array.from({ length: dots.end - dots.start }, (_, index) => {
          const number = dots.start + index;
          const available = resourceDotAvailable(
            layout,
            resource.max,
            spent,
            number,
          );
          const label = `${available ? 'Użyj' : 'Przywróć'}: ${resource.label} — użycie ${number + 1}`;
          return (
            <button
              key={number}
              type="button"
              className="ability-resource-dot"
              aria-pressed={available}
              aria-label={label}
              title={label}
              disabled={blocked}
              onClick={() => void step(available ? 'use' : 'restore', number)}
            >
              <span aria-hidden="true" />
            </button>
          );
        })}
        {resource.max === 0 && spent > 0 && (
          <button
            type="button"
            className="ability-resource-dot"
            aria-pressed={false}
            aria-label={`Przywróć: ${resource.label} — wcześniejsze użycie`}
            title="Przywróć wcześniejsze użycie"
            disabled={blocked}
            onClick={() => void step('restore')}
          >
            <span aria-hidden="true" />
          </button>
        )}
        {resource.max === 0 && (
          <span className="ability-resource-empty">Brak dostępnych użyć</span>
        )}
      </div>
      {dots.lastPage > 0 && (
        <div
          className="ability-resource-pages"
          aria-label={`Użycia ${resource.label} — strony`}
        >
          <button
            type="button"
            aria-label="Pokaż poprzednie użycia"
            disabled={dots.page === 0}
            onClick={() => setRequestedPage(dots.page - 1)}
          >
            <ChevronLeft size={16} aria-hidden="true" />
          </button>
          <span>
            Użycia {dots.start + 1}–{dots.end} · limit {resource.max}
          </span>
          <button
            type="button"
            aria-label="Pokaż kolejne użycia"
            disabled={dots.page === dots.lastPage}
            onClick={() => setRequestedPage(dots.page + 1)}
          >
            <ChevronRight size={16} aria-hidden="true" />
          </button>
        </div>
      )}
      <span className="ability-resource-sr" role="status">
        {resource.label}: dostępne {dots.remaining} z {resource.max}.
      </span>
      {spent > resource.max && (
        <small className="ability-resource-empty">
          Wcześniejsze użycia ponad obecny limit: {spent - resource.max}.
        </small>
      )}
      {error && (
        <p className="ability-resource-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function AbilityResources({
  record,
  resources,
  disabled,
  showLabels = false,
}: {
  record: Character;
  resources: readonly ResourceDefinition[];
  disabled?: boolean;
  showLabels?: boolean;
}) {
  if (!resources.length) return null;
  return (
    <div className="ability-resources">
      {resources.map((resource) => (
        <ResourceDots
          key={record.id + ':' + resource.id}
          record={record}
          resource={resource}
          disabled={disabled}
          showLabel={showLabels || resources.length > 1}
        />
      ))}
    </div>
  );
}

export function ManualResourceForm({
  record,
  disabled = false,
}: {
  record: Character;
  disabled?: boolean;
}) {
  const store = useCharacterStore();
  const [open, setOpen] = useState(false);
  const [label, setLabel] = useState('');
  const [max, setMax] = useState('1');
  const [error, setError] = useState<string | null>(null);
  const blocked =
    disabled ||
    store.locked ||
    store.saving ||
    record.archived ||
    !!record.draft ||
    !record.sheet;

  async function add() {
    if (blocked || useCharacterStore.getState().locked) return;
    const parsed = manualResourceSchema.safeParse({
      id: crypto.randomUUID(),
      label: label.trim(),
      max: /^\d+$/.test(max) ? Number(max) : NaN,
    });
    if (!parsed.success) {
      setError('Podaj nazwę i limit od 0 do 100000.');
      return;
    }
    const current = useCharacterStore
      .getState()
      .records.find((r) => r.id === record.id);
    if (!current || current.archived || current.draft || !current.sheet) return;
    setError(null);
    store.select(record.id);
    if (
      await store.mutateCondition(
        {
          type: 'manual',
          entry: parsed.data,
          reason: 'Dodanie własnego licznika',
        },
        current.revision,
      )
    ) {
      setOpen(false);
      setLabel('');
      setMax('1');
    } else
      setError(useCharacterStore.getState().error ?? 'Nie zapisano licznika.');
  }

  return (
    <div className="ability-manual-resource">
      {!open ? (
        <button type="button" disabled={blocked} onClick={() => setOpen(true)}>
          <Plus size={16} aria-hidden="true" /> Dodaj własny licznik
        </button>
      ) : (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            void add();
          }}
        >
          <fieldset disabled={blocked}>
            <legend>Własny licznik</legend>
            <label>
              Nazwa
              <input
                value={label}
                maxLength={200}
                onChange={(event) => setLabel(event.target.value)}
              />
            </label>
            <label>
              Limit użyć
              <input
                type="number"
                min="0"
                max="100000"
                step="1"
                value={max}
                onChange={(event) => setMax(event.target.value)}
              />
            </label>
            <div>
              <button type="submit">Dodaj</button>
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  setError(null);
                }}
              >
                Anuluj
              </button>
            </div>
          </fieldset>
          {error && (
            <p role="alert" className="ability-resource-error">
              {error}
            </p>
          )}
        </form>
      )}
    </div>
  );
}
