import {
  Backpack,
  ChevronUp,
  Crosshair,
  Dices,
  Hand,
  Package,
  RotateCw,
  Search,
  Shirt,
  Sword,
  Shield,
} from 'lucide-react';
import { StarterEquipmentPanel } from './StarterEquipmentPanel';
import {
  itemDisplayName,
  withItemDisplayName,
} from '../../domain/catalogNames';
import { ItemIllustration } from '../equipment/ItemIllustration';
import {
  allowedSlots,
  availableSlotOptions,
  displayedSlot,
  isHandySlot,
  isLegacyHandSlot,
  isReadyWeapon,
  weaponGrip,
} from '../../domain/character/inventorySlots';
import { formatWeaponRange } from '../../domain/item';
import { useDiceStore } from '../../stores/diceStore';
import {
  inventoryWeight,
  weightlessAmmo,
  fixedWeaponWeight,
  medicineWeightReason,
} from '../../domain/medicineWeight';
import { conditionSheet } from '../../domain/character/condition';
import { ZodError } from 'zod';
import { useEffect, useRef, useState } from 'react';
import { create } from 'zustand';
import { useCharacterStore } from '../../stores/characterStore';
import { useParticipationStore } from '../../stores/participationStore';
import {
  rollCharacter,
  characterRollSettings,
  defaultRollSettings,
} from '../../services/characterRolls';
import type { SlotId } from '../../domain/encounterDetails';
import { useEquipmentStore } from '../../stores/equipmentStore';
import {
  emptyInventory,
  PLACES,
  SLOTS,
  type InventoryEntry,
  type InventoryAction,
  type Inventory,
  type FireMode,
  newInventoryEntry,
} from '../../domain/character/inventoryModel';
import {
  applyInventoryAction,
  countRounds,
  cinematic,
  weaponMagazine,
  InventoryError,
  effectivePlace,
  ancestry,
} from '../../domain/character/inventory';
import {
  deriveEquipment,
  deriveInventoryWeapon,
} from '../../domain/character/equipped';
import {
  catalogEntry,
  customItem,
} from '../../domain/character/inventoryCatalog';
import type { Character } from '../../domain/character/model';
import { deriveCharacter } from '../../domain/character/derive';
import { weaponNames } from '../../domain/character/catalog';
import { filterEquipment, ITEM_TYPES } from '../../domain/equipment';
import { InventoryItemDetails } from './InventoryItemDetails';
import {
  BASE_TRADE_CONTEXT,
  TRADE_COLORS,
  marketRulesSchema,
  calculateMarketValues,
  type TradeContext,
} from '../../domain/market';
import rawRules from '../../data/equipment/market-rules.v1.json';
import './inventory.css';
const rules = marketRulesSchema.parse(rawRules);
const fmt = (n: number) => n.toLocaleString('pl', { maximumFractionDigits: 2 });
const modes: Record<FireMode, string> = {
  single: 'Pojedynczy',
  double: 'Dublet',
  short: 'Krótka seria',
  long: 'Długa seria',
  massive: 'Miażdżąca seria',
};
const inventoryGroups = [
  { id: 'melee', label: 'Broń biała', icon: Sword },
  { id: 'ranged', label: 'Broń dystansowa', icon: Crosshair },
  { id: 'handy', label: 'Przedmioty podręczne', icon: Hand },
  { id: 'armor', label: 'Pancerz i osłony', icon: Shield },
  { id: 'body', label: 'Przy sobie', icon: Shirt },
  { id: 'backpack', label: 'Plecak', icon: Backpack },
  { id: 'external', label: 'Juki / przechowywane', icon: Package },
] as const;
function inventoryGroup(inv: Inventory, entry: InventoryEntry) {
  const place = effectivePlace(inv, entry);
  if (place === 'backpack' || place === 'external') return place;
  const owner = ancestry(inv, entry).at(-1) ?? entry;
  const slot = displayedSlot(inv, owner);
  if (slot.startsWith('melee')) return 'melee';
  if (slot.startsWith('ranged')) return 'ranged';
  if (isHandySlot(slot) || place === 'handy') return 'handy';
  if (owner.armor && slot !== 'none') return 'armor';
  return 'body';
}
function inventoryOrder(inv: Inventory, entry: InventoryEntry) {
  const owner = ancestry(inv, entry).at(-1) ?? entry;
  return `${displayedSlot(inv, owner)}:${owner.id}:${entry.id === owner.id ? '0' : '1'}`;
}
function placementLabel(inv: Inventory, entry: InventoryEntry) {
  const weapon = inv.entries.find((w) => w.installedMagazineId === entry.id);
  if (weapon) return `W broni: ${weapon.item.name}`;
  const slot = displayedSlot(inv, entry);
  return slot === 'none' ? PLACES[effectivePlace(inv, entry)] : SLOTS[slot];
}
type Editor = {
  entry: InventoryEntry;
  reason: string;
  quantity: string;
  weight: string;
  paid: string;
};
type DialogState = {
  owner: string | null;
  editor: Editor | null;
  preview: {
    action: InventoryAction;
    revision: number;
    summary: string;
  } | null;
  error: string | null;
  set: (patch: Partial<Omit<DialogState, 'set'>>) => void;
};
const useDialog = create<DialogState>((set) => ({
  owner: null,
  editor: null,
  preview: null,
  error: null,
  set,
}));
function Modal({
  children,
  onCancel,
}: {
  children: React.ReactNode;
  onCancel: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    d?.showModal();
    return () => d?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      className="bg-dialog inventory-dialog"
      onCancel={(e) => {
        e.preventDefault();
        onCancel();
      }}
    >
      {children}
    </dialog>
  );
}
export function InventoryPanel({
  record,
  view = 'inventory',
}: {
  record: Character;
  view?: 'weapons' | 'inventory';
}) {
  const store = useCharacterStore(),
    equipment = useEquipmentStore(),
    dialog = useDialog();
  const [query, setQuery] = useState(''),
    [type, setType] = useState<keyof typeof ITEM_TYPES | ''>(''),
    [showCatalog, setShowCatalog] = useState(false),
    [context, setContext] = useState<TradeContext>(
      structuredClone(BASE_TRADE_CONTEXT),
    );
  const sheet = conditionSheet(record.sheet ?? record.draft!, record.condition),
    inv = record.inventory ?? emptyInventory(),
    result = deriveEquipment(sheet, inv, record.condition),
    disabled =
      !record.sheet || !!record.draft || record.archived || store.locked;
  useEffect(() => {
    if (!useEquipmentStore.getState().loaded)
      void useEquipmentStore.getState().load();
  }, []);
  const owned = dialog.owner === record.id;
  const catalogToggle = useRef<HTMLButtonElement>(null);
  const catalogSearch = useRef<HTMLInputElement>(null);
  function closeCatalog() {
    catalogToggle.current?.focus();
    setShowCatalog(false);
  }
  function toggleCatalog() {
    if (showCatalog) closeCatalog();
    else {
      setShowCatalog(true);
      requestAnimationFrame(() => catalogSearch.current?.focus());
    }
  }
  function close() {
    store.invalidInput(record.id + ':inventory-dialog', null);
    dialog.set({ owner: null, editor: null, preview: null, error: null });
  }
  function edit(entry: InventoryEntry) {
    const slot = displayedSlot(inv, entry);
    const placement =
      slot === entry.slot
        ? {}
        : {
            slot,
            location: isHandySlot(slot)
              ? ('handy' as const)
              : ('body' as const),
            parentId: null,
            ...(entry.weapon && isLegacyHandSlot(entry.slot)
              ? { grip: weaponGrip(entry) }
              : {}),
          };
    store.invalidInput(
      record.id + ':inventory-dialog',
      'Niedokończona edycja inwentarza',
    );
    dialog.set({
      owner: record.id,
      editor: {
        entry: {
          ...structuredClone(entry),
          item: structuredClone(withItemDisplayName(entry.item)),
          ...placement,
          weightReason:
            entry.weightReason ||
            (inventoryWeight(entry) === 0 ? medicineWeightReason : ''),
        },
        reason: 'Zmiana inwentarza',
        quantity: String(entry.quantityMilli / 1000),
        weight:
          inventoryWeight(entry) === null
            ? ''
            : String(inventoryWeight(entry)! / 1_000_000),
        paid: entry.paidMilli === null ? '' : String(entry.paidMilli / 1000),
      },
      preview: null,
      error: null,
    });
  }
  function preview(action: InventoryAction, summary: string) {
    try {
      applyInventoryAction(
        inv,
        action,
        sheet.rulesContext.gameColor,
        deriveCharacter(sheet).activeFeats.includes('fingers'),
      );
      store.invalidInput(
        record.id + ':inventory-dialog',
        'Potwierdź lub anuluj zmianę inwentarza',
      );
      dialog.set({
        owner: record.id,
        preview: { action, revision: record.revision, summary },
        error: null,
      });
    } catch (e) {
      const fields: Record<string, string> = {
        quantityMilli: 'Ilość',
        weightMg: 'Masa jednostki',
        paidMilli: 'Zapłacono',
        item: 'Przedmiot',
        weapon: 'Profil broni',
        armor: 'Profil pancerza',
      };
      dialog.set({
        error:
          e instanceof ZodError
            ? e.issues
                .map(
                  (i) =>
                    `${i.path
                      .filter((k) => typeof k === 'string' && k !== 'entries')
                      .map((k) => fields[String(k)] ?? k)
                      .join(
                        ' → ',
                      )}: wpisz poprawną wartość w dozwolonym zakresie.`,
                )
                .join('; ')
            : String(e),
      });
      if (e instanceof ZodError) {
        const field = e.issues[0]?.path.find((k) =>
          ['quantityMilli', 'weightMg', 'paidMilli'].includes(String(k)),
        );
        if (field)
          document.getElementById('inventory-field-' + String(field))?.focus();
      }
      if (e instanceof InventoryError && e.entryId) {
        window.dispatchEvent(
          new CustomEvent('bg-show-page', { detail: 'inventory' }),
        );
        requestAnimationFrame(() => {
          document
            .getElementById('inventory-' + e.entryId)
            ?.scrollIntoView({ block: 'center' });
        });
      }
    }
  }
  async function confirm() {
    const p = dialog.preview;
    if (!p) return;
    if (record.revision !== p.revision) {
      dialog.set({
        error: 'Karta zmieniła się. Anuluj i sprawdź nowy podgląd.',
      });
      return;
    }
    close();
    await store.mutateInventory(p.action);
  }
  function makeMagazine(weapon: InventoryEntry) {
    const w = weapon.weapon!;
    const e = newInventoryEntry(customItem('Magazynek — ' + weapon.item.name));
    e.catalogId = null;
    e.item.type = 'ammunition';
    e.magazine = {
      capacity: w.capacity,
      caliber: w.caliber,
      model: w.model,
      rounds: [],
    };
    edit(e);
  }
  const items = filterEquipment(equipment.items, query, type, '');
  return (
    <section
      className="bg-section bg-inventory"
      id="bg-inventory"
      data-inventory-view={view}
    >
      <div className="inventory-heading">
        <div>
          <h2>{view === 'weapons' ? 'Broń i ataki' : 'Ekwipunek'}</h2>
          <p hidden={view === 'weapons'}>
            Masa niesiona:{' '}
            <strong>
              {fmt(result.weight.kg)} kg
              {!result.weight.complete ? ' + nieznana masa' : ''}
            </strong>{' '}
            · {result.encumbrance.label}
          </p>
        </div>
        <button
          ref={catalogToggle}
          type="button"
          className="inventory-catalog-toggle"
          hidden={view === 'weapons'}
          aria-expanded={showCatalog}
          aria-controls="inventory-catalog"
          onClick={toggleCatalog}
        >
          {showCatalog ? (
            <ChevronUp aria-hidden="true" />
          ) : (
            <Search aria-hidden="true" />
          )}
          {showCatalog ? 'Schowaj wyszukiwarkę' : 'Dodaj z katalogu'}
        </button>
        <button
          hidden={view === 'weapons'}
          disabled={disabled}
          onClick={() => {
            const e = newInventoryEntry(customItem());
            e.catalogId = null;
            edit(e);
          }}
        >
          Dodaj własny przedmiot
        </button>
      </div>
      {disabled && !store.locked && (
        <p className="bg-notice">
          Zatwierdź lub odrzuć szkic rozwoju, aby korzystać z inwentarza.
        </p>
      )}
      {dialog.error && !owned && (
        <p role="alert" className="bg-invalid">
          {dialog.error}
        </p>
      )}
      {result.weight.unknownIds.length > 0 && (
        <div className="bg-notice" hidden={view === 'weapons'}>
          Uzupełnij masę:{' '}
          {result.weight.unknownIds.map((id) => {
            const e = inv.entries.find((e) => e.id === id)!;
            return (
              <button
                key={id}
                className="bg-link"
                disabled={disabled}
                onClick={() => edit(e)}
              >
                {itemDisplayName(e.item)}
              </button>
            );
          })}
        </div>
      )}
      <details className="inventory-settings" hidden={view === 'weapons'}>
        <summary>Warunki handlu i liczenie amunicji</summary>
        <div className="inventory-settings-grid">
          <section>
            <h3>Warunki handlu</h3>
            <div className="inventory-fields">
              <label>
                Region
                <select
                  value={
                    context.region.kind === 'none' ? 'none' : context.region.id
                  }
                  onChange={(e) =>
                    setContext({
                      ...context,
                      region:
                        e.target.value === 'none'
                          ? { kind: 'none' }
                          : { kind: 'region', id: e.target.value },
                    })
                  }
                >
                  <option value="none">N/D</option>
                  {Object.entries(rules.regions).map(([id, r]) => (
                    <option key={id} value={id}>
                      {r.label}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Lokalizacja
                <select
                  value={
                    context.location.kind === 'none'
                      ? 'none'
                      : context.location.id
                  }
                  onChange={(e) =>
                    setContext({
                      ...context,
                      location:
                        e.target.value === 'none'
                          ? { kind: 'none' }
                          : { kind: 'location', id: e.target.value },
                    })
                  }
                >
                  <option value="none">N/D</option>
                  {Object.entries(rules.locations).map(([id, r]) => (
                    <option key={id} value={id}>
                      {r.label}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Kolor handlu
                <select
                  value={context.color}
                  onChange={(e) =>
                    setContext({
                      ...context,
                      color: e.target.value as TradeContext['color'],
                    })
                  }
                >
                  {Object.entries(TRADE_COLORS).map(([id, c]) => (
                    <option key={id} value={id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <p className="bg-small">
              Odrębne od Koloru gry. Kwota zapłacona pozostaje bez zmian.
              {result.availabilityBonus > 0
                ? ' Gambling we krwi: +5 punktów procentowych przed mnożnikiem Koloru.'
                : ''}
            </p>
          </section>
          <section>
            <h3>Amunicja</h3>{' '}
            <label className="inventory-mode">
              Liczenie amunicji
              <select
                disabled={disabled}
                value={inv.ammoMode}
                onChange={(e) =>
                  preview(
                    {
                      kind: 'mode',
                      mode: e.target.value as Inventory['ammoMode'],
                    },
                    'Zmień sposób liczenia. Dokładny zapas i zawartość magazynków pozostaną zachowane. W trybie nieliczonym oddzielnie oznacz broń jako załadowaną.',
                  )
                }
              >
                <option value="auto">
                  Według Koloru gry (Chrom: nieliczony zapas)
                </option>
                <option value="tracked">Dokładne liczenie naboi</option>
                <option value="cinematic">Nieliczony zapas</option>
              </select>
            </label>
            {cinematic(inv, sheet.rulesContext.gameColor) && (
              <p className="bg-notice">
                Nieliczony zapas: po naturalnej 1 oznacz „Pusta broń”. Przycisk
                przeładowania przywraca gotowość. Dokładny zapas jest zachowany.
              </p>
            )}
          </section>
        </div>
      </details>
      {showCatalog && (
        <section
          className="inventory-catalog"
          id="inventory-catalog"
          hidden={view === 'weapons'}
          aria-labelledby="inventory-catalog-title"
        >
          <div className="inventory-catalog-toolbar">
            <h3 id="inventory-catalog-title">
              <Search aria-hidden="true" />
              Katalog przedmiotów
            </h3>
            <button
              type="button"
              onClick={closeCatalog}
              className="inventory-catalog-close"
            >
              <ChevronUp aria-hidden="true" />
              Schowaj wyszukiwarkę
            </button>
          </div>
          <div className="inventory-fields">
            <label>
              Szukaj przedmiotu
              <input
                ref={catalogSearch}
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Nazwa lub właściwość…"
              />
            </label>
            <label>
              Typ
              <select
                value={type}
                onChange={(e) => setType(e.target.value as typeof type)}
              >
                <option value="">Wszystkie</option>
                {Object.entries(ITEM_TYPES).map(([id, label]) => (
                  <option value={id} key={id}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          {equipment.error && (
            <p role="alert">
              {equipment.error}
              <button onClick={() => void equipment.load()}>
                Ponów odczyt
              </button>
            </p>
          )}
          <p>{items.length} wyników · pokazano pierwsze 30</p>
          <div className="inventory-search-results">
            {items.slice(0, 30).map((i) => (
              <button
                key={i.id}
                disabled={disabled}
                onClick={() => edit(catalogEntry(i))}
              >
                <ItemIllustration item={i} size="small" />
                <span className="inventory-search-copy">
                  <strong>{i.name}</strong>
                  <small>{i.category}</small>
                </span>
              </button>
            ))}
          </div>
        </section>
      )}
      <div hidden={view === 'weapons'}>
        <StarterEquipmentPanel
          key={record.id}
          classId={sheet.levels[0]!.classId}
          inventory={inv}
          items={equipment.items}
          disabled={disabled || equipment.loading || !equipment.loaded}
          onPreview={preview}
        />
      </div>
      {inventoryGroups.map(({ id: place, label, icon: PlaceIcon }) => {
        const entries = inv.entries
          .filter((e) => inventoryGroup(inv, e) === place)
          .sort((a, b) =>
            inventoryOrder(inv, a).localeCompare(inventoryOrder(inv, b)),
          );
        if (!entries.length) return null;
        return (
          <section
            key={place}
            className="inventory-place"
            hidden={
              view === 'weapons' && !entries.some((entry) => entry.weapon)
            }
          >
            <h3>
              <PlaceIcon aria-hidden="true" />
              {label}
              <span className="inventory-place-count">
                {
                  entries.filter(
                    (entry) =>
                      (view === 'inventory' || entry.weapon) &&
                      !inv.entries.some(
                        (weapon) => weapon.installedMagazineId === entry.id,
                      ),
                  ).length
                }
              </span>
            </h3>
            <div className="inventory-list">
              {entries.map((e) => {
                let market: ReturnType<typeof calculateMarketValues> | null =
                    null,
                  marketError = '';
                try {
                  market = calculateMarketValues(
                    e.item,
                    context,
                    rules,
                    result.availabilityBonus,
                  );
                } catch (error) {
                  marketError = String(error);
                }
                return (
                  <article
                    key={e.id}
                    id={'inventory-' + e.id}
                    className={
                      'inventory-entry' +
                      (e.weapon ? ' inventory-entry--weapon' : '')
                    }
                    hidden={view === 'weapons' && !e.weapon}
                  >
                    <div className="inventory-heading">
                      <div className="inventory-item-identity">
                        <ItemIllustration item={e.item} />
                        <div className="inventory-item-copy">
                          <h4>{itemDisplayName(e.item)}</h4>
                          <p>
                            {fmt(e.quantityMilli / 1000)} {e.unit}{' '}
                            {!weightlessAmmo(e) &&
                              '· ' +
                                (inventoryWeight(e) === null
                                  ? 'masa nieznana'
                                  : `${fmt(inventoryWeight(e)! / 1_000_000)} kg / ${e.massMode === 'aggregate' ? 'zestaw' : e.unit}`)}{' '}
                            · {placementLabel(inv, e)}
                          </p>
                          {e.parentId && (
                            <small>
                              W:{' '}
                              {
                                inv.entries.find((x) => x.id === e.parentId)
                                  ?.item.name
                              }
                            </small>
                          )}
                        </div>
                      </div>
                      <button disabled={disabled} onClick={() => edit(e)}>
                        {view === 'weapons' && !isReadyWeapon(e)
                          ? 'Wyposaż / edytuj'
                          : 'Edytuj'}
                      </button>
                    </div>
                    {e.weapon && (
                      <details
                        className="inventory-weapon-details"
                        open={view === 'weapons'}
                      >
                        <summary>Broń i ataki</summary>
                        {!isReadyWeapon(e) && (
                          <p className="inventory-ready-note">
                            Przypisz broń do numerowanego slotu w edycji
                            przedmiotu, aby wykonać atak.
                          </p>
                        )}
                        <WeaponControls
                          entry={e}
                          inv={inv}
                          record={record}
                          disabled={disabled}
                          preview={preview}
                          makeMagazine={makeMagazine}
                        />
                      </details>
                    )}
                    {e.magazine &&
                      (!e.weapon ||
                        ['none', 'singleUse'].includes(e.weapon.system)) && (
                        <MagazineControls
                          movie={cinematic(inv, sheet.rulesContext.gameColor)}
                          entry={e}
                          inv={inv}
                          disabled={disabled}
                          preview={preview}
                        />
                      )}
                    <InventoryItemDetails
                      entry={e}
                      market={market}
                      error={marketError}
                    />
                  </article>
                );
              })}
            </div>
          </section>
        );
      })}
      {view === 'weapons' && !inv.entries.some((entry) => entry.weapon) && (
        <div className="inventory-empty">
          <Crosshair aria-hidden="true" />
          <h3>Nie masz jeszcze broni</h3>
          <p>
            Dodaj broń z katalogu Ekwipunku i wybierz dla niej slot broni białej
            lub dystansowej.
          </p>
          <button
            onClick={() =>
              window.dispatchEvent(
                new CustomEvent('bg-show-page', { detail: 'inventory' }),
              )
            }
          >
            Otwórz Ekwipunek
          </button>
        </div>
      )}
      {view === 'inventory' && !inv.entries.length && (
        <p className="inventory-empty">
          Inwentarz jest pusty. Dodaj pierwszy przedmiot z katalogu lub utwórz
          własny.
        </p>
      )}
      <p
        className="bg-small inventory-packing-note"
        hidden={view === 'weapons'}
      >
        Plecak: dobycie wymaga{' '}
        {deriveCharacter(sheet).activeFeats.includes('packing')
          ? 'Interakcji (Pakowanie)'
          : 'Akcji'}
        . Pod ręką: Interakcja.
      </p>
      {owned && (dialog.editor || dialog.preview) && (
        <Modal onCancel={close}>
          {dialog.error && (
            <p role="alert" className="bg-invalid">
              {dialog.error}
            </p>
          )}
          {dialog.preview ? (
            <>
              <h2>Potwierdź zmianę</h2>
              <p>{dialog.preview.summary}</p>
              <div className="inventory-heading">
                <button onClick={() => void confirm()}>Zatwierdź</button>
                <button
                  onClick={() =>
                    dialog.editor
                      ? dialog.set({ preview: null, error: null })
                      : close()
                  }
                >
                  Wróć
                </button>
                <button onClick={close}>Anuluj</button>
              </div>
            </>
          ) : (
            <EntryEditor
              editor={dialog.editor!}
              inv={inv}
              onChange={(editor) => dialog.set({ editor, error: null })}
              onPreview={preview}
              onCancel={close}
            />
          )}
        </Modal>
      )}
    </section>
  );
}
function MagazineControls({
  movie,
  entry: e,
  inv,
  disabled,
  preview,
}: {
  movie: boolean;
  entry: InventoryEntry;
  inv: Inventory;
  disabled: boolean;
  preview: (a: InventoryAction, s: string) => void;
}) {
  const [ammo, setAmmo] = useState(''),
    [count, setCount] = useState('1');
  const stocks = inv.entries.filter(
    (a) => a.caliber && a.caliber === e.magazine!.caliber,
  );
  const selected = stocks.find((a) => a.id === ammo) ?? stocks[0];
  return (
    <div className="inventory-magazine">
      <strong>
        {movie ? 'Zachowany stan magazynka (dokładne liczenie):' : 'Magazynek:'}{' '}
        {countRounds(e)} / {e.magazine!.capacity} · {e.magazine!.caliber}
      </strong>
      {!movie && !countRounds(e) && (
        <p className="bg-invalid">Pusty magazynek — przeładuj</p>
      )}
      <p className="bg-small">
        {e
          .magazine!.rounds.map(
            (l) =>
              `${inv.entries.find((a) => a.id === l.ammoId)?.item.name}: ${l.count}`,
          )
          .join(' · ')}
      </p>
      <div className="inventory-fields">
        <label>
          Zapas
          <select
            disabled={disabled}
            value={selected?.id ?? ''}
            onChange={(e) => setAmmo(e.target.value)}
          >
            <option value="">Wybierz zapas</option>
            {stocks.map((a) => (
              <option key={a.id} value={a.id}>
                {a.item.name} · {a.quantityMilli / 1000} ·{' '}
                {PLACES[effectivePlace(inv, a)]}
              </option>
            ))}
          </select>
        </label>
        <label>
          Liczba naboi
          <input
            inputMode="numeric"
            value={count}
            onChange={(e) => setCount(e.target.value)}
          />
        </label>
      </div>
      <div className="inventory-heading">
        <button
          disabled={disabled || !selected}
          onClick={() =>
            selected &&
            preview(
              {
                kind: 'load',
                magazineId: e.id,
                ammoId: selected.id,
                count: Number(count),
              },
              `Przenieś ${count} naboi z ${selected.item.name} (${PLACES[effectivePlace(inv, selected)]}) do ${itemDisplayName(e.item)}.`,
            )
          }
        >
          Załaduj naboje
        </button>
        <button
          disabled={disabled || !countRounds(e)}
          onClick={() =>
            preview(
              { kind: 'unload', magazineId: e.id },
              `Wyjmij ${countRounds(e)} naboi do pierwotnych zapasów: ${e
                .magazine!.rounds.map((l) => {
                  const a = inv.entries.find((a) => a.id === l.ammoId)!;
                  return a.item.name + ' — ' + PLACES[effectivePlace(inv, a)];
                })
                .join(', ')}.`,
            )
          }
        >
          Rozładuj
        </button>
      </div>
    </div>
  );
}
function WeaponControls({
  entry: e,
  inv,
  record,
  disabled,
  preview,
  makeMagazine,
}: {
  entry: InventoryEntry;
  inv: Inventory;
  record: Character;
  disabled: boolean;
  preview: (a: InventoryAction, s: string) => void;
  makeMagazine: (w: InventoryEntry) => void;
}) {
  const dice = useDiceStore();
  const [mode, setMode] = useState<FireMode>('single'),
    [firing, setFiring] = useState(false),
    [count, setCount] = useState(10),
    [ability, setAbility] = useState<'auto' | 'str' | 'dex'>('auto'),
    [damage, setDamage] = useState(''),
    [grip, setGrip] = useState<'oneHanded' | 'twoHanded' | undefined>(),
    [mag, setMag] = useState(''),
    [heatFace, setHeatFace] = useState(''),
    [coolReason, setCoolReason] = useState(''),
    [reload, setReload] = useState(false);
  const sheet = conditionSheet(record.sheet ?? record.draft!, record.condition),
    w = e.weapon!,
    movie = cinematic(inv, sheet.rulesContext.gameColor),
    cost =
      mode === 'single'
        ? 1
        : mode === 'double'
          ? 2
          : mode === 'short'
            ? 3
            : count;
  const p = deriveInventoryWeapon(
      sheet,
      e,
      mode,
      cost,
      ability,
      damage,
      inv,
      'normal',
      grip,
    ),
    m = weaponMagazine(inv, e),
    stats = deriveCharacter(sheet),
    equipped = deriveEquipment(sheet, inv, record.condition);
  const compatible = inv.entries.filter(
    (x) =>
      x.magazine &&
      !x.weapon &&
      x.magazine.model === w.model &&
      x.magazine.caliber === w.caliber &&
      x.magazine.capacity === w.capacity &&
      !inv.entries.some((other) => other.installedMagazineId === x.id),
  );
  const isArea = mode === 'long' || mode === 'massive';
  const sourceKey = `weapon:${e.id}:${mode}`;
  const canShoot =
    !disabled &&
    !firing &&
    !dice.busy &&
    !dice.pending &&
    isReadyWeapon(e) &&
    !e.spent &&
    !e.combatState?.jammed &&
    !(isArea && (e.combatState?.overheated || e.combatState?.heatPending)) &&
    !(e.needsCycle && !stats.activeFeats.includes('fingers')) &&
    (w.system === 'none' ||
      w.system === 'singleUse' ||
      (movie ? e.cinematicLoaded : !!m && countRounds(m) >= cost));
  async function attack(favoriteBonus = false) {
    if (
      !canShoot ||
      !p ||
      (!isArea && p.attack === null) ||
      useDiceStore.getState().busy ||
      useDiceStore.getState().pending
    )
      return;
    setFiring(true);
    try {
      if (!isArea) {
        const diceStore = useDiceStore.getState();
        diceStore.setOpen(true);
        await diceStore.load();
        if (!useDiceStore.getState().loaded) return;
        const { manual } =
          characterRollSettings.getState().values[record.id] ??
          defaultRollSettings;
        if (
          manual.trim() &&
          (!Number.isInteger(Number(manual)) ||
            Number(manual) < 1 ||
            Number(manual) > 20)
        ) {
          useDiceStore.setState({
            inputError: 'Ręczny wynik kości musi wynosić 1–20.',
          });
          return;
        }
      }
      const active = useParticipationStore
        .getState()
        .entries.find(
          (entry) =>
            entry.characterId === record.id && entry.state === 'active',
        );
      const saved =
        w.system === 'none'
          ? active
            ? await useParticipationStore
                .getState()
                .send(active.actorId, active.encounterId as SlotId, record.id, {
                  kind: 'weaponAttack',
                  weaponId: e.id,
                  bonus: favoriteBonus,
                })
            : true
          : await useCharacterStore.getState().mutateInventory({
              kind: 'shot',
              weaponId: e.id,
              mode,
              count: cost,
              ...(favoriteBonus ? { favoriteBonus: true } : {}),
            });
      if (!saved || isArea || !p) return;
      if (active && w.system !== 'none') {
        await useParticipationStore.getState().load();
      }
      const current = useCharacterStore
        .getState()
        .records.find((r) => r.id === record.id);
      if (!current) return;
      const participation = useParticipationStore
        .getState()
        .entries.find(
          (entry) =>
            entry.characterId === record.id && entry.state === 'active',
        );
      await rollCharacter(
        current,
        participation,
        String(p.attack),
        `Atak — ${itemDisplayName(e.item)}`,
        ['attack', p.ability],
        'attack',
        sourceKey,
        p.disadvantage,
      );
    } finally {
      setFiring(false);
    }
  }
  return (
    <div className="inventory-weapon">
      {p && (
        <div className="inventory-weapon-rolls">
          <button
            type="button"
            disabled={!canShoot || (!isArea && p.attack === null)}
            onClick={() => void attack()}
          >
            <span className="inventory-roll-label">
              <Crosshair aria-hidden="true" />
              {isArea ? 'Seria obszarowa' : 'Rzuć na atak'}
            </span>
            <strong className="inventory-roll-value">
              {isArea
                ? 'Rozlicz serię'
                : p.attack === null
                  ? '—'
                  : `${p.attack >= 0 ? '+' : ''}${p.attack}`}
            </strong>
            <small>
              {isArea ? modes[mode] : '1k20'}
              {w.system !== 'none' &&
                !movie &&
                ` · −${cost} ${cost === 1 ? 'nabój' : 'naboi'}`}
            </small>
          </button>
          <button
            type="button"
            disabled={
              disabled ||
              p.damage.includes('?') ||
              firing ||
              dice.busy ||
              !!dice.pending
            }
            onClick={() => {
              const current = useCharacterStore
                .getState()
                .records.find((r) => r.id === record.id);
              if (!current) return;
              const participation = useParticipationStore
                .getState()
                .entries.find(
                  (entry) =>
                    entry.characterId === record.id && entry.state === 'active',
                );
              void rollCharacter(
                current,
                participation,
                p.damage,
                `Obrażenia — ${itemDisplayName(e.item)}`,
                ['damage', p.ability],
                'damage',
                sourceKey,
              );
            }}
          >
            <span className="inventory-roll-label">
              <Dices aria-hidden="true" />
              Rzuć obrażenia
            </span>
            <strong className="inventory-roll-value">{p.damage}</strong>
            <small>{p.damageType}</small>
          </button>
          {(!p.proficient ||
            p.disadvantage ||
            equipped.untrained ||
            equipped.encumbrance.attackDisadvantage) && (
            <p>
              {!p.proficient ? 'Bez Biegłości' : ''}
              {p.disadvantage ||
              equipped.untrained ||
              equipped.encumbrance.attackDisadvantage
                ? `${!p.proficient ? ' · ' : ''}Utrudnienie ataku`
                : ''}
            </p>
          )}
        </div>
      )}
      {!p && (
        <p className="bg-small">
          Atak i obrażenia: uzupełnij profil ataku tej broni.
        </p>
      )}
      <div className="inventory-fields inventory-weapon-modes">
        {['short', 'intermediate', 'long', 'heavy'].includes(w.category) &&
          !w.twoHanded && (
            <label>
              Chwyt przy strzale
              <select
                value={grip ?? weaponGrip(e)}
                onChange={(event) =>
                  setGrip(event.target.value as 'oneHanded' | 'twoHanded')
                }
              >
                <option value="twoHanded">Dwie ręce</option>
                <option value="oneHanded">Jedna ręka</option>
              </select>
            </label>
          )}
        {e.item.weaponProfile?.abilityRule === 'finesse' && (
          <label>
            Finezyjna
            <select
              value={ability}
              onChange={(e) => setAbility(e.target.value as typeof ability)}
            >
              <option value="auto">Wyższy modyfikator</option>
              <option value="str">Siła</option>
              <option value="dex">Zręczność</option>
            </select>
          </label>
        )}
        {(e.item.weaponProfile?.damageModes.length ?? 0) > 1 && (
          <label>
            Obrażenia
            <select
              value={
                damage ||
                p?.damageModeId ||
                e.item.weaponProfile!.damageModes[0]!.id
              }
              onChange={(e) => setDamage(e.target.value)}
            >
              {e.item.weaponProfile!.damageModes.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.label}
                </option>
              ))}
            </select>
          </label>
        )}
        {w.system !== 'none' && (
          <label>
            Tryb strzału
            <select
              value={mode}
              onChange={(e) => {
                const mode = e.target.value as FireMode;
                setMode(mode);
                setCount(mode === 'massive' ? 50 : 10);
              }}
            >
              {w.modes.map((m) => (
                <option key={m} value={m}>
                  {modes[m]}
                </option>
              ))}
            </select>
          </label>
        )}
        {['long', 'massive'].includes(mode) && (
          <label>
            Naboje
            <select
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
            >
              {(mode === 'long'
                ? [10, 15, 20, 25, 30]
                : [50, 100, 150, 200]
              ).map((n) => (
                <option key={n}>{n}</option>
              ))}
            </select>
          </label>
        )}
      </div>
      {p && (
        <p className="inventory-range">Zasięg {formatWeaponRange(p.range)}</p>
      )}
      {w.system !== 'none' && (
        <>
          <div className="inventory-reload-bar">
            <div className="inventory-magazine-status">
              <span>{movie ? 'Gotowość' : 'Magazynek'}</span>
              <strong>
                {movie ? (
                  e.cinematicLoaded ? (
                    'Broń załadowana'
                  ) : (
                    'Pusta broń'
                  )
                ) : (
                  <>
                    {m ? countRounds(m) : 0}
                    <small> / {w.capacity}</small>
                  </>
                )}
              </strong>
              {!movie && !m && w.system === 'detachable' && (
                <small>Brak zamontowanego magazynka</small>
              )}
              {e.needsCycle && !stats.activeFeats.includes('fingers') && (
                <small>Przeładuj mechanizm</small>
              )}
              {e.spent && <small>Zużyta</small>}
            </div>
            {!movie && !['none', 'singleUse'].includes(w.system) && (
              <button
                disabled={disabled}
                aria-expanded={reload}
                aria-controls={'reload-' + e.id}
                onClick={() => setReload(!reload)}
              >
                <RotateCw aria-hidden="true" />
                Przeładuj
              </button>
            )}
            {movie && (
              <>
                <button
                  disabled={disabled || e.cinematicLoaded}
                  onClick={() =>
                    preview(
                      { kind: 'cinematic', weaponId: e.id, loaded: true },
                      'Przeładuj broń. Dokładny zapas nie zmieni się.',
                    )
                  }
                >
                  <RotateCw aria-hidden="true" />
                  Przeładuj broń
                </button>
                <button
                  disabled={disabled || !e.cinematicLoaded}
                  onClick={() =>
                    preview(
                      { kind: 'cinematic', weaponId: e.id, loaded: false },
                      'Naturalna 1: broń jest pusta do przeładowania.',
                    )
                  }
                >
                  Pusta broń — naturalna 1
                </button>
              </>
            )}
            {w.cycle && (
              <button
                disabled={disabled || !e.needsCycle}
                onClick={() =>
                  preview(
                    { kind: 'cycle', weaponId: e.id },
                    'Przeładuj mechanizm: Interakcja lub Akcja Bonusowa, bez zużycia naboju.',
                  )
                }
              >
                Przeładuj mechanizm
              </button>
            )}
          </div>
          {stats.classLevels.twardziel > 0 &&
            ['single', 'double'].includes(mode) &&
            sheet.levels.some((l) =>
              (l.choices['favorite-weapon'] ?? []).some((name) =>
                [w.model, e.item.name].some(
                  (n) =>
                    n.trim().toLocaleLowerCase('pl') ===
                    name.trim().toLocaleLowerCase('pl'),
                ),
              ),
            ) && (
              <button
                disabled={!canShoot || p?.attack === null}
                onClick={() => void attack(true)}
              >
                Ulubiona broń — dodatkowy strzał (B)
              </button>
            )}
          {(sheet.rulesContext.gameColor !== 'chrome' ||
            e.combatState?.heatPending ||
            e.combatState?.overheated) && (
            <details
              className="inventory-maintenance"
              open={
                !!(
                  e.combatState?.jammed ||
                  e.combatState?.heatPending ||
                  e.combatState?.overheated
                )
              }
            >
              <summary>
                Stan broni
                {e.combatState?.jammed ? ' · zacięta' : ''}
                {e.combatState?.heatPending ? ' · sprawdź przegrzanie' : ''}
                {e.combatState?.overheated ? ' · przegrzana' : ''}
              </summary>
              <div className="inventory-heading">
                {sheet.rulesContext.gameColor !== 'chrome' && (
                  <button
                    disabled={disabled}
                    onClick={() =>
                      preview(
                        {
                          kind: 'weaponState',
                          weaponId: e.id,
                          operation: e.combatState?.jammed ? 'clearJam' : 'jam',
                          face: null,
                          reason: '',
                        },
                        e.combatState?.jammed
                          ? 'Usuń zacięcie: Akcja.'
                          : 'Potwierdź zacięcie przy pierwszym wystrzale: Akcja zużyta, amunicja bez zmian.',
                      )
                    }
                  >
                    {e.combatState?.jammed
                      ? 'Usuń zacięcie…'
                      : 'Zacięcie przy strzale…'}
                  </button>
                )}
                {e.combatState?.heatPending && (
                  <>
                    <label>
                      Wynik przegrzania k6
                      <input
                        type="number"
                        min="1"
                        max="6"
                        value={heatFace}
                        onChange={(event) => setHeatFace(event.target.value)}
                      />
                    </label>
                    <button
                      disabled={disabled}
                      onClick={async () => {
                        const dice = useDiceStore.getState();
                        if (
                          await dice.roll('1k6', undefined, {
                            characterId: record.id,
                            name: sheet.identity.name,
                            label: 'Przegrzanie — ' + e.item.name,
                          })
                        ) {
                          const last = useDiceStore.getState().history[0];
                          if (last) setHeatFace(String(last.values[0]));
                        }
                      }}
                    >
                      Rzuć k6
                    </button>
                    <button
                      disabled={
                        disabled ||
                        !Number.isInteger(Number(heatFace)) ||
                        Number(heatFace) < 1 ||
                        Number(heatFace) > 6
                      }
                      onClick={() =>
                        preview(
                          {
                            kind: 'weaponState',
                            weaponId: e.id,
                            operation: 'heat',
                            face: Number(heatFace),
                            reason: '',
                          },
                          Number(heatFace) < 5
                            ? 'Broń przegrzana — dalsza seria zablokowana.'
                            : 'Broń gotowa do kolejnej serii w następnej turze.',
                        )
                      }
                    >
                      Zastosuj wynik…
                    </button>
                  </>
                )}
                {e.combatState?.overheated && (
                  <>
                    <strong>Broń przegrzana — seria zablokowana</strong>
                    <label>
                      Ostygnięcie po walce — uzasadnienie MG
                      <input
                        value={coolReason}
                        onChange={(event) => setCoolReason(event.target.value)}
                      />
                    </label>
                    <button
                      disabled={disabled || !coolReason.trim()}
                      onClick={() =>
                        preview(
                          {
                            kind: 'weaponState',
                            weaponId: e.id,
                            operation: 'cool',
                            face: null,
                            reason: coolReason,
                          },
                          'Rozlicz ostygnięcie broni: ' + coolReason,
                        )
                      }
                    >
                      Potwierdź ostygnięcie…
                    </button>
                  </>
                )}
              </div>
            </details>
          )}
        </>
      )}
      {!['none', 'singleUse'].includes(w.system) && (
        <details
          className="inventory-reload-panel"
          id={'reload-' + e.id}
          open={reload}
          onToggle={(event) => setReload(event.currentTarget.open)}
        >
          <summary>Zapas i magazynki</summary>
          {m && (
            <MagazineControls
              movie={movie}
              entry={m}
              inv={inv}
              disabled={disabled}
              preview={preview}
            />
          )}
          {!movie && !m && w.system === 'detachable' && (
            <p>
              Dodaj pasujący magazynek, załaduj go nabojami i zamontuj w broni.
            </p>
          )}
          {w.system === 'detachable' && (
            <>
              <div className="inventory-fields">
                <label>
                  Magazynek do wymiany
                  <select
                    disabled={disabled}
                    value={mag}
                    onChange={(e) => setMag(e.target.value)}
                  >
                    <option value="">Wybierz magazynek</option>
                    {compatible.map((m) => (
                      <option key={m.id} value={m.id}>
                        {itemDisplayName(m.item)} · {countRounds(m)}/
                        {m.magazine!.capacity}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="inventory-heading">
                <button
                  disabled={disabled || !mag}
                  onClick={() =>
                    preview(
                      { kind: 'attach', weaponId: e.id, magazineId: mag },
                      'Wymień magazynek. Jeśli zapasowy był w slocie podręcznym, wyjęty magazynek zajmie ten slot. Liczba naboi nie zmienia się.',
                    )
                  }
                >
                  Przeładuj — wymień magazynek
                </button>
                <button
                  disabled={disabled || !e.installedMagazineId}
                  onClick={() =>
                    preview(
                      { kind: 'attach', weaponId: e.id, magazineId: null },
                      'Odłącz magazynek bez zmiany liczby naboi.',
                    )
                  }
                >
                  Wyjmij magazynek
                </button>
                <button disabled={disabled} onClick={() => makeMagazine(e)}>
                  Dodaj pasujący magazynek
                </button>
              </div>
            </>
          )}
        </details>
      )}
      <p className="bg-small">
        {w.system === 'loading'
          ? stats.activeFeats.includes('robin') && w.category === 'thrown'
            ? 'Ładowanie: Interakcja (Robin Hood).'
            : 'Ładowanie: Akcja lub Akcja Bonusowa.'
          : w.system === 'internal'
            ? stats.activeFeats.includes('fingers')
              ? 'Ładowanie wewnętrzne: 1 nabój / Akcję Bonusową.'
              : 'Ładowanie wewnętrzne: 1 nabój / Akcję.'
            : w.system === 'detachable'
              ? stats.activeFeats.includes('fingers')
                ? 'Wymiana magazynka: Akcja Bonusowa.'
                : 'Wymiana magazynka: Akcja.'
              : ''}
        {stats.activeFeats.includes('fingers')
          ? ' Szybkie palce: ignorujesz przeładowanie mechanizmu.'
          : ''}{' '}
        {w.cycle ? 'Przeładowanie mechanizmu jest odrębną czynnością.' : ''}
      </p>
    </div>
  );
}
function EntryEditor({
  editor,
  inv,
  onChange,
  onPreview,
  onCancel,
}: {
  editor: Editor;
  inv: Inventory;
  onChange: (e: Editor) => void;
  onPreview: (a: InventoryAction, s: string) => void;
  onCancel: () => void;
}) {
  const e = editor.entry;
  const patch = (p: Partial<InventoryEntry>) => {
    const next = { ...e, ...p };
    if (next.slot !== 'none' && !allowedSlots(next).includes(next.slot)) {
      next.slot = 'none';
      next.location = 'backpack';
      next.parentId = null;
    }
    onChange({ ...editor, entry: next });
  };
  const installedIn = inv.entries.find((w) => w.installedMagazineId === e.id);
  const placement = e.slot === 'none' ? e.location : e.slot;
  const slotOptions = availableSlotOptions(inv, e);
  function choosePlacement(value: string) {
    if (value === 'backpack' || value === 'external')
      patch({ slot: 'none', location: value, parentId: null });
    else
      patch({
        slot: value as InventoryEntry['slot'],
        location: isHandySlot(value as InventoryEntry['slot'])
          ? 'handy'
          : 'body',
        parentId: null,
      });
  }
  const item = (p: Partial<InventoryEntry['item']>) =>
    patch({ item: { ...e.item, ...p } });
  function submit() {
    const number = (s: string, scale: number) => {
      if (!/^\d+(?:[.,]\d+)?$/.test(s)) return NaN;
      const n = Number(s.replace(',', '.')) * scale;
      return Math.floor(n + 1e-7);
    };
    const entry = {
      ...e,
      quantityMilli: number(editor.quantity, 1000),
      weightMg: weightlessAmmo(e)
        ? null
        : fixedWeaponWeight(e.item) !== null
          ? Math.round(fixedWeaponWeight(e.item)! * 1_000_000)
          : editor.weight === ''
            ? null
            : number(editor.weight, 1_000_000),
      weightReason:
        fixedWeaponWeight(e.item) !== null
          ? 'Masa z podręcznika'
          : e.weightReason || 'Masa wpisana przez gracza',
      paidMilli: editor.paid === '' ? null : number(editor.paid, 1000),
    };
    onPreview(
      { kind: 'edit', entry, reason: editor.reason },
      `Zapisz ${itemDisplayName(entry.item)}: ${editor.quantity} ${entry.unit}, ${weightlessAmmo(e) ? '' : (editor.weight || 'nieznana') + ' kg na jednostkę.'} ${entry.slot === 'none' ? PLACES[entry.location] : SLOTS[entry.slot]}. `,
    );
  }
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        submit();
      }}
    >
      <h2>
        {inv.entries.some((x) => x.id === e.id)
          ? 'Edytuj przedmiot'
          : 'Dodaj przedmiot'}
      </h2>
      <div className="inventory-fields">
        <label>
          Nazwa
          <input
            required
            maxLength={300}
            value={itemDisplayName(e.item)}
            onChange={(x) => item({ name: x.target.value })}
          />
        </label>
        <label>
          Typ
          <select
            value={e.item.type}
            onChange={(x) =>
              item({ type: x.target.value as InventoryEntry['item']['type'] })
            }
          >
            {Object.entries(ITEM_TYPES).map(([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Ilość
          <input
            required
            inputMode="decimal"
            id="inventory-field-quantityMilli"
            value={editor.quantity}
            onChange={(x) => onChange({ ...editor, quantity: x.target.value })}
          />
        </label>
        <label>
          Jednostka
          <input
            required
            value={e.unit}
            onChange={(x) => patch({ unit: x.target.value })}
          />
        </label>
        {!weightlessAmmo(e) && (
          <label>
            {fixedWeaponWeight(e.item) !== null
              ? 'Masa z podręcznika (kg)'
              : 'Masa jednostki (kg, puste = nieznana)'}
            <input
              autoFocus={inventoryWeight(e) === null}
              inputMode="decimal"
              id="inventory-field-weightMg"
              readOnly={fixedWeaponWeight(e.item) !== null}
              value={editor.weight}
              onChange={(x) => onChange({ ...editor, weight: x.target.value })}
            />
          </label>
        )}
        {installedIn ? (
          <p className="inventory-installed-place">
            Miejsce: w broni {installedIn.item.name}
          </p>
        ) : (
          <label>
            Miejsce w ekwipunku
            <select
              value={placement}
              onChange={(event) => choosePlacement(event.target.value)}
            >
              <optgroup label="Przechowywanie">
                <option value="backpack">Plecak</option>
                <option value="external">Juki / przechowywane</option>
                {e.slot === 'none' &&
                  ['body', 'handy'].includes(e.location) && (
                    <option value={e.location}>
                      {PLACES[e.location]} — dotychczasowe miejsce
                    </option>
                  )}
              </optgroup>
              {slotOptions.length > 0 && (
                <optgroup label="Sloty na karcie">
                  {slotOptions.map(({ slot, label, occupiedBy }) => (
                    <option key={slot} value={slot} disabled={!!occupiedBy}>
                      {label}
                      {occupiedBy ? ` — zajęte: ${occupiedBy}` : ''}
                    </option>
                  ))}
                </optgroup>
              )}
            </select>
          </label>
        )}
        {!installedIn && e.slot === 'none' && (
          <label>
            W pojemniku
            <select
              value={e.parentId ?? ''}
              onChange={(event) => {
                const parent = inv.entries.find(
                  (entry) => entry.id === event.target.value,
                );
                patch({
                  parentId: parent?.id ?? null,
                  ...(parent ? { location: effectivePlace(inv, parent) } : {}),
                });
              }}
            >
              <option value="">Poza pojemnikiem</option>
              {inv.entries
                .filter(
                  (entry) =>
                    entry.container &&
                    entry.id !== e.id &&
                    ['backpack', 'external'].includes(
                      effectivePlace(inv, entry),
                    ),
                )
                .map((entry) => (
                  <option key={entry.id} value={entry.id}>
                    {itemDisplayName(entry.item)}
                  </option>
                ))}
            </select>
          </label>
        )}
        <label>
          Pojemnik
          <select
            value={e.container ? 'yes' : 'no'}
            onChange={(x) =>
              patch({ container: x.target.value === 'yes', massMode: 'unit' })
            }
          >
            <option value="no">Nie</option>
            <option value="yes">Tak</option>
          </select>
        </label>
        {e.container && (
          <label>
            Sposób liczenia masy
            <select
              value={e.massMode}
              onChange={(x) =>
                patch({
                  massMode: x.target.value as InventoryEntry['massMode'],
                })
              }
            >
              <option value="unit">Masa pustego pojemnika + składniki</option>
              <option value="aggregate">
                Masa całego zestawu, zawartość już wliczona
              </option>
            </select>
          </label>
        )}
      </div>
      <label>
        Opis / zawartość
        <textarea
          value={e.item.description}
          onChange={(x) => item({ description: x.target.value })}
        />
      </label>
      <label>
        Notatki
        <textarea
          maxLength={10000}
          value={e.notes}
          onChange={(x) => patch({ notes: x.target.value })}
        />
      </label>
      <details>
        <summary>Bazowa wycena i źródło przedmiotu</summary>
        <div className="inventory-fields">
          {(['basePrice', 'baseAvailability'] as const).map((k) => (
            <div key={k}>
              <p>
                {k === 'basePrice'
                  ? 'Cena bazowa (G)'
                  : 'Dostępność bazowa (%)'}
              </p>
              {(['min', 'max'] as const).map((end) => (
                <label key={end}>
                  {end === 'min' ? 'Od' : 'Do'}
                  <input
                    type="number"
                    min={0}
                    max={k === 'baseAvailability' ? 100 : 1000000000}
                    step="any"
                    value={e.item[k]?.[end] ?? ''}
                    onChange={(x) =>
                      item({
                        [k]:
                          x.target.value === ''
                            ? null
                            : {
                                ...(e.item[k] ?? {
                                  min: Number(x.target.value),
                                  max: Number(x.target.value),
                                }),
                                [end]: Number(x.target.value),
                              },
                      })
                    }
                  />
                </label>
              ))}
            </div>
          ))}
          <label>
            Kategoria ekonomiczna
            <select
              value={e.item.economicCategory}
              onChange={(x) => item({ economicCategory: x.target.value })}
            >
              <option value="">N/D</option>
              {[
                ...new Set(
                  Object.values(rules.regions).flatMap((r) =>
                    Object.keys(r.priceMultipliers),
                  ),
                ),
              ].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <label>
            Źródło
            <input
              value={e.item.source ?? ''}
              onChange={(x) => item({ source: x.target.value })}
            />
          </label>
          <label>
            Środek leczący w handlu Chromu
            <input
              type="checkbox"
              checked={e.item.category === 'Prochy i używki / Środki lecznicze'}
              onChange={(x) =>
                item({
                  category: x.target.checked
                    ? 'Prochy i używki / Środki lecznicze'
                    : 'Własne',
                })
              }
            />
          </label>
        </div>
      </details>
      {e.item.type === 'armor' && !e.armor && (
        <button
          type="button"
          onClick={() =>
            patch({
              armor: {
                kind: 'light',
                base: 10,
                dexCap: null,
                strength: 0,
                penalty: 'none',
                threshold: 0,
                source: 'Własny profil MG',
              },
            })
          }
        >
          Uzupełnij własny profil pancerza
        </button>
      )}
      {e.item.type === 'ammunition' && !e.magazine && !e.caliber && (
        <button
          type="button"
          onClick={() =>
            patch({
              magazine: {
                capacity: 1,
                caliber: '9 mm',
                model: 'własny',
                rounds: [],
              },
            })
          }
        >
          To jest pusty magazynek
        </button>
      )}
      {e.magazine && !e.weapon && (
        <details open>
          <summary>Dane magazynka</summary>
          <label>
            Dopasuj do modelu posiadanej broni
            <select
              value={
                inv.entries.find((w) => w.weapon?.model === e.magazine!.model)
                  ?.id ?? ''
              }
              onChange={(x) => {
                const w = inv.entries.find(
                  (w) => w.id === x.target.value,
                )?.weapon;
                if (w)
                  patch({
                    magazine: {
                      ...e.magazine!,
                      model: w.model,
                      caliber: w.caliber,
                      capacity: w.capacity,
                    },
                  });
              }}
            >
              <option value="">Własny model</option>
              {inv.entries
                .filter((w) => w.weapon?.system === 'detachable')
                .map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.item.name}
                  </option>
                ))}
            </select>
          </label>
          <div className="inventory-fields">
            <label>
              Model
              <input
                value={e.magazine.model}
                onChange={(x) =>
                  patch({ magazine: { ...e.magazine!, model: x.target.value } })
                }
              />
            </label>
            <label>
              Kaliber
              <input
                value={e.magazine.caliber}
                onChange={(x) =>
                  patch({
                    magazine: { ...e.magazine!, caliber: x.target.value },
                  })
                }
              />
            </label>
            <label>
              Pojemność
              <input
                type="number"
                min={1}
                max={10000}
                value={e.magazine.capacity}
                onChange={(x) =>
                  patch({
                    magazine: {
                      ...e.magazine!,
                      capacity: Number(x.target.value),
                    },
                  })
                }
              />
            </label>
          </div>
        </details>
      )}
      {e.item.type === 'ammunition' && !e.magazine && (
        <label>
          Kaliber zapasu (puste = zwykły przedmiot)
          <input
            value={e.caliber}
            onChange={(x) => patch({ caliber: x.target.value })}
          />
        </label>
      )}
      {(e.weapon || e.magazine) && (
        <p className="bg-small">
          Masa dotyczy pustej broni lub pustego magazynka.
        </p>
      )}
      {e.item.type === 'weapon' && !e.weapon && (
        <button
          type="button"
          onClick={() =>
            patch({
              weapon: {
                category: 'short',
                model: e.id,
                caliber: '9 mm',
                system: 'detachable',
                capacity: 15,
                modes: ['single'],
                cycle: false,
                twoHanded: false,
                handy: false,
                source: 'Własny profil MG',
              },
              item: {
                ...e.item,
                weaponProfile: {
                  attackKind: 'ranged',
                  abilityRule: 'dex',
                  attackModifier: 0,
                  range: { normal: null, long: null, unit: 'm' },
                  damageModes: [
                    {
                      id: '0',
                      label: 'Podstawowe',
                      dice: '1k6',
                      average: null,
                      damageType: 'kłute',
                      condition: null,
                    },
                  ],
                  properties: [],
                  fireModes: [],
                  ammoVariants: [],
                },
              },
            })
          }
        >
          Uzupełnij własny profil broni
        </button>
      )}
      {e.weapon && (
        <details>
          <summary>Profil broni</summary>
          <div className="inventory-fields">
            <label>
              Kategoria
              <select
                value={e.weapon.category}
                onChange={(x) =>
                  patch({
                    weapon: {
                      ...e.weapon!,
                      category: x.target.value as NonNullable<
                        InventoryEntry['weapon']
                      >['category'],
                      family:
                        (['revolver', 'smg'].includes(e.weapon!.family ?? '') &&
                          x.target.value !== 'short') ||
                        (e.weapon!.family === 'axe' &&
                          !['melee', 'thrown'].includes(x.target.value))
                          ? undefined
                          : e.weapon!.family,
                    },
                  })
                }
              >
                {Object.entries(weaponNames).map(([id, name]) => (
                  <option key={id} value={id}>
                    {name}
                  </option>
                ))}
                <option value="improvised">Improwizowana</option>
              </select>
            </label>
            <label>
              Rodzaj modelu dla zdolności
              <select
                value={e.weapon.family ?? ''}
                onChange={(x) =>
                  patch({
                    weapon: {
                      ...e.weapon!,
                      ...(x.target.value
                        ? {
                            family: x.target.value as
                              'revolver' | 'smg' | 'axe',
                          }
                        : { family: undefined }),
                    },
                  })
                }
              >
                <option value="">
                  Z danych katalogu / bez specjalnego rodzaju
                </option>
                {e.weapon.category === 'short' && (
                  <option value="revolver">Rewolwer</option>
                )}
                {e.weapon.category === 'short' && (
                  <option value="smg">Pistolet maszynowy</option>
                )}
                {['melee', 'thrown'].includes(e.weapon.category) && (
                  <option value="axe">Siekierka</option>
                )}
              </select>
              <small>
                Wybierz dla własnego modelu, jeśli zdolność odnosi się do
                rewolweru, PM lub siekierki.
              </small>
            </label>
            <label>
              Kaliber
              <input
                value={e.weapon.caliber}
                onChange={(x) =>
                  patch({
                    weapon: { ...e.weapon!, caliber: x.target.value },
                    ...(e.magazine
                      ? { magazine: { ...e.magazine, caliber: x.target.value } }
                      : {}),
                  })
                }
              />
            </label>
            <label>
              Pojemność
              <input
                type="number"
                min={0}
                max={10000}
                value={e.weapon.capacity}
                onChange={(x) =>
                  patch({
                    weapon: { ...e.weapon!, capacity: Number(x.target.value) },
                    ...(e.magazine
                      ? {
                          magazine: {
                            ...e.magazine,
                            capacity: Number(x.target.value),
                          },
                        }
                      : {}),
                  })
                }
              />
            </label>
            <label>
              System
              <select
                value={e.weapon.system}
                onChange={(x) => {
                  const system = x.target.value as NonNullable<
                    InventoryEntry['weapon']
                  >['system'];
                  patch({
                    weapon: { ...e.weapon!, system },
                    magazine: ['internal', 'loading'].includes(system)
                      ? {
                          capacity: e.weapon!.capacity || 1,
                          caliber: e.weapon!.caliber,
                          model: e.weapon!.model,
                          rounds: e.magazine?.rounds ?? [],
                        }
                      : null,
                  });
                }}
              >
                {Object.entries({
                  none: 'Bez amunicji',
                  detachable: 'Wymienny magazynek',
                  internal: 'Wewnętrzny',
                  loading: 'Ładowanie',
                  singleUse: 'Jednorazowa',
                }).map(([id, name]) => (
                  <option key={id} value={id}>
                    {name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Źródło profilu
              <input
                value={e.weapon.source}
                onChange={(x) =>
                  patch({ weapon: { ...e.weapon!, source: x.target.value } })
                }
              />
            </label>
          </div>
          {(['cycle', 'twoHanded', 'handy'] as const).map((k, index) => (
            <label key={k}>
              <input
                type="checkbox"
                checked={e.weapon![k]}
                onChange={(x) =>
                  patch({ weapon: { ...e.weapon!, [k]: x.target.checked } })
                }
              />
              {
                [
                  'Wymaga przeładowania mechanizmu',
                  'Wymaga obu rąk',
                  'Poręczna',
                ][index]
              }
            </label>
          ))}
          <div className="inventory-heading">
            {Object.entries(modes).map(([id, label]) => (
              <label key={id}>
                <input
                  type="checkbox"
                  checked={e.weapon!.modes.includes(id as FireMode)}
                  onChange={(x) =>
                    patch({
                      weapon: {
                        ...e.weapon!,
                        modes: x.target.checked
                          ? [...e.weapon!.modes, id as FireMode]
                          : e.weapon!.modes.filter((m) => m !== id),
                      },
                    })
                  }
                />
                {label}
              </label>
            ))}
          </div>
          {e.item.weaponProfile && (
            <>
              <label>
                Cecha ataku
                <select
                  value={e.item.weaponProfile.abilityRule}
                  onChange={(x) =>
                    item({
                      weaponProfile: {
                        ...e.item.weaponProfile!,
                        abilityRule: x.target.value as
                          'str' | 'dex' | 'finesse',
                      },
                    })
                  }
                >
                  <option value="str">Siła</option>
                  <option value="dex">Zręczność</option>
                  <option value="finesse">
                    Finezyjna — wybór Siła / Zręczność
                  </option>
                </select>
              </label>
              {e.item.weaponProfile.damageModes.map((d, index) => (
                <label key={d.id}>
                  {d.label} — bazowe kości obrażeń
                  <input
                    value={d.dice}
                    onChange={(x) =>
                      item({
                        weaponProfile: {
                          ...e.item.weaponProfile!,
                          damageModes: e.item.weaponProfile!.damageModes.map(
                            (m, j) =>
                              j === index ? { ...m, dice: x.target.value } : m,
                          ),
                        },
                      })
                    }
                  />
                </label>
              ))}
            </>
          )}
        </details>
      )}
      {e.armor && (
        <details>
          <summary>Profil pancerza</summary>
          <div className="inventory-fields">
            <label>
              Rodzaj
              <select
                value={e.armor.kind}
                onChange={(x) =>
                  patch({
                    armor: {
                      ...e.armor!,
                      kind: x.target.value as NonNullable<
                        InventoryEntry['armor']
                      >['kind'],
                    },
                  })
                }
              >
                {Object.entries({
                  light: 'Lekki',
                  medium: 'Średni',
                  heavy: 'Ciężki',
                  helmet: 'Hełm',
                  arms: 'Ochraniacze rąk',
                  legs: 'Ochraniacze nóg',
                  shield: 'Tarcza',
                }).map(([id, name]) => (
                  <option key={id} value={id}>
                    {name}
                  </option>
                ))}
              </select>
            </label>
            {(['base', 'strength', 'threshold'] as const).map((k) => (
              <label key={k}>
                {
                  {
                    base: 'Baza TT / premia akcesorium',
                    strength: 'Wymagana Siła',
                    threshold: 'Próg obrażeń',
                  }[k]
                }
                <input
                  type="number"
                  min={0}
                  max={k === 'strength' ? 30 : 100}
                  value={e.armor![k]}
                  onChange={(x) =>
                    patch({
                      armor: { ...e.armor!, [k]: Number(x.target.value) },
                    })
                  }
                />
              </label>
            ))}
            <label>
              Maksymalny modyfikator Zręczności (puste = bez limitu)
              <input
                type="number"
                min={0}
                max={30}
                value={e.armor.dexCap ?? ''}
                onChange={(x) =>
                  patch({
                    armor: {
                      ...e.armor!,
                      dexCap:
                        x.target.value === '' ? null : Number(x.target.value),
                    },
                  })
                }
              />
            </label>
            <label>
              Kary pancerza
              <select
                value={e.armor.penalty}
                onChange={(x) =>
                  patch({
                    armor: {
                      ...e.armor!,
                      penalty: x.target.value as NonNullable<
                        InventoryEntry['armor']
                      >['penalty'],
                    },
                  })
                }
              >
                <option value="none">Brak</option>
                <option value="disadvantage">
                  Utrudnienie skradania i pływania
                </option>
                <option value="impossible">
                  Utrudnienie skradania, pływanie niemożliwe
                </option>
              </select>
            </label>
            <label>
              Źródło profilu
              <input
                value={e.armor.source}
                onChange={(x) =>
                  patch({ armor: { ...e.armor!, source: x.target.value } })
                }
              />
            </label>
          </div>
          <label>
            Obniżenie TT przez zużycie
            <input
              type="number"
              min={0}
              max={100}
              value={e.armorDamage}
              onChange={(x) => patch({ armorDamage: Number(x.target.value) })}
            />
          </label>
        </details>
      )}
      <div className="inventory-heading">
        <button type="submit">Sprawdź i zapisz</button>
        <button type="button" onClick={onCancel}>
          Anuluj
        </button>
        {inv.entries.some((x) => x.id === e.id) && (
          <button
            type="button"
            onClick={() =>
              onPreview(
                { kind: 'remove', entryId: e.id, reason: editor.reason },
                `Usuń ${itemDisplayName(e.item)} z inwentarza. `,
              )
            }
          >
            Usuń przedmiot
          </button>
        )}
      </div>
    </form>
  );
}
