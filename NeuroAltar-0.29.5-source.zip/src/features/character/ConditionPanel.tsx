import {
  HeartPulse,
  Footprints,
  Zap,
  ShieldOff,
  Minus,
  Plus,
} from 'lucide-react';
import { characterInjurySteps } from '../../domain/character/conditionEffects';
import { characterCombatValues } from '../../domain/character/participation';
import { useParticipationStore } from '../../stores/participationStore';
import { useCombatStore } from '../../stores/combatStore';
import { useDiceStore } from '../../stores/diceStore';
import { useEffect, useRef } from 'react';
import { create } from 'zustand';
import { ZodError } from 'zod';
import { useCharacterStore } from '../../stores/characterStore';
import type { Character } from '../../domain/character/model';
import { abilityNames } from '../../domain/character/model';
import {
  conditionView,
  previewCondition,
  restDuration,
  ConditionError,
} from '../../domain/character/condition';
import {
  type ConditionAction,
  type RestInput,
  exhaustionNames,
  exhaustionCauses,
} from '../../domain/character/conditionModel';
import './condition.css';
type Mode =
  | 'combatHealth'
  | 'health'
  | 'effect'
  | 'exhaustion'
  | 'exhaustionReduce'
  | 'block'
  | 'remove'
  | 'rest'
  | 'cancel'
  | 'fuks'
  | 'session'
  | 'world';
type DialogState = {
  owner: string | null;
  mode: Mode | null;
  fields: Record<string, string>;
  preview: {
    action: ConditionAction;
    revision: number;
    lines: string[];
  } | null;
  error: string | null;
  set: (p: Partial<Omit<DialogState, 'set'>>) => void;
};
const useConditionDialog = create<DialogState>((set) => ({
  owner: null,
  mode: null,
  fields: {},
  preview: null,
  error: null,
  set,
}));
function Modal({
  children,
  onCancel,
}: {
  children: React.ReactNode;
  onCancel: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    ref.current?.showModal();
    const d = ref.current;
    return () => d?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      className="bg-dialog condition-dialog"
      onCancel={(e) => {
        e.preventDefault();
        onCancel();
      }}
    >
      {children}
    </dialog>
  );
}
export function ConditionPanel({ record }: { record: Character }) {
  const store = useCharacterStore(),
    dialog = useConditionDialog(),
    v = conditionView(record),
    s = v.state,
    effects = v.consequences,
    combatValues = characterCombatValues(record);
  const participation = useParticipationStore((state) =>
    state.entries.find(
      (p) => p.characterId === record.id && p.state === 'active',
    ),
  );
  const currentActor = useCombatStore(
    (state) =>
      state.slots.find(
        (slot) => slot.encounterId === participation?.encounterId,
      )?.currentTurnActorId,
  );
  const healthTurnBlocked = (kind: string) =>
    Boolean(
      participation &&
      (currentActor !== participation.actorId ||
        participation.usedRound.includes('turn:' + kind)),
    );
  const disabled =
      !record.sheet || !!record.draft || record.archived || store.locked,
    owned = dialog.owner === record.id;
  const marker = record.id + ':condition-dialog',
    f = dialog.fields;
  const set = (key: string, value: string) =>
    dialog.set({
      fields: {
        ...f,
        ...(key === 'outcome'
          ? {
              rolls6: '',
              rolls8: '',
              kolejkaRolls: '',
              kolejkaLevel: '0',
              healingSave: '',
            }
          : {}),
        [key]: value,
      },
      preview: null,
      error: null,
    });
  const close = () => {
    if (store.locked) return;
    store.invalidInput(marker, null);
    dialog.set({ owner: null, mode: null, preview: null, error: null });
  };
  function open(mode: Mode, fields: Record<string, string> = {}) {
    store.invalidInput(marker, 'Dokończ formularz zdrowia lub odpoczynku.');
    dialog.set({ owner: record.id, mode, fields, error: null, preview: null });
  }
  function fail(e: unknown) {
    let field = '';
    let message = String(e);
    if (e instanceof ConditionError) {
      field = e.field;
      message = e.message;
    }
    if (e instanceof ZodError) {
      field = String(e.issues[0]?.path[0] ?? '');
      message =
        'Sprawdź pole ' +
        (labels[field] ?? field) +
        ': wartość poza zakresem lub brak wymaganych danych.';
    }
    dialog.set({ error: message });
    setTimeout(() => {
      const input = document.getElementById('condition-' + field);
      input?.focus();
      input?.scrollIntoView({ block: 'center' });
    }, 0);
  }
  function preview(action: ConditionAction) {
    try {
      const result = previewCondition(record, action, crypto.randomUUID());
      const after = conditionView({ ...record, condition: result.state });
      const lines = [
        ...result.lines,
        'PW: ' + s.hp + ' → ' + after.state.hp + ' / ' + after.max,
        'Dostępne KW: k6 ' +
          Math.max(0, v.derived.hitDice[6] - after.state.hitDiceSpent[6]) +
          ', k8 ' +
          Math.max(0, v.derived.hitDice[8] - after.state.hitDiceSpent[8]),
      ];
      for (const res of after.resources) {
        const before = Math.max(
            0,
            (v.resources.find((r) => r.id === res.id)?.max ?? 0) -
              (s.spent[res.id] ?? 0),
          ),
          next = Math.max(0, res.max - (after.state.spent[res.id] ?? 0));
        if (before !== next)
          lines.push(res.label + ': ' + before + ' → ' + next);
      }
      lines.push(
        'Zranienia: ' + s.injury + ' → ' + after.state.injury,
        'Wyczerpanie: ' + v.exhaustion + ' → ' + after.exhaustion,
      );
      store.invalidInput(marker, 'Potwierdź lub anuluj podgląd.');
      dialog.set({
        owner: record.id,
        preview: { action, revision: record.revision, lines },
        error: null,
      });
    } catch (e) {
      fail(e);
    }
  }
  function number(key: string, min = 0, max = 100000) {
    const raw = f[key]?.trim() ?? '';
    if (!/^[-+]?\d+$/.test(raw) || Number(raw) < min || Number(raw) > max)
      throw new ConditionError(
        key,
        'Pole „' +
          (labels[key] ?? key) +
          '”: wpisz liczbę całkowitą od ' +
          min +
          ' do ' +
          max +
          '.',
      );
    return Number(raw);
  }
  function rolls(key: string, sides: number) {
    if (!f[key]?.trim()) return [];
    return f[key]!.trim()
      .split(/[ ,;]+/)
      .map((x) => {
        if (!/^\d+$/.test(x) || Number(x) < 1 || Number(x) > sides)
          throw new ConditionError(
            key,
            'Wyniki k' +
              sides +
              ': podaj liczby od 1 do ' +
              sides +
              ', oddzielone spacją.',
          );
        return Number(x);
      });
  }
  function submit() {
    try {
      const reason = f.reason ?? '',
        id = f.id ?? crypto.randomUUID();
      let action: ConditionAction;
      switch (dialog.mode) {
        case 'combatHealth':
          action = {
            type: 'combatHealth',
            command:
              f.kind === 'damage'
                ? {
                    kind: 'damage',
                    amount: number('amount'),
                    critical: f.critical === 'yes',
                    melee: f.melee === 'yes',
                  }
                : f.kind === 'healing'
                  ? { kind: 'healing', amount: number('amount') }
                  : { kind: 'deathSave', face: number('face', 1, 20) },
          };
          break;
        case 'health':
          action = {
            type: 'correct',
            hp: number('hp'),
            injury: number('injury', 0, 5),
            hitDiceSpent: { 6: number('spent6'), 8: number('spent8') },
            reason: 'Zmiana zdrowia',
          };
          break;
        case 'effect':
          action = {
            type: 'effect',
            entry: {
              id,
              source: f.source ?? '',
              target: (f.target ?? 'hpMax') as 'hpMax',
              amount: number('amount'),
              refresh: f.refresh === 'long' ? 'long' : 'manual',
            },
          };
          break;
        case 'exhaustion':
          action = {
            type: 'exhaustion',
            entry: {
              id,
              source:
                f.source?.trim() ||
                exhaustionNames[(f.cause ?? 'ordinary') as 'ordinary'],
              cause: (f.cause ?? 'ordinary') as 'ordinary',
              level: number('level', 1, 6),
            },
          };
          break;
        case 'exhaustionReduce':
          action = { type: 'exhaustionReduce', id: f.exhaustionId ?? '' };
          break;
        case 'block':
          action = { type: 'block', id, source: f.source ?? '' };
          break;
        case 'remove':
          action = { type: 'remove', group: f.group as 'effects', id, reason };
          break;
        case 'cancel':
          action = { type: 'restCancel', reason };
          break;
        case 'rest': {
          if (!s.rest)
            throw new ConditionError('rest', 'Nie ma rozpoczętego odpoczynku.');
          action = {
            type: 'restApply',
            sessionId: s.rest.id,
            outcome: f.outcome === 'interrupt' ? 'interrupt' : 'complete',
            elapsed: number('elapsed'),
            sleep: f.outcome === 'interrupt' ? 0 : number('sleep'),
            armored: f.armored === 'yes',
            consecutive: f.consecutive === 'yes',
            food: f.food === 'yes',
            water: f.water === 'yes',
            warm: f.warm === 'yes',
            exhaustionId: f.exhaustionId || null,
            medicProficient: f.medicProficient === 'yes',
            medicTools: f.medicTools === 'yes',
            healingSave: f.healingSave?.trim()
              ? number('healingSave', -100, 100)
              : null,
            rolls6: rolls('rolls6', 6),
            rolls8: rolls('rolls8', 8),
            kolejkaLevel: number('kolejkaLevel', 0, 12),
            kolejkaRolls: rolls('kolejkaRolls', 8),
          } satisfies RestInput;
          break;
        }
        case 'fuks':
          action = {
            type: 'fuksGrant',
            entry: {
              id,
              source: f.source ?? '',
              kind: (f.kind ?? 'manual') as 'manual',
              expiresAt: ['song', 'meal'].includes(f.kind ?? '')
                ? s.worldMinutes + 1440
                : null,
              session: null,
            },
          };
          break;
        case 'session':
          action = { type: 'session', id: f.session ?? '' };
          break;
        case 'world':
          action = { type: 'worldTime', minutes: number('minutes', 1) };
          break;
        default:
          return;
      }
      if (dialog.mode === 'exhaustion' || dialog.mode === 'exhaustionReduce') {
        store.invalidInput(marker, null);
        void changeCondition(action).then((ok) => {
          if (ok) close();
        });
      } else preview(action);
    } catch (e) {
      fail(e);
    }
  }
  async function changeCondition(action: ConditionAction) {
    const ok = await store.mutateCondition(action, record.revision);
    if (!ok)
      dialog.set({
        error: useCharacterStore.getState().error ?? 'Nie zapisano zmian.',
      });
    return ok;
  }
  const changeInjury = (amount: number) =>
    changeCondition({
      type: 'correct',
      hp: s.hp,
      injury: s.injury + amount,
      hitDiceSpent: s.hitDiceSpent,
      reason: 'Zmiana stopnia Zranienia',
    });
  async function confirm() {
    const p = dialog.preview;
    if (!p) return;
    if (record.revision !== p.revision) {
      dialog.set({
        error: 'Karta zmieniła się od podglądu. Oblicz podgląd ponownie.',
        preview: null,
      });
      return;
    }
    store.invalidInput(marker, null);
    const ok = await store.mutateCondition(p.action, p.revision);
    if (ok) close();
    else {
      store.invalidInput(marker, 'Nierozstrzygnięty zapis zdrowia.');
      dialog.set({
        error: useCharacterStore.getState().error ?? 'Nie zapisano zmian.',
      });
    }
  }
  const input = (
    key: string,
    label: string = labels[key] ?? key,
    placeholder = '',
  ) => (
    <label key={key}>
      {label}
      <input
        id={'condition-' + key}
        value={f[key] ?? ''}
        onChange={(e) => set(key, e.target.value)}
        placeholder={placeholder}
      />
    </label>
  );
  const select = (
    key: string,
    label: string,
    values: Record<string, string>,
  ) => (
    <label>
      {label}
      <select
        id={'condition-' + key}
        value={f[key] ?? ''}
        onChange={(e) => set(key, e.target.value)}
      >
        {Object.entries(values).map(([value, text]) => (
          <option key={value} value={value}>
            {text}
          </option>
        ))}
      </select>
    </label>
  );
  const check = (key: string, label: string) => (
    <label className="bg-inline">
      <input
        type="checkbox"
        checked={f[key] === 'yes'}
        onChange={(e) => set(key, e.target.checked ? 'yes' : 'no')}
      />
      {label}
    </label>
  );
  return (
    <section
      className="bg-section condition-panel condition-panel--health"
      id="character-condition"
    >
      <header>
        <h2>Zdrowie i odpoczynek</h2>
        <p>Neuroshima: Ostatnia Era, s. 45–46, 67–105, 115, 201–203.</p>
      </header>
      {!!record.draft && (
        <p>Zatwierdź rozwój postaci, aby rozliczać zdrowie i odpoczynek.</p>
      )}
      <dl className="condition-summary">
        <div
          className={
            s.hp === 0 ? 'condition-stat is-warning' : 'condition-stat'
          }
        >
          <dt>Punkty Wytrzymałości</dt>
          <dd>
            {s.hp}
            <small> / {v.max} PW</small>
          </dd>
        </div>
        <div
          className={
            s.injury > 0 ? 'condition-stat is-warning' : 'condition-stat'
          }
        >
          <dt>Zranienia</dt>
          <dd>
            {s.injury}
            <small> / 5 · {effects.injuryLabel}</small>
          </dd>
          <div className="condition-step-controls">
            <button
              disabled={disabled || s.injury === 0}
              aria-label="Zmniejsz Zranienia o 1"
              onClick={() => void changeInjury(-1)}
            >
              <Minus size={16} aria-hidden="true" /> −1
            </button>
            <button
              disabled={disabled || s.injury === 5}
              aria-label="Zwiększ Zranienia o 1"
              onClick={() => void changeInjury(1)}
            >
              <Plus size={16} aria-hidden="true" /> +1
            </button>
          </div>
        </div>
        <div
          className={
            v.exhaustion > 0 ? 'condition-stat is-warning' : 'condition-stat'
          }
        >
          <dt>Wyczerpanie</dt>
          <dd>
            {v.exhaustion}
            <small> / 6</small>
          </dd>
          <div className="condition-step-controls">
            <button
              disabled={disabled || v.exhaustion === 0}
              aria-label="Zmniejsz Wyczerpanie o 1"
              onClick={() => {
                if (s.exhaustion.length === 1)
                  void changeCondition({
                    type: 'exhaustionReduce',
                    id: s.exhaustion[0]!.id,
                  });
                else
                  open('exhaustionReduce', {
                    exhaustionId: s.exhaustion[0]?.id ?? '',
                  });
              }}
            >
              <Minus size={16} aria-hidden="true" /> −1
            </button>
            <button
              disabled={disabled || v.exhaustion >= 6}
              aria-label="Dodaj Wyczerpanie"
              onClick={() =>
                open('exhaustion', { cause: 'ordinary', level: '1' })
              }
            >
              <Plus size={16} aria-hidden="true" /> Dodaj
            </button>
          </div>
        </div>
        <div className="condition-stat condition-stat--dice">
          <dt>Kości Wytrzymałości</dt>
          <dd>
            <span>
              {Math.max(0, v.derived.hitDice[6] - s.hitDiceSpent[6])}
              <small> / {v.derived.hitDice[6]} k6</small>
            </span>
            <span>
              {Math.max(0, v.derived.hitDice[8] - s.hitDiceSpent[8])}
              <small> / {v.derived.hitDice[8]} k8</small>
            </span>
          </dd>
        </div>
      </dl>
      <section
        className="condition-group condition-health"
        aria-label="Rozliczanie zdrowia"
      >
        <div className="condition-group-heading">
          <h3>Rozlicz zdrowie</h3>
          <button
            disabled={disabled}
            onClick={() =>
              open('health', {
                hp: String(s.hp),
                injury: String(s.injury),
                spent6: String(s.hitDiceSpent[6]),
                spent8: String(s.hitDiceSpent[8]),
              })
            }
          >
            Ustaw PW, Zranienia i KW…
          </button>
        </div>
        <div className="condition-actions condition-health-actions">
          <button
            disabled={disabled}
            onClick={() =>
              open('combatHealth', { kind: 'damage', amount: '1' })
            }
          >
            Obrażenia…
          </button>
          <button
            disabled={disabled}
            onClick={() =>
              open('combatHealth', { kind: 'healing', amount: '1' })
            }
          >
            Leczenie…
          </button>
          <button
            disabled={
              disabled ||
              s.hp !== 0 ||
              s.combatHealth?.stable ||
              s.combatHealth?.dead ||
              healthTurnBlocked('deathSave')
            }
            onClick={() =>
              open('combatHealth', { kind: 'deathSave', face: '' })
            }
          >
            Rzut przeciw śmierci…
          </button>
          <button
            disabled={disabled || s.hp !== 0 || s.combatHealth?.dead}
            onClick={() =>
              preview({ type: 'combatHealth', command: { kind: 'stabilize' } })
            }
          >
            Stabilizacja…
          </button>
          {s.combatHealth?.bleeding && (
            <>
              <button
                disabled={
                  disabled || s.combatHealth?.dead || healthTurnBlocked('bleed')
                }
                title={
                  healthTurnBlocked('bleed')
                    ? 'Krwawienie można rozliczyć raz w swojej turze.'
                    : undefined
                }
                onClick={() =>
                  preview({ type: 'combatHealth', command: { kind: 'bleed' } })
                }
              >
                Krwawienie: rozlicz 1 PW…
              </button>
              <button
                disabled={disabled}
                onClick={() =>
                  preview({
                    type: 'combatHealth',
                    command: { kind: 'stopBleeding' },
                  })
                }
              >
                Zatrzymaj krwawienie…
              </button>
            </>
          )}
        </div>
        {s.combatHealth && (
          <p className="condition-health-status">
            RO przeciw śmierci: sukcesy {s.combatHealth.successes}, porażki{' '}
            {s.combatHealth.failures}.{' '}
            {s.combatHealth.dead
              ? 'Śmierć'
              : s.combatHealth.stable
                ? 'Stan stabilny'
                : ''}{' '}
            {s.combatHealth.bleeding ? 'Krwawienie: łącznie 1 PW na turę.' : ''}
          </p>
        )}
        <div
          className="condition-consequences"
          aria-label="Skutki Zranień i Wyczerpania"
        >
          <div className="condition-current-effects" role="status">
            <span>
              <Footprints size={18} aria-hidden="true" /> Szybkość{' '}
              <strong>
                {combatValues?.speed?.toLocaleString('pl-PL') ?? '—'} m
              </strong>
            </span>
            <span>
              <Zap size={18} aria-hidden="true" /> Testy k20{' '}
              <strong>
                {effects.testPenalty ? `−${effects.testPenalty}` : 'bez kary'}
              </strong>
            </span>
            {effects.reactionBlocked && (
              <span>
                <ShieldOff size={18} aria-hidden="true" /> Brak Reakcji
              </span>
            )}
            {effects.bonusBlocked && (
              <span>
                <Zap size={18} aria-hidden="true" /> Brak Akcji Bonusowej
              </span>
            )}
            {effects.fatal && (
              <strong className="condition-fatal">Śmierć</strong>
            )}
          </div>
          <ol
            className="condition-injury-track"
            aria-label="Kumulatywne skutki stopni Zranienia"
          >
            {characterInjurySteps.map((step) => (
              <li
                key={step.level}
                className={s.injury >= step.level ? 'is-active' : ''}
              >
                <span className="condition-injury-level">
                  <HeartPulse size={16} aria-hidden="true" /> {step.level}.{' '}
                  {step.label}
                </span>
                <span>{step.effect}</span>
              </li>
            ))}
          </ol>
          {s.injury > 0 && (
            <p>
              Zranienia zmniejszają Szybkość o 4,5 m. Skutki kolejnych stopni
              sumują się.
            </p>
          )}
          {v.exhaustion > 0 && (
            <p>
              Wyczerpanie dodatkowo zmniejsza Szybkość o{' '}
              {effects.exhaustionSpeedPenalty.toLocaleString('pl-PL')} m i każdy
              Test k20 o {effects.testPenalty}.
            </p>
          )}
          {!!s.exhaustion.length && (
            <div
              className="condition-exhaustion-sources"
              aria-label="Przyczyny Wyczerpania"
            >
              {s.exhaustion.map((entry) => (
                <div className="condition-entry" key={entry.id}>
                  <span>
                    <strong>{entry.source}</strong> ·{' '}
                    {exhaustionNames[entry.cause]} · {entry.level} poz.
                  </span>
                  <button
                    disabled={disabled}
                    aria-label={`Zmniejsz Wyczerpanie: ${entry.source}`}
                    onClick={() =>
                      void changeCondition({
                        type: 'exhaustionReduce',
                        id: entry.id,
                      })
                    }
                  >
                    −1 poziom
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
      <div className="condition-management">
        <section
          className="condition-group condition-rest"
          aria-label="Odpoczynek"
        >
          <h3>Odpoczynek</h3>
          <p>
            Krótki: {restDuration(v.sheet.rulesContext.gameColor).short / 60} h
            · Długi: {restDuration(v.sheet.rulesContext.gameColor).long / 60} h.
            Czas w świecie gry podaje MG.
          </p>
          {!s.rest ? (
            <div className="condition-actions">
              {(['short', 'long'] as const).map((kind) => (
                <button
                  key={kind}
                  disabled={disabled}
                  onClick={() =>
                    preview({
                      type: 'restStart',
                      id: crypto.randomUUID(),
                      kind,
                    })
                  }
                >
                  {kind === 'short' ? 'Rozpocznij krótki' : 'Rozpocznij długi'}
                </button>
              ))}
            </div>
          ) : (
            <>
              <p>
                Rozpoczęty {s.rest.kind === 'short' ? 'krótki' : 'długi'} ·
                przerwy: {s.rest.interruptions} · rozliczony czas:{' '}
                {s.rest.elapsed} min.
              </p>
              <div className="condition-actions">
                <button
                  disabled={disabled}
                  onClick={() =>
                    open('rest', {
                      elapsed: String(
                        restDuration(s.rest!.color)[s.rest!.kind] +
                          s.rest!.interruptions * 60,
                      ),
                      sleep: s.rest!.kind === 'long' ? '360' : '0',
                      kolejkaLevel: '0',
                      outcome: 'complete',
                      armored: record.inventory?.entries.some(
                        (e) => e.slot === 'armor',
                      )
                        ? 'yes'
                        : 'no',
                    })
                  }
                >
                  Rozlicz odpoczynek
                </button>
                <button disabled={disabled} onClick={() => open('cancel')}>
                  Zakończ bez korzyści
                </button>
              </div>
            </>
          )}
        </section>
      </div>
      <details>
        <summary>Redukcje cech i blokady odpoczynku</summary>
        <div className="condition-actions">
          <button
            disabled={disabled}
            onClick={() =>
              open('effect', {
                target: 'hpMax',
                refresh: 'manual',
                amount: '1',
              })
            }
          >
            Dodaj redukcję
          </button>
          <button disabled={disabled} onClick={() => open('block')}>
            Zablokuj korzyści odpoczynku
          </button>
        </div>
        <p>
          Choroba popromienna i szczurza gorączka po nieudanym RO blokują
          korzyści odpoczynku. Zapisz przyczynę po rozstrzygnięciu testu; usuń
          blokadę dopiero, gdy ustanie jej powód.
        </p>
        {(['effects', 'restBlocks'] as const).map((group) =>
          s[group].map((e) => (
            <div className="condition-entry" key={e.id}>
              <span>
                {e.source}
                {'target' in e
                  ? ' · ' +
                    (e.target === 'hpMax'
                      ? 'Maksymalne PW'
                      : abilityNames[e.target]) +
                    ' −' +
                    e.amount +
                    ' · ' +
                    (e.refresh === 'long'
                      ? 'Długi odpoczynek'
                      : 'Usunięcie ręczne')
                  : ''}
              </span>
              <button
                disabled={disabled}
                onClick={() => open('remove', { group, id: e.id })}
              >
                Usuń z powodem
              </button>
            </div>
          )),
        )}
      </details>
      <details>
        <summary>Fuksy ({s.fuks.length}) i czas gry</summary>
        {v.sheet.rulesContext.gameColor === 'mercury' && (
          <p>
            Rtęć: wszystkie Fuksy niedostępne. Dawne tokeny pozostają w historii
            postaci.
          </p>
        )}
        <div className="condition-actions">
          <button
            disabled={disabled || v.sheet.rulesContext.gameColor === 'mercury'}
            onClick={() => open('fuks', { kind: 'manual' })}
          >
            Przyznaj Fuksa
          </button>
          <button disabled={disabled} onClick={() => open('session')}>
            Nowa sesja
          </button>
          <button
            disabled={disabled}
            onClick={() => open('world', { minutes: '60' })}
          >
            Upływ czasu gry
          </button>
        </div>
        {s.session && (
          <button
            disabled={disabled}
            onClick={() => preview({ type: 'sessionEnd' })}
          >
            Zakończ sesję
          </button>
        )}
        <p>
          Czas gry: {s.worldMinutes} min. Sesja: {s.session ?? 'nie rozpoczęto'}
          .
        </p>
        {s.fuks.map((token) => (
          <div className="condition-entry" key={token.id}>
            <span>
              {token.source}
              {token.expiresAt !== null
                ? ' · pozostało ' + (token.expiresAt - s.worldMinutes) + ' min'
                : ''}
            </span>
            <button
              disabled={
                disabled || v.sheet.rulesContext.gameColor === 'mercury'
              }
              onClick={() => preview({ type: 'fuksUse', id: token.id })}
            >
              Zużyj Fuksa
            </button>
          </div>
        ))}
      </details>
      <details>
        <summary>Historia zdrowia i zasobów ({s.journal.length})</summary>
        <ol>
          {s.journal
            .slice(-30)
            .reverse()
            .map((e) => (
              <li key={e.id} style={{ whiteSpace: 'pre-line' }}>
                {e.text}
              </li>
            ))}
        </ol>
      </details>
      {owned && (dialog.mode || dialog.preview) && (
        <Modal onCancel={close}>
          <h2>{dialog.preview ? 'Podgląd zmian' : titles[dialog.mode!]}</h2>
          {dialog.error && <p role="alert">{dialog.error}</p>}
          {dialog.preview ? (
            <>
              <ul>
                {dialog.preview.lines.map((line, i) => (
                  <li key={i}>{line}</li>
                ))}
              </ul>
              <div className="condition-actions">
                <button disabled={store.locked} onClick={() => void confirm()}>
                  Zastosuj zmiany
                </button>
                {dialog.mode && (
                  <button
                    disabled={store.locked}
                    onClick={() => dialog.set({ preview: null })}
                  >
                    Wróć do pól
                  </button>
                )}
              </div>
            </>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit();
              }}
            >
              <div className="condition-form">
                {dialog.mode === 'combatHealth' && (
                  <>
                    {f.kind === 'deathSave' ? (
                      <>
                        {input('face', 'Naturalny wynik k20')}
                        <button
                          type="button"
                          onClick={async () => {
                            const dice = useDiceStore.getState();
                            if (
                              await dice.roll('1k20', undefined, {
                                characterId: record.id,
                                name: v.sheet.identity.name,
                                label: 'Rzut przeciw śmierci',
                              })
                            ) {
                              const last = useDiceStore.getState().history[0];
                              if (last) set('face', String(last.values[0]));
                            }
                          }}
                        >
                          Rzuć k20
                        </button>
                      </>
                    ) : (
                      input('amount', 'Liczba PW')
                    )}
                    {f.kind === 'damage' && (
                      <>
                        {check('critical', 'Trafienie krytyczne')}
                        {check('melee', 'Atak wręcz przy 0 PW')}
                      </>
                    )}
                    <p>
                      Zatwierdzenie podglądu zmieni zdrowie. Sam rzut nie
                      odejmuje PW.
                    </p>
                  </>
                )}
                {dialog.mode === 'health' && (
                  <>
                    {input('hp')}
                    {input('injury')}
                    {input('spent6')}
                    {input('spent8')}
                  </>
                )}
                {dialog.mode === 'effect' && (
                  <>
                    {input('source')}
                    {select('target', 'Obniżana wartość', {
                      hpMax: 'Maksymalne PW',
                      ...abilityNames,
                    })}
                    {input('amount')}
                    {select('refresh', 'Usunięcie', {
                      manual: 'Ręcznie — choroba lub trwały efekt',
                      long: 'Po długim odpoczynku',
                    })}
                  </>
                )}
                {dialog.mode === 'exhaustion' && (
                  <>
                    {input('source', 'Opis (opcjonalnie)')}
                    {select(
                      'cause',
                      'Przyczyna',
                      Object.fromEntries(
                        exhaustionCauses.map((x) => [x, exhaustionNames[x]]),
                      ),
                    )}
                    {input('level')}
                  </>
                )}
                {dialog.mode === 'exhaustionReduce' &&
                  select(
                    'exhaustionId',
                    'Zmniejsz wybraną przyczynę o 1 poziom',
                    Object.fromEntries(
                      s.exhaustion.map((e) => [
                        e.id,
                        `${e.source} · ${exhaustionNames[e.cause]} · ${e.level} poz.`,
                      ]),
                    ),
                  )}
                {dialog.mode === 'block' &&
                  input('source', 'Choroba / powód blokady')}
                {(dialog.mode === 'remove' || dialog.mode === 'cancel') &&
                  input('reason')}
                {dialog.mode === 'rest' && (
                  <>
                    {select('outcome', 'Wynik odpoczynku', {
                      complete: 'Ukończony',
                      interrupt: 'Przerwany (długi można kontynuować)',
                    })}
                    {input('elapsed')}
                    <p>
                      Zatwierdzenie przesunie czas gry do końca tego okresu i
                      rozliczy wygasające efekty. Czas już przesunięty ręcznie
                      nie zostanie doliczony ponownie.
                    </p>
                    {s.rest?.kind === 'long' && f.outcome !== 'interrupt' && (
                      <>
                        {input('sleep')}
                        {check('armored', 'Sen w pancerzu')}
                        {check(
                          'consecutive',
                          'Kolejny długi odpoczynek bez dnia przerwy',
                        )}
                        {check('warm', 'Odpoczynek w cieple')}
                        {check('food', 'Uzupełniona dzienna norma jedzenia')}
                        {check('water', 'Uzupełniona dzienna norma wody')}
                        {select(
                          'exhaustionId',
                          'Usuń jeden poziom Wyczerpania',
                          {
                            '': 'Nie usuwaj',
                            ...Object.fromEntries(
                              s.exhaustion.map((e) => [
                                e.id,
                                e.source + ' — ' + exhaustionNames[e.cause],
                              ]),
                            ),
                          },
                        )}
                        {check(
                          'medicProficient',
                          'Pomoc osoby biegłej w Medycynie',
                        )}
                        {check(
                          'medicTools',
                          'Pomoc z narzędziami małego medyka',
                        )}
                        {input(
                          'healingSave',
                          'Wynik końcowy RO gojenia ST 15 (opcjonalnie)',
                        )}
                      </>
                    )}
                    {(s.rest?.kind === 'short' ||
                      f.outcome === 'interrupt') && (
                      <>
                        {input('rolls6', 'Wyniki wydawanych k6', 'np. 3 5')}
                        {input('rolls8', 'Wyniki wydawanych k8', 'np. 3 5')}
                        {input(
                          'kolejkaLevel',
                          'Kolejka — poziom Cwaniaka (0 = brak)',
                        )}
                        {input('kolejkaRolls', 'Dodatkowe wyniki Kolejki')}
                      </>
                    )}
                    <p>
                      Przerwany krótki odpoczynek nie daje korzyści. Długi:
                      minimum 6h snu i dodatkowa godzina za każdą przerwę. Przy
                      przerwaniu wpisz łączny czas i tylko nowe KW. Sam upływ
                      czasu komputera niczego nie odnawia.
                    </p>
                  </>
                )}
                {dialog.mode === 'fuks' && (
                  <>
                    {input('source')}
                    {select('kind', 'Źródło', {
                      manual: 'Nagroda MG',
                      start: 'Pierwszy Fuks — jednorazowo',
                      fant: 'Fant',
                      song: 'Pieśń otuchy — 24h',
                      meal: 'Posiłek — 24h',
                    })}
                  </>
                )}
                {dialog.mode === 'session' &&
                  input('session', 'Nazwa / numer nowej sesji')}
                {dialog.mode === 'world' &&
                  input('minutes', 'Upływ czasu gry w minutach')}
              </div>
              <button disabled={store.locked} type="submit">
                {dialog.mode === 'exhaustion'
                  ? 'Dodaj Wyczerpanie'
                  : dialog.mode === 'exhaustionReduce'
                    ? 'Zmniejsz o 1 poziom'
                    : 'Pokaż podgląd'}
              </button>
            </form>
          )}
          {store.locked && (
            <button
              onClick={() =>
                void store.flush().then((ok) => {
                  if (ok) {
                    store.invalidInput(marker, null);
                    dialog.set({
                      owner: null,
                      mode: null,
                      preview: null,
                      error: null,
                    });
                  }
                })
              }
            >
              Ponów dokładnie ten zapis
            </button>
          )}
          {store.locked && (
            <button
              onClick={() =>
                void store.compareConflict().then(() => {
                  if (useCharacterStore.getState().conflict) {
                    store.invalidInput(marker, null);
                    dialog.set({
                      owner: null,
                      mode: null,
                      preview: null,
                      error: null,
                    });
                  }
                })
              }
            >
              Odczytaj zapis i porównaj
            </button>
          )}
          <button disabled={store.locked} onClick={close}>
            Anuluj
          </button>
        </Modal>
      )}
    </section>
  );
}
const labels: Record<string, string> = {
  hp: 'Aktualne PW',
  injury: 'Stopień Zranienia',
  spent6: 'Wydane KW k6',
  spent8: 'Wydane KW k8',
  reason: 'Powód',
  source: 'Źródło / opis',
  amount: 'Ilość',
  spent: 'Wydane użycia',
  max: 'Maksimum',
  label: 'Nazwa',
  elapsed: 'Łączny czas odpoczynku (minuty)',
  sleep: 'Sen (minuty)',
  level: 'Poziomy Wyczerpania',
};
const titles: Record<Mode, string> = {
  combatHealth: 'Rozliczenie zdrowia w walce',
  health: 'Zdrowie i Kości Wytrzymałości',
  effect: 'Redukcja wartości',
  exhaustion: 'Dodaj Wyczerpanie',
  exhaustionReduce: 'Zmniejsz Wyczerpanie',
  block: 'Blokada odpoczynku',
  remove: 'Usunięcie efektu',
  rest: 'Rozliczenie odpoczynku',
  cancel: 'Zakończenie bez korzyści',
  fuks: 'Przyznanie Fuksa',
  session: 'Nowa sesja',
  world: 'Czas w świecie gry',
};
