import { useState } from 'react';
import { ActiveAbilityPanel } from './ActiveAbilityPanel';
import { randomDie } from '../../domain/dice';
import { resolutionSummary } from '../../domain/character/activeAbilities';
import { useCombatStore } from '../../stores/combatStore';
import { useInitiativeStore } from '../../stores/initiativeStore';
import type { SlotId } from '../../domain/encounterDetails';
import { create } from 'zustand';
import { useCharacterStore } from '../../stores/characterStore';
import { useParticipationStore } from '../../stores/participationStore';
import { useDiceStore } from '../../stores/diceStore';
import {
  conditionView,
  previewCondition,
} from '../../domain/character/condition';
import type { Character } from '../../domain/character/model';
import type { Participation } from '../../domain/character/participation';
import {
  abilityApplicationSchema,
  hasCombatAbilityPath,
  type AbilityApplication,
} from '../../domain/character/combatAbility';
import type { ConditionAction } from '../../domain/character/conditionModel';
const costs = {
  none: 'Bez akcji',
  action: 'Akcja',
  bonus: 'Akcja Bonusowa',
  reaction: 'Reakcja',
  interaction: 'Interakcja',
  use: 'Dodatkowe Używanie',
} as const;
const targets = {
  attackSave: 'Ataki i Rzuty Obronne',
  intTools: 'Inteligencja i narzędzia',
  tt: 'Trudność Trafienia',
  all: 'Testy k20',
  attack: 'Ataki',
  damage: 'Obrażenia',
  str: 'Siła',
  dex: 'Zręczność',
  con: 'Kondycja',
  int: 'Inteligencja',
  wis: 'Mądrość',
  cha: 'Charyzma',
  save: 'Rzuty Obronne',
  skill: 'Umiejętności',
} as const;
const fixedCosts: Record<string, AbilityApplication['cost']> = {
  berserk: 'bonus',
  advice: 'bonus',
  stamina: 'bonus',
  motivation: 'reaction',
  heckle: 'reaction',
  defense: 'reaction',
  insult: 'action',
};
const abilityNotes: Record<string, string> = {
  'resource:motivation':
    'Reakcja przed testem sojusznika w 18 m. Sojusznik musi Cię słyszeć. Dodaj kość Motywacji do tego testu.',
  'resource:advice':
    'Akcja Bonusowa: słyszący Cię sojusznik dodaje Twój modyfikator INT do testów cech, ataków i RO do początku Twojej następnej tury.',
  'resource:brain':
    'Dodaj kość do testu Inteligencji albo testu dowolnych narzędzi.',
  'resource:luck':
    'Raz na rundę przerzuć własny test, zachowując Ułatwienie/Utrudnienie. Nowy wynik obowiązuje także wtedy, gdy jest gorszy.',
  'resource:heckle':
    'Reakcja po udanym ataku lub RO widzianej istoty w 18 m: powtarza test i zachowuje gorszy wynik.',
  'resource:insult':
    'Akcja: cel w 18 m musi Cię widzieć i słyszeć. Do końca Twojej następnej tury ma Utrudnienie ataków przeciw innym istotom niż Ty.',
  'profession.star.1':
    'Akcja; słyszący sojusznicy w 27 m. Wybierz ataki albo RO. Wynik Występów/instrumentu 5/10/15/20/25 daje +1/+2/+3/+4/+5 do początku Twojej następnej tury. Nieprzytomność, Obezwładnienie lub Ogłuchnięcie wykonawcy kończą efekt.',
  'profession.preacher.1':
    'Akcja Bonusowa. Słyszący sojusznicy w 18 m, maksymalnie tylu, ile poziomów Cwaniaka. Dodają osobne 1k4 do każdego ataku i RO do początku Twojej następnej tury.',
  'profession.preacher.2':
    'Raz na turę dodaj 1k10 obrażeń po trafieniu bronią palną.',
  'feat.neo':
    'Reakcja przed obrażeniami: +5 TT przeciw jednemu trafieniu. Zakończ efekt po rozliczeniu tego trafienia.',
  'feat.steady':
    'Akcja Bonusowa przed ruchem i atakiem: Szybkość 0 do końca tury, Ułatwienie następnego ataku dystansowego bez serii.',
};
type FormState = {
  owner: string | null;
  selection: string;
  cost: AbilityApplication['cost'];
  once: AbilityApplication['once'];
  target: string;
  extraTargets: string[];
  checkDice: string;
  performance: string;
  effect: boolean;
  nextRoll: boolean;
  damageDice: string;
  modifier: string;
  scope: keyof typeof targets;
  mode: 'normal' | 'advantage' | 'disadvantage';
  phase: 'start' | 'end' | 'round' | 'manual';
  remaining: string;
  amount: string;
  formula: string;
  healingRoll: string;
  combatChoice: 'action' | 'bonus';
  confirmed: boolean;
  error: string | null;
  preview: {
    command: ConditionAction;
    revision: number;
    lines: string[];
  } | null;
  set: (v: Partial<FormState>) => void;
};
const useForm = create<FormState>((set) => ({
  owner: null,
  selection: '',
  cost: 'none',
  once: 'none',
  target: '',
  extraTargets: [],
  checkDice: '',
  performance: '',
  effect: false,
  nextRoll: true,
  damageDice: '',
  modifier: '0',
  scope: 'attack',
  mode: 'normal',
  phase: 'manual',
  remaining: '1',
  amount: '1',
  formula: '1k6',
  healingRoll: '',
  combatChoice: 'action',
  confirmed: false,
  error: null,
  preview: null,
  set,
}));
export function CombatAbilities({
  record,
  participation: p,
  disabled,
}: {
  record: Character;
  participation: Participation;
  disabled: boolean;
}) {
  const [rerollId, setRerollId] = useState('');
  const combat = useCombatStore(
    (s) => s.drafts[p.encounterId as SlotId]?.value,
  );
  const f = useForm(),
    store = useCharacterStore(),
    ps = useParticipationStore(),
    dice = useDiceStore(),
    v = conditionView(record);
  const choices = [
    ...v.resources.map((r) => ({
      id: 'resource:' + r.id,
      label: r.label,
      page: r.page,
      summary: r.note,
      resource: r,
    })),
    ...v.derived.rules.map((r) => ({ ...r, resource: undefined })),
  ]
    .filter(
      (x) =>
        x.id !== 'resource:trajectory' &&
        hasCombatAbilityPath(x.id) &&
        x.resource?.page !== 0,
    )
    .filter((x, i, list) => list.findIndex((y) => y.label === x.label) === i);
  const selected = choices.find((x) => x.id === f.selection);
  const recipients = ps.entries.filter(
    (x) => x.encounterId === p.encounterId && x.state === 'active',
  );
  const marker = record.id + ':combat-ability';
  const edit = (value: Parameters<typeof f.set>[0]) =>
    f.set({ ...value, preview: null, error: null });
  const close = () => {
    if (store.locked) return;
    f.set({ owner: null, preview: null, error: null });
    store.invalidInput(marker, null);
  };
  const open = (id: string) => {
    if (f.owner && f.owner !== record.id) return;
    store.select(record.id);
    store.invalidInput(marker, 'Potwierdź lub anuluj użycie zdolności.');
    const resource = choices.find((x) => x.id === id)?.resource;
    const formula =
      resource?.id === 'rage'
        ? '1k6'
        : resource?.id === 'motivation'
          ? `1k${v.derived.classLevels.cwaniak >= 9 ? 10 : v.derived.classLevels.cwaniak >= 5 ? 8 : 6}`
          : resource?.id === 'brain'
            ? `1k${Math.min(12, 2 + 2 * Math.floor(v.derived.classLevels.spec / 2))}`
            : '1k6';
    f.set({
      owner: record.id,
      selection: id,
      cost:
        fixedCosts[resource?.id ?? ''] ??
        (
          {
            'profession.star.1': 'action',
            'profession.preacher.1': 'bonus',
            'feat.neo': 'reaction',
            'feat.steady': 'bonus',
          } as const
        )[id as 'profession.star.1'] ??
        'none',
      once: ['rage', 'luck'].includes(resource?.id ?? '')
        ? 'round'
        : [
              'class.zlodziej.1.1',
              'profession.preacher.2',
              'feat.steady',
            ].includes(id)
          ? 'turn'
          : 'none',
      target: [
        'resource:motivation',
        'resource:advice',
        'profession.star.1',
        'profession.preacher.1',
      ].includes(id)
        ? (recipients.find((t) => t.id !== p.id)?.id ?? '')
        : p.id,
      extraTargets: [],
      checkDice:
        resource?.id === 'motivation' || resource?.id === 'brain'
          ? formula
          : id === 'profession.preacher.1'
            ? '1k4'
            : '',
      performance: '',
      effect:
        [
          'rage',
          'advice',
          'defense',
          'motivation',
          'brain',
          'luck',
          'insult',
          'heckle',
        ].includes(resource?.id ?? '') ||
        [
          'class.zlodziej.1.1',
          'profession.star.1',
          'profession.preacher.1',
          'profession.preacher.2',
          'feat.neo',
          'feat.steady',
        ].includes(id),
      nextRoll:
        !['advice', 'defense', 'insult'].includes(resource?.id ?? '') &&
        !['profession.star.1', 'profession.preacher.1'].includes(id),
      damageDice:
        resource?.id === 'rage'
          ? '1k6'
          : id === 'class.zlodziej.1.1'
            ? `${Math.ceil(v.derived.classLevels.zlodziej / 2)}k6`
            : id === 'profession.preacher.2'
              ? '1k10'
              : '',
      scope:
        resource?.id === 'rage' ||
        ['class.zlodziej.1.1', 'profession.preacher.2'].includes(id)
          ? 'damage'
          : resource?.id === 'defense' || id === 'feat.neo'
            ? 'tt'
            : resource?.id === 'brain'
              ? 'intTools'
              : id === 'profession.preacher.1' || resource?.id === 'heckle'
                ? 'attackSave'
                : resource?.id === 'insult' ||
                    ['profession.star.1', 'feat.steady'].includes(id)
                  ? 'attack'
                  : 'all',
      modifier: ['advice', 'defense'].includes(resource?.id ?? '')
        ? String(v.derived.modifiers.int ?? 0)
        : id === 'feat.neo'
          ? '5'
          : '0',
      mode:
        resource?.id === 'insult'
          ? 'disadvantage'
          : id === 'feat.steady'
            ? 'advantage'
            : 'normal',
      phase:
        resource?.id === 'insult'
          ? 'end'
          : ['advice', 'defense'].includes(resource?.id ?? '') ||
              ['profession.star.1', 'profession.preacher.1'].includes(id)
            ? 'start'
            : 'manual',
      remaining: resource?.id === 'insult' ? '2' : '1',
      amount: '1',
      formula,
      healingRoll: '',
      combatChoice: 'action',
      confirmed: false,
      error: null,
      preview: null,
    });
  };
  function preview() {
    try {
      if (!selected) throw Error('Wybierz zdolność.');
      if (selected.id === 'resource:luck' && !eligibleRolls.length)
        throw Error('Brak testu do przerzucenia w bieżącej rundzie.');
      if (selected.resource?.id === 'stamina' && !/^[1-8]$/.test(f.healingRoll))
        throw Error('Kondycha: wpisz wynik k8 od 1 do 8.');
      const npc = combat?.actors.find((a) => a.id === f.target && !!a.enemy);
      if (selected.id === 'resource:heckle' && !npc)
        throw Error(
          'Wybierz przeciwnika z potyczki jako cel wymuszonego przerzutu.',
        );
      const target = recipients.find((x) => x.id === (npc ? p.id : f.target));
      if (!target) throw Error('Wybierz aktywnego BG.');
      const chosenTargets = [
        target,
        ...f.extraTargets.map((id) => recipients.find((t) => t.id === id)),
      ];
      if (chosenTargets.some((t) => !t))
        throw Error('Cel nie jest już aktywny.');
      if (
        [
          'resource:motivation',
          'resource:advice',
          'profession.star.1',
          'profession.preacher.1',
        ].includes(selected.id) &&
        chosenTargets.some((t) => t!.id === p.id)
      )
        throw Error('Ta zdolność wymaga sojusznika jako celu.');
      if (
        selected.id === 'profession.preacher.1' &&
        chosenTargets.length > v.derived.classLevels.cwaniak
      )
        throw Error('Łaska Boża: za dużo celów względem poziomu Cwaniaka.');
      if (selected.id === 'profession.star.1' && !/^-?\d+$/.test(f.performance))
        throw Error('Wpisz wynik Występów lub instrumentu.');
      const modifier =
        selected.id === 'profession.star.1'
          ? Math.max(0, Math.min(5, Math.floor(Number(f.performance) / 5)))
          : Number(f.modifier);
      const resolution =
        selected.id === 'resource:insult' && v.derived.classLevels.cwaniak >= 11
          ? { kind: 'deadlyInsult' as const, die: randomDie(6) }
          : undefined;
      const app = abilityApplicationSchema.parse({
        ...(resolution ? { resolution } : {}),
        ruleId: selected.id,
        label: selected.label,
        page: selected.page,
        cost: f.cost,
        once: f.once,
        confirmed: f.confirmed,
        targetId: target.id,
        targetRevision: target.revision,
        additionalTargets: chosenTargets
          .slice(1)
          .map((t) => ({ id: t!.id, revision: t!.revision })),
        effect: f.effect
          ? {
              id: crypto.randomUUID(),
              label: selected.label + ' — ' + v.sheet.identity.name,
              nextRoll: f.nextRoll,
              sourceRuleId: selected.id,
              ...(npc ? { recipientActorId: npc.id } : {}),
              clockActorId: p.actorId,
              ...(f.scope === 'damage' && f.damageDice
                ? { damageDice: f.damageDice }
                : {}),
              remaining: Number(f.remaining),
              phase: f.phase,
              target: f.scope,
              modifier,
              ...(f.checkDice ? { checkDice: f.checkDice } : {}),
              mode: f.mode,
            }
          : null,
      });
      const command: ConditionAction = selected.resource
        ? {
            type: 'use',
            resourceId: selected.resource.id,
            amount: Number(f.amount),
            healingRoll:
              selected.resource.id === 'stamina' ? Number(f.healingRoll) : null,
            ...(selected.resource.id === 'surge'
              ? { combatChoice: f.combatChoice }
              : {}),
            combatApplication: app,
          }
        : { type: 'combatAbility', combatApplication: app };
      const result = previewCondition(record, command, crypto.randomUUID());
      const name =
        npc?.displayName ??
        store.records.find((c) => c.id === target.characterId)?.sheet?.identity
          .name ??
        'BG';
      f.set({
        preview: {
          command,
          revision: record.revision,
          lines: [
            ...result.lines,
            ...(resolution
              ? [resolutionSummary(resolution, v.derived.modifiers.cha ?? 0)]
              : []),
            'Koszt: ' + costs[f.cost],
            'Cele: ' +
              [
                name,
                ...chosenTargets
                  .slice(1)
                  .map(
                    (t) =>
                      store.records.find((c) => c.id === t!.characterId)?.sheet
                        ?.identity.name ?? 'BG',
                  ),
              ].join(', '),
            ...(f.effect
              ? [
                  `${targets[f.scope]}: ${modifier}${f.checkDice ? ' + ' + f.checkDice : ''}${f.damageDice ? ' + ' + f.damageDice : ''}; ${f.mode === 'advantage' ? 'Ułatwienie' : f.mode === 'disadvantage' ? 'Utrudnienie' : 'bez zmiany rodzaju rzutu'}`,
                  f.phase === 'manual'
                    ? 'Efekt do ręcznego zakończenia.'
                    : `Czas: ${f.remaining}; ${f.phase === 'start' ? 'początki tur używającego' : f.phase === 'end' ? 'końce tur używającego' : 'rundy'}`,
                ]
              : ['Bez automatycznej zmiany PW ani wyniku poprzedniego rzutu.']),
          ],
        },
        error: null,
      });
    } catch (e) {
      f.set({ error: String(e) });
    }
  }
  const luck = p.effects.find((e) => e.sourceRuleId === 'resource:luck');
  const eligibleRolls = dice.history.filter(
    (r) =>
      r.context?.actorId === p.actorId &&
      r.context.encounterId === p.encounterId &&
      r.context.roundNumber === combat?.roundNumber &&
      r.count === 1 &&
      r.sides === 20 &&
      !r.context.rerollOf &&
      !dice.history.some((later) => later.context?.rerollOf === r.id),
  );
  const previous =
    eligibleRolls.find((r) => r.id === rerollId) ?? eligibleRolls[0];
  return (
    <section aria-label="Zdolności w walce">
      <h3>Zdolności i sztuczki</h3>
      <p>
        Wybierz zdolność z obsługą w walce, potwierdź warunki i rozlicz koszt.
        Zdolności fabularne pozostają opisane na Karcie BG i nie tworzą premii
        do rzutu. Rzut nie zmienia PW.
      </p>
      <ActiveAbilityPanel
        record={record}
        participation={p}
        disabled={disabled || !!f.owner}
      />
      {luck && (
        <div>
          <label>
            Test do przerzucenia
            <select
              value={previous?.id ?? ''}
              onChange={(e) => setRerollId(e.target.value)}
            >
              {eligibleRolls.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.context?.label}: {r.total}
                </option>
              ))}
            </select>
          </label>
          <button
            disabled={disabled || dice.busy || !!dice.pending || !previous}
            onClick={async () => {
              if (!previous?.context) return;
              if (previous.context.purpose === 'initiative') {
                await useInitiativeStore
                  .getState()
                  .roll(p.encounterId as SlotId, p.actorId, previous.modifier, {
                    mode: previous.checkDice?.mode ?? 'normal',
                    name: v.sheet.identity.name,
                    rerollOf: previous.id,
                    consumedEffects: [luck.id],
                    participationRevision: p.revision,
                  });
                return;
              }
              await dice.roll(
                previous.formula,
                {
                  ...previous.context,
                  label: 'Szczęście — przerzut: ' + previous.context.label,
                  rerollOf: previous.id,
                  consumedEffects: [luck.id],
                  participationRevision: p.revision,
                },
                undefined,
                { mode: previous.checkDice?.mode ?? 'normal' },
              );
            }}
          >
            Szczęście — przerzuć wybrany test
            {previous ? ' (' + previous.context?.label + ')' : ''}
          </button>
        </div>
      )}
      {f.owner !== record.id ? (
        <label>
          Zdolność z obsługą w walce
          <select
            value=""
            disabled={disabled || p.state !== 'active' || !!f.owner}
            onChange={(e) => {
              if (e.target.value) open(e.target.value);
            }}
          >
            <option value="">Wybierz…</option>
            {choices.map((c) => (
              <option key={c.id} value={c.id}>
                {c.label}
                {c.resource
                  ? ` (${Math.max(0, c.resource.max - (v.state.spent[c.resource.id] ?? 0))}/${c.resource.max})`
                  : ''}
              </option>
            ))}
          </select>
        </label>
      ) : (
        <fieldset disabled={disabled || store.locked}>
          <legend>
            {selected?.label} · podręcznik s. {selected?.page}
          </legend>
          <p>{abilityNotes[selected?.id ?? ''] ?? selected?.summary}</p>
          {f.preview ? (
            <>
              <ul>
                {f.preview.lines.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
              <button
                onClick={async () => {
                  store.select(record.id);
                  if (
                    await store.mutateCondition(
                      f.preview!.command,
                      f.preview!.revision,
                    )
                  ) {
                    f.set({ owner: null, preview: null });
                    store.invalidInput(marker, null);
                  }
                }}
              >
                Zastosuj zdolność
              </button>
              <button onClick={() => edit({})}>Wróć do pól</button>
            </>
          ) : (
            <>
              {selected?.resource?.id === 'stamina' && (
                <label>
                  Kondycha — wynik k8
                  <input
                    type="number"
                    min="1"
                    max="8"
                    value={f.healingRoll}
                    onChange={(e) => edit({ healingRoll: e.target.value })}
                  />
                  <small>
                    Po zatwierdzeniu: wynik + poziom Twardziela PW, do maksimum.
                  </small>
                </label>
              )}
              {selected?.resource?.id === 'surge' && (
                <label>
                  Zryw — przyznaj
                  <select
                    value={f.combatChoice}
                    onChange={(e) =>
                      edit({
                        combatChoice: e.target.value as 'action' | 'bonus',
                      })
                    }
                  >
                    <option value="action">Akcję</option>
                    <option value="bonus">Akcję Bonusową</option>
                  </select>
                </label>
              )}
              {selected?.resource && (
                <label>
                  Zużycie zasobu
                  <input
                    type="number"
                    min="1"
                    max={selected.resource.costMax}
                    value={f.amount}
                    onChange={(e) =>
                      edit({
                        amount: e.target.value,
                        ...(selected.resource?.id === 'rage'
                          ? { damageDice: e.target.value + 'k6' }
                          : {}),
                      })
                    }
                  />
                </label>
              )}
              <label>
                Koszt
                <select
                  value={f.cost}
                  disabled={!!fixedCosts[selected?.resource?.id ?? '']}
                  onChange={(e) =>
                    edit({ cost: e.target.value as typeof f.cost })
                  }
                >
                  {Object.entries(costs).map(([id, name]) => (
                    <option key={id} value={id}>
                      {name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Limit
                <select
                  value={f.once}
                  onChange={(e) =>
                    edit({ once: e.target.value as typeof f.once })
                  }
                >
                  <option value="none">Bez dodatkowego limitu</option>
                  <option value="turn">Raz na turę</option>
                  <option value="round">Raz na rundę</option>
                </select>
              </label>
              <label>
                Cel
                <select
                  value={f.target}
                  onChange={(e) =>
                    edit({
                      target: e.target.value,
                      extraTargets: f.extraTargets.filter(
                        (id) => id !== e.target.value,
                      ),
                    })
                  }
                >
                  {combat?.actors
                    .filter((a) => a.enemy)
                    .map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.displayName} (przeciwnik)
                      </option>
                    ))}
                  {recipients.map((t) => (
                    <option key={t.id} value={t.id}>
                      {store.records.find((c) => c.id === t.characterId)?.sheet
                        ?.identity.name ?? 'BG'}
                    </option>
                  ))}
                </select>
              </label>
              {['profession.star.1', 'profession.preacher.1'].includes(
                selected?.id ?? '',
              ) && (
                <fieldset>
                  <legend>Dodatkowi sojusznicy w zasięgu</legend>
                  {recipients
                    .filter((t) => t.id !== p.id && t.id !== f.target)
                    .map((t) => (
                      <label key={t.id}>
                        <input
                          type="checkbox"
                          checked={f.extraTargets.includes(t.id)}
                          onChange={(e) =>
                            edit({
                              extraTargets: e.target.checked
                                ? [...f.extraTargets, t.id]
                                : f.extraTargets.filter((id) => id !== t.id),
                            })
                          }
                        />
                        {store.records.find((c) => c.id === t.characterId)
                          ?.sheet?.identity.name ?? 'BG'}
                      </label>
                    ))}
                </fieldset>
              )}
              {selected?.id === 'profession.star.1' && (
                <label>
                  Wynik Występów lub instrumentu
                  <input
                    type="number"
                    value={f.performance}
                    onChange={(e) => edit({ performance: e.target.value })}
                  />
                </label>
              )}
              <label>
                <input
                  type="checkbox"
                  checked={f.effect}
                  onChange={(e) => edit({ effect: e.target.checked })}
                />
                Dodaj efekt do następnych rzutów celu
              </label>
              {f.effect && (
                <>
                  <label>
                    <input
                      type="checkbox"
                      checked={f.nextRoll}
                      onChange={(e) => edit({ nextRoll: e.target.checked })}
                    />
                    Zużyj przy najbliższym pasującym rzucie
                  </label>
                  <label>
                    Dotyczy
                    <select
                      value={f.scope}
                      onChange={(e) =>
                        edit({ scope: e.target.value as typeof f.scope })
                      }
                    >
                      {Object.entries(targets).map(([id, label]) => (
                        <option key={id} value={id}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>
                  {f.scope === 'damage' && (
                    <label>
                      Dodatkowe kości obrażeń
                      <input
                        placeholder="np. 2k6"
                        value={f.damageDice}
                        onChange={(e) => edit({ damageDice: e.target.value })}
                      />
                      <small>
                        Kości zostaną dodane do rzutu obrażeń i uwzględnione
                        przy krytyku.
                      </small>
                    </label>
                  )}
                  <label>
                    Kość dodawana przy każdym pasującym teście
                    <select
                      value={f.checkDice}
                      onChange={(e) => edit({ checkDice: e.target.value })}
                    >
                      <option value="">Brak</option>
                      {['1k4', '1k6', '1k8', '1k10', '1k12'].map((d) => (
                        <option key={d}>{d}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Premia lub kara
                    <input
                      type="number"
                      min="-100"
                      max="100"
                      value={f.modifier}
                      onChange={(e) => edit({ modifier: e.target.value })}
                    />
                  </label>
                  <label>
                    Kości zdolności
                    <input
                      value={f.formula}
                      onChange={(e) => edit({ formula: e.target.value })}
                    />
                  </label>
                  <button
                    disabled={dice.busy || !!dice.pending}
                    onClick={async () => {
                      const ok = await dice.roll(f.formula, undefined, {
                        characterId: record.id,
                        name: v.sheet.identity.name,
                        label: selected?.label ?? 'Zdolność',
                      });
                      if (ok)
                        edit({
                          modifier: String(
                            useDiceStore.getState().history[0]!.total,
                          ),
                        });
                      else
                        f.set({
                          error:
                            'Rzut nie został zapisany. Sprawdź panel kości.',
                        });
                    }}
                  >
                    Rzuć i wpisz premię
                  </button>
                  <label>
                    Warunek rzutu
                    <select
                      value={f.mode}
                      onChange={(e) =>
                        edit({ mode: e.target.value as typeof f.mode })
                      }
                    >
                      <option value="normal">Bez zmiany</option>
                      <option value="advantage">Ułatwienie</option>
                      <option value="disadvantage">Utrudnienie</option>
                    </select>
                  </label>
                  <label>
                    Wygaśnięcie
                    <select
                      value={f.phase}
                      onChange={(e) =>
                        edit({ phase: e.target.value as typeof f.phase })
                      }
                    >
                      <option value="manual">Ręcznie</option>
                      <option value="start">Początek tury używającego</option>
                      <option value="end">Koniec tury używającego</option>
                      <option value="round">Zmiana rundy</option>
                    </select>
                  </label>
                  {f.phase !== 'manual' && (
                    <label>
                      Liczba odliczeń
                      <input
                        type="number"
                        min="1"
                        max="1000"
                        value={f.remaining}
                        onChange={(e) => edit({ remaining: e.target.value })}
                      />
                    </label>
                  )}
                </>
              )}
              <label>
                <input
                  type="checkbox"
                  checked={f.confirmed}
                  onChange={(e) => edit({ confirmed: e.target.checked })}
                />
                Warunki zdolności, wybrany cel, koszt i czas są zgodne z jej
                zasadą.
              </label>
              <button disabled={!f.confirmed} onClick={preview}>
                Pokaż podgląd
              </button>
            </>
          )}
          <button onClick={close}>Anuluj</button>
          {f.error && <p role="alert">{f.error}</p>}
        </fieldset>
      )}
      {store.locked && store.error && (
        <div role="alert">
          <p>{store.error}</p>
          <button onClick={() => void store.flush()}>
            Ponów dokładnie ten zapis
          </button>
          <button onClick={() => void store.compareConflict()}>
            Odczytaj zapis i porównaj
          </button>
        </div>
      )}
    </section>
  );
}
