import { equipmentSource } from '../../domain/equipmentSource';
import type { InventoryEntry } from '../../domain/character/inventoryModel';

const pages = String.raw`([1-9]\d*(?:\s*[-–]\s*[1-9]\d*)?(?:\s*,\s*[1-9]\d*(?:\s*[-–]\s*[1-9]\d*)?)*)`;
const citation = String.raw`^Neuroshima: Ostatnia Era\s*(?:,|—)\s*s\.\s*${pages}`;
const itemCitation = new RegExp(`${citation}(?:\\s*;[^\\n]+)?$`);
const plainProfileCitation = new RegExp(`${citation}$`);
const pageKey = (match: RegExpMatchArray | null) =>
  match?.[1]?.replace(/\s/g, '').replace(/–/g, '-') ?? null;

/** Present references without rewriting source data or hiding custom profile notes. */
export function inventorySources(entry: InventoryEntry): string[] {
  const primary = equipmentSource(entry.item)?.trim();
  const primaryPages = primary ? pageKey(primary.match(itemCitation)) : null;
  const sources = primary ? [primary] : [];
  for (const raw of [entry.weapon?.source, entry.armor?.source]) {
    const source = raw?.trim();
    if (!source || sources.includes(source)) continue;
    // Only a bare citation of exactly the same handbook pages is redundant.
    // A profile with extra wording or a broader page range remains visible.
    if (
      primaryPages !== null &&
      pageKey(source.match(plainProfileCitation)) === primaryPages
    )
      continue;
    sources.push(source);
  }
  return sources;
}
