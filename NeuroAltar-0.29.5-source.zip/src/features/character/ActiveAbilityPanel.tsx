import { useState } from 'react';
import {
  activeAbilityCommand,
  activeAbilityLabels,
  availableActiveAbilities,
  resolutionSummary,
  type ActiveAbilityKind,
} from '../../domain/character/activeAbilities';
import {
  conditionView,
  previewCondition,
} from '../../domain/character/condition';
import type { AbilityResolution } from '../../domain/character/combatAbility';
import type { ConditionAction } from '../../domain/character/conditionModel';
import type { Character } from '../../domain/character/model';
import type { Participation } from '../../domain/character/participation';
import { randomDie } from '../../domain/dice';
import type { SlotId } from '../../domain/encounterDetails';
import { useCharacterStore } from '../../stores/characterStore';
import { useCombatStore } from '../../stores/combatStore';
import { useParticipationStore } from '../../stores/participationStore';

export function ActiveAbilityPanel({
  record,
  participation: p,
  disabled,
}: {
  record: Character;
  participation: Participation;
  disabled: boolean;
}) {
  const store = useCharacterStore(),
    participations = useParticipationStore((s) => s.entries);
  const combat = useCombatStore(
    (s) => s.drafts[p.encounterId as SlotId]?.value,
  );
  const [kind, setKind] = useState<ActiveAbilityKind | ''>(''),
    [target, setTarget] = useState(''),
    [die, setDie] = useState(''),
    [incoming, setIncoming] = useState(''),
    [success, setSuccess] = useState(false),
    [confirmed, setConfirmed] = useState(false),
    [error, setError] = useState<string | null>(null);
  const [prepared, setPrepared] = useState<{
    command: ConditionAction;
    revision: number;
    lines: string[];
  } | null>(null);
  const options = availableActiveAbilities(record),
    marker = record.id + ':active-ability';
  const v = conditionView(record),
    sneak = kind.startsWith('sneak');
  if (!options.length) return null;
  function close() {
    if (store.locked) return;
    store.invalidInput(marker, null);
    setKind('');
    setPrepared(null);
    setError(null);
  }
  function preview() {
    try {
      if (!kind || !confirmed)
        throw Error('Potwierdź warunki użycia zdolności.');
      const recipient = participations.find(
        (x) =>
          x.id === target &&
          x.state === 'active' &&
          x.encounterId === p.encounterId,
      );
      const npc = combat?.actors.find((a) => a.id === target && !!a.enemy);
      if (sneak && !npc && (!recipient || recipient.id === p.id))
        throw Error('Wybierz trafiony cel.');
      let resolution: AbilityResolution | undefined;
      if (kind === 'catDefense' || kind === 'sneakSlow') {
        const sides =
          kind === 'sneakSlow'
            ? 6
            : 4 + 2 * Math.floor((v.derived.classLevels.zlodziej - 2) / 3);
        const face = die ? Number(die) : randomDie(sides);
        if (!Number.isInteger(face) || face < 1 || face > sides)
          throw Error(`Wynik musi mieścić się w zakresie 1–${sides}.`);
        setDie(String(face));
        resolution = { kind, die: face };
      } else if (kind === 'matrix' || kind === 'dodge') {
        if (!/^\d+$/.test(incoming))
          throw Error('Wpisz obrażenia przed redukcją.');
        resolution =
          kind === 'matrix'
            ? { kind, incomingDamage: Number(incoming), saveSucceeded: success }
            : { kind, incomingDamage: Number(incoming) };
      } else if (kind === 'sneakBleed' || kind === 'sneakBlind')
        resolution = { kind };
      const chosen =
        sneak && recipient
          ? { id: recipient.id, revision: recipient.revision }
          : {
              id: p.id,
              revision: p.revision,
              ...(sneak && npc ? { actorId: npc.id } : {}),
            };
      const command = activeAbilityCommand(record, p, kind, chosen, resolution);
      const check = previewCondition(record, command, crypto.randomUUID());
      setPrepared({
        command,
        revision: record.revision,
        lines: [
          ...check.lines,
          ...(resolution
            ? [resolutionSummary(resolution)]
            : [
                `Następny atak dystansowy: ${(v.derived.modifiers.int ?? 0) >= 0 ? '+' : ''}${v.derived.modifiers.int ?? 0} z Inteligencji.`,
              ]),
          ...(sneak
            ? [
                `Cel: ${npc?.displayName ?? store.records.find((c) => c.id === recipient?.characterId)?.sheet?.identity.name ?? 'BG'}`,
              ]
            : []),
        ],
      });
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  }
  return (
    <section aria-label="Zdolności szczególne">
      {!kind ? (
        <label>
          Zdolności szczególne
          <select
            value=""
            disabled={disabled || store.locked || p.state !== 'active'}
            onChange={(e) => {
              if (!e.target.value) return;
              store.invalidInput(
                marker,
                'Potwierdź lub anuluj użycie zdolności.',
              );
              setKind(e.target.value as ActiveAbilityKind);
              setTarget('');
              setDie('');
              setIncoming('');
              setSuccess(false);
              setConfirmed(false);
              setPrepared(null);
              setError(null);
            }}
          >
            <option value="">Wybierz…</option>
            {options.map((k) => (
              <option key={k} value={k}>
                {activeAbilityLabels[k]}
              </option>
            ))}
          </select>
        </label>
      ) : (
        <fieldset disabled={disabled || store.locked}>
          <legend>{activeAbilityLabels[kind]}</legend>
          {prepared ? (
            <>
              <ul>
                {prepared.lines.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
              <button
                onClick={async () => {
                  store.select(record.id);
                  if (
                    await store.mutateCondition(
                      prepared.command,
                      prepared.revision,
                    )
                  ) {
                    store.invalidInput(marker, null);
                    setKind('');
                    setPrepared(null);
                  }
                }}
              >
                Zastosuj zdolność
              </button>
              <button onClick={() => setPrepared(null)}>Wróć do pól</button>
            </>
          ) : (
            <>
              {kind === 'trajectory' && (
                <p>
                  Dodaj modyfikator Inteligencji do następnego testu ataku
                  dystansowego. Zużywasz jedno użycie Trajektorii.
                </p>
              )}
              {sneak && (
                <>
                  <p>
                    Po trafieniu spełniającym warunki Bolesnego ataku wybierz
                    jeden efekt zamiast jego dodatkowych obrażeń.
                  </p>
                  <label>
                    Trafiony cel
                    <select
                      value={target}
                      onChange={(e) => setTarget(e.target.value)}
                    >
                      <option value="">Wybierz…</option>
                      {combat?.actors
                        .filter((a) => a.enemy)
                        .map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.displayName}
                          </option>
                        ))}
                      {participations
                        .filter(
                          (t) =>
                            t.encounterId === p.encounterId &&
                            t.state === 'active' &&
                            t.id !== p.id,
                        )
                        .map((t) => (
                          <option key={t.id} value={t.id}>
                            {store.records.find((c) => c.id === t.characterId)
                              ?.sheet?.identity.name ?? 'BG'}
                          </option>
                        ))}
                    </select>
                  </label>
                </>
              )}
              {(kind === 'catDefense' || kind === 'sneakSlow') && (
                <label>
                  {kind === 'catDefense'
                    ? `Wynik Kociej kości k${4 + 2 * Math.floor((v.derived.classLevels.zlodziej - 2) / 3)}`
                    : 'Wynik k6'}
                  <input
                    type="number"
                    min="1"
                    max={
                      kind === 'catDefense'
                        ? 4 +
                          2 *
                            Math.floor((v.derived.classLevels.zlodziej - 2) / 3)
                        : 6
                    }
                    value={die}
                    onChange={(e) => setDie(e.target.value)}
                    placeholder="Puste — rzuć w aplikacji"
                  />
                </label>
              )}
              {(kind === 'matrix' || kind === 'dodge') && (
                <>
                  <label>
                    Obrażenia przed redukcją
                    <input
                      type="number"
                      min="0"
                      max="100000"
                      value={incoming}
                      onChange={(e) => setIncoming(e.target.value)}
                    />
                  </label>
                  {kind === 'matrix' ? (
                    <>
                      <p>
                        Efekt obszarowy wymagający RO na Zręczność. Udany RO: 0
                        obrażeń; nieudany: połowa, w dół.
                      </p>
                      <label>
                        <input
                          type="checkbox"
                          checked={success}
                          onChange={(e) => setSuccess(e.target.checked)}
                        />
                        RO na Zręczność zakończony sukcesem
                      </label>
                    </>
                  ) : (
                    <p>
                      Reakcja na bezpośredni atak skierowany w Ciebie. Obrażenia
                      psychiczne są wyłączone.
                    </p>
                  )}
                  <p>
                    Wynik redukcji trafi do logu. PW rozliczasz w sekcji
                    Zdrowie.
                  </p>
                </>
              )}
              {kind === 'catDefense' && (
                <p>
                  Reakcja i jedna Kocia kość: TT rośnie o wynik kości do
                  początku Twojej następnej tury.
                </p>
              )}
              <label>
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                />
                Warunki tej zdolności są spełnione
              </label>
              <button onClick={preview}>Przygotuj użycie</button>
            </>
          )}
          {error && <p role="alert">{error}</p>}
          <button onClick={close}>Anuluj</button>
        </fieldset>
      )}
    </section>
  );
}
