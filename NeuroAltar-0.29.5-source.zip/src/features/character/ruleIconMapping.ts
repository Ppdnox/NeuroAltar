import icons from './rule-icons.json';

// Stable local rule IDs keep similarly named features of different classes distinct.
// Art is presentation only; no source-module mechanics or catalog data are imported.
const ruleIcons: Readonly<Record<string, string>> = icons;

export function ruleIllustration(ruleId: string): string | undefined {
  return ruleIcons[ruleId];
}
