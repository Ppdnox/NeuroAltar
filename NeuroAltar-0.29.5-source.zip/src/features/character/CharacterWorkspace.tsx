import { useEncounterStore } from '../../stores/encounterStore';
import { useCombatStore } from '../../stores/combatStore';
import { useBestiaryStore } from '../../stores/bestiaryStore';
import { useNavigationStore } from '../../stores/navigationStore';
import type { SlotId } from '../../domain/encounterDetails';
import { characterCombatValues } from '../../domain/character/participation';
import { useParticipationStore } from '../../stores/participationStore';
import { CombatAbilities } from './CombatAbilities';
import { RuleIllustration } from './RuleIllustration';
import { AbilityResources, ManualResourceForm } from './AbilityResources';
import {
  resourcesForRule,
  unassignedResources,
} from '../../domain/character/resourceRules';
import {
  Backpack,
  ClipboardList,
  Crosshair,
  Dices,
  Heart,
  NotebookPen,
  Shield,
  Tent,
  Zap,
} from 'lucide-react';
import { RollValue, type ActorRollHandler } from '../dice/ActorRoll';
import { useDiceStore } from '../../stores/diceStore';
import type { DiceRoll } from '../../domain/dice';
import {
  naturalRollClass,
  naturalRollLabel,
} from '../../domain/dicePresentation';
import { rollCharacter } from '../../services/characterRolls';
import { CarePanel } from './CarePanel';
import { ConditionPanel } from './ConditionPanel';
import {
  conditionSheet,
  conditionView,
} from '../../domain/character/condition';
import { InventoryPanel } from './InventoryPanel';
import { deriveEquipment } from '../../domain/character/equipped';
import { emptyInventory } from '../../domain/character/inventoryModel';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useCharacterStore } from '../../stores/characterStore';
import {
  ABILITIES,
  CLASSES,
  COLORS,
  abilityNames,
  characterJournal,
  colorNames,
  withGameColor,
  type Ability,
  type CharacterSheet,
  type GameColor,
} from '../../domain/character/model';
import {
  classes,
  origins,
  skills,
  tools,
  weaponNames,
  armorNames,
  professions,
} from '../../domain/character/catalog';
import {
  deriveCharacter,
  arrays,
  type Value,
  type Choice,
} from '../../domain/character/derive';
import { feats } from '../../domain/character/feats';
import { describeSheet } from '../../domain/character/review';
import { experienceProgress } from '../../domain/character/experience';
import './character.css';

const format = (value: number | null) =>
  value === null
    ? '—'
    : new Intl.NumberFormat('pl-PL', { maximumFractionDigits: 2 }).format(
        value,
      );
const signed = (value: number | null) =>
  value === null ? '—' : (value >= 0 ? '+' : '') + format(value);

const sessionPages = [
  { id: 'weapons', label: 'Broń', Icon: Crosshair },
  { id: 'checks', label: 'Testy', Icon: Dices },
  { id: 'abilities', label: 'Zdolności', Icon: Zap },
  { id: 'inventory', label: 'Ekwipunek', Icon: Backpack },
  { id: 'health', label: 'Zdrowie i odpoczynek', Icon: Heart },
  { id: 'downtime', label: 'Postój', Icon: Tent },
  { id: 'overview', label: 'Podsumowanie', Icon: ClipboardList },
  { id: 'development', label: 'Rozwój i dane', Icon: NotebookPen },
] as const;

function CharacterLastRoll({ characterId }: { characterId: string }) {
  const history = useDiceStore((s) => s.history);
  const pending = useDiceStore((s) => s.pending);
  const participations = useParticipationStore((s) => s.entries);
  const matches = (roll: DiceRoll) =>
    roll.characterContext?.characterId === characterId ||
    roll.characterCheck?.characterId === characterId ||
    roll.supplement?.characterId === characterId ||
    (!!roll.context &&
      participations.some(
        (p) =>
          p.characterId === characterId && p.actorId === roll.context!.actorId,
      ));
  const roll = pending && matches(pending) ? pending : history.find(matches);
  const label =
    roll?.characterContext?.label ??
    roll?.context?.label ??
    roll?.supplement?.originalLabel;
  return (
    <div className="bg-session-roll" aria-label="Ostatni rzut postaci">
      <Dices size={17} aria-hidden="true" />
      <span className="bg-session-roll-label">Ostatni rzut</span>
      <span className="bg-session-roll-result" aria-live="polite">
        {roll ? (
          <>
            <span>
              {label ?? 'Rzut'} · {roll.formula}
            </span>
            <strong
              className={naturalRollClass(roll)}
              title={naturalRollLabel(roll)}
            >
              {roll.total}
            </strong>
            {!!naturalRollLabel(roll) && (
              <span className={naturalRollClass(roll)}>
                {naturalRollLabel(roll)}
              </span>
            )}
            {pending?.id === roll.id && <span>Oczekuje na zapis</span>}
          </>
        ) : (
          <span>Wybierz atak lub test, aby rzucić.</span>
        )}
      </span>
      <button
        className="bg-link"
        onClick={() => useDiceStore.getState().setOpen(true)}
      >
        Historia rzutów
      </button>
    </div>
  );
}
function Calculated({
  label,
  result,
  unit = '',
  sign = false,
  onRoll,
  rollLabel,
  icon,
  children,
}: {
  label: string;
  result: Value;
  unit?: string;
  sign?: boolean;
  onRoll?: ActorRollHandler;
  rollLabel?: string;
  icon?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <details className="bg-result">
      <summary>
        <span className="bg-result-label">
          {icon}
          {label}
        </span>
        <strong onClick={onRoll ? (e) => e.stopPropagation() : undefined}>
          {onRoll && result.value !== null ? (
            <RollValue
              formula={`1k20${result.value >= 0 ? '+' : ''}${result.value}`}
              label={rollLabel ?? label}
              onRoll={onRoll}
            >
              {signed(result.value)}
            </RollValue>
          ) : sign ? (
            signed(result.value)
          ) : (
            format(result.value)
          )}
          {unit}
        </strong>
      </summary>
      <ul>
        {result.components.map((p, i) => (
          <li key={i}>
            {p.source}: {signed(p.value)}
          </li>
        ))}
      </ul>
      {result.conditions.map((c, i) => (
        <p key={i}>{c}</p>
      ))}
      {result.value === null && <p>Uzupełnij brakujące dane.</p>}
      {children}
    </details>
  );
}
function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    d?.showModal();
    return () => d?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      className="bg-dialog"
      aria-label={title}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <h2>{title}</h2>
      {children}
      <button className="secondary-button" onClick={onClose}>
        Anuluj
      </button>
    </dialog>
  );
}
function ChoiceField({
  choice,
  values,
  disabled,
  invalid,
  onChange,
  weaponModels = [],
}: {
  choice: Choice;
  values: string[];
  disabled: boolean;
  invalid: boolean;
  onChange: (values: string[]) => void;
  weaponModels?: { id: string; name: string }[];
}) {
  return (
    <fieldset
      id={`level-${choice.level}-${choice.key}`}
      className="bg-choice"
      disabled={disabled}
    >
      <legend>{choice.label}</legend>
      {Array.from({ length: choice.count }, (_, i) => (
        <label key={i}>
          <span className="bg-small">
            {choice.count > 1 ? `Wybór ${i + 1}` : 'Wybór'}
          </span>
          {choice.freeText ? (
            choice.key === 'favorite-weapon' ? (
              <>
                {weaponModels.length > 0 && (
                  <select
                    aria-label="Wybierz model broni z ekwipunku"
                    value={
                      weaponModels.some((w) => w.id === values[i])
                        ? values[i]
                        : ''
                    }
                    onChange={(e) => {
                      const next = [...values];
                      next[i] = e.target.value;
                      onChange(next);
                    }}
                  >
                    <option value="">Wpisz model ręcznie</option>
                    {weaponModels.map((w) => (
                      <option value={w.id} key={w.id}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                )}
                {!weaponModels.some((w) => w.id === values[i]) && (
                  <input
                    aria-label="Nazwa modelu broni"
                    aria-invalid={invalid || undefined}
                    value={values[i] ?? ''}
                    maxLength={300}
                    onChange={(e) => {
                      const next = [...values];
                      next[i] = e.target.value;
                      onChange(next);
                    }}
                  />
                )}
                <small>
                  Wybór z ekwipunku zachowuje powiązanie po zmianie nazwy
                  przedmiotu.
                </small>
              </>
            ) : (
              <input
                aria-invalid={invalid || undefined}
                value={values[i] ?? ''}
                maxLength={300}
                onChange={(e) => {
                  const next = [...values];
                  next[i] = e.target.value;
                  onChange(next);
                }}
              />
            )
          ) : (
            <select
              aria-invalid={invalid || undefined}
              value={values[i] ?? ''}
              onChange={(e) => {
                const next = [...values];
                next[i] = e.target.value;
                onChange(next);
              }}
            >
              <option value="">Wybierz…</option>
              {values[i] && !choice.options.some((o) => o.id === values[i]) && (
                <option value={values[i]}>
                  Nieaktualny wybór: {values[i]}
                </option>
              )}
              {choice.options.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.label}
                </option>
              ))}
            </select>
          )}
        </label>
      ))}
    </fieldset>
  );
}
function NumberField({
  id,
  label,
  value,
  disabled,
  min = 0,
  max = 100000,
  integer = false,
  onChange,
  characterId,
}: {
  id: string;
  label: string;
  value: number | null;
  disabled: boolean;
  min?: number;
  max?: number;
  integer?: boolean;
  onChange: (n: number | null) => void;
  characterId: string;
}) {
  const raw = useCharacterStore((s) => s.invalid[characterId + ':' + id]);
  const outOfRange =
    value !== null &&
    (value < min || value > max || (integer && !Number.isInteger(value)));
  const invalid = raw !== undefined || outOfRange;
  return (
    <label id={id}>
      {label}
      <input
        type="text"
        inputMode={integer ? 'numeric' : 'decimal'}
        disabled={disabled}
        value={raw ?? (value === null ? '' : String(value).replace('.', ','))}
        aria-invalid={invalid || undefined}
        onChange={(e) => {
          const text = e.target.value,
            n = text.trim() === '' ? null : Number(text.replace(',', '.'));
          const valid =
            n === null ||
            (Number.isFinite(n) &&
              n >= min &&
              n <= max &&
              (!integer || Number.isInteger(n)));
          useCharacterStore
            .getState()
            .invalidInput(characterId + ':' + id, valid ? null : text);
          if (valid) onChange(n);
        }}
      />
      {invalid && (
        <span className="bg-invalid">
          Wpisz {integer ? 'liczbę całkowitą' : 'liczbę'} od {min} do {max}.
        </span>
      )}
    </label>
  );
}
function reveal(path: string) {
  const target = document.getElementById(path);
  if (!target) return;
  for (let p: HTMLElement | null = target; p; p = p.parentElement) {
    if (p instanceof HTMLDetailsElement) p.open = true;
    if (p.dataset.bgPage) {
      p.hidden = false;
      window.dispatchEvent(
        new CustomEvent('bg-show-page', { detail: p.dataset.bgPage }),
      );
    }
  }
  target.scrollIntoView({ block: 'center', behavior: 'smooth' });
  (
    target.querySelector<HTMLElement>('input,select,textarea,button') ?? target
  ).focus();
}
export function CharacterWorkspace() {
  const store = useCharacterStore();
  useEffect(() => {
    void useParticipationStore.getState().load();
    const refresh = () => void useParticipationStore.getState().load();
    window.addEventListener('character-combat-saved', refresh);
    return () => window.removeEventListener('character-combat-saved', refresh);
  }, []);
  const [color, setColor] = useState<GameColor | null>(null),
    [retro, setRetro] = useState(false),
    [archiving, setArchiving] = useState<boolean | null>(null),
    [discarding, setDiscarding] = useState(false);
  const [archiveVisible, setArchiveVisible] = useState(false);
  const [alternate, setAlternate] = useState<Record<string, Ability>>({});
  const [pageSelection, setPageSelection] = useState<{
    characterId: string | null;
    page: string;
  } | null>(null);
  function setPage(next: string) {
    setPageSelection({
      characterId: useCharacterStore.getState().selectedId,
      page: next,
    });
  }
  const dashboardRef = useRef<HTMLDivElement>(null);
  function selectPage(next: string, focusPanel = true) {
    setPage(next);
    if (!focusPanel) return;
    requestAnimationFrame(() => {
      const dashboard = dashboardRef.current;
      const content = dashboard?.querySelector<HTMLElement>(
        `[data-bg-page="${next}"]`,
      );
      content?.focus({ preventScroll: true });
      dashboard?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    });
  }
  useEffect(() => {
    const show = (event: Event) =>
      setPageSelection({
        characterId: useCharacterStore.getState().selectedId,
        page: (event as CustomEvent<string>).detail,
      });
    window.addEventListener('bg-show-page', show);
    return () => window.removeEventListener('bg-show-page', show);
  }, []);
  const [portraitError, setPortraitError] = useState<string | null>(null);
  useEffect(() => {
    void useCharacterStore.getState().initialize();
    void useDiceStore.getState().load();
  }, []);
  const record = store.records.find((r) => r.id === store.selectedId);
  const page =
    pageSelection && pageSelection.characterId === record?.id
      ? pageSelection.page
      : record?.draft
        ? 'development'
        : 'weapons';
  const activeParticipation = useParticipationStore((s) =>
    s.entries.find((p) => p.characterId === record?.id && p.state === 'active'),
  );
  const rollCheck =
    (targets: string[]): ActorRollHandler =>
    (formula, label) => {
      if (!record || store.locked) return;
      const p = useParticipationStore
        .getState()
        .entries.find(
          (p) => p.characterId === record.id && p.state === 'active',
        );
      const c =
        record.draft && !p ? { ...record, sheet: record.draft } : record;
      void rollCharacter(
        c,
        p,
        String(Number(formula.slice(4))),
        label,
        targets,
      );
    };
  const sheet = record?.draft ?? record?.sheet;
  const effectiveSheet = sheet
    ? conditionSheet(sheet, record?.condition)
    : null;
  const derived = effectiveSheet ? deriveCharacter(effectiveSheet) : null;
  const equipped =
    sheet && record
      ? deriveEquipment(
          effectiveSheet ?? sheet,
          record.inventory ?? emptyInventory(),
          record.condition,
        )
      : null;
  const currentDefense = record
    ? characterCombatValues(
        record.draft && !activeParticipation
          ? { ...record, sheet: record.draft }
          : record,
        activeParticipation,
      )
    : null;
  const currentTT = currentDefense?.equipment.armor.some(
    (a) => a.value !== null,
  )
    ? currentDefense.tt
    : null;
  const editable = !!record?.draft && !store.locked;
  const journal = record ? characterJournal(record) : null;
  const experience = derived
    ? experienceProgress(derived.xp, derived.totalLevel)
    : null;
  const update = (next: CharacterSheet) => store.update(next);
  const change = <K extends keyof CharacterSheet>(
    key: K,
    value: CharacterSheet[K],
  ) => {
    if (sheet) update({ ...sheet, [key]: value });
  };
  const invalid = (path: string) =>
    !!derived?.issues.some((i) => i.path === path);
  const choiceChange = (c: Choice, values: string[]) => {
    if (!sheet) return;
    change(
      'levels',
      sheet.levels.map((l, i) =>
        i === c.level
          ? { ...l, choices: { ...l.choices, [c.key]: values } }
          : l,
      ),
    );
  };
  const setIdentity = <K extends keyof CharacterSheet['identity']>(
    key: K,
    value: CharacterSheet['identity'][K],
  ) => {
    if (sheet) change('identity', { ...sheet.identity, [key]: value });
  };
  const firstClass = sheet?.levels[0]?.classId;
  const visibleRecords = store.records.filter(
    (r) => archiveVisible || !r.archived,
  );
  const colorPreview =
    sheet && color ? withGameColor(sheet, color, retro) : null;
  const colorDerived = colorPreview ? deriveCharacter(colorPreview) : null;
  const health = record?.sheet ? conditionView(record) : null;
  const currentHp = health?.state.hp ?? sheet?.hpCurrent ?? null;
  const maxHp = health?.max ?? derived?.hpMax.value ?? null;
  const healthPercent =
    currentHp !== null && maxHp !== null && maxHp > 0
      ? Math.min(100, Math.max(0, (currentHp / maxHp) * 100))
      : 0;
  return (
    <div className="bg-workspace bg-session-workspace">
      <div className="bg-session-manager">
        {!!visibleRecords.length && (
          <label className="bg-session-picker">
            <span>Twoje postacie</span>
            <select
              aria-label="Wybierz postać BG"
              value={store.selectedId ?? ''}
              disabled={store.locked}
              onChange={(e) => store.select(e.target.value)}
            >
              {!visibleRecords.some((c) => c.id === store.selectedId) && (
                <option value={store.selectedId ?? ''} disabled>
                  {record
                    ? (record.draft ?? record.sheet)?.identity.name ||
                      'Postać w archiwum'
                    : 'Wybierz postać'}
                </option>
              )}
              {visibleRecords.map((c) => (
                <option key={c.id} value={c.id}>
                  {(c.draft ?? c.sheet)?.identity.name || 'Nowa postać'}
                  {c.archived ? ' · archiwum' : c.draft ? ' · szkic' : ''}
                </option>
              ))}
            </select>
          </label>
        )}
        <button
          className="secondary-button"
          disabled={store.status !== 'ready' || store.locked}
          onClick={() => void store.create()}
        >
          + Nowa postać
        </button>
        <label className="bg-inline">
          <input
            type="checkbox"
            checked={archiveVisible}
            onChange={(e) => setArchiveVisible(e.target.checked)}
          />{' '}
          Pokaż archiwum
        </label>
      </div>
      {store.status === 'loading' && <p role="status">Odczytywanie kart…</p>}
      {store.status === 'error' && (
        <button
          className="secondary-button"
          onClick={() => void store.initialize()}
        >
          Ponów odczyt
        </button>
      )}
      {store.error && (
        <div role="alert" className="error-panel bg-error">
          <p>{store.error}</p>
          {(store.locked || store.dirty.length > 0) && (
            <>
              <button
                className="secondary-button"
                onClick={() => void store.flush()}
              >
                Ponów zapis
              </button>
              <button
                className="secondary-button"
                onClick={() => void store.compareConflict()}
              >
                Odczytaj i porównaj aktualny zapis
              </button>
            </>
          )}
        </div>
      )}
      {activeParticipation && record?.draft && (
        <div className="bg-notice">
          <p>
            Rozwój zatwierdzisz po zakończeniu udziału w walce. Szkic zapisuje
            się niezależnie; nie musisz usuwać postaci z potyczki.
          </p>
          <button
            className="secondary-button"
            onClick={() => {
              const slot = activeParticipation.encounterId as SlotId;
              useEncounterStore.getState().selectSlot(slot);
              useCombatStore
                .getState()
                .selectActor(slot, activeParticipation.actorId);
              useBestiaryStore.getState().setView('combat');
              useNavigationStore.getState().navigate('gm');
            }}
          >
            Przejdź do udziału w potyczce
          </button>
        </div>
      )}
      {!record && store.status === 'ready' && (
        <p>
          Utwórz pierwszą postać. Jej karta będzie zapisywana lokalnie,
          niezależnie od potyczek.
        </p>
      )}
      {record && sheet && derived && (
        <>
          <div className="bg-toolbar">
            <div className="bg-save-status">
              <strong>
                {record.draft ? 'Szkic karty' : 'Zatwierdzona karta'}
              </strong>
              <p className="bg-small" role="status">
                {store.saving
                  ? 'Zapisywanie…'
                  : store.dirty.includes(record.id)
                    ? 'Oczekuje na zapis'
                    : `Zapis lokalny · wersja ${record.revision + 1}`}
              </p>
            </div>
            <div className="actor-actions">
              {record.draft ? (
                <>
                  <button
                    className="primary-button"
                    disabled={store.locked}
                    onClick={() => {
                      void store.publish().then((ok) => {
                        if (!ok && derived.issues[0])
                          reveal(derived.issues[0].path);
                      });
                    }}
                  >
                    Zatwierdź kartę
                  </button>
                  {record.sheet && (
                    <button
                      className="secondary-button"
                      disabled={store.locked}
                      onClick={() => setDiscarding(true)}
                    >
                      Odrzuć szkic
                    </button>
                  )}
                </>
              ) : (
                <button
                  className="primary-button"
                  disabled={store.locked}
                  onClick={() => {
                    store.edit();
                    selectPage('development');
                  }}
                >
                  Edytuj kartę / awansuj
                </button>
              )}
              <button
                className="secondary-button"
                disabled={store.locked}
                onClick={() => setArchiving(!record.archived)}
              >
                {record.archived ? 'Przywróć kartę' : 'Archiwizuj'}
              </button>
            </div>
          </div>
          {record.draft && (
            <p className="bg-notice">
              Szkic zapisuje się automatycznie, również gdy nie jest ukończony.
              „Zatwierdź kartę” przyjmuje cały zestaw wyborów i przeliczeń.
            </p>
          )}
          {record.draft && derived.issues.length > 0 && (
            <details className="bg-validation">
              <summary>Do uzupełnienia: {derived.issues.length}</summary>
              <ul>
                {derived.issues.map((i, k) => (
                  <li key={k}>
                    <button className="bg-link" onClick={() => reveal(i.path)}>
                      {i.message}
                    </button>
                  </li>
                ))}
              </ul>
            </details>
          )}
          <div className="bg-dashboard" ref={dashboardRef}>
            <div className="bg-dashboard-content">
              <section
                className={`bg-identity${record.draft ? '' : ' bg-identity--approved'}`}
                aria-label="Tożsamość postaci"
              >
                <div>
                  {sheet.identity.portrait && (
                    <img
                      className="bg-portrait"
                      src={sheet.identity.portrait}
                      alt="Portret postaci"
                    />
                  )}
                  {record.draft ? (
                    <label id="identity-name">
                      Imię / nazwa
                      <input
                        maxLength={300}
                        disabled={!editable}
                        value={sheet.identity.name}
                        aria-invalid={invalid('identity-name') || undefined}
                        onChange={(e) => setIdentity('name', e.target.value)}
                      />
                    </label>
                  ) : (
                    <h2 className="bg-character-name">
                      {sheet.identity.name || 'Postać BG'}
                    </h2>
                  )}
                  <p>
                    {Object.entries(derived.classLevels)
                      .filter(([, n]) => n)
                      .map(
                        ([id, n]) =>
                          `${classes[id as keyof typeof classes].label} ${n}`,
                      )
                      .join(' / ')}
                  </p>
                </div>
                {record.draft ? (
                  <label>
                    Kolor gry
                    <select
                      disabled={!editable}
                      value={sheet.rulesContext.gameColor}
                      onChange={(e) => {
                        setColor(e.target.value as GameColor);
                        setRetro(false);
                      }}
                    >
                      {COLORS.map((c) => (
                        <option value={c} key={c}>
                          {colorNames[c]}
                        </option>
                      ))}
                    </select>
                    <small title="Kolor wpływa na przyrosty PW, amunicję, odpoczynek i Fuksy.">
                      Neuroshima: Ostatnia Era, s. 201–203.
                    </small>
                  </label>
                ) : (
                  <span
                    className="bg-game-color"
                    title="Kolor zmienisz po wybraniu Edytuj kartę / awansuj."
                  >
                    Kolor gry:{' '}
                    <strong>{colorNames[sheet.rulesContext.gameColor]}</strong>
                  </span>
                )}
              </section>

              <div
                className="bg-session-vitals"
                aria-label="Bieżące wartości postaci"
              >
                <button
                  className="bg-session-health"
                  onClick={() => selectPage('health')}
                  title="Otwórz zdrowie i odpoczynek"
                >
                  <span className="bg-session-stat-label">
                    <Heart size={16} aria-hidden="true" /> Wytrzymałość
                  </span>
                  <strong>
                    {format(currentHp)} <small>/ {format(maxHp)} PW</small>
                  </strong>
                  <span className="bg-session-health-track" aria-hidden="true">
                    <span style={{ width: `${healthPercent}%` }} />
                  </span>
                </button>
                <button
                  className="bg-session-stat"
                  onClick={() => selectPage('overview')}
                  title="Otwórz pancerz i obronę"
                >
                  <span className="bg-session-stat-label">Obrona</span>
                  <strong>{format(currentTT)}</strong>
                  <small>
                    <Shield size={14} aria-hidden="true" /> TT
                  </small>
                </button>
                <div className="bg-session-stat bg-session-initiative">
                  <span className="bg-session-stat-label">Inicjatywa</span>
                  <RollValue
                    formula={`1k20${(derived.initiative.value ?? 0) >= 0 ? '+' : ''}${derived.initiative.value ?? 0}`}
                    label="Inicjatywa"
                    onRoll={
                      derived.initiative.value === null
                        ? undefined
                        : rollCheck(['dex', 'initiative'])
                    }
                    disabled={store.locked}
                  >
                    <strong>{signed(derived.initiative.value)}</strong>
                    <small>
                      <Dices size={14} aria-hidden="true" />{' '}
                      {derived.initiative.value === null
                        ? 'Brak danych'
                        : 'Rzuć'}
                    </small>
                  </RollValue>
                </div>
                <div className="bg-session-stat">
                  <span className="bg-session-stat-label">Szybkość</span>
                  <strong>
                    {format(equipped?.encumbrance.speed ?? derived.speed.value)}{' '}
                    <small>m</small>
                  </strong>
                  <small>ruch</small>
                </div>
              </div>
              <nav
                className="bg-session-tabs"
                role="tablist"
                aria-label="Sekcje karty postaci"
              >
                {sessionPages.map(({ id, label, Icon }, index) => (
                  <button
                    id={`bg-session-tab-${id}`}
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={page === id}
                    aria-controls={
                      id === 'weapons' || id === 'inventory'
                        ? 'bg-session-panel-equipment'
                        : id === 'health'
                          ? 'bg-session-panel-health bg-session-panel-care'
                          : id === 'downtime'
                            ? 'bg-session-panel-care'
                            : `bg-session-panel-${id}`
                    }
                    tabIndex={
                      page === id ||
                      (!sessionPages.some((p) => p.id === page) && index === 0)
                        ? 0
                        : -1
                    }
                    onClick={() => selectPage(id, false)}
                    onKeyDown={(event) => {
                      const next =
                        event.key === 'ArrowRight'
                          ? (index + 1) % sessionPages.length
                          : event.key === 'ArrowLeft'
                            ? (index + sessionPages.length - 1) %
                              sessionPages.length
                            : event.key === 'Home'
                              ? 0
                              : event.key === 'End'
                                ? sessionPages.length - 1
                                : null;
                      if (next === null) return;
                      event.preventDefault();
                      const target = sessionPages[next]!.id;
                      selectPage(target, false);
                      document
                        .getElementById(`bg-session-tab-${target}`)
                        ?.focus();
                    }}
                  >
                    <Icon size={18} aria-hidden="true" /> {label}
                  </button>
                ))}
              </nav>
              <CharacterLastRoll characterId={record.id} />
              <div
                hidden={page !== 'overview'}
                id="bg-session-panel-overview"
                data-bg-page="overview"
                tabIndex={-1}
                role="region"
                aria-label="Podsumowanie postaci"
              >
                <header className="bg-page-intro">
                  <h2>Podsumowanie postaci</h2>
                  <p>
                    Wartości do szybkiego odczytu; szczegóły testów i zdolności
                    są w osobnych sekcjach.
                  </p>
                </header>
                <div className="bg-sheet-grid bg-overview-grid">
                  <div className="bg-middle">
                    <section className="bg-section">
                      <h2>Wartości postaci</h2>
                      <div className="bg-stat-grid">
                        <div className="bg-stat">
                          <span>Poziom</span>
                          <strong>{derived.totalLevel}</strong>
                        </div>
                        <div className="bg-stat">
                          <span>Premia Biegłości</span>
                          <strong>+{derived.pb}</strong>
                        </div>
                        <Calculated
                          label="Maksymalne PW"
                          result={{
                            ...derived.hpMax,
                            value:
                              derived.hpMax.value === null
                                ? null
                                : Math.max(
                                    0,
                                    Math.floor(derived.hpMax.value) -
                                      (record.condition?.effects
                                        .filter((e) => e.target === 'hpMax')
                                        .reduce(
                                          (sum, e) => sum + e.amount,
                                          0,
                                        ) ?? 0),
                                  ),
                            components: [
                              ...derived.hpMax.components,
                              ...(record.condition?.effects
                                .filter((e) => e.target === 'hpMax')
                                .map((e) => ({
                                  source: e.source,
                                  value: -e.amount,
                                })) ?? []),
                            ],
                          }}
                        />
                        {record.sheet ? (
                          <div className="bg-stat">
                            <span>Aktualne PW</span>
                            <strong>
                              {conditionView(record).state.hp} /{' '}
                              {conditionView(record).max}
                            </strong>
                            <button
                              className="bg-link"
                              onClick={() => selectPage('health')}
                            >
                              Zdrowie i odpoczynki
                            </button>
                          </div>
                        ) : (
                          <NumberField
                            characterId={record.id}
                            id="hp-current"
                            label="Aktualne PW"
                            value={sheet.hpCurrent}
                            disabled={!editable}
                            integer
                            onChange={(n) => change('hpCurrent', n)}
                          />
                        )}
                        <Calculated
                          label="Szybkość"
                          result={{
                            ...derived.speed,
                            value: equipped?.encumbrance.speed ?? null,
                            conditions: [
                              ...derived.speed.conditions,
                              equipped?.encumbrance.label ?? '',
                            ],
                          }}
                          unit=" m"
                        />
                        <Calculated
                          label="Inicjatywa"
                          result={derived.initiative}
                          sign
                          onRoll={rollCheck(['dex', 'initiative'])}
                          rollLabel="Inicjatywa"
                        />
                        <Calculated
                          label="Pasywna Percepcja"
                          result={derived.perception}
                        />
                        <div className="bg-stat">
                          <span>Kości Wytrzymałości</span>
                          <strong>
                            {[
                              derived.hitDice[8]
                                ? `${derived.hitDice[8]}k8`
                                : '',
                              derived.hitDice[6]
                                ? `${derived.hitDice[6]}k6`
                                : '',
                            ]
                              .filter(Boolean)
                              .join(' + ')}
                          </strong>
                        </div>
                      </div>
                    </section>
                    <section className="bg-section">
                      <h2>Pancerz i obrona</h2>
                      {equipped?.armor.map((a) => (
                        <div className="bg-stat" key={a.label}>
                          <span>{a.label}</span>
                          <strong>TT {a.value ?? 'N/D'}</strong>
                        </div>
                      ))}
                      {equipped?.warnings.map((w) => (
                        <p className="bg-small" key={w}>
                          {w}
                        </p>
                      ))}
                      <p>
                        Wyszkolenie:{' '}
                        {[
                          ...new Set(
                            derived.grants
                              .filter((g) => g.target.startsWith('armor:'))
                              .map((g) => armorNames[g.target.slice(6)]),
                          ),
                        ].join(', ') || 'Brak'}
                      </p>
                    </section>
                    <section className="bg-section">
                      <h2>Ruch i udźwig</h2>
                      <Calculated
                        label="Udźwig użytkowy"
                        result={derived.carry}
                        unit=" kg"
                      />
                      <Calculated
                        label="Udźwig maksymalny"
                        result={derived.maxCarry}
                        unit=" kg"
                      />
                      <Calculated
                        label="Skok w dal z rozbiegu"
                        result={derived.longJump}
                        unit=" m"
                      />
                      <Calculated
                        label="Skok wzwyż z rozbiegu"
                        result={derived.highJump}
                        unit=" m"
                      />
                      <p className="bg-small">
                        Bez rozbiegu: połowa dystansu. Masa i obciążenie
                        widoczne w sekcji Ekwipunek i amunicja.
                      </p>
                      {derived.climb !== null && (
                        <p>
                          Wspinanie: {format(derived.climb)} m (Zwinność
                          szczura).
                        </p>
                      )}
                      {derived.swim !== null && (
                        <p>
                          Pływanie: {format(derived.swim)} m
                          (Człowiek-aligator).
                        </p>
                      )}
                    </section>
                  </div>
                  <aside className="bg-right">
                    <section className="bg-section">
                      <h2>Broń i wyszkolenie</h2>
                      <button
                        className="bg-link"
                        onClick={() => selectPage('weapons')}
                      >
                        Przejdź do broni ↓
                      </button>
                      <p>
                        {[
                          ...new Set(
                            derived.grants
                              .filter((g) => g.target.startsWith('weapon:'))
                              .map(
                                (g) =>
                                  weaponNames[g.target.slice(7)] ??
                                  'Improwizowana',
                              ),
                          ),
                        ].join(', ') || 'Brak'}
                      </p>
                      <p className="bg-small">
                        Broń biała, dystansowa, przedmioty pod ręką i magazynki
                        znajdziesz w sekcji Ekwipunek i amunicja.
                      </p>
                    </section>
                  </aside>
                </div>
              </div>
              <div
                hidden={page !== 'checks'}
                id="bg-session-panel-checks"
                data-bg-page="checks"
                tabIndex={-1}
                role="region"
                aria-label="Cechy i testy"
              >
                <header className="bg-page-intro">
                  <h2>Cechy i testy</h2>
                  <p>
                    Kliknij wartość, aby rzucić. Rozwiń wiersz, aby zobaczyć
                    składniki wyniku.
                  </p>
                </header>
                <div className="bg-checks-layout">
                  <section
                    className="bg-abilities"
                    aria-labelledby="bg-abilities-title"
                  >
                    <h2 id="bg-abilities-title">Cechy i umiejętności</h2>
                    {ABILITIES.map((a) => (
                      <section className="bg-ability" key={a}>
                        <div className="bg-ability-heading">
                          <h3>{abilityNames[a]}</h3>
                          <strong>
                            {derived.modifiers[a] === null ? (
                              format(derived.scores[a].value)
                            ) : (
                              <RollValue
                                formula={`1k20${derived.modifiers[a]! >= 0 ? '+' : ''}${derived.modifiers[a]}`}
                                label={`Test ${abilityNames[a]}`}
                                onRoll={rollCheck([a])}
                                disabled={store.locked}
                              >
                                {format(derived.scores[a].value)} (
                                {signed(derived.modifiers[a])})
                              </RollValue>
                            )}
                          </strong>
                        </div>
                        <Calculated
                          label="Rzut Obronny"
                          icon={<Shield size={16} aria-hidden="true" />}
                          rollLabel={`Rzut Obronny — ${abilityNames[a]}`}
                          onRoll={rollCheck([a, 'save'])}
                          result={derived.check('save:' + a, a)}
                          sign
                        />
                        {skills
                          .filter((s) => s.ability === a)
                          .map((s) => (
                            <div key={s.id} className="bg-skill">
                              <Calculated
                                label={s.label}
                                onRoll={rollCheck([
                                  alternate[s.id] ?? s.ability,
                                  'skill',
                                  'skill:' + s.id,
                                ])}
                                result={derived.check(
                                  'skill:' + s.id,
                                  alternate[s.id] ?? s.ability,
                                )}
                                sign
                              >
                                <div className="bg-check-context">
                                  <label>
                                    Cecha do tego testu
                                    <select
                                      value={alternate[s.id] ?? s.ability}
                                      onChange={(e) =>
                                        setAlternate({
                                          ...alternate,
                                          [s.id]: e.target.value as Ability,
                                        })
                                      }
                                    >
                                      {ABILITIES.map((a) => (
                                        <option key={a} value={a}>
                                          {abilityNames[a]}
                                        </option>
                                      ))}
                                    </select>
                                  </label>
                                  <ul>
                                    {derived.grants
                                      .filter(
                                        (g) => g.target === 'skill:' + s.id,
                                      )
                                      .map((g, i) => (
                                        <li key={i}>
                                          {g.source} · poziom {g.level} ·{' '}
                                          {g.rank === 2
                                            ? 'specjalizacja'
                                            : 'biegłość'}
                                        </li>
                                      ))}
                                  </ul>
                                </div>
                              </Calculated>
                            </div>
                          ))}
                      </section>
                    ))}
                  </section>
                  <div className="bg-checks-aside">
                    <section className="bg-section">
                      <h2>Narzędzia i instrumenty</h2>
                      {tools
                        .filter((t) => derived.rank('tool:' + t.id) > 0)
                        .map((t) => (
                          <Calculated
                            key={t.id}
                            label={t.label}
                            result={derived.check('tool:' + t.id, t.ability)}
                            onRoll={rollCheck([
                              t.ability,
                              'tool',
                              'tool:' + t.id,
                            ])}
                            sign
                          />
                        ))}
                      {[
                        ...new Set(
                          derived.grants
                            .filter((g) => g.target.startsWith('instrument:'))
                            .map((g) => g.target),
                        ),
                      ].map((t) => (
                        <Calculated
                          key={t}
                          label={t.slice(11)}
                          result={derived.check(t, 'cha')}
                          onRoll={rollCheck(['cha', 'tool', t])}
                          sign
                        />
                      ))}
                      <p className="bg-small">
                        Biegłość nie oznacza posiadania zestawu narzędzi. Dodaj
                        go do inwentarza.
                      </p>
                    </section>
                  </div>
                </div>
              </div>
              <div
                hidden={page !== 'abilities'}
                id="bg-session-panel-abilities"
                data-bg-page="abilities"
                tabIndex={-1}
                role="region"
                aria-label="Zdolności i sztuczki"
              >
                <header className="bg-page-intro">
                  <h2>Zdolności i sztuczki</h2>
                  <p>
                    Rozwiń opis, aby sprawdzić działanie i stronę podręcznika.
                  </p>
                </header>
                <section className="bg-section bg-rules-list">
                  {derived.rules.map((r, i) => {
                    const resources = resourcesForRule(
                      health?.resources ?? [],
                      r.id,
                    );
                    const description = (
                      <details className="bg-rule">
                        <summary>
                          <span className="bg-rule-heading">
                            <RuleIllustration ruleId={r.id} />
                            <span className="bg-rule-caption">
                              {r.label} <small>poz. {r.level}</small>
                            </span>
                          </span>
                        </summary>
                        <p>{r.summary}</p>
                        <small>Neuroshima: Ostatnia Era, s. {r.page}</small>
                      </details>
                    );
                    return resources.length ? (
                      <article className="bg-ability-card" key={r.id + '-' + i}>
                        {description}
                        <AbilityResources
                          record={record}
                          resources={resources}
                          disabled={store.locked || !!record.draft}
                        />
                      </article>
                    ) : (
                      <div key={r.id + '-' + i}>{description}</div>
                    );
                  })}
                  {unassignedResources(
                    health?.resources ?? [],
                    derived.rules,
                  ).map((res) => (
                    <article
                      className="bg-ability-card"
                      key={'resource-' + res.id}
                    >
                      <h3>{res.label}</h3>
                      <AbilityResources
                        record={record}
                        resources={[res]}
                        disabled={store.locked || !!record.draft}
                      />
                    </article>
                  ))}
                  <ManualResourceForm
                    key={record.id}
                    record={record}
                    disabled={store.locked || !!record.draft}
                  />
                  {activeParticipation && !record.draft && (
                    <details className="bg-rule">
                      <summary>Zdolności w aktywnej walce</summary>
                      <CombatAbilities
                        record={record}
                        participation={activeParticipation}
                        disabled={store.locked}
                      />
                    </details>
                  )}
                </section>
              </div>
              <div
                hidden={page !== 'health'}
                id="bg-session-panel-health"
                data-bg-page="health"
                tabIndex={-1}
                role="region"
                aria-label="Zdrowie i odpoczynek"
              >
                <ConditionPanel
                  key={record.id + '-condition'}
                  record={record}
                />
              </div>
              <div
                hidden={page !== 'health' && page !== 'downtime'}
                id="bg-session-panel-care"
                data-bg-page={page === 'downtime' ? 'downtime' : 'health'}
                tabIndex={-1}
                role="region"
                aria-label={
                  page === 'downtime' ? 'Postój' : 'Opieka i leczenie'
                }
              >
                <CarePanel
                  key={record.id + '-care'}
                  record={record}
                  mode={page === 'downtime' ? 'downtime' : 'health'}
                />
              </div>
              <div
                hidden={page !== 'inventory' && page !== 'weapons'}
                id="bg-session-panel-equipment"
                data-bg-page={page === 'weapons' ? 'weapons' : 'inventory'}
                tabIndex={-1}
                role="region"
                aria-label="Ekwipunek i amunicja"
              >
                <InventoryPanel
                  key={record.id}
                  record={record}
                  view={page === 'weapons' ? 'weapons' : 'inventory'}
                />
              </div>
              <div
                hidden={page !== 'development'}
                id="bg-session-panel-development"
                data-bg-page="development"
                tabIndex={-1}
                role="region"
                aria-label="Rozwój i dane"
              >
                <section className="bg-section" id="creation-method">
                  <h2>Tworzenie i rozwój</h2>
                  <div className="bg-form-grid">
                    <label>
                      Metoda cech
                      <select
                        disabled={!editable}
                        value={sheet.method}
                        onChange={(e) => {
                          const method = e.target
                            .value as CharacterSheet['method'];
                          const baseScores = { ...sheet.baseScores };
                          for (const ability of ABILITIES) {
                            const path = record.id + ':ability-' + ability;
                            const raw = store.invalid[path];
                            if (raw === undefined) continue;
                            const value =
                              raw.trim() === ''
                                ? null
                                : Number(raw.replace(',', '.'));
                            if (
                              value === null ||
                              (Number.isInteger(value) &&
                                value >= (method === 'points' ? 8 : 1) &&
                                value <= (method === 'points' ? 15 : 30))
                            ) {
                              store.invalidInput(path, null);
                              baseScores[ability] = value;
                            }
                          }
                          update({ ...sheet, method, baseScores });
                        }}
                      >
                        <option value="array-a">
                          Tablica: 15 / 14 / 13 / 12 / 10 / 8
                        </option>
                        <option value="array-b">
                          Tablica: 15 / 15 / 15 / 8 / 8 / 8
                        </option>
                        <option value="array-c">
                          Tablica: 15 / 12 / 12 / 12 / 12 / 10
                        </option>
                        <option value="points">Zakup za 27 punktów</option>
                        <option value="gm">Własne — decyzja MG</option>
                      </select>
                    </label>
                    <label id="origin">
                      Pochodzenie
                      <select
                        disabled={!editable}
                        value={sheet.originId}
                        aria-invalid={invalid('origin') || undefined}
                        onChange={(e) => change('originId', e.target.value)}
                      >
                        <option value="">Wybierz…</option>
                        {origins.map((o) => (
                          <option key={o.id} value={o.id}>
                            {o.label} (+1{' '}
                            {o.abilities.map((a) => abilityNames[a]).join(', ')}
                            )
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                  {sheet.method === 'gm' && (
                    <label>
                      Powód własnych wartości MG
                      <input
                        disabled={!editable}
                        value={sheet.methodReason}
                        maxLength={300}
                        onChange={(e) => change('methodReason', e.target.value)}
                      />
                    </label>
                  )}
                  {sheet.method === 'points' && (
                    <div
                      className={`bg-point-budget${derived.pointTotal !== null && derived.pointTotal > 27 ? ' bg-point-budget-over' : ''}`}
                    >
                      <strong aria-live="polite">
                        Wydano {format(derived.pointTotal)} / 27 punktów.
                      </strong>
                      {derived.pointTotal !== null &&
                        derived.pointTotal > 27 && (
                          <p role="alert">
                            Przekroczono budżet o {derived.pointTotal - 27} pkt.
                            Obniż wartości Cech przed zatwierdzeniem postaci.
                          </p>
                        )}
                      <p>
                        Cechy przed premiami: od 8 do 15. Pochodzenie i sztuczka
                        mogą podnieść wynik — na 1. poziomie maksymalnie do 18.
                      </p>
                      <span className="bg-small">
                        Neuroshima: Ostatnia Era, s. 48–50.
                      </span>
                    </div>
                  )}
                  {sheet.method in arrays && (
                    <p className="bg-small">
                      Rozdziel wartości tablicy pomiędzy cechy. Pole poniżej
                      zawiera bazę, przed premiami pochodzenia i rozwoju.
                    </p>
                  )}
                  <div className="bg-base-scores">
                    {ABILITIES.map((a) => (
                      <NumberField
                        key={a}
                        characterId={record.id}
                        id={'ability-' + a}
                        label={abilityNames[a] + ' — baza'}
                        value={sheet.baseScores[a]}
                        disabled={!editable}
                        min={sheet.method === 'points' ? 8 : 1}
                        max={sheet.method === 'points' ? 15 : 30}
                        integer
                        onChange={(v) =>
                          change('baseScores', { ...sheet.baseScores, [a]: v })
                        }
                      />
                    ))}
                  </div>
                  {ABILITIES.map((a) => (
                    <Calculated
                      key={a}
                      label={abilityNames[a] + ' — składniki'}
                      result={derived.scores[a]}
                    />
                  ))}
                  {sheet.levels.map((entry, i) => (
                    <details
                      className="bg-level"
                      open={i === 0 || undefined}
                      key={i}
                    >
                      <summary>
                        Poziom {i + 1} · {classes[entry.classId].label}
                        {derived.professionByClass[entry.classId]
                          ? ' · ' +
                            professions[
                              derived.professionByClass[entry.classId]!
                            ]!.label
                          : ''}
                      </summary>
                      <label id={`level-${i}-class`}>
                        Klasa na tym poziomie
                        <select
                          disabled={!editable}
                          value={entry.classId}
                          onChange={(e) =>
                            change(
                              'levels',
                              sheet.levels.map((l, j) =>
                                j === i
                                  ? {
                                      ...l,
                                      classId: e.target
                                        .value as typeof entry.classId,
                                    }
                                  : l,
                              ),
                            )
                          }
                        >
                          {CLASSES.map((c) => (
                            <option key={c} value={c}>
                              {classes[c].label}
                            </option>
                          ))}
                        </select>
                      </label>
                      <p className="bg-small">
                        Kolor tego awansu: {colorNames[entry.color]}. Przyrost
                        PW: {format(derived.hpHistory[i]!.value)} (
                        {derived.hpHistory[i]!.base} baza +{' '}
                        {format(derived.hpHistory[i]!.constitution)} KON{' '}
                        {i
                          ? ' + ' +
                            derived.hpHistory[i]!.colorModifier +
                            ' Kolor; minimum 0'
                          : ''}
                        ).
                      </p>
                      <div className="bg-form-grid">
                        {derived.choices
                          .filter((c) => c.level === i)
                          .map((c) => (
                            <ChoiceField
                              key={c.key}
                              choice={c}
                              values={entry.choices[c.key] ?? []}
                              disabled={!editable}
                              invalid={invalid(`level-${i}-${c.key}`)}
                              onChange={(v) => choiceChange(c, v)}
                              weaponModels={Array.from(
                                new Map(
                                  (record.inventory?.entries ?? [])
                                    .filter((e) => e.weapon)
                                    .map((e) => [
                                      e.weapon!.model,
                                      {
                                        id: e.weapon!.model,
                                        name: e.item.name,
                                      },
                                    ]),
                                ).values(),
                              )}
                            />
                          ))}
                      </div>
                      {Object.keys(entry.choices).some(
                        (k) =>
                          !derived.choices.some(
                            (c) => c.level === i && c.key === k,
                          ),
                      ) && (
                        <button
                          id={`level-${i}-stale`}
                          className="secondary-button"
                          disabled={!editable}
                          onClick={() =>
                            change(
                              'levels',
                              sheet.levels.map((l, j) =>
                                j === i
                                  ? {
                                      ...l,
                                      choices: Object.fromEntries(
                                        Object.entries(l.choices).filter(
                                          ([key]) =>
                                            derived.choices.some(
                                              (c) =>
                                                c.level === i && c.key === key,
                                            ),
                                        ),
                                      ),
                                    }
                                  : l,
                              ),
                            )
                          }
                        >
                          Usuń wybory, które przestały pasować do tego poziomu
                        </button>
                      )}
                    </details>
                  ))}
                  <div
                    className="actor-actions"
                    role="group"
                    aria-label="Poziomy postaci"
                  >
                    <button
                      className="secondary-button"
                      disabled={!editable || sheet.levels.length >= 12}
                      onClick={() =>
                        change('levels', [
                          ...sheet.levels,
                          {
                            classId:
                              sheet.levels.at(-1)?.classId ?? firstClass!,
                            color: sheet.rulesContext.gameColor,
                            contextRevision: sheet.rulesContext.revision,
                            choices: {},
                          },
                        ])
                      }
                    >
                      Dodaj kolejny poziom do szkicu
                    </button>
                    <button
                      className="secondary-button"
                      disabled={!editable || sheet.levels.length <= 1}
                      onClick={() =>
                        change('levels', sheet.levels.slice(0, -1))
                      }
                    >
                      Usuń ostatni poziom
                    </button>
                  </div>
                  <details>
                    <summary>Wymagania sztuczek</summary>
                    <p>
                      Dostępna lista każdego wyboru uwzględnia wymagania w
                      chwili jego nabycia, przed premią tej sztuczki. Katalog
                      zawiera {feats.length} sztuczki.
                    </p>
                    <p>Neuroshima: Ostatnia Era, s. 102–108.</p>
                  </details>
                </section>
                <section className="bg-section" id="xp">
                  <h2>Doświadczenie i dziennik</h2>
                  <label>
                    Tryb awansu
                    <select
                      disabled={!editable}
                      value={sheet.advancementMode}
                      onChange={(e) =>
                        change(
                          'advancementMode',
                          e.target.value as 'xp' | 'milestones',
                        )
                      }
                    >
                      <option value="milestones">
                        Kamienie milowe — decyzja MG
                      </option>
                      <option value="xp">Punkty Doświadczenia</option>
                    </select>
                  </label>
                  {experience && (
                    <div className="bg-experience" aria-live="polite">
                      <div>
                        <strong>{format(derived.xp)} PD</strong>
                        <span>
                          {experience.nextLevel
                            ? `Do poziomu ${experience.nextLevel}`
                            : 'Poziom 12 — maksimum'}
                        </span>
                      </div>
                      <progress
                        aria-label="Postęp doświadczenia do kolejnego poziomu"
                        max={100}
                        value={experience.percent}
                      />
                      <p>
                        {experience.target === null
                          ? 'Osiągnięto najwyższy poziom z podręcznika.'
                          : experience.remaining === 0
                            ? `Próg ${experience.target} PD osiągnięty. Możesz przygotować kolejny poziom.`
                            : `Brakuje ${experience.remaining} PD · próg ${experience.target} PD.`}
                      </p>
                      {sheet.advancementMode === 'milestones' && (
                        <span className="bg-small">
                          W trybie kamieni milowych o awansie decyduje MG.
                        </span>
                      )}
                    </div>
                  )}
                  {sheet.xp.map((e, i) => (
                    <div className="bg-form-grid" key={e.id}>
                      <NumberField
                        characterId={record.id}
                        id={'xp-' + e.id}
                        label="Zmiana PD"
                        value={e.amount}
                        disabled={!editable}
                        min={-100000}
                        integer
                        onChange={(n) => {
                          if (n !== null)
                            change(
                              'xp',
                              sheet.xp.map((x, j) =>
                                i === j ? { ...x, amount: n } : x,
                              ),
                            );
                        }}
                      />
                      <button
                        disabled={!editable}
                        className="secondary-button"
                        onClick={() =>
                          change(
                            'xp',
                            sheet.xp.filter((x) => x.id !== e.id),
                          )
                        }
                      >
                        Usuń wpis ze szkicu
                      </button>
                    </div>
                  ))}
                  <button
                    disabled={!editable}
                    className="secondary-button"
                    onClick={() =>
                      change('xp', [
                        ...sheet.xp,
                        { id: crypto.randomUUID(), amount: 0, reason: '' },
                      ])
                    }
                  >
                    Dodaj wpis PD
                  </button>
                  <div className="bg-form-grid">
                    {(['notes', 'contacts', 'discoveries'] as const).map(
                      (key, i) => (
                        <label key={key}>
                          {
                            [
                              'Notatki',
                              'Znajomi',
                              'Pierwsze spotkania i nowe obszary',
                            ][i]
                          }
                          <textarea
                            disabled={store.locked || record.archived}
                            maxLength={20000}
                            rows={5}
                            value={journal?.[key] ?? ''}
                            onChange={(e) =>
                              store.updateJournal(key, e.target.value)
                            }
                          />
                        </label>
                      ),
                    )}
                  </div>
                  <p className="bg-small">
                    Notatki zapisują się automatycznie, niezależnie od edycji
                    rozwoju postaci.
                  </p>
                </section>
                <section className="bg-section">
                  <h2>Opis postaci</h2>
                  <div className="bg-form-grid">
                    <NumberField
                      characterId={record.id}
                      id="age"
                      label="Wiek (lata)"
                      value={sheet.identity.age}
                      disabled={!editable}
                      max={1000}
                      integer
                      onChange={(n) => setIdentity('age', n)}
                    />
                    <NumberField
                      characterId={record.id}
                      id="height"
                      label="Wzrost (cm)"
                      value={sheet.identity.height}
                      disabled={!editable}
                      max={1000}
                      onChange={(n) => setIdentity('height', n)}
                    />
                    <NumberField
                      characterId={record.id}
                      id="body-weight"
                      label="Masa ciała (kg)"
                      value={sheet.identity.bodyWeight}
                      disabled={!editable}
                      max={10000}
                      onChange={(n) => setIdentity('bodyWeight', n)}
                    />
                    <label>
                      Wielkość
                      <select
                        disabled={!editable}
                        value={sheet.identity.size}
                        onChange={(e) =>
                          setIdentity(
                            'size',
                            e.target
                              .value as CharacterSheet['identity']['size'],
                          )
                        }
                      >
                        {(
                          [
                            'tiny',
                            'small',
                            'medium',
                            'large',
                            'huge',
                            'gargantuan',
                          ] as const
                        ).map((s, i) => (
                          <option key={s} value={s}>
                            {
                              [
                                'Malutki',
                                'Mały',
                                'Średni',
                                'Duży',
                                'Wielki',
                                'Olbrzymi',
                              ][i]
                            }
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                  <label>
                    Wygląd i historia
                    <textarea
                      maxLength={20000}
                      rows={4}
                      disabled={!editable}
                      value={sheet.identity.description}
                      onChange={(e) =>
                        setIdentity('description', e.target.value)
                      }
                    />
                  </label>
                  <label>
                    Portret lokalny (PNG, JPEG lub WebP, do 1 MB)
                    <input
                      disabled={!editable}
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        if (
                          file.size > 1000000 ||
                          !['image/png', 'image/jpeg', 'image/webp'].includes(
                            file.type,
                          )
                        ) {
                          setPortraitError(
                            'Wybierz PNG, JPEG lub WebP o wielkości do 1 MB.',
                          );
                          return;
                        }
                        const reader = new FileReader();
                        const selectedId = record.id;
                        reader.onload = () => {
                          const current = useCharacterStore.getState();
                          const c = current.records.find(
                            (c) => c.id === selectedId,
                          );
                          if (current.selectedId === selectedId && c?.draft) {
                            current.update({
                              ...c.draft,
                              identity: {
                                ...c.draft.identity,
                                portrait: String(reader.result),
                              },
                            });
                            setPortraitError(null);
                          }
                        };
                        reader.readAsDataURL(file);
                      }}
                    />
                  </label>
                  {portraitError && <p role="alert">{portraitError}</p>}
                  {sheet.identity.portrait && (
                    <button
                      disabled={!editable}
                      className="secondary-button"
                      onClick={() => setIdentity('portrait', '')}
                    >
                      Usuń portret ze szkicu
                    </button>
                  )}
                </section>
                {editable &&
                  derived.issues.some(
                    (issue) => issue.path === 'overrides',
                  ) && (
                    <section className="bg-section" id="overrides">
                      <h2>Niepoprawny zapis ze starszej wersji</h2>
                      <p>
                        Szkic zawiera niepoprawny modyfikator. Usuń wadliwy
                        wpis, aby móc zatwierdzić kartę. Usunięcie dotyczy
                        wyłącznie wybranego zapisu w szkicu.
                      </p>
                      {sheet.overrides.map((entry, index) => (
                        <div className="bg-stat" key={`${entry.id}-${index}`}>
                          <p>
                            <strong>{entry.target}</strong> · {entry.value} ·{' '}
                            {entry.reason.trim() || 'Brak opisu'}
                          </p>
                          <button
                            type="button"
                            className="secondary-button"
                            onClick={() =>
                              change(
                                'overrides',
                                sheet.overrides.filter((_, i) => i !== index),
                              )
                            }
                          >
                            Usuń zapis ze szkicu
                          </button>
                        </div>
                      ))}
                    </section>
                  )}
              </div>
            </div>
          </div>
        </>
      )}
      {color !== null && colorPreview && colorDerived && sheet && derived && (
        <Modal title="Zmiana Koloru gry" onClose={() => setColor(null)}>
          <p>
            {colorNames[sheet.rulesContext.gameColor]} → {colorNames[color]}.
            Zmiana dotyczy tej karty, niezależnie od kalkulatora cen.
          </p>
          <label className="bg-inline">
            <input
              type="checkbox"
              checked={retro}
              onChange={(e) => setRetro(e.target.checked)}
            />{' '}
            Przelicz także historię przyrostów PW
          </label>
          <p>
            Maksymalne PW: {format(derived.hpMax.value)} →{' '}
            {format(colorDerived.hpMax.value)}. Aktualne PW pozostaną{' '}
            {format(record?.condition?.hp ?? sheet.hpCurrent)}.
          </p>
          <p>
            {retro
              ? 'Historia przyrostów po pierwszym poziomie przyjmie nowy Kolor.'
              : 'Wcześniejsze awanse pozostaną bez zmian; nowy Kolor będzie zapisany przy kolejnych.'}
          </p>
          <p className="bg-small">
            Zmiany odpoczynków, Fuksów, zdrowia, krytyków i amunicji zostaną
            obsłużone w kolejnych aktualizacjach. Zmiana nie usuwa chorób ani
            obrażeń.
          </p>
          <button
            className="primary-button"
            onClick={() => {
              update(colorPreview);
              setColor(null);
            }}
          >
            Przyjmij zmianę w szkicu
          </button>
        </Modal>
      )}
      {archiving !== null && (
        <Modal
          title={archiving ? 'Archiwizacja karty' : 'Przywrócenie karty'}
          onClose={() => setArchiving(null)}
        >
          <p>Dane karty i jej historia pozostają zapisane.</p>
          <button
            className="primary-button"
            onClick={() =>
              void store.archive(archiving).then((ok) => {
                if (ok) setArchiving(null);
              })
            }
          >
            Potwierdź
          </button>
        </Modal>
      )}
      {discarding && (
        <Modal
          title="Odrzucić szkic zmian?"
          onClose={() => setDiscarding(false)}
        >
          <p>
            Wrócisz do ostatniej zatwierdzonej karty. Niezatwierdzone zmiany
            zostaną odrzucone.
          </p>
          <button
            className="primary-button"
            onClick={() =>
              void store.discard().then((ok) => {
                if (ok) setDiscarding(false);
              })
            }
          >
            Odrzuć szkic
          </button>
        </Modal>
      )}
      {store.conflict && record && (
        <Modal
          title="Porównanie wersji karty"
          onClose={() => useCharacterStore.setState({ conflict: null })}
        >
          <p>
            Aktualny zapis: wersja {store.conflict.revision + 1}. Twój szkic
            pochodzi z wersji {record.revision + 1}. Zatwierdzona karta z bazy
            pozostanie zachowana.
          </p>
          {store.conflictIsInventory && (
            <div className="bg-notice">
              <p>
                Odczytane zdrowie: PW {conditionView(store.conflict).state.hp},
                Zranienia {conditionView(store.conflict).state.injury},
                Wyczerpanie {conditionView(store.conflict).exhaustion}.
                Inwentarz: {store.conflict.inventory?.entries.length ?? 0}{' '}
                pozycji. Przyjęcie tego stanu zakończy oczekiwanie na poprzednią
                operację; przygotuj ją ponownie tylko jeśli nie została już
                zapisana.
              </p>
              {store.conflict.inventory?.entries.map((e) => (
                <p key={e.id}>
                  {e.item.name}: {e.quantityMilli / 1000} {e.unit}
                  {e.magazine
                    ? ` · magazynek ${e.magazine.rounds.reduce((sum, l) => sum + l.count, 0)}/${e.magazine.capacity}`
                    : ''}
                </p>
              ))}
            </div>
          )}
          <div className="bg-conflict">
            <div>
              <h3>Aktualny zapis</h3>
              <SheetSummary
                sheet={{
                  ...(store.conflict.draft ?? store.conflict.sheet)!,
                  ...characterJournal(store.conflict),
                }}
              />
            </div>
            <div>
              <h3>Twój szkic</h3>
              <SheetSummary
                sheet={{
                  ...(record.draft ?? record.sheet)!,
                  ...characterJournal(record),
                }}
              />
            </div>
          </div>
          <button className="primary-button" onClick={store.acceptRebase}>
            {store.conflictIsInventory
              ? 'Przyjmij odczytany stan postaci'
              : 'Przenieś mój szkic na aktualną wersję do ponownej kontroli'}
          </button>
        </Modal>
      )}
    </div>
  );
}
function SheetSummary({ sheet }: { sheet: CharacterSheet }) {
  return (
    <div>
      {sheet.identity.portrait && (
        <img
          className="bg-portrait"
          src={sheet.identity.portrait}
          alt="Portret"
        />
      )}
      <dl>
        {describeSheet(sheet).map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
