import { useMemo, useState } from 'react';
import { Backpack, Coins, PackageCheck } from 'lucide-react';
import { ItemIllustration } from '../equipment/ItemIllustration';
import type { Item } from '../../domain/item';
import type { ClassId } from '../../domain/character/model';
import type {
  Inventory,
  InventoryAction,
} from '../../domain/character/inventoryModel';
import { classes } from '../../domain/character/catalog';
import { starterPack } from '../../domain/character/inventoryCatalog';
import {
  starterComplete,
  starterEquipmentAction,
  starterOptions,
  starterRules,
  type StarterChoice,
} from '../../domain/character/starterEquipment';

export function StarterEquipmentPanel({
  classId,
  inventory,
  items,
  disabled,
  onPreview,
}: {
  classId: ClassId;
  inventory: Inventory;
  items: Item[];
  disabled: boolean;
  onPreview: (action: InventoryAction, summary: string) => void;
}) {
  const [choice, setChoice] = useState<StarterChoice>('equipment');
  const [selectedId, setSelectedId] = useState('');
  const [lighterId, setLighterId] = useState('');
  const [error, setError] = useState('');
  // Old cards may already have individual starter items granted manually.
  const [skipped, setSkipped] = useState<string[]>([]);
  const rule = starterRules[classId];
  const pack = useMemo(() => starterPack(classId), [classId]);
  const hasPack = inventory.starterClaims.includes('initial-equipment');
  const choices = starterOptions(items, classId);
  const { proposed, validation } = useMemo(() => {
    try {
      return {
        proposed: starterEquipmentAction(
          inventory,
          items,
          classId,
          choice,
          selectedId,
          lighterId,
        ),
        validation: '',
      };
    } catch (e) {
      return { proposed: null, validation: (e as Error).message };
    }
  }, [inventory, items, classId, choice, selectedId, lighterId]);
  if (starterComplete(inventory)) return null;
  const group = new Map<string, { item: Item; quantity: number }>();
  for (const e of proposed?.entries ?? []) {
    const key = e.catalogId ?? 'starter-pack';
    const existing = group.get(key);
    group.set(key, {
      item: e.item,
      quantity: (existing?.quantity ?? 0) + e.quantityMilli / 1000,
    });
  }
  function submit() {
    try {
      const action = starterEquipmentAction(
        inventory,
        items,
        classId,
        choice,
        selectedId,
        lighterId,
      );
      action.entries = action.entries.filter(
        (e) => !hasPack || !skipped.includes(e.catalogId ?? 'starter-pack'),
      );
      const lines = action.entries.map(
        (e) => `${e.item.name} × ${e.quantityMilli / 1000}`,
      );
      onPreview(
        action,
        `Sprzęt początkowy — ${classes[classId].label}. ${choice === 'gamble' ? `${rule.gamble} G do samodzielnych zakupów. ` : 'Wariant przedmiotów. '}${lines.length ? 'Dodaj: ' + lines.join(', ') + '.' : 'Wszystkie przedmioty zostały już przyznane.'} Aplikacja nie śledzi wydanych gambli; wartość zakupów początkowych obliczasz samodzielnie.`,
      );
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <details className="inventory-starter" open={!hasPack}>
      <summary>
        <Backpack aria-hidden="true" />
        Sprzęt początkowy · {classes[classId].label}
      </summary>
      <p>
        {hasPack
          ? 'Plecak został już przyznany. Uzupełnij pozostały sprzęt albo wybierz gamble.'
          : `${pack.item.name} (${pack.weightMg! / 1_000_000} kg) otrzymujesz w obu wariantach.`}
      </p>
      <fieldset disabled={disabled}>
        <legend>Wybierz wariant startowy</legend>
        <div className="inventory-starter-options">
          <label>
            <input
              type="radio"
              name="starter-variant"
              checked={choice === 'equipment'}
              onChange={() => setChoice('equipment')}
            />
            <PackageCheck aria-hidden="true" />
            <span>Sprzęt z podręcznika</span>
          </label>
          <label>
            <input
              type="radio"
              name="starter-variant"
              checked={choice === 'gamble'}
              onChange={() => setChoice('gamble')}
            />
            <Coins aria-hidden="true" />
            <span>{rule.gamble} G na własne zakupy</span>
          </label>
        </div>
        {rule.choice && (
          <label className="inventory-starter-choice">
            {rule.choice === 'instrument'
              ? 'Instrument do 50 G — w obu wariantach'
              : 'Zestaw narzędzi — w obu wariantach'}
            <select
              value={selectedId}
              onChange={(e) => setSelectedId(e.target.value)}
            >
              <option value="">Wybierz…</option>
              {choices.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
        )}
        {classId === 'cwaniak' && choice === 'equipment' && (
          <label className="inventory-starter-choice">
            Zapalniczka
            <select
              value={lighterId}
              onChange={(e) => setLighterId(e.target.value)}
            >
              <option value="">Wybierz…</option>
              {items
                .filter((i) =>
                  ['Zapalniczka plastikowa', 'Zapalniczka Zippo'].includes(
                    i.name,
                  ),
                )
                .map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name}
                  </option>
                ))}
            </select>
          </label>
        )}
        {validation ? (
          <p>{validation}</p>
        ) : (
          <>
            {hasPack && (
              <p>
                Odznacz przedmioty, które zostały wcześniej przyznane ręcznie.
              </p>
            )}
            <ul className="inventory-starter-list">
              {[...group].map(([key, { item, quantity }]) => (
                <li key={key}>
                  {hasPack && (
                    <input
                      type="checkbox"
                      aria-label={`Dodaj ${item.name}`}
                      checked={!skipped.includes(key)}
                      onChange={(e) =>
                        setSkipped(
                          e.target.checked
                            ? skipped.filter((id) => id !== key)
                            : [...skipped, key],
                        )
                      }
                    />
                  )}
                  <ItemIllustration item={item} size="small" />
                  <span>
                    {item.name}
                    {quantity > 1 ? ` × ${quantity}` : ''}
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}
        <p className="inventory-starter-help">
          Aplikacja nie śledzi wydanych gambli. Wartość zakupów początkowych
          obliczasz samodzielnie.
        </p>
        {error && <p role="alert">{error}</p>}
        <button
          type="button"
          disabled={disabled || !!validation}
          onClick={submit}
        >
          Przyznaj wybrany wariant
        </button>
      </fieldset>
      <small>Neuroshima: Ostatnia Era, s. {rule.page}.</small>
    </details>
  );
}
