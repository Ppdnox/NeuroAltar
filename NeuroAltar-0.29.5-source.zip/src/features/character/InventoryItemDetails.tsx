import {
  BookOpen,
  CircleDot,
  Coins,
  Crosshair,
  Layers3,
  NotebookPen,
  Percent,
  Ruler,
  Tags,
  Weight,
} from 'lucide-react';
import type { InventoryEntry } from '../../domain/character/inventoryModel';
import {
  formatMarketRange,
  type calculateMarketValues,
} from '../../domain/market';
import { inventoryDetails } from './inventoryDetails';
import { inventorySources } from './inventorySources';

const fieldIcons = {
  magazine: Layers3,
  range: Ruler,
  weight: Weight,
  damage: Crosshair,
  ammo: CircleDot,
};

export function InventoryItemDetails({
  entry,
  market,
  error,
}: {
  entry: InventoryEntry;
  market: ReturnType<typeof calculateMarketValues> | null;
  error: string;
}) {
  const { fields, description, properties } = inventoryDetails(entry);
  const sources = inventorySources(entry);
  return (
    <details className="inventory-item-details">
      <summary>Opis, cena i źródło</summary>
      <div className="item-details-content">
        {fields.length > 0 && (
          <dl className="item-details-facts">
            {fields.map((field, index) => {
              const Icon = fieldIcons[field.kind];
              return (
                <div key={index} className="item-details-fact">
                  <dt>
                    <Icon aria-hidden="true" />
                    {field.label}
                  </dt>
                  <dd>{field.value}</dd>
                </div>
              );
            })}
          </dl>
        )}
        {description && (
          <p className="item-details-description">{description}</p>
        )}
        {properties.length > 0 && (
          <div className="item-details-properties">
            <h5>
              <Tags aria-hidden="true" />
              Właściwości
            </h5>
            <ul>
              {properties.map((property, index) => (
                <li key={index}>{property}</li>
              ))}
            </ul>
          </div>
        )}
        {entry.notes.trim() && (
          <div className="item-details-notes">
            <h5>
              <NotebookPen aria-hidden="true" />
              Notatki
            </h5>
            <p>{entry.notes}</p>
          </div>
        )}
        <dl className="item-details-market">
          <div className="item-details-fact">
            <dt>
              <Coins aria-hidden="true" />
              Wycena / {entry.unit}
            </dt>
            <dd>{formatMarketRange(market?.price ?? null, 'G')}</dd>
          </div>
          <div className="item-details-fact">
            <dt>
              <Percent aria-hidden="true" />
              Dostępność
            </dt>
            <dd>{formatMarketRange(market?.availability ?? null, '%')}</dd>
          </div>
        </dl>
        {error && <p role="alert">{error}</p>}
        {sources.length > 0 && (
          <div className="item-details-source">
            <BookOpen aria-hidden="true" />
            <div>
              <h5>Źródło</h5>
              {sources.map((source) => (
                <p key={source}>{source}</p>
              ))}
            </div>
          </div>
        )}
      </div>
    </details>
  );
}
