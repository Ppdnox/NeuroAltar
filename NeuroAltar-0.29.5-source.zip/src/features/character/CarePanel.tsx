import {
  medicalAidProfile,
  resuscitationDC,
} from '../../domain/character/downtime';
import { inventoryWeight } from '../../domain/medicineWeight';
import { useEffect, useRef } from 'react';
import {
  BookOpen,
  Check,
  ChefHat,
  Clock3,
  Hammer,
  HeartPulse,
  PackagePlus,
  Pill,
  Plus,
  Sparkles,
  Wrench,
  Zap,
  type LucideIcon,
} from 'lucide-react';
import './care.css';
import { create } from 'zustand';
import { ZodError } from 'zod';
import { useCharacterStore } from '../../stores/characterStore';
import type { Character, Ability } from '../../domain/character/model';
import { abilityNames } from '../../domain/character/model';
import {
  conditionView,
  previewCondition,
  ConditionError,
} from '../../domain/character/condition';
import type { ConditionAction } from '../../domain/character/conditionModel';
import {
  emptyCare,
  diseaseKinds,
  phobiaKinds,
  type CareCommand,
} from '../../domain/character/careModel';
import {
  diseaseNames,
  medicineNames,
  phobiaNames,
  diseaseEffects,
  nutritionNeeds,
} from '../../domain/character/care';
import {
  emptyDowntime,
  type DowntimeCommand,
} from '../../domain/character/downtimeModel';
import { newInventoryEntry } from '../../domain/character/inventoryModel';
import {
  customItem,
  catalogEntry,
} from '../../domain/character/inventoryCatalog';
import {
  skills,
  tools,
  weaponCategories,
  weaponNames,
  armorNames,
} from '../../domain/character/catalog';
import { useEquipmentStore } from '../../stores/equipmentStore';
import { itemSchema } from '../../domain/item';
type Mode = CareCommand['kind'] | DowntimeCommand['kind'];
type Fields = Record<string, string>;
type Review = { action: ConditionAction; revision: number; lines: string[] };
const useDialog = create<{
  owner: string | null;
  mode: Mode | null;
  fields: Fields;
  review: Review | null;
  error: string | null;
  set: (
    p: Partial<{
      owner: string | null;
      mode: Mode | null;
      fields: Fields;
      review: Review | null;
      error: string | null;
    }>,
  ) => void;
}>((set) => ({
  owner: null,
  mode: null,
  fields: {},
  review: null,
  error: null,
  set,
}));
function Dialog({
  children,
  cancel,
}: {
  children: React.ReactNode;
  cancel: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const el = ref.current;
    el?.showModal();
    return () => el?.close();
  }, []);
  return (
    <dialog
      ref={ref}
      className="bg-dialog condition-dialog"
      onCancel={(e) => {
        e.preventDefault();
        cancel();
      }}
    >
      {children}
    </dialog>
  );
}
export function CarePanel({
  record,
  mode = 'health',
}: {
  record: Character;
  mode?: 'health' | 'downtime';
}) {
  const equipment = useEquipmentStore();
  useEffect(() => {
    if (!useEquipmentStore.getState().loaded)
      void useEquipmentStore.getState().load();
  }, []);
  const store = useCharacterStore(),
    dialog = useDialog(),
    v = conditionView(record),
    s = v.state,
    c = s.care ?? { ...emptyCare(), day: Math.floor(s.worldMinutes / 1440) },
    d = s.downtime ?? emptyDowntime(),
    f = dialog.fields,
    entries = record.inventory?.entries ?? [];
  const disabled =
      store.locked || !record.sheet || !!record.draft || record.archived,
    marker = record.id + ':care-dialog';
  const owned = dialog.owner === record.id;
  const close = () => {
    if (store.locked) return;
    store.invalidInput(marker, null);
    dialog.set({ owner: null, mode: null, review: null, error: null });
  };
  const open = (mode: Mode, fields: Fields = {}) => {
    store.invalidInput(marker, 'Dokończ formularz zdrowia lub postoju.');
    dialog.set({
      owner: record.id,
      mode,
      fields: { id: crypto.randomUUID(), ...fields },
      review: null,
      error: null,
    });
  };
  const set = (key: string, val: string) => {
    const item =
      key === 'catalogId' ? equipment.items.find((e) => e.id === val) : null;
    dialog.set({
      fields: {
        ...f,
        ...(item
          ? { price: String(item.basePrice?.min ?? 0), label: item.name }
          : {}),
        [key]: val,
      },
      review: null,
      error: null,
    });
  };
  const input = (key: string, label: string, placeholder = '') => (
    <label key={key}>
      {label}
      <input
        id={'care-' + key}
        value={f[key] ?? ''}
        placeholder={placeholder}
        onChange={(e) => set(key, e.target.value)}
      />
    </label>
  );
  const select = (
    key: string,
    label: string,
    options: Record<string, string>,
  ) => (
    <label key={key}>
      {label}
      <select
        id={'care-' + key}
        value={f[key] ?? ''}
        onChange={(e) => set(key, e.target.value)}
      >
        <option value="">Wybierz</option>
        {Object.entries(options).map(([id, name]) => (
          <option key={id} value={id}>
            {name}
          </option>
        ))}
      </select>
    </label>
  );
  const check = (key: string, label: string) => (
    <label className="bg-inline">
      <input
        type="checkbox"
        checked={f[key] === 'yes'}
        onChange={(e) => set(key, e.target.checked ? 'yes' : 'no')}
      />
      {label}
    </label>
  );
  const inventoryOptions = Object.fromEntries(
    entries.map((e) => [
      e.id,
      e.item.name + ' — ' + e.quantityMilli / 1000 + ' ' + e.unit,
    ]),
  );
  const num = (key: string, min = 0, max = 1e9, integer = true) => {
    const raw = f[key]?.trim().replace(',', '.');
    if (!raw || !/^[-+]?\d+(\.\d+)?$/.test(raw))
      throw new ConditionError(
        key,
        'Podaj liczbę w polu „' + (labels[key] ?? key) + '”.',
      );
    const n = Number(raw);
    if (
      !Number.isFinite(n) ||
      n < min ||
      n > max ||
      (integer && !Number.isInteger(n))
    )
      throw new ConditionError(
        key,
        'Pole „' +
          (labels[key] ?? key) +
          '”: zakres ' +
          min +
          '–' +
          max +
          (integer ? ', liczba całkowita.' : '.'),
      );
    return n;
  };
  const optional = (key: string) =>
    f[key]?.trim() ? num(key, -100, 200) : null;
  const inventoryPick = (key = 'entryId', label = 'Środek / materiał') =>
    select(key, label, inventoryOptions);
  const material = () => [
    {
      id: f.materialId ?? '',
      quantity: Math.round(num('quantity', 0.001, 1e6, false) * 1000),
      valueGb: num('materialValue', 0, 1e6, false),
    },
  ];
  const fail = (e: unknown) => {
    const field =
      e instanceof ConditionError
        ? e.field
        : e instanceof ZodError
          ? String(e.issues[0]?.path.at(-1) ?? '')
          : '';
    dialog.set({
      error:
        e instanceof ZodError
          ? 'Uzupełnij wymagane pole: ' + (labels[field] ?? field)
          : e instanceof Error
            ? e.message
            : String(e),
    });
    setTimeout(() => {
      const el = document.getElementById('care-' + field);
      el?.focus();
      el?.scrollIntoView({ block: 'center' });
    }, 0);
  };
  function submit() {
    try {
      const id = f.id!,
        mode = dialog.mode!;
      let action: ConditionAction;
      const care = (command: CareCommand): ConditionAction => ({
          type: 'care',
          command,
        }),
        post = (command: DowntimeCommand): ConditionAction => ({
          type: 'downtime',
          command,
        });
      switch (mode) {
        case 'start': {
          const group = f.group === 'phobia' ? 'phobia' : 'disease',
            choice = num('choice', -1, 7);
          let medicine = null;
          if (group === 'disease' && choice >= 0) {
            medicine = newInventoryEntry(
              customItem(medicineNames[diseaseKinds[choice]!]!),
            );
            medicine.catalogId = null;
            medicine.quantityMilli = 3000;
            medicine.unit = 'dawka';
            medicine.item.description =
              'Neuroshima: Ostatnia Era, s. 109, 132. Dawki początkowe.';
          }
          action = care({
            kind: mode,
            group,
            choice,
            ability: f.ability as Ability,
            id,
            medicine,
          });
          break;
        }
        case 'disease':
          action = care({
            kind: mode,
            id,
            disease: f.disease as (typeof diseaseKinds)[number],
            details: f.details ?? '',
            onsetMinutes: num('onsetMinutes'),
          });
          break;
        case 'diseaseCheck':
          action = care({
            kind: mode,
            id,
            natural: num('natural', 1, 20),
            total: num('total', -100, 200),
            chronicRoll: f.chronicRoll ? num('chronicRoll', 1, 8) : null,
          });
          break;
        case 'medicine':
          action = care({
            kind: mode,
            id,
            entryId: f.entryId ?? '',
            doses: num('doses', 1, 100),
            treatment: f.treatment as 'daily',
            sideSave: optional('sideSave'),
          });
          break;
        case 'bleeding':
          action = care({
            kind: mode,
            id,
            mode: f.bleedingMode as 'start',
            total: optional('total'),
            tools: f.tools === 'yes',
          });
          break;
        case 'phobia':
          action = care({
            kind: mode,
            id,
            phobia: f.phobia as (typeof phobiaKinds)[number],
          });
          break;
        case 'phobiaAway':
          action = care({ kind: mode, id });
          break;
        case 'phobiaCheck':
          action = care({
            kind: mode,
            id,
            total: num('total', -100, 200),
            turn: f.turn ?? '',
            trigger: true,
          });
          break;
        case 'day':
          action = care({
            kind: mode,
            id: f.dayLabel ?? '',
            foodMg: Math.round(num('food', 0, 1000, false) * 1e6),
            waterMl: Math.round(num('water', 0, 1000, false) * 1000),
            hungerSave: optional('hungerSave'),
            foodEntryId: f.foodEntryId || null,
            foodQuantity: f.foodEntryId
              ? Math.round(num('foodQuantity', 0.001, 1e6, false) * 1000)
              : 0,
            waterEntryId: f.waterEntryId || null,
            waterQuantity: f.waterEntryId
              ? Math.round(num('waterQuantity', 0.001, 1e6, false) * 1000)
              : 0,
          });
          break;
        case 'environment':
          action = care({
            kind: mode,
            id: f.event ?? '',
            hazard: f.hazard as 'cold',
            total: optional('total'),
            dc: num('dc', 0, 100),
            diseaseId: id,
          });
          break;
        case 'careCorrection':
          action = care({
            kind: mode,
            id,
            group: f.group as 'disease',
            reason: f.reason ?? '',
          });
          break;
        case 'quickProduction':
        case 'project': {
          const source = equipment.items.find((e) => e.id === f.catalogId);
          const repair = f.repairId
            ? entries.find((e) => e.id === f.repairId)
            : null;
          const output = repair
            ? structuredClone(repair)
            : source
              ? catalogEntry(itemSchema.parse(source))
              : newInventoryEntry(customItem(f.label ?? ''));
          if (repair) output.armorDamage = 0;
          else {
            output.id = id;
            output.quantityMilli = 1000;
            output.parentId = null;
            output.slot = 'none';
          }
          const override =
            f.special === 'yes'
              ? {
                  cost: num('cost'),
                  minutes: num('recipeMinutes'),
                  dc: num('dc', 0, 100),
                  source: f.source ?? '',
                }
              : null;
          if (mode === 'quickProduction') {
            action = post({
              kind: mode,
              products: Array.from(
                { length: num('productCount', 1, 50) },
                (_, i) => ({
                  output: {
                    ...structuredClone(output),
                    id: i === 0 ? id : crypto.randomUUID(),
                  },
                  price: num('price', 0.01, 50, false),
                }),
              ),
              tools: f.toolsName ?? '',
              proficient: f.proficient === 'yes',
              schematic: f.schematic === 'yes',
              materials: f.materialId ? material() : [],
            });
            break;
          }
          action = post({
            kind: mode,
            project: {
              id,
              label: f.label || output.item.name,
              output,
              price: num('price', 0, 1e6, false),
              singleUse: f.singleUse === 'yes',
              repairId: f.repairId || null,
              tools: f.toolsName ?? '',
              proficient: f.proficient === 'yes',
              schematic: f.schematic === 'yes',
              materials: f.materialId ? material() : [],
              override,
            },
          });
          break;
        }
        case 'work':
          action = post({
            kind: mode,
            id,
            minutes: num('minutes', 1, 600),
            finish: f.finish === 'yes',
            total: optional('total'),
          });
          break;
        case 'cancelProject':
          action = post({ kind: mode, id, reason: f.reason ?? '' });
          break;
        case 'clean':
          action = post({
            kind: mode,
            weaponId: f.weaponId ?? '',
            tools: f.tools === 'yes',
          });
          break;
        case 'cook':
          action = post({
            kind: mode,
            tools: f.tools === 'yes',
            ingredients: material(),
            total: num('total', -100, 200),
          });
          break;
        case 'healingItem':
          action = post({
            kind: mode,
            entryId: f.entryId ?? '',
            formula: f.formula === 'ar23' ? 'ar23' : 'medpak',
            rolls: (f.rolls ?? '')
              .trim()
              .split(/[ ,;]+/)
              .map(Number),
            wisSave: optional('wisSave'),
          });
          break;
        case 'medicalAid':
          action = post({
            kind: mode,
            patient: f.patient ?? '',
            kitId: f.kitId ?? '',
            inReach: f.inReach === 'yes',
            handsFree: f.handsFree === 'yes',
            total: num('total', -100, 200),
            rolls: (f.rolls ?? '').trim()
              ? f
                  .rolls!.trim()
                  .split(/[ ,;]+/)
                  .map(Number)
              : [],
          });
          break;
        case 'refillMedicKit':
          action = post({
            kind: mode,
            kitId: f.kitId ?? '',
            entryId: f.entryId ?? '',
          });
          break;
        case 'resuscitate':
          action = post({
            kind: mode,
            patient: f.patient ?? '',
            minutesSincePulse: num('minutesSincePulse', 0.01, 8, false),
            massiveDamage: f.massiveDamage === 'yes',
            total: num('total', -100, 200),
          });
          break;
        case 'training':
          action = post({
            kind: mode,
            id,
            target: f.target ?? '',
            minutes: num('minutes', 1, 600),
            teacher: f.teacher === 'yes',
            paid: num('paid', 0, 10000, false),
          });
          break;
        case 'removeBenefit':
          action = post({ kind: mode, id, reason: f.reason ?? '' });
          break;
      }
      const p = previewCondition(record, action, crypto.randomUUID()),
        lines = [...p.lines, 'PW ' + s.hp + ' → ' + p.state.hp];
      if (p.inventory)
        for (const e of p.inventory.entries) {
          const old = entries.find((x) => x.id === e.id);
          if (!old || old.quantityMilli !== e.quantityMilli)
            lines.push(
              e.item.name +
                ': ' +
                (old?.quantityMilli ?? 0) / 1000 +
                ' → ' +
                e.quantityMilli / 1000 +
                ' ' +
                e.unit +
                (inventoryWeight(e) === null ? ' (masa do uzupełnienia)' : ''),
            );
        }
      dialog.set({
        review: { action, revision: record.revision, lines },
        error: null,
      });
    } catch (e) {
      fail(e);
    }
  }
  const actionButton = (label: string, mode: Mode, fields: Fields = {}) => (
    <button disabled={disabled} onClick={() => open(mode, fields)}>
      {label}
    </button>
  );
  const actionTile = (
    label: string,
    description: string,
    Icon: LucideIcon,
    mode: Mode,
    fields: Fields = {},
  ) => (
    <button
      type="button"
      className="care-action-tile"
      disabled={disabled}
      onClick={() => open(mode, fields)}
    >
      <span className="care-action-icon">
        <Icon aria-hidden="true" strokeWidth={1.6} />
      </span>
      <span>
        <strong>{label}</strong>
        <small>{description}</small>
      </span>
    </button>
  );
  const trainingFields = (
    id?: string,
    target?: string,
    remaining = 18000,
  ): Fields => {
    const minutes = Math.min(60, remaining);
    return {
      ...(id ? { id } : {}),
      ...(target ? { target } : {}),
      minutes: String(minutes),
      paid: String(minutes / 60),
    };
  };
  const activeTraining = owned
    ? d.training.find((t) => t.id === f.id)
    : undefined;
  const todayWork = d.work[String(Math.floor(s.worldMinutes / 1440))] ?? 0;
  const targets = Object.fromEntries([
    ...skills.map((x) => ['skill:' + x.id, x.label]),
    ...tools.map((x) => ['tool:' + x.id, x.label]),
    ...weaponCategories.map((x) => ['weapon:' + x, weaponNames[x]!]),
    ...Object.entries(armorNames).map(([k, v]) => ['armor:' + k, v]),
  ]);
  const needs = nutritionNeeds(record.sheet ?? record.draft!);
  return (
    <section
      className={`bg-section condition-panel care-panel care-panel--${mode}`}
    >
      <h2>
        {mode === 'health'
          ? 'Choroby, leki i zagrożenia'
          : 'Rozwój i czynności podczas postoju'}
      </h2>
      <p className="care-source">
        {mode === 'downtime'
          ? 'Neuroshima: Ostatnia Era, s. 46–47, 132, 144–146.'
          : 'Neuroshima: Ostatnia Era, s. 109–112, 132, 137–138, 258–259.'}
      </p>
      <details hidden={mode !== 'health'}>
        <summary>
          Choroby i fobie (
          {c.diseases.filter((x) => x.active).length +
            c.phobias.filter((x) => x.active).length}
          )
        </summary>
        <div className="bg-actions">
          {actionButton('Wybór początkowy', 'start', {
            group: 'disease',
            choice: '0',
            ability: 'str',
          })}
          {!v.derived.activeFeats.includes('immunity') &&
            actionButton('Dodaj chorobę', 'disease', {
              disease: 'rat',
              onsetMinutes: '1440',
            })}
          {v.derived.activeFeats.includes('immunity') && (
            <p className="bg-notice">
              Immunitet: nowe choroby nie występują; RO przeciw posiadanym
              chorobom z Ułatwieniem.
            </p>
          )}
          {actionButton('Dodaj fobię', 'phobia', { phobia: 'heights' })}
          {actionButton('Medpak / AR-23', 'healingItem', { formula: 'medpak' })}
          {record.sheet?.rulesContext.gameColor === 'mercury' && (
            <p className="bg-notice">Rtęć: medpak i AR-23 nie działają.</p>
          )}
          {actionButton('RadOff — napromieniowanie', 'medicine', {
            treatment: 'exposure',
            doses: '1',
          })}
        </div>
        <div className="condition-resources">
          {c.diseases
            .filter((x) => x.active)
            .map((x) => (
              <article key={x.id}>
                <strong>{diseaseNames[x.kind]}</strong>
                <p>
                  {['Przewlekły / ogólny', 'Ostry', 'Krytyczny'][x.stage]} ·{' '}
                  {x.details}
                </p>
                <p>
                  {(diseaseEffects[x.kind] ?? [])[x.stage] ??
                    diseaseEffects[x.kind]?.[0]}
                </p>
                {x.blocked && <p role="alert">Blokuje korzyści odpoczynków.</p>}
                <p>
                  Kuracja: {x.treatmentDays} dni.{' '}
                  {x.bleeding
                    ? 'Krwawienie: ' + x.successes + '/3 sukcesy.'
                    : ''}
                </p>
                <div className="bg-actions">
                  {!['hemophilia', 'infection'].includes(x.kind) &&
                    actionButton('RO choroby', 'diseaseCheck', { id: x.id })}
                  {x.kind !== 'death' &&
                    actionButton('Przyjmij lek', 'medicine', {
                      id: x.id,
                      doses: '1',
                      treatment:
                        x.kind === 'radiation'
                          ? 'radoff'
                          : ['rat', 'infection'].includes(x.kind)
                            ? 'antibiotic'
                            : 'daily',
                    })}
                  {x.kind === 'hemophilia' &&
                    actionButton('Krwawienie', 'bleeding', {
                      id: x.id,
                      bleedingMode: x.bleeding ? 'save' : 'start',
                    })}
                  {actionButton('Zakończ chorobę', 'careCorrection', {
                    id: x.id,
                    group: 'disease',
                  })}
                </div>
              </article>
            ))}
          {c.phobias
            .filter((x) => x.active)
            .map((x) => (
              <article key={x.id}>
                <strong>{phobiaNames[x.kind]}</strong>
                <p>
                  Kolejne sukcesy: {x.successes}/3.{' '}
                  {x.fear
                    ? 'Utrudnienie testów cech i ataków przy działającym bodźcu.'
                    : ''}
                </p>
                {x.immuneUntil > s.worldMinutes && (
                  <p>
                    Przełamanie jeszcze {x.immuneUntil - s.worldMinutes} min.
                  </p>
                )}
                {x.attackUntil > s.worldMinutes && (
                  <p>
                    Ułatwienie ataków przeciw źródłu fobii przez{' '}
                    {x.attackUntil - s.worldMinutes} min.
                  </p>
                )}
                {actionButton('Bodziec / powtórz RO', 'phobiaCheck', {
                  id: x.id,
                })}
                {x.fear &&
                  actionButton('Bodziec ustał', 'phobiaAway', { id: x.id })}
                {actionButton('Zakończ fobię', 'careCorrection', {
                  id: x.id,
                  group: 'phobia',
                })}
              </article>
            ))}
        </div>
      </details>
      <details hidden={mode !== 'health'}>
        <summary>Żywienie i środowisko</summary>
        <p>
          Dzienna norma: {needs.foodMg / 1e6} kg jedzenia i{' '}
          {needs.waterMl / 1000} l wody. Dni bez jedzenia: {c.hungryDays}.
        </p>
        {actionButton('Rozlicz dobę', 'day', {
          dayLabel: 'Dzień ' + (c.day + 1),
          food: String(needs.foodMg / 1e6),
          water: String(needs.waterMl / 1000),
        })}
        {actionButton('Zagrożenie / oddech', 'environment', {
          hazard: 'cold',
          dc: '10',
        })}
        <p>
          Zakończenie doby przesuwa czas gry do kolejnego dnia. Godziny
          ekspozycji i zakończone tury rozliczasz jawnymi zdarzeniami.
        </p>
      </details>
      <div hidden={mode !== 'downtime'} className="care-downtime">
        <div
          className="care-action-grid"
          aria-label="Czynności podczas postoju"
        >
          {actionTile(
            'Nowy projekt',
            'Produkcja lub naprawa przedmiotu',
            Hammer,
            'project',
            {
              price: '10',
              toolsName: '',
              quantity: '1',
              materialValue: '5',
              dc: '10',
              cost: '5',
              recipeMinutes: '60',
            },
          )}
          {v.derived.classLevels.spec >= 3 &&
            actionTile(
              'Szybka produkcja',
              'Zdolność Speca',
              Zap,
              'quickProduction',
              {
                price: '10',
                productCount: '1',
                quantity: '1',
                materialValue: '5',
              },
            )}
          {actionTile(
            'Pomoc medyczna',
            'Leczenie narzędziami medyka',
            HeartPulse,
            'medicalAid',
            {
              total: '10',
            },
          )}
          {actionTile(
            'Uzupełnij zestaw',
            'Narzędzia małego medyka',
            PackagePlus,
            'refillMedicKit',
          )}
          {medicalAidProfile(v.sheet, 0).resuscitate &&
            actionTile('Reanimacja', 'Łapiduch', HeartPulse, 'resuscitate', {
              minutesSincePulse: '1',
            })}
          {actionTile(
            'Wyczyść broń',
            'Konserwacja jednej broni',
            Wrench,
            'clean',
          )}
          {actionTile(
            'Przygotuj posiłek',
            'Gotowanie ze składników',
            ChefHat,
            'cook',
            {
              quantity: '1',
              materialValue: '0',
            },
          )}
          {actionTile(
            'Środek leczniczy',
            'Medpak lub AR-23',
            Pill,
            'healingItem',
            {
              formula: 'medpak',
            },
          )}
          {actionTile(
            'Trening / nauka',
            'Rozpocznij naukę biegłości',
            BookOpen,
            'training',
            trainingFields(),
          )}
        </div>
        <p className="care-work-budget">
          <Clock3 aria-hidden="true" size={17} />
          Praca w tej dobie: <strong>{duration(todayWork)} / 10 h</strong>
        </p>
        {d.projects.some((p) => p.status === 'working') && (
          <section className="care-tracker-group" aria-label="Projekty w toku">
            <h3>
              <Hammer aria-hidden="true" size={20} /> Projekty w toku
            </h3>
            <div className="care-progress-grid">
              {d.projects
                .filter((p) => p.status === 'working')
                .map((p) => (
                  <article className="care-progress-card" key={p.id}>
                    <h4>{p.label}</h4>
                    <div className="care-progress-caption">
                      <span>
                        {duration(p.progress)} / {duration(p.minutes)}
                      </span>
                      <strong>
                        {Math.min(
                          100,
                          Math.floor(
                            (p.progress / Math.max(1, p.minutes)) * 100,
                          ),
                        )}
                        %
                      </strong>
                    </div>
                    <progress
                      aria-label={'Postęp projektu: ' + p.label}
                      value={Math.min(p.progress, p.minutes)}
                      max={Math.max(1, p.minutes)}
                    />
                    <p>
                      Materiały: {p.cost} G · ST {p.dc}
                    </p>
                    <div className="bg-actions">
                      {actionButton('Zapisz pracę / wynik', 'work', {
                        id: p.id,
                        minutes: '60',
                      })}
                      {actionButton('Anuluj projekt', 'cancelProject', {
                        id: p.id,
                      })}
                    </div>
                  </article>
                ))}
            </div>
          </section>
        )}
        <section
          className="care-tracker-group"
          aria-label="Postęp treningu i nauki"
        >
          <h3>
            <BookOpen aria-hidden="true" size={20} /> Trening i nauka
          </h3>
          <p className="care-training-rule">
            300 godzin z nauczycielem · 1 G za godzinę · do 10 godzin pracy
            dziennie
          </p>
          {d.training.length === 0 ? (
            <p className="care-empty">
              Wybierz „Trening / nauka”, aby rozpocząć i zapisywać kolejne
              godziny.
            </p>
          ) : (
            <div className="care-progress-grid">
              {d.training.map((t) => (
                <article
                  className={`care-progress-card${t.completed ? ' is-complete' : ''}`}
                  key={t.id}
                >
                  <div className="care-progress-heading">
                    <h4>{targets[t.target] ?? t.target}</h4>
                    {t.completed && (
                      <span className="care-complete">
                        <Check aria-hidden="true" size={16} /> Ukończone
                      </span>
                    )}
                  </div>
                  <div className="care-progress-caption">
                    <span>{duration(t.minutes)} / 300 h</span>
                    <strong>
                      {Math.min(100, Math.floor((t.minutes / 18000) * 100))}%
                    </strong>
                  </div>
                  <progress
                    aria-label={
                      'Postęp nauki: ' + (targets[t.target] ?? t.target)
                    }
                    max={18000}
                    value={Math.min(t.minutes, 18000)}
                  />
                  <p>
                    {t.completed
                      ? 'Biegłość dostępna na karcie.'
                      : 'Pozostało: ' +
                        duration(Math.max(0, 18000 - t.minutes))}
                  </p>
                  {!t.completed && (
                    <button
                      type="button"
                      className="care-training-continue"
                      disabled={disabled}
                      onClick={() =>
                        open(
                          'training',
                          trainingFields(t.id, t.target, 18000 - t.minutes),
                        )
                      }
                    >
                      <Plus aria-hidden="true" size={17} /> Zapisz trening
                    </button>
                  )}
                </article>
              ))}
            </div>
          )}
        </section>
        {(d.cleaned.length > 0 || d.benefits.length > 0) && (
          <section
            className="care-tracker-group"
            aria-label="Przygotowania i efekty"
          >
            <h3>
              <Sparkles aria-hidden="true" size={20} /> Przygotowania i efekty
            </h3>
            {d.cleaned.map((id) => (
              <p key={id}>
                Wyczyszczona broń:{' '}
                <strong>
                  {entries.find((e) => e.id === id)?.item.name ??
                    'usunięty egzemplarz'}
                </strong>{' '}
                — przerzut najbliższej walki.
              </p>
            ))}
            {d.benefits.map((b) => (
              <div className="care-benefit" key={b.id}>
                <span>{b.label}</span>
                {actionButton('Rozlicz efekt', 'removeBenefit', {
                  id: b.id,
                  reason: 'Efekt wykorzystany',
                })}
              </div>
            ))}
          </section>
        )}
      </div>
      {owned && (dialog.mode || dialog.review) && (
        <Dialog cancel={close}>
          <h2>{titles[dialog.mode!]}</h2>
          {dialog.error && <p role="alert">{dialog.error}</p>}
          {dialog.review ? (
            <>
              <ul>
                {dialog.review.lines.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
              <div className="bg-actions">
                <button
                  disabled={store.locked}
                  onClick={() => dialog.set({ review: null })}
                >
                  Wróć
                </button>
                <button
                  disabled={store.locked}
                  onClick={async () => {
                    const p = dialog.review!;
                    store.invalidInput(marker, null);
                    if (await store.mutateCondition(p.action, p.revision))
                      close();
                    else {
                      store.invalidInput(
                        marker,
                        'Nierozstrzygnięty zapis zdrowia/postoju.',
                      );
                      dialog.set({
                        error:
                          useCharacterStore.getState().error ??
                          'Nie zapisano zmian. Dokończ pozostałe formularze.',
                      });
                    }
                  }}
                >
                  Zastosuj
                </button>
                <button disabled={store.locked} onClick={close}>
                  Anuluj
                </button>
              </div>
            </>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit();
              }}
            >
              <div className="condition-form">
                {dialog.mode === 'start' && (
                  <>
                    {select('group', 'Rodzaj', {
                      disease: 'Choroba',
                      phobia: 'Fobia',
                    })}
                    {select('choice', 'Wybór', {
                      ...Object.fromEntries(
                        (f.group === 'phobia'
                          ? phobiaKinds
                          : diseaseKinds.slice(0, 8)
                        ).map((kind, index) => [
                          String(index),
                          f.group === 'phobia'
                            ? phobiaNames[kind as keyof typeof phobiaNames]!
                            : diseaseNames[kind as keyof typeof diseaseNames]!,
                        ]),
                      ),
                      '-1': 'Nie wybieram — −1 do cechy',
                    })}
                    {select('ability', 'Cecha bazowa', abilityNames)}
                    <p>
                      Wybór +1 do cechy bazowej (maks. 18); odmowa −1. Choroba
                      przyznaje trzy dawki leku o masie 0 kg. Każdy wybór jest
                      jednorazowy.
                    </p>
                  </>
                )}
                {dialog.mode === 'disease' && (
                  <>
                    {select('disease', 'Choroba', diseaseNames)}
                    {input('details', 'Okoliczności / objawy')}
                    {input('onsetMinutes', 'Minuty do pierwszych objawów')}
                  </>
                )}
                {dialog.mode === 'diseaseCheck' && (
                  <>
                    {v.derived.activeFeats.includes('immunity') && (
                      <p className="bg-notice">
                        Immunitet: wykonaj RO z Ułatwieniem i wpisz wybraną kość
                        oraz końcowy wynik.
                      </p>
                    )}
                    {input('natural', 'Naturalny wynik k20')}
                    {input('total', 'Końcowy wynik RO')}
                    {input(
                      'chronicRoll',
                      'Nowa choroba po sukcesie popromiennej — k8 (opcjonalnie)',
                    )}
                  </>
                )}
                {dialog.mode === 'medicine' && (
                  <>
                    {inventoryPick()}
                    {input('doses', 'Liczba podań leku')}
                    {v.derived.activeFeats.includes('plaster') && (
                      <p>
                        Pan Plaster: dzienna kuracja zużywa pół dawki na każde
                        podanie; zużycie pokaże podgląd.
                      </p>
                    )}
                    {select('treatment', 'Cel leczenia', {
                      daily: 'Dawka dobowa przewlekłej',
                      antibiotic: 'Antybiotykoterapia',
                      radoff: 'Kuracja RadOff',
                      exposure: 'RadOff — same skutki napromieniowania',
                      bleeding: 'Powstrzymanie krwawienia hemofilii',
                    })}
                    {['radoff', 'exposure'].includes(f.treatment ?? '') &&
                      input('sideSave', 'RO KON ST 15 po RadOff — wynik')}
                    <p>
                      Przy lekach 1 szt. = 1 dawka. Dobowa dawka zapobiega
                      testowi postępu; nie kasuje automatycznie istniejącego
                      stadium.
                    </p>
                  </>
                )}
                {dialog.mode === 'bleeding' && (
                  <>
                    {select('bleedingMode', 'Czynność', {
                      start: 'Rozpoczęcie krwawienia',
                      save: 'RO KON na koniec tury',
                      medicineCheck: 'Test Medycyny ST 15',
                    })}
                    {input('total', 'Wynik końcowy (przy teście)')}
                    {check('tools', 'Narzędzia małego medyka')}
                  </>
                )}
                {dialog.mode === 'phobiaAway' && (
                  <p>
                    Zakończ działanie bieżącego bodźca. Fobia pozostaje na
                    karcie.
                  </p>
                )}
                {dialog.mode === 'phobia' &&
                  select('phobia', 'Fobia', phobiaNames)}
                {dialog.mode === 'phobiaCheck' && (
                  <>
                    {input('total', 'Wynik RO MDR ST 15')}
                    {input(
                      'turn',
                      'Oznaczenie końca tury (poza walką zostaw puste)',
                    )}
                    <p>
                      Poza walką minimum 10 minut między próbami. Trzy kolejne
                      sukcesy leczą fobię; porażka zeruje serię.
                    </p>
                  </>
                )}
                {dialog.mode === 'day' && (
                  <>
                    {input('dayLabel', 'Nazwa rozliczanej doby')}
                    {input('food', 'Spożyte jedzenie (kg)')}
                    {input('water', 'Wypita woda (l)')}
                    {input(
                      'hungerSave',
                      'RO KON przy mniej niż połowie jedzenia (opcjonalnie)',
                    )}
                    {inventoryPick(
                      'foodEntryId',
                      'Zużyj jedzenie z inwentarza (opcjonalnie)',
                    )}
                    {f.foodEntryId &&
                      input(
                        'foodQuantity',
                        'Ilość zużytych jednostek jedzenia',
                      )}
                    {inventoryPick(
                      'waterEntryId',
                      'Zużyj wodę z inwentarza (opcjonalnie)',
                    )}
                    {f.waterEntryId &&
                      input('waterQuantity', 'Ilość zużytych jednostek wody')}
                  </>
                )}
                {dialog.mode === 'environment' && (
                  <>
                    {input(
                      'event',
                      'Unikalne zdarzenie, np. dzień 2, godzina 3',
                    )}
                    {select('hazard', 'Zagrożenie', {
                      cold: 'Zimno',
                      radiation: 'Promieniowanie',
                      suffocation: 'Tura duszenia',
                      breathe: 'Odzyskany oddech',
                      noSleep: 'Doba bez snu',
                    })}
                    {input('dc', 'ST (zimno: 5 + stopnie poniżej zera)')}
                    {input(
                      'total',
                      'Końcowy wynik RO (bez duszenia / oddechu)',
                    )}
                  </>
                )}
                {['careCorrection', 'cancelProject', 'removeBenefit'].includes(
                  dialog.mode!,
                ) && input('reason', 'Powód')}
                {['project', 'quickProduction'].includes(dialog.mode!) && (
                  <>
                    {dialog.mode === 'project' &&
                      inventoryPick(
                        'repairId',
                        'Naprawa istniejącego przedmiotu (opcjonalnie)',
                      )}
                    {select(
                      'catalogId',
                      'Produkt z katalogu (lub własna nazwa)',
                      Object.fromEntries(
                        equipment.items.map((e) => [e.id, e.name]),
                      ),
                    )}
                    {input('label', 'Nazwa projektu / własnego produktu')}
                    {input('price', 'Cena bazowa, bez regionu i Koloru (gb)')}
                    {dialog.mode === 'project' &&
                      check('singleUse', 'Przedmiot jednorazowy')}
                    {dialog.mode === 'quickProduction' &&
                      input('productCount', 'Liczba egzemplarzy')}
                    {dialog.mode === 'quickProduction' && (
                      <p>
                        Jedno użycie, łącznie do{' '}
                        {v.derived.classLevels.spec >= 11 ? 50 : 25} gb; 1
                        minuta na 1 gb. Podgląd rozlicza czas, surowce, pulę
                        zdolności i gotowe przedmioty razem.
                      </p>
                    )}
                    {input('toolsName', 'Właściwe narzędzia')}
                    {check(
                      'proficient',
                      'Mam narzędzia i biegłość potrzebną do tej pracy',
                    )}
                    {check('schematic', 'Mam wymagany schemat')}
                    {inventoryPick('materialId', 'Surowce — zapas')}
                    {input('quantity', 'Liczba zużywanych jednostek surowca')}
                    {input(
                      'materialValue',
                      'Łączna wartość tych surowców (gb)',
                    )}
                    {dialog.mode === 'project' &&
                      check(
                        'special',
                        'Szczególna receptura / naprawa / reguła MG',
                      )}
                    {dialog.mode === 'project' && f.special === 'yes' && (
                      <>
                        {input('source', 'Nazwa receptury, strona / powód')}
                        {input('cost', 'Wymagany koszt surowców (gb)')}
                        {input('recipeMinutes', 'Wymagany czas (min)')}
                        {input('dc', 'ST')}
                      </>
                    )}
                    {dialog.mode === 'project' && (
                      <p>
                        Naprawa (s. 146): ST 10 / 15 / 20, koszt 10% / 30% / 50%
                        ceny, czas 1k4 min / 1k4 h / 2k4 h. Wpisz właściwy
                        wariant w regule szczególnej. Materiały są zużywane
                        dopiero po sukcesie. Dla mieszanki można wskazać
                        wcześniej utworzony pakiet surowców z opisem składników.
                      </p>
                    )}
                  </>
                )}
                {dialog.mode === 'work' && (
                  <>
                    {input('minutes', 'Minuty pracy w tej dobie')}
                    {check(
                      'finish',
                      'Kończę projekt i rozliczam test narzędzi',
                    )}
                    {f.finish === 'yes' &&
                      input('total', 'Wynik testu narzędzi')}
                  </>
                )}
                {dialog.mode === 'clean' && (
                  <>
                    {select(
                      'weaponId',
                      'Broń',
                      Object.fromEntries(
                        entries
                          .filter((e) => e.weapon)
                          .map((e) => [e.id, e.item.name]),
                      ),
                    )}
                    {check('tools', 'Mam środki do czyszczenia i konserwacji')}
                    <p>Czas: 1 godzina.</p>
                  </>
                )}
                {dialog.mode === 'cook' && (
                  <>
                    {check('tools', 'Mam narzędzia małego kucharza')}
                    {inventoryPick('materialId', 'Składniki')}
                    {input('quantity', 'Ilość zużywanych jednostek')}
                    {input('total', 'Wynik testu narzędzi kucharza')}
                    <p>
                      Czas: 2 godziny; ST 10. Wynik 20+ daje Fuks na 24 godziny
                      gry (poza Rtęcią).
                    </p>
                  </>
                )}
                {dialog.mode === 'medicalAid' && (
                  <>
                    {input('patient', 'Pacjent')}
                    {select(
                      'kitId',
                      'Narzędzia małego medyka',
                      Object.fromEntries(
                        entries
                          .filter(
                            (e) =>
                              /medyk/i.test(e.item.name) &&
                              !/uzupełnienie/i.test(e.item.name),
                          )
                          .map((e) => [
                            e.id,
                            e.item.name +
                              ' — ' +
                              (5 - (d.medicKitUses?.[e.id] ?? 0)) +
                              '/5 użyć',
                          ]),
                      ),
                    )}
                    {check('inReach', 'Pacjent w zasięgu 1,5 m')}
                    {check('handsFree', 'Obie ręce wolne')}
                    {input(
                      'total',
                      'Wynik testu INT (narzędzia małego medyka)',
                    )}
                    {Number.isFinite(Number(f.total)) && (
                      <p>
                        Rzuć {medicalAidProfile(v.sheet, Number(f.total)).count}
                        k{medicalAidProfile(v.sheet, Number(f.total)).sides};
                        premia PW:{' '}
                        {medicalAidProfile(v.sheet, Number(f.total)).modifier}.
                        Wynik leczenia zapisze się dla pacjenta w historii; jego
                        PW zatwierdzisz na jego karcie.
                      </p>
                    )}
                    {input('rolls', 'Wyniki kości leczenia, oddzielone spacją')}
                  </>
                )}
                {dialog.mode === 'refillMedicKit' && (
                  <>
                    {inventoryPick('kitId', 'Narzędzia medyka')}
                    {inventoryPick('entryId', 'Uzupełnienie — jedno użycie')}
                  </>
                )}
                {dialog.mode === 'resuscitate' && (
                  <>
                    {input('patient', 'Pacjent')}
                    {input('minutesSincePulse', 'Minuty od ustania tętna')}
                    {check(
                      'massiveDamage',
                      'Pacjent otrzymał Olbrzymie obrażenia',
                    )}
                    {input('total', 'Wynik testu Medycyny')}
                    <p>
                      Reanimacja trwa 1 minutę. ST{' '}
                      {resuscitationDC(Number(f.minutesSincePulse))}. Sukces
                      przywraca funkcje życiowe, lecz nie stabilizuje pacjenta i
                      nie przywraca PW.
                    </p>
                  </>
                )}
                {dialog.mode === 'healingItem' && (
                  <>
                    {inventoryPick()}
                    {select('formula', 'Środek', {
                      medpak: v.derived.activeFeats.includes('plaster')
                        ? 'Medpak — 3k6 + 2 (Pan Plaster)'
                        : 'Medpak — 2k6 + 2',
                      ar23: v.derived.activeFeats.includes('plaster')
                        ? 'AR-23 — 5k6 + 4 (Pan Plaster)'
                        : 'AR-23 — 4k6 + 4',
                    })}
                    {input('rolls', 'Wyniki k6, oddzielone spacją')}
                    {f.formula === 'ar23' &&
                      input('wisSave', 'RO MDR ST 15 — wynik')}
                    <p>
                      Maksymalnie dwa zastosowania na dobę. Dieta cud podwaja
                      przywracane PW.
                    </p>
                  </>
                )}
                {dialog.mode === 'training' && (
                  <>
                    {activeTraining ? (
                      <div className="care-training-target">
                        <strong>
                          {targets[activeTraining.target] ??
                            activeTraining.target}
                        </strong>
                        <p>
                          Zapisano {duration(activeTraining.minutes)} z 300 h.
                          Pozostało{' '}
                          {duration(
                            Math.max(0, 18000 - activeTraining.minutes),
                          )}
                          .
                        </p>
                      </div>
                    ) : (
                      select('target', 'Nowa biegłość', targets)
                    )}
                    {input('minutes', 'Minuty ukończonego treningu')}
                    {input('paid', 'Zapłacona kwota (gb)')}
                    {check('teacher', 'Trening z właściwym nauczycielem')}
                    <p>
                      1 G za godzinę. W tej dobie wykorzystano{' '}
                      {duration(todayWork)} z 10 h pracy. Zapis dodaje tylko
                      podany czas; nauka wymaga łącznie 300 godzin z
                      nauczycielem.
                    </p>
                  </>
                )}
              </div>
              <div className="bg-actions">
                <button type="submit">Podgląd</button>
                <button type="button" onClick={close}>
                  Anuluj
                </button>
              </div>
            </form>
          )}
          {store.locked && (
            <div className="bg-actions">
              <button
                onClick={() =>
                  void store.flush().then((ok) => {
                    if (ok) {
                      store.invalidInput(marker, null);
                      dialog.set({
                        owner: null,
                        mode: null,
                        review: null,
                        error: null,
                      });
                    } else
                      dialog.set({ error: useCharacterStore.getState().error });
                  })
                }
              >
                Ponów dokładnie ten zapis
              </button>
              <button
                onClick={() =>
                  void store.compareConflict().then(() => {
                    if (useCharacterStore.getState().conflict) {
                      store.invalidInput(marker, null);
                      dialog.set({
                        owner: null,
                        mode: null,
                        review: null,
                        error: null,
                      });
                    }
                  })
                }
              >
                Odczytaj zapis i porównaj
              </button>
            </div>
          )}
        </Dialog>
      )}
    </section>
  );
}
const titles: Record<Mode, string> = {
  quickProduction: 'Szybka produkcja',
  medicalAid: 'Leczenie narzędziami medyka',
  refillMedicKit: 'Uzupełnienie narzędzi medyka',
  resuscitate: 'Łapiduch — reanimacja',
  start: 'Wybór początkowy',
  disease: 'Nowa choroba',
  diseaseCheck: 'Test choroby',
  medicine: 'Przyjęcie leku',
  bleeding: 'Krwawienie',
  phobia: 'Nowa fobia',
  phobiaCheck: 'Test fobii',
  phobiaAway: 'Zakończenie bodźca fobii',
  day: 'Zakończenie doby',
  environment: 'Zdarzenie środowiskowe',
  careCorrection: 'Zakończenie choroby lub fobii',
  project: 'Produkcja przedmiotu',
  work: 'Postęp produkcji',
  cancelProject: 'Anulowanie projektu',
  clean: 'Czyszczenie broni',
  cook: 'Gotowanie',
  healingItem: 'Środek leczniczy',
  training: 'Trening i nauka',
  removeBenefit: 'Rozliczenie efektu',
};
const labels: Record<string, string> = {
  total: 'Wynik testu',
  quantity: 'Ilość',
  materialValue: 'Wartość surowców',
  price: 'Cena bazowa',
  choice: 'Wybór',
  minutes: 'Minuty',
  food: 'Jedzenie',
  water: 'Woda',
  paid: 'Koszt',
  natural: 'Naturalny k20',
  entryId: 'Środek',
  materials: 'Surowce',
  tools: 'Narzędzia',
  medicine: 'Lek',
  ability: 'Cecha',
  source: 'Źródło receptury',
};

function duration(minutes: number) {
  const hours = Math.floor(minutes / 60),
    remainder = minutes % 60;
  return (
    [hours ? `${hours} h` : '', remainder ? `${remainder} min` : '']
      .filter(Boolean)
      .join(' ') || '0 h'
  );
}
