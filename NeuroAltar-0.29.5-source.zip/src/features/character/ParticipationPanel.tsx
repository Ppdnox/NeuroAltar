import { StatusPanel } from '../statuses/StatusPanel';
import { useEffect, useState } from 'react';
import { useCharacterStore } from '../../stores/characterStore';
import { useParticipationStore } from '../../stores/participationStore';
import { useCombatStore } from '../../stores/combatStore';
import { useNavigationStore } from '../../stores/navigationStore';
import {
  characterCombatValues,
  costNames,
  type Participation,
  type CombatEffect,
} from '../../domain/character/participation';
import type { ActorDraft } from '../../domain/combat';
import type { SlotId } from '../../domain/encounterDetails';
import { CharacterCombatRolls } from './CharacterCombatRolls';
export function ParticipationStatus() {
  const s = useParticipationStore();
  if (s.busy)
    return <p role="status">Zapisywanie i odświeżanie powiązania karty BG…</p>;
  return s.error ? (
    <div className="editor-error" role="alert">
      <p>{s.error}</p>
      {s.pending && (
        <button disabled={s.busy} onClick={() => void s.retry()}>
          Ponów ten sam zapis
        </button>
      )}
      <button disabled={s.busy} onClick={() => void s.recover()}>
        Sprawdź zapis i odśwież podgląd
      </button>
    </div>
  ) : null;
}
export function LinkCharacter({
  actor,
  slotId,
  disabled,
}: {
  actor: ActorDraft;
  slotId: SlotId;
  disabled: boolean;
}) {
  const store = useCharacterStore(),
    p = useParticipationStore();
  const [id, setId] = useState(''),
    [open, setOpen] = useState(false);
  useEffect(() => {
    void useCharacterStore.getState().initialize();
  }, []);
  const c = store.records.find((c) => c.id === id),
    v = c ? characterCombatValues(c) : null;
  return (
    <section className="bg-section">
      <button
        className="secondary-button"
        disabled={disabled || p.busy || !!p.pending}
        onClick={() => setOpen(!open)}
      >
        Powiąż z pełną kartą BG
      </button>
      {open && (
        <>
          <p>
            Ten BG będzie używał zdrowia i wyposażenia wybranej karty.
            Dotychczasowy zapis pozostaje w historii powiązania. Inicjatywa
            pozostaje osobna dla tej potyczki.
          </p>
          <label>
            Karta postaci
            <select value={id} onChange={(e) => setId(e.target.value)}>
              <option value="">Wybierz kartę</option>
              {store.records
                .filter((c) => c.sheet && !c.draft && !c.archived)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.sheet!.identity.name}
                  </option>
                ))}
            </select>
          </label>
          {v && (
            <>
              <p>
                Potyczka: {actor.displayName}, PW {actor.hpCurrent}/
                {actor.hpMaxCurrent}, TT {actor.ttCurrent}.
              </p>
              <p>
                Po powiązaniu: {v.name}, PW {v.hp}/{v.hpMax}, TT {v.tt}. Statusy
                potyczki pozostają lokalne.
              </p>
              <button
                className="primary-button"
                disabled={disabled || p.busy || !!p.pending}
                onClick={() =>
                  void p.send(actor.id, slotId, id, { kind: 'link' })
                }
              >
                Powiąż — przyjmij dane karty
              </button>
            </>
          )}
        </>
      )}
    </section>
  );
}
export function LinkedCharacter({
  actor,
  slotId,
  participation: p,
  disabled,
}: {
  actor: ActorDraft;
  slotId: SlotId;
  participation: Participation;
  disabled: boolean;
}) {
  const store = useCharacterStore(),
    state = useParticipationStore();
  const c = store.records.find((c) => c.id === p.characterId),
    v = c ? characterCombatValues(c, p) : null;
  const [label, setLabel] = useState(''),
    [remaining, setRemaining] = useState('1'),
    [phase, setPhase] = useState<CombatEffect['phase']>('end'),
    [target, setTarget] = useState<CombatEffect['target']>('all'),
    [modifier, setModifier] = useState('0'),
    [mode, setMode] = useState<CombatEffect['mode']>('normal'),
    [unlink, setUnlink] = useState(false);
  if (!c || !v)
    return <p role="alert">Nie można odczytać powiązanej karty BG.</p>;
  const locked = disabled || state.busy || !!state.pending || store.locked;
  const send = (action: Record<string, unknown>) =>
    state.send(actor.id, slotId, c.id, action);
  return (
    <section
      className="actor-detail bg-workspace"
      aria-label="Pełna karta BG w walce"
    >
      <h2>{v.name}</h2>
      <p>
        {p.state === 'active'
          ? 'Aktywny udział'
          : p.state === 'ended'
            ? 'Udział zakończony'
            : 'Przygotowany udział'}{' '}
        · karta BG
      </p>
      <div className="bg-quick-values">
        <div>
          PW
          <strong>
            {v.hp}/{v.hpMax}
          </strong>
        </div>
        <div>
          TT<strong>{v.tt}</strong>
        </div>
        <div>
          Szybkość<strong>{v.speed} m</strong>
        </div>
        <label>
          Inicjatywa
          <input
            type="number"
            value={actor.initiativeValue}
            disabled={locked}
            onChange={(e) =>
              useCombatStore.getState().editActor(slotId, actor.id, {
                initiativeValue: e.target.value,
              })
            }
          />
        </label>
      </div>
      {!!v.consequences.messages.length && (
        <p className="condition-alert" role="status">
          {v.consequences.messages.join(' · ')}
        </p>
      )}
      <button
        className="secondary-button"
        disabled={locked}
        onClick={() => {
          store.select(c.id);
          useNavigationStore.getState().navigate('character');
        }}
      >
        Otwórz kartę — zdrowie, zasoby i wyposażenie
      </button>
      <button
        disabled={locked || !actor.initiativeValue.trim()}
        onClick={() => useCombatStore.getState().setCurrent(slotId, actor.id)}
      >
        Ustaw obecną turę
      </button>
      <details open={!!c.draft}>
        <summary>Zakończenie i powiązanie</summary>
        <p>
          Możesz zakończyć udział bez zatwierdzania szkicu karty. Najpierw
          rozlicz efekty tej walki poniżej. Zakończenie nie usuwa postaci, nie
          odnawia zasobów ani amunicji.
        </p>
        <button
          disabled={locked || p.effects.length > 0}
          onClick={() => void send({ kind: 'end' })}
        >
          Zakończ udział w walce
        </button>
        <button
          disabled={locked || p.state === 'active'}
          onClick={() => setUnlink(!unlink)}
        >
          Odłącz kartę…
        </button>
        {unlink && (
          <>
            <p>
              Potyczka zachowa {v.name}, PW {v.hp}/{v.hpMax}, TT {v.tt} jako
              niezależne wartości. Pełna karta pozostanie bez zmian. Przed
              resetem przygotuj nowy stan potyczki.
            </p>
            <button
              disabled={locked}
              onClick={() =>
                void send({
                  kind: 'unlink',
                  name: v.name,
                  hp: v.hp,
                  hpMax: v.hpMax,
                  tt: v.tt,
                })
              }
            >
              Potwierdź odłączenie
            </button>
          </>
        )}
      </details>
      <StatusPanel
        slotId={slotId}
        actor={actor}
        parentDisabled={locked}
        persistentHealth
      />
      <p>Pozostałe ataki w rozpoczętej Akcji: {p.budget.attacks}</p>
      <CharacterCombatRolls record={c} participation={p} disabled={locked} />
      <div className="actor-actions">
        {Object.entries(costNames).map(([key, name]) => (
          <button
            className="secondary-button"
            key={key}
            disabled={
              locked ||
              p.state !== 'active' ||
              v.consequences.fatal ||
              (key === 'reaction' && v.consequences.reactionBlocked) ||
              (key === 'bonus' && v.consequences.bonusBlocked) ||
              p.budget[key as keyof typeof p.budget] === 0
            }
            onClick={() => void send({ kind: 'spend', cost: key, label: name })}
          >
            {name}: {p.budget[key as keyof typeof p.budget]}
          </button>
        ))}
      </div>
      <p className="editor-hint">
        Rzut nie zużywa akcji ani amunicji. Zapis strzału, użycie zasobu i
        przeładowanie rozliczają koszty przy zatwierdzeniu. Zdrowie zmieniaj na
        wspólnej karcie.
      </p>
      <h3>Efekty tej walki</h3>
      {p.effects.map((e) => (
        <div className="bg-combat-effect" key={e.id}>
          <div>
            <strong>{e.label}</strong>
            <span className="bg-small">
              {e.sourceRuleId === 'feat.neo'
                ? 'Jedno trafienie · +5 TT'
                : e.phase === 'manual'
                  ? 'Do ręcznego rozliczenia'
                  : `${e.remaining} · ${e.phase === 'start' ? 'początek tury' : e.phase === 'end' ? 'koniec tury' : 'koniec rundy'}`}
            </span>
          </div>
          <button
            disabled={locked}
            onClick={() => void send({ kind: 'removeEffect', id: e.id })}
          >
            {e.sourceRuleId === 'feat.neo'
              ? 'Trafienie rozliczone — zakończ +5 TT'
              : 'Rozlicz i usuń'}
          </button>
        </div>
      ))}
      <details>
        <summary>Dodaj efekt warunkowy</summary>
        <label>
          Nazwa i warunek
          <input
            value={label}
            maxLength={300}
            onChange={(e) => setLabel(e.target.value)}
          />
        </label>
        <label>
          Czas
          <input
            type="number"
            min="1"
            max="1000"
            value={remaining}
            onChange={(e) => setRemaining(e.target.value)}
          />
        </label>
        <label>
          Odliczaj
          <select
            value={phase}
            onChange={(e) => setPhase(e.target.value as CombatEffect['phase'])}
          >
            <option value="start">Początki tur BG</option>
            <option value="end">Końce tur BG</option>
            <option value="round">Końce rund</option>
            <option value="manual">Rozliczenie ręczne</option>
          </select>
        </label>
        <label>
          Dotyczy
          <select
            value={target}
            onChange={(e) =>
              setTarget(e.target.value as CombatEffect['target'])
            }
          >
            {Object.entries({
              all: 'Wszystkie testy',
              attack: 'Atak',
              damage: 'Obrażenia',
              str: 'Siła',
              dex: 'Zręczność',
              con: 'Kondycja',
              int: 'Inteligencja',
              wis: 'Mądrość',
              cha: 'Charyzma',
              save: 'Rzuty Obronne',
              skill: 'Umiejętności',
            }).map(([id, name]) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Modyfikator
          <input
            type="number"
            min="-100"
            max="100"
            value={modifier}
            onChange={(e) => setModifier(e.target.value)}
          />
        </label>
        <label>
          Warunki
          <select
            value={mode}
            onChange={(e) => setMode(e.target.value as CombatEffect['mode'])}
          >
            <option value="normal">Zwykły test</option>
            <option value="advantage">Ułatwienie</option>
            <option value="disadvantage">Utrudnienie</option>
          </select>
        </label>
        <button
          disabled={
            locked ||
            !label.trim() ||
            !Number.isInteger(Number(remaining)) ||
            Number(remaining) < 1 ||
            Number(remaining) > 1000 ||
            !Number.isInteger(Number(modifier)) ||
            Math.abs(Number(modifier)) > 100
          }
          onClick={() =>
            void send({
              kind: 'effect',
              effect: {
                id: crypto.randomUUID(),
                label,
                remaining: Number(remaining),
                phase,
                target,
                modifier: Number(modifier),
                mode,
              },
            }).then((ok) => {
              if (ok) setLabel('');
            })
          }
        >
          Dodaj efekt
        </button>
      </details>
    </section>
  );
}
