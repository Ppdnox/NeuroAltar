import { Zap } from 'lucide-react';
import { DedicatedIcon } from '../../components/DedicatedIcon';
import { ruleIllustration } from './ruleIconMapping';
import './ruleIllustration.css';

export function RuleIllustration({ ruleId }: { ruleId: string }) {
  const path = ruleIllustration(ruleId);
  return (
    <span className="bg-rule-illustration" aria-hidden="true">
      {path ? (
        <DedicatedIcon path={path} />
      ) : (
        <Zap strokeWidth={1.5} focusable="false" />
      )}
    </span>
  );
}
