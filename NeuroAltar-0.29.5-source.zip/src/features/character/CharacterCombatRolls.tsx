import { useParticipationStore } from '../../stores/participationStore';
import { CombatAbilities } from './CombatAbilities';
import { useState } from 'react';
import type { Character, Ability } from '../../domain/character/model';
import { ABILITIES, abilityNames } from '../../domain/character/model';
import { skills } from '../../domain/character/catalog';
import {
  characterCombatValues,
  checkContext,
  bleedingPerTurn,
  type Participation,
} from '../../domain/character/participation';
import { deriveInventoryWeapon } from '../../domain/character/equipped';
import type { FireMode } from '../../domain/character/inventoryModel';
import { useDiceStore } from '../../stores/diceStore';
import { useInitiativeStore } from '../../stores/initiativeStore';
import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';
import {
  rollCharacter,
  characterRollSettings,
  defaultRollSettings,
} from '../../services/characterRolls';
export function CharacterCombatRolls({
  record,
  participation: p,
  disabled,
}: {
  record: Character;
  participation: Participation;
  disabled: boolean;
}) {
  const dice = useDiceStore();
  const settings = characterRollSettings(
    (s) => s.values[record.id] ?? defaultRollSettings,
  );
  const { adv, dis, manual } = settings;
  const setAdv = (adv: boolean) =>
    characterRollSettings.getState().set(record.id, { adv });
  const setDis = (dis: boolean) =>
    characterRollSettings.getState().set(record.id, { dis });
  const setManual = (manual: string) =>
    characterRollSettings.getState().set(record.id, { manual });
  const [fire, setFire] = useState<Record<string, FireMode>>({}),
    [counts, setCounts] = useState<Record<string, string>>({}),
    [distances, setDistances] = useState<Record<string, 'normal' | 'long'>>({});
  const v = characterCombatValues(record, p)!;
  const penalty =
    2 *
    Math.min(
      6,
      v.condition.exhaustion.reduce((s, e) => s + e.level, 0),
    );
  const slot = p.encounterId as SlotId;
  const actor = useCombatStore((s) =>
    s.drafts[slot]?.value.actors.find((a) => a.id === p.actorId),
  );
  const statuses = new Set(actor?.effects?.map((e) => e.systemKey));
  const initiativeContext = checkContext(
    p.effects,
    ['dex'],
    adv || v.derived.classLevels.brutal >= 9,
    dis || statuses.has('incapacitated'),
  );
  const roll = (
    formula: string,
    label: string,
    targets: string[],
    purpose?: 'attack' | 'damage',
    sourceKey?: string,
    disadvantage = false,
  ) =>
    rollCharacter(
      record,
      p,
      formula,
      label,
      targets,
      purpose,
      sourceKey,
      disadvantage,
    );
  const checkButton = (
    label: string,
    value: number | null,
    targets: string[],
  ) => (
    <button
      className="secondary-button"
      disabled={disabled || dice.busy || !!dice.pending || value === null}
      onClick={() => void roll(String(value), label, targets)}
    >
      {label} {value === null ? '—' : `${value >= 0 ? '+' : ''}${value}`}
    </button>
  );
  return (
    <>
      <details>
        <summary>Warunki rzutu / ręczna kość</summary>
        <label>
          <input
            type="checkbox"
            checked={adv}
            onChange={(e) => setAdv(e.target.checked)}
          />{' '}
          Ułatwienie
        </label>
        <label>
          <input
            type="checkbox"
            checked={dis}
            onChange={(e) => setDis(e.target.checked)}
          />{' '}
          Utrudnienie
        </label>
        <label>
          Ręczny wynik k20 (puste: rzut)
          <input
            type="number"
            min="1"
            max="20"
            value={manual}
            onChange={(e) => setManual(e.target.value)}
          />
        </label>
        <p>
          Ułatwienie i Utrudnienie znoszą się. Efekty tej walki są doliczane.
          Ręczny wynik oznacza już wybraną kość.
        </p>
      </details>
      <div className="actor-actions">
        {ABILITIES.map((a) => (
          <span key={a}>
            {checkButton(abilityNames[a], v.derived.modifiers[a], [a])}
          </span>
        ))}
        <button
          className="secondary-button"
          disabled={disabled || v.derived.initiative.value === null}
          onClick={() =>
            void useInitiativeStore
              .getState()
              .roll(
                slot,
                p.actorId,
                (v.derived.initiative.value ?? 0) -
                  penalty +
                  initiativeContext.modifier,
                {
                  mode: initiativeContext.mode,
                  ...(manual ? { manual: Number(manual) } : {}),
                  name: v.name,
                },
              )
          }
        >
          Inicjatywa {v.derived.initiative.value}
        </button>
      </div>
      <details>
        <summary>Rzuty Obronne i umiejętności</summary>
        <div className="actor-actions">
          {ABILITIES.map((a) => (
            <span key={a}>
              {checkButton(
                'RO ' + abilityNames[a],
                v.derived.check('save:' + a, a).value,
                [a, 'save'],
              )}
            </span>
          ))}
          {skills.map((s) => (
            <span key={s.id}>
              {checkButton(
                s.label,
                v.derived.check('skill:' + s.id, s.ability as Ability).value,
                [s.ability, 'skill', 'skill:' + s.id],
              )}
            </span>
          ))}
        </div>
      </details>
      <h3>Broń i ataki</h3>
      {record.inventory?.entries
        .filter((e) => e.weapon && e.slot !== 'none')
        .map((e) => {
          const mode = fire[e.id] ?? 'single',
            count = Number(
              counts[e.id + ':' + mode] ?? (mode === 'massive' ? '50' : '10'),
            ),
            w = deriveInventoryWeapon(
              v.sheet,
              e,
              mode,
              count,
              'auto',
              undefined,
              record.inventory,
              distances[e.id] ?? 'normal',
            );
          if (!w) return null;
          return (
            <article key={e.id} className="inventory-entry">
              <h4>{e.item.name}</h4>
              {e.item.weaponProfile?.attackKind === 'ranged' && (
                <label>
                  Dystans
                  <select
                    value={distances[e.id] ?? 'normal'}
                    onChange={(event) =>
                      setDistances({
                        ...distances,
                        [e.id]: event.target.value as 'normal' | 'long',
                      })
                    }
                  >
                    <option value="normal">Normalny zasięg</option>
                    <option value="long">Daleki zasięg</option>
                  </select>
                </label>
              )}
              <label>
                Tryb
                <select
                  value={mode}
                  onChange={(event) =>
                    setFire({ ...fire, [e.id]: event.target.value as FireMode })
                  }
                >
                  {e.weapon!.modes.map((m) => (
                    <option key={m} value={m}>
                      {
                        {
                          single: 'Pojedynczy',
                          double: 'Podwójny',
                          short: 'Krótka seria',
                          long: 'Długa seria',
                          massive: 'Miażdżąca seria',
                        }[m]
                      }
                    </option>
                  ))}
                </select>
              </label>
              {['long', 'massive'].includes(mode) && (
                <label>
                  Liczba naboi
                  <select
                    value={count}
                    onChange={(event) =>
                      setCounts({
                        ...counts,
                        [e.id + ':' + mode]: event.target.value,
                      })
                    }
                  >
                    {(mode === 'massive'
                      ? [50, 100, 150, 200]
                      : [10, 15, 20, 25, 30]
                    ).map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {e.item.weaponProfile?.attackKind === 'melee' && (
                <div className="actor-actions">
                  <button
                    disabled={disabled}
                    onClick={() =>
                      void useParticipationStore
                        .getState()
                        .send(p.actorId, p.encounterId as SlotId, record.id, {
                          kind: 'weaponAttack',
                          weaponId: e.id,
                          bonus: false,
                        })
                    }
                  >
                    Rozlicz atak wręcz
                  </button>
                  {v.sheet.levels.some((l) =>
                    (l.choices['favorite-weapon'] ?? []).some((n) =>
                      [e.weapon!.model, e.item.name].some(
                        (model) =>
                          model.trim().toLocaleLowerCase('pl') ===
                          n.trim().toLocaleLowerCase('pl'),
                      ),
                    ),
                  ) && (
                    <button
                      disabled={disabled}
                      onClick={() =>
                        void useParticipationStore
                          .getState()
                          .send(p.actorId, p.encounterId as SlotId, record.id, {
                            kind: 'weaponAttack',
                            weaponId: e.id,
                            bonus: true,
                          })
                      }
                    >
                      Ulubiona broń — dodatkowy atak (B)
                    </button>
                  )}
                </div>
              )}
              <div className="actor-actions">
                {!['long', 'massive'].includes(mode) && (
                  <button
                    disabled={disabled || w.attack === null || dice.busy}
                    onClick={() =>
                      void roll(
                        String(w.attack),
                        'Atak — ' + e.item.name,
                        ['attack', w.ability],
                        'attack',
                        'weapon:' + e.id + ':' + mode,
                        w.disadvantage,
                      )
                    }
                  >
                    Atak {w.attack}
                  </button>
                )}
                <button
                  disabled={disabled || dice.busy || w.damage.includes('?')}
                  onClick={() =>
                    void roll(
                      w.damage,
                      'Obrażenia — ' + e.item.name,
                      ['damage', w.ability],
                      'damage',
                      'weapon:' + e.id + ':' + mode,
                    )
                  }
                >
                  Obrażenia {w.damage} {w.damageType}
                </button>
              </div>
              <p>
                Zasięg {w.range.normal ?? '—'}/{w.range.long ?? '—'} m
              </p>
            </article>
          );
        })}
      {v.condition.combatHealth?.bleeding &&
        bleedingPerTurn(v.sheet.rulesContext.gameColor, v.condition.injury) >
          0 && (
          <p className="bg-notice">
            Zranienie: sprawdź krwawienie — łącznie 1 PW na początku tury,
            dopóki nie zostanie zatrzymane. Ubytek zatwierdzasz w zdrowiu
            postaci.
          </p>
        )}
      <CombatAbilities record={record} participation={p} disabled={disabled} />
    </>
  );
}
