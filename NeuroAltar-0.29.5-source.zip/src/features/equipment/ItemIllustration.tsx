import { DedicatedIcon } from '../../components/DedicatedIcon';
import { dedicatedItemIcon } from './itemIcon';
import type { ReactNode } from 'react';
import {
  Anvil,
  Apple,
  Axe,
  Backpack,
  Battery,
  Beef,
  Binoculars,
  BookOpen,
  BriefcaseMedical,
  Cable,
  Cat,
  CircuitBoard,
  Coffee,
  Compass,
  PcCase,
  Stamp,
  Crosshair,
  Gamepad2,
  KeyRound,
  SquareTerminal,
  FireExtinguisher,
  Dices,
  Disc3,
  Dog,
  Drum,
  Egg,
  Fish,
  Flame,
  FlaskConical,
  Flashlight,
  Footprints,
  Fuel,
  Gem,
  Guitar,
  Hammer,
  Hand,
  HandFist,
  HardHat,
  Laptop,
  Link,
  Lock,
  Map,
  Megaphone,
  Milk,
  Monitor,
  Music,
  Package,
  Paintbrush,
  Piano,
  Pickaxe,
  Pill,
  PocketKnife,
  Radar,
  Radio,
  Rat,
  Ruler,
  Scissors,
  Shield,
  Shirt,
  Shovel,
  ShoppingCart,
  Skull,
  Speaker,
  SprayCan,
  Sword,
  Syringe,
  Tent,
  Usb,
  Utensils,
  Wheat,
  Whistle,
  Wind,
  Wine,
  Wrench,
  Bird,
  Cigarette,
  Lamp,
  Search,
  type LucideIcon,
} from 'lucide-react';
import {
  itemIllustration,
  type IllustratedItem,
  type ItemIllustrationKind,
} from './itemPictogram';
import './itemIllustration.css';

// A few equipment silhouettes absent from Lucide share its rounded outline style.
const drawings: Partial<Record<ItemIllustrationKind, ReactNode>> = {
  pistol: (
    <>
      <path d="M7 13h33v8H23l-5 16H9l5-16H7z" />
      <path d="M23 21h7v5a4 4 0 0 1-4 4h-5M10 17h27M25 22v4M33 10v3" />
    </>
  ),
  revolver: (
    <>
      <path d="M27 15h15v6H28M15 14l-5-3M14 24 8 37h10l5-11M26 25h6v4a4 4 0 0 1-4 4h-7" />
      <circle cx="21" cy="20" r="7" />
      <path d="M18 17v6m6-6v6M39 12v3" />
    </>
  ),
  smg: (
    <>
      <path d="M12 14h23v10H12zM35 17h9v5h-9M12 17H5v13h5l5-6M19 24l-3 12h6l3-12M28 24v15h6V24" />
      <path d="M16 18h7m4 0h4M15 11v3m15-3v3" />
    </>
  ),
  rifle: (
    <>
      <path d="M4 21h8l5-5h17v8H17l-6 9H4zM34 18h11v4H34M21 24l-3 11h6l2-11M29 24l3 11h5l-4-11" />
      <path d="M21 12h9m-7 0v4m5-4v4M18 20h12M7 24v5" />
    </>
  ),
  shotgun: (
    <>
      <path d="M4 24h8l6-6h27v6H23l-6 5-6 6H4zM19 24l-3 10h6l4-10" />
      <path d="M29 18v6m4-6v6m4-6v6M21 15h23M7 27v4" />
    </>
  ),
  laserPistol: (
    <>
      <path d="M8 13h31l4 4-4 6H24l-4 14H10l4-14H8zM29 23v7h-7M34 13v10" />
      <path d="m24 15-4 5h5l-3 5M10 17h5" />
    </>
  ),
  laserRifle: (
    <>
      <path d="M4 21h8l5-6h22v10H17l-6 9H4zM39 18h6v5h-6M22 25l-3 10h7l3-10" />
      <path d="m28 17-4 5h5l-3 5M34 15v10M18 11h14m-11 0v4" />
    </>
  ),
  ammo: (
    <>
      <path d="M8 36V17l4-7 4 7v19zM20 36V13l4-7 4 7v23zM32 36V17l4-7 4 7v19z" />
      <path d="M8 31h8m4 0h8m4 0h8M7 39h10m2 0h10m2 0h10" />
    </>
  ),
  shells: (
    <>
      <rect x="9" y="12" width="12" height="24" rx="2" />
      <rect x="27" y="8" width="12" height="28" rx="2" />
      <path d="M9 29h12m6 0h12M8 39h14m4 0h14M13 16h4m14-4h4" />
    </>
  ),
  magazine: (
    <>
      <path d="M15 7h17v15c0 8 3 13 7 18H20c-4-5-5-11-5-18z" />
      <path d="M15 12h17M21 17v7c0 4 1 7 2 10M27 17v7c0 4 1 7 2 10" />
    </>
  ),
  arrows: (
    <>
      <path d="M13 39 29 9m-9 4 9-4 1 10M21 41 37 11m-9 4 9-4 1 10M13 39l-5-2 1-6m4 8 6 1 4-4M21 41l-5-2" />
    </>
  ),
  rocket: (
    <>
      <path d="M20 9q4-7 8 0v24h-8zM20 26l-6 11h6m8-11 6 11h-6M20 15h8M23 37v5m4-5v5" />
    </>
  ),
  bow: (
    <>
      <path d="M12 6q31 18 0 36M12 6l14 18-14 18M6 24h34m-6-5 6 5-6 5" />
    </>
  ),
  crossbow: (
    <>
      <path d="M9 7q-4 17 15 22Q43 24 39 7M9 7l15 12L39 7M21 20v21h6V20M24 5v22m-4-17 4-5 4 5" />
    </>
  ),
  boomerang: (
    <>
      <path d="m8 35 9-26q2-4 5-1l17 20q2 4-2 5L22 18l-7 20q-5 5-7-3Z" />
    </>
  ),
  slingshot: (
    <>
      <path d="m9 8 7 17 5 4v12h6V29l5-4 7-17M9 8l15 12L39 8M16 25l8-5 8 5" />
    </>
  ),
  spear: (
    <>
      <path d="m12 42 17-29M24 14l8-10 2 13-5-4zM17 33l4 2" />
    </>
  ),
  saw: (
    <>
      <path d="M9 26h10v13H7V28a2 2 0 0 1 2-2ZM19 28l17-17q6-4 8 2L25 33h-6M11 26v-5h7v6" />
      <path d="m24 23 3 3m2-8 3 3m2-8 3 3M11 32h4" />
    </>
  ),
  whip: (
    <>
      <path d="m8 40 7-12 5 3-7 12zM17 28c2-5-8-8-4-15 5-8 18-8 23-2 7 9-12 15-11 7 0-4 6-5 9-3" />
    </>
  ),
  grenade: (
    <>
      <path d="M18 13h12v5c7 5 9 16 3 22H15c-6-6-4-17 3-22zM18 13V8h13l6 17" />
      <path d="M13 25h22M12 32h24M20 18v22m8-22v22" />
      <circle cx="36" cy="10" r="4" />
    </>
  ),
  mine: (
    <>
      <ellipse cx="24" cy="30" rx="18" ry="7" />
      <path d="M6 30v5c3 9 33 9 36 0v-5M15 25l3-8h12l3 8M21 17v-5h6v5" />
    </>
  ),
  dynamite: (
    <>
      <rect x="9" y="14" width="7" height="26" rx="3" />
      <rect x="20" y="14" width="7" height="26" rx="3" />
      <rect x="31" y="14" width="7" height="26" rx="3" />
      <path d="M8 23h31M8 31h31M24 14V9q0-5 8-4m1 0 3-2m-1 4 4 1" />
    </>
  ),
  explosive: (
    <>
      <rect x="10" y="20" width="28" height="19" rx="3" />
      <path d="M16 20v19m16-19v19M20 20V10h9v10M25 10V6m-7 4-4-3m19 3 4-3" />
    </>
  ),
  armor: (
    <>
      <path d="M16 6h5q3 5 6 0h5l7 7-5 8v20H14V21l-5-8z" />
      <path d="M18 17h12v10H18zM18 31h5v6h-5zm7 0h5v6h-5zM14 21h-4m24 0h4" />
    </>
  ),
  mask: (
    <>
      <path d="M11 14q13-13 26 0v15l-8 10H19l-8-10zM11 18H6v12h7m24-12h5v12h-7" />
      <ellipse cx="18" cy="19" rx="5" ry="4" />
      <ellipse cx="30" cy="19" rx="5" ry="4" />
      <circle cx="24" cy="31" r="5" />
      <path d="M22 28v6m4-6v6" />
    </>
  ),
  accordion: (
    <>
      <rect x="5" y="13" width="11" height="24" rx="2" />
      <rect x="32" y="13" width="11" height="24" rx="2" />
      <path d="M16 15h16v20H16M20 15v20m4-20v20m4-20v20M8 13V9h5v4m22 0V9h5v4M5 19h7m-7 6h7m-7 6h7M12 13v24" />
      <path d="M36 19h1m2 4h1m-4 4h1m2 4h1" />
    </>
  ),
  violin: (
    <>
      <path d="m26 6 4 1-6 18M21 14c-10-3-14 5-6 10-13 8-2 20 5 15 7-4 6-11 1-13 8-2 9-8 4-11M20 26l-4 9M35 8 26 41" />
    </>
  ),
  saxophone: (
    <>
      <path d="M22 7h8l3 4-4 3-3-3h-2v20c0 9-14 12-17 2l-2-8 12-3-1 10q3 4 5-1V7" />
      <path d="M24 16h4m-4 5h4m-4 5h4M5 25l12-3" />
    </>
  ),
  harmonica: (
    <>
      <path d="M5 17h38v16H5zM5 22h38M10 25v5m6-5v5m6-5v5m6-5v5m6-5v5m5-5v5" />
    </>
  ),
  toolbox: (
    <>
      <rect x="6" y="17" width="36" height="23" rx="3" />
      <path d="M17 17v-7h14v7M6 25h36M21 22h6v7h-6zM11 32h8" />
    </>
  ),
  bottle: (
    <>
      <path d="M19 7h10v7l5 7v19H14V21l5-7zM19 11h10M14 25h20M18 29h12" />
    </>
  ),
  water: (
    <>
      <path d="M19 7h10v7l5 7v19H14V21l5-7zM19 11h10M14 28q5-4 10 0t10 0" />
    </>
  ),
  can: (
    <>
      <ellipse cx="24" cy="11" rx="13" ry="5" />
      <path d="M11 11v27c0 7 26 7 26 0V11M11 22h26m-26 11h26M21 10h6" />
    </>
  ),
  sleeping: (
    <>
      <path d="M13 16c0-14 22-14 22 0v25H13zM13 17h22M13 26h22m-22 8h22M28 17v24" />
      <path d="M18 13q6-7 12 0" />
    </>
  ),
  rope: (
    <>
      <ellipse cx="24" cy="21" rx="13" ry="15" />
      <ellipse cx="24" cy="21" rx="8" ry="11" />
      <path d="M24 32c-6 0-4-17 0-17s6 10 3 19q-2 9-12 8M31 10l4-4" />
    </>
  ),
  candle: (
    <>
      <path d="M18 22h12v18H18zM15 40h18M24 22v-4M24 6q-10 9 0 12 10-3 0-12Z" />
    </>
  ),
  mirror: (
    <>
      <ellipse cx="24" cy="18" rx="12" ry="14" />
      <path d="M21 32v11h6V32M19 20l9-9m-6 15 7-7" />
    </>
  ),
  tape: (
    <>
      <circle cx="21" cy="22" r="14" />
      <circle cx="21" cy="22" r="7" />
      <path d="M35 22v15h8v5H21" />
    </>
  ),
  ski: (
    <>
      <path d="M12 7c0-5 6-5 6 0v33h-6zM23 7c0-5 6-5 6 0v33h-6zM13 23h4m7 0h4M38 8v32m-4-5h8" />
    </>
  ),
  horse: (
    <>
      <path d="m8 22 5-9 15 2 5-10 3 6 7 6-3 6-8-2-2 8H13l-3 12H6l3-17M18 29v12m11-12 5 12h5l-4-17M13 13l-5 2-4 9" />
      <path d="M37 15h.1" />
    </>
  ),
  livestock: (
    <>
      <path d="M10 16h18l5-6 8 3v12l-7 3-5-6-2 8H12zM12 30v11m6-11v11m7-11 6 11M10 16l-5 2v12M33 10l-4-6m9 8 5-6" />
      <path d="M36 18h.1" />
    </>
  ),
};

const icons: Partial<Record<ItemIllustrationKind, LucideIcon>> = {
  knife: PocketKnife,
  sword: Sword,
  axe: Axe,
  hammer: Hammer,
  pickaxe: Pickaxe,
  chain: Link,
  fist: HandFist,
  flame: Flame,
  helmet: HardHat,
  shield: Shield,
  gloves: Hand,
  boots: Footprints,
  clothes: Shirt,
  guitar: Guitar,
  piano: Piano,
  drum: Drum,
  music: Music,
  backpack: Backpack,
  medical: BriefcaseMedical,
  pill: Pill,
  syringe: Syringe,
  flask: FlaskConical,
  wrench: Wrench,
  scissors: Scissors,
  anvil: Anvil,
  gem: Gem,
  dice: Dices,
  brush: Paintbrush,
  ruler: Ruler,
  shovel: Shovel,
  battery: Battery,
  computer: PcCase,
  stamp: Stamp,
  hunting: Crosshair,
  remote: Gamepad2,
  lockpick: KeyRound,
  terminal: SquareTerminal,
  extinguisher: FireExtinguisher,
  laptop: Laptop,
  monitor: Monitor,
  radio: Radio,
  radar: Radar,
  circuit: CircuitBoard,
  usb: Usb,
  speaker: Speaker,
  microphone: Megaphone,
  disc: Disc3,
  power: Cable,
  fan: Wind,
  food: Utensils,
  coffee: Coffee,
  meat: Beef,
  fish: Fish,
  fruit: Apple,
  milk: Milk,
  grain: Wheat,
  egg: Egg,
  fuel: Fuel,
  wine: Wine,
  cigarette: Cigarette,
  poison: Skull,
  cleaning: SprayCan,
  tent: Tent,
  flashlight: Flashlight,
  lamp: Lamp,
  compass: Compass,
  map: Map,
  book: BookOpen,
  binoculars: Binoculars,
  magnifier: Search,
  lock: Lock,
  whistle: Whistle,
  cart: ShoppingCart,
  dog: Dog,
  cat: Cat,
  bird: Bird,
  rat: Rat,
  package: Package,
};

export function ItemIllustration({
  item,
  size = 'regular',
}: {
  item: IllustratedItem;
  size?: 'small' | 'regular';
}) {
  const dedicated = dedicatedItemIcon(item);
  const kind = itemIllustration(item);
  const drawing = drawings[kind];
  const Icon = icons[kind] ?? Package;
  return (
    <span
      className={`item-illustration item-illustration--${size}`}
      aria-hidden="true"
      data-item-illustration={kind}
    >
      {dedicated ? (
        <DedicatedIcon path={dedicated} />
      ) : drawing ? (
        <svg
          viewBox="0 0 48 48"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          focusable="false"
        >
          {drawing}
        </svg>
      ) : (
        <Icon strokeWidth={1.5} focusable="false" />
      )}
    </span>
  );
}
