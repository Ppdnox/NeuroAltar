import type { Item } from '../../domain/item';

export type IllustratedItem = Pick<Item, 'name' | 'category' | 'type'>;
export type ItemIllustrationKind =
  | 'pistol'
  | 'revolver'
  | 'smg'
  | 'rifle'
  | 'shotgun'
  | 'laserPistol'
  | 'laserRifle'
  | 'ammo'
  | 'shells'
  | 'magazine'
  | 'arrows'
  | 'rocket'
  | 'knife'
  | 'sword'
  | 'axe'
  | 'hammer'
  | 'pickaxe'
  | 'chain'
  | 'whip'
  | 'fist'
  | 'bow'
  | 'crossbow'
  | 'boomerang'
  | 'slingshot'
  | 'spear'
  | 'saw'
  | 'grenade'
  | 'mine'
  | 'dynamite'
  | 'explosive'
  | 'flame'
  | 'armor'
  | 'helmet'
  | 'shield'
  | 'gloves'
  | 'boots'
  | 'mask'
  | 'clothes'
  | 'accordion'
  | 'guitar'
  | 'piano'
  | 'drum'
  | 'violin'
  | 'saxophone'
  | 'harmonica'
  | 'music'
  | 'backpack'
  | 'medical'
  | 'pill'
  | 'syringe'
  | 'flask'
  | 'toolbox'
  | 'stamp'
  | 'hunting'
  | 'remote'
  | 'lockpick'
  | 'terminal'
  | 'extinguisher'
  | 'wrench'
  | 'scissors'
  | 'anvil'
  | 'gem'
  | 'dice'
  | 'brush'
  | 'ruler'
  | 'shovel'
  | 'battery'
  | 'computer'
  | 'laptop'
  | 'monitor'
  | 'radio'
  | 'radar'
  | 'circuit'
  | 'usb'
  | 'speaker'
  | 'microphone'
  | 'disc'
  | 'power'
  | 'fan'
  | 'food'
  | 'water'
  | 'coffee'
  | 'meat'
  | 'fish'
  | 'fruit'
  | 'milk'
  | 'grain'
  | 'egg'
  | 'can'
  | 'fuel'
  | 'wine'
  | 'cigarette'
  | 'bottle'
  | 'poison'
  | 'cleaning'
  | 'tent'
  | 'sleeping'
  | 'rope'
  | 'flashlight'
  | 'lamp'
  | 'candle'
  | 'compass'
  | 'map'
  | 'book'
  | 'binoculars'
  | 'magnifier'
  | 'mirror'
  | 'tape'
  | 'lock'
  | 'whistle'
  | 'cart'
  | 'ski'
  | 'horse'
  | 'livestock'
  | 'dog'
  | 'cat'
  | 'bird'
  | 'rat'
  | 'package';

const normalize = (text: string) =>
  text
    .toLocaleLowerCase('pl')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ł/g, 'l');
type Rule = readonly [RegExp, ItemIllustrationKind];
const match = (text: string, rules: readonly Rule[]) =>
  rules.find(([pattern]) => pattern.test(text))?.[1];

// Saved inventory snapshots can predate the catalog's medicine categories.
const medicineNames = new Set([
  'desmopresyna',
  'aspiryna k',
  'dracophen',
  'reminex',
  'relanium',
  'wapniak',
  'psychotropy',
  'actinix',
  'anestix',
  'antybiotyk',
  'ar-23',
  'ar-35 beta',
  'deadline',
  'detoks',
  'medpak',
  'neuro-cola',
  'painkiller',
  'radmov',
  'radoff',
  'taurus',
  'trybiotyl',
  'wd-tabs',
]);

/** Visual classification only; never determines item rules or inventory behavior. */
export function itemIllustration(item: IllustratedItem): ItemIllustrationKind {
  const name = normalize(item.name);
  const category = normalize(item.category);
  const text = `${name} ${category}`;
  if (/akordeon|accordion/.test(name)) return 'accordion';

  // Medicine names such as AR-23, Taurus and Neuro-Cola are not weapons or food.
  const medicineName = name
    .replace(/\s*\(\d+\s+(?:dawek|fiolek|tabletek)\)\s*$/, '')
    .trim();
  if (
    /lekarstwa|srodki lecznicze/.test(category) ||
    medicineNames.has(medicineName)
  )
    return /medpak|detoks|fiolk/.test(name) ? 'medical' : 'pill';
  if (/maly medyk|maly aptekarz|medyka|defibrylator|^staza$|apteczk/.test(name))
    return 'medical';

  // Magazine names in the seed are simply "Broń palna krótka/długa/...".
  if (/kolczan/.test(name)) return 'arrows';
  if (/magazynk/.test(category) || /magazynek|szybkoladowarka/.test(name))
    return 'magazine';
  if (item.type === 'ammunition' || /amunicja/.test(category)) {
    return (
      match(name, [
        [/strzal|belt/, 'arrows'],
        [/strzykaw/, 'syringe'],
        [/granat|pocisk (60|120)/, 'rocket'],
        [/\.12|srut|brenek/, 'shells'],
      ]) ?? 'ammo'
    );
  }

  const instrument = match(name, [
    [/gitara|banjo/, 'guitar'],
    [/skrzyp|kontrabas/, 'violin'],
    [/keyboard|pianin|fortepian/, 'piano'],
    [/perkus|beben/, 'drum'],
    [/saksofon/, 'saxophone'],
    [/harmonijk/, 'harmonica'],
    [/mikser audio|glosnik/, 'speaker'],
  ]);
  if (instrument) return instrument;
  if (/instrumenty muzyczne/.test(category)) return 'music';

  if (
    item.type === 'armor' ||
    /pancerz|zbroj|plate carrier|helm|tarcza|tarcze/.test(text)
  ) {
    return (
      match(name, [
        [/helm/, 'helmet'],
        [/tarcz/, 'shield'],
        [/ochraniacze nog/, 'boots'],
        [/ochraniacze rak/, 'gloves'],
      ]) ?? 'armor'
    );
  }

  if (
    item.type === 'weapon' ||
    /bron |pistole|rewolwer|karabin|strzelb|kusz|\bluk\b/.test(text)
  ) {
    const special = match(name, [
      [/bigbeamgun/, 'laserRifle'],
      [/beamgun/, 'laserPistol'],
      [/kusz/, 'crossbow'],
      [/\bluk\b/, 'bow'],
      [/proca/, 'slingshot'],
      [/bumerang/, 'boomerang'],
      [/obrzyn|dwururk|pompka|strzelb/, 'shotgun'],
      [/dynamit/, 'dynamite'],
      [/\bmina\b/, 'mine'],
      [/granat/, 'grenade'],
      [/molotow/, 'flame'],
      [/ladunek|plastik c4/, 'explosive'],
      [/szoker/, 'power'],
      [/lancuch/, 'chain'],
      [/\bbat\b/, 'whip'],
      [/kastet/, 'fist'],
      [/pila spalinowa/, 'saw'],
      [/kilof/, 'pickaxe'],
      [/kafar|nadziak|bejsbol|rurka/, 'hammer'],
      [/siekier|topor|crash/, 'axe'],
      [/noz/, 'knife'],
      [/katana|szabla|maczeta|pilomiec/, 'sword'],
      [/wloczn|oszczep|widly|dmuchawka/, 'spear'],
      [/bolas/, 'rope'],
    ]);
    if (special) return special;
    if (/pistolety maszynowe/.test(category)) return 'smg';
    if (/rewolwer/.test(text)) return 'revolver';
    if (/strzelb/.test(text)) return 'shotgun';
    if (/pistolet|bron kombinowana/.test(category) || /pistolet/.test(name))
      return 'pistol';
    if (/karabin|bron palna/.test(category)) return 'rifle';
    return 'sword';
  }

  if (/zywe istoty/.test(category)) {
    return (
      match(name, [
        [/kon\b|konia/, 'horse'],
        [/pies/, 'dog'],
        [/kot/, 'cat'],
        [/kura|ptak/, 'bird'],
        [/szczur/, 'rat'],
      ]) ?? 'livestock'
    );
  }

  if (item.type === 'food') {
    return (
      match(name, [
        [/woda/, 'water'],
        [/kaw|herbat/, 'coffee'],
        [/mieso/, 'meat'],
        [/ryb/, 'fish'],
        [/owoce|warzywa/, 'fruit'],
        [/mleko|maslo|\bser\b/, 'milk'],
        [/chleb|ziarno/, 'grain'],
        [/jajko/, 'egg'],
        [/konserw/, 'can'],
        [/olej/, 'bottle'],
      ]) ?? 'food'
    );
  }
  if (item.type === 'fuel') return 'fuel';
  if (/narkotyki/.test(category)) return 'pill';
  if (/pirotechniczne/.test(category)) return 'explosive';

  const everyday = match(name, [
    [/plecak|zestaw startowy|torba/, 'backpack'],
    [/latark|czolowk/, 'flashlight'],
    [/noktowizor|termowizor|lornetk/, 'binoculars'],
    [/bateri|akumulator/, 'battery'],
    [/laptop/, 'laptop'],
    [/komputer/, 'computer'],
    [/monitor/, 'monitor'],
    [/detonator|zapalnik elektryczny/, 'explosive'],
    [/radio|krotkofalow/, 'radio'],
    [/detektor|miernik|wykrywacz/, 'radar'],
    [/analizator chemiczny/, 'flask'],
    [/agregat|alternator/, 'power'],
    [/turbina/, 'fan'],
    [/nosnik danych/, 'usb'],
    [/odtwarzacz cd/, 'disc'],
    [/megafon|mikrofon/, 'microphone'],
    [/kontroler/, 'remote'],
    [/wytrychy elektroniczne/, 'lockpick'],
    [/maly chemik|maly gorzelnik|kwas/, 'flask'],
    [/maly elektronik/, 'circuit'],
    [/maly haker/, 'terminal'],
    [/maly falszerz/, 'stamp'],
    [/maly klusownik/, 'hunting'],
    [/maly kowal/, 'anvil'],
    [/maly krawiec|nozycz/, 'scissors'],
    [/maly jubiler/, 'gem'],
    [/maly szuler/, 'dice'],
    [/maly kartograf|^mapa$/, 'map'],
    [/maly charakteryzator|maly tatuazysta/, 'brush'],
    [/maly kucharz/, 'food'],
    [/maly rzeznik/, 'knife'],
    [/maly stolarz|maly szklarz/, 'ruler'],
    [/maly mechanik|maly slusarz|maly rusznikarz/, 'wrench'],
    [/alkohol/, 'wine'],
    [/cygar|papieros|tyton/, 'cigarette'],
    [/trucizna/, 'poison'],
    [/srodek usypiajacy/, 'flask'],
    [/czyszcz|dezynfekuj|perfum/, 'cleaning'],
    [/namiot/, 'tent'],
    [/gasnicz/, 'extinguisher'],
    [/spiwor|hamak|\bkoc\b/, 'sleeping'],
    [/lina|siec|wspinacz/, 'rope'],
    [/lancuch/, 'chain'],
    [/lopata/, 'shovel'],
    [/kompas/, 'compass'],
    [/ksiazka/, 'book'],
    [/szklo powiekszajace/, 'magnifier'],
    [/klodka/, 'lock'],
    [/gwizdek/, 'whistle'],
    [/wozek/, 'cart'],
    [/narty/, 'ski'],
    [/maska przeciwgazowa|nurkowan/, 'mask'],
    [/kostium|ubran|skafander/, 'clothes'],
    [/swieczk/, 'candle'],
    [/lampa/, 'lamp'],
    [/palnik|zapalnicz|zapalk/, 'flame'],
    [/tasma/, 'tape'],
    [/klej/, 'bottle'],
    [/lusterko/, 'mirror'],
    [/siodlo/, 'horse'],
    [/kolczatki/, 'mine'],
  ]);
  if (everyday) return everyday;
  if (item.type === 'electronics') return 'circuit';
  if (item.type === 'tool') return 'toolbox';
  return 'package';
}
