# Ekwipunek

Uzupełnienie 2026-09-27: zakładki „Ulepszenia broni” i „Fanty” pokazują
statyczne tabele podręcznika. „Pojazdy” to osobny sąsiedni widok z 14 wierszami
tabeli pojazdów, bez indywidualnych statblocków. Dane są współdzielone z
Wiedzą MG i nie są nowym seedem Item. Zobacz `docs/TABELE_PODRECZNIKA.md`.

Etap 20: EquipmentWorkspace, katalog 299 Item i kalkulator handlu. Odczyt przez
repozytorium SQLite, dane startowe src/data/equipment/catalog.v1.json;
reguły regionalne/lokalizacyjne market-rules.v1.json. Kolory tylko w domain/market.ts.
Zustand przechowuje wyłącznie widok, wybór i TradeContext w sesji.

Etap 9: LoadoutFields / AttackProfiles / LoadoutPanel pozostają niezależnymi
osadzonymi profilami bojowymi Item. Katalog handlowy nie aktualizuje tych kopii.
Nie wyprowadzamy niepełnych weaponProfile z opisów źródłowych. Parametry broni
z Excela są zachowane opisowo, bez wymyślonych premii ani wykonania rzutu.
Nie ma runtime importu/synchronizacji Excela, CRUD katalogu ani licznika amunicji.
