import { listKnowledge } from '../../data/knowledge/catalog';
import { useMemo } from 'react';
import {
  formatHandbookPages,
  type KnowledgeEntry,
  type KnowledgeTable,
} from '../../domain/knowledge';
import { KnowledgeTableView } from '../reference/KnowledgeWorkspace';

const upgradeTitles = [
  'Ulepszenia broni białej',
  'Ulepszenia broni dystansowej',
];

export function EquipmentReferenceTables({
  section,
}: {
  section: 'upgrades' | 'loot';
}) {
  const entries = useMemo(() => listKnowledge(), []);
  const titles = section === 'upgrades' ? upgradeTitles : ['Tabela Fantów'];
  return (
    <div className="equipment-reference-tables">
      {titles.map((title) => {
        const entry = entries.find((candidate) => candidate.title === title)!;
        const table = entry.blocks.find(
          (block): block is KnowledgeTable => block.kind === 'table',
        )!;
        return (
          <EquipmentReferenceTable key={entry.id} entry={entry} table={table} />
        );
      })}
    </div>
  );
}

function EquipmentReferenceTable({
  entry,
  table,
}: {
  entry: KnowledgeEntry;
  table: KnowledgeTable;
}) {
  return (
    <article className="knowledge-reader equipment-reference-reader">
      <h3>{entry.title}</h3>
      <KnowledgeTableView entry={entry} table={table} query="" />
      {entry.blocks
        .filter((block) => block.kind === 'text')
        .map((block, index) => (
          <p key={index} className="equipment-table-note">
            {block.text}
          </p>
        ))}
      <p className="editor-hint">
        {entry.handbook.title} · s. {formatHandbookPages(entry.handbook.pages)}
      </p>
    </article>
  );
}
