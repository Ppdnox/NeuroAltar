import { actorRollHandler } from '../../services/actorDice';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { parseActorDraft, type ActorDraft } from '../../domain/combat';
import type { SlotId } from '../../domain/encounterDetails';
import { emptyLoadout } from '../../domain/item';
import { LoadoutFields } from './LoadoutFields';
import { AttackProfiles } from './AttackProfiles';
export function LoadoutPanel({
  slotId,
  actor,
}: {
  slotId: SlotId;
  actor: ActorDraft;
}) {
  const state = useCombatStore();
  const closing = useEncounterStore((s) => s.closing);
  if (!actor.enemy) return null;
  let valid = false;
  try {
    parseActorDraft(actor);
    valid = true;
  } catch {
    /* Keep raw input. */
  }
  const disabled =
    closing ||
    state.closing ||
    !valid ||
    !!state.failureForm ||
    !!state.statblockForm ||
    !!state.loadoutForm ||
    !!state.capabilityForm ||
    !!state.statusForm ||
    !!state.enemyForm;
  return (
    <section className="loadout-panel" aria-label="Broń i profile ataku">
      <h3>Broń i profile ataku</h3>
      <button
        type="button"
        className="secondary-button"
        disabled={disabled}
        onClick={() => state.openLoadoutForm(slotId, actor.id)}
      >
        Edytuj / podmień broń
      </button>
      <p className="editor-hint">
        Naciśnij premię ataku lub kości obrażeń, aby wykonać rzut i zapisać
        wynik w logu.
      </p>
      <AttackProfiles
        onRoll={actorRollHandler(slotId, actor)}
        loadout={actor.enemy.loadout ?? emptyLoadout()}
        failures={actor.enemy.machineFailures}
        disabled={disabled}
        onSelect={(id, patch) =>
          state.selectWeapon(slotId, actor.id, id, patch)
        }
      />
    </section>
  );
}
export function LoadoutForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore();
  const form = state.loadoutForm;
  if (!form || form.slotId !== slotId) return null;
  return (
    <form
      className="enemy-form"
      aria-label="Zestaw broni instancji"
      onSubmit={(e) => {
        e.preventDefault();
        state.submitLoadoutForm();
      }}
    >
      <fieldset disabled={disabled}>
        <legend>Broń tej instancji</legend>
        <p className="editor-hint">
          Zmiany dotyczą tylko tej postaci. Zatwierdzenie obejmuje również
          podmiany i usunięte wiersze. Stan przygotowany zmienisz osobnym
          poleceniem potyczki.
        </p>
        <LoadoutFields value={form.fields} onChange={state.editLoadoutForm} />
        {form.error && (
          <p className="editor-error" role="alert">
            {form.error}
          </p>
        )}
        <div className="actor-actions">
          <button type="submit" className="secondary-button">
            Zatwierdź zestaw broni
          </button>
          <button
            type="button"
            className="secondary-button"
            onClick={state.cancelLoadoutForm}
          >
            Anuluj formularz broni
          </button>
        </div>
      </fieldset>
    </form>
  );
}
