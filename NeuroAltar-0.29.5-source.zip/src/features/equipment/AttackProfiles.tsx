import { RuleText } from '../statblocks/RuleText';
import { RollValue, type ActorRollHandler } from '../dice/ActorRoll';
import {
  failureModifiers,
  failureAttackWarning,
} from '../../domain/machineFailures';
import type { MachineFailure } from '../../domain/machineFailureSchema';
import { Dice5 } from 'lucide-react';
import {
  calculateWeaponAttackProfile,
  formatWeaponRange,
  type CombatLoadout,
  type EquippedItem,
} from '../../domain/item';
export function AttackProfiles({
  loadout,
  onSelect,
  onRoll,
  disabled = false,
  failures = [],
}: {
  loadout: CombatLoadout;
  onRoll?: ActorRollHandler;
  failures?: MachineFailure[];
  onSelect?: (
    id: string,
    patch: Partial<
      Pick<EquippedItem, 'damageModeId' | 'fireModeId' | 'ammoVariantId'>
    >,
  ) => void;
  disabled?: boolean;
}) {
  return (
    <div className="attack-profiles">
      <p className="editor-hint">
        PB {loadout.pb ?? 'N/D'} · SIŁ {loadout.strModifier ?? 'N/D'} · ZRC{' '}
        {loadout.dexModifier ?? 'N/D'} (modyfikatory)
      </p>
      {loadout.items.length === 0 && <p>Brak przypisanej broni.</p>}
      {loadout.items.map((e) => {
        let result: ReturnType<typeof calculateWeaponAttackProfile> | null =
            null,
          error = '';
        try {
          if (e.item.weaponProfile)
            result = calculateWeaponAttackProfile(e, loadout, failures);
        } catch (err) {
          error = err instanceof Error ? err.message : 'Niepoprawny profil.';
        }
        const p = e.item.weaponProfile;
        const mods = failureModifiers(failures);
        const attack = result?.attack ?? 0;
        const warning = p
          ? failureAttackWarning(failures, e.item.id, p.attackKind)
          : failures.some((f) => f.result === 1 && f.weaponId === e.item.id)
            ? 'Broń zniszczona — rozstrzyga MG.'
            : null;
        return (
          <section key={e.item.id} className="attack-profile">
            <h4>
              {e.item.name}{' '}
              {p && (
                <small>
                  · {p.attackKind === 'ranged' ? 'dystansowy' : 'wręcz'}
                </small>
              )}
            </h4>
            {warning && <p className="hp-warning">{warning}</p>}
            {p?.attackKind === 'melee' && mods.halfMelee && (
              <p className="hp-warning">
                Połowa obrażeń wręcz — rozstrzyga MG.
              </p>
            )}
            {result ? (
              <>
                <p className="attack-line">
                  <RollValue
                    formula={`1k20${attack >= 0 ? '+' : ''}${attack}`}
                    label={`Atak — ${e.item.name}`}
                    kind="weaponAttack"
                    onRoll={onRoll}
                    disabled={disabled}
                  >
                    <strong>
                      {attack >= 0 ? '+' : ''}
                      {attack} do ataku
                    </strong>
                  </RollValue>
                  <span>· {formatWeaponRange(result.range)}</span>
                  <span className="dice-formula">
                    <RollValue
                      formula={result.damage.dice}
                      label={`Obrażenia — ${e.item.name}`}
                      kind="damage"
                      onRoll={onRoll}
                      disabled={disabled}
                    >
                      <Dice5 size={20} aria-hidden="true" />{' '}
                      {result.damage.dice}
                    </RollValue>
                  </span>
                  <span>· {result.damage.damageType}</span>
                  {result.damage.average !== null && (
                    <span>· średnia {result.damage.average}</span>
                  )}
                </p>
                {mods.attack !== 0 && (
                  <p className="editor-hint">
                    Uwzględniono karę awarii: {mods.attack}.
                  </p>
                )}
                <details className="profile-calculation">
                  <summary>Skąd premia?</summary>
                  <p>
                    PB {result.pb >= 0 ? '+' : ''}
                    {result.pb}, cecha {result.abilityModifier >= 0 ? '+' : ''}
                    {result.abilityModifier}. Pozostałe premie z profilu i
                    wybranych wariantów.
                  </p>
                </details>
                {result.effects.map((s, i) => (
                  <RuleText
                    key={i}
                    text={s}
                    label={e.item.name}
                    onRoll={onRoll}
                    disabled={disabled}
                  />
                ))}
                {result.properties.length > 0 && (
                  <p>{result.properties.join(' · ')}</p>
                )}
              </>
            ) : (
              <>
                {p ? (
                  <p className="editor-hint">{error}</p>
                ) : (
                  <>
                    <RuleText
                      text={e.item.description || 'Brak opisu przedmiotu.'}
                      label={e.item.name}
                      onRoll={onRoll}
                      disabled={disabled}
                    />
                    {e.item.properties.length > 0 && (
                      <p>{e.item.properties.join(' · ')}</p>
                    )}
                  </>
                )}
              </>
            )}
            {p && (
              <div className="enemy-fields">
                {(
                  [
                    ['damageModeId', 'Formuła', p.damageModes],
                    ['fireModeId', 'Tryb ognia', p.fireModes],
                    ['ammoVariantId', 'Wariant amunicji', p.ammoVariants],
                  ] as const
                )
                  .filter(([key, , list]) =>
                    key === 'damageModeId' ? list.length > 1 : list.length > 0,
                  )
                  .map(([key, label, list]) =>
                    onSelect ? (
                      <label key={key}>
                        <span>{label}</span>
                        <select
                          aria-label={`${label}: ${e.item.name}`}
                          disabled={disabled}
                          value={e[key] ?? ''}
                          onChange={(ev) =>
                            onSelect(e.item.id, {
                              [key]: ev.target.value || null,
                            })
                          }
                        >
                          {key !== 'damageModeId' && (
                            <option value="">N/D — bez zmian</option>
                          )}
                          {list.map((v) => (
                            <option key={v.id} value={v.id}>
                              {v.label}
                            </option>
                          ))}
                        </select>
                      </label>
                    ) : (
                      <p key={key}>
                        {label}:{' '}
                        {list.find((v) => v.id === e[key])?.label ?? 'N/D'}
                      </p>
                    ),
                  )}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
