import { equipmentSource } from '../../domain/equipmentSource';
import { useEffect, useMemo, useState } from 'react';
import { useEquipmentStore } from '../../stores/equipmentStore';
import {
  filterEquipment,
  ITEM_TYPES,
  equipmentWeight,
} from '../../domain/equipment';
import {
  BASE_TRADE_CONTEXT,
  TRADE_COLORS,
  marketRulesSchema,
  marketFactors,
  calculateMarketValues,
  formatMarketRange,
} from '../../domain/market';
import type { Item } from '../../domain/item';
import rawRules from '../../data/equipment/market-rules.v1.json';
import { EquipmentReferenceTables } from './EquipmentReferenceTables';
import { ItemIllustration } from './ItemIllustration';
import './equipment.css';
const rules = marketRulesSchema.parse(rawRules);
const PAGE_SIZE = 40;
export function EquipmentWorkspace() {
  const state = useEquipmentStore();
  const [page, setPage] = useState(0);
  const [section, setSection] = useState<'items' | 'upgrades' | 'loot'>(
    'items',
  );
  useEffect(() => {
    if (!useEquipmentStore.getState().loaded)
      void useEquipmentStore.getState().load();
  }, []);
  const filtered = useMemo(
    () => filterEquipment(state.items, state.query, state.type, state.category),
    [state.items, state.query, state.type, state.category],
  );
  const categories = useMemo(
    () =>
      [
        ...new Set(
          state.items
            .filter((i) => !state.type || i.type === state.type)
            .map((i) => i.category),
        ),
      ].sort((a, b) => a.localeCompare(b, 'pl')),
    [state.items, state.type],
  );
  const actualPage = Math.min(
    page,
    Math.max(0, Math.ceil(filtered.length / PAGE_SIZE) - 1),
  );
  const visible = filtered.slice(
    actualPage * PAGE_SIZE,
    (actualPage + 1) * PAGE_SIZE,
  );
  const selected =
    filtered.find((i) => i.id === state.selectedId) ?? visible[0];
  const filter = (patch: Parameters<typeof state.setFilters>[0]) => {
    state.setFilters(patch);
    setPage(0);
  };
  const context = state.context;
  function values(item: Item) {
    try {
      return {
        result: calculateMarketValues(item, context, rules),
        error: null,
      };
    } catch (error) {
      return { result: null, error: String(error) };
    }
  }
  const market = selected ? values(selected) : null;
  const factors =
    selected && market?.result ? marketFactors(selected, context, rules) : null;
  const sections = (
    <nav className="equipment-section-tabs" aria-label="Działy Ekwipunku">
      {(
        [
          ['items', 'Przedmioty'],
          ['upgrades', 'Ulepszenia broni'],
          ['loot', 'Fanty'],
        ] as const
      ).map(([id, label]) => (
        <button
          key={id}
          type="button"
          aria-current={section === id ? 'page' : undefined}
          onClick={() => setSection(id)}
        >
          {label}
        </button>
      ))}
    </nav>
  );
  if (section !== 'items')
    return (
      <div className="equipment-workspace">
        {sections}
        <EquipmentReferenceTables section={section} />
      </div>
    );
  return (
    <div className="equipment-workspace">
      {sections}
      <section className="trade-context" aria-labelledby="trade-title">
        <h3 id="trade-title">Warunki handlu</h3>
        <div className="enemy-fields">
          <label>
            <span>Region</span>
            <select
              value={
                context.region.kind === 'none' ? 'none' : context.region.id
              }
              onChange={(e) =>
                state.setContext({
                  ...context,
                  region:
                    e.target.value === 'none'
                      ? { kind: 'none' }
                      : { kind: 'region', id: e.target.value },
                })
              }
            >
              <option value="none">N/D — brak modyfikacji</option>
              {Object.entries(rules.regions).map(([id, r]) => (
                <option key={id} value={id}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Lokalizacja</span>
            <select
              value={
                context.location.kind === 'none' ? 'none' : context.location.id
              }
              onChange={(e) =>
                state.setContext({
                  ...context,
                  location:
                    e.target.value === 'none'
                      ? { kind: 'none' }
                      : { kind: 'location', id: e.target.value },
                })
              }
            >
              <option value="none">N/D — brak modyfikacji</option>
              {Object.entries(rules.locations).map(([id, r]) => (
                <option key={id} value={id}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Kolor</span>
            <select
              value={context.color}
              onChange={(e) =>
                state.setContext({
                  ...context,
                  color: e.target.value as typeof context.color,
                })
              }
            >
              {Object.entries(TRADE_COLORS).map(([id, r]) => (
                <option key={id} value={id}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>
        </div>
        <button
          className="secondary-button"
          onClick={() => state.setContext(structuredClone(BASE_TRADE_CONTEXT))}
        >
          Przywróć wartości bazowe
        </button>
        {context.color === 'steel' && (
          <p className="editor-hint">
            Stal: cena ×0,5 i dostępność ×2 tylko dla broni oraz amunicji.
          </p>
        )}
      </section>
      <div className="enemy-fields equipment-filters">
        <label>
          <span>Szukaj przedmiotu</span>
          <input
            type="search"
            value={state.query}
            placeholder="Nazwa, opis lub właściwość…"
            onChange={(e) => filter({ query: e.target.value })}
          />
        </label>
        <label>
          <span>Typ przedmiotu</span>
          <select
            value={state.type}
            onChange={(e) =>
              filter({
                type: e.target.value as typeof state.type,
                category: '',
              })
            }
          >
            <option value="">Wszystkie typy</option>
            {Object.entries(ITEM_TYPES).map(([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span>Kategoria przedmiotu</span>
          <select
            value={state.category}
            onChange={(e) => filter({ category: e.target.value })}
          >
            <option value="">Wszystkie kategorie</option>
            {categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
      </div>
      <p role="status">
        {state.loading
          ? 'Odczytywanie katalogu…'
          : `Wyniki: ${filtered.length} z ${state.items.length}`}
      </p>
      {state.error && (
        <div role="alert" className="error-panel">
          <p>{state.error}</p>
          <button
            className="secondary-button"
            onClick={() => {
              void state.load();
            }}
          >
            Ponów odczyt Ekwipunku
          </button>
        </div>
      )}
      {!state.loading && !state.error && filtered.length === 0 && (
        <p>Brak pasujących przedmiotów. Zmień wyszukiwanie lub filtry.</p>
      )}
      <div className="equipment-columns">
        <section aria-label="Lista przedmiotów">
          <div className="equipment-list">
            {visible.map((item) => {
              const v = values(item);
              return (
                <button
                  key={item.id}
                  className="equipment-row"
                  aria-pressed={item.id === selected?.id}
                  onClick={() => state.select(item.id)}
                >
                  <ItemIllustration item={item} size="small" />
                  <span className="equipment-row-copy">
                    <strong>{item.name}</strong>
                    <span>
                      {ITEM_TYPES[item.type]}
                      {item.type !== 'ammunition' && (
                        <> · {equipmentWeight(item)}</>
                      )}
                    </span>
                    <span>
                      {v.result
                        ? `${formatMarketRange(v.result.price, 'gb')} · ${formatMarketRange(v.result.availability, '%')}`
                        : 'Sprawdź warunki handlu'}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
          {filtered.length > PAGE_SIZE && (
            <nav
              className="actor-actions equipment-pages"
              aria-label="Strony Ekwipunku"
            >
              <button
                className="secondary-button"
                disabled={actualPage === 0}
                onClick={() => {
                  setPage(actualPage - 1);
                  state.select('');
                }}
              >
                Poprzednia strona
              </button>
              <span>
                {actualPage + 1} / {Math.ceil(filtered.length / PAGE_SIZE)}
              </span>
              <button
                className="secondary-button"
                disabled={(actualPage + 1) * PAGE_SIZE >= filtered.length}
                onClick={() => {
                  setPage(actualPage + 1);
                  state.select('');
                }}
              >
                Następna strona
              </button>
            </nav>
          )}
        </section>
        {selected && (
          <article
            className="equipment-detail"
            aria-label={`Przedmiot: ${selected.name}`}
          >
            <div className="equipment-detail-heading">
              <ItemIllustration item={selected} />
              <div>
                <p className="section-kicker">{ITEM_TYPES[selected.type]}</p>
                <h3>{selected.name}</h3>
                <p className="editor-hint">{selected.category}</p>
              </div>
            </div>
            {market?.error && (
              <p role="alert" className="editor-error">
                {market.error}
              </p>
            )}
            <table className="equipment-values">
              <caption>Cena i dostępność</caption>
              <thead>
                <tr>
                  <th scope="col">Wartość</th>
                  <th scope="col">Bazowa</th>
                  <th scope="col">Po modyfikacjach</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Cena</th>
                  <td>{formatMarketRange(selected.basePrice, 'gb')}</td>
                  <td>
                    {market?.result
                      ? formatMarketRange(market.result.price, 'gb')
                      : 'N/D'}
                  </td>
                </tr>
                <tr>
                  <th scope="row">Dostępność</th>
                  <td>{formatMarketRange(selected.baseAvailability, '%')}</td>
                  <td>
                    {market?.result
                      ? formatMarketRange(market.result.availability, '%')
                      : 'N/D'}
                  </td>
                </tr>
              </tbody>
            </table>
            {selected.type !== 'ammunition' && (
              <p>
                <strong>Waga:</strong> {equipmentWeight(selected)}
              </p>
            )}
            {factors && (
              <details>
                <summary>Przeliczenie i kategoria ekonomiczna</summary>
                <p>
                  Kategoria ekonomiczna: {selected.economicCategory || 'N/D'}
                </p>
                <p>
                  Cena: baza × {factors.region.toLocaleString('pl')} (region) ×{' '}
                  {factors.colorPrice.toLocaleString('pl')} (Kolor).
                </p>
                <p>
                  Dostępność: (baza {factors.location < 0 ? '−' : '+'}{' '}
                  {Math.abs(factors.location)} p.p.) ×{' '}
                  {factors.colorAvailability.toLocaleString('pl')} (Kolor), w
                  granicach 0–100%.
                </p>
              </details>
            )}
            {selected.properties.filter((p) => !p.startsWith('Waga: ')).length >
              0 && (
              <section>
                <h4>Parametry</h4>
                <ul>
                  {selected.properties
                    .filter((p) => !p.startsWith('Waga: '))
                    .map((p, index) => (
                      <li key={index}>{p}</li>
                    ))}
                </ul>
              </section>
            )}
            {selected.description && (
              <section>
                <h4>Właściwości i opis</h4>
                <p className="bestiary-text">{selected.description}</p>
              </section>
            )}
            {selected.source && (
              <details>
                <summary>Źródło</summary>
                <p>{equipmentSource(selected)}</p>
              </details>
            )}
          </article>
        )}
      </div>
    </div>
  );
}
