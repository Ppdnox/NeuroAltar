import {
  newWeaponDraft,
  newVariantDraft,
  type LoadoutDraft,
  type EquippedDraft,
  type ProfileDraft,
  type RangeDraft,
  type VariantDraft,
} from '../../domain/itemDraft';
function RangeFields({
  path,
  value,
  onChange,
}: {
  path: string;
  value: RangeDraft;
  onChange(v: RangeDraft): void;
}) {
  return (
    <div className="enemy-fields" data-validation-path={path}>
      {(['normal', 'long'] as const).map((key) => (
        <label key={key}>
          <span>
            {key === 'normal'
              ? 'Zwykły zasięg / dosięg (m)'
              : 'Długi zasięg (m)'}
          </span>
          <input
            inputMode="decimal"
            data-validation-path={`${path}.${key}`}
            value={value[key]}
            onChange={(e) => onChange({ ...value, [key]: e.target.value })}
          />
        </label>
      ))}
    </div>
  );
}
export function LoadoutFields({
  value,
  onChange,
}: {
  value: LoadoutDraft;
  onChange(value: LoadoutDraft): void;
}) {
  const edit = (id: string, patch: Partial<EquippedDraft>) =>
    onChange({
      ...value,
      items: value.items.map((e) =>
        e.original.id === id ? { ...e, ...patch } : e,
      ),
    });
  return (
    <div className="loadout-fields">
      <p className="editor-hint">
        PB jest doliczane do każdego ataku. Wpisz modyfikatory cech, nie
        wartości cech. Puste PB lub cecha oznaczają brak danych, nie zero.
      </p>
      <div className="enemy-fields">
        {(
          [
            ['pb', 'Premia z biegłości (PB)'],
            ['strModifier', 'Modyfikator SIŁ'],
            ['dexModifier', 'Modyfikator ZRC'],
          ] as const
        ).map(([key, label]) => (
          <label key={key}>
            <span>{label}</span>
            <input
              aria-label={label}
              inputMode="numeric"
              data-validation-path={`loadout.${key}`}
              value={value[key]}
              onChange={(e) => onChange({ ...value, [key]: e.target.value })}
            />
          </label>
        ))}
      </div>
      <p className="editor-hint">
        Formułę obrażeń wpisz w całości, np. 1k8 + 3. Aplikacja nie dodaje do
        niej cechy i nie wykonuje rzutu. Puste zasięgi i średnia oznaczają brak
        danych.
      </p>
      {value.items.map((e, index) => {
        const path = `loadout.items.${index}`;
        const id = e.original.id,
          p = e.profile;
        const profile = (patch: Partial<ProfileDraft>) =>
          edit(id, { profile: { ...p!, ...patch } });
        const variants = (key: 'fireModes' | 'ammoVariants') => (
          <details>
            <summary>
              {key === 'fireModes' ? 'Tryby ognia' : 'Warianty amunicji'} (
              {p![key].length})
            </summary>
            <p className="editor-hint">
              Wpisz znane modyfikatory i efekty. Wybrany wariant amunicji ma
              pierwszeństwo nad trybem ognia dla zasięgu i formuły; premie do
              ataku sumują się.
            </p>
            {p![key].map((v, vi) => {
              const variant = (patch: Partial<VariantDraft>) =>
                profile({
                  [key]: p![key].map((row) =>
                    row.id === v.id ? { ...row, ...patch } : row,
                  ),
                });
              return (
                <fieldset
                  key={v.id}
                  data-validation-path={`${path}.item.weaponProfile.${key}.${vi}`}
                >
                  <legend>{v.label || 'Nowy wariant'}</legend>
                  <div className="enemy-fields">
                    <label>
                      <span>Nazwa wariantu</span>
                      <input
                        data-validation-path={`${path}.item.weaponProfile.${key}.${vi}.label`}
                        value={v.label}
                        onChange={(ev) => variant({ label: ev.target.value })}
                      />
                    </label>
                    <label>
                      <span>Modyfikator ataku wariantu</span>
                      <input
                        inputMode="numeric"
                        data-validation-path={`${path}.item.weaponProfile.${key}.${vi}.attackModifier`}
                        value={v.attackModifier}
                        onChange={(ev) =>
                          variant({ attackModifier: ev.target.value })
                        }
                      />
                    </label>
                    <label>
                      <span>Formuła wariantu</span>
                      <select
                        data-validation-path={`${path}.item.weaponProfile.${key}.${vi}.damageModeId`}
                        value={v.damageModeId ?? ''}
                        onChange={(ev) =>
                          variant({ damageModeId: ev.target.value || null })
                        }
                      >
                        <option value="">Bez zmiany formuły</option>
                        {p!.damageModes.map((d) => (
                          <option value={d.id} key={d.id}>
                            {d.label || 'Bez nazwy'}
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                  <label>
                    <span>Efekt / przypomnienie</span>
                    <textarea
                      data-validation-path={`${path}.item.weaponProfile.${key}.${vi}.effect`}
                      value={v.effect}
                      onChange={(ev) => variant({ effect: ev.target.value })}
                    />
                  </label>
                  <label className="injury-toggle">
                    <input
                      type="checkbox"
                      checked={v.overrideRange}
                      onChange={(ev) =>
                        variant({ overrideRange: ev.target.checked })
                      }
                    />
                    Osobny zasięg wariantu
                  </label>
                  {v.overrideRange && (
                    <RangeFields
                      path={`${path}.item.weaponProfile.${key}.${vi}.range`}
                      value={v.range}
                      onChange={(range) => variant({ range })}
                    />
                  )}
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => {
                      profile({
                        [key]: p![key].filter((row) => row.id !== v.id),
                      });
                      const selection =
                        key === 'fireModes' ? 'fireModeId' : 'ammoVariantId';
                      if (e[selection] === v.id)
                        onChange({
                          ...value,
                          items: value.items.map((row) =>
                            row.original.id === id
                              ? {
                                  ...row,
                                  [selection]: null,
                                  profile: {
                                    ...p!,
                                    [key]: p![key].filter((r) => r.id !== v.id),
                                  },
                                }
                              : row,
                          ),
                        });
                    }}
                  >
                    Usuń wariant z formularza
                  </button>
                </fieldset>
              );
            })}
            <button
              type="button"
              className="secondary-button"
              onClick={() =>
                profile({ [key]: [...p![key], newVariantDraft()] })
              }
            >
              Dodaj {key === 'fireModes' ? 'tryb ognia' : 'wariant amunicji'}
            </button>
          </details>
        );
        return (
          <fieldset
            className="weapon-editor"
            key={id}
            data-validation-path={path}
          >
            <legend>
              Przedmiot {index + 1}: {e.name || 'Nowa broń'}
            </legend>
            <div className="enemy-fields">
              <label>
                <span>Nazwa broni</span>
                <input
                  aria-label={`Nazwa broni ${index + 1}`}
                  data-validation-path={`${path}.item.name`}
                  value={e.name}
                  onChange={(ev) => edit(id, { name: ev.target.value })}
                />
              </label>
              <label>
                <span>Kategoria broni</span>
                <input
                  data-validation-path={`${path}.item.category`}
                  value={e.category}
                  onChange={(ev) => edit(id, { category: ev.target.value })}
                />
              </label>
            </div>
            <label>
              <span>Opis / krótki efekt</span>
              <textarea
                data-validation-path={`${path}.item.description`}
                value={e.description}
                onChange={(ev) => edit(id, { description: ev.target.value })}
              />
            </label>
            {p ? (
              <>
                <div className="enemy-fields">
                  <label>
                    <span>Rodzaj ataku</span>
                    <select
                      data-validation-path={`${path}.item.weaponProfile.attackKind`}
                      value={p.attackKind}
                      onChange={(ev) =>
                        profile({
                          attackKind: ev.target
                            .value as ProfileDraft['attackKind'],
                        })
                      }
                    >
                      <option value="melee">Wręcz</option>
                      <option value="ranged">Dystansowy</option>
                    </select>
                  </label>
                  <label>
                    <span>Cecha do ataku</span>
                    <select
                      data-validation-path={`${path}.item.weaponProfile.abilityRule`}
                      value={p.abilityRule}
                      onChange={(ev) =>
                        profile({
                          abilityRule: ev.target
                            .value as ProfileDraft['abilityRule'],
                        })
                      }
                    >
                      <option value="str">SIŁ</option>
                      <option value="dex">ZRC</option>
                      <option value="finesse">
                        Finezyjna — wyższy modyfikator SIŁ/ZRC
                      </option>
                    </select>
                  </label>
                  <label>
                    <span>Modyfikator ataku broni</span>
                    <input
                      inputMode="numeric"
                      data-validation-path={`${path}.item.weaponProfile.attackModifier`}
                      value={p.attackModifier}
                      onChange={(ev) =>
                        profile({ attackModifier: ev.target.value })
                      }
                    />
                  </label>
                </div>
                <RangeFields
                  path={`${path}.item.weaponProfile.range`}
                  value={p.range}
                  onChange={(range) => profile({ range })}
                />
                {p.damageModes.map((d, di) => (
                  <fieldset
                    key={d.id}
                    data-validation-path={`${path}.item.weaponProfile.damageModes.${di}`}
                  >
                    <legend>Formuła: {d.label || 'Nowa'}</legend>
                    <div className="enemy-fields">
                      <label>
                        <span>Nazwa formuły</span>
                        <input
                          data-validation-path={`${path}.item.weaponProfile.damageModes.${di}.label`}
                          value={d.label}
                          onChange={(ev) =>
                            profile({
                              damageModes: p.damageModes.map((m) =>
                                m.id === d.id
                                  ? { ...m, label: ev.target.value }
                                  : m,
                              ),
                            })
                          }
                        />
                      </label>
                      <label>
                        <span>Formuła kości — pełne obrażenia</span>
                        <input
                          aria-label={`Formuła obrażeń ${index + 1} ${d.label}`}
                          data-validation-path={`${path}.item.weaponProfile.damageModes.${di}.dice`}
                          value={d.dice}
                          onChange={(ev) =>
                            profile({
                              damageModes: p.damageModes.map((m) =>
                                m.id === d.id
                                  ? { ...m, dice: ev.target.value }
                                  : m,
                              ),
                            })
                          }
                        />
                      </label>
                      <label>
                        <span>Typ obrażeń</span>
                        <input
                          data-validation-path={`${path}.item.weaponProfile.damageModes.${di}.damageType`}
                          value={d.damageType}
                          onChange={(ev) =>
                            profile({
                              damageModes: p.damageModes.map((m) =>
                                m.id === d.id
                                  ? { ...m, damageType: ev.target.value }
                                  : m,
                              ),
                            })
                          }
                        />
                      </label>
                      <label>
                        <span>Średnia obrażeń (opcjonalnie)</span>
                        <input
                          inputMode="decimal"
                          data-validation-path={`${path}.item.weaponProfile.damageModes.${di}.average`}
                          value={d.average}
                          onChange={(ev) =>
                            profile({
                              damageModes: p.damageModes.map((m) =>
                                m.id === d.id
                                  ? { ...m, average: ev.target.value }
                                  : m,
                              ),
                            })
                          }
                        />
                      </label>
                    </div>
                    <label>
                      <span>Warunek / przypomnienie formuły</span>
                      <textarea
                        data-validation-path={`${path}.item.weaponProfile.damageModes.${di}.condition`}
                        value={d.condition ?? ''}
                        onChange={(ev) =>
                          profile({
                            damageModes: p.damageModes.map((m) =>
                              m.id === d.id
                                ? { ...m, condition: ev.target.value || null }
                                : m,
                            ),
                          })
                        }
                      />
                    </label>
                    <button
                      className="secondary-button"
                      type="button"
                      disabled={
                        p.damageModes.length === 1 ||
                        e.damageModeId === d.id ||
                        [...p.fireModes, ...p.ammoVariants].some(
                          (v) => v.damageModeId === d.id,
                        )
                      }
                      onClick={() =>
                        profile({
                          damageModes: p.damageModes.filter(
                            (m) => m.id !== d.id,
                          ),
                        })
                      }
                    >
                      Usuń nieużywaną formułę
                    </button>
                  </fieldset>
                ))}
                <button
                  className="secondary-button"
                  type="button"
                  onClick={() =>
                    profile({
                      damageModes: [
                        ...p.damageModes,
                        {
                          id: crypto.randomUUID(),
                          label: '',
                          dice: '',
                          average: '',
                          damageType: '',
                          condition: null,
                        },
                      ],
                    })
                  }
                >
                  Dodaj formułę obrażeń
                </button>
                <label>
                  <span>Właściwości profilu — po jednej w wierszu</span>
                  <textarea
                    value={p.propertiesText}
                    onChange={(ev) =>
                      profile({ propertiesText: ev.target.value })
                    }
                  />
                </label>
                {variants('fireModes')}
                {variants('ammoVariants')}
                <div className="enemy-fields">
                  {(
                    [
                      ['damageModeId', 'Formuła początkowa', p.damageModes],
                      ['fireModeId', 'Tryb ognia początkowy', p.fireModes],
                      [
                        'ammoVariantId',
                        'Wariant amunicji początkowy',
                        p.ammoVariants,
                      ],
                    ] as const
                  ).map(([key, label, list]) => (
                    <label key={key}>
                      <span>{label}</span>
                      <select
                        data-validation-path={`${path}.${key}`}
                        value={e[key] ?? ''}
                        onChange={(ev) =>
                          edit(id, { [key]: ev.target.value || null })
                        }
                      >
                        {key !== 'damageModeId' && (
                          <option value="">N/D — bez zmian</option>
                        )}
                        {list.map((v) => (
                          <option key={v.id} value={v.id}>
                            {v.label || 'Bez nazwy'}
                          </option>
                        ))}
                      </select>
                    </label>
                  ))}
                </div>
              </>
            ) : (
              <p>Ten przedmiot nie ma profilu broni.</p>
            )}
            <label>
              <span>Właściwości przedmiotu — po jednej w wierszu</span>
              <textarea
                value={e.propertiesText}
                onChange={(ev) => edit(id, { propertiesText: ev.target.value })}
              />
            </label>
            <div className="actor-actions">
              <button
                className="secondary-button"
                type="button"
                onClick={() =>
                  onChange({
                    ...value,
                    items: value.items.map((row) =>
                      row.original.id === id ? newWeaponDraft() : row,
                    ),
                  })
                }
              >
                Zastąp nową bronią
              </button>
              <button
                className="secondary-button"
                type="button"
                onClick={() =>
                  onChange({
                    ...value,
                    items: value.items.filter((row) => row.original.id !== id),
                  })
                }
              >
                Usuń przedmiot z formularza
              </button>
            </div>
          </fieldset>
        );
      })}
      <button
        className="secondary-button"
        type="button"
        onClick={() =>
          onChange({ ...value, items: [...value.items, newWeaponDraft()] })
        }
      >
        Dodaj broń do zestawu
      </button>
    </div>
  );
}
