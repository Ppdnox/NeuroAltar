import { StatusForm } from './StatusForm';
import { useEncounterStore } from '../../stores/encounterStore';
import { useState } from 'react';
import { Dice4 } from 'lucide-react';
import type { ActorDraft } from '../../domain/combat';
import type { SlotId } from '../../domain/encounterDetails';
import {
  exhaustionEffects,
  statusDuration,
  systemStatuses,
  type SystemKey,
} from '../../domain/status';
import { useCombatStore } from '../../stores/combatStore';
export function StatusPanel({
  slotId,
  actor,
  parentDisabled = false,
  persistentHealth = false,
}: {
  slotId: SlotId;
  actor: ActorDraft;
  parentDisabled?: boolean;
  persistentHealth?: boolean;
}) {
  const state = useCombatStore();
  const closing = useEncounterStore((s) => s.closing);
  const disabled =
    parentDisabled ||
    closing ||
    state.closing ||
    Boolean(
      state.enemyForm ||
      state.statusForm ||
      state.failureForm ||
      state.statblockForm ||
      state.loadoutForm ||
      state.capabilityForm,
    );
  const [remove, setRemove] = useState<string | null>(null);
  const effects = actor.effects ?? [];
  const exhaustion = exhaustionEffects(effects);
  return (
    <section className="status-panel" aria-label="Statusy postaci">
      <fieldset disabled={disabled}>
        <div className="actor-list-heading">
          <h3>Statusy</h3>
        </div>
        <label className="status-picker">
          <span>Dodaj status z listy</span>
          <select
            aria-label="Dodaj status z listy"
            value=""
            onChange={(event) => {
              const key = event.target.value;
              if (!key) return;
              state.openStatusForm(slotId, actor.id);
              state.editStatusForm({
                systemKey: key === 'custom' ? null : (key as SystemKey),
              });
            }}
          >
            <option value="" disabled>
              Wybierz status…
            </option>
            {Object.entries(systemStatuses).map(([key, [label]]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
            <option value="custom">Własny status…</option>
          </select>
        </label>
      </fieldset>
      {state.statusForm?.slotId === slotId &&
        state.statusForm.actorId === actor.id && (
          <StatusForm slotId={slotId} disabled={closing || state.closing} />
        )}
      <fieldset disabled={disabled}>
        {!persistentHealth && (
          <div className="exhaustion-control">
            <strong>Wyczerpanie: {exhaustion.level}/6</strong>
            <button
              type="button"
              aria-label="Zmniejsz Wyczerpanie"
              disabled={!exhaustion.level}
              onClick={() => state.adjustExhaustion(slotId, actor.id, -1)}
            >
              −1
            </button>
            <button
              type="button"
              aria-label="Zwiększ Wyczerpanie"
              disabled={exhaustion.level === 6}
              onClick={() => state.adjustExhaustion(slotId, actor.id, 1)}
            >
              +1
            </button>
          </div>
        )}
        {!persistentHealth && exhaustion.level > 0 && (
          <p
            className={exhaustion.deathWarning ? 'hp-warning' : 'editor-hint'}
            role={exhaustion.deathWarning ? 'alert' : undefined}
          >
            Testy k20: −{exhaustion.testPenalty}. Szybkość: −
            {exhaustion.speedPenalty.toLocaleString('pl-PL')} m (minimum 0).
            {exhaustion.deathWarning &&
              ' Poziom 6 — śmierć. MG rozstrzyga dalszy stan postaci.'}
          </p>
        )}
        {!effects.length && (
          <p className="editor-hint">
            Brak aktywnych statusów systemowych i czasowych.
          </p>
        )}
        <ul className="status-list">
          {effects.map((s) => (
            <li key={s.id}>
              <div className="status-heading">
                <strong>
                  {s.systemKey === 'burning' && (
                    <Dice4 size={16} aria-label="Formuła kości, bez rzutu" />
                  )}
                  {s.name}
                  {s.level !== null ? ` ${s.level}` : ''}
                </strong>
                <span>{statusDuration(s)}</span>
              </div>
              <details className="status-rule-details">
                <summary>Opis i źródło</summary>
                {s.systemKey && <p>{systemStatuses[s.systemKey][1]}</p>}
                {s.description && (
                  <p className="status-description">{s.description}</p>
                )}
                {s.sourceText && <small>Źródło: {s.sourceText}</small>}
              </details>
              <div className="actor-actions">
                <button
                  type="button"
                  className="secondary-button"
                  disabled={Boolean(state.enemyForm)}
                  onClick={() => state.openStatusForm(slotId, actor.id, s.id)}
                >
                  Edytuj {s.name}
                </button>
                <button
                  type="button"
                  className="remove-actor"
                  onClick={() => setRemove(s.id)}
                >
                  Usuń {s.name}
                </button>
              </div>
              {remove === s.id && (
                <div className="remove-confirm" role="alert">
                  <p>Usunąć status „{s.name}”?</p>
                  <button
                    type="button"
                    onClick={() => {
                      state.removeStatus(slotId, actor.id, s.id);
                      setRemove(null);
                    }}
                  >
                    Potwierdź usunięcie statusu
                  </button>
                  <button type="button" onClick={() => setRemove(null)}>
                    Anuluj
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
        <details className="source-notes">
          <summary>Zasady statusów</summary>
          <p className="editor-hint">
            Statusy przypominają o regułach. Nie zmieniają wpisanych PW, TT ani
            ruchu. Powtórzone stany mają osobny czas, ale nie wzmacniają efektu;
            Wyczerpanie ma wspólny licznik.
          </p>
        </details>
      </fieldset>
    </section>
  );
}
