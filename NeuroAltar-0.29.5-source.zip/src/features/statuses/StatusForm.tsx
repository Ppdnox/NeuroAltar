import { useNavigationStore } from '../../stores/navigationStore';
import { useEffect, useRef } from 'react';
import type { SlotId } from '../../domain/encounterDetails';
import {
  durationLabels,
  systemStatuses,
  type DurationType,
  type SystemKey,
} from '../../domain/status';
import { useCombatStore } from '../../stores/combatStore';
export function StatusForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore();
  const form = state.statusForm;
  const firstField = useRef<HTMLSelectElement>(null);
  const closeIssue = useNavigationStore((s) => s.closeIssue);
  const formId = form?.slotId === slotId ? form.statusId : null;
  useEffect(() => {
    if (formId && !disabled) {
      firstField.current?.focus({ preventScroll: true });
      firstField.current?.scrollIntoView({ block: 'center' });
    }
  }, [formId, disabled, closeIssue]);
  if (!form || form.slotId !== slotId) return null;
  const actor = state.drafts[slotId]?.value.actors.find(
    (a) => a.id === form.actorId,
  );
  const edit = state.editStatusForm,
    d = form.fields;
  const editing = actor?.effects?.some((s) => s.id === form.statusId);
  return (
    <form
      className="status-form"
      aria-label="Formularz statusu"
      onSubmit={(e) => {
        e.preventDefault();
        state.submitStatusForm();
      }}
    >
      <fieldset disabled={disabled}>
        <legend>
          {editing ? 'Edytuj' : 'Dodaj'} status — {actor?.displayName}
        </legend>
        <label>
          Rodzaj statusu
          <select
            ref={firstField}
            aria-label="Rodzaj statusu"
            value={d.systemKey ?? 'custom'}
            onChange={(e) =>
              edit({
                systemKey:
                  e.target.value === 'custom'
                    ? null
                    : (e.target.value as SystemKey),
              })
            }
          >
            <option value="custom">Własny status</option>
            {Object.entries(systemStatuses).map(([key, [label]]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </label>
        {d.systemKey === null && (
          <label>
            Nazwa statusu
            <input
              aria-label="Nazwa statusu"
              value={d.name}
              onChange={(e) => edit({ name: e.target.value })}
            />
          </label>
        )}
        {d.systemKey && (
          <p className="editor-hint">{systemStatuses[d.systemKey][1]}</p>
        )}
        <label>
          Opis / przypomnienie
          <textarea
            aria-label="Opis statusu"
            value={d.description}
            onChange={(e) => edit({ description: e.target.value })}
          />
        </label>
        <label>
          Źródło
          <input
            aria-label="Źródło statusu"
            value={d.sourceText}
            onChange={(e) => edit({ sourceText: e.target.value })}
          />
        </label>
        {d.systemKey === 'exhaustion' ? (
          <label>
            Poziom Wyczerpania
            <input
              aria-label="Poziom Wyczerpania"
              inputMode="numeric"
              value={d.level}
              onChange={(e) => edit({ level: e.target.value })}
            />
          </label>
        ) : (
          <>
            <label>
              Czas statusu
              <select
                aria-label="Czas statusu"
                value={d.durationType}
                onChange={(e) =>
                  edit({ durationType: e.target.value as DurationType })
                }
              >
                {Object.entries(durationLabels).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            {d.durationType === 'rounds' && (
              <label>
                Liczba rund
                <input
                  aria-label="Liczba rund"
                  inputMode="numeric"
                  value={d.rounds}
                  onChange={(e) => edit({ rounds: e.target.value })}
                />
              </label>
            )}
          </>
        )}
        <p className="editor-hint">
          Czas dotyczy tur tej postaci. Rundy maleją przy zmianie numeru rundy.
          „Następna tura” pomija koniec bieżącej tury, jeśli postać jest teraz
          aktywna. Ręczna korekta tury nie odlicza czasu. Zapis edycji ustawia
          czas od nowa.
        </p>
        {form.error && (
          <p className="editor-error" role="alert">
            {form.error}
          </p>
        )}
        <div className="actor-actions">
          <button type="submit" className="secondary-button">
            {editing ? 'Zapisz status' : 'Dodaj ten status'}
          </button>
          <button
            type="button"
            className="secondary-button"
            onClick={() => state.cancelStatusForm()}
          >
            Anuluj formularz statusu
          </button>
        </div>
      </fieldset>
    </form>
  );
}
