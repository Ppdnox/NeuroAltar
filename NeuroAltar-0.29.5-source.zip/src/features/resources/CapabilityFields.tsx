import {
  actionLabels,
  refreshLabels,
  type CapabilityDraft,
  type ActionKind,
} from '../../domain/capabilitySchema';
export function CapabilityFields({
  value: d,
  onChange,
  template = false,
}: {
  value: CapabilityDraft;
  onChange: (d: CapabilityDraft) => void;
  template?: boolean;
}) {
  const resource = (
    id: string,
    patch: Partial<CapabilityDraft['resources'][number]>,
  ) =>
    onChange({
      ...d,
      resources: d.resources.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    });
  const ability = (
    id: string,
    patch: Partial<CapabilityDraft['abilities'][number]>,
  ) =>
    onChange({
      ...d,
      abilities: d.abilities.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    });
  return (
    <div className="capability-fields">
      <label>
        <input
          type="checkbox"
          checked={d.unlimitedReactions ?? false}
          onChange={(e) =>
            onChange({ ...d, unlimitedReactions: e.target.checked })
          }
        />
        <span>Reakcje bez limitu</span>
      </label>
      <p className="editor-hint">
        Znosi limit liczby Reakcji. Blokady stanów, Zranień i koszty zasobów
        nadal obowiązują.
      </p>
      <label>
        <span>Pula Akcji Legendarnych na rundę (0 = brak)</span>
        <input
          aria-label="Maksimum Akcji Legendarnych"
          inputMode="numeric"
          data-validation-path="capabilities.legendaryMax"
          value={d.legendaryMax}
          onChange={(e) => onChange({ ...d, legendaryMax: e.target.value })}
        />
      </label>
      <h4>Zasoby</h4>
      {d.resources.map((r, i) => (
        <div className="capability-row" key={r.id}>
          <label>
            <span>Nazwa zasobu</span>
            <input
              aria-label={`Nazwa zasobu ${i + 1}`}
              data-validation-path={`capabilities.resources.${i}.name`}
              value={r.name}
              onChange={(e) => resource(r.id, { name: e.target.value })}
            />
          </label>
          <label>
            <span>Maksimum</span>
            <input
              aria-label={`Maksimum zasobu ${i + 1}`}
              inputMode="numeric"
              data-validation-path={`capabilities.resources.${i}.maxValue`}
              value={r.maxValue}
              onChange={(e) =>
                resource(r.id, {
                  maxValue: e.target.value,
                  ...(template ? { currentValue: e.target.value } : {}),
                })
              }
            />
          </label>
          {!template && (
            <label>
              <span>Pozostało</span>
              <input
                aria-label={`Pozostało zasobu ${i + 1}`}
                inputMode="numeric"
                data-validation-path={`capabilities.resources.${i}.currentValue`}
                value={r.currentValue}
                onChange={(e) =>
                  resource(r.id, { currentValue: e.target.value })
                }
              />
            </label>
          )}
          <label>
            <span>Odnowienie</span>
            <select
              aria-label={`Odnowienie zasobu ${i + 1}`}
              data-validation-path={`capabilities.resources.${i}.refreshRule`}
              value={r.refreshRule}
              onChange={(e) =>
                resource(r.id, {
                  refreshRule: e.target.value as keyof typeof refreshLabels,
                })
              }
            >
              {Object.entries(refreshLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            className="remove-actor"
            disabled={d.abilities.some((a) => a.resourceId === r.id)}
            onClick={() =>
              onChange({
                ...d,
                resources: d.resources.filter((v) => v.id !== r.id),
              })
            }
          >
            Usuń wiersz zasobu {i + 1}
          </button>
        </div>
      ))}
      <button
        type="button"
        className="secondary-button"
        onClick={() =>
          onChange({
            ...d,
            resources: [
              ...d.resources,
              {
                id: crypto.randomUUID(),
                name: '',
                maxValue: '1',
                currentValue: '1',
                refreshRule: 'manual',
              },
            ],
          })
        }
      >
        Dodaj zasób
      </button>
      <h4>Akcje i zdolności</h4>
      {d.abilities.map((a, i) => (
        <div className="capability-row" key={a.id}>
          <label>
            <span>Nazwa akcji</span>
            <input
              aria-label={`Nazwa akcji ${i + 1}`}
              data-validation-path={`capabilities.abilities.${i}.name`}
              value={a.name}
              onChange={(e) => ability(a.id, { name: e.target.value })}
            />
          </label>
          <label>
            <span>Rodzaj</span>
            <select
              aria-label={`Rodzaj akcji ${i + 1}`}
              data-validation-path={`capabilities.abilities.${i}.kind`}
              value={a.kind}
              onChange={(e) =>
                ability(a.id, { kind: e.target.value as ActionKind })
              }
            >
              {Object.entries(actionLabels).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Opis — MG rozstrzyga efekt</span>
            <textarea
              aria-label={`Opis akcji ${i + 1}`}
              data-validation-path={`capabilities.abilities.${i}.description`}
              value={a.description}
              onChange={(e) => ability(a.id, { description: e.target.value })}
            />
          </label>
          {a.kind === 'legendary' && (
            <label>
              <span>Koszt z puli legendarnej</span>
              <input
                aria-label={`Koszt legendarny ${i + 1}`}
                inputMode="numeric"
                data-validation-path={`capabilities.abilities.${i}.legendaryCost`}
                value={a.legendaryCost}
                onChange={(e) =>
                  ability(a.id, { legendaryCost: e.target.value })
                }
              />
            </label>
          )}
          <label>
            <span>Powiązany zasób</span>
            <select
              aria-label={`Zasób akcji ${i + 1}`}
              data-validation-path={`capabilities.abilities.${i}.resourceId`}
              value={a.resourceId}
              onChange={(e) => ability(a.id, { resourceId: e.target.value })}
            >
              <option value="">Brak kosztu zasobu</option>
              {d.resources.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name || 'Zasób bez nazwy'}
                </option>
              ))}
            </select>
          </label>
          {a.resourceId && (
            <label>
              <span>Koszt zasobu</span>
              <input
                aria-label={`Koszt zasobu akcji ${i + 1}`}
                inputMode="numeric"
                data-validation-path={`capabilities.abilities.${i}.resourceCost`}
                value={a.resourceCost}
                onChange={(e) =>
                  ability(a.id, { resourceCost: e.target.value })
                }
              />
            </label>
          )}
          <button
            type="button"
            className="remove-actor"
            onClick={() =>
              onChange({
                ...d,
                abilities: d.abilities.filter((v) => v.id !== a.id),
              })
            }
          >
            Usuń wiersz akcji {i + 1}
          </button>
        </div>
      ))}
      <button
        type="button"
        className="secondary-button"
        onClick={() =>
          onChange({
            ...d,
            abilities: [
              ...d.abilities,
              {
                id: crypto.randomUUID(),
                name: '',
                description: '',
                kind: 'action',
                legendaryCost: '1',
                resourceId: '',
                resourceCost: '1',
              },
            ],
          })
        }
      >
        Dodaj akcję
      </button>
    </div>
  );
}
