import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';
import { CapabilityFields } from './CapabilityFields';
export function CapabilityForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore();
  const form = state.capabilityForm;
  if (!form || form.slotId !== slotId) return null;
  return (
    <form
      className="enemy-form"
      aria-label="Edycja zasobów i akcji"
      onSubmit={(e) => {
        e.preventDefault();
        state.submitCapabilityForm();
      }}
    >
      <fieldset disabled={disabled}>
        <legend>Zasoby i akcje instancji</legend>
        <p className="editor-hint">
          Zmiany dotyczą tej kopii. Zapisz stan przygotowany potyczki, jeśli
          mają być punktem powrotu. Zapis formularza zatwierdza także usunięte
          wiersze; Anuluj przywraca ich poprzedni stan.
        </p>
        <CapabilityFields
          value={form.fields}
          onChange={state.editCapabilityForm}
        />
        {form.error && (
          <p className="editor-error" role="alert">
            {form.error}
          </p>
        )}
        <div className="actor-actions">
          <button className="secondary-button" type="submit">
            Zapisz zasoby i akcje
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={state.cancelCapabilityForm}
          >
            Anuluj edycję zasobów
          </button>
        </div>
      </fieldset>
    </form>
  );
}
