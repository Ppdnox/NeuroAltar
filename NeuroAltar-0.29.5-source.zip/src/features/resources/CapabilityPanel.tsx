import { actorRollHandler } from '../../services/actorDice';
import { RuleText } from '../statblocks/RuleText';
import { LoadoutPanel } from '../equipment/LoadoutPanel';
import { useState } from 'react';
import { parseActorDraft, type ActorDraft } from '../../domain/combat';
import { capabilities, actionRestriction } from '../../domain/capabilities';
import {
  actionLabels,
  refreshLabels,
  type ActionKind,
} from '../../domain/capabilitySchema';
import type { SlotId } from '../../domain/encounterDetails';
import { useCombatStore } from '../../stores/combatStore';
export function CapabilityPanel({
  slotId,
  actor,
}: {
  slotId: SlotId;
  actor: ActorDraft;
}) {
  const state = useCombatStore();
  const [exception, setException] = useState<string | null>(null);
  let parsed;
  try {
    parsed = parseActorDraft(actor);
  } catch {
    return null;
  }
  if (!parsed.enemy) return null;
  const c = capabilities(parsed);
  const control = (
    key: string,
    name: string,
    kind: ActionKind,
    cost = 1,
    resourceId: string | null = null,
    resourceCost = 1,
  ) => {
    const restriction = actionRestriction(parsed, kind);
    const spent =
      !(kind === 'reaction' && c.unlimitedReactions) && c.budget[kind] < cost;
    const resource = resourceId
      ? c.resources.find((r) => r.id === resourceId)
      : null;
    const missing = Boolean(
      resourceId && (!resource || resource.currentValue < resourceCost),
    );
    const noPool = kind === 'legendary' && c.legendaryMax === 0;
    return (
      <div className="ability-controls">
        <button
          className="secondary-button"
          type="button"
          disabled={Boolean(restriction) || spent || missing || noPool}
          onClick={() => state.useCapability(slotId, actor.id, key)}
        >
          Użyj: {name}
        </button>
        {restriction && <p className="hp-warning">{restriction}</p>}
        {missing && (
          <p className="hp-warning">Za mało zasobu: {resource?.name}.</p>
        )}
        {(restriction || spent) && !missing && !noPool && (
          <button
            className="secondary-button"
            type="button"
            onClick={() => setException(key)}
          >
            Wyjątek MG: {name}
          </button>
        )}
        {exception === key && (
          <div className="remove-confirm">
            <p>
              Zarejestrować {name} mimo ograniczenia lub zużytej puli? Koszt
              zasobu nadal obowiązuje. Efekt rozstrzyga MG.
            </p>
            <button
              type="button"
              onClick={() => {
                state.useCapability(slotId, actor.id, key, true);
                setException(null);
              }}
            >
              Zarejestruj wyjątek MG
            </button>
            <button type="button" onClick={() => setException(null)}>
              Anuluj wyjątek
            </button>
          </div>
        )}
      </div>
    );
  };
  return (
    <section
      className="capability-panel"
      aria-label="Zasoby i akcje przeciwnika"
    >
      <div className="actor-list-heading">
        <h3>Zasoby i akcje</h3>
        <button
          className="secondary-button"
          type="button"
          disabled={Boolean(state.enemyForm || state.capabilityForm)}
          onClick={() => state.openCapabilityForm(slotId, actor.id)}
        >
          Edytuj zasoby i akcje
        </button>
      </div>
      <details className="source-notes">
        <summary>Zasady używania i odnowienia</summary>
        <p className="editor-hint">
          Akcja, Bonusowa i Reakcja odnawiają się na początku własnej tury.
          Legendarne — przy zmianie rundy. Użycie rejestruje koszt; MG
          rozstrzyga moment, cel i efekt. Legendarne stosuj po turze innej
          postaci.
        </p>
      </details>
      <div className="combat-resources" aria-label="Liczniki zasobów">
        {c.resources.map((r) => (
          <div className="capability-budget" key={r.id}>
            <strong>
              {r.name}: {r.currentValue}/{r.maxValue}
            </strong>
            <span>{refreshLabels[r.refreshRule]}</span>
            <button
              type="button"
              aria-label={`Zużyj zasób: ${r.name}`}
              disabled={r.currentValue === 0}
              onClick={() => state.adjustResource(slotId, actor.id, r.id, -1)}
            >
              −1
            </button>
            <button
              type="button"
              aria-label={`Przywróć zasób: ${r.name}`}
              disabled={r.currentValue === r.maxValue}
              onClick={() => state.adjustResource(slotId, actor.id, r.id, 1)}
            >
              +1
            </button>
          </div>
        ))}
      </div>
      <div className="action-groups">
        {Object.entries(actionLabels).map(([k, label]) => {
          const kind = k as ActionKind;
          const list = c.abilities.filter((a) => a.kind === kind);
          if (kind === 'legendary' && !c.legendaryMax && !list.length)
            return null;
          return (
            <section
              className="action-group"
              key={kind}
              aria-label={`${label} — pula i zdolności`}
            >
              <div className="capability-budget">
                <strong>
                  {label}:{' '}
                  {kind === 'reaction' && c.unlimitedReactions
                    ? 'Bez limitu'
                    : `${c.budget[kind]}/${kind === 'legendary' ? c.legendaryMax : 1}`}
                </strong>
                {control(k, label, kind)}
                <button
                  className="secondary-button"
                  type="button"
                  disabled={
                    (kind === 'reaction' && c.unlimitedReactions) ||
                    c.budget[kind] ===
                      (kind === 'legendary' ? c.legendaryMax : 1)
                  }
                  onClick={() => state.restoreBudget(slotId, actor.id, kind)}
                >
                  Przywróć: {label}
                </button>
              </div>
              <div className="rule-grid">
                {list.map((a) => (
                  <div className="ability-entry" key={a.id}>
                    {control(
                      a.id,
                      a.name,
                      a.kind,
                      a.legendaryCost,
                      a.resourceId,
                      a.resourceCost,
                    )}
                    <details className="ability-description">
                      <summary>Opis: {a.name}</summary>
                      <RuleText
                        text={a.description}
                        label={a.name}
                        onRoll={actorRollHandler(slotId, actor)}
                      />
                    </details>

                    {(a.kind === 'legendary' || a.resourceId) && (
                      <p className="editor-hint">
                        {a.kind === 'legendary'
                          ? `Koszt legendarny: ${a.legendaryCost}. `
                          : ''}
                        {a.resourceId
                          ? `Zasób: ${c.resources.find((r) => r.id === a.resourceId)?.name}, koszt ${a.resourceCost}.`
                          : ''}
                      </p>
                    )}
                  </div>
                ))}
              </div>
              {kind === 'action' && (
                <details className="action-weapons">
                  <summary>
                    Profile broni i warianty (
                    {parsed.enemy?.loadout?.items.length ?? 0})
                  </summary>
                  <p className="editor-hint">
                    Zestaw broni jest wspólny dla zdolności. Rodzaj i koszt
                    akcji określa opis używanej zdolności.
                  </p>
                  <LoadoutPanel slotId={slotId} actor={actor} />
                </details>
              )}
            </section>
          );
        })}
      </div>
    </section>
  );
}
