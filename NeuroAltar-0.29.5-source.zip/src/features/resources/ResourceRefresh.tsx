import { useState } from 'react';
import type { SlotId } from '../../domain/encounterDetails';
import { useCombatStore } from '../../stores/combatStore';
export function ResourceRefresh({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore();
  const [event, setEvent] = useState<'day' | 'encounter' | null>(null);
  return (
    <div className="preparation-controls">
      <div className="actor-actions">
        <button
          type="button"
          className="secondary-button"
          disabled={disabled}
          onClick={() => setEvent('encounter')}
        >
          Odnów zasoby na potyczkę
        </button>
        <button
          type="button"
          className="secondary-button"
          disabled={disabled}
          onClick={() => setEvent('day')}
        >
          Nowy dzień — odnów zasoby
        </button>
      </div>
      {event && (
        <div className="remove-confirm">
          <p>
            Odnowić do maksimum tylko zasoby{' '}
            {event === 'day' ? 'dzienne' : 'na potyczkę'} obecnych przeciwników
            tego slotu? PW, statusy, tura i stan przygotowany pozostaną bez
            zmian.
          </p>
          <button
            type="button"
            disabled={disabled}
            onClick={() => {
              state.refreshResources(slotId, event);
              setEvent(null);
            }}
          >
            Potwierdź odnowienie zasobów
          </button>
          <button type="button" onClick={() => setEvent(null)}>
            Anuluj odnowienie
          </button>
        </div>
      )}
    </div>
  );
}
