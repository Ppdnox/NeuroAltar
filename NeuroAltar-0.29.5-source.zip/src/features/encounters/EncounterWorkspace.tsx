import { combatWorkspaceActive } from '../../services/workspaceShortcuts';
import { SlotDifficulty } from '../difficulty/SlotDifficulty';
import { DifficultyPanel } from '../difficulty/DifficultyPanel';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Check, Clock3, LoaderCircle, AlertTriangle } from 'lucide-react';
import { useCombatStore } from '../../stores/combatStore';
import { CombatWorkspace } from '../combat/CombatWorkspace';
import { combatSaveLabels } from '../combat/saveLabels';
import { SLOT_IDS } from '../../domain/encounter';
import { type SlotId } from '../../domain/encounterDetails';
import {
  useEncounterStore,
  type SaveStatus,
} from '../../stores/encounterStore';

const labels: Record<SaveStatus, string> = {
  saved: 'Zapisano lokalnie',
  pending: 'Oczekuje na zapis',
  saving: 'Zapisywanie…',
  error: 'Nie zapisano',
  invalid: 'Popraw dane',
};
export function EncounterWorkspace() {
  const {
    activeId,
    drafts,
    selectSlot: selectDetailsSlot,
    edit,
    flush,
    closing,
    closeError,
  } = useEncounterStore();
  const combat = useCombatStore();
  useEffect(() => {
    if (
      !closing &&
      !combat.closing &&
      closeError?.startsWith('Aplikacja pozostaje otwarta:') &&
      [
        combat.enemyForm,
        combat.statusForm,
        combat.capabilityForm,
        combat.failureForm,
        combat.statblockForm,
        combat.loadoutForm,
      ].every((form) => form === null) &&
      SLOT_IDS.every(
        (id) =>
          drafts[id]?.status === 'saved' &&
          combat.drafts[id]?.status === 'saved',
      )
    )
      useEncounterStore.setState({ closeError: null });
  }, [closeError, closing, combat, drafts]);

  const [panels, setPanels] = useState<Partial<Record<SlotId, boolean>>>({});
  const selectSlot = useCallback(
    (id: SlotId) => {
      if (closing || useCombatStore.getState().closing) return;
      void useCombatStore.getState().flush(activeId);
      selectDetailsSlot(id);
    },
    [activeId, closing, selectDetailsSlot],
  );
  const tabs = useRef<Partial<Record<SlotId, HTMLButtonElement | null>>>({});
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!combatWorkspaceActive()) return;
      if (
        document.querySelector('dialog[open]') ||
        event.defaultPrevented ||
        event.repeat ||
        !(event.metaKey || event.ctrlKey) ||
        event.altKey ||
        event.shiftKey ||
        event.isComposing
      )
        return;
      const id = SLOT_IDS.find((value) => String(value) === event.key);
      if (id) {
        event.preventDefault();
        selectSlot(id);
        tabs.current[id]?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectSlot]);
  const draft = drafts[activeId]!;
  const StatusIcon =
    draft.status === 'saved'
      ? Check
      : draft.status === 'saving'
        ? LoaderCircle
        : draft.status === 'pending'
          ? Clock3
          : AlertTriangle;
  return (
    <div className="encounter-dashboard">
      <header className="session-encounter-heading">
        <div>
          <p className="session-eyebrow">Panel mistrza gry</p>
          <h1>{draft.details.name.trim() || `Potyczka ${activeId}`}</h1>
          <p className="session-encounter-subtitle">
            Potyczka {activeId} · Runda{' '}
            {combat.drafts[activeId]?.value.roundNumber ?? 1}
          </p>
        </div>
        <span className={`save-state save-${draft.status}`} role="status">
          <StatusIcon size={15} aria-hidden="true" />
          {closing ? 'Kończenie zapisu…' : labels[draft.status]}
        </span>
      </header>
      <div
        className="encounter-grid"
        role="tablist"
        aria-label="Stałe sloty potyczek"
      >
        {SLOT_IDS.map((id, index) => (
          <button
            type="button"
            role="tab"
            key={id}
            id={`slot-tab-${id}`}
            ref={(element) => {
              tabs.current[id] = element;
            }}
            className="encounter-card"
            aria-selected={id === activeId}
            aria-controls="slot-panel"
            tabIndex={id === activeId ? 0 : -1}
            disabled={closing}
            onClick={() => selectSlot(id)}
            onKeyDown={(event) => {
              const next =
                event.key === 'ArrowRight' || event.key === 'ArrowDown'
                  ? (index + 1) % 5
                  : event.key === 'ArrowLeft' || event.key === 'ArrowUp'
                    ? (index + 4) % 5
                    : event.key === 'Home'
                      ? 0
                      : event.key === 'End'
                        ? 4
                        : undefined;
              if (next !== undefined) {
                event.preventDefault();
                selectSlot(SLOT_IDS[next]!);
                tabs.current[SLOT_IDS[next]!]?.focus();
              }
            }}
          >
            <span className="card-top">
              <span className="card-label">Potyczka {id}</span>
              <span className="card-shortcut">⌘{id}</span>
            </span>
            <span className="card-name">
              {drafts[id]?.details.name.trim() || `Potyczka ${id}`}
            </span>
            <span
              className={`card-foot save-${drafts[id]?.status} ${drafts[id]?.status === 'saved' && (!combat.drafts[id] || combat.drafts[id]?.status === 'saved') ? 'is-clean' : ''}`}
            >
              <span className="card-dash" aria-hidden="true" />
              {labels[drafts[id]!.status]}
              {combat.drafts[id] && combat.drafts[id]!.status !== 'saved' && (
                <span> · {combatSaveLabels[combat.drafts[id]!.status]}</span>
              )}
            </span>
            <SlotDifficulty
              levels={drafts[id]!.details.partyLevelsText}
              actors={combat.drafts[id]?.value.actors}
            />
          </button>
        ))}
      </div>
      <section
        key={activeId}
        className="encounter-editor"
        role="tabpanel"
        id="slot-panel"
        aria-labelledby={`slot-tab-${activeId}`}
      >
        {closeError && (
          <p className="editor-error" role="alert">
            {closeError}
          </p>
        )}
        <DifficultyPanel
          slotId={activeId}
          open={panels[activeId] ?? false}
          onToggle={(open) =>
            setPanels((p) =>
              p[activeId] === open ? p : { ...p, [activeId]: open },
            )
          }
        />
        <CombatWorkspace slotId={activeId} />
        <details
          className="encounter-details"
          open={
            draft.status === 'invalid' || draft.status === 'error'
              ? true
              : undefined
          }
        >
          <summary>Nazwa i notatki potyczki</summary>
          <label className="field-label" htmlFor="encounter-name">
            Nazwa potyczki
          </label>
          <input
            id="encounter-name"
            className="name-input"
            value={draft.details.name}
            disabled={closing}
            autoComplete="off"
            aria-invalid={draft.status === 'invalid'}
            aria-describedby={draft.error ? 'save-error' : undefined}
            onChange={(event) => edit(activeId, { name: event.target.value })}
            onBlur={() => {
              void flush(activeId);
            }}
          />
          <label className="field-label notes-label" htmlFor="encounter-notes">
            Notatki Mistrza Gry
          </label>
          <textarea
            id="encounter-notes"
            value={draft.details.notes}
            disabled={closing}
            placeholder="Miejsce starcia, stawka, tropy. Wszystko, co warto mieć pod ręką."
            onChange={(event) => edit(activeId, { notes: event.target.value })}
            onBlur={() => {
              void flush(activeId);
            }}
          />
          {draft.error && (
            <div className="editor-error" id="save-error" role="alert">
              <p>{draft.error}</p>
              {draft.status === 'error' && (
                <button
                  className="retry-button"
                  type="button"
                  onClick={() => {
                    void flush(activeId);
                  }}
                >
                  Ponów zapis
                </button>
              )}
            </div>
          )}
          <p className="editor-hint">
            Zmiany zapisują się automatycznie. Każdy slot ma własną nazwę i
            notatki.
          </p>
        </details>
      </section>
    </div>
  );
}
