# Wiedza MG — Etap 21

KnowledgeWorkspace przegląda 50 wpisów źródłowych. Lokalne dane pakietu przechodzą
walidację w src/data/knowledge/catalog.ts. Czyste modele, wyszukiwanie i wybór
wierszy są w domain/knowledge.ts; stan widoku w knowledgeStore. Brak SQLite,
mutacji gry, importera, rollera i synchronizacji z Excelem.
Tabele handlu korzystają z istniejących market-rules i TRADE_COLORS.
KnowledgeEntry/ReferenceEntry: jeden model tabel i opisów. Pełny spis źródeł
w docs/WIEDZA_MG_ZRODLA.md. Prywatny root reference/ nadal ignorowany.
