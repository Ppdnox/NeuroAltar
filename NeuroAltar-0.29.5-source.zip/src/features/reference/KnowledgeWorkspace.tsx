import { useEffect, useMemo } from 'react';
import { useKnowledgeStore } from '../../stores/knowledgeStore';
import {
  filterKnowledge,
  formatHandbookPages,
  knowledgeParagraphs,
  matchingRows,
  type KnowledgeEntry,
  type KnowledgeTable,
} from '../../domain/knowledge';
import { useBestiaryStore } from '../../stores/bestiaryStore';
import './knowledge.css';

function LongText({ text }: { text: string }) {
  const paragraphs = knowledgeParagraphs(text);
  return (
    <div className="knowledge-paragraphs">
      {paragraphs.map((paragraph, index) => {
        // A short leading label is emphasized without hiding any rule text.
        const label = paragraph.match(/^([^:\n]{3,84}):\s+([\s\S]+)$/);
        return (
          <p key={index}>
            {label ? (
              <>
                <strong>{label[1]}:</strong> {label[2]}
              </>
            ) : (
              paragraph
            )}
          </p>
        );
      })}
    </div>
  );
}
export function KnowledgeTableView({
  entry,
  table,
  query,
}: {
  entry: KnowledgeEntry;
  table: KnowledgeTable;
  query: string;
}) {
  const rows = matchingRows(entry, table, query);
  const armorStrengthColumn =
    entry.category === 'Pancerze' && table.columns[2]?.label === 'SIŁA';
  return (
    <section>
      {query.trim() && (
        <p className="editor-hint">
          Wiersze: {rows.length} z {table.rows.length}
        </p>
      )}
      <div
        className="knowledge-table-scroll"
        tabIndex={0}
        aria-label={`Tabela: ${entry.title}`}
      >
        <table
          className={`knowledge-table${armorStrengthColumn ? ' knowledge-table--armor' : ''}`}
        >
          <caption>{entry.title}</caption>
          <thead>
            <tr>
              {table.columns.map((col, index) => (
                <th key={index} scope="col">
                  {col.label}
                  {col.unit && ` (${col.unit})`}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                {row.cells.map((cell, index) => (
                  <td key={index}>
                    <span className="knowledge-cell-label">
                      {table.columns[index]!.label}
                      {table.columns[index]!.unit &&
                        ` (${table.columns[index]!.unit})`}
                    </span>
                    {cell.text ? (
                      <LongText text={cell.text} />
                    ) : (
                      <span aria-label="Brak danych">—</span>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length === 0 && (
        <p>
          Hasło znaleziono w opisie wpisu. Wyczyść wyszukiwanie, aby zobaczyć
          całą tabelę.
        </p>
      )}
    </section>
  );
}
export function KnowledgeWorkspace() {
  const state = useKnowledgeStore();
  useEffect(() => {
    if (!useKnowledgeStore.getState().loaded)
      useKnowledgeStore.getState().load();
  }, []);
  const filtered = useMemo(
    () => filterKnowledge(state.entries, state.query, state.category),
    [state.entries, state.query, state.category],
  );
  const categories = useMemo(
    () => [...new Set(state.entries.map((e) => e.category))],
    [state.entries],
  );
  const selected =
    filtered.find((e) => e.id === state.selectedId) ?? filtered[0];
  return (
    <div className="knowledge-workspace">
      <div className="knowledge-filters">
        <label>
          <span>Szukaj w Wiedzy MG</span>
          <input
            type="search"
            value={state.query}
            placeholder="Zasada, stan, przedmiot…"
            onChange={(e) => state.search(e.target.value)}
          />
        </label>
        <label>
          <span>Dział Wiedzy MG</span>
          <select
            value={state.category}
            onChange={(e) => state.filter(e.target.value)}
          >
            <option value="">Wszystkie działy</option>
            {categories.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <button
          className="secondary-button"
          onClick={() => {
            state.search('');
            state.filter('');
          }}
        >
          Wyczyść filtry
        </button>
      </div>
      <p role="status">
        Wpisy: {filtered.length} z {state.entries.length}
      </p>
      {state.error && (
        <div role="alert" className="error-panel">
          <p>{state.error}</p>
          <button className="secondary-button" onClick={state.load}>
            Ponów odczyt Wiedzy MG
          </button>
        </div>
      )}
      {state.loaded && filtered.length === 0 && (
        <p>Brak pasujących wpisów. Zmień hasło lub dział.</p>
      )}
      <div className="knowledge-columns">
        <nav className="knowledge-index" aria-label="Spis Wiedzy MG">
          {filtered.map((e) => (
            <button
              key={e.id}
              className="knowledge-entry"
              aria-pressed={selected?.id === e.id}
              onClick={() => state.select(e.id)}
            >
              <small>{e.category}</small>
              <strong>{e.title}</strong>
            </button>
          ))}
        </nav>
        {selected && (
          <KnowledgeReader
            key={selected.id}
            entry={selected}
            query={state.query}
          />
        )}
      </div>
    </div>
  );
}

export function KnowledgeReader({
  entry: selected,
  query,
}: {
  entry: KnowledgeEntry;
  query: string;
}) {
  return (
    <article
      key={selected.id}
      className="knowledge-reader"
      aria-label={`Wiedza MG: ${selected.title}`}
    >
      <p className="section-kicker">{selected.category}</p>
      <h3>{selected.title}</h3>
      {selected.blocks.map((block, index) =>
        block.kind === 'table' ? (
          <KnowledgeTableView
            key={index}
            table={block}
            entry={selected}
            query={query}
          />
        ) : (
          <LongText key={index} text={block.text} />
        ),
      )}
      <details className="knowledge-source">
        <summary>Źródło</summary>
        <p>
          {selected.handbook.title} · s.{' '}
          {formatHandbookPages(selected.handbook.pages)}
        </p>
      </details>
      {(selected.category === 'Handel' ||
        selected.blocks.some(
          (b) => b.kind === 'table' && b.columns.some((c) => c.unit === 'gb'),
        )) && (
        <button
          className="secondary-button"
          onClick={() => useBestiaryStore.getState().setView('equipment')}
        >
          Przelicz ceny w Ekwipunku
        </button>
      )}
    </article>
  );
}
