import { parseActorDraft, type ActorDraft } from '../../domain/combat';
import {
  cowardiceWarning,
  injuryConsequences,
  injuryLabels,
} from '../../domain/injury';
import { displaySpeeds } from '../../domain/presentation';
import type { SlotId } from '../../domain/encounterDetails';
import { useCombatStore } from '../../stores/combatStore';
export function InjuryBadges({ actor }: { actor: ActorDraft }) {
  let parsed;
  try {
    parsed = parseActorDraft(actor);
  } catch {
    return null;
  }
  const injury = injuryConsequences(parsed);
  const cowardice = cowardiceWarning(parsed);
  return (
    <>
      {injury.level > 0 && (
        <small className="injury-badge">
          Zranienie:{' '}
          {injury.deathWarning ? 'Śmierć — MG' : injuryLabels[injury.level]}
        </small>
      )}
      {cowardice?.active && (
        <small className="injury-badge">Tchórzliwość — próg PW</small>
      )}
    </>
  );
}

export function InjuryPanel({
  slotId,
  actor,
}: {
  slotId: SlotId;
  actor: ActorDraft;
}) {
  const state = useCombatStore();
  if (!actor.enemy) return null;
  const result = (() => {
    try {
      const parsed = parseActorDraft(actor);
      return {
        injury: injuryConsequences(parsed),
        cowardice: cowardiceWarning(parsed),
      };
    } catch {
      return null;
    }
  })();
  const injury = actor.enemy.injury;
  const step = injury?.deathWarning ? 5 : (injury?.level ?? 0);
  return (
    <section className="injury-panel" aria-label="Zranienia i Tchórzliwość">
      <h3>Zranienia</h3>
      <label className="injury-toggle">
        <input
          type="checkbox"
          checked={injury?.enabled ?? false}
          disabled={!result}
          onChange={(e) =>
            state.setInjuryEnabled(slotId, actor.id, e.target.checked)
          }
        />
        Stosuj Stopnie Zranienia
      </label>
      {injury?.enabled && (
        <>
          <div className="exhaustion-control">
            <strong>
              {injury.level}/4 — {injuryLabels[injury.level]}
            </strong>
            <button
              type="button"
              aria-label="Zmniejsz Zranienie"
              disabled={!result || step === 0}
              onClick={() => state.setInjuryLevel(slotId, actor.id, step - 1)}
            >
              −1
            </button>
            <button
              type="button"
              aria-label="Zwiększ Zranienie"
              disabled={!result || step === 5}
              onClick={() => state.setInjuryLevel(slotId, actor.id, step + 1)}
            >
              +1
            </button>
          </div>
          {result && (
            <div aria-live="polite">
              {result.injury.level >= 1 && (
                <p>Szybkość: −4,5 m ze Zranienia.</p>
              )}
              {result.injury.reactionsBlocked && <p>Brak Reakcji.</p>}
              {result.injury.bonusActionsBlocked && (
                <p>Brak Akcji Bonusowych.</p>
              )}
              {result.injury.level === 4 && (
                <p>Krytyczny — wejście na ten stopień dodaje 1 Wyczerpania.</p>
              )}
              {result.injury.deathWarning && (
                <p className="hp-warning" role="alert">
                  Kolejne Zranienie po Krytycznym — śmierć. MG rozstrzyga dalszy
                  stan postaci.
                </p>
              )}
            </div>
          )}
          <p className="editor-hint">
            MG zmienia stopień ręcznie. Obniżenie lub wyłączenie Zranień nie
            usuwa Wyczerpania; skoryguj jego licznik osobno. Wyłączenie zeruje
            tor Zranień.
          </p>
        </>
      )}
      {result &&
        (result.injury.speedPenalty > 0 ||
          actor.enemy.machineFailures?.some((f) =>
            [2, 19, 20].includes(f.result),
          )) && (
          <div className="movement-preview">
            <strong>Ruch po karach Zranienia, Wyczerpania i awarii</strong>
            <pre>
              {displaySpeeds(result.injury.speeds) || 'Brak danych o ruchu'}
            </pre>
            <p className="editor-hint">
              Podgląd w metrach, minimum 0. Pole ruchu zachowuje wartość przed
              tymi karami. Najpierw odejmowane są kary, potem mnożniki awarii.
              Pozostałe stany rozstrzyga MG.
            </p>
          </div>
        )}
      <label>
        <span>Tchórzliwość — % maksymalnych PW (puste = brak)</span>
        <input
          aria-label="Tchórzliwość instancji"
          inputMode="numeric"
          value={actor.cowardicePercentText ?? ''}
          onChange={(e) =>
            state.editActor(slotId, actor.id, {
              cowardicePercentText: e.target.value,
            })
          }
          onBlur={() => {
            void state.flush(slotId);
          }}
        />
      </label>
      {result?.cowardice && (
        <p
          className={result.cowardice.active ? 'hp-warning' : 'editor-hint'}
          role={result.cowardice.active ? 'alert' : undefined}
        >
          Próg Tchórzliwości: {result.cowardice.percent}% — PW ≤{' '}
          {result.cowardice.threshold}.
          {result.cowardice.active &&
            ' Próg osiągnięty — rozważ wycofanie lub poddanie. Decyzja należy do MG.'}
        </p>
      )}
    </section>
  );
}
