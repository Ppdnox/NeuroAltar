import { Fragment } from 'react';
import { ruleRolls } from '../../domain/ruleRolls';
import { RollValue, type ActorRollHandler } from './ActorRoll';
export function RollText({
  text,
  label,
  onRoll,
  disabled,
}: {
  text: string;
  label: string;
  onRoll?: ActorRollHandler;
  disabled?: boolean;
}) {
  if (!onRoll) return text;
  const rolls = ruleRolls(text);
  const chunks = rolls.map((roll, index) => {
    const prefix = text.slice(rolls[index - 1]?.end ?? 0, roll.start);
    return (
      <Fragment key={roll.start}>
        {prefix}
        <RollValue
          formula={roll.formula}
          label={`${roll.kind === 'attack' ? 'Atak' : 'Rzut'} — ${label}`}
          kind={roll.kind}
          onRoll={onRoll}
          disabled={disabled}
        >
          {text.slice(roll.start, roll.end)}
        </RollValue>
      </Fragment>
    );
  });
  return (
    <>
      {chunks}
      {text.slice(rolls.at(-1)?.end ?? 0)}
    </>
  );
}
