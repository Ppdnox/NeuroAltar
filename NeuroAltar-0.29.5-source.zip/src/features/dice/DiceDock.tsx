import { Dice5, X } from 'lucide-react';
import { useDiceStore } from '../../stores/diceStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { useEncounterMaintenanceStore } from '../../stores/encounterMaintenanceStore';
import { DiceWorkspace } from './DiceWorkspace';
export function DiceDock() {
  const open = useDiceStore((s) => s.open);
  const closing = useEncounterStore((s) => s.closing);
  const maintenance = useEncounterMaintenanceStore((s) => s.slotId !== null);
  const blocked = closing || maintenance;
  const close = () => {
    useDiceStore.getState().setOpen(false);
    document.getElementById('dice-toggle')?.focus();
  };
  return (
    <aside
      className="dice-dock"
      aria-label="Podręczne kości"
      onKeyDown={(e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          close();
        }
        if (e.repeat && (e.key === 'Enter' || e.code === 'Space'))
          e.preventDefault();
      }}
    >
      {open && (
        <section
          id="dice-popover"
          className="dice-popover"
          aria-label="Panel kości"
        >
          <header>
            <h2>Kości</h2>
            <button
              type="button"
              className="secondary-button"
              aria-label="Zwiń panel kości"
              onClick={close}
            >
              <X size={18} />
            </button>
          </header>
          <DiceWorkspace blocked={blocked} />
        </section>
      )}
      <button
        id="dice-toggle"
        className="dice-toggle"
        type="button"
        aria-expanded={open}
        aria-controls={open ? 'dice-popover' : undefined}
        onClick={() => (open ? close() : useDiceStore.getState().setOpen(true))}
      >
        <Dice5 size={22} aria-hidden="true" /> Kości
      </button>
    </aside>
  );
}
