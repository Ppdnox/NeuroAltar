import {
  naturalDieClass,
  naturalRollClass,
  naturalRollLabel,
} from '../../domain/dicePresentation';
import { useEffect } from 'react';
import {
  DICE_SIDES,
  HISTORY_LIMIT,
  diceFaceSides,
  type DiceRoll,
} from '../../domain/dice';
import { useDiceStore } from '../../stores/diceStore';
import './dice.css';
import { RollSupplements } from './RollSupplements';
export function DiceResult({ roll }: { roll: DiceRoll }) {
  return (
    <div className="dice-result">
      {roll.characterContext && (
        <p>
          {roll.characterContext.name} · {roll.characterContext.label}
        </p>
      )}
      {roll.context && (
        <p>
          {roll.context.actorName} · {roll.context.label} · Potyczka{' '}
          {roll.context.encounterId}
        </p>
      )}
      {roll.critical && (
        <p className="natural-twenty">
          Krytyk · kości ×{roll.context?.criticalMultiplier ?? 2} (
          {roll.critical.originalFormula} → {roll.formula})
        </p>
      )}
      {roll.context?.purpose === 'attack' &&
        roll.values.length === 1 &&
        roll.sides === 20 &&
        roll.values[0] === 20 && (
          <p className="natural-twenty">
            Naturalne 20 w ataku. Następny rzut obrażeń z tej samej broni lub
            zdolności pomnoży kości ×{roll.context?.criticalMultiplier ?? 2}.
          </p>
        )}
      <p className="section-kicker">{roll.formula}</p>
      {roll.supplement && (
        <p>
          {roll.supplement.originalLabel}: poprzedni wynik{' '}
          {roll.supplement.originalTotal} (k20:{' '}
          {roll.supplement.originalNatural}) + kość zdolności {roll.values[0]} ={' '}
          {roll.total}.
        </p>
      )}
      <p className="dice-total">
        <span>Wynik</span>
        <strong className={naturalRollClass(roll)}>{roll.total}</strong>
        {naturalRollLabel(roll) && (
          <small className={naturalRollClass(roll)}>
            {naturalRollLabel(roll)}
          </small>
        )}
      </p>
      {roll.checkDice && (
        <p>
          {roll.checkDice.mode === 'advantage' ? 'Ułatwienie' : 'Utrudnienie'}:{' '}
          {roll.checkDice.values.join(' / ')} → {roll.values[0]}
        </p>
      )}
      <div className="dice-values" aria-label="Wyniki poszczególnych kości">
        {roll.values.map((v, i) => (
          <span key={i} className={naturalDieClass(diceFaceSides(roll)[i]!, v)}>
            {roll.groups ? `k${diceFaceSides(roll)[i]}: ` : ''}
            {v}
          </span>
        ))}
      </div>
      <p>
        Suma kości: {roll.total - roll.modifier} · Modyfikator:{' '}
        {roll.modifier > 0 ? '+' : ''}
        {roll.modifier}
      </p>
    </div>
  );
}
export function DiceWorkspace({ blocked = false }: { blocked?: boolean }) {
  const state = useDiceStore();
  useEffect(() => {
    void useDiceStore.getState().load();
  }, []);
  const latest = state.pending ?? state.history[0];
  const locked = blocked || state.busy || !state.loaded || !!state.pending;
  return (
    <div className="dice-workspace">
      <section className="dice-controls" aria-label="Ustawienia rzutu">
        <div className="actor-actions" aria-label="Sposób ustawienia rzutu">
          <button
            className="secondary-button"
            aria-pressed={state.mode === 'simple'}
            onClick={() => state.edit({ mode: 'simple' })}
          >
            Wybierz kości
          </button>
          <button
            className="secondary-button"
            aria-pressed={state.mode === 'formula'}
            onClick={() => state.edit({ mode: 'formula' })}
          >
            Wpisz formułę
          </button>
        </div>
        <form
          aria-label="Rzut kośćmi"
          onSubmit={async (e) => {
            e.preventDefault();
            if (locked) return;
            if (!(await state.roll()))
              document.getElementById('dice-input-error')?.focus();
          }}
        >
          {state.mode === 'simple' ? (
            <>
              <div className="dice-choices" aria-label="Rodzaj kości">
                {DICE_SIDES.map((sides) => (
                  <button
                    key={sides}
                    type="button"
                    className="secondary-button"
                    aria-pressed={state.sides === sides}
                    onClick={() => state.edit({ sides })}
                  >
                    k{sides}
                  </button>
                ))}
              </div>
              <div className="dice-fields">
                <label>
                  Liczba kości
                  <input
                    aria-label="Liczba kości"
                    inputMode="numeric"
                    value={state.count}
                    maxLength={3}
                    onChange={(e) => state.edit({ count: e.target.value })}
                  />
                </label>
                <label>
                  Modyfikator
                  <input
                    aria-label="Modyfikator rzutu"
                    inputMode="text"
                    value={state.modifier}
                    maxLength={6}
                    onChange={(e) => state.edit({ modifier: e.target.value })}
                  />
                </label>
              </div>
            </>
          ) : (
            <label>
              Formuła rzutu
              <input
                aria-label="Formuła rzutu"
                value={state.formula}
                maxLength={64}
                spellCheck={false}
                autoComplete="off"
                aria-describedby="dice-formula-help"
                onChange={(e) => state.edit({ formula: e.target.value })}
              />
              <small id="dice-formula-help">
                Np. 2k6+3, 2k8+2k6+4, k20-1 lub 1k100. Do 100 kości i
                modyfikator od −10000 do 10000.
              </small>
            </label>
          )}
          {state.inputError && (
            <p
              id="dice-input-error"
              className="editor-error"
              role="alert"
              tabIndex={-1}
            >
              {state.inputError}
            </p>
          )}
          <button className="retry-button" disabled={locked} type="submit">
            Rzuć kośćmi
          </button>
        </form>
        {state.storageError && (
          <div className="editor-error" role="alert" tabIndex={-1}>
            <p>{state.storageError}</p>
            <button
              className="secondary-button"
              onClick={() => {
                void (state.loaded ? state.retry() : state.load());
              }}
            >
              {state.loaded ? 'Ponów zapis wyniku' : 'Ponów odczyt historii'}
            </button>
          </div>
        )}
        {state.busy && <p role="status">Zapisuję wynik…</p>}
        <div role="status" aria-live="polite" aria-atomic="true">
          {latest ? (
            <>
              <DiceResult roll={latest} />
              <RollSupplements
                key={latest.id}
                roll={latest}
                disabled={locked}
              />
            </>
          ) : (
            <p>Wybierz kości i wykonaj pierwszy rzut.</p>
          )}
        </div>
      </section>
      <section className="dice-history" aria-label="Historia rzutów">
        <h3>Historia rzutów</h3>
        <p>Ostatnie {HISTORY_LIMIT} rzutów, zapisane na tym urządzeniu.</p>
        {state.history.length === 0 && <p>Brak zapisanych rzutów.</p>}
        <ol>
          {state.history.map((roll) => (
            <li key={roll.id}>
              <div className="dice-history-heading">
                <strong
                  className={naturalRollClass(roll)}
                  title={naturalRollLabel(roll)}
                >
                  {roll.formula} = {roll.total}
                </strong>
                <time dateTime={roll.createdAt}>
                  {new Date(roll.createdAt).toLocaleString('pl-PL')}
                </time>
              </div>
              <details>
                <summary>Składowe wyniku</summary>
                <DiceResult roll={roll} />
                <RollSupplements roll={roll} disabled={locked} />
              </details>
              <button
                className="secondary-button"
                disabled={locked}
                onClick={() => {
                  void state.roll(roll.formula);
                }}
                aria-label={`Powtórz rzut ${roll.formula}`}
              >
                Rzuć ponownie bez przypisania
              </button>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
