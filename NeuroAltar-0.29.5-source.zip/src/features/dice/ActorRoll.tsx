import type { ReactNode } from 'react';
import { useDiceStore } from '../../stores/diceStore';
import { parseDiceFormula } from '../../domain/dice';
import type { ActorRollHandler } from '../../services/actorDice';
export type { ActorRollHandler } from '../../services/actorDice';
export function RollValue({
  formula,
  label,
  kind = 'test',
  onRoll,
  disabled,
  children,
}: {
  formula: string;
  label: string;
  kind?: 'test' | 'damage' | 'attack' | 'weaponAttack' | 'roll';
  onRoll?: ActorRollHandler;
  disabled?: boolean;
  children: ReactNode;
}) {
  const busy = useDiceStore((s) => s.busy || !!s.pending);
  let valid = true;
  try {
    parseDiceFormula(formula);
  } catch {
    valid = false;
  }
  return onRoll && valid ? (
    <button
      type="button"
      className="roll-value"
      aria-label={`Rzuć: ${label} (${formula})`}
      title={`Rzuć ${formula}`}
      disabled={disabled || busy}
      onClick={() => onRoll(formula, label, kind)}
      onKeyDown={(e) => {
        if (e.repeat && (e.key === 'Enter' || e.code === 'Space'))
          e.preventDefault();
      }}
    >
      {children}
    </button>
  ) : (
    <span
      title={
        onRoll && !valid
          ? 'Ten zapis wymaga ręcznego ustawienia rzutu w panelu kości.'
          : undefined
      }
    >
      {children}
    </span>
  );
}
