import { useState } from 'react';
import type { DiceRoll } from '../../domain/dice';
import { useCharacterStore } from '../../stores/characterStore';
import { useParticipationStore } from '../../stores/participationStore';
import { useCombatStore } from '../../stores/combatStore';
import { useDiceStore } from '../../stores/diceStore';
import {
  addCharacterRollBonus,
  rollBonusOptions,
} from '../../services/characterRollBonus';

export function RollSupplements({
  roll,
  disabled,
}: {
  roll: DiceRoll;
  disabled: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const characters = useCharacterStore();
  const parts = useParticipationStore((s) => s.entries);
  const history = useDiceStore((s) => s.history);
  const combat = useCombatStore((s) =>
    roll.context ? s.drafts[roll.context.encounterId]?.value : undefined,
  );
  const id =
    roll.characterCheck?.characterId ??
    roll.characterContext?.characterId ??
    parts.find(
      (p) =>
        p.actorId === roll.context?.actorId &&
        p.encounterId === roll.context?.encounterId,
    )?.characterId;
  const record = characters.records.find((c) => c.id === id);
  if (!record) return null;
  if (
    roll.context &&
    (!combat ||
      combat.roundNumber !== roll.context.roundNumber ||
      !parts.some(
        (p) =>
          p.characterId === record.id &&
          p.actorId === roll.context!.actorId &&
          p.encounterId === roll.context!.encounterId &&
          p.state === 'active',
      ))
  )
    return null;
  if (
    roll.context?.purpose === 'initiative' &&
    Number(
      combat?.actors.find((a) => a.id === roll.context!.actorId)
        ?.initiativeValue,
    ) !== roll.total
  )
    return null;
  const options = rollBonusOptions(record, roll).filter(
    (o) =>
      !history.some(
        (r) =>
          r.supplement?.originalRollId === roll.id &&
          r.supplement.resourceId === o.id,
      ),
  );
  if (!options.length) return null;
  return (
    <fieldset
      disabled={disabled || characters.locked || characters.dirty.length > 0}
      className="dice-supplements"
    >
      <legend>Dodatkowa kość zdolności</legend>
      {options.some((o) => o.requiresFailure) && (
        <label>
          <input
            type="checkbox"
            checked={failed}
            onChange={(e) => setFailed(e.target.checked)}
          />
          Ten test zakończył się niepowodzeniem
        </label>
      )}
      <div className="actor-actions">
        {options.map((o) => (
          <button
            type="button"
            className="secondary-button"
            key={o.id}
            disabled={o.requiresFailure && !failed}
            onClick={() =>
              void addCharacterRollBonus(record, roll, o.id, failed)
            }
          >
            {o.label} + k{o.sides} · 1 użycie
          </button>
        ))}
      </div>
    </fieldset>
  );
}
