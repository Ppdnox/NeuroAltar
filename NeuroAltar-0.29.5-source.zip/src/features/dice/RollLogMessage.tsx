import type { CombatLogEntry } from '../../domain/combatLog';
import { diceRollSchema } from '../../domain/dice';
import {
  naturalRollClass,
  naturalRollLabel,
} from '../../domain/dicePresentation';
export function RollLogMessage({ entry }: { entry: CombatLogEntry }) {
  const roll =
    entry.eventType === 'dice_rolled'
      ? diceRollSchema.safeParse(entry.payload.after)
      : null;
  if (!roll?.success) return <>{entry.message}</>;
  return (
    <span
      className={naturalRollClass(roll.data)}
      title={naturalRollLabel(roll.data)}
    >
      {entry.message}
      {roll.data.critical &&
        ` · Krytyk: kości ×${roll.data.context?.criticalMultiplier ?? 2}`}
      {naturalRollLabel(roll.data) && <> · {naturalRollLabel(roll.data)}</>}
    </span>
  );
}
