import { helpShortcut } from '../../domain/shortcuts';
import { useNavigationStore } from '../../stores/navigationStore';
import { useEffect, useRef } from 'react';
import { Keyboard } from 'lucide-react';

export function ShortcutHelp() {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (
        useNavigationStore.getState().page !== 'gm' ||
        !helpShortcut(event, Boolean(document.querySelector('dialog[open]')))
      )
        return;
      event.preventDefault();
      if (!dialog.current?.open) dialog.current?.showModal();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  return (
    <>
      <button
        type="button"
        className="secondary-button shortcut-help-button"
        title="Skróty i obsługa"
        aria-haspopup="dialog"
        onClick={() => dialog.current?.showModal()}
      >
        <Keyboard size={16} aria-hidden="true" /> Skróty i obsługa
      </button>
      <dialog
        ref={dialog}
        className="shortcut-dialog"
        aria-labelledby="shortcut-title"
      >
        <h2 id="shortcut-title" tabIndex={-1} autoFocus>
          Skróty i obsługa
        </h2>
        <dl>
          <dt>⌘ / Ctrl + 1–5</dt>
          <dd>W panelu potyczek przełącz slot i zapisz jego zmiany.</dd>
          <dt>Spacja</dt>
          <dd>
            Rozpocznij lub przejdź do następnej tury — poza polami i
            kontrolkami.
          </dd>
          <dt>⌥ / Alt + ↑ / ↓</dt>
          <dd>
            Poprzednia / następna karta; najpierw kolejka inicjatywy, potem
            pozostałe postacie. Nie zmienia tury. Działa poza polami edycji.
          </dd>
          <dt>Tab / Shift + Tab</dt>
          <dd>Przejdź do następnej / poprzedniej kontrolki.</dd>
          <dt>Enter / Spacja</dt>
          <dd>
            Uruchom wybrany przycisk lub rozwiń sekcję. Strzałki, Home i End na
            zakładkach wybierają slot lub zakładkę karty postaci.
          </dd>
          <dt>F1</dt>
          <dd>
            W Panelu MG otwórz tę pomoc; na części klawiatur Mac użyj Fn + F1.
          </dd>
          <dt>Escape</dt>
          <dd>Zamknij pomoc. Nie usuwa ani nie anuluje szkiców formularzy.</dd>
          <dt>⌘Q</dt>
          <dd>
            Zapisz i zamknij aplikację. Niepełne dane zatrzymają zamykanie.
          </dd>
        </dl>
        <p>
          „Pokaż bieżącą postać” wraca do karty właściciela tury. Wybór karty
          nie rozstrzyga działań za MG. Formularz dokończ lub anuluj przed
          prowadzeniem kolejnej tury.
        </p>
        <p>
          Skróty walki działają w panelu potyczek. Otwarte okno dialogowe lub
          panel kości wstrzymuje skróty walki; pola edycji nie przechwytują
          Spacji jako zmiany tury.
        </p>
        <h3>Potyczka i rzuty</h3>
        <dl>
          <dt>Dodaj przeciwnika / Dodaj własnego</dt>
          <dd>
            Pierwszy przycisk otwiera wyszukiwarkę Bestiariusza, drugi formularz
            własnej postaci.
          </dd>
          <dt>Inicjatywa przeciwnika</dt>
          <dd>
            Kliknij wpis Inicjatywa w sekcji Zdolności stałe i zasady. Wynik
            trafia do kolejki; można go też wpisać ręcznie.
          </dd>
          <dt>Ataki, obrażenia, cechy, umiejętności i RO</dt>
          <dd>
            Kliknij przycisk wartości lub formuły, aby rzucić. Panel Kości w
            prawym dolnym rogu pozwala też wybrać liczbę kości i modyfikator,
            np. 3k8+2. Wyniki znajdziesz w historii, a rzuty w potyczce również
            w jej logu.
          </dd>
          <dt>Krytyk i awarie</dt>
          <dd>
            Naturalne 20 na k20 jest zielone, 1 czerwone. Krytyczny atak
            przygotowuje dodatkowe kości kolejnego rzutu obrażeń tej samej broni
            lub zdolności. Awarię możesz wylosować albo wpisać ręcznie;
            zatwierdza ją przycisk Zastosuj awarię.
          </dd>
          <dt>Karta BG w walce</dt>
          <dd>
            Powiąż postać z istniejącą kartą BG. Zdolności i sztuczki rozliczaj
            z podglądem kosztu, celu i efektu. Rzut ataku lub obrażeń sam nie
            odejmuje PW.
          </dd>
          <dt>Zapis i trudność</dt>
          <dd>
            Zmiany zapisują się automatycznie. Karta potyczki rozwija pole
            poziomów BG; trudność pokazuje procent zaokrąglony do liczby
            całkowitej.
          </dd>
        </dl>
        <h3>Karta postaci</h3>
        <dl>
          <dt>Broń / Testy / Zdolności / Ekwipunek</dt>
          <dd>
            Główne zakładki otwierają wybraną część karty. Strzałki w lewo i
            prawo oraz Home i End przełączają zakładki, gdy mają fokus.
            Najnowszy rzut postaci widać pod zakładkami.
          </dd>
          <dt>Pasek parametrów</dt>
          <dd>
            PW otwierają zdrowie i odpoczynek, TT — szczegóły obrony. Inicjatywa
            pozwala rzucić z premią postaci. Zdrowie, postój, podsumowanie i
            rozwój pozostają dostępne pod głównymi zakładkami.
          </dd>
          <dt>Broń i amunicja</dt>
          <dd>
            Kliknij Atak lub Obrażenia na karcie broni. Zapisany atak bronią
            palną rozlicza amunicję zgodnie z wybranym trybem. Przeładowanie
            znajduje się obok magazynka; szczegóły broni można rozwinąć.
          </dd>
        </dl>
        <form method="dialog">
          <button className="secondary-button" type="submit">
            Zamknij pomoc
          </button>
        </form>
      </dialog>
    </>
  );
}
