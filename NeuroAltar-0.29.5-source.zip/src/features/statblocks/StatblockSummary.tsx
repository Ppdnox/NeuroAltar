import type { ReactNode } from 'react';
import { RollValue, type ActorRollHandler } from '../dice/ActorRoll';
import {
  ABILITIES,
  abilityLabels,
  abilityModifier,
  signedBonus,
  statblockListLabels,
  type Statblock,
  type StatblockList,
} from '../../domain/statblock';
import { presentRule } from '../../domain/presentation';
import { RuleText } from './RuleText';
export function StatblockSummary({
  value,
  tt,
  onRoll,
  disabled,
  renderInitiative,
}: {
  value?: Statblock;
  tt?: number;
  onRoll?: ActorRollHandler;
  disabled?: boolean;
  renderInitiative?: (text: string) => ReactNode;
}) {
  const traits = (value?.traits ?? [])
    .map((t) => presentRule(t, tt))
    .filter(Boolean);
  // Only recognizable provenance is folded away. Unknown/freeform rules stay visible.
  const isSource = (line: string) => /^Źródło:|^PW:/.test(line);
  const rules = traits.filter((line) => !isSource(line));
  const source = traits.filter(isSource);
  const lists = Object.entries(statblockListLabels) as [
    StatblockList,
    string,
  ][];
  return (
    <div className="statblock-summary">
      <div className="statblock-meta">
        {value?.subtype && <span>{value.subtype}</span>}
        {value?.damageThreshold != null && (
          <span>
            <strong>Próg Obrażeń</strong> {value.damageThreshold}
          </span>
        )}
      </div>
      <div
        className="ability-score-grid"
        role="group"
        aria-label="Cechy i końcowe rzuty obronne"
      >
        {ABILITIES.map((key) => (
          <div className="ability-score" key={key}>
            <span className="ability-label">{abilityLabels[key]}</span>
            <RollValue
              formula={`k20${signedBonus(abilityModifier(value?.abilityScores[key]))}`}
              label={`Test ${abilityLabels[key]}`}
              onRoll={onRoll}
              disabled={disabled}
            >
              <strong>{value?.abilityScores[key] ?? 'N/D'}</strong>
            </RollValue>
            <span>
              mod. {signedBonus(abilityModifier(value?.abilityScores[key]))}
            </span>
            <span className="saving-throw">
              <RollValue
                formula={`k20${signedBonus(value?.savingThrows[key])}`}
                label={`RO ${abilityLabels[key]}`}
                onRoll={onRoll}
                disabled={disabled}
              >
                RO {signedBonus(value?.savingThrows[key])}
              </RollValue>
            </span>
          </div>
        ))}
      </div>
      <dl className="statblock-facts">
        {lists
          .filter(([key]) => value?.[key] != null)
          .map(([key, label]) => (
            <div key={key}>
              <dt>{label}</dt>
              <dd>
                {value![key]!.length
                  ? value![key]!.map((line, index) => (
                      <span className="statblock-tag" key={index}>
                        {key === 'skills' &&
                        /^.+\s[+−-]\d+$/.test(line.trim()) ? (
                          <RollValue
                            formula={`k20${line
                              .trim()
                              .match(/[+−-]\d+$/)![0]
                              .replace('−', '-')}`}
                            label={line}
                            onRoll={onRoll}
                            disabled={disabled}
                          >
                            {line}
                          </RollValue>
                        ) : (
                          line
                        )}
                      </span>
                    ))
                  : 'Brak'}
              </dd>
            </div>
          ))}
      </dl>
      {rules.length > 0 && (
        <details className="statblock-section" open>
          <summary>
            Zdolności stałe i zasady <span>{rules.length}</span>
          </summary>
          <div className="rule-grid">
            {rules.map((line, index) =>
              renderInitiative && /^Inicjatywa\s*:/i.test(line) ? (
                <p className="rule-text" key={index}>
                  {renderInitiative(line)}
                </p>
              ) : (
                <RuleText
                  text={line}
                  key={index}
                  onRoll={onRoll}
                  disabled={disabled}
                />
              ),
            )}
          </div>
        </details>
      )}
      <details className="statblock-section source-notes">
        <summary>Źródło i pozostałe informacje</summary>
        {source.map((line, index) => (
          <RuleText text={line} key={index} />
        ))}
        {value?.subtype == null && <p>Podtyp: N/D</p>}
        {value?.damageThreshold == null && <p>Próg Obrażeń: N/D</p>}
        {lists
          .filter(([key]) => value?.[key] == null)
          .map(([key, label]) => (
            <p key={key}>{label}: N/D</p>
          ))}
        <p className="editor-hint">
          N/D oznacza brak danych. RO i premie umiejętności są końcowe.
          Odporności i progi przypominają o regułach; ich skutki rozstrzyga MG.
        </p>
      </details>
    </div>
  );
}
