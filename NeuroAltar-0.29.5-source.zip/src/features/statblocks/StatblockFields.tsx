import {
  ABILITIES,
  abilityLabels,
  statblockListLabels,
  toStatblockDraft,
  type StatblockDraft,
  type StatblockList,
} from '../../domain/statblock';
export function StatblockFields({
  value,
  onChange,
}: {
  value: StatblockDraft;
  onChange: (value: StatblockDraft) => void;
}) {
  return (
    <>
      <p className="editor-hint">
        Puste pola oznaczają brak danych (N/D). W listach wpisz jedną pozycję na
        wiersz, a „brak”, aby jawnie oznaczyć pustą listę. Zachowaj warunki i
        wyjątki z opisu.
      </p>
      <label>
        <span>Zdolności stałe i uwagi źródłowe</span>
        <textarea
          aria-label="Zdolności stałe i uwagi źródłowe"
          data-validation-path="statblock.traits"
          value={value.traits ?? ''}
          onChange={(e) => onChange({ ...value, traits: e.target.value })}
          placeholder="Jedna zdolność lub uwaga na wiersz"
        />
      </label>
      <label>
        <span>Podtyp</span>
        <input
          aria-label="Podtyp"
          data-validation-path="statblock.subtype"
          value={value.subtype}
          onChange={(e) => onChange({ ...value, subtype: e.target.value })}
        />
      </label>
      <div className="statblock-abilities">
        {ABILITIES.map((key) => (
          <div key={key}>
            <label>
              <span>{abilityLabels[key]} — wartość cechy</span>
              <input
                aria-label={`${abilityLabels[key]} — wartość cechy`}
                inputMode="numeric"
                data-validation-path={`statblock.abilityScores.${key}`}
                value={value.abilityScores[key]}
                onChange={(e) =>
                  onChange({
                    ...value,
                    abilityScores: {
                      ...value.abilityScores,
                      [key]: e.target.value,
                    },
                  })
                }
              />
            </label>
            <label>
              <span>RO {abilityLabels[key]} — końcowa premia</span>
              <input
                aria-label={`RO ${abilityLabels[key]}`}
                inputMode="text"
                data-validation-path={`statblock.savingThrows.${key}`}
                value={value.savingThrows[key]}
                onChange={(e) =>
                  onChange({
                    ...value,
                    savingThrows: {
                      ...value.savingThrows,
                      [key]: e.target.value,
                    },
                  })
                }
              />
            </label>
          </div>
        ))}
      </div>
      <p className="editor-hint">
        RO i umiejętności wpisuj z końcową premią, np. +5. Program nie dodaje do
        nich ponownie modyfikatora cechy ani biegłości. Dane ataku ustawiasz
        osobno w profilu broni.
      </p>
      {(Object.entries(statblockListLabels) as [StatblockList, string][]).map(
        ([key, label]) => (
          <label key={key}>
            <span>{label}</span>
            <textarea
              aria-label={label}
              data-validation-path={`statblock.${key}`}
              value={value[key]}
              onChange={(e) => onChange({ ...value, [key]: e.target.value })}
              placeholder={
                key === 'skills'
                  ? 'Atletyka: +5\nSkradanie: +4 (w cieniu)'
                  : 'Jedna pozycja na wiersz'
              }
            />
          </label>
        ),
      )}
      <label>
        <span>Próg Obrażeń — puste = brak danych</span>
        <input
          aria-label="Próg Obrażeń"
          inputMode="numeric"
          data-validation-path="statblock.damageThreshold"
          value={value.damageThreshold}
          onChange={(e) =>
            onChange({ ...value, damageThreshold: e.target.value })
          }
        />
      </label>
      <p className="editor-hint">
        Próg Obrażeń jest odrębny od Progu Awarii. Progi i odporności są
        przypomnieniami: MG wpisuje finalne obrażenia.
      </p>
    </>
  );
}
export function TemplateStatblockFields({
  value,
  onChange,
}: {
  value?: StatblockDraft;
  onChange: (value: StatblockDraft) => void;
}) {
  return (
    <details className="template-summary" data-validation-path="statblock">
      <summary>Cechy, obrona i zmysły (opcjonalne)</summary>
      {value ? (
        <StatblockFields value={value} onChange={onChange} />
      ) : (
        <button
          type="button"
          className="secondary-button"
          onClick={() => onChange(toStatblockDraft())}
        >
          Uzupełnij statblock
        </button>
      )}
    </details>
  );
}
