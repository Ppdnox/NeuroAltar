import { RollText } from '../dice/RollText';
import type { ActorRollHandler } from '../../services/actorDice';
import { presentRule } from '../../domain/presentation';
export function RuleText({
  text: raw,
  onRoll,
  disabled,
  label,
}: {
  text: string;
  onRoll?: ActorRollHandler;
  disabled?: boolean;
  label?: string;
}) {
  const text = presentRule(raw);
  if (!text) return null;
  const colon = text.indexOf(':');
  const rollLabel =
    label ?? (colon > 0 ? text.slice(0, colon) : 'Zasada postaci');
  const render = (value: string) => (
    <RollText
      text={value}
      label={rollLabel}
      onRoll={onRoll}
      disabled={disabled}
    />
  );
  return (
    <p className="rule-text">
      {colon > 0 && colon < 90 && !/\batak/i.test(text.slice(0, colon)) ? (
        <>
          <strong>{render(text.slice(0, colon + 1))}</strong>
          {render(text.slice(colon + 1))}
        </>
      ) : (
        render(text)
      )}
    </p>
  );
}
