import { actionLabels, refreshLabels } from '../../domain/capabilitySchema';
import type { EnemyTemplate } from '../../domain/enemy';
import { RuleText } from './RuleText';
export function CapabilitySummary({
  value,
}: {
  value: NonNullable<EnemyTemplate['capabilities']>;
}) {
  return (
    <div className="capability-summary">
      {(value.resources.length > 0 ||
        value.legendaryMax > 0 ||
        value.unlimitedReactions) && (
        <section className="statblock-section" aria-label="Limity zdolności">
          <h4>Limity zdolności</h4>
          <div className="resource-chips">
            {value.unlimitedReactions && (
              <span>
                <strong>Reakcje: Bez limitu</strong>
              </span>
            )}
            {value.legendaryMax > 0 && (
              <span>
                <strong>{value.legendaryMax}</strong> Legendarne / runda
              </span>
            )}
            {value.resources.map((r) => (
              <span key={r.id}>
                <strong>
                  {r.name}: {r.maxValue}
                </strong>{' '}
                · {refreshLabels[r.refreshRule]}
              </span>
            ))}
          </div>
        </section>
      )}
      {Object.entries(actionLabels).map(([kind, label]) => {
        const list = value.abilities.filter((a) => a.kind === kind);
        return (
          list.length > 0 && (
            <details className="statblock-section" key={kind} open>
              <summary>
                {label} <span>{list.length}</span>
              </summary>
              <div className="rule-grid">
                {list.map((a) => (
                  <article className="rule-card" key={a.id}>
                    <h4>{a.name}</h4>
                    <RuleText text={a.description} />
                    {(a.kind === 'legendary' || a.resourceId) && (
                      <p className="ability-cost">
                        {a.kind === 'legendary' &&
                          `Koszt Legendarnych: ${a.legendaryCost}`}
                        {a.resourceId &&
                          ` · ${value.resources.find((r) => r.id === a.resourceId)?.name}: ${a.resourceCost}`}
                      </p>
                    )}
                  </article>
                ))}
              </div>
            </details>
          )
        );
      })}
    </div>
  );
}
