import { InitiativeRollButton } from '../combat/InitiativeRoll';
import { actorRollHandler } from '../../services/actorDice';
import { useEffect, useMemo, useRef } from 'react';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { parseActorDraft, type ActorDraft } from '../../domain/combat';
import type { SlotId } from '../../domain/encounterDetails';
import { parseStatblockDraft } from '../../domain/statblock';
import { withIssuePath, validationIssues } from '../../domain/validation';
import { FieldValidation } from '../../components/TemplateValidation';
import { StatblockFields } from './StatblockFields';
import { StatblockSummary } from './StatblockSummary';
export function StatblockPanel({
  slotId,
  actor,
}: {
  slotId: SlotId;
  actor: ActorDraft;
}) {
  const state = useCombatStore();
  const closing = useEncounterStore((s) => s.closing);
  if (!actor.enemy) return null;
  let valid = false;
  try {
    parseActorDraft(actor);
    valid = true;
  } catch {
    /* Preserve raw input. */
  }
  const disabled =
    closing ||
    state.closing ||
    !valid ||
    !!state.statblockForm ||
    !!state.loadoutForm ||
    !!state.failureForm ||
    !!state.capabilityForm ||
    !!state.statusForm ||
    !!state.enemyForm;
  return (
    <section className="template-summary" aria-label="Statblock tej instancji">
      <h3>Cechy, obrona i zmysły</h3>
      <StatblockSummary
        renderInitiative={(text) => (
          <InitiativeRollButton
            actor={actor}
            slotId={slotId}
            disabled={disabled}
            text={text}
          />
        )}
        onRoll={actorRollHandler(slotId, actor)}
        disabled={disabled}
        value={actor.enemy.statblock}
        tt={actor.ttCurrent === '' ? undefined : Number(actor.ttCurrent)}
      />
      <button
        className="secondary-button"
        type="button"
        disabled={disabled}
        onClick={() => state.openStatblockForm(slotId, actor.id)}
      >
        Edytuj statblock instancji
      </button>
    </section>
  );
}
export function StatblockForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatStore();
  const form = state.statblockForm;
  const root = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (form?.slotId === slotId) root.current?.querySelector('input')?.focus();
  }, [form?.actorId, form?.slotId, slotId]);
  const issues = useMemo(() => {
    if (!form?.error) return [];
    try {
      withIssuePath(['statblock'], () => parseStatblockDraft(form.fields));
      return [];
    } catch (error) {
      return validationIssues(error);
    }
  }, [form]);
  if (!form || form.slotId !== slotId) return null;
  return (
    <form
      ref={root}
      className="enemy-form"
      aria-label="Statblock instancji"
      onSubmit={(e) => {
        e.preventDefault();
        state.submitStatblockForm();
      }}
    >
      <fieldset disabled={disabled}>
        <legend>Statblock tej instancji</legend>
        <p className="editor-hint">
          Zatwierdzenie zmienia tylko tę postać i zapisuje zmianę w logu.
          Szablon i stan przygotowany pozostają niezależne.
        </p>
        <FieldValidation issues={issues} error={form.error}>
          <StatblockFields
            value={form.fields}
            onChange={state.editStatblockForm}
          />
        </FieldValidation>
        <div className="actor-actions">
          <button type="submit" className="secondary-button">
            Zatwierdź statblock
          </button>
          <button
            type="button"
            className="secondary-button"
            onClick={state.cancelStatblockForm}
          >
            Anuluj formularz statblocka
          </button>
        </div>
      </fieldset>
    </form>
  );
}
