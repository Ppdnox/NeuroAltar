import { useMemo, useState } from 'react';
import { listKnowledge } from '../../data/knowledge/catalog';
import {
  formatHandbookPages,
  type KnowledgeTable,
} from '../../domain/knowledge';
import { KnowledgeTableView } from '../reference/KnowledgeWorkspace';
import './vehicles.css';

export function VehicleWorkspace() {
  const [query, setQuery] = useState('');
  const entry = useMemo(
    () =>
      listKnowledge().find(
        (candidate) =>
          candidate.title === 'Tabela statystyk wybranych pojazdów',
      )!,
    [],
  );
  const table = entry.blocks.find(
    (block): block is KnowledgeTable => block.kind === 'table',
  )!;
  return (
    <div className="vehicle-workspace">
      <label className="vehicle-search">
        <span>Szukaj pojazdu</span>
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Np. motocykl, czołg…"
        />
      </label>
      <article className="knowledge-reader vehicle-table-card">
        <h3>Pojazdy</h3>
        <KnowledgeTableView entry={entry} table={table} query={query} />
        <p className="editor-hint">
          {entry.handbook.title} · s.{' '}
          {formatHandbookPages(entry.handbook.pages)}
        </p>
      </article>
    </div>
  );
}
