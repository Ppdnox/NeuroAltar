import { speedDraftLabel } from '../../domain/presentation';
import { TemplateStatblockFields } from '../statblocks/StatblockFields';
import { TemplateValidation } from '../../components/TemplateValidation';
import { emptyLoadoutDraft } from '../../domain/itemDraft';
import { LoadoutFields } from '../equipment/LoadoutFields';
import { CapabilityFields } from '../resources/CapabilityFields';
import { emptyCapabilityDraft } from '../../domain/capabilitySchema';
import { injuryLabels } from '../../domain/injury';
import { categoryOptions, type EnemyTemplateDraft } from '../../domain/enemy';

export function TemplateFields({
  value,
  onChange,
  error,
}: {
  value: EnemyTemplateDraft;
  error?: string | null;
  onChange(patch: Partial<EnemyTemplateDraft>): void;
}) {
  const field = (key: 'name' | 'size' | 'tt' | 'hpMax', label: string) => (
    <label>
      <span>{label}</span>
      <input
        data-validation-path={key}
        value={value[key]}
        aria-label={label}
        inputMode={key === 'tt' || key === 'hpMax' ? 'numeric' : 'text'}
        onChange={(event) => onChange({ [key]: event.target.value })}
      />
    </label>
  );
  return (
    <TemplateValidation value={value} error={error}>
      <div className="enemy-fields">
        {field('name', 'Nazwa szablonu')}
        <label>
          <span>Kategoria</span>
          <select
            aria-label="Kategoria"
            data-validation-path="category"
            value={value.category}
            onChange={(event) =>
              onChange({
                category: event.target.value as EnemyTemplateDraft['category'],
              })
            }
          >
            {categoryOptions([value.category]).map(([key, label]) => (
              <option value={key} key={key}>
                {label}
              </option>
            ))}
          </select>
        </label>
        {field('size', 'Rozmiar')}
        {field('tt', 'Bazowe TT')}
        {field('hpMax', 'Bazowe maksymalne PW')}
        <label>
          <span>SP szablonu — puste = brak danych</span>
          <input
            aria-label="SP szablonu"
            inputMode="decimal"
            data-validation-path="sp"
            value={value.sp ?? ''}
            onChange={(e) => onChange({ sp: e.target.value })}
          />
        </label>
      </div>
      <TemplateStatblockFields
        value={value.statblock}
        onChange={(statblock) => onChange({ statblock })}
      />
      <label>
        <span>Ruch szablonu — metry, po jednym w wierszu</span>
        <textarea
          aria-label="Ruch szablonu"
          placeholder={'Szybkość: 9\nWspinaczka: 4,5'}
          data-validation-path="speeds"
          value={speedDraftLabel(value.speedsText)}
          onChange={(event) => onChange({ speedsText: event.target.value })}
        />
      </label>
      <p className="editor-hint">
        Puste pole oznacza brak danych o ruchu. Wpisz 0 dla konkretnego rodzaju,
        jeśli przeciwnik nie może się nim poruszać.
      </p>
      {(value.category === 'machine' ||
        value.failureThreshold !== undefined) && (
        <label>
          <span>
            Próg awarii szablonu — obrażenia jednego ataku, puste = brak
          </span>
          <input
            aria-label="Próg awarii szablonu"
            inputMode="numeric"
            data-validation-path="failureThreshold"
            value={value.failureThreshold ?? ''}
            onChange={(e) => onChange({ failureThreshold: e.target.value })}
          />
        </label>
      )}
      <label className="injury-toggle">
        <input
          type="checkbox"
          checked={value.injuryEnabled ?? false}
          onChange={(e) =>
            onChange({
              injuryEnabled: e.target.checked,
              initialInjuryLevel: '0',
            })
          }
        />
        Stopnie Zranienia w szablonie
      </label>
      {value.injuryEnabled && (
        <label>
          <span>Początkowy Stopień Zranienia</span>
          <select
            aria-label="Początkowy Stopień Zranienia"
            data-validation-path="injuryTrack"
            value={value.initialInjuryLevel ?? '0'}
            onChange={(e) => onChange({ initialInjuryLevel: e.target.value })}
          >
            {injuryLabels.map((label, level) => (
              <option key={level} value={level}>
                {level} — {label}
              </option>
            ))}
          </select>
        </label>
      )}
      <label>
        <span>Tchórzliwość szablonu — % PW, puste = brak</span>
        <input
          aria-label="Tchórzliwość szablonu"
          inputMode="numeric"
          data-validation-path="cowardicePercent"
          value={value.cowardicePercent ?? ''}
          onChange={(e) => onChange({ cowardicePercent: e.target.value })}
        />
      </label>
      <p className="editor-hint">
        Próg 0–100%. Początkowy Krytyczny stopień dodaje kopii 1 Wyczerpania.
        Każda instancja ma niezależny stan.
      </p>
      <details className="template-summary" data-validation-path="capabilities">
        <summary>Zasoby i akcje szablonu (opcjonalne)</summary>
        {value.capabilities ? (
          <CapabilityFields
            template
            value={value.capabilities}
            onChange={(capabilities) => onChange({ capabilities })}
          />
        ) : (
          <button
            className="secondary-button"
            type="button"
            onClick={() => onChange({ capabilities: emptyCapabilityDraft() })}
          >
            Przygotuj zasoby i akcje
          </button>
        )}
        <p className="editor-hint">
          Nowa kopia zaczyna z pełnymi licznikami. Pola nie opisują amunicji ani
          magazynków.
        </p>
      </details>
      <details className="template-summary" data-validation-path="loadout">
        <summary>Broń i profile ataku (opcjonalne)</summary>
        {value.loadout ? (
          <LoadoutFields
            value={value.loadout}
            onChange={(loadout) => onChange({ loadout })}
          />
        ) : (
          <button
            type="button"
            className="secondary-button"
            onClick={() => onChange({ loadout: emptyLoadoutDraft() })}
          >
            Przygotuj broń i profile ataku
          </button>
        )}
      </details>
    </TemplateValidation>
  );
}
