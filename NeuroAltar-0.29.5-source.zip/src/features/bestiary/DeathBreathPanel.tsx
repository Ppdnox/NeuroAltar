import { presentRule } from '../../domain/presentation';
import { RuleText } from '../statblocks/RuleText';
import { useState } from 'react';
import { deathBreath, prepareDeathBreath } from '../../domain/deathBreath';
import type { CatalogEntry } from '../../domain/bestiary';
import type { EnemyTemplateDraft } from '../../domain/enemy';
export function DeathBreathPanel({
  entries,
  locked,
  onPrepare,
}: {
  entries: CatalogEntry[];
  locked: boolean;
  onPrepare(draft: EnemyTemplateDraft): void;
}) {
  const [hostId, setHostId] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const [error, setError] = useState('');
  const hosts = entries.filter((e) =>
    ['human', 'mutant'].includes(e.template.category),
  );
  const host = hosts.find((e) => e.template.id === hostId)?.template;
  return (
    <section className="bestiary-detail" aria-label="Nakładka Death Breath">
      <h3>{deathBreath.name}</h3>
      <p>{deathBreath.source}</p>
      <div className="rule-grid">
        {deathBreath.rules.map((rule) => (
          <RuleText key={rule} text={rule} />
        ))}
      </div>
      <fieldset disabled={locked}>
        <legend>Przygotuj nowy szablon Zombie</legend>
        <label>
          <span>Nosiciel — człowiek lub mutant</span>
          <select
            aria-label="Nosiciel Zombie"
            value={hostId}
            onChange={(e) => {
              setHostId(e.target.value);
              setSelected([]);
              setError('');
            }}
          >
            <option value="">Wybierz nosiciela</option>
            {hosts.map((e) => (
              <option key={e.template.id} value={e.template.id}>
                {e.template.name}
              </option>
            ))}
          </select>
        </label>
        {!hosts.length && (
          <p>Najpierw utwórz w Bestiariuszu szablon człowieka lub mutanta.</p>
        )}
        {host && (
          <>
            <p>
              Zachowaj tylko zdolności będące atakami wręcz nosiciela. Profile
              broni wręcz zostaną przeniesione; opisowe ataki bez profilu trzeba
              sprawdzić w formularzu. Ataki dystansowe pomiń.
            </p>
            {host.capabilities?.abilities.map((a) => (
              <label key={a.id} className="target-slot">
                <input
                  type="checkbox"
                  checked={selected.includes(a.id)}
                  onChange={(e) =>
                    setSelected(
                      e.target.checked
                        ? [...selected, a.id]
                        : selected.filter((id) => id !== a.id),
                    )
                  }
                />
                <span>
                  {a.name}: {presentRule(a.description)}
                </span>
              </label>
            ))}
            <button
              className="secondary-button"
              onClick={() => {
                try {
                  onPrepare(prepareDeathBreath(host, selected));
                } catch (e) {
                  setError(String(e));
                }
              }}
            >
              Przygotuj formularz Zombie
            </button>
            <p>
              Sprawdź formularz i zatwierdź nowy szablon. Nosiciel i postacie w
              potyczkach pozostaną bez zmian.
            </p>
          </>
        )}
        {error && (
          <p role="alert" className="editor-error">
            {error}
          </p>
        )}
      </fieldset>
    </section>
  );
}
