import { displaySpeeds } from '../../domain/presentation';
import { CapabilitySummary } from '../statblocks/CapabilitySummary';
import { DeathBreathPanel } from './DeathBreathPanel';
import { deathBreath } from '../../domain/deathBreath';
import { StatblockSummary } from '../statblocks/StatblockSummary';
import { AttackProfiles } from '../equipment/AttackProfiles';
import { useEffect, useState } from 'react';
import { useBestiaryStore } from '../../stores/bestiaryStore';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { filterCatalog } from '../../domain/bestiary';
import { categoryOptions, categoryLabels } from '../../domain/enemy';
import { parseCombatDraft } from '../../domain/combat';
import { SLOT_IDS } from '../../domain/encounter';
import type { SlotId } from '../../domain/encounterDetails';
import { TemplateFields } from './TemplateFields';
export function BestiaryWorkspace() {
  const state = useBestiaryStore();
  const combat = useCombatStore();
  const encounters = useEncounterStore();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const [size, setSize] = useState('');
  const [selected, setSelected] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [slot, setSlot] = useState<SlotId>(encounters.activeId);
  const [count, setCount] = useState('1');
  const [notice, setNotice] = useState('');
  useEffect(() => {
    void useBestiaryStore.getState().load();
  }, []);
  const overlayVisible =
    (!category || category === 'monster') &&
    (!size || size === 'Średni') &&
    query
      .toLocaleLowerCase('pl')
      .trim()
      .split(/\s+/)
      .every((w) =>
        [deathBreath.name, ...deathBreath.rules]
          .join(' ')
          .toLocaleLowerCase('pl')
          .includes(w),
      );
  const entries = filterCatalog(state.entries, query, category, size);
  const entry = state.entries.find((e) => e.template.id === selected);
  const t = entry?.template;
  const disabled =
    state.busy || state.loading || combat.closing || encounters.closing;
  const locked = disabled || !!state.form || !!state.pending;
  const n = /^\d+$/.test(count.trim()) ? Number(count) : NaN;
  let validSlot = false;
  try {
    parseCombatDraft(
      combat.drafts[slot]!.value,
      combat.slots.find((s) => s.encounterId === slot)!,
    );
    validSlot = true;
  } catch {
    /* Preserve incomplete combat input. */
  }
  return (
    <div className="bestiary-workspace">
      <p className="editor-hint">
        Szablon jest wzorcem nowych kopii. Jego edycja lub usunięcie z katalogu
        nie zmienia postaci w potyczkach.
      </p>
      <div className="actor-actions">
        <button
          className="secondary-button"
          disabled={locked}
          onClick={() => {
            setDeleting(false);
            state.open();
          }}
        >
          Nowy szablon
        </button>
        <button
          className="secondary-button"
          disabled={disabled}
          onClick={() => {
            void state.load();
          }}
        >
          Odśwież katalog
        </button>
      </div>
      {state.loading && <p role="status">Odczytywanie katalogu…</p>}
      {state.error && (!state.form || !!state.pending) && (
        <p className="editor-error" role="alert">
          {state.error}
        </p>
      )}
      {state.pending && (
        <div className="actor-actions">
          <button
            className="secondary-button"
            disabled={disabled}
            onClick={() => {
              void state.retry();
            }}
          >
            Ponów zapis zmiany
          </button>
          <button
            className="secondary-button"
            disabled={disabled}
            onClick={state.cancel}
          >
            Odrzuć niezapisaną zmianę
          </button>
        </div>
      )}
      {state.form && (
        <form
          className="enemy-form"
          aria-label="Szablon Bestiariusza"
          onSubmit={(e) => {
            e.preventDefault();
            void state.submit();
          }}
        >
          <fieldset disabled={disabled || !!state.pending}>
            <legend>
              {state.form.expectedRevision === null
                ? 'Nowy szablon'
                : 'Edytuj szablon'}
            </legend>
            <TemplateFields
              value={state.form.fields}
              onChange={state.edit}
              error={state.pending ? null : state.error}
            />
            <div className="actor-actions">
              <button type="submit" className="secondary-button">
                Zatwierdź szablon
              </button>
              <button
                type="button"
                className="secondary-button"
                onClick={state.cancel}
              >
                Anuluj formularz
              </button>
            </div>
          </fieldset>
        </form>
      )}
      <div className="enemy-fields bestiary-filters">
        <label>
          <span>Szukaj nazwy lub zdolności</span>
          <input
            aria-label="Szukaj w Bestiariuszu"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <label>
          <span>Kategoria</span>
          <select
            aria-label="Filtr kategorii"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">Wszystkie kategorie</option>
            {categoryOptions(state.entries.map((e) => e.template.category)).map(
              ([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ),
            )}
          </select>
        </label>
        <label>
          <span>Rozmiar</span>
          <select
            aria-label="Filtr rozmiaru"
            value={size}
            onChange={(e) => setSize(e.target.value)}
          >
            <option value="">Wszystkie rozmiary</option>
            {[...new Set(state.entries.map((e) => e.template.size))]
              .sort((a, b) => a.localeCompare(b, 'pl'))
              .map((s) => (
                <option key={s}>{s}</option>
              ))}
          </select>
        </label>
      </div>
      <p role="status">
        Wyniki: {entries.length + Number(overlayVisible)} /{' '}
        {state.entries.length + 1}
      </p>
      {!entries.length && !overlayVisible && !state.loading && (
        <p>
          {state.entries.length
            ? 'Brak pasujących szablonów. Zmień wyszukiwanie lub filtry.'
            : 'Katalog jest pusty. Utwórz pierwszy szablon.'}
        </p>
      )}
      <div className="bestiary-layout">
        <ul className="bestiary-list" aria-label="Szablony przeciwników">
          {overlayVisible && (
            <li>
              <button
                className="secondary-button"
                aria-pressed={selected === 'death-breath'}
                onClick={() => {
                  setSelected('death-breath');
                  setDeleting(false);
                  setNotice('');
                }}
              >
                <strong>{deathBreath.name}</strong>
                <span>Potwory · Średni · wartości nosiciela</span>
              </button>
            </li>
          )}
          {entries.map((e) => (
            <li key={e.template.id}>
              <button
                className="secondary-button"
                aria-pressed={selected === e.template.id}
                onClick={() => {
                  setSelected(e.template.id);
                  setDeleting(false);
                  setNotice('');
                }}
              >
                <strong>{e.template.name}</strong>
                <span>
                  {categoryLabels[e.template.category]} · {e.template.size} · TT{' '}
                  {e.template.tt} · PW {e.template.hpMax}
                </span>
              </button>
            </li>
          ))}
        </ul>
        {selected === 'death-breath' && (
          <DeathBreathPanel
            entries={state.entries}
            locked={locked}
            onPrepare={(draft) => {
              state.open();
              state.edit(draft);
              setSelected(null);
              window.requestAnimationFrame(() =>
                document
                  .querySelector<HTMLInputElement>(
                    '[aria-label="Nazwa szablonu"]',
                  )
                  ?.focus(),
              );
            }}
          />
        )}
        {entry && t && (
          <section
            key={t.id}
            className="bestiary-detail"
            aria-label="Podgląd szablonu"
          >
            <header className="statblock-heading">
              <p className="statblock-kind">
                {categoryLabels[t.category]} · {t.size}
              </p>
              <h3>{t.name}</h3>
              <dl className="statblock-vitals">
                <div>
                  <dt>TT</dt>
                  <dd>{t.tt}</dd>
                </div>
                <div>
                  <dt>PW</dt>
                  <dd>{t.hpMax}</dd>
                </div>
                <div>
                  <dt>SP</dt>
                  <dd>{t.sp ?? 'N/D'}</dd>
                </div>
                {t.category === 'machine' && (
                  <div>
                    <dt>Próg Awarii</dt>
                    <dd>{t.failureThreshold ?? 'N/D'}</dd>
                  </div>
                )}
              </dl>
              <p className="bestiary-text">
                <strong>Ruch</strong> · {displaySpeeds(t.speeds) || 'N/D'}
              </p>
              <p className="statblock-minor">
                Zranienia: {t.injuryTrack?.enabled ? 'możliwe' : 'wyłączone'} ·
                Tchórzliwość:{' '}
                {t.cowardicePercent == null ? 'N/D' : `${t.cowardicePercent}%`}
              </p>
            </header>
            <StatblockSummary value={t.statblock} tt={t.tt} />
            {t.capabilities && <CapabilitySummary value={t.capabilities} />}
            {t.loadout && (
              <details className="statblock-section">
                <summary>
                  Broń i warianty <span>{t.loadout.items.length}</span>
                </summary>
                <AttackProfiles loadout={t.loadout} />
              </details>
            )}
            <div className="actor-actions">
              <button
                className="secondary-button"
                disabled={locked}
                onClick={() => {
                  setDeleting(false);
                  state.open(entry);
                }}
              >
                Edytuj
              </button>
              <button
                className="secondary-button"
                disabled={locked}
                onClick={() => {
                  setDeleting(false);
                  state.open(entry, true);
                }}
              >
                Duplikuj
              </button>
              <button
                className="secondary-button"
                disabled={locked}
                onClick={() => setDeleting(true)}
              >
                Usuń z Bestiariusza
              </button>
            </div>
            {deleting && (
              <div
                className="error-panel"
                role="group"
                aria-label="Potwierdzenie usunięcia szablonu"
              >
                <p>
                  Usunąć „{t.name}” z katalogu? Istniejące postacie i ich stan
                  przygotowany pozostaną.
                </p>
                <button
                  className="secondary-button"
                  disabled={locked}
                  onClick={() => {
                    void state.remove(entry).then(() => setDeleting(false));
                  }}
                >
                  Potwierdź usunięcie szablonu
                </button>
                <button
                  className="secondary-button"
                  disabled={disabled}
                  onClick={() => setDeleting(false)}
                >
                  Zachowaj szablon
                </button>
              </div>
            )}
            <fieldset disabled={locked || deleting}>
              <legend>Dodaj kopie do potyczki</legend>
              <div className="enemy-fields">
                <fieldset className="target-slots">
                  <legend>Docelowa potyczka</legend>
                  {SLOT_IDS.map((id) => (
                    <label key={id} className="target-slot">
                      <input
                        type="radio"
                        name="bestiary-target-slot"
                        value={id}
                        checked={slot === id}
                        onChange={() => {
                          setSlot(id);
                          setNotice('');
                        }}
                      />
                      <span>
                        Slot {id} —{' '}
                        {encounters.drafts[id]?.details.name ||
                          `Potyczka ${id}`}
                      </span>
                    </label>
                  ))}
                </fieldset>
                <label>
                  <span>Liczba kopii (1–100)</span>
                  <input
                    aria-label="Liczba kopii"
                    inputMode="numeric"
                    value={count}
                    onChange={(e) => {
                      setCount(e.target.value);
                      setNotice('');
                    }}
                  />
                </label>
              </div>
              <button
                className="secondary-button"
                disabled={
                  !validSlot || !Number.isInteger(n) || n < 1 || n > 100
                }
                onClick={() => {
                  const ok = combat.addEnemies(slot, t, n);
                  setNotice(
                    ok
                      ? `Dodano ${n} kopii do slotu ${slot}.`
                      : 'Popraw dane docelowej potyczki przed dodaniem kopii.',
                  );
                }}
              >
                Dodaj ×{Number.isInteger(n) ? n : 'N'}
              </button>
              {!validSlot && (
                <p className="editor-error">
                  Popraw niedokończone dane w slocie {slot} przed dodaniem
                  kopii.
                </p>
              )}
            </fieldset>
            {notice && (
              <p role="status">
                {notice}{' '}
                {combat.drafts[slot]?.status === 'saved'
                  ? 'Zapisano.'
                  : combat.drafts[slot]?.status === 'error'
                    ? 'Błąd zapisu — przejdź do potyczki i ponów zapis.'
                    : 'Trwa autozapis.'}
              </p>
            )}
            <button
              className="secondary-button"
              disabled={disabled}
              onClick={() => {
                encounters.selectSlot(slot);
                state.setView('combat');
              }}
            >
              Przejdź do slotu {slot}
            </button>
          </section>
        )}
      </div>
    </div>
  );
}
