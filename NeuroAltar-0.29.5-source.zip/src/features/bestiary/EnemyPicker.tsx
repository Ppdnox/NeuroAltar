import { useEffect, useRef, useState } from 'react';
import { Search, Plus } from 'lucide-react';
import { useBestiaryStore } from '../../stores/bestiaryStore';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { filterCatalog } from '../../domain/bestiary';
import { categoryLabels, categoryOptions } from '../../domain/enemy';
import type { SlotId } from '../../domain/encounterDetails';
import './enemyPicker.css';
export function EnemyPicker({
  slotId,
  onClose,
}: {
  slotId: SlotId;
  onClose(): void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const state = useBestiaryStore();
  const combat = useCombatStore();
  const encounters = useEncounterStore();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const [notice, setNotice] = useState('');
  useEffect(() => {
    dialog.current?.showModal();
    dialog.current?.querySelector<HTMLInputElement>('input')?.focus();
    void useBestiaryStore.getState().load();
    const node = dialog.current;
    return () => node?.close();
  }, []);
  const entries = filterCatalog(state.entries, query, category, '');
  const locked =
    combat.closing ||
    encounters.closing ||
    state.loading ||
    state.busy ||
    !!state.pending;
  return (
    <dialog
      ref={dialog}
      className="enemy-picker"
      aria-labelledby="enemy-picker-title"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <header>
        <div>
          <h2 id="enemy-picker-title">Dodaj przeciwnika</h2>
          <p>
            Potyczka {slotId} — {encounters.drafts[slotId]?.details.name}
          </p>
        </div>
        <button type="button" className="secondary-button" onClick={onClose}>
          Zamknij wyszukiwarkę
        </button>
      </header>
      <label className="field-label">
        <span>
          <Search size={16} aria-hidden="true" /> Szukaj w Bestiariuszu
        </span>
        <input
          autoComplete="off"
          spellCheck={false}
          autoFocus
          aria-label="Szukaj przeciwnika w Bestiariuszu"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Wpisz nazwę, np. Gangus"
        />
      </label>
      <label className="field-label">
        <span>Kategoria</span>
        <select
          aria-label="Kategoria przeciwnika"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">Wszystkie kategorie</option>
          {categoryOptions(state.entries.map((e) => e.template.category)).map(
            ([id, label]) => (
              <option key={id} value={id}>
                {label}
              </option>
            ),
          )}
        </select>
      </label>
      {state.loading && <p role="status">Odczytywanie Bestiariusza…</p>}
      {state.error && (
        <div role="alert">
          <p>{state.error}</p>
          <button
            className="secondary-button"
            disabled={state.loading}
            onClick={() => {
              void state.load();
            }}
          >
            Ponów odczyt Bestiariusza
          </button>
        </div>
      )}
      <p role="status">{notice || `Znaleziono: ${entries.length}`}</p>
      <ul className="enemy-picker-results">
        {entries.map(({ template: t }) => (
          <li key={t.id}>
            <div>
              <strong>{t.name}</strong>
              <span>
                {categoryLabels[t.category]} · {t.size} · TT {t.tt} · PW{' '}
                {t.hpMax} · SP {t.sp ?? 'N/D'}
              </span>
            </div>
            <button
              type="button"
              className="secondary-button"
              disabled={locked}
              aria-label={`Dodaj: ${t.name}`}
              onClick={() => {
                if (useCombatStore.getState().addEnemies(slotId, t, 1))
                  onClose();
                else
                  setNotice('Popraw dane potyczki przed dodaniem przeciwnika.');
              }}
            >
              <Plus size={16} aria-hidden="true" /> Dodaj
            </button>
          </li>
        ))}
      </ul>
      {!state.loading && !state.error && !entries.length && (
        <p>Brak pasujących przeciwników. Zmień nazwę lub kategorię.</p>
      )}
    </dialog>
  );
}
