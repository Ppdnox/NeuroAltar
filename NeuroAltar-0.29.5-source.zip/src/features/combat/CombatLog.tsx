import { RollLogMessage } from '../dice/RollLogMessage';
import { useEffect, useState } from 'react';
import { useCombatLogStore } from '../../stores/combatLogStore';
import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';
const time = new Intl.DateTimeFormat('pl-PL', {
  dateStyle: 'short',
  timeStyle: 'medium',
});
export function CombatLog({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const state = useCombatLogStore();
  const combat = useCombatStore();
  const revision = combat.slots.find(
    (slot) => slot.encounterId === slotId,
  )?.revision;
  const [confirm, setConfirm] = useState(false);
  const refresh = state.refresh;
  useEffect(() => {
    if (revision !== undefined) void refresh(slotId);
  }, [slotId, revision, refresh]);
  const log = state.slots[slotId];
  const canClear =
    !disabled &&
    log?.status === 'ready' &&
    log.entries.length > 0 &&
    combat.drafts[slotId]?.status === 'saved';
  return (
    <details
      className="combat-log"
      open={log?.status === 'error' ? true : undefined}
    >
      <summary>
        Log walki{' '}
        <span>
          {log?.status === 'error' ? (
            'Błąd odczytu'
          ) : log?.entries[0] ? (
            <RollLogMessage entry={log.entries[0]} />
          ) : (
            'Brak wpisów'
          )}
        </span>
      </summary>
      <section aria-label="Log walki">
        <div className="actor-list-heading">
          <h2>Log walki</h2>
          <button
            className="secondary-button"
            type="button"
            disabled={!canClear}
            onClick={() => setConfirm(true)}
          >
            Wyczyść log
          </button>
        </div>
        <p className="editor-hint">
          Historia tej potyczki, od najnowszych wpisów. Obejmuje zmiany zapisane
          od wersji 0.5.0.
        </p>
        {confirm && (
          <div className="remove-confirm" role="alert">
            <p>
              Usunąć całą historię logu tej potyczki? PW, statusy, skład i stan
              przygotowany pozostaną. Tej operacji nie można cofnąć.
            </p>
            <button
              className="remove-actor"
              type="button"
              disabled={!canClear}
              onClick={() => {
                combat.clearLog(slotId);
                setConfirm(false);
              }}
            >
              Potwierdź wyczyszczenie logu
            </button>
            <button
              className="secondary-button"
              type="button"
              onClick={() => setConfirm(false)}
            >
              Anuluj
            </button>
          </div>
        )}
        {(!log || log.status === 'loading') && (
          <p role="status" className="editor-hint">
            Odczytywanie logu…
          </p>
        )}
        {log?.status === 'error' && (
          <div className="editor-error" role="alert">
            <p>
              Nie udało się odświeżyć logu: {log.error} Wyświetlana historia
              może być nieaktualna.
            </p>
            <button
              className="retry-button"
              type="button"
              onClick={() => {
                void refresh(slotId);
              }}
            >
              Ponów odczyt logu
            </button>
          </div>
        )}
        {log?.status === 'ready' && !log.entries.length && (
          <p className="empty-log">
            Brak wpisów. Kolejne zapisane zmiany pojawią się tutaj.
          </p>
        )}
        <ol className="combat-log-list" aria-label="Wpisy logu">
          {log?.entries.map((entry) => (
            <li key={entry.id}>
              <div className="log-entry-meta">
                <strong>Runda {entry.roundNumber}</strong>
                <time dateTime={entry.createdAt}>
                  {time.format(new Date(entry.createdAt))}
                </time>
              </div>
              <p>
                <RollLogMessage entry={entry} />
              </p>
            </li>
          ))}
        </ol>
        {log?.hasMore && (
          <button
            className="secondary-button"
            type="button"
            disabled={log.status !== 'ready'}
            onClick={() => {
              void state.older(slotId);
            }}
          >
            Pokaż starsze wpisy
          </button>
        )}
      </section>
    </details>
  );
}
