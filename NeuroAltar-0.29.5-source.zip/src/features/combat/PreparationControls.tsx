import { useState } from 'react';
import type { SlotId } from '../../domain/encounterDetails';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import { useEncounterMaintenanceStore } from '../../stores/encounterMaintenanceStore';

export function PreparationControls({
  slotId,
  disabled,
  canReset,
}: {
  slotId: SlotId;
  disabled: boolean;
  canReset: boolean;
}) {
  const state = useCombatStore();
  const details = useEncounterStore();
  const maintenance = useEncounterMaintenanceStore();
  const [confirm, setConfirm] = useState<{
    kind: 'prepare' | 'reset' | 'clear';
    token: string;
  } | null>(null);
  const token = JSON.stringify([
    slotId,
    state.drafts[slotId]?.value,
    details.drafts[slotId]?.details,
    state.slots.find((s) => s.encounterId === slotId)?.revision,
  ]);
  const stale = confirm?.token !== token;
  const canClear =
    !state.closing &&
    !details.closing &&
    state.status === 'ready' &&
    details.status === 'ready' &&
    !state.enemyForm &&
    !state.statusForm &&
    !state.capabilityForm &&
    !state.statblockForm &&
    !state.loadoutForm &&
    !state.failureForm &&
    !['invalid', 'error'].includes(state.drafts[slotId]?.status ?? 'invalid') &&
    !['invalid', 'error'].includes(details.drafts[slotId]?.status ?? 'invalid');
  const name = details.drafts[slotId]?.details.name;
  const count = state.drafts[slotId]?.value.actors.length ?? 0;
  return (
    <div className="preparation-controls">
      <div className="actor-actions">
        <button
          className="secondary-button"
          type="button"
          disabled={disabled}
          onClick={() => setConfirm({ kind: 'prepare', token })}
        >
          Zapisz stan przygotowany
        </button>
        <button
          className="secondary-button"
          type="button"
          disabled={disabled || !canReset}
          onClick={() => setConfirm({ kind: 'reset', token })}
        >
          Reset potyczki
        </button>
        <button
          className="remove-actor"
          type="button"
          disabled={!canClear}
          onClick={() => setConfirm({ kind: 'clear', token })}
        >
          Wyczyść potyczkę
        </button>
      </div>
      <p className="editor-hint">
        Stan przygotowany: punkt powrotu dla obecnych postaci. Reset go
        odtwarza; czyszczenie usuwa postacie wraz z ich punktami powrotu.
      </p>
      {confirm && (
        <div className="remove-confirm" role="alert">
          <p>
            <strong>
              Slot {slotId}: „{name}” — liczba postaci: {count}.
            </strong>
          </p>
          <p>
            {confirm.kind === 'clear'
              ? 'Usunąć cały skład, stany przygotowane i bieżące, statusy, cały log oraz notatki tej potyczki? Runda wróci do 1, bieżąca tura zostanie wyłączona. Nazwa slotu, lista poziomów BG, Bestiariusz i pozostałe sloty pozostaną. Tej operacji nie można cofnąć resetem.'
              : confirm.kind === 'prepare'
                ? 'Zastąpić punkt powrotu aktualnymi nazwami, PW, TT, SP, inicjatywami, statusami i ich czasem, ruchem, Zranieniami, Tchórzliwością, zasobami, akcjami, bronią i awariami wszystkich obecnych postaci? Poprzedni punkt powrotu zostanie zastąpiony.'
                : 'Przywrócić dokładnie zapisane nazwy, PW, TT, SP, inicjatywy, statusy i ich czas, ruch, Zranienia, Tchórzliwość, zasoby, akcje, broń i awarie obecnych postaci? Runda wróci do 1, bieżąca tura zostanie wyłączona. Skład, nazwa, poziomy BG, notatki i log pozostaną. Usunięte postacie nie wrócą.'}
          </p>
          {stale && (
            <p>
              Dane zmieniły się od wyświetlenia potwierdzenia. Anuluj i ponownie
              wybierz operację.
            </p>
          )}
          <button
            className="secondary-button"
            type="button"
            onClick={() => setConfirm(null)}
          >
            Anuluj
          </button>
          <button
            className={
              confirm.kind === 'clear' ? 'remove-actor' : 'secondary-button'
            }
            type="button"
            disabled={
              stale ||
              (confirm.kind === 'clear'
                ? !canClear
                : disabled || (confirm.kind === 'reset' && !canReset))
            }
            onClick={() => {
              if (stale) return;
              if (confirm.kind === 'clear') void maintenance.clear(slotId);
              else if (confirm.kind === 'prepare')
                state.prepareEncounter(slotId);
              else state.resetEncounter(slotId);
              setConfirm(null);
            }}
          >
            {confirm.kind === 'clear'
              ? 'Potwierdź wyczyszczenie potyczki'
              : confirm.kind === 'prepare'
                ? 'Potwierdź zapis stanu'
                : 'Potwierdź reset'}
          </button>
        </div>
      )}
      {maintenance.slotId === slotId && (
        <div className="editor-error" role="status">
          {maintenance.busy ? (
            <p>Zapisywanie i czyszczenie slotu {slotId}…</p>
          ) : (
            <>
              <p>{maintenance.error}</p>
              <p>
                Edycja jest wstrzymana do ustalenia wyniku. Ponów tę samą
                operację albo odczytaj zapisany stan slotu.
              </p>
              <button
                type="button"
                className="secondary-button"
                onClick={() => {
                  void maintenance.retry();
                }}
              >
                Ponów czyszczenie
              </button>
              <button
                type="button"
                className="secondary-button"
                onClick={() => {
                  void maintenance.reload();
                }}
              >
                Odczytaj stan slotu
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
