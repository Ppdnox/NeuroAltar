import { NpcAbilityEffects } from '../character/NpcAbilityEffects';
import { useParticipationStore } from '../../stores/participationStore';
import { useCharacterStore } from '../../stores/characterStore';
import { characterCombatValues } from '../../domain/character/participation';
import {
  LinkedCharacter,
  LinkCharacter,
  ParticipationStatus,
} from '../character/ParticipationPanel';
import { EnemyPicker } from '../bestiary/EnemyPicker';
import { StatblockPanel, StatblockForm } from '../statblocks/StatblockPanel';
import { StatblockSummary } from '../statblocks/StatblockSummary';
import { combatWorkspaceActive } from '../../services/workspaceShortcuts';
import { flushSync } from 'react-dom';
import { adjacentCard, combatShortcut } from '../../domain/shortcuts';
import { draftMachineTT } from '../../domain/machineFailureView';
import { FailurePanel, FailureSummary } from '../machine-failures/FailurePanel';
import { effectiveMachineTT } from '../../domain/machineFailures';
import { LoadoutForm } from '../equipment/LoadoutPanel';
import { AttackProfiles } from '../equipment/AttackProfiles';
import { CapabilityPanel } from '../resources/CapabilityPanel';
import { CapabilityForm } from '../resources/CapabilityForm';
import { ResourceRefresh } from '../resources/ResourceRefresh';
import { InjuryPanel, InjuryBadges } from '../injuries/InjuryPanel';
import { StatusPanel } from '../statuses/StatusPanel';
import { statusDuration } from '../../domain/status';
import { CombatLog } from './CombatLog';
import { EnemyForm } from './EnemyForm';
import { PreparationControls } from './PreparationControls';
import {
  displaySpeeds,
  displaySpeedDraft,
  speedDraftLabel,
  fixedHandbookSp,
} from '../../domain/presentation';
import { categoryLabels } from '../../domain/enemy';
import { combatSaveLabels } from './saveLabels';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, ChevronRight, Plus, Trash2 } from 'lucide-react';
import { useCombatStore } from '../../stores/combatStore';
import { useEncounterStore } from '../../stores/encounterStore';
import {
  parseCombatDraft,
  parseActorDraft,
  type ActorDraft,
} from '../../domain/combat';
import { initiativeOrder } from '../../domain/initiative';
import type { SlotId } from '../../domain/encounterDetails';

function revealActorCard() {
  const card = document.getElementById('actor-card');
  card?.focus({ preventScroll: true });
  card?.scrollIntoView({ block: 'start' });
}

export function CombatWorkspace({ slotId }: { slotId: SlotId }) {
  const state = useCombatStore();
  const participation = useParticipationStore();
  const characters = useCharacterStore();
  useEffect(() => {
    void useParticipationStore.getState().load();
    void useCharacterStore.getState().initialize();
  }, []);
  useEffect(() => {
    const refresh = () => {
      void useParticipationStore.getState().load();
    };
    window.addEventListener('character-combat-saved', refresh);
    return () => window.removeEventListener('character-combat-saved', refresh);
  }, []);
  const [picker, setPicker] = useState(false);
  const pickerTrigger = useRef<HTMLButtonElement>(null);
  const detailsClosing = useEncounterStore((s) => s.closing);
  const draft = state.drafts[slotId];
  const disabled =
    detailsClosing ||
    state.closing ||
    participation.busy ||
    !!participation.pending;
  let valid = false;
  if (draft) {
    try {
      parseCombatDraft(
        draft.value,
        state.slots.find((s) => s.encounterId === slotId)!,
      );
      valid = true;
    } catch {
      /* Inputs remain editable. */
    }
  }
  const actors = (draft?.value.actors ?? []).map((a) => {
    const link = participation.entries.find((p) => p.actorId === a.id),
      record = characters.records.find((c) => c.id === link?.characterId),
      v = record ? characterCombatValues(record, link) : null;
    return v
      ? {
          ...a,
          displayName: v.name,
          hpCurrent: String(v.hp),
          hpMaxCurrent: String(v.hpMax),
          ttCurrent: String(v.tt),
        }
      : a;
  });
  const queue = initiativeOrder(
    actors.map((pc) => ({
      ...pc,
      initiativeValue: /^-?\d+$/.test(pc.initiativeValue.trim())
        ? Number(pc.initiativeValue)
        : null,
    })),
  );
  const hasForm = Boolean(
    state.enemyForm ||
    state.statusForm ||
    state.capabilityForm ||
    state.failureForm ||
    state.statblockForm ||
    state.loadoutForm,
  );
  const canAdvance =
    valid &&
    queue.length > 0 &&
    !disabled &&
    !state.enemyForm &&
    !state.statusForm &&
    !state.failureForm &&
    !state.statblockForm &&
    !state.loadoutForm &&
    !state.capabilityForm;
  const nextTurn = state.nextTurn;
  useEffect(() => {
    const navigationIds = [
      ...queue.map((pc) => pc.id),
      ...(state.drafts[slotId]?.value.actors ?? [])
        .filter((pc) => !queue.some((entry) => entry.id === pc.id))
        .map((pc) => pc.id),
    ];
    const onKey = (event: KeyboardEvent) => {
      if (!combatWorkspaceActive()) return;
      const target = event.target instanceof HTMLElement ? event.target : null;
      const intent = combatShortcut(event, {
        editing: Boolean(
          target?.closest(
            'input, textarea, select, [contenteditable]:not([contenteditable="false"])',
          ),
        ),
        interactive: Boolean(
          target?.closest('button, a, summary, [role="button"]'),
        ),
        dialog: Boolean(document.querySelector('dialog[open]')),
      });
      if (intent === 'next-turn' && canAdvance) {
        event.preventDefault();
        nextTurn(slotId);
      } else if (
        (intent === 'previous-card' || intent === 'next-card') &&
        !disabled &&
        !hasForm
      ) {
        const id = adjacentCard(
          navigationIds,
          state.selected[slotId] ?? navigationIds[0],
          intent === 'previous-card' ? -1 : 1,
        );
        if (id) {
          event.preventDefault();
          flushSync(() => state.selectActor(slotId, id));
          revealActorCard();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [slotId, canAdvance, nextTurn, disabled, hasForm, queue, state]);
  if (state.status === 'error')
    return (
      <div className="editor-error" role="alert">
        <p>Nie można odczytać postaci: {state.error}</p>
        <button
          type="button"
          className="retry-button"
          onClick={() => {
            void state.initialize();
          }}
        >
          Ponów odczyt postaci
        </button>
      </div>
    );
  if (!draft) return <p role="status">Odczytywanie postaci…</p>;
  const selected =
    actors.find((pc) => pc.id === state.selected[slotId]) ?? actors[0];
  const active = actors.find((pc) => pc.id === draft.value.currentTurnActorId);
  const displayOrder = [
    ...queue.map((pc) => pc.id),
    ...actors
      .filter((pc) => !queue.some((entry) => entry.id === pc.id))
      .map((pc) => pc.id),
  ];
  return (
    <section className="combat-workspace" aria-label="Postacie i inicjatywa">
      <ParticipationStatus />
      <div className="turn-toolbar" aria-label="Prowadzenie tury">
        <div>
          <span className="section-note">RUNDA</span>
          <strong className="round-number">{draft.value.roundNumber}</strong>
        </div>
        <div className="current-turn" aria-live="polite">
          <span className="section-note">AKTUALNA TURA</span>
          <strong>{active?.displayName || 'Jeszcze nie rozpoczęto'}</strong>
        </div>
        {active && (
          <button
            className="current-actor-link"
            type="button"
            disabled={disabled || hasForm}
            onClick={() => {
              flushSync(() => state.selectActor(slotId, active.id));
              revealActorCard();
            }}
          >
            Pokaż bieżącą postać
          </button>
        )}
        <button
          className="next-turn"
          type="button"
          disabled={!canAdvance}
          onClick={() => state.nextTurn(slotId)}
        >
          <span>{active ? 'NASTĘPNA TURA' : 'ROZPOCZNIJ TURĘ'}</span>
          <ChevronRight size={21} aria-hidden="true" />
        </button>
      </div>
      <div className="combat-save-line">
        <span className={`save-state save-${draft.status}`} role="status">
          {combatSaveLabels[draft.status]}
        </span>
        <span className="editor-hint">
          Spacja: następna tura · ⌥/Alt + ↑/↓: wybór karty · F1: pomoc.
        </span>
      </div>
      {draft.error && (
        <div className="editor-error" role="alert">
          <p>{draft.error}</p>
          {draft.status === 'error' && (
            <button
              className="retry-button"
              type="button"
              disabled={
                disabled ||
                state.statusForm !== null ||
                state.capabilityForm !== null ||
                state.failureForm !== null ||
                state.statblockForm !== null ||
                state.loadoutForm !== null
              }
              onClick={() => {
                void state.flush(slotId);
              }}
            >
              Ponów zapis postaci
            </button>
          )}
        </div>
      )}
      <div className="enemy-toolbar">
        <button
          className="secondary-button"
          type="button"
          disabled={
            disabled ||
            !valid ||
            state.enemyForm !== null ||
            state.statusForm !== null ||
            state.capabilityForm !== null ||
            state.failureForm !== null ||
            state.statblockForm !== null ||
            state.loadoutForm !== null
          }
          ref={pickerTrigger}
          aria-haspopup="dialog"
          onClick={() => setPicker(true)}
        >
          <Plus size={16} aria-hidden="true" />
          Dodaj przeciwnika
        </button>
        <button
          className="secondary-button"
          type="button"
          disabled={disabled || !valid || hasForm}
          onClick={() => state.openEnemyForm(slotId)}
        >
          Dodaj własnego
        </button>
        {picker && (
          <EnemyPicker
            slotId={slotId}
            onClose={() => {
              flushSync(() => setPicker(false));
              pickerTrigger.current?.focus();
            }}
          />
        )}
        {state.enemyForm && state.enemyForm.slotId !== slotId && (
          <span className="editor-hint">
            Formularz przeciwnika czeka w slocie {state.enemyForm.slotId}.
          </span>
        )}
      </div>
      {active?.effects?.some((s) => s.systemKey === 'burning') && (
        <p className="burning-reminder" role="status">
          ⚄ Podpalenie — {active.displayName}: początek tury, 1k4 obrażeń od
          ognia. MG wpisuje wynik po rozstrzygnięciu.
        </p>
      )}
      <CapabilityForm slotId={slotId} disabled={disabled} />
      {state.capabilityForm && state.capabilityForm.slotId !== slotId && (
        <p className="editor-hint">
          Edycja zasobów czeka w slocie {state.capabilityForm.slotId}.
        </p>
      )}
      <StatblockForm slotId={slotId} disabled={disabled} />
      <LoadoutForm slotId={slotId} disabled={disabled} />
      <EnemyForm
        slotId={slotId}
        disabled={
          disabled ||
          state.statusForm !== null ||
          state.capabilityForm !== null ||
          state.failureForm !== null ||
          state.statblockForm !== null ||
          state.loadoutForm !== null
        }
      />
      <div className="combat-layout">
        <div className="initiative-column">
          <section className="initiative-panel" aria-label="Kolejka inicjatywy">
            <div className="actor-list-heading">
              <h2>Inicjatywa</h2>
              <button
                className="secondary-button"
                type="button"
                disabled={
                  disabled ||
                  state.statusForm !== null ||
                  state.capabilityForm !== null ||
                  state.failureForm !== null ||
                  state.statblockForm !== null ||
                  state.loadoutForm !== null
                }
                onClick={() => state.addActor(slotId)}
              >
                <Plus size={16} aria-hidden="true" />
                Dodaj BG
              </button>
            </div>
            {!actors.length && (
              <div className="empty-combat">
                <p>Potyczka czeka na postacie.</p>
                <p>Dodaj BG lub przeciwnika i wpisz wyniki inicjatywy.</p>
              </div>
            )}
            <ol className="initiative-list">
              {displayOrder.map((id) => {
                const pc = actors.find((p) => p.id === id)!;
                const index = queue.findIndex((p) => p.id === id);
                const inQueue = queue[index];
                const tied =
                  inQueue !== undefined &&
                  queue.some(
                    (p) =>
                      p.id !== id &&
                      p.initiativeValue === inQueue.initiativeValue,
                  );
                return (
                  <li
                    key={pc.id}
                    className={`initiative-row ${active?.id === pc.id ? 'is-current' : ''}`}
                  >
                    <button
                      type="button"
                      className="actor-select"
                      disabled={disabled}
                      aria-pressed={selected?.id === pc.id}
                      onClick={() => state.selectActor(slotId, pc.id)}
                    >
                      <span className="initiative-score">
                        {inQueue ? pc.initiativeValue : '—'}
                      </span>
                      <span className="actor-list-copy">
                        <strong>
                          {pc.displayName.trim() || 'Bez imienia'}
                        </strong>
                        <span>
                          {pc.enemy ? 'WRÓG' : 'BG'} · PW {pc.hpCurrent || '—'}/
                          {pc.hpMaxCurrent || '—'} · TT {draftMachineTT(pc)}
                        </span>
                        <InjuryBadges actor={pc} />
                        {(active?.id === pc.id || tied || !inQueue) && (
                          <small
                            className={
                              active?.id === pc.id
                                ? 'current-turn-badge'
                                : undefined
                            }
                          >
                            {active?.id === pc.id
                              ? 'TERAZ'
                              : tied
                                ? 'Remis — kolejność MG'
                                : 'Bez inicjatywy'}
                          </small>
                        )}
                      </span>
                    </button>
                    {tied && (
                      <span className="tie-buttons">
                        <button
                          type="button"
                          aria-label={`Przesuń ${pc.displayName} wyżej w remisie`}
                          disabled={
                            disabled ||
                            !valid ||
                            queue[index - 1]?.initiativeValue !==
                              inQueue.initiativeValue
                          }
                          onClick={() => state.moveTie(slotId, pc.id, -1)}
                        >
                          <ArrowUp size={16} aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          aria-label={`Przesuń ${pc.displayName} niżej w remisie`}
                          disabled={
                            disabled ||
                            !valid ||
                            queue[index + 1]?.initiativeValue !==
                              inQueue.initiativeValue
                          }
                          onClick={() => state.moveTie(slotId, pc.id, 1)}
                        >
                          <ArrowDown size={16} aria-hidden="true" />
                        </button>
                      </span>
                    )}
                  </li>
                );
              })}
            </ol>
            {actors.length > 0 && (
              <p className="editor-hint">
                Najwyższy wynik zaczyna. Remisy ustaw strzałkami; brak wyniku
                wyłącza postać z kolejki. 0 PW nie pomija tury.
              </p>
            )}
          </section>
        </div>
        {selected &&
        participation.entries.some((p) => p.actorId === selected.id) ? (
          <div
            id="actor-card"
            className="combat-actor-card"
            tabIndex={-1}
            key={selected.id}
          >
            <ActorCardNavigation actor={selected} />
            <LinkedCharacter
              actor={selected}
              slotId={slotId}
              participation={participation.entries.find(
                (p) => p.actorId === selected.id,
              )!}
              disabled={disabled}
            />
          </div>
        ) : selected ? (
          <div
            id="actor-card"
            className="combat-actor-card"
            tabIndex={-1}
            key={selected.id}
          >
            <ActorCardNavigation actor={selected} />
            {!selected.enemy && (
              <LinkCharacter
                actor={selected}
                slotId={slotId}
                disabled={disabled}
              />
            )}
            <ActorEditor
              key={selected.id}
              slotId={slotId}
              pc={selected}
              disabled={
                disabled ||
                state.statusForm !== null ||
                state.capabilityForm !== null ||
                state.failureForm !== null ||
                state.statblockForm !== null ||
                state.loadoutForm !== null
              }
              canSetCurrent={
                valid &&
                selected.initiativeValue.trim() !== '' &&
                active?.id !== selected.id
              }
            />
          </div>
        ) : (
          <div className="actor-empty">
            <span className="section-note">KARTA POSTACI</span>
            <p>Tu zobaczysz PW, TT i statusy wybranej postaci.</p>
          </div>
        )}
        <CombatLog
          slotId={slotId}
          disabled={
            disabled ||
            !valid ||
            state.enemyForm !== null ||
            state.statusForm !== null ||
            state.capabilityForm !== null ||
            state.failureForm !== null ||
            state.statblockForm !== null ||
            state.loadoutForm !== null
          }
        />
      </div>
      <ResourceRefresh
        key={slotId}
        slotId={slotId}
        disabled={
          disabled ||
          !valid ||
          !actors.length ||
          Boolean(
            state.enemyForm ||
            state.statusForm ||
            state.capabilityForm ||
            state.failureForm ||
            state.statblockForm ||
            state.loadoutForm,
          )
        }
      />
      <PreparationControls
        slotId={slotId}
        disabled={
          disabled ||
          !valid ||
          !actors.length ||
          state.enemyForm !== null ||
          state.statusForm !== null ||
          state.capabilityForm !== null ||
          state.failureForm !== null ||
          state.statblockForm !== null ||
          state.loadoutForm !== null
        }
        canReset={actors.every((actor) => Boolean(actor.prepared))}
      />
    </section>
  );
}

function ActorCardNavigation({ actor }: { actor: ActorDraft }) {
  const sections = [
    { label: 'PW i TT', selector: '.stats-grid, .bg-quick-values' },
    ...(actor.enemy
      ? [
          {
            label: 'Cechy',
            selector: '[aria-label="Statblock tej instancji"]',
          },
          { label: 'Akcje', selector: '.capability-panel' },
        ]
      : []),
    { label: 'Statusy', selector: '.status-panel' },
    ...(actor.enemy?.template.category === 'machine'
      ? [{ label: 'Awarie', selector: '.failure-panel' }]
      : []),
  ];
  return (
    <nav className="actor-card-nav" aria-label="Sekcje karty uczestnika">
      {sections.map(({ label, selector }) => (
        <button
          type="button"
          key={label}
          onClick={() => {
            const card = document.getElementById('actor-card');
            const target = card?.querySelector<HTMLElement>(selector);
            if (!card || !target) return;
            target.tabIndex = -1;
            target.focus({ preventScroll: true });
            if (
              ['auto', 'scroll'].includes(getComputedStyle(card).overflowY) &&
              card.scrollHeight > card.clientHeight
            ) {
              // Only move the card. scrollIntoView also moves the whole page
              // and can tuck its navigation under the sticky round toolbar.
              const navHeight =
                card.querySelector<HTMLElement>('.actor-card-nav')
                  ?.offsetHeight ?? 0;
              card.scrollTo({
                top:
                  card.scrollTop +
                  target.getBoundingClientRect().top -
                  card.getBoundingClientRect().top -
                  navHeight -
                  12,
                behavior: 'auto',
              });
            } else {
              // Narrow windows use the page scroll; leave the round controls clear.
              const toolbar = card
                .closest('.combat-workspace')
                ?.querySelector<HTMLElement>('.turn-toolbar');
              const inset =
                toolbar && getComputedStyle(toolbar).position === 'sticky'
                  ? toolbar.offsetHeight + 12
                  : 12;
              window.scrollTo({
                top:
                  window.scrollY + target.getBoundingClientRect().top - inset,
                behavior: 'auto',
              });
            }
          }}
        >
          {label}
        </button>
      ))}
    </nav>
  );
}

function ActorEditor({
  slotId,
  pc,
  disabled,
  canSetCurrent,
}: {
  slotId: SlotId;
  pc: ActorDraft;
  disabled: boolean;
  canSetCurrent: boolean;
}) {
  const { editActor, adjustHp, flush, removeActor, setCurrent, addEnemy } =
    useCombatStore();
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [amount, setAmount] = useState('5');
  let valid = true;
  try {
    parseActorDraft(pc);
  } catch {
    valid = false;
  }
  useEffect(() => {
    if (!valid) {
      const details = document.querySelector<HTMLDetailsElement>(
        '#actor-card .actor-extra-fields',
      );
      if (details) details.open = true;
    }
  }, [valid]);
  const numericAmount = /^\d+$/.test(amount.trim()) ? Number(amount) : NaN;
  const amountValid = Number.isSafeInteger(numericAmount) && numericAmount > 0;
  const edit = (patch: Partial<ActorDraft>) => editActor(slotId, pc.id, patch);
  const field = (
    name: 'ttCurrent' | 'hpCurrent' | 'hpMaxCurrent' | 'initiativeValue',
    label: string,
  ) => (
    <label className={`stat-field ${name.startsWith('hp') ? 'hp-field' : ''}`}>
      <span>{label}</span>
      <input
        aria-label={label}
        inputMode={name === 'initiativeValue' ? 'text' : 'numeric'}
        value={pc[name]}
        onChange={(event) => edit({ [name]: event.target.value })}
        onBlur={() => {
          void flush(slotId);
        }}
        aria-invalid={
          name === 'initiativeValue'
            ? pc[name].trim() !== '' && !/^-?\d+$/.test(pc[name].trim())
            : !/^\d+$/.test(pc[name].trim())
        }
      />
    </label>
  );
  return (
    <section
      className="actor-editor"
      aria-label={pc.enemy ? 'Karta przeciwnika' : 'Karta BG'}
    >
      {pc.enemy && <NpcAbilityEffects actorId={pc.id} slotId={slotId} />}
      <fieldset disabled={disabled}>
        <legend className="section-note">
          {pc.enemy ? 'PRZECIWNIK' : 'BOHATER GRACZA'}
        </legend>
        <label className="field-label" htmlFor={`pc-name-${pc.id}`}>
          {pc.enemy ? 'Nazwa instancji' : 'Imię BG'}
        </label>
        <input
          id={`pc-name-${pc.id}`}
          className="name-input"
          value={pc.displayName}
          autoComplete="off"
          aria-invalid={!pc.displayName.trim()}
          onChange={(event) => edit({ displayName: event.target.value })}
          onBlur={() => {
            void flush(slotId);
          }}
        />
        <div className="stats-grid">
          {field('hpCurrent', 'Aktualne PW')}
          {field('hpMaxCurrent', 'Maksymalne PW')}
          {field(
            'ttCurrent',
            pc.enemy?.machineFailures?.some((f) => f.result === 13)
              ? 'TT przed awariami'
              : 'TT',
          )}
          {field('initiativeValue', 'Inicjatywa')}
        </div>
        <div className="hp-controls">
          <div className="hp-shortcuts" aria-label="Szybka zmiana PW">
            {[-1, -5, -10, 1].map((delta) => (
              <button
                type="button"
                key={delta}
                disabled={!valid}
                onClick={() => adjustHp(slotId, pc.id, delta)}
                aria-label={`${delta > 0 ? 'Dodaj' : 'Odejmij'} ${Math.abs(delta)} PW`}
              >
                {delta > 0 ? '+' : ''}
                {delta}
              </button>
            ))}
          </div>
          <div className="hp-custom">
            <label>
              <span>Zmiana PW</span>
              <input
                inputMode="numeric"
                aria-label="Własna wartość PW"
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
              />
            </label>
            <button
              type="button"
              disabled={!valid || !amountValid}
              onClick={() => adjustHp(slotId, pc.id, -numericAmount)}
            >
              Obrażenia
            </button>
            <button
              type="button"
              disabled={!valid || !amountValid}
              onClick={() => adjustHp(slotId, pc.id, numericAmount)}
            >
              Leczenie
            </button>
          </div>
        </div>
        {pc.enemy && fixedHandbookSp(pc.enemy.template) && (
          <p className="statblock-minor">
            <strong>SP</strong> {pc.spText || 'N/D'}
          </p>
        )}
        {pc.enemy && (
          <p className="combat-movement">
            <strong>Ruch bazowy:</strong>{' '}
            {displaySpeedDraft(pc.speedsText ?? '') || 'N/D'}
          </p>
        )}
        {pc.statusesText && (
          <p className="status-description">
            <strong>Statusy opisowe:</strong> {pc.statusesText}
          </p>
        )}
        <InjuryBadges actor={pc} />
        <div className="combat-state-badges">
          {pc.effects?.map((effect) => (
            <span key={effect.id}>
              {effect.name}
              {effect.level != null ? ` ${effect.level}` : ''} ·{' '}
              {statusDuration(effect)}
            </span>
          ))}
        </div>
        {valid && <FailureSummary actor={parseActorDraft(pc)} />}
        <StatblockPanel slotId={slotId} actor={pc} />
        <details className="actor-extra-fields">
          <summary>Parametry i notatki postaci</summary>
          {pc.enemy && !fixedHandbookSp(pc.enemy.template) && (
            <label className="stat-field sp-field">
              <span>Aktualne SP — puste = brak danych</span>
              <input
                aria-label="Aktualne SP"
                inputMode="decimal"
                value={pc.spText ?? ''}
                onChange={(event) => edit({ spText: event.target.value })}
                onBlur={() => {
                  void flush(slotId);
                }}
              />
            </label>
          )}
          {pc.enemy && (
            <label className="movement-field">
              <span>Aktualny ruch — metry, po jednym w wierszu</span>
              <textarea
                aria-label="Aktualny ruch"
                value={speedDraftLabel(pc.speedsText ?? '')}
                placeholder={'Szybkość: 9\nWspinaczka: 4,5'}
                onChange={(event) => edit({ speedsText: event.target.value })}
                onBlur={() => {
                  void flush(slotId);
                }}
              />
            </label>
          )}
          <label
            className="field-label notes-label"
            htmlFor={`pc-status-${pc.id}`}
          >
            Statusy opisowe — po jednym w wierszu
          </label>
          <textarea
            id={`pc-status-${pc.id}`}
            className="status-input"
            placeholder="Własne przypomnienia bez czasu"
            value={pc.statusesText}
            onChange={(event) => edit({ statusesText: event.target.value })}
            onBlur={() => {
              void flush(slotId);
            }}
          />
          <p className="editor-hint">
            Dotychczasowe wpisy opisowe zachowują swoją treść. Nie uruchamiają
            efektów systemowych ani odliczania czasu.
          </p>
        </details>
        <CapabilityPanel slotId={slotId} actor={pc} />
        <InjuryPanel slotId={slotId} actor={pc} />
      </fieldset>
      <StatusPanel slotId={slotId} actor={pc} parentDisabled={disabled} />
      <FailurePanel slotId={slotId} actor={pc} parentDisabled={disabled} />
      <fieldset disabled={disabled}>
        {pc.enemy && (
          <details className="template-summary">
            <summary>Szablon: {pc.enemy.template.name}</summary>
            <p>
              {categoryLabels[pc.enemy.template.category]} ·{' '}
              {pc.enemy.template.size} · TT {pc.enemy.template.tt} · PW{' '}
              {pc.enemy.template.hpMax}
            </p>
            <StatblockSummary
              disabled={disabled}
              value={pc.enemy.template.statblock}
              tt={pc.enemy.template.tt}
            />
            <pre>
              {displaySpeeds(pc.enemy.template.speeds) || 'Brak danych o ruchu'}
            </pre>
            <button
              className="secondary-button"
              type="button"
              onClick={() => addEnemy(slotId, pc.enemy!.template)}
            >
              Dodaj kolejną instancję tego szablonu
            </button>
            <p className="editor-hint">
              Kopia zaczyna z danymi szablonu i pustą inicjatywą. Edycja tej
              karty zmienia tylko wybraną instancję.
            </p>
          </details>
        )}
        <details className="template-summary">
          <summary>Stan przygotowany tej postaci</summary>
          {pc.prepared ? (
            <>
              <p>
                {pc.prepared.displayName} · PW {pc.prepared.hpCurrent}/
                {pc.prepared.hpMaxCurrent} · TT{' '}
                {effectiveMachineTT(pc.prepared)} · Inicjatywa{' '}
                {pc.prepared.initiativeValue ?? '—'}
              </p>
              <p>
                Statusy opisowe: {pc.prepared.statuses.join(', ') || 'brak'}
              </p>
              {pc.prepared.effects?.map((s) => (
                <p key={s.id}>
                  {s.name}
                  {s.level ? ` ${s.level}` : ''} · {statusDuration(s)}
                </p>
              ))}
              <FailureSummary actor={pc.prepared} />
              {pc.prepared.enemy?.loadout && (
                <AttackProfiles
                  loadout={pc.prepared.enemy.loadout}
                  failures={pc.prepared.enemy.machineFailures}
                />
              )}
              {pc.prepared.enemy?.capabilities && (
                <p>
                  Zasoby:{' '}
                  {pc.prepared.enemy.capabilities.resources
                    .map((r) => `${r.name}: ${r.currentValue}/${r.maxValue}`)
                    .join(', ') || 'brak'}{' '}
                  · Akcja {pc.prepared.enemy.capabilities.budget.action},
                  Bonusowa {pc.prepared.enemy.capabilities.budget.bonus},
                  Reakcja{' '}
                  {pc.prepared.enemy.capabilities.unlimitedReactions
                    ? 'Bez limitu'
                    : pc.prepared.enemy.capabilities.budget.reaction}
                  , Legendarne {pc.prepared.enemy.capabilities.budget.legendary}
                  /{pc.prepared.enemy.capabilities.legendaryMax}
                </p>
              )}
              {pc.prepared.enemy && (
                <p>
                  SP {pc.prepared.enemy.sp ?? 'N/D'} · Zranienia:{' '}
                  {pc.prepared.enemy.injury?.enabled
                    ? `${pc.prepared.enemy.injury.level}/4${pc.prepared.enemy.injury.deathWarning ? ' — śmierć (MG)' : ''}`
                    : 'wyłączone'}{' '}
                  · Tchórzliwość:{' '}
                  {pc.prepared.enemy.cowardicePercent == null
                    ? 'brak'
                    : `${pc.prepared.enemy.cowardicePercent}%`}
                </p>
              )}
              {pc.prepared.enemy && (
                <pre>
                  {displaySpeeds(pc.prepared.enemy.speeds) ||
                    'Brak danych o ruchu'}
                </pre>
              )}
            </>
          ) : (
            <p>Zapisz stan przygotowany potyczki przed resetem.</p>
          )}
        </details>
        <div className="actor-actions">
          <button
            className="secondary-button"
            type="button"
            disabled={!canSetCurrent}
            onClick={() => setCurrent(slotId, pc.id)}
          >
            Ustaw bieżącą turę
          </button>
          <button
            className="remove-actor"
            type="button"
            onClick={() => setConfirmRemove(true)}
          >
            <Trash2 size={15} aria-hidden="true" />
            {pc.enemy ? 'Usuń przeciwnika' : 'Usuń BG'}
          </button>
        </div>
        {confirmRemove && (
          <div className="remove-confirm" role="alert">
            <p>Usunąć „{pc.displayName}” z tej potyczki?</p>
            <button
              className="remove-actor"
              type="button"
              onClick={() => removeActor(slotId, pc.id)}
            >
              Usuń tę postać
            </button>
            <button
              type="button"
              className="secondary-button"
              onClick={() => setConfirmRemove(false)}
            >
              Anuluj
            </button>
          </div>
        )}
      </fieldset>
    </section>
  );
}
