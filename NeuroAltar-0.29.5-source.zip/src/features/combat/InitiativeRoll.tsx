import { useEffect, useRef } from 'react';
import { enemyInitiative } from '../../domain/enemyInitiative';
import type { ActorDraft } from '../../domain/combat';
import type { SlotId } from '../../domain/encounterDetails';
import { useInitiativeStore } from '../../stores/initiativeStore';
import { useCombatStore } from '../../stores/combatStore';
import { useDiceStore } from '../../stores/diceStore';
import { DiceResult } from '../dice/DiceWorkspace';
export function InitiativeRollButton({
  actor,
  slotId,
  disabled,
  text,
}: {
  actor: ActorDraft;
  slotId: SlotId;
  disabled: boolean;
  text: string;
}) {
  const dice = useDiceStore();
  const state = useCombatStore();
  const bonus = enemyInitiative(actor);
  const form =
    state.enemyForm ||
    state.statusForm ||
    state.capabilityForm ||
    state.failureForm ||
    state.statblockForm ||
    state.loadoutForm;
  return (
    <button
      type="button"
      className="roll-value"
      aria-label={`Rzuć inicjatywę — ${actor.displayName}`}
      disabled={disabled || !bonus || !!form || dice.busy || !!dice.pending}
      title={
        bonus
          ? `Rzuć ${bonus.formula} i wpisz wynik w tej potyczce`
          : 'Brak premii inicjatywy i wartości Zręczności — wpisz wynik ręcznie.'
      }
      onKeyDown={(e) => {
        if (e.repeat && (e.key === 'Enter' || e.code === 'Space'))
          e.preventDefault();
      }}
      onClick={() => {
        void useInitiativeStore.getState().roll(slotId, actor.id);
      }}
    >
      <strong>{text.slice(0, text.indexOf(':') + 1)}</strong>
      {text.slice(text.indexOf(':') + 1)}
    </button>
  );
}
export function InitiativeRollStatus() {
  const state = useInitiativeStore();
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (state.slotId !== null) dialog.current?.showModal();
    else dialog.current?.close();
  }, [state.slotId]);
  return (
    <dialog
      ref={dialog}
      className="shortcut-dialog"
      aria-labelledby="initiative-save-title"
      onCancel={(e) => e.preventDefault()}
    >
      <h2 id="initiative-save-title">Inicjatywa — potyczka {state.slotId}</h2>
      {state.pending && <DiceResult roll={state.pending} />}
      {state.busy ? (
        <p role="status">Zapisywanie inicjatywy…</p>
      ) : (
        <>
          <p role="alert" className="editor-error">
            {state.error}
          </p>
          <p>Wynik pozostaje zachowany. Ponowienie zapisuje ten sam rzut.</p>
          <div className="actor-actions">
            {state.pending && (
              <button
                className="secondary-button"
                onClick={() => {
                  void state.retry();
                }}
              >
                Ponów zapis inicjatywy
              </button>
            )}
            <button
              className="secondary-button"
              onClick={() => {
                void state.reload();
              }}
            >
              Odczytaj potyczkę i anuluj niezapisany rzut
            </button>
          </div>
        </>
      )}
    </dialog>
  );
}
