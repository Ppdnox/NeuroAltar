import { TemplateFields } from '../bestiary/TemplateFields';
import { useCombatStore } from '../../stores/combatStore';
import type { SlotId } from '../../domain/encounterDetails';

export function EnemyForm({
  slotId,
  disabled,
}: {
  slotId: SlotId;
  disabled: boolean;
}) {
  const {
    enemyForm: form,
    editEnemyForm,
    submitEnemyForm,
    cancelEnemyForm,
  } = useCombatStore();
  if (!form || form.slotId !== slotId) return null;
  return (
    <form
      className="enemy-form"
      aria-label="Nowy przeciwnik"
      onSubmit={(event) => {
        event.preventDefault();
        submitEnemyForm();
      }}
    >
      <fieldset disabled={disabled}>
        <legend>Przygotuj przeciwnika</legend>
        <p className="editor-hint">
          Wpisz dane szablonu. Każda dodana kopia otrzyma własne PW i
          inicjatywę.
        </p>
        <TemplateFields
          value={form.fields}
          onChange={editEnemyForm}
          error={form.error}
        />
        <div className="actor-actions">
          <button className="secondary-button" type="submit">
            Zapisz szablon i dodaj przeciwnika
          </button>
          <button
            className="secondary-button"
            type="button"
            onClick={cancelEnemyForm}
          >
            Anuluj formularz
          </button>
        </div>
      </fieldset>
    </form>
  );
}
