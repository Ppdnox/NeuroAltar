import type { SaveStatus } from '../../stores/encounterStore';
export const combatSaveLabels: Record<SaveStatus, string> = {
  saved: 'Postacie zapisane',
  pending: 'Postacie: oczekuje na zapis',
  saving: 'Zapisywanie postaci…',
  error: 'Postacie: nie zapisano',
  invalid: 'Postacie: popraw dane',
};
