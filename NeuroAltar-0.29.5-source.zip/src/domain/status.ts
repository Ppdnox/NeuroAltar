import { z } from 'zod';

export const systemStatuses = {
  unconscious: [
    'Nieprzytomność',
    'Obezwładnienie, powalenie i szybkość 0. Pamiętaj o upuszczonych przedmiotach, atakach i RO.',
  ],
  invisible: [
    'Niewidoczność',
    'Przypomnienie o ułatwieniu własnych ataków i utrudnieniu ataków przeciwnika, który nie widzi tej postaci.',
  ],
  incapacitated: [
    'Obezwładnienie',
    'Brak akcji, akcji bonusowych i reakcji; brak mowy, utrudnienie inicjatywy.',
  ],
  deafened: [
    'Ogłuchnięcie',
    'Brak słuchu; testy wymagające słyszenia nie mogą się powieść.',
  ],
  stunned: [
    'Ogłuszenie',
    'Obezwładnienie, ułatwienie ataków przeciw postaci; automatyczna porażka RO na SIŁ/ZRC.',
  ],
  blinded: [
    'Oślepienie',
    'Brak wzroku; utrudnienie własnych ataków i ułatwienie ataków przeciw postaci.',
  ],
  grappled: [
    'Pochwycenie',
    'Szybkość 0; utrudnienie ataków przeciw innym celom niż chwytający.',
  ],
  prone: [
    'Powalenie',
    'Czołganie lub połowa szybkości na wstanie; pamiętaj o modyfikatorach ataku zależnych od odległości.',
  ],
  frightened: [
    'Przerażenie',
    'Utrudnienie ataków i testów cech; nie zbliżaj się dobrowolnie do źródła strachu.',
  ],
  paralyzed: [
    'Sparaliżowanie',
    'Obezwładnienie i szybkość 0; porażka RO SIŁ/ZRC, trafienie z odległości do 1,5 m jest krytyczne.',
  ],
  restrained: [
    'Unieruchomienie',
    'Szybkość 0; utrudnienie własnych ataków i RO ZRC, ułatwienie ataków przeciw postaci.',
  ],
  exhaustion: [
    'Wyczerpanie',
    'Każdy poziom: −2 do testów k20 i −1,5 m szybkości. Poziom 6 oznacza śmierć. Długi odpoczynek usuwa 1 poziom.',
  ],
  poisoned: ['Zatrucie', 'Utrudnienie testów ataku i cech.'],
  charmed: [
    'Zauroczenie',
    'Nie krzywdź źródła zauroczenia; ma ułatwienie społecznych testów Charyzmy przeciw tej postaci.',
  ],
  burning: [
    'Podpalenie',
    'Na początku tury: 1k4 obrażeń od ognia. MG rozstrzyga obrażenia i ugaszenie.',
  ],
} as const;
export const systemKeySchema = z.enum(
  Object.keys(systemStatuses) as [
    keyof typeof systemStatuses,
    ...Array<keyof typeof systemStatuses>,
  ],
);
export type SystemKey = z.infer<typeof systemKeySchema>;
export const durationLabels = {
  manual: 'Ręcznie',
  rounds: 'Liczba rund',
  until_start_of_turn: 'Do początku tury',
  until_end_of_turn: 'Do końca tury',
  until_end_of_next_turn: 'Do końca następnej tury',
} as const;
export const durationSchema = z.enum([
  'manual',
  'rounds',
  'until_start_of_turn',
  'until_end_of_turn',
  'until_end_of_next_turn',
]);
export type DurationType = z.infer<typeof durationSchema>;
export const statusSchema = z
  .object({
    id: z.uuid(),
    systemKey: systemKeySchema.nullable(),
    name: z.string().trim().min(1),
    description: z.string(),
    sourceText: z.string(),
    durationType: durationSchema,
    durationValue: z.number().int().min(1).max(999).nullable(),
    remaining: z.number().int().min(1).max(999).nullable(),
    level: z.number().int().min(1).max(6).nullable(),
  })
  .strict()
  .superRefine((s, ctx) => {
    const timedEnd =
      s.durationType === 'until_end_of_turn' ||
      s.durationType === 'until_end_of_next_turn';
    if (
      (s.systemKey !== null && s.name !== systemStatuses[s.systemKey][0]) ||
      (s.systemKey === 'exhaustion'
        ? s.level === null || s.durationType !== 'manual'
        : s.level !== null) ||
      (s.durationType === 'rounds'
        ? s.durationValue === null ||
          s.remaining === null ||
          s.remaining > s.durationValue
        : s.durationValue !== null) ||
      (timedEnd
        ? s.remaining === null ||
          s.remaining > (s.durationType === 'until_end_of_turn' ? 1 : 2)
        : s.durationType !== 'rounds' && s.remaining !== null)
    )
      ctx.addIssue({
        code: 'custom',
        message: 'Niepoprawny status lub czas trwania.',
      });
  });
export type Status = z.infer<typeof statusSchema>;
export const statusListSchema = z
  .array(statusSchema)
  .superRefine((list, ctx) => {
    if (
      new Set(list.map((s) => s.id)).size !== list.length ||
      list.filter((s) => s.systemKey === 'exhaustion').length > 1
    )
      ctx.addIssue({
        code: 'custom',
        message: 'Powtórzony identyfikator lub poziom Wyczerpania.',
      });
  });
export interface StatusDraft {
  systemKey: SystemKey | null;
  name: string;
  description: string;
  sourceText: string;
  durationType: DurationType;
  rounds: string;
  level: string;
}
export function newStatusDraft(): StatusDraft {
  return {
    systemKey: 'burning',
    name: '',
    description: '',
    sourceText: '',
    durationType: 'manual',
    rounds: '1',
    level: '1',
  };
}
export function parseStatusDraft(
  draft: StatusDraft,
  active: boolean,
  id: string = crypto.randomUUID(),
): Status {
  const durationType =
    draft.systemKey === 'exhaustion' ? 'manual' : draft.durationType;
  const rounds = /^\d+$/.test(draft.rounds.trim()) ? Number(draft.rounds) : NaN;
  return statusSchema.parse({
    id,
    systemKey: draft.systemKey,
    name: draft.systemKey ? systemStatuses[draft.systemKey][0] : draft.name,
    description: draft.description,
    sourceText: draft.sourceText,
    durationType,
    durationValue: durationType === 'rounds' ? rounds : null,
    remaining:
      durationType === 'rounds'
        ? rounds
        : durationType === 'until_end_of_turn'
          ? 1
          : durationType === 'until_end_of_next_turn'
            ? active
              ? 2
              : 1
            : null,
    level:
      draft.systemKey === 'exhaustion' && /^\d+$/.test(draft.level.trim())
        ? Number(draft.level)
        : null,
  });
}
// Only ordinary Next Turn executes hooks. Selecting/correcting an active actor is neutral.
export function tickStatuses(
  statuses: readonly Status[],
  end: boolean,
  round: boolean,
  start: boolean,
): Status[] {
  return statuses.flatMap((s) => {
    if (start && s.durationType === 'until_start_of_turn') return [];
    if (
      (round && s.durationType === 'rounds') ||
      (end &&
        ['until_end_of_turn', 'until_end_of_next_turn'].includes(
          s.durationType,
        ))
    )
      return s.remaining === 1 ? [] : [{ ...s, remaining: s.remaining! - 1 }];
    return [s];
  });
}
export function statusDuration(s: Status): string {
  return s.durationType === 'rounds'
    ? `Rundy: ${s.remaining} / ${s.durationValue}`
    : s.durationType === 'until_end_of_next_turn'
      ? `${durationLabels[s.durationType]} (końce tur: ${s.remaining})`
      : durationLabels[s.durationType];
}
export function exhaustionEffects(statuses: readonly Status[]) {
  const level = statuses.find((s) => s.systemKey === 'exhaustion')?.level ?? 0;
  return {
    level,
    testPenalty: 2 * level,
    speedPenalty: 1.5 * level,
    deathWarning: level === 6,
  };
}
