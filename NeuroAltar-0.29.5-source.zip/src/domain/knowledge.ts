import { z } from 'zod';

const text = z.string().trim().min(1);
const source = text;
const cellSchema = z.object({ text: z.string(), source }).strict();
export const knowledgeBlockSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('text'), text, source }).strict(),
  z
    .object({
      kind: z.literal('table'),
      columns: z
        .array(
          z.object({ label: text, source, unit: text.nullable() }).strict(),
        )
        .min(1),
      rows: z.array(
        z.object({ id: text, cells: z.array(cellSchema) }).strict(),
      ),
    })
    .strict()
    .superRefine((table, ctx) => {
      if (new Set(table.rows.map((r) => r.id)).size !== table.rows.length)
        ctx.addIssue({ code: 'custom', message: 'Powtórzone ID wiersza.' });
      table.rows.forEach((row, index) => {
        if (row.cells.length !== table.columns.length)
          ctx.addIssue({
            code: 'custom',
            path: ['rows', index, 'cells'],
            message: 'Wiersz musi odpowiadać nagłówkom tabeli.',
          });
      });
    }),
]);
export const knowledgeEntrySchema = z
  .object({
    handbook: z
      .object({
        title: text,
        pages: z.array(z.number().int().positive().max(279)).min(1),
      })
      .strict(),
    id: z.uuid(),
    title: text,
    category: text,
    tags: z.array(text),
    blocks: z.array(knowledgeBlockSchema).min(1),
    source: z.object({ sheet: text, range: text }).strict(),
    createdAt: text,
    updatedAt: text,
  })
  .strict();
export const knowledgeEntriesSchema = z
  .array(knowledgeEntrySchema)
  .refine(
    (entries) => new Set(entries.map((e) => e.id)).size === entries.length,
    'Powtórzone ID wpisu wiedzy.',
  );
export type KnowledgeEntry = z.infer<typeof knowledgeEntrySchema>;
export type ReferenceEntry = KnowledgeEntry;
export type KnowledgeBlock = KnowledgeEntry['blocks'][number];
export type KnowledgeTable = Extract<KnowledgeBlock, { kind: 'table' }>;

export function normalizeKnowledge(value: string) {
  return value
    .toLocaleLowerCase('pl')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replaceAll('ł', 'l');
}
export function knowledgeMatches(value: string, query: string) {
  const normalized = normalizeKnowledge(value);
  return normalizeKnowledge(query.trim())
    .split(/\s+/)
    .every((word) => normalized.includes(word));
}
function entryHeading(entry: KnowledgeEntry) {
  return [entry.title, entry.category, ...entry.tags].join(' ');
}
export function entryMatches(entry: KnowledgeEntry, query: string) {
  const heading = entryHeading(entry);
  return (
    knowledgeMatches(heading, query) ||
    entry.blocks.some((block) =>
      block.kind === 'text'
        ? knowledgeMatches(`${heading} ${block.text}`, query)
        : block.rows.some((row) =>
            knowledgeMatches(
              [
                heading,
                ...block.columns.map((c) => c.label),
                ...row.cells.map((c) => c.text),
              ].join(' '),
              query,
            ),
          ),
    )
  );
}
export function filterKnowledge(
  entries: KnowledgeEntry[],
  query: string,
  category: string,
) {
  return entries.filter(
    (e) => (!category || category === e.category) && entryMatches(e, query),
  );
}
// Keep headings and source notes; narrow only the data rows, without altering the source entry.
export function matchingRows(
  entry: KnowledgeEntry,
  table: KnowledgeTable,
  query: string,
) {
  if (
    !query.trim() ||
    knowledgeMatches(
      [
        entry.title,
        entry.category,
        ...entry.tags,
        ...table.columns.map((c) => c.label),
      ].join(' '),
      query,
    )
  )
    return table.rows;
  const rows = table.rows.filter((r) =>
    knowledgeMatches(
      [
        entryHeading(entry),
        ...table.columns.map((c) => c.label),
        ...r.cells.map((c) => c.text),
      ].join(' '),
      query,
    ),
  );
  // A match in an accompanying note still needs its complete table as context.
  return rows.length ||
    !entry.blocks.some(
      (b) =>
        b.kind === 'text' &&
        knowledgeMatches(`${entryHeading(entry)} ${b.text}`, query),
    )
    ? rows
    : table.rows;
}
export function knowledgeParagraphs(text: string) {
  return text
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean);
}

export function formatHandbookPages(pages: number[]) {
  const sorted = [...new Set(pages)].sort((a, b) => a - b);
  const ranges: string[] = [];
  for (let i = 0; i < sorted.length; i++) {
    const first = sorted[i]!;
    let last = first;
    while (sorted[i + 1] === last + 1) {
      last++;
      i++;
    }
    ranges.push(first === last ? String(first) : `${first}–${last}`);
  }
  return ranges.join(', ');
}
