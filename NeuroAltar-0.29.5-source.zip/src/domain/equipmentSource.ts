import handbook from '../data/equipment/handbook-sources.v1.json';
import type { Item } from './item';
const references = new Map(
  handbook.groups.flatMap((group) =>
    Object.entries(group.items).map(
      ([id, row]) =>
        [
          id,
          {
            original: `Suplement tabelaryczny • KATALOG, wiersz ${row}`,
            label: `${handbook.title} — s. ${group.pages.join(', ')}; ${group.section}`,
          },
        ] as const,
    ),
  ),
);
/** Resolve the verified handbook citation for existing seed rows without rewriting user data. */
export function equipmentSource(
  item: Pick<Item, 'id' | 'source'>,
): string | undefined {
  const reference = references.get(item.id);
  return reference && item.source === reference.original
    ? reference.label
    : item.source;
}
