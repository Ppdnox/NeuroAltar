import { z } from 'zod';
import { partyLevelsSchema } from './encounter';

export const spSchema = z
  .number()
  .finite()
  .min(0)
  .max(Number.MAX_SAFE_INTEGER)
  .nullable();
export function parseSP(text: string): number | null {
  const value = text.trim();
  if (value === '') return null;
  if (!/^\d+(?:[.,]\d+)?$/.test(value))
    throw new Error('SP: wpisz liczbę nieujemną lub pozostaw puste.');
  return spSchema.parse(Number(value.replace(',', '.')));
}
export function parsePartyLevels(text: string): number[] {
  const values = text.trim() === '' ? [] : text.trim().split(/[\s,;]+/);
  if (values.some((v) => !/^\d+$/.test(v)))
    throw new Error(
      'Poziomy BG: wpisz dodatnie liczby całkowite, oddzielone spacją lub nowym wierszem.',
    );
  return partyLevelsSchema.parse(values.map(Number));
}
// User-defined intermediate ranges; exact percentage is never rounded before classification.
export function difficultyLabel(percent: number): string {
  if (!Number.isFinite(percent) || percent < 0)
    throw new Error('Niepoprawny procent trudności.');
  if (percent < 126) return 'Łatwa';
  if (percent < 176) return 'Wyczerpująca';
  if (percent < 251) return 'Ryzykowna';
  return 'Zabójcza';
}
export const difficultyAnchors = [
  { percent: 100, label: 'Łatwa' },
  { percent: 150, label: 'Wyczerpująca' },
  { percent: 200, label: 'Ryzykowna' },
  { percent: 300, label: 'Zabójcza' },
] as const;
function sum(values: number[]): number {
  const total = values.reduce((a, b) => a + b, 0);
  if (!Number.isFinite(total) || total > Number.MAX_SAFE_INTEGER)
    throw new Error('Suma przekracza bezpieczny zakres obliczeń.');
  return total;
}
// Roster difficulty is independent of HP, statuses and current turn.
export function calculateEncounterDifficulty(
  partyLevels: number[],
  enemies: { sp?: number | null }[],
) {
  const sd = sum(partyLevelsSchema.parse(partyLevels));
  const values = enemies.map((enemy) => spSchema.parse(enemy.sp ?? null));
  const missingSP = values.filter((v) => v === null).length;
  const knownSP = sum(values.filter((v): v is number => v !== null));
  const sp = missingSP ? null : knownSP;
  const ratio = sd > 0 && sp !== null ? sp / sd : null;
  const percent = ratio === null ? null : ratio * 100;
  return {
    sd,
    sp,
    knownSP,
    missingSP,
    ratio,
    percent,
    label: percent === null ? null : difficultyLabel(percent),
    markerPercent: percent === null ? null : Math.min(percent / 3, 100),
  };
}

export const formatDifficultyNumber = (value: number | null) =>
  value === null
    ? 'N/D'
    : value.toLocaleString('pl-PL', { maximumFractionDigits: 2 });
export function difficultyFromDrafts(
  levels: string,
  actors:
    | { displayName: string; spText?: string; enemy?: { sp?: number | null } }[]
    | undefined,
) {
  if (!actors) return { result: null, error: null };
  try {
    let party: number[];
    try {
      party = parsePartyLevels(levels);
    } catch {
      throw new Error(
        'Poziomy BG: wpisz dodatnie liczby całkowite, oddzielone spacją lub nowym wierszem.',
      );
    }
    const enemies = actors
      .filter((a) => a.enemy)
      .map((a) => {
        try {
          return {
            sp: a.spText === undefined ? a.enemy!.sp : parseSP(a.spText),
          };
        } catch {
          throw new Error(
            `${a.displayName || 'Przeciwnik'} — Aktualne SP: wpisz liczbę nieujemną (np. 2,5) lub pozostaw puste.`,
          );
        }
      });
    return {
      result: calculateEncounterDifficulty(party, enemies),
      error: null,
    };
  } catch (e) {
    return {
      result: null,
      error: e instanceof Error ? e.message : 'Nie można obliczyć trudności.',
    };
  }
}
