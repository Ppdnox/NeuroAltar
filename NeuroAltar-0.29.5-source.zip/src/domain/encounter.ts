import { z } from 'zod';

export const SLOT_IDS = [1, 2, 3, 4, 5] as const;
export const encounterIdSchema = z.union([
  z.literal(1),
  z.literal(2),
  z.literal(3),
  z.literal(4),
  z.literal(5),
]);
export const partyLevelsSchema = z.array(z.number().int().positive());
export type PartyLevels = z.infer<typeof partyLevelsSchema>;

export const encounterSchema = z
  .object({
    id: encounterIdSchema,
    name: z.string().refine((value) => value.trim().length > 0),
    notes: z.string(),
    roundNumber: z.number().int().positive(),
    currentTurnActorId: z.uuid().nullable(),
    partyLevels: partyLevelsSchema,
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .strict();
export type Encounter = z.infer<typeof encounterSchema>;

export const encounterSlotsSchema = z
  .array(encounterSchema)
  .length(5)
  .superRefine((slots, ctx) => {
    if (new Set(slots.map((slot) => slot.id)).size !== SLOT_IDS.length) {
      ctx.addIssue({
        code: 'custom',
        message: 'Baza musi zawierać dokładnie sloty 1–5.',
      });
    }
  });
