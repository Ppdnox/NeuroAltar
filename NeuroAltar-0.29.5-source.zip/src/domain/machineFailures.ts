import type { Actor } from './combat';
import type { ActionKind } from './capabilitySchema';
import { newStatusDraft, parseStatusDraft, type SystemKey } from './status';
import {
  machineFailureSchema,
  machineFailuresSchema,
  parseFailureResult,
  parseFailureThreshold,
  type FailureDraft,
  type MachineFailure,
} from './machineFailureSchema';
export const failureTable = [
  [
    'Zniszczona broń',
    'Wskaż jedną broń. Zostanie oznaczona jako niezdatna do ataku, bez usunięcia przedmiotu.',
  ],
  ['Uszkodzony napęd', 'Szybkości ×0,5. Wpisane wartości bazowe pozostają.'],
  ['Celowanie −2', 'Kara −2 do wszystkich profili ataku.'],
  [
    'Uszkodzony procesor',
    'MG wybiera blokadę Akcji Bonusowych albo Legendarnych.',
  ],
  ['Przerwa zasilania', 'Sparaliżowanie do końca następnej własnej tury.'],
  [
    'Eksplozja amunicji',
    'Odejmij 50 PW (minimum 0) i oznacz brak amunicji. Bez licznika nabojów.',
  ],
  [
    'Uszkodzony manipulator',
    'O jeden atak mniej w turze. MG rozstrzyga atak wielokrotny.',
  ],
  ['Awaria optyki', 'Oślepienie do naprawy.'],
  ['Wyciek płynów', 'Brak Reakcji.'],
  [
    'Reset systemów',
    'Brak Akcji i Bonusowych do końca następnej własnej tury.',
  ],
  [
    'Samozapłon',
    'Podpalenie. Pamiętaj również o 1k4 od ognia przy kontakcie; MG rozstrzyga obrażenia.',
  ],
  [
    'Awaria żyroskopu',
    'Powalenie bez wstawania do końca następnej własnej tury.',
  ],
  [
    'Uszkodzony pancerz',
    'TT −2 (minimum 0). Wpisane TT pozostaje wartością przed awariami.',
  ],
  ['Celowanie −4', 'Kara −4 do wszystkich profili ataku.'],
  [
    'Uszkodzone siłowniki',
    'Połowa obrażeń ataków wręcz. Przypomnienie — nie zmienia formuły kości.',
  ],
  ['Zniszczone siłowniki', 'Ataki wręcz niedostępne.'],
  ['Wycofanie', 'MG prowadzi wycofanie do bazy i zaprzestanie ataków.'],
  ['Błąd rozpoznawania', 'MG wskazuje najbliższe cele, także sojuszników.'],
  [
    'Wyłączenie',
    'Maszyna nie działa do naprawy. Pozostaje na liście i w kolejce.',
  ],
  [
    'Zniszczenie',
    'Ustaw 0 PW i oznacz zniszczenie. MG rozstrzyga autodestrukcję ze statblocka; bez obrażeń innych postaci.',
  ],
] as const;
export function isMachine(actor: Actor) {
  return actor.enemy?.template.category === 'machine';
}
export function failureModifiers(failures: readonly MachineFailure[] = []) {
  const has = (n: number) => failures.some((f) => f.result === n);
  return {
    attack: failures.reduce(
      (n, f) => n + (f.result === 3 ? -2 : f.result === 14 ? -4 : 0),
      0,
    ),
    armor: -2 * failures.filter((f) => f.result === 13).length,
    speed:
      has(19) || has(20)
        ? 0
        : 0.5 ** failures.filter((f) => f.result === 2).length,
    off: has(19) || has(20),
    noAmmo: has(6),
    noMelee: has(16),
    halfMelee: has(15),
    fewerAttacks: failures.filter((f) => f.result === 7).length,
  };
}
export function effectiveMachineTT(actor: Actor) {
  return Math.max(
    0,
    actor.ttCurrent + failureModifiers(actor.enemy?.machineFailures).armor,
  );
}
export function machineActionRestriction(
  actor: Actor,
  kind: ActionKind,
): string | null {
  const fs = actor.enemy?.machineFailures ?? [];
  if (failureModifiers(fs).off)
    return 'Awaria: maszyna wyłączona lub zniszczona.';
  if (
    fs.some(
      (f) =>
        (f.result === 4 && f.blockedAction === kind) ||
        (f.result === 9 && kind === 'reaction') ||
        (f.result === 10 && (kind === 'action' || kind === 'bonus')),
    )
  )
    return 'Awaria: zablokowana akcja. Naprawa lub upływ czasu znosi blokadę.';
  return null;
}
export function failureAttackWarning(
  failures: readonly MachineFailure[],
  itemId: string,
  kind: 'melee' | 'ranged',
) {
  const m = failureModifiers(failures);
  if (m.off) return 'Maszyna wyłączona lub zniszczona — atak niedostępny.';
  if (failures.some((f) => f.result === 1 && f.weaponId === itemId))
    return 'Broń zniszczona — atak niedostępny.';
  if (kind === 'melee' && m.noMelee) return 'Awaria: brak ataków wręcz.';
  if (kind === 'ranged' && m.noAmmo)
    return 'Brak amunicji — MG rozstrzyga możliwość tego ataku.';
  return null;
}
export function applyMachineFailure(
  actor: Actor,
  draft: FailureDraft,
  active: boolean,
  id = crypto.randomUUID(),
): Actor {
  if (!isMachine(actor)) throw new Error('Awarie dotyczą maszyn.');
  const result = parseFailureResult(draft.result);
  parseFailureThreshold(draft.damage); // Optional damage is only a comparison, never a second HP subtraction.
  const weapon = actor.enemy!.loadout?.items.find(
    (e) => e.item.id === draft.weaponId && e.item.type === 'weapon',
  );
  if (result === 1 && !weapon) throw new Error('Wybierz istniejącą broń.');
  const failure = machineFailureSchema.parse({
    id,
    result,
    weaponId: result === 1 ? weapon!.item.id : null,
    weaponName: result === 1 ? weapon!.item.name : null,
    blockedAction: result === 4 ? draft.blockedAction || null : null,
    remainingEnds: [5, 10, 12].includes(result) ? (active ? 2 : 1) : null,
    note: draft.note,
  });
  const fs = machineFailuresSchema.parse([
    ...(actor.enemy!.machineFailures ?? []),
    failure,
  ]);
  const statusKey: SystemKey | null =
    result === 5
      ? 'paralyzed'
      : result === 8
        ? 'blinded'
        : result === 11
          ? 'burning'
          : result === 12
            ? 'prone'
            : null;
  return {
    ...actor,
    hpCurrent:
      result === 6
        ? Math.max(0, actor.hpCurrent - 50)
        : result === 20
          ? 0
          : actor.hpCurrent,
    enemy: { ...actor.enemy!, machineFailures: fs },
    ...(statusKey
      ? {
          effects: [
            ...(actor.effects ?? []),
            parseStatusDraft(
              {
                ...newStatusDraft(),
                systemKey: statusKey,
                sourceText: `Awaria ${result}: ${failureTable[result - 1]![0]}`,
                description: failureTable[result - 1]![1],
                durationType: [5, 12].includes(result)
                  ? 'until_end_of_next_turn'
                  : 'manual',
              },
              active,
              id,
            ),
          ],
        }
      : {}),
  };
}
export function repairMachineFailure(actor: Actor, id: string): Actor {
  if (!actor.enemy?.machineFailures?.some((f) => f.id === id)) return actor;
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      machineFailures: actor.enemy.machineFailures.filter((f) => f.id !== id),
    },
    ...(actor.effects
      ? { effects: actor.effects.filter((s) => s.id !== id) }
      : {}),
  };
}
export function tickMachineFailures(actor: Actor, end: boolean): Actor {
  if (!actor.enemy?.machineFailures || !end) return actor;
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      machineFailures: actor.enemy.machineFailures.flatMap((f) =>
        f.remainingEnds === null
          ? [f]
          : f.remainingEnds === 1
            ? []
            : [{ ...f, remainingEnds: f.remainingEnds - 1 }],
      ),
    },
  };
}
