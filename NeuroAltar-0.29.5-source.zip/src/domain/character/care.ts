import { emptyDowntime } from './downtimeModel';
import {
  type Care,
  type CareCommand,
  emptyCare,
  diseaseKinds,
  phobiaKinds,
} from './careModel';
import type { Condition } from './conditionModel';
import { abilityNames, type Character, type CharacterSheet } from './model';
import { emptyInventory } from './inventoryModel';
import { validateInventory } from './inventory';
import { deriveCharacter } from './derive';
import { ConditionError } from './condition';
export const diseaseNames: Record<string, string> = {
  hemophilia: 'Hemofilia',
  circulation: 'Niewydolność krążenia',
  dracula: 'Syndrom Draculi',
  thurman: 'Syndrom Thurmana',
  boston: 'Szaleństwo bostońskie',
  osteoporosis: 'Osteoporoza',
  paranoia: 'Paranoja',
  labyrinth: 'Zaburzenia błędnika',
  radiation: 'Choroba popromienna',
  rat: 'Szczurza gorączka',
  infection: 'Choroba zakaźna',
  death: 'Death Breath',
};
export const medicineNames: Record<string, string> = {
  hemophilia: 'Desmopresyna',
  circulation: 'Aspiryna K',
  dracula: 'Dracophen',
  thurman: 'Reminex',
  boston: 'Relanium',
  osteoporosis: 'Wapniak',
  paranoia: 'Psychotropy',
  labyrinth: 'Actinix',
  radiation: 'RadOff',
  rat: 'Antybiotyki',
  infection: 'Antybiotyki',
};
export const phobiaNames: Record<string, string> = {
  heights: 'Akrofobia',
  spiders: 'Arachnofobia',
  closed: 'Klaustrofobia',
  mutants: 'Mutkofobia',
  dark: 'Nyktofobia',
  fire: 'Pirofobia',
  machines: 'Robofobia',
  rats: 'Rodentofobia',
};
export const diseaseEffects: Record<string, string[]> = {
  hemophilia: [
    'Po obrażeniach ciętych lub kłutych: krwawienie. RO KON ST 10 na koniec tury; porażka oznacza rzut 1k4 obrażeń. Trzy kolejne sukcesy zatrzymują krwawienie.',
  ],
  circulation: [
    'Utrudnienie testów cech SIŁ i KON.',
    'Utrudnienie testów cech i RO SIŁ/KON oraz ataków opartych na SIŁ.',
    'Utrudnienie wszystkich testów; Szybkość 0 i Powalenie.',
  ],
  dracula: [
    'W świetle dziennym: Utrudnienie ataków i Percepcji wzrokowej. Widzenie w ciemności 18 m.',
    'Odsłonięta skóra na słońcu: 1k4 obrażeń na minutę.',
    'Każde źródło światła: 1k6 obrażeń na minutę.',
  ],
  thurman: [
    'Utrudnienie testów opartych na INT.',
    'INT 6; Utrudnienie testów opartych na CHA.',
    'INT 2; tylko ataki bez broni lub bronią improwizowaną; niewrażliwość na Przerażenie.',
  ],
  boston: [
    'Utrudnienie Perswazji i Oszustwa; Ułatwienie Zastraszania.',
    'Utrudnienie testów cech INT/CHA. Porażka: 50% szans na atakowanie źródła frustracji.',
    'Porażka w teście wywołuje szał przeciw wszystkim wokół do utraty przytomności.',
  ],
  osteoporosis: [
    'Obrażenia od upadku ×2.',
    'Utrudnienie testów cech, ataków i RO opartych na SIŁ.',
    'Szybkość ×0,5; obrażenia od upadku ×4.',
  ],
  paranoia: [
    'Ułatwienie Intuicji i Percepcji; Utrudnienie Oszustwa i Perswazji.',
    'Utrudnienie testów i RO INT/MDR oraz Wpływania.',
    'Przerażenie; w walce dostępna wyłącznie akcja Unikanie.',
  ],
  labyrinth: [
    'Jako pasażer pojazdu: Utrudnienie wszystkich testów cech, ataków i RO.',
    'Najwyżej 3 m w linii prostej; Utrudnienie wszystkich ataków.',
    'Utrudnienie wszystkich testów; Szybkość 0.',
  ],
  radiation: [
    'RO KON ST 20 na koniec dnia: sukces zamienia chorobę w losową przewlekłą; porażka blokuje odpoczynki i dodaje Wyczerpanie. RadOff przez 10 kolejnych dni.',
  ],
  rat: [
    'RO KON ST 15 na koniec dnia: sukces leczy; porażka blokuje odpoczynki i dodaje Wyczerpanie. Antybiotyki przez 10 kolejnych dni.',
  ],
  infection: [
    'Skutki ustala MG. Antybiotyki: po 3 kolejnych dniach objawy ustępują, po 10 kończy się zakaźność.',
  ],
  death: [
    'Po kontakcie RO KON ST 10. Porażka oznacza przemianę w zombie w ciągu kilku godzin; brak leku. Objawy po 1k4 godzinach.',
  ],
};
function need(ok: unknown, field: string, message: string): asserts ok {
  if (!ok) throw new ConditionError(field, message);
}
export function careSheet(sheet: CharacterSheet, care?: Care): CharacterSheet {
  if (!care) return sheet;
  const out = { ...structuredClone(sheet), healthAdjustments: care.starts };
  const thurman = care.diseases
    .filter((d) => d.active && d.kind === 'thurman')
    .reduce((s, d) => Math.max(s, d.stage), 0);
  if (thurman)
    out.overrides = [
      ...out.overrides.filter((o) => o.target !== 'score:int'),
      {
        id: care.diseases.find((d) => d.active && d.kind === 'thurman')!.id,
        target: 'score:int',
        mode: 'replace',
        value: thurman === 2 ? 2 : 6,
        reason: 'Syndrom Thurmana',
      },
    ];
  return out;
}
export function nutritionNeeds(sheet: CharacterSheet) {
  const d = deriveCharacter(sheet);
  if (d.rules.some((r) => r.id === 'origin.desert.diet'))
    return { foodMg: 250000, waterMl: 1000 };
  const sizes = {
    tiny: [100000, 500],
    small: [250000, 1000],
    medium: [500000, 2000],
    large: [2000000, 30000],
    huge: [8000000, 60000],
    gargantuan: [32000000, 240000],
  } as const;
  const p = sizes[sheet.identity.size];
  return { foodMg: p[0], waterMl: p[1] };
}
export function applyCare(
  record: Character,
  s: Condition,
  a: CareCommand,
  operationId: string,
) {
  const c = structuredClone(s.care ?? emptyCare()),
    inventory = structuredClone(record.inventory ?? emptyInventory()),
    lines: string[] = [];
  const sheet = record.sheet!,
    now = s.worldMinutes,
    day = Math.floor(now / 1440),
    feats = deriveCharacter(sheet).activeFeats,
    immune = feats.includes('immunity');
  c.day = day;
  const disease = (id: string) => {
    const d = c.diseases.find((d) => d.id === id && d.active);
    need(d, 'id', 'Wybierz aktywną chorobę.');
    return d;
  };
  const phobia = (id: string) => {
    const p = c.phobias.find((p) => p.id === id && p.active);
    need(p, 'id', 'Wybierz aktywną fobię.');
    return p;
  };
  const addDisease = (
    id: string,
    kind: (typeof diseaseKinds)[number],
    details: string,
    onsetMinutes = 0,
    initial = false,
  ) => {
    if (immune && !initial) {
      lines.push('Immunitet: nie nabyto nowej choroby.');
      return;
    }
    need(!c.diseases.some((d) => d.id === id), 'id', 'Ten wpis już istnieje.');
    c.diseases.push({
      id,
      kind,
      stage: 0,
      active: true,
      details,
      onsetAt: now + onsetMinutes,
      treatedDay: null,
      treatmentDays: 0,
      lastTreatmentDay: null,
      lastCheckDay: null,
      blocked: false,
      bleeding: false,
      successes: 0,
    });
  };
  const addPhobia = (id: string, kind: (typeof phobiaKinds)[number]) => {
    need(!c.phobias.some((p) => p.id === id), 'id', 'Ten wpis już istnieje.');
    c.phobias.push({
      id,
      kind,
      successes: 0,
      active: true,
      fear: false,
      immuneUntil: 0,
      attackUntil: 0,
      lastCheckAt: null,
      turns: [],
    });
  };
  const exhaust = (
    cause:
      | 'hunger'
      | 'thirst'
      | 'cold'
      | 'radiation'
      | 'suffocation'
      | 'disease'
      | 'ordinary',
    source: string,
  ) => {
    s.exhaustion.push({ id: operationId, cause, source, level: 1 });
  };
  const consume = (id: string, quantity: number) => {
    const e = inventory.entries.find((e) => e.id === id);
    need(
      e &&
        e.quantityMilli >= quantity &&
        quantity > 0 &&
        !e.weapon &&
        !e.magazine &&
        !e.container,
      'entryId',
      'Brak właściwej ilości wybranego materiału/środka.',
    );
    e.quantityMilli -= quantity;
  };
  switch (a.kind) {
    case 'start': {
      need(
        !c.starts.some((x) => x.group === a.group),
        'group',
        'Początkowy wybór jest już rozliczony.',
      );
      const base = sheet.baseScores[a.ability];
      need(base !== null, 'ability', 'Brak cechy bazowej.');
      const prior = c.starts
        .filter((x) => x.ability === a.ability)
        .reduce(
          (v, x) => Math.max(1, Math.min(x.delta > 0 ? 18 : 30, v + x.delta)),
          base,
        );
      const delta = a.choice < 0 ? -1 : prior >= 18 ? 0 : 1;
      need(prior + delta >= 1, 'ability', 'Cecha nie może spaść poniżej 1.');
      c.starts.push({ group: a.group, ability: a.ability, delta });
      if (a.choice >= 0) {
        const index = a.choice;
        if (a.group === 'disease') {
          const kind = diseaseKinds[index]!;
          addDisease(a.id, kind, 'Wybór początkowy', 0, true);
          const med = a.medicine;
          need(
            med &&
              med.item.name === medicineNames[kind] &&
              med.quantityMilli === 3000 &&
              med.unit === 'dawka' &&
              med.weightMg === 0 &&
              med.slot === 'none' &&
              !med.weapon &&
              !med.armor &&
              !med.magazine &&
              !med.container &&
              med.parentId === null,
            'medicine',
            'Wybór choroby wymaga trzech dawek właściwego leku o masie 0 kg.',
          );
          need(
            !inventory.entries.some((e) => e.id === med.id),
            'medicine',
            'Lek już istnieje.',
          );
          inventory.entries.push(med);
        } else {
          need(a.medicine === null, 'medicine', 'Fobia nie przyznaje leków.');
          addPhobia(a.id, phobiaKinds[index]!);
        }
      } else
        need(
          a.medicine === null,
          'medicine',
          'Odrzucenie chorób nie przyznaje leków.',
        );
      lines.push(
        'Wybór początkowy: ' +
          (a.group === 'disease' ? 'Choroba' : 'Fobia') +
          '; ' +
          abilityNames[a.ability] +
          ' ' +
          (delta >= 0 ? '+' : '') +
          delta,
      );
      break;
    }
    case 'disease':
      need(!immune, 'disease', 'Immunitet: postać nie nabywa nowych chorób.');
      addDisease(a.id, a.disease, a.details, a.onsetMinutes);
      lines.push('Dodano: ' + diseaseNames[a.disease]);
      break;
    case 'diseaseCheck': {
      const d = disease(a.id);
      need(now >= d.onsetAt, 'id', 'Nie upłynął czas do pierwszych objawów.');
      need(d.lastCheckDay !== day, 'id', 'Ten dzień został już rozliczony.');
      need(
        !['hemophilia', 'infection'].includes(d.kind),
        'id',
        'Ta choroba nie ma dobowego testu postępu.',
      );
      if (diseaseKinds.slice(0, 8).includes(d.kind)) {
        need(
          d.treatedDay !== day,
          'id',
          'Dzienna dawka leku została już przyjęta.',
        );
        d.stage =
          a.natural === 20
            ? 0
            : Math.min(
                2,
                d.stage + (a.natural === 1 ? 2 : a.total < 10 ? 1 : 0),
              );
      } else if (d.kind === 'death') {
        if (a.total < 10) {
          d.stage = 2;
          lines.push(
            'Death Breath: przemiana w zombie wymaga rozstrzygnięcia MG.',
          );
        } else d.active = false;
      } else if (a.total >= (d.kind === 'radiation' ? 20 : 15)) {
        d.blocked = false;
        d.active = false;
        if (d.kind === 'radiation' && !immune) {
          need(
            a.chronicRoll !== null,
            'chronicRoll',
            'Podaj wynik k8 nowej choroby przewlekłej.',
          );
          addDisease(
            operationId,
            diseaseKinds[a.chronicRoll - 1]!,
            'Następstwo choroby popromiennej',
          );
        }
      } else {
        d.blocked = true;
        exhaust('disease', diseaseNames[d.kind]!);
      }
      d.lastCheckDay = day;
      lines.push(
        'Rozliczono chorobę: ' +
          diseaseNames[d.kind] +
          '; naturalne ' +
          a.natural +
          ', wynik ' +
          a.total,
      );
      break;
    }
    case 'medicine': {
      if (a.treatment === 'exposure') {
        const e = inventory.entries.find((e) => e.id === a.entryId);
        need(
          e &&
            e.item.name.toLowerCase() === 'radoff' &&
            ['dawka', 'szt.'].includes(e.unit),
          'entryId',
          'Wybierz RadOff; 1 szt. = 1 dawka.',
        );
        need(a.sideSave !== null, 'sideSave', 'RadOff wymaga RO KON ST 15.');
        s.exhaustion = s.exhaustion.filter(
          (x) =>
            x.cause !== 'radiation' &&
            !(x.cause === 'disease' && x.source === 'Choroba popromienna'),
        );
        c.radiationFailures = 0;
        if (a.sideSave! < 15) {
          s.downtime ??= emptyDowntime();
          s.downtime.benefits.push({
            id: operationId,
            label: 'RadOff: przez minutę nie możesz wykonywać akcji',
            expiresAt: now + 1,
            refresh: 'manual',
          });
        }
        consume(a.entryId, a.doses * 1000);
        lines.push(
          'RadOff: usunięto skutki napromieniowania; zużyto ' +
            a.doses +
            ' dawek.',
        );
        break;
      }

      const d = disease(a.id),
        e = inventory.entries.find((e) => e.id === a.entryId);
      need(e, 'entryId', 'Wybierz lek z inwentarza.');
      const expected =
        a.treatment === 'antibiotic'
          ? 'Antybiotyk'
          : a.treatment === 'radoff'
            ? 'RadOff'
            : medicineNames[d.kind];
      need(
        expected &&
          e.item.name
            .toLocaleLowerCase('pl')
            .includes(expected.toLocaleLowerCase('pl')),
        'entryId',
        'Wybrany środek nie leczy tego schorzenia.',
      );
      need(
        ['dawka', 'szt.'].includes(e.unit),
        'entryId',
        'Przy lekach 1 szt. = 1 dawka.',
      );
      if (a.treatment === 'bleeding') {
        need(
          d.kind === 'hemophilia' && d.bleeding,
          'id',
          'Brak krwawienia hemofilii.',
        );
        d.bleeding = false;
        d.successes = 0;
      } else {
        need(d.treatedDay !== day, 'id', 'Dawka dobowa już przyjęta.');
        d.treatedDay = day;
        if (a.treatment === 'daily') {
          need(
            diseaseKinds.slice(0, 8).includes(d.kind),
            'treatment',
            'Wybierz właściwą kurację.',
          );
        } else {
          need(
            (a.treatment === 'radoff' && d.kind === 'radiation') ||
              (a.treatment === 'antibiotic' &&
                ['rat', 'infection'].includes(d.kind)),
            'treatment',
            'Ta kuracja nie dotyczy wybranej choroby.',
          );
          d.treatmentDays =
            d.lastTreatmentDay === day - 1 ? d.treatmentDays + 1 : 1;
          d.lastTreatmentDay = day;
          if (d.treatmentDays >= 10) {
            d.active = false;
            d.blocked = false;
          }
          if (d.kind === 'infection' && d.treatmentDays >= 3) d.stage = 0;
        }
      }
      if (a.treatment === 'radoff') {
        need(a.sideSave !== null, 'sideSave', 'RadOff wymaga RO KON ST 15.');
        s.exhaustion = s.exhaustion.filter(
          (e) =>
            e.cause !== 'radiation' &&
            !(e.cause === 'disease' && e.source === 'Choroba popromienna'),
        );
        c.radiationFailures = 0;
        if (a.sideSave < 15) {
          s.downtime ??= emptyDowntime();
          s.downtime.benefits.push({
            id: operationId,
            label: 'RadOff: przez minutę nie możesz wykonywać akcji',
            expiresAt: now + 1,
            refresh: 'manual',
          });
        }
      }
      const doses =
        a.doses *
        (feats.includes('plaster') &&
        ['daily', 'antibiotic', 'radoff'].includes(a.treatment)
          ? 0.5
          : 1);
      consume(a.entryId, doses * 1000);
      lines.push(
        'Przyjęto ' +
          doses +
          ' dawek: ' +
          e.item.name +
          (doses !== a.doses ? ' — Pan Plaster' : ''),
      );
      break;
    }
    case 'bleeding': {
      const d = disease(a.id);
      need(d.kind === 'hemophilia', 'id', 'Ta czynność dotyczy hemofilii.');
      if (a.mode === 'start') {
        d.bleeding = true;
        d.successes = 0;
      } else {
        need(
          d.bleeding && a.total !== null,
          'total',
          'Podaj wynik przy aktywnym krwawieniu.',
        );
        if (a.mode === 'medicineCheck') {
          need(a.tools, 'tools', 'Wymagane narzędzia małego medyka.');
          if (a.total >= 15) {
            d.bleeding = false;
            d.successes = 0;
          }
        } else {
          d.successes = a.total >= 10 ? d.successes + 1 : 0;
          if (d.successes >= 3) d.bleeding = false;
          if (a.total < 10)
            lines.push('Porażka: rozlicz 1k4 obrażeń z krwawienia.');
        }
      }
      lines.push('Rozliczono krwawienie.');
      break;
    }
    case 'phobia':
      addPhobia(a.id, a.phobia);
      lines.push('Dodano: ' + phobiaNames[a.phobia]);
      break;
    case 'phobiaAway':
      phobia(a.id).fear = false;
      lines.push('Bodziec fobii ustał; fobia i licznik sukcesów pozostają.');
      break;
    case 'phobiaCheck': {
      const p = phobia(a.id);
      need(now >= p.immuneUntil, 'id', 'Trwa okres przełamania tej fobii.');
      if (a.turn) {
        need(
          !p.turns.includes(a.turn),
          'turn',
          'Ta tura została już rozliczona.',
        );
        p.turns.push(a.turn);
      } else
        need(
          p.lastCheckAt === null || now - p.lastCheckAt >= 10,
          'id',
          'Poza walką odczekaj 10 minut czasu gry.',
        );
      if (a.total >= 15) {
        p.successes++;
        p.fear = false;
        p.immuneUntil = now + (['heights', 'fire'].includes(p.kind) ? 480 : 60);
        if (['spiders', 'mutants', 'machines', 'rats'].includes(p.kind))
          p.attackUntil = now + 1;
        if (p.successes >= 3) p.active = false;
      } else {
        p.successes = 0;
        p.fear = true;
      }
      p.lastCheckAt = now;
      lines.push(
        'RO fobii ' +
          a.total +
          ' przeciw ST 15; kolejne sukcesy: ' +
          p.successes +
          (p.active ? '' : ' — fobia wyleczona'),
      );
      break;
    }
    case 'day': {
      need(!c.days.includes(a.id), 'id', 'Ten dzień został już rozliczony.');
      const needs = nutritionNeeds(sheet);
      c.days.push(a.id);
      c.hungryDays = a.foodMg === 0 ? c.hungryDays + 1 : 0;
      c.foodSatisfied = a.foodMg >= needs.foodMg;
      c.waterSatisfied = a.waterMl >= needs.waterMl;
      let hunger = false;
      if (c.hungryDays >= 5) hunger = true;
      else if (a.foodMg < needs.foodMg / 2) {
        need(
          a.hungerSave !== null,
          'hungerSave',
          'Podaj RO KON ST 10 za niedożywienie.',
        );
        hunger = a.hungerSave < 10;
      }
      if (hunger) exhaust('hunger', 'Niedożywienie — ' + a.id);
      if (a.waterMl < needs.waterMl / 2) {
        if (hunger)
          s.exhaustion.push({
            id: cryptoIdSibling(operationId),
            cause: 'thirst',
            source: 'Odwodnienie — ' + a.id,
            level: 1,
          });
        else exhaust('thirst', 'Odwodnienie — ' + a.id);
      }
      if (a.foodEntryId) consume(a.foodEntryId, a.foodQuantity);
      if (a.waterEntryId) consume(a.waterEntryId, a.waterQuantity);
      c.day++;
      s.worldMinutes = c.day * 1440;
      lines.push(
        'Rozliczono dobę ' +
          a.id +
          ': jedzenie ' +
          a.foodMg / 1e6 +
          ' kg, woda ' +
          a.waterMl / 1000 +
          ' l.',
      );
      break;
    }
    case 'environment': {
      need(!c.exposures.includes(a.id), 'id', 'To zdarzenie już rozliczono.');
      c.exposures.push(a.id);
      if (a.hazard === 'breathe')
        s.exhaustion = s.exhaustion.filter((e) => e.cause !== 'suffocation');
      else if (a.hazard === 'suffocation')
        exhaust('suffocation', 'Duszenie — ' + a.id);
      else {
        need(a.total !== null, 'total', 'Podaj wynik RO.');
        const dc = a.hazard === 'noSleep' ? 20 : a.dc;
        if (a.total < dc) {
          exhaust(a.hazard === 'noSleep' ? 'ordinary' : a.hazard, a.id);
          if (a.hazard === 'radiation') {
            c.radiationFailures++;
            if (c.radiationFailures === 3)
              addDisease(
                a.diseaseId,
                'radiation',
                'Trzy nieudane RO przeciw promieniowaniu',
                1440,
              );
          }
        }
      }
      lines.push('Środowisko: ' + a.hazard + ' — ' + a.id);
      break;
    }
    case 'careCorrection': {
      if (a.group === 'disease') {
        const d = disease(a.id);
        d.active = false;
        d.blocked = false;
        d.bleeding = false;
      } else {
        const p = phobia(a.id);
        p.active = false;
        p.fear = false;
      }
      lines.push('Zakończono schorzenie: ' + a.reason);
      break;
    }
  }
  validateInventory(inventory);
  s.care = c;
  return { inventory, lines };
}
// Deterministic second ID when one day produces two distinct exhaustion causes.
export function cryptoIdSibling(id: string) {
  return id.slice(0, -1) + (id.endsWith('0') ? '1' : '0');
}
