import { abilityApplicationSchema } from './combatAbility';
import { downtimeSchema, downtimeCommandSchema } from './downtimeModel';
import { z } from 'zod';
import { careSchema, careCommandSchema } from './careModel';
const count = z.number().int().min(0).max(100000);
const name = z.string().trim().min(1).max(300);
export const exhaustionCauses = [
  'ordinary',
  'hunger',
  'thirst',
  'cold',
  'radiation',
  'suffocation',
  'disease',
  'manual',
] as const;
export const exhaustionNames: Record<
  (typeof exhaustionCauses)[number],
  string
> = {
  ordinary: 'Zmęczenie',
  hunger: 'Głód',
  thirst: 'Pragnienie',
  cold: 'Zimno',
  radiation: 'Promieniowanie',
  suffocation: 'Duszenie',
  disease: 'Choroba',
  manual: 'Inna przyczyna',
};
export const effectSchema = z
  .object({
    id: z.uuid(),
    source: name,
    target: z.enum(['hpMax', 'str', 'dex', 'con', 'int', 'wis', 'cha']),
    amount: count,
    refresh: z.enum(['long', 'manual']),
  })
  .strict();
export const exhaustionSchema = z
  .object({
    id: z.uuid(),
    cause: z.enum(exhaustionCauses),
    source: name,
    level: z.number().int().min(1).max(6),
  })
  .strict();
export const manualResourceSchema = z
  .object({ id: z.uuid(), label: name, max: count })
  .strict();
export const fuksSchema = z
  .object({
    id: z.uuid(),
    source: name,
    kind: z.enum(['start', 'fant', 'song', 'meal', 'session', 'manual']),
    expiresAt: z.number().int().min(0).max(1000000000).nullable(),
    session: z.string().max(100).nullable(),
  })
  .strict();
export const restSessionSchema = z
  .object({
    id: z.uuid(),
    kind: z.enum(['short', 'long']),
    color: z.enum(['none', 'rust', 'mercury', 'steel', 'chrome']),
    contextRevision: count,
    hpAtStart: count,
    startedAt: z.number().int().min(0).max(1000000000).optional(),
    elapsed: count,
    lastShortAt: count,
    interruptions: count,
  })
  .strict();
export const combatHealthSchema = z
  .object({
    bleeding: z.boolean(),
    successes: z.number().int().min(0).max(3),
    failures: z.number().int().min(0).max(3),
    stable: z.boolean(),
    dead: z.boolean(),
  })
  .strict();
export const healthCommandSchema = z.discriminatedUnion('kind', [
  z
    .object({
      kind: z.literal('damage'),
      amount: count,
      critical: z.boolean(),
      melee: z.boolean(),
    })
    .strict(),
  z.object({ kind: z.literal('healing'), amount: count }).strict(),
  z
    .object({
      kind: z.literal('deathSave'),
      face: z.number().int().min(1).max(20),
    })
    .strict(),
  z.object({ kind: z.literal('bleed') }).strict(),
  z.object({ kind: z.literal('stopBleeding') }).strict(),
  z.object({ kind: z.literal('stabilize') }).strict(),
]);
export type HealthCommand = z.infer<typeof healthCommandSchema>;
export const conditionSchema = z
  .object({
    combatHealth: combatHealthSchema.optional(),
    care: careSchema.optional(),
    downtime: downtimeSchema.optional(),
    hp: count,
    hitDiceSpent: z.object({ '6': count, '8': count }).strict(),
    spent: z.record(z.string().min(1).max(100), count),
    manual: z.array(manualResourceSchema).max(100),
    effects: z.array(effectSchema).max(100),
    injury: z.number().int().min(0).max(5),
    exhaustion: z.array(exhaustionSchema).max(100),
    restBlocks: z
      .array(z.object({ id: z.uuid(), source: name }).strict())
      .max(30),
    rest: restSessionSchema.nullable(),
    completedRests: z.array(z.uuid()).max(10000),
    longStreak: count,
    fuks: z.array(fuksSchema).max(100),
    startFuksClaimed: z.boolean(),
    session: z.string().max(100).nullable(),
    sessions: z.array(name).max(10000),
    worldMinutes: z.number().int().min(0).max(1000000000),
    journal: z
      .array(
        z.object({ id: z.uuid(), text: z.string().min(1).max(3000) }).strict(),
      )
      .max(10000),
  })
  .strict();
export type Condition = z.infer<typeof conditionSchema>;
export type Effect = z.infer<typeof effectSchema>;
export type Exhaustion = z.infer<typeof exhaustionSchema>;
export const restInputSchema = z
  .object({
    type: z.literal('restApply'),
    sessionId: z.uuid(),
    outcome: z.enum(['complete', 'interrupt']),
    elapsed: count,
    sleep: count,
    armored: z.boolean(),
    consecutive: z.boolean(),
    food: z.boolean(),
    water: z.boolean(),
    warm: z.boolean(),
    exhaustionId: z.uuid().nullable(),
    medicProficient: z.boolean(),
    medicTools: z.boolean(),
    healingSave: z.number().int().min(-100).max(100).nullable(),
    rolls6: z.array(z.number().int().min(1).max(6)).max(12),
    rolls8: z.array(z.number().int().min(1).max(8)).max(12),
    kolejkaLevel: z.number().int().min(0).max(12),
    kolejkaRolls: z.array(z.number().int().min(1).max(8)).max(12),
  })
  .strict();
export type RestInput = z.infer<typeof restInputSchema>;
export const conditionActionSchema = z.discriminatedUnion('type', [
  z
    .object({
      type: z.literal('combatAbility'),
      combatApplication: abilityApplicationSchema,
    })
    .strict(),
  z
    .object({ type: z.literal('combatHealth'), command: healthCommandSchema })
    .strict(),
  z.object({ type: z.literal('care'), command: careCommandSchema }).strict(),
  z
    .object({ type: z.literal('downtime'), command: downtimeCommandSchema })
    .strict(),
  z
    .object({
      type: z.literal('use'),
      resourceId: name,
      combatChoice: z.enum(['action', 'bonus']).optional(),
      combatApplication: abilityApplicationSchema.optional(),
      amount: z.number().int().min(1).max(100000),
      healingRoll: z.number().int().min(1).max(8).nullable(),
    })
    .strict(),
  z
    .object({
      type: z.literal('correct'),
      hp: count,
      injury: z.number().int().min(0).max(5),
      hitDiceSpent: z.object({ '6': count, '8': count }).strict(),
      reason: name,
    })
    .strict(),
  z
    .object({
      type: z.literal('resourceStep'),
      id: name,
      direction: z.enum(['use', 'restore']),
    })
    .strict(),
  z
    .object({
      type: z.literal('resource'),
      id: name,
      spent: count,
      reason: name,
    })
    .strict(),
  z
    .object({
      type: z.literal('manual'),
      entry: manualResourceSchema,
      reason: name,
    })
    .strict(),
  z.object({ type: z.literal('effect'), entry: effectSchema }).strict(),
  z.object({ type: z.literal('exhaustion'), entry: exhaustionSchema }).strict(),
  z.object({ type: z.literal('exhaustionReduce'), id: z.uuid() }).strict(),
  z.object({ type: z.literal('block'), id: z.uuid(), source: name }).strict(),
  z
    .object({
      type: z.literal('remove'),
      group: z.enum(['effects', 'exhaustion', 'restBlocks']),
      id: z.uuid(),
      reason: name,
    })
    .strict(),
  z
    .object({
      type: z.literal('restStart'),
      id: z.uuid(),
      kind: z.enum(['short', 'long']),
    })
    .strict(),
  restInputSchema,
  z.object({ type: z.literal('restCancel'), reason: name }).strict(),
  z.object({ type: z.literal('fuksGrant'), entry: fuksSchema }).strict(),
  z.object({ type: z.literal('fuksUse'), id: z.uuid() }).strict(),
  z.object({ type: z.literal('session'), id: name }).strict(),
  z.object({ type: z.literal('sessionEnd') }).strict(),
  z
    .object({
      type: z.literal('worldTime'),
      minutes: z.number().int().min(1).max(100000),
    })
    .strict(),
]);
export type ConditionAction = z.infer<typeof conditionActionSchema>;
