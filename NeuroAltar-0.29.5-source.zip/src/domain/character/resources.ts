import { deriveCharacter } from './derive';
import type { CharacterSheet } from './model';
export type Refresh = 'short' | 'long' | 'encounter' | 'day' | 'manual';
export interface ResourceDefinition {
  id: string;
  label: string;
  max: number;
  refresh: Refresh;
  page: number;
  costMax: number;
  note: string;
  unresolved: boolean;
}
export function deriveResources(sheet: CharacterSheet): ResourceDefinition[] {
  const d = deriveCharacter(sheet),
    c = d.classLevels,
    m = d.modifiers,
    out: ResourceDefinition[] = [];
  const add = (
    id: string,
    label: string,
    max: number,
    refresh: Refresh,
    page: number,
    note = '',
    costMax = 1,
  ) =>
    out.push({
      id,
      label,
      max: Math.max(0, max),
      refresh,
      page,
      note,
      costMax,
      unresolved: max <= 0,
    });
  const has = (id: string) => d.rules.some((r) => r.id === id);
  if (c.brutal) {
    add(
      'berserk',
      'Berserk',
      2 + Math.floor((c.brutal - 1) / 3),
      'long',
      67,
      'Akcja Bonusowa; 10 rund.',
    );
    if (c.brutal >= 2)
      add(
        'rage',
        'Wściekły cios',
        c.brutal,
        'long',
        67,
        'Kości k6; raz na rundę.',
        3,
      );
  }
  if (c.cwaniak) {
    add(
      'motivation',
      'Motywacja',
      m.cha ?? 0,
      'short',
      72,
      'Reakcja; przed poznaniem wyniku.',
    );
    add(
      'luck',
      'Szczęście',
      1 + Math.floor((c.cwaniak - 1) / 3),
      'long',
      72,
      'Raz na rundę.',
    );
    if (c.cwaniak >= 2)
      add('heckle', 'Spieprzysz to!', m.cha ?? 0, 'short', 72, 'Reakcja.');
    if (c.cwaniak >= 5) add('insult', 'Obelga', d.pb, 'short', 73, 'Akcja.');
  }
  if (c.spec) {
    add('advice', 'Dobra rada', d.pb, 'short', 78, 'Akcja Bonusowa.');
    add('defense', 'Inteligentna obrona', m.int ?? 0, 'short', 78, 'Reakcja.');
    if (c.spec >= 2)
      add(
        'brain',
        'Łeb jak sklep',
        d.pb,
        'long',
        78,
        'Kość k' + Math.min(12, 2 + 2 * Math.floor(c.spec / 2)),
      );
    if (c.spec >= 3)
      add(
        'production',
        'Szybka produkcja',
        1,
        'short',
        79,
        'Wymaga schematu, narzędzi i surowców; limit ' +
          (c.spec >= 11 ? 50 : 25) +
          ' gb.',
      );
    if (c.spec >= 4)
      add(
        'hands',
        'Szybkie ręce',
        m.dex ?? 0,
        'short',
        79,
        'Dodatkowe Używanie.',
      );
    if (c.spec >= 7) add('trajectory', 'Trajektoria', d.pb, 'long', 79);
  }
  if (c.twardziel) {
    add(
      'stamina',
      'Kondycha',
      m.con ?? 0,
      'long',
      86,
      'Akcja Bonusowa; leczenie 1k8 + poziom Twardziela.',
    );
    if (c.twardziel >= 2)
      add(
        'surge',
        'Zryw',
        1,
        'short',
        87,
        'Dodatkowa Akcja lub Akcja Bonusowa.',
      );
    if (c.twardziel >= 3)
      add(
        'toughness',
        'Twardość',
        m.con ?? 0,
        'long',
        87,
        'Kość k' + (2 + 2 * Math.floor(c.twardziel / 3)),
      );
  }
  if (c.zlodziej >= 2)
    add(
      'cat',
      'Kocie kości',
      m.dex ?? 0,
      'long',
      92,
      'Kość k' + (4 + 2 * Math.floor((c.zlodziej - 2) / 3)),
      12,
    );
  if (c.zlodziej >= 7) add('matrix', 'Matrix', d.pb, 'long', 92);
  if (c.zlodziej >= 11) add('sapper', 'Saper', 1, 'short', 93);
  if (has('profession.preacher.0')) add('amen', 'Amen', m.cha ?? 0, 'long', 75);
  if (has('profession.star.3'))
    add(
      'concert',
      'Za garść gambli',
      1,
      'day',
      74,
      'Jeden czterogodzinny koncert dziennie. Przywróć kropkę w kolejnym dniu gry.',
    );
  if (has('profession.cowboy.0'))
    add(
      'clint',
      'Clint — Poprawka',
      1,
      'encounter',
      88,
      'Odnawia rozpoczęcie walki, nie odpoczynek.',
    );
  for (const [rule, id, label, page, refresh] of [
    ['origin.newyork.patriot', 'patriot', 'Czas patriotów', 63, 'long'],
    ['origin.hegemony.stubborn', 'stubborn', 'Zawzięty sukinkot', 63, 'long'],
    ['origin.saltlake.believe', 'believe', 'Wierzę', 64, 'long'],
    ['origin.vegas.luck', 'fart', 'Fart', 65, 'short'],
    ['feat.musician', 'song', 'Pieśń otuchy', 105, 'long'],
  ] as const)
    if (has(rule)) add(id, label, 1, refresh, page);
  return out;
}
export const refreshNames: Record<Refresh, string> = {
  short: 'Krótki lub długi',
  long: 'Długi',
  encounter: 'Nowa walka',
  day: 'Kolejny dzień (ręcznie)',
  manual: 'Ręcznie',
};
