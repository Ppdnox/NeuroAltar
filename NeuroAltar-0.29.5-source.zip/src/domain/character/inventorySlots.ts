import { SLOTS, type Inventory, type InventoryEntry } from './inventoryModel';

export type InventorySlot = InventoryEntry['slot'];
export type WeaponGrip = NonNullable<InventoryEntry['grip']>;
export const MELEE_SLOTS = ['melee1', 'melee2', 'melee3', 'melee4'] as const;
export const RANGED_SLOTS = ['ranged1', 'ranged2', 'ranged3'] as const;
export const HANDY_SLOTS = ['handy1', 'handy2', 'handy3'] as const;
const LEGACY_HANDS = ['mainHand', 'offHand', 'bothHands'];
export const isLegacyHandSlot = (slot: InventorySlot) =>
  LEGACY_HANDS.includes(slot);
export const isHandySlot = (slot: InventorySlot) =>
  (HANDY_SLOTS as readonly string[]).includes(slot);
export const isNumberedWeaponSlot = (slot: InventorySlot) =>
  ([...MELEE_SLOTS, ...RANGED_SLOTS] as readonly string[]).includes(slot);
const normalized = (text: string) =>
  text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ł/g, 'l');

/** Prepared storage category, independent of weapon grip or wielding. */
export function weaponSlotKind(
  entry: InventoryEntry,
): 'melee' | 'ranged' | null {
  if (entry.item.type !== 'weapon') return null;
  if (entry.weapon)
    return ['melee', 'improvised'].includes(entry.weapon.category)
      ? 'melee'
      : 'ranged';
  if (entry.item.weaponProfile)
    return entry.item.weaponProfile.attackKind === 'melee' ? 'melee' : 'ranged';
  const category = normalized(entry.item.category);
  if (/biala|wrecz/.test(category)) return 'melee';
  if (/palna|dystans|miotana|laser|granat|wybuch|miny/.test(category))
    return 'ranged';
  return null;
}

/** Handbook handy examples include a grenade, a medpak and a spare magazine. */
export function canUseHandySlot(entry: InventoryEntry): boolean {
  if (entry.armor || entry.item.type === 'armor') return false;
  if (entry.item.type !== 'weapon') return true;
  if (entry.weapon) return entry.weapon.system === 'singleUse';
  return (
    /granat|wybuch|miny/.test(normalized(entry.item.category)) ||
    /^granat\b/.test(normalized(entry.item.name))
  );
}

export function allowedSlots(entry: InventoryEntry): InventorySlot[] {
  if (entry.armor) {
    const kind = entry.armor.kind;
    return [
      ['light', 'medium', 'heavy'].includes(kind) ? 'armor' : kind,
    ] as InventorySlot[];
  }
  if (entry.item.type === 'armor') return [];
  const kind = weaponSlotKind(entry);
  return [
    ...(kind === 'melee' ? MELEE_SLOTS : kind === 'ranged' ? RANGED_SLOTS : []),
    ...(canUseHandySlot(entry) ? HANDY_SLOTS : []),
  ];
}

export function isReadyWeapon(entry: InventoryEntry): boolean {
  if (
    !entry.weapon ||
    entry.item.type !== 'weapon' ||
    entry.parentId ||
    !['body', 'handy'].includes(entry.location)
  )
    return false;
  if (isLegacyHandSlot(entry.slot)) return true;
  return (
    (entry.location === 'body' &&
      isNumberedWeaponSlot(entry.slot) &&
      allowedSlots(entry).includes(entry.slot)) ||
    (entry.location === 'handy' &&
      isHandySlot(entry.slot) &&
      canUseHandySlot(entry))
  );
}

export function weaponGrip(entry: InventoryEntry): WeaponGrip {
  if (entry.grip) return entry.grip;
  if (entry.slot === 'bothHands') return 'twoHanded';
  if (isLegacyHandSlot(entry.slot)) return 'oneHanded';
  if (isNumberedWeaponSlot(entry.slot) || isHandySlot(entry.slot)) {
    if (
      entry.weapon?.twoHanded ||
      (entry.weapon &&
        ['short', 'intermediate', 'long', 'heavy'].includes(
          entry.weapon.category,
        ) &&
        !entry.weapon.handy)
    )
      return 'twoHanded';
  }
  return 'oneHanded';
}

/** Display projection only: historical snapshots are never rewritten during reads. */
function projectedSlots(inventory: Inventory): Map<string, InventorySlot> {
  const result = new Map<string, InventorySlot>();
  const reserved = new Set<InventorySlot>();
  for (const entry of inventory.entries) {
    if (!isLegacyHandSlot(entry.slot) && entry.slot !== 'none') {
      result.set(entry.id, entry.slot);
      reserved.add(entry.slot);
    }
  }
  for (const entry of inventory.entries) {
    if (result.has(entry.id)) continue;
    let candidates: readonly InventorySlot[] = [];
    if (isLegacyHandSlot(entry.slot)) {
      if (entry.armor?.kind === 'shield') candidates = ['shield'];
      else {
        const kind = weaponSlotKind(entry);
        candidates =
          kind === 'melee'
            ? MELEE_SLOTS
            : kind === 'ranged'
              ? RANGED_SLOTS
              : HANDY_SLOTS;
      }
    } else if (
      entry.slot === 'none' &&
      entry.location === 'handy' &&
      !entry.parentId &&
      entry.quantityMilli === 1000 &&
      canUseHandySlot(entry) &&
      !inventory.entries.some(
        (weapon) => weapon.installedMagazineId === entry.id,
      )
    ) {
      candidates = HANDY_SLOTS;
    }
    const available = candidates.find((slot) => !reserved.has(slot));
    result.set(entry.id, available ?? 'none');
    if (available) reserved.add(available);
  }
  return result;
}
export function displayedSlot(
  inventory: Inventory,
  entry: InventoryEntry,
): InventorySlot {
  return (
    projectedSlots(inventory).get(entry.id) ??
    (isLegacyHandSlot(entry.slot) ? 'none' : entry.slot)
  );
}
export function availableSlotOptions(
  inventory: Inventory,
  entry: InventoryEntry,
) {
  const projected = projectedSlots(inventory);
  return allowedSlots(entry).map((slot) => {
    const other = inventory.entries.find(
      (candidate) =>
        candidate.id !== entry.id && projected.get(candidate.id) === slot,
    );
    return {
      slot,
      label: SLOTS[slot],
      ...(other ? { occupiedBy: other.item.name } : {}),
    };
  });
}
