import type { InventoryEntry } from './inventoryModel';

// Explicit catalog identities; renamed inventory copies retain their rules.
const models = {
  revolver: [
    '3ac784bb-b970-553d-9a93-3bb9792b6b52',
    '1cd11bda-0c4e-5a9e-86f4-09583e0cb54b',
    '73ba5532-84ee-5f97-af7a-bbd13115fc83',
    'ccc03e79-4afe-5aea-81c0-c875887e1fe7',
  ],
  smg: [
    '22382256-9361-5de7-8e7a-50f67dc9283f',
    'e23d38d1-6446-5bdf-82a2-51a035ccec0a',
    '2a10aa7a-6009-5460-999d-e7224dbe567a',
    '4bc7fc3c-9526-590e-8ee6-d0f83a51c29d',
  ],
  axe: ['e668ea8e-4701-55db-adc9-0031cee95348'],
} as const;
export function weaponTrait(entry: InventoryEntry, trait: keyof typeof models) {
  return (
    entry.weapon?.family === trait ||
    (models[trait] as readonly string[]).includes(entry.weapon?.model ?? '')
  );
}
