import type { CharacterSheet } from './model';
import { ABILITIES, abilityNames, colorNames } from './model';
import { classes, origins } from './catalog';
import { deriveCharacter } from './derive';

export function changesHistory(
  before: CharacterSheet | null,
  after: CharacterSheet,
): boolean {
  if (!before) return false;
  if (
    ['baseScores', 'method', 'methodReason', 'originId'].some(
      (key) =>
        JSON.stringify(before[key as keyof CharacterSheet]) !==
        JSON.stringify(after[key as keyof CharacterSheet]),
    )
  )
    return true;
  return before.levels.some((l, i) => {
    const next = after.levels[i];
    return (
      !next ||
      l.classId !== next.classId ||
      JSON.stringify(l.choices) !== JSON.stringify(next.choices)
    );
  });
}
export function describeSheet(s: CharacterSheet): [string, string][] {
  const d = deriveCharacter(s);
  const choices = d.choices;
  const labels = new Map(
    choices.flatMap((c) => c.options.map((o) => [o.id, o.label] as const)),
  );
  const rows: [string, string][] = [
    ['Imię', s.identity.name || 'Bez imienia'],
    ['Opis postaci', s.identity.description || '—'],
    [
      'Wiek / wzrost / masa ciała',
      [s.identity.age, s.identity.height, s.identity.bodyWeight]
        .map((v) => v ?? '—')
        .join(' / ') + ' (lata / cm / kg)',
    ],
    [
      'Wielkość',
      {
        tiny: 'Malutka',
        small: 'Mała',
        medium: 'Średnia',
        large: 'Duża',
        huge: 'Wielka',
        gargantuan: 'Olbrzymia',
      }[s.identity.size],
    ],
    [
      'Cechy bazowe',
      ABILITIES.map(
        (a) => abilityNames[a] + ': ' + (s.baseScores[a] ?? '—'),
      ).join(', '),
    ],
    [
      'Metoda tworzenia',
      {
        'array-a': 'Tablica A',
        'array-b': 'Tablica B',
        'array-c': 'Tablica C',
        points: '27 punktów',
        gm: 'Decyzja MG',
      }[s.method] + (s.methodReason ? ': ' + s.methodReason : ''),
    ],
    ['Pochodzenie', origins.find((o) => o.id === s.originId)?.label ?? '—'],
    ['Kolor gry', colorNames[s.rulesContext.gameColor]],
    ['Bieżące PW', String(s.hpCurrent ?? '—')],
    [
      'Rozwój',
      s.advancementMode === 'xp' ? 'Punkty doświadczenia' : 'Kamienie milowe',
    ],
    [
      'Dziennik PD',
      s.xp
        .map((x) => String(x.amount) + (x.reason ? ': ' + x.reason : ''))
        .join('\n') || '—',
    ],
    ['Notatki', s.notes || '—'],
    ['Znajomi', s.contacts || '—'],
    ['Odkrycia', s.discoveries || '—'],
    [
      'Zapisane modyfikatory',
      s.overrides
        .map((o) => o.target + ' ' + o.mode + ' ' + o.value + ': ' + o.reason)
        .join('\n') || '—',
    ],
  ];
  s.levels.forEach((l, i) =>
    rows.push([
      'Poziom ' + (i + 1),
      classes[l.classId].label +
        ' · ' +
        colorNames[l.color] +
        '\n' +
        Object.entries(l.choices)
          .map(
            ([key, values]) =>
              (choices.find((c) => c.level === i && c.key === key)?.label ??
                'Zapisany wybór') +
              ': ' +
              values.map((v) => labels.get(v) ?? v).join(', '),
          )
          .join('\n'),
    ]),
  );
  return rows;
}
