import type { Item } from '../item';
import type { ClassId } from './model';
import type {
  Inventory,
  InventoryAction,
  InventoryEntry,
} from './inventoryModel';
import { catalogEntry, starterPack } from './inventoryCatalog';

export type StarterChoice = 'equipment' | 'gamble';
type Grant = { name: string; count?: number; alias?: string };
type StarterRule = {
  page: number;
  gamble: number;
  always?: Grant[];
  choice?: 'instrument' | 'tools';
  equipment: Grant[];
};
export const starterRules: Record<ClassId, StarterRule> = {
  brutal: {
    page: 67,
    gamble: 150,
    equipment: [
      { name: 'Kafar' },
      { name: 'Nóż taktyczny' },
      { name: 'Medpak' },
      { name: 'Obrzyn' },
      { name: '.12 Ga (b - breneka)', count: 10 },
      { name: 'Oszczep', count: 3 },
    ],
  },
  cwaniak: {
    page: 72,
    gamble: 150,
    choice: 'instrument',
    equipment: [
      { name: 'Koktajl Mołotowa', count: 2 },
      { name: 'Kurtka ćwiekowana' },
      { name: 'Medpak' },
      { name: 'Mały szuler' },
      { name: 'Nóż taktyczny' },
      { name: 'Papieros', count: 10 },
      { name: 'Trzydziestka ósemka' },
      { name: '.38 SPL', count: 12 },
    ],
  },
  spec: {
    page: 78,
    gamble: 170,
    choice: 'tools',
    equipment: [
      { name: 'Mały medyk' },
      { name: 'Medpak' },
      { name: 'B 93R' },
      { name: '9 mm', count: 15 },
      { name: 'Szoker' },
    ],
  },
  twardziel: {
    page: 86,
    gamble: 200,
    equipment: [
      { name: 'Empepiątka' },
      { name: '9 mm', count: 30 },
      { name: 'Plate carrier typ I' },
      { name: 'Bejsbol/Rurka', alias: 'Rura stalowa' },
    ],
  },
  zlodziej: {
    page: 91,
    gamble: 150,
    always: [{ name: 'Mały ślusarz' }],
    equipment: [
      { name: 'Kolczatki' },
      { name: 'Kulki stalowe' },
      { name: 'Kurtka ćwiekowana' },
      { name: 'Łuk tradycyjny' },
      { name: 'Strzała', count: 20 },
      { name: 'Medpak' },
      { name: 'Nóż taktyczny' },
      { name: 'Nóż do rzucania', count: 2 },
    ],
  },
  zwiadowca: {
    page: 96,
    gamble: 150,
    always: [{ name: 'Mały kłusownik' }],
    equipment: [
      { name: 'Kurtka ćwiekowana' },
      { name: 'Lewar M95' },
      { name: '.30-06', count: 10 },
      { name: 'Nóż taktyczny' },
      { name: 'Medpak' },
    ],
  },
};
export function starterComplete(inv: Inventory) {
  return inv.starterClaims.some((key) =>
    ['initial-loadout:equipment', 'initial-loadout:gamble'].includes(key),
  );
}
export function starterOptions(items: Item[], classId: ClassId) {
  return items.filter((item) =>
    starterRules[classId].choice === 'instrument'
      ? item.category.startsWith('Instrumenty muzyczne /') &&
        item.basePrice !== null &&
        item.basePrice.max <= 50
      : starterRules[classId].choice === 'tools' &&
        item.category === 'Narzędzia / Zestawy narzędzi',
  );
}
export function starterEquipmentAction(
  inventory: Inventory,
  items: Item[],
  classId: ClassId,
  choice: StarterChoice,
  selectedId = '',
  lighterId = '',
): Extract<InventoryAction, { kind: 'starter' }> {
  if (starterComplete(inventory))
    throw new Error('Wyposażenie startowe zostało już wybrane.');
  const rule = starterRules[classId];
  const entries: InventoryEntry[] = inventory.starterClaims.includes(
    'initial-equipment',
  )
    ? []
    : [starterPack(classId)];
  const add = (item: Item, count = 1, alias?: string) => {
    const first = catalogEntry(item);
    if (alias) first.item.name = alias;
    first.notes = `Wyposażenie startowe — Neuroshima: Ostatnia Era, s. ${rule.page}.`;
    // Weapons are independent instances; cartridges and consumables are stacks.
    if (first.weapon || first.armor || first.magazine) {
      entries.push(first);
      for (let n = 1; n < count; n++) {
        const copy = catalogEntry(item);
        copy.notes = first.notes;
        entries.push(copy);
      }
    } else {
      first.quantityMilli = count * 1000;
      entries.push(first);
    }
  };
  for (const grant of [
    ...(rule.always ?? []),
    ...(choice === 'equipment' ? rule.equipment : []),
  ]) {
    const item = items.find((i) => i.name === grant.name);
    if (!item)
      throw new Error(
        `Brak w katalogu: ${grant.name}. Odśwież katalog przed przyznaniem sprzętu.`,
      );
    add(item, grant.count, grant.alias);
  }
  if (rule.choice) {
    const selected = starterOptions(items, classId).find(
      (i) => i.id === selectedId,
    );
    if (!selected)
      throw new Error(
        rule.choice === 'instrument'
          ? 'Wybierz instrument do 50 G.'
          : 'Wybierz zestaw narzędzi.',
      );
    add(selected);
  }
  if (classId === 'cwaniak' && choice === 'equipment') {
    const lighter = items.find(
      (i) =>
        i.id === lighterId &&
        ['Zapalniczka plastikowa', 'Zapalniczka Zippo'].includes(i.name),
    );
    if (!lighter) throw new Error('Wybierz zapalniczkę.');
    add(lighter);
  }
  return { kind: 'starter', key: `initial-loadout:${choice}`, entries };
}
