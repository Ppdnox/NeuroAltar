import type { Ability, ClassId } from './model';
export interface CheckDefinition {
  id: string;
  label: string;
  ability: Ability;
}
const checks = (ability: Ability, entries: string): CheckDefinition[] =>
  entries.split('|').map((pair) => {
    const [id = '', label = ''] = pair.split(':');
    return { id, label, ability };
  });
export const skills = [
  ...checks('str', 'athletics:Atletyka'),
  ...checks(
    'dex',
    'acrobatics:Akrobatyka|stealth:Skradanie się|sleight:Zwinne dłonie',
  ),
  ...checks(
    'int',
    'history:Historia|medicine:Medycyna|nature:Przyroda|investigation:Śledztwo|technology:Technika',
  ),
  ...checks(
    'wis',
    'insight:Intuicja|perception:Percepcja|vehicles:Pojazdy|survival:Survival|animals:Tresura',
  ),
  ...checks(
    'cha',
    'deception:Oszustwo|persuasion:Perswazja|performance:Występy|intimidation:Zastraszanie',
  ),
];
export const tools = [
  ...checks('str', 'smith:Kowal'),
  ...checks(
    'int',
    'apothecary:Aptekarz|chemist:Chemik|hacker:Haker|jeweler:Jubiler|medic:Medyk|glass:Szklarz',
  ),
  ...checks(
    'wis',
    'distiller:Gorzelnik|cartographer:Kartograf|cook:Kucharz|butcher:Rzeźnik|gambler:Szuler',
  ),
  ...checks(
    'dex',
    'disguise:Charakteryzator|electronics:Elektronik|forger:Fałszerz|trapper:Kłusownik|tailor:Krawiec|mechanic:Mechanik|gunsmith:Rusznikarz|carpenter:Stolarz|locksmith:Ślusarz|tattoo:Tatuażysta',
  ),
];
export const weaponCategories = [
  'melee',
  'thrown',
  'short',
  'long',
  'intermediate',
  'heavy',
  'special',
] as const;
export const weaponNames: Record<string, string> = {
  melee: 'Biała',
  thrown: 'Miotana',
  short: 'Palna krótka',
  long: 'Palna długa',
  intermediate: 'Palna pośrednia',
  heavy: 'Palna ciężka',
  special: 'Specjalna',
};
export const armorNames: Record<string, string> = {
  light: 'Lekki pancerz',
  medium: 'Średni pancerz',
  heavy: 'Ciężki pancerz',
  shield: 'Tarcze',
};
export interface ClassDefinition {
  label: string;
  page: number;
  favorite: Ability;
  hitDie: 6 | 8;
  saves: Ability[];
  skillCount: number;
  skills: string[];
  tools: string[];
  toolCount: number;
  instruments: number;
  weapons: string[];
  armor: string[];
  professions: string[];
  progression: Record<number, string[]>;
}
const ids = (s: string) => s.split(' ').filter(Boolean);
export const classes: Record<ClassId, ClassDefinition> = {
  brutal: {
    label: 'Brutal',
    page: 67,
    favorite: 'str',
    hitDie: 8,
    saves: ['str', 'con'],
    skillCount: 2,
    skills: ids('athletics animals perception nature survival intimidation'),
    tools: [],
    toolCount: 0,
    instruments: 0,
    weapons: ids('melee short'),
    armor: ids('light medium shield'),
    professions: ['ganger', 'gladiator', 'mercenary'],
    progression: {
      1: ['Berserk', 'Goła klata'],
      2: ['Z bara', 'Wściekły cios'],
      3: ['Szósty zmysł'],
      5: ['Drugi atak', 'Brutalny cios'],
      7: ['Szaleńcza szarża', 'Solówa'],
      9: ['Paranoja'],
      11: ['Zabójczy cios'],
    },
  },
  cwaniak: {
    label: 'Cwaniak',
    page: 72,
    favorite: 'cha',
    hitDie: 6,
    saves: ['cha', 'dex'],
    skillCount: 4,
    skills: ids(
      'acrobatics stealth history deception persuasion performance intimidation sleight',
    ),
    tools: [],
    toolCount: 1,
    instruments: 2,
    weapons: ids('melee short'),
    armor: ids('light'),
    professions: ['star', 'preacher', 'mafia'],
    progression: {
      1: ['Motywacja', 'Szczęście'],
      2: ['Kolejka', 'Spieprzysz to!'],
      3: ['Szybka gadka'],
      4: ['Ekspert'],
      5: ['Cwaniacki zwód', 'Obelga'],
      7: ['Głowa do góry!'],
      9: ['Samouk'],
      11: ['Śmiertelna obelga'],
    },
  },
  spec: {
    label: 'Spec',
    page: 78,
    favorite: 'int',
    hitDie: 6,
    saves: ['int', 'wis'],
    skillCount: 4,
    skills: ids(
      'history insight medicine vehicles nature investigation technology',
    ),
    tools: [],
    toolCount: 2,
    instruments: 0,
    weapons: ids('melee short'),
    armor: ids('light'),
    professions: ['chemist', 'medic', 'engineer'],
    progression: {
      1: ['Dobra rada', 'Inteligentna obrona'],
      2: ['Łeb jak sklep', 'Szybkie badanie'],
      3: ['Szybka produkcja'],
      4: ['Szybkie ręce'],
      5: ['Wykształciuch', 'Zdolność z pochodzenia'],
      7: ['Specjalizacja', 'Trajektoria'],
      9: ['Bystrzacha'],
      11: ['W czuły punkt', 'Szybka produkcja (2)'],
    },
  },
  twardziel: {
    label: 'Twardziel',
    page: 86,
    favorite: 'con',
    hitDie: 8,
    saves: ['con', 'dex'],
    skillCount: 2,
    skills: ids(
      'acrobatics athletics insight perception vehicles survival animals intimidation',
    ),
    tools: [],
    toolCount: 0,
    instruments: 0,
    weapons: [...weaponCategories],
    armor: ids('light medium heavy shield'),
    professions: ['cowboy', 'roadwarrior', 'soldier'],
    progression: {
      1: ['Wyjadacz', 'Kondycha', 'Ulubiona broń'],
      2: ['Zryw', 'Przycelowanie'],
      3: ['Twardość'],
      5: ['Drugi atak'],
      7: ['Wyjadacz (2)'],
      9: ['Nie klękam'],
      10: ['Trzeci atak'],
    },
  },
  zlodziej: {
    label: 'Złodziej',
    page: 91,
    favorite: 'dex',
    hitDie: 6,
    saves: ['int', 'dex'],
    skillCount: 4,
    skills: ids(
      'acrobatics insight deception perception persuasion stealth investigation technology performance intimidation sleight',
    ),
    tools: ['locksmith'],
    toolCount: 0,
    instruments: 0,
    weapons: ids('melee thrown short'),
    armor: ids('light'),
    professions: ['courier', 'rat', 'assassin'],
    progression: {
      1: ['Specjalizacja', 'Bolesny atak', 'Szybkie nogi'],
      2: ['Ulubiona broń', 'Kocie kości'],
      3: ['Podstępny atak'],
      4: ['Elektronik'],
      5: ['Szybkość kota', 'Specjalizacja (2)'],
      7: ['Matrix'],
      9: ['Dziewięć żyć'],
      11: ['Saper'],
    },
  },
  zwiadowca: {
    label: 'Zwiadowca',
    page: 96,
    favorite: 'wis',
    hitDie: 8,
    saves: ['con', 'wis'],
    skillCount: 3,
    skills: ids(
      'athletics insight perception nature survival stealth investigation animals',
    ),
    tools: ['trapper'],
    toolCount: 1,
    instruments: 0,
    weapons: ids('melee thrown short long'),
    armor: ids('light medium'),
    professions: ['mutanthunter', 'judge', 'machinehunter'],
    progression: {
      1: ['Mój wróg', 'Mój biom', 'Ulubiona broń'],
      2: ['Kłusownik', 'Wyjadacz'],
      3: ['Cichy krok'],
      5: ['Drugi atak', 'Mój wróg (2)'],
      7: ['Sportowiec', 'Wyczulone zmysły'],
      9: ['Mój wróg (3)', 'Ulubiona broń (2)'],
      11: ['Wyjadacz (2)', 'Pogoń'],
    },
  },
};
export interface OriginDefinition {
  id: string;
  label: string;
  page: number;
  abilities: Ability[];
  choices: { id: string; label: string; description: string }[];
}
function origin(
  id: string,
  label: string,
  page: number,
  abilities: Ability[],
  entries: string[],
): OriginDefinition {
  return {
    id,
    label,
    page,
    abilities,
    choices: entries.map((s) => {
      const [key = '', name = '', description = ''] = s.split('|');
      return { id: key, label: name, description };
    }),
  };
}
export const origins = [
  origin(
    'asgard',
    'Asgard',
    60,
    ['con', 'int'],
    [
      'new|Nówka sztuka|Przedmiot do 100 gb.',
      'education|Przedwojenna edukacja|Wiedza i wybrane narzędzie.',
      'nano|Nano-Tech|Obsługa elektroniki; wybór biegłości.',
    ],
  ),
  origin(
    'desert',
    'Człowiek Pustyni',
    60,
    ['con', 'wis'],
    [
      'diet|Dieta cud|Kucharz; mniejsze zapotrzebowanie na żywność i wodę, lepsze leczenie.',
      'ghost|Duch pustyni|Warunkowe Skradanie się i Survival na piasku.',
      'self|Polegam tylko na sobie|Kowal; premie własnoręcznie wykonanej broni niepalnej.',
    ],
  ),
  origin(
    'detroit',
    'Detroit',
    61,
    ['dex', 'wis'],
    [
      'sweat|Siódme poty|Pojazdy; szybkość pojazdu +50%.',
      'engine|Jeśli ma silnik, to ruszy|Mechanik; prace przy pojazdach.',
      'ride|Ale jazda!|Ignorowanie niestabilnego podłoża.',
    ],
  ),
  origin(
    'appalachia',
    'Federacja Appalachów',
    61,
    ['str', 'cha'],
    [
      'miner|Górnik z dziada pradziada|Ułatwienie Atletyki, podwojony udźwig.',
      'gun|Wychuchana spluwa|Rusznikarz; wybrana broń bez zacięcia.',
      'noble|Szlachetne urodzenie|Dwie wybrane biegłości.',
    ],
  ),
  origin(
    'miami',
    'Miami',
    62,
    ['str', 'dex'],
    [
      'alligator|Człowiek-aligator|Szybkość pływania równa bazowej szybkości.',
      'sick|Ja już swoje odchorowałem|Ułatwienie RO Kondycji.',
      'wanderer|Włóczykij|Kartograf; ruch po piasku i bagnach.',
    ],
  ),
  origin(
    'mississippi',
    'Missisipi',
    62,
    ['str', 'wis'],
    [
      'smell|Coś mi tu śmierdzi|Wyczuwanie mutanta w 9 m; identyfikacja Percepcja ST 15.',
      'acid|Kwas w żyłach|Warunkowe RO przeciw truciznom i kwasom.',
      'drowned|Chodźmy, na pewno już utonął|Wydłużony oddech i Ułatwienie pływania.',
    ],
  ),
  origin(
    'newyork',
    'Nowy Jork',
    63,
    ['int', 'cha'],
    [
      'education|Edukacja|Dwie wybrane biegłości.',
      'gamble|Gambling we krwi|Dostępność +5 punktów procentowych przed mnożnikiem Koloru.',
      'patriot|Czas patriotów|+5 do jednego testu cechy lub RO, raz na długi odpoczynek.',
    ],
  ),
  origin(
    'hegemony',
    'Południowa Hegemonia',
    63,
    ['str', 'con'],
    [
      'killer|Urodzony morderca|Jednorazowy przerzut jedynki kości obrażeń.',
      'dog|Wiesz, zjadłem własnego psa|Zastraszanie i rzeźnik; Ułatwienie testu.',
      'stubborn|Zawzięty sukinkot|Powstanie z 1 PW przed rzutem przeciw śmierci, raz na długi odpoczynek.',
    ],
  ),
  origin(
    'outpost',
    'Posterunek',
    64,
    ['int', 'wis'],
    [
      'simulator|Na symulatorach to działało|Dwie wybrane biegłości.',
      'hitech|Hi-Tech|Ułatwienie obsługi elektroniki.',
      'moloch|Moloch? Coś słyszałem|Wiedza i RO przeciw maszynom Molocha.',
    ],
  ),
  origin(
    'saltlake',
    'Salt Lake City',
    64,
    ['wis', 'cha'],
    [
      'preacher|Cholerny kaznodzieja|Perswazja; warunki wiary.',
      'before|Przed wojną wszystko było lepsze|Historia i Medycyna; wiedza przedwojenna.',
      'believe|Wierzę|Przedmiot do 5 gb raz na długi odpoczynek.',
    ],
  ),
  origin(
    'texas',
    'Teksas',
    65,
    ['con', 'cha'],
    [
      'horse|Człowiek zwany koniem|Dwie z trzech biegłości: Atletyka, Tresura, Medycyna.',
      'quinn|Doktor Quinn|Medycyna; Ułatwienie testu.',
      'healthy|Zdrowa okolica|RO Kondycji; Ułatwienie testu.',
    ],
  ),
  origin(
    'vegas',
    'Vegas',
    65,
    ['dex', 'cha'],
    [
      'gambler|Hazardzista|Zwinne dłonie i Oszustwo.',
      'telepath|Telepata|Intuicja; Ułatwienie testu.',
      'luck|Fart|Przerzut naturalnej 1 raz na krótki lub długi odpoczynek.',
    ],
  ),
];
export interface ProfessionDefinition {
  label: string;
  page: number;
  abilities: string[];
}
export const professions: Record<string, ProfessionDefinition> = {
  ganger: {
    label: 'Ganger',
    page: 69,
    abilities: [
      'Dwóch na jednego',
      'Ja i mój gang',
      'Jeden z nich',
      'Odważny czy głupi',
    ],
  },
  gladiator: {
    label: 'Gladiator',
    page: 69,
    abilities: [
      'Nie do zdarcia',
      'Łyżeczka',
      'Zew areny',
      'Zawołajcie kolegów',
    ],
  },
  mercenary: {
    label: 'Najemnik',
    page: 70,
    abilities: ['Maszyna do zabijania', 'Reputacja', 'Skuteczny cios'],
  },
  star: {
    label: 'Gwiazda',
    page: 74,
    abilities: ['Kakofonia', 'Let’s Rock', 'Stylówa', 'Za garść gambli'],
  },
  preacher: {
    label: 'Kaznodzieja Nowej Ery',
    page: 75,
    abilities: ['Amen', 'Łaska Boża', 'Mój Bóg kule nosi', 'Tarcza Wiary'],
  },
  mafia: {
    label: 'Mafiozo',
    page: 75,
    abilities: ['Bezlitosny przywódca', 'Renoma', 'Moja prawa ręka'],
  },
  chemist: {
    label: 'Chemik',
    page: 80,
    abilities: ['Smakuje jak arszenik', 'Pirotechnika', 'Rusznikarstwo'],
  },
  medic: {
    label: 'Medyk',
    page: 81,
    abilities: ['Doktor Brain', 'Krwawy anioł', 'Łapiduch', 'Farmacja'],
  },
  engineer: {
    label: 'Monter',
    page: 82,
    abilities: ['Mechanika', 'Hakerstwo', 'Serwisowanie'],
  },
  cowboy: {
    label: 'Kowboj',
    page: 88,
    abilities: ['Clint', 'Rewolwerowiec', 'Zawsze w siodle'],
  },
  roadwarrior: {
    label: 'Wojownik Autostrady',
    page: 88,
    abilities: ['Drzwi w drzwi', 'Kaskader', 'Pancerna fura'],
  },
  soldier: {
    label: 'Żołnierz',
    page: 89,
    abilities: ['Jak dbasz, tak masz', 'Rutyna', 'Trening w zbroi'],
  },
  courier: {
    label: 'Kurier',
    page: 93,
    abilities: ['Skrytka', 'Slang', 'Znajomości'],
  },
  rat: {
    label: 'Szczur',
    page: 93,
    abilities: ['A co mi tam!', 'Szary', 'Truciciel', 'Zwinność szczura'],
  },
  assassin: {
    label: 'Zabójca',
    page: 94,
    abilities: ['Jeden strzał', 'Kamuflaż', 'Strzelec'],
  },
  mutanthunter: {
    label: 'Łowca Mutantów',
    page: 98,
    abilities: [
      'Bez tajemnic',
      'Mutant na śniadanie',
      'Pogromca',
      'Oswajanie zwierząt',
    ],
  },
  judge: {
    label: 'Sędzia',
    page: 100,
    abilities: ['Jeden z nas', 'Rzuć broń i gleba!', 'Partner'],
  },
  machinehunter: {
    label: 'Zabójca Maszyn',
    page: 101,
    abilities: ['Emiter EMP', 'Empiryk', 'Słaby punkt'],
  },
};
export const xpThresholds = [
  0, 50, 150, 300, 500, 800, 1100, 1400, 1900, 2400, 2900, 3400,
];

export function classRulePage(
  id: ClassId,
  level: number,
  label: string,
): number {
  if (id === 'brutal') return level >= 11 ? 69 : level >= 3 ? 68 : 67;
  if (id === 'cwaniak') return level >= 3 ? 73 : 72;
  if (id === 'spec') return level >= 3 ? 79 : 78;
  if (id === 'twardziel') return level >= 2 ? 87 : 86;
  if (id === 'zlodziej') return level >= 11 ? 93 : level >= 3 ? 92 : 91;
  return level >= 3 ? 98 : level >= 2 || label === 'Ulubiona broń' ? 97 : 96;
}
export function professionRulePage(id: string): number {
  const overrides: Record<string, number> = {
    'gladiator.2': 70,
    'gladiator.3': 70,
    'chemist.2': 81,
    'medic.3': 82,
    'engineer.1': 83,
    'engineer.2': 84,
    'roadwarrior.2': 89,
    'rat.1': 94,
    'rat.2': 94,
    'rat.3': 94,
    'mutanthunter.2': 99,
    'mutanthunter.3': 99,
  };
  return overrides[id] ?? professions[id.split('.')[0]!]!.page;
}
