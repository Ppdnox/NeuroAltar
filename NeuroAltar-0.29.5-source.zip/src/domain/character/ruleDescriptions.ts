import type { ClassId } from './model';

type ClassLevels = Record<ClassId, number>;
type Description = string | ((levels: ClassLevels) => string);

// Neuroshima: Ostatnia Era, printed pages 67–101. These are rule summaries;
// automation and applicability remain the responsibility of the rule handlers.
const secondAttack =
  'W swojej turze wykonujesz dwa ataki w ramach jednej akcji Atakowanie. Drugi atak z kilku klas nie sumuje się.';
const favoriteWeapon =
  'Po wykonaniu akcji Atakowanie ulubionym modelem broni możesz wykonać nim jeszcze jeden atak w Akcji Bonusowej. Broń dystansowa musi być załadowana. Podczas Długiego odpoczynku możesz zmienić jeden ulubiony model po godzinie treningu.';
const veteran =
  'Wybierz jedną zdolność, której jeszcze nie masz. Obsługa pancerza: +2 TT podczas noszenia pancerza. Rzeźnik: +3 obrażeń broni, jeśli w drugiej ręce nie trzymasz innej broni. Sokole oko: +3 do ataków bronią palną, dystansową i rzucaną. Stalowy nadgarstek: brak Utrudnienia za jednoręczny strzał bronią krótką lub pistoletem maszynowym; broń krótka zyskuje właściwość lekka.';
const scoutVeteran =
  veteran +
  ' Jeździec: kierowanie wierzchowcem bez rąk, brak Utrudnienia strzałów za niestabilne podłoże, wsiadanie/zsiadanie za 1,5 m ruchu i +PB do TT wierzchowca. Zasadzka: Ułatwienie ataków do końca swojej tury przeciw zaskoczonemu celowi lub celowi, przed którym działasz w pierwszej turze walki.';
const favoredEnemy = ({ zwiadowca }: ClassLevels) => {
  const rank = 1 + Math.floor((zwiadowca - 1) / 4);
  return `Wybierasz typy wrogów spośród Ludzi, Maszyn, Mutantów, Potworów i Zwierząt: obecnie ${rank}. Przeciw wybranym typom masz +${rank} do Testu Ataku i +${rank}k6 obrażeń. Masz też Ułatwienie Survivalu podczas ich tropienia i testów Inteligencji dotyczących wiedzy o nich. Premie stosujesz tylko po rozpoznaniu właściwego typu celu. Kolejne typy wybierasz na 5. i 9. poziomie Zwiadowcy.`;
};
const quickProduction = ({ spec }: ClassLevels) =>
  `Raz między Krótkimi lub Długimi odpoczynkami możesz wytworzyć drobne przedmioty o łącznej wartości do ${spec >= 11 ? 50 : 25} G. Potrzebujesz odpowiednich narzędzi, schematów i surowców. Podstawowy czas wynosi 1 minutę na 1 G wartości przedmiotów. Na 11. poziomie Speca limit rośnie z 25 do 50 G.`;

export const classRuleDescriptions: Record<string, Description> = {
  'class.brutal.1.0': ({ brutal }) =>
    `Akcja Bonusowa: wpadasz w Berserk na 10 rund, do końca swojej ostatniej tury. Masz Ułatwienie testów i RO Siły oraz +1k${6 + 2 * Math.floor((brutal - 1) / 3)} obrażeń przy atakach opartych na Sile. Po przeznaczeniu całej Szybkości na zbliżenie do widzianego lub słyszanego przeciwnika możesz w Akcji Bonusowej Przyspieszyć w jego kierunku. Bez pancerza, hełmu i tarczy dodajesz modyfikator Siły do TT. Nieprzytomność, Obezwładnienie lub Zauroczenie przerywają Berserk; po zakończeniu nie wykonujesz żadnej akcji do końca swojej następnej tury. Masz ${2 + Math.floor((brutal - 1) / 3)} użyć, odnawianych po Długim odpoczynku.`,
  'class.brutal.1.1':
    'Bez pancerza, hełmu i tarczy twoja TT wynosi 10 + modyfikator Zręczności + modyfikator Kondycji. Wybierasz ten wzór albo inny dostępny wzór TT; nie sumujesz ich.',
  'class.brutal.2.0':
    'Podczas Berserka możesz w Akcji Bonusowej Odepchnąć dużą lub mniejszą istotę. Cel wykonuje RO na Siłę lub Zręczność o ST 8 + twój modyfikator Siły + PB. Porażka pozwala ci odsunąć cel o 1,5 m albo go Powalić.',
  'class.brutal.2.1': ({ brutal }) =>
    `Raz w rundzie po trafieniu atakiem opartym na Sile możesz dodać 1–3 kości k6 obrażeń. Twoja pula wynosi ${brutal}k6, po jednej kości na poziom Brutala; wydane kości odnawia Długi odpoczynek.`,
  'class.brutal.3.0':
    'Masz Ułatwienie RO Zręczności przeciw zagrożeniom, które możesz zarejestrować zmysłami, np. pułapkom, granatom lub długiej serii. Szósty zmysł nie działa podczas Oślepienia, Ogłuszenia ani Nieprzytomności.',
  'class.brutal.5.0': secondAttack,
  'class.brutal.5.1':
    'Gdy używasz Wściekłego ciosu w ataku wręcz, możesz dodać jeden efekt zależny od obrażeń: obuchowe — Powalenie celu najwyżej o jeden rozmiar większego; cięte — kara 1k4 do jego Testów Ataku; kłute — Szybkość celu mniejsza o 6 m. Kara do ataku i ruchu trwa do początku twojej następnej tury. Takie same efekty się nie kumulują.',
  'class.brutal.7.0':
    'Twoja Szybkość rośnie o 3 m. Po wykonaniu Przyspieszenia ataki dystansowe przeciw tobie mają Utrudnienie do początku twojej następnej tury.',
  'class.brutal.7.1':
    'Akcja Bonusowa: prowokujesz widzianą istotę w zasięgu 18 m do atakowania tylko ciebie. Cel wykonuje RO Inteligencji o ST 8 + twój modyfikator Siły + PB. Efekt po porażce trwa, dopóki istota cię widzi lub zda RO na końcu swojej następnej tury.',
  'class.brutal.9.0':
    'Nie możesz zostać zaskoczony i wykonujesz testy Inicjatywy z Ułatwieniem.',
  'class.brutal.11.0':
    'Przy trafieniu krytycznym atakiem wręcz potrajasz kości obrażeń zamiast je podwajać. Stałe modyfikatory dodajesz jeden raz.',

  'class.cwaniak.1.0': ({ cwaniak }) =>
    `Reakcja przed poznaniem efektu testu: sojusznik w zasięgu 18 m dodaje 1k${6 + 2 * Math.floor((cwaniak - 1) / 4)} do swojego Testu k20. Liczba użyć równa modyfikatorowi Charyzmy; odnawia ją Krótki lub Długi odpoczynek.`,
  'class.cwaniak.1.1': ({ cwaniak }) =>
    `Raz w rundzie możesz powtórzyć dowolny niezadowalający test, zachowując jego Ułatwienie lub Utrudnienie. Musisz przyjąć nowy wynik. Masz ${1 + Math.floor((cwaniak - 1) / 3)} użyć, odnawianych po Długim odpoczynku.`,
  'class.cwaniak.2.0': ({ cwaniak }) =>
    `Podczas Krótkiego odpoczynku częstujesz towarzyszy napitkiem. Każdy pijący odzyskuje dodatkowo 1k${4 + 2 * Math.floor((cwaniak - 1) / 4)} PW za każdą wydaną w tym odpoczynku Kość Wytrzymałości.`,
  'class.cwaniak.2.1':
    'Reakcja po udanym Teście Ataku lub Rzucie Obronnym widzianej istoty w zasięgu 18 m: cel powtarza rzut i wybiera gorszy wynik. Liczba użyć równa modyfikatorowi Charyzmy; odnawia ją Krótki lub Długi odpoczynek.',
  'class.cwaniak.3.0':
    'W czasie walki możesz wykonać Wpływanie w Akcji Bonusowej, np. zastraszyć, oszukać lub uspokoić przeciwnika. Wybór testu, ST i możliwy skutek zależą od sytuacji i nastawienia celu.',
  'class.cwaniak.4.0':
    'Wybierasz dwie posiadane biegłości w umiejętnościach albo jedną w umiejętności i jedną w narzędziach. Zyskujesz w nich Specjalizację: PB do tych testów liczy się podwójnie.',
  'class.cwaniak.5.0':
    'Jeżeli nie nosisz ciężkiego pancerza, możesz w Akcji Bonusowej wykonać Odstąpienie i przemieścić się przez obszar przeciwników bez prowokowania ataków okazyjnych.',
  'class.cwaniak.5.1':
    'Akcja zamiast Atakowania: obrażasz istotę w zasięgu 18 m, która cię widzi i słyszy; nie musi rozumieć twoich słów. Do końca twojej następnej tury jej ataki na kogoś innego niż ty mają Utrudnienie. Liczba użyć równa PB, odnawiana po Krótkim lub Długim odpoczynku.',
  'class.cwaniak.7.0':
    'Akcja: rozpoczynasz występ trwający do końca twojej następnej tury. Ty i słyszący cię sojusznicy w zasięgu 18 m automatycznie zdajecie RO przeciw Przerażeniu.',
  'class.cwaniak.9.0':
    'Na 9. poziomie Cwaniaka zyskujesz biegłość w dwóch wybranych umiejętnościach albo jednej umiejętności i jednym zestawie narzędzi.',
  'class.cwaniak.11.0':
    'Twoja Obelga zadaje dodatkowo obrażenia psychiczne równe wynikowi jednej kości k6 pomnożonemu przez modyfikator Charyzmy. Nie jest to rzut tyloma kośćmi, ile wynosi modyfikator. Cel sprowadzony Obelgą do 0 PW upada pogrążony w rozpaczy.',

  'class.spec.1.0':
    'Akcja Bonusowa: jeden słyszący cię sojusznik otrzymuje premię równą twojemu modyfikatorowi Inteligencji do Testu Cechy, Ataku lub RO, do początku twojej następnej tury. Liczba użyć równa PB, odnawiana po Krótkim lub Długim odpoczynku.',
  'class.spec.1.1':
    'Reakcja po trafieniu, przed poznaniem obrażeń: zwiększasz swoją TT o modyfikator Inteligencji, aż do początku swojej następnej tury, co może zapobiec trafieniu. Liczba użyć równa modyfikatorowi Inteligencji; odnawia ją Krótki lub Długi odpoczynek.',
  'class.spec.2.0': ({ spec }) =>
    `Do testu Inteligencji lub dowolnego zestawu narzędzi możesz dodać 1k${Math.min(12, 2 + 2 * Math.floor(spec / 2))}. Masz tyle kości, ile wynosi PB. Pula odnawia się po Długim odpoczynku.`,
  'class.spec.2.1':
    'W walce możesz wykonać Badanie w Akcji Bonusowej. Odpowiednia umiejętność pozwala szybko zdobyć informacje o otoczeniu, urządzeniu lub przeciwniku; np. Technika o ST 15 może ujawnić PW lub TT maszyny.',
  'class.spec.3.0': quickProduction,
  'class.spec.4.0':
    'W swojej turze zyskujesz jedną dodatkową akcję wyłącznie na Używanie, poza zwykłą Akcją i Akcją Bonusową. Liczba użyć równa modyfikatorowi Zręczności; odnawia ją Krótki lub Długi odpoczynek.',
  'class.spec.5.0':
    'Zyskujesz dwie wybrane biegłości w umiejętnościach albo dwie biegłości w zestawach narzędzi.',
  'class.spec.5.1':
    'Wybierasz drugą, jeszcze nieposiadaną zdolność swojego pochodzenia. Nie otrzymujesz ponownie początkowego zwiększenia cech.',
  'class.spec.7.0':
    'Wybierasz dwie posiadane biegłości w umiejętnościach lub narzędziach, także po jednej z każdej grupy. Zyskujesz Specjalizację: PB do tych testów liczy się podwójnie.',
  'class.spec.7.1':
    'Do Testu Ataku dystansowego możesz dodać swój modyfikator Inteligencji. Liczba użyć równa PB; odnawia ją Długi odpoczynek.',
  'class.spec.9.0':
    'Do testów wszystkich umiejętności, w których nie masz biegłości, dodajesz połowę PB, zaokrągloną w dół.',
  'class.spec.11.0':
    'Do zadawanych obrażeń możesz dodać swój modyfikator Inteligencji. Zachowaj ograniczenia wybranego trybu ataku dotyczące dodawania modyfikatorów.',
  'class.spec.11.1': quickProduction,

  'class.twardziel.1.0': veteran,
  'class.twardziel.1.1': ({ twardziel }) =>
    `Akcja Bonusowa: odzyskujesz 1k8 + ${twardziel} PW (poziom Twardziela). Liczba użyć równa modyfikatorowi Kondycji; odnawia ją Długi odpoczynek.`,
  'class.twardziel.1.2': ({ twardziel }) =>
    `Możesz mieć ${1 + Math.floor((twardziel - 1) / 3)} ulubionych modeli broni; kolejne wybierasz na poziomach 4, 7 i 10. ${favoriteWeapon}`,
  'class.twardziel.2.0':
    'W swojej turze możesz wykonać jedną dodatkową Akcję albo Akcję Bonusową. Zryw ma jedno użycie, odnawiane po Krótkim lub Długim odpoczynku.',
  'class.twardziel.2.1':
    'Akcja Bonusowa przed atakiem: wybierasz część ciała lub maszyny. Ręka: TT +3, upuszczenie trzymanego przedmiotu. Noga: TT +2, Powalenie. Głowa/jednostka centralna: TT +5, trafienie krytyczne. Opona/gąsienica: TT +4, połowa Szybkości do naprawy. Tętnica/hydraulika: TT +4, utrata 1k6 PW na początku każdej tury do opatrzenia lub naprawy.',
  'class.twardziel.3.0': ({ twardziel }) =>
    `Po nieudanym Rzucie Obronnym, także Rzucie Przeciw Śmierci, możesz dodać do wyniku jedną kość k${2 + 2 * Math.floor(twardziel / 3)}. Pula kości równa modyfikatorowi Kondycji; odnawia ją Długi odpoczynek.`,
  'class.twardziel.5.0': secondAttack,
  'class.twardziel.7.0': 'Wybierasz drugą zdolność Wyjadacza. ' + veteran,
  'class.twardziel.9.0':
    'Masz biegłość we wszystkich sześciu Rzutach Obronnych. Nie dodaje to PB do Rzutu Przeciw Śmierci.',
  'class.twardziel.10.0':
    'W swojej turze możesz wykonać trzy ataki w ramach jednej akcji Atakowanie. Zastępuje to dwa ataki ze zdolności Drugi atak.',

  'class.zlodziej.1.0':
    'Wybierasz jedną posiadaną biegłość w umiejętności i jedną w narzędziach. Zyskujesz w nich Specjalizację, więc PB liczy się podwójnie. Na 5. poziomie wybierasz jeszcze jedną biegłość w umiejętności lub narzędziach.',
  'class.zlodziej.1.1': ({ zlodziej }) =>
    `Raz na turę możesz dodać ${Math.ceil(zlodziej / 2)}k6 obrażeń jednemu celowi, gdy trafiasz bronią przy użyciu Zręczności z Ułatwieniem. Ułatwienie nie jest potrzebne, jeśli w odległości 1,5 m od celu stoi twój sojusznik bez Obezwładnienia, a twój atak nie ma Utrudnienia.`,
  'class.zlodziej.1.2':
    'Możesz wykonać Odstąpienie, Przyspieszenie albo Ukrywanie się w Akcji Bonusowej.',
  'class.zlodziej.2.0':
    'Wybierasz jeden ulubiony model broni, w którym masz biegłość. ' +
    favoriteWeapon,
  'class.zlodziej.2.1': ({ zlodziej }) =>
    `Masz pulę kości k${4 + 2 * Math.floor((zlodziej - 2) / 3)} równą modyfikatorowi Zręczności, odnawianą po Długim odpoczynku. Możesz użyć jednej lub kilku kości: w Reakcji dodać do Ukrywania się po wykryciu przez wroga; w Reakcji zmniejszyć obrażenia od upadku; albo dodać do niezadowalającej Akrobatyki przed poznaniem skutku testu.`,
  'class.zlodziej.3.0':
    'Zamiast dodatkowych obrażeń Bolesnego ataku wybierasz jeden efekt: Krwawienie żywej istoty — 1k8 obrażeń na początku jej tur do opatrzenia; Spowolnienie — Szybkość mniejsza o 1k6 × 1,5 m do końca twojej następnej tury; Oślepienie — do końca twojej następnej tury. Takie same efekty się nie kumulują.',
  'class.zlodziej.4.0':
    'Przeciw elektronicznym zabezpieczeniom wykonujesz testy narzędzi małego ślusarza lub małego elektronika z Ułatwieniem.',
  'class.zlodziej.5.0':
    'Szybkość rośnie o 3 m. Reakcja po obrażeniach z bezpośredniego ataku pozwala zmniejszyć je o połowę, zaokrąglając w dół; nie działa na obrażenia psychiczne. Możesz także dodać jedną Kocią kość do testu Inicjatywy.',
  'class.zlodziej.5.1':
    'Wybierasz jeszcze jedną posiadaną biegłość w umiejętności lub narzędziach. Zyskujesz w niej Specjalizację, czyli podwójną PB do testu.',
  'class.zlodziej.7.0':
    'Gdy atak obszarowy pozwala wykonać RO Zręczności o połowę obrażeń, możesz otrzymać 0 obrażeń po sukcesie albo połowę po porażce, zaokrągloną w dół. Liczba użyć równa PB, odnawiana po Długim odpoczynku.',
  'class.zlodziej.9.0':
    'Zyskujesz dwa zastosowania Kocich kości: w Reakcji możesz dodać wynik jednej kości do TT do początku swojej następnej tury; możesz też dodać jedną kość do dowolnego RO, także Rzutu Przeciw Śmierci.',
  'class.zlodziej.11.0':
    'W teście umiejętności, w której masz Specjalizację, możesz potraktować wynik 1–9 na k20 jako 10. Jedno użycie odnawiane po Krótkim lub Długim odpoczynku.',

  'class.zwiadowca.1.0': favoredEnemy,
  'class.zwiadowca.1.1': ({ zwiadowca }) =>
    `Liczba ulubionych biomów: ${2 + Math.floor((zwiadowca - 1) / 3)}. Zaczynasz z dwoma i dodajesz po jednym na poziomach 4, 7 i 10. W testach Inteligencji i Mądrości dotyczących tych biomów masz Ułatwienie. Podczas podróży pieszej trudny teren nie spowalnia drużyny, nie możesz zostać zaskoczony, a podróżując samotnie skradasz się w normalnym tempie. Osiem godzin poszukiwań pozwala wyżywić cztery osoby przez dobę. Tropiąc, rozpoznajesz liczbę i rozmiar istot oraz wiek śladów. Korzyści wymagają właściwego biomu.`,
  'class.zwiadowca.1.2': favoriteWeapon,
  'class.zwiadowca.2.0':
    'Z narzędziami małego kłusownika możesz w minutę wykonać test Survivalu albo narzędzi i zbudować pułapkę. Jej zauważenie, wyzwolenie się lub uniknięcie części obrażeń ma ST 8 + twój modyfikator Mądrości + PB. ST budowy: potykacz/alarm 5, wnyki/sieć 10, granat lub broń biała 15, broń samoczynna 20. Potrzebujesz odpowiednio sieci, granatu lub broni; szczegóły pułapki ustalasz z MG.',
  'class.zwiadowca.2.1': scoutVeteran,
  'class.zwiadowca.3.0':
    'Nie otrzymujesz Utrudnienia Skradania się wynikającego z pancerza. Bez ciężkiego pancerza masz Ułatwienie testów Ukrywania się. Trudny teren nie spowalnia twojego ruchu.',
  'class.zwiadowca.5.0': secondAttack,
  'class.zwiadowca.5.1': favoredEnemy,
  'class.zwiadowca.7.0':
    'Twoja Szybkość rośnie o 3 m. Masz Ułatwienie Atletyki podczas wspinania, pływania i skakania.',
  'class.zwiadowca.7.1':
    'Masz stałe Ułatwienie testów Percepcji. Twoja Pasywna Percepcja rośnie o 5.',
  'class.zwiadowca.9.0': favoredEnemy,
  'class.zwiadowca.9.1':
    'Możesz mieć jednocześnie dwa ulubione modele broni. ' + favoriteWeapon,
  'class.zwiadowca.11.0': 'Wybierasz drugą zdolność Wyjadacza. ' + scoutVeteran,
  'class.zwiadowca.11.1':
    'Wykonujesz z Ułatwieniem Rzuty Obronne, których porażka powodowałaby otrzymanie Wyczerpania.',
};

export const professionRuleDescriptions: Record<string, Description> = {
  'profession.ganger.0':
    'Jeśli atakujesz wręcz istotę zaatakowaną w ten sam sposób przez twojego sojusznika, masz +2 do Testów Ataku wręcz przeciw niej do końca swojej tury.',
  'profession.ganger.1':
    'Podczas twojego Berserka sojusznicy w promieniu 3 m od ciebie mają Ułatwienie Testów Ataku przeciw wrogim istotom, które widzisz.',
  'profession.ganger.2':
    'Zyskujesz biegłość w Zastraszaniu, a jeśli już ją masz — Specjalizację. Symbol gangu sprawia, że bandyci traktują cię jak swojego; masz Ułatwienie testów Charyzmy w rozmowie z podobnymi do ciebie przestępcami.',
  'profession.ganger.3':
    'Masz niewrażliwość na Przerażenie. Sojusznicy w zasięgu 9 m od ciebie dodają 1k4 do RO przeciw Przerażeniu.',
  'profession.gladiator.0':
    'Trafienie, które zadałoby ci obrażenia krytyczne, zadaje zamiast nich zwykłe obrażenia.',
  'profession.gladiator.1':
    'Możesz walczyć improwizowanym przedmiotem z biegłością, wręcz albo rzucając do 6 m; jego masa w kg nie może przekraczać twojej Siły. Obrażenia według masy: do 5 kg — 1k6 i jedna ręka; 6–11 kg — 2k6; 12–17 kg — 3k6; 18–20 kg — 4k6, wszystkie oburęcznie. Typ obrażeń i szczegóły ustalasz z MG. Naturalna 1 w ataku niszczy przedmiot.',
  'profession.gladiator.2':
    'W Berserku jesteś niewrażliwy na Przerażenie, ataki okazyjne przeciw tobie mają Utrudnienie, a zasięg i wysokość skoku są podwojone. Lądując na istocie najwyżej o jeden rozmiar większej, zmuszasz ją do RO Siły o ST 8 + twój modyfikator Siły + PB; porażka oznacza Powalenie i 1k6 obrażeń obuchowych za każde 3 m długości lub wysokości skoku.',
  'profession.gladiator.3':
    'Kiedy co najmniej dwóch przeciwników znajduje się w odległości 1,5 m od ciebie, masz Ułatwienie Testów Ataku wręcz.',
  'profession.mercenary.0':
    'Podczas Berserka możesz wykonać jeden dodatkowy atak wręcz w Akcji Bonusowej. Raz w rundzie możesz także wykonać jeden atak wręcz oparty na Sile z Ułatwieniem.',
  'profession.mercenary.1':
    'Podczas negocjowania zapłaty masz Ułatwienie testów Wpływania. Po wykonaniu zlecenia otrzymujesz dodatkowo 1k4 × 10% uzgodnionej stawki.',
  'profession.mercenary.2':
    'Po trafieniu wręcz możesz wydać jedną kość Wściekłego ciosu na efekt zamiast jej obrażeń: Odepchnięcie; Wytrącenie; albo dodatkowy atak wręcz przeciw innej istocie w odległości 1,5 m od trafionego celu, jeśli jest też w zasięgu twojej broni.',

  'profession.star.0':
    'Akcja: głosem lub instrumentem wywołujesz kakofonię. Każda słysząca istota w promieniu 9 m wykonuje RO Kondycji o ST 8 + twój modyfikator Charyzmy + PB. Porażka oznacza Obezwładnienie do początku twojej następnej tury. Twoi sojusznicy mają Ułatwienie tego RO.',
  'profession.star.1':
    'Akcja: wykonujesz test Występów lub instrumentu. Słyszący sojusznicy w zasięgu 27 m otrzymują premię do Testów Ataku lub RO do początku twojej następnej tury: wynik 5–9 daje +1, 10–14 +2, 15–19 +3, 20–24 +4, 25+ +5. Możesz powtarzać występ, za każdym razem testując ponownie. Nieprzytomność, Obezwładnienie lub Ogłuchnięcie kończą efekt.',
  'profession.star.2':
    'Każde pełne 50 G wartości noszonych na sobie towarów luksusowych daje +1 do testów Wpływania.',
  'profession.star.3':
    'Raz dziennie możesz dać czterogodzinny koncert, po którym zyskujesz jeden poziom Wyczerpania. Zarobek w G to wynik testu Występów lub instrumentu pomnożony przez miejsce: ulica ×0,5, tania knajpa ×1, dobra knajpa ×2, drogi klub ×3. Występy zapewniają też możliwość zdobycia noclegu i wyżywienia.',
  'profession.preacher.0':
    'Po nieudanym Teście Cechy, Ataku lub RO możesz dodać 1k6 do wyniku i musisz przyjąć nowy wynik. Liczba użyć równa modyfikatorowi Charyzmy; odnawia ją Długi odpoczynek.',
  'profession.preacher.1': ({ cwaniak }) =>
    `Akcja Bonusowa: do ${cwaniak} słyszących cię sojuszników (poziom Cwaniaka) w zasięgu 18 m otrzymuje +1k4 do Testów Ataku i RO do początku twojej następnej tury.`,
  'profession.preacher.2':
    'Raz na turę, kiedy zadasz obrażenia atakiem bronią palną, możesz dodać 1k10 obrażeń.',
  'profession.preacher.3':
    'Bez pancerza dodajesz modyfikator Charyzmy do TT. Ten sposób wyliczania TT nie łączy się z innym alternatywnym wzorem, np. Gołą klatą.',
  'profession.mafia.0':
    'Masz Ułatwienie ataku przeciw istocie, która w ostatniej rundzie zraniła członka twojej mafii oznaczonego tatuażem. W Akcji Bonusowej możesz rozkazać członkowi grupy zaatakować wskazany cel; wykonuje ten atak w swojej Reakcji, jeśli cel jest w jego zasięgu.',
  'profession.mafia.1':
    'Każde pełne 50 G wartości noszonych na sobie towarów luksusowych daje +1 do testów Wpływania.',
  'profession.mafia.2': ({ cwaniak }) =>
    `Możesz zwerbować jednego ludzkiego pomocnika; poszukiwania następcy zajmują 24 godziny. Zapewniasz mu utrzymanie i 10% swojej doli. Działa tuż po twojej turze pod twoją kontrolą. Jego PW wynoszą ${5 * cwaniak}, KW ${cwaniak}k6, a PB zawsze +2. Otrzymuje cechy 14/14/12/12/10/8 albo 24 punkty, lokalne pochodzenie, twoje biegłości broni i pancerza, dwie wybrane biegłości RO, dwie umiejętności/narzędzia i jedną sztuczkę, której wymagania spełnia. Używa Zranień i rzutów przeciw śmierci jak BG.`,

  'profession.chemist.0':
    'Masz odporność na obrażenia od kwasu i trucizny oraz Ułatwienie RO Kondycji przeciw kwasom, truciznom i skażeniu radioaktywnemu.',
  'profession.chemist.1':
    'Zyskujesz schematy produkcji materiałów wybuchowych, granatów, min, pocisków i prochu. Wytwarzanie wymaga narzędzi małego chemika i małego rusznikarza, surowców oraz czasu; każdy schemat określa własne ST, czas i składniki.',
  'profession.chemist.2':
    'Zyskujesz schematy produkcji broni palnej, kusz i ulepszeń broni. Potrzebujesz narzędzi małego kowala i małego rusznikarza, surowców oraz czasu. ST, nakład pracy i składniki zależą od konkretnego schematu.',
  'profession.medic.0':
    'Trwale zwiększasz Inteligencję o 4, do maksimum 20. W zamian trwale zmniejszasz wybraną Kondycję albo Zręczność o 2. Odpoczynek nie cofa tej ceny.',
  'profession.medic.1': ({ spec }) =>
    `Używając narzędzi małego medyka, zastępujesz kość leczenia k4 kością k${4 + 2 * Math.floor(spec / 3)}. Wartość zależy od poziomu Speca: k6 od 3., k8 od 6., k10 od 9. i k12 od 12.`,
  'profession.medic.2':
    'Reanimacja trwa 1 minutę i wymaga testu Medycyny. ST według czasu od ustania tętna: do 1 minuty — 15; do 2 — 20; do 4 — 25; do 8 — 30. Sukces przywraca funkcje życiowe, lecz pacjent nadal jest niestabilny. Nie działa po śmierci od Olbrzymich obrażeń.',
  'profession.medic.3':
    'Zyskujesz biegłość w narzędziach małego aptekarza oraz schematy leków i środków leczących. Produkcja ze składników chemicznych lub organicznych wymaga narzędzi małego chemika i aptekarza; schemat określa ST, czas i zużywane surowce.',
  'profession.engineer.0':
    'Zyskujesz biegłość w narzędziach małego mechanika oraz schematy pojazdów i mechanicznych pancerzy. Możesz je budować, ulepszać i naprawiać, używając narzędzi małego mechanika i kowala, odpowiednich surowców oraz czasu.',
  'profession.engineer.1':
    'Zyskujesz biegłość w narzędziach małego hakera i schematy komputerów, dronów oraz przeprogramowania maszyn. Produkcja wymaga narzędzi hakera i elektronika. Dron potrzebuje kontrolera: Akcja Bonusowa wydaje proste polecenie, a Akcja daje pełne sterowanie, w tym atak. Godzina naprawy przywraca 2k6 + modyfikator Inteligencji PW. Akumulator 24 V zasila średniego drona przez 1 h, małego przez 4 h; agregat zużywa 0,5 l paliwa na godzinę.',
  'profession.engineer.2':
    'Zyskujesz biegłość w narzędziach małego elektronika i schematy urządzeń elektronicznych oraz drobnych mechanizmów. Naprawa i produkcja wymagają narzędzi małego chemika i elektronika, surowców oraz czasu określonego przez schemat.',

  'profession.cowboy.0':
    'Raz na walkę możesz powtórzyć jeden Test Ataku bronią palną. Rewolwery w twoich rękach zadają jedną dodatkową kość obrażeń broni.',
  'profession.cowboy.1':
    'Dobycie lub schowanie jednego albo dwóch rewolwerów z kabur nie kosztuje Interakcji. Rewolwery się nie zacinają, są dla ciebie lekkie i poręczne; strzelasz jedną ręką bez Utrudnienia z tego powodu. Masz +5 do Inicjatywy, jeśli trzymasz lub będziesz dobywać rewolwer. Mając wolną rękę i pełny szybkoładowacz, uzupełniasz pusty bębenek w Akcji Bonusowej.',
  'profession.cowboy.2':
    'Jeśli nie masz konia ani motocykla, podczas najbliższego Długiego odpoczynku trafia się okazja zdobycia jednego z nich. Nadajesz mu imię i nie możesz go sprzedać; może mieć prawowitego właściciela.',
  'profession.roadwarrior.0':
    'Podczas walki, wyścigu i pościgu masz Ułatwienie testów Mądrości (Pojazdy), a Szybkość twojego pojazdu rośnie o 50%. Jako kierowca lub pasażer nie masz Utrudnienia ataków za niestabilne podłoże pojazdu. Taranowane przez ciebie istoty wykonują RO Zręczności z Utrudnieniem.',
  'profession.roadwarrior.1':
    'Pojazdem silnikowym możesz jechać po schodach z pełną Szybkością, przejechać na dwóch bocznych kołach albo po 60 m rozpędu przeskoczyć odległość równą czterem długościom pojazdu. Każdy trik wymaga testu Mądrości (Pojazdy) o ST 15 z Ułatwieniem. Porażka daje małe uszkodzenia; porażka o 5 lub więcej — awarię i obrażenia pasażerów.',
  'profession.roadwarrior.2':
    'Prowadząc poruszający się pojazd mechaniczny dający pasażerom Osłonę, dodajesz modyfikator Mądrości do TT swojej i pasażerów. W Akcji Bonusowej możesz uruchomić lub zatrzymać pojazd albo wykonać nim Przyspieszenie, Odstąpienie czy Unikanie.',
  'profession.soldier.0':
    'Broń palna w twoich rękach nie zacina się. Zaciętą broń możesz naprawić w Akcji Bonusowej, a uszkodzoną broń białą podczas Krótkiego odpoczynku.',
  'profession.soldier.1':
    'W czasie walki wykonujesz Rzuty Obronne Zręczności i Mądrości z Ułatwieniem.',
  'profession.soldier.2':
    'Nie otrzymujesz Utrudnienia Skradania się wynikającego z pancerza. Maksymalna premia ze Zręczności dopuszczana przez noszony pancerz rośnie o 1.',

  'profession.courier.0':
    'Ukrywając przedmiot albo istotę nie większą niż mała, wykonujesz test Skradania się z Ułatwieniem. Skutecznie ukryty przedmiot lub istota otrzymuje Niewidoczność.',
  'profession.courier.1':
    'W godzinę i przy niewielkiej wymianie uprzejmości orientujesz się w lokalnym półświatku: rozpoznajesz jego ważne osoby, interesy i zagrożenia. Związane z tym testy Perswazji i Śledztwa wykonujesz z Ułatwieniem.',
  'profession.courier.2':
    'W cywilizowanym miejscu wykonujesz test Charyzmy, by ustalić znajomości: 1–9 — nikogo nie znasz; 10–14 — miejscowy znajomy; 15–19 — przedsiębiorca lub stróż prawa; 20+ — wpływowa osoba rządząca okolicą.',
  'profession.rat.0':
    'Masz Ułatwienie RO przeciw chorobom, truciznom i radiacji oraz odporność na obrażenia z tych źródeł, także alkoholu. Nie usuwa to posiadanej choroby przewlekłej.',
  'profession.rat.1':
    'Dodajesz wybrany modyfikator Inteligencji albo Mądrości do Skradania się. Możesz ukrywać się nawet na otwartym, jasno oświetlonym terenie, udając nieistotnego przechodnia. Jeśli milczysz i nie hałasujesz, masz Ułatwienie Ukrywania się do chwili ataku lub wykonania głośnej czynności.',
  'profession.rat.2':
    'Z narzędziami małego chemika wytwarzasz podczas Długiego odpoczynku jedną porcję 10 ml trucizny. Akcja Bonusowa nakłada ją na ostrze albo do trzech grotów. Trucizna działa przez minutę lub do aplikacji. Trafiony cel wykonuje RO Kondycji o ST 8 + twój modyfikator Inteligencji + PB; porażka daje Zatrucie na minutę, z kolejnym RO na końcu każdej tury celu.',
  'profession.rat.3':
    'Masz Szybkość wspinania równą swojej Szybkości. Przy skokach możesz testować Akrobatykę zamiast Atletyki i obliczać maksymalną odległość ze Zręczności zamiast Siły.',
  'profession.assassin.0':
    'Przy broni finezyjnej lub ogniu pojedynczym: w pierwszej rundzie walki masz Ułatwienie pierwszego ataku na cel, przed którego turą działasz. Możesz też, nie wykonując ruchu w swojej turze, poświęcić Akcję Bonusową na celowanie i wykonać jeden atak z Ułatwieniem.',
  'profession.assassin.1':
    'Dopasowany do otoczenia strój maskujący i pomalowana twarz dają Ułatwienie Skradania się. Jeśli przed atakiem bronią dystansową lub rzucaną masz Niewidoczność, zachowujesz ją po ataku, dopóki się nie poruszysz. Cel zna jedynie kierunek ataku, chyba że broń ma właściwość cicha.',
  'profession.assassin.2':
    'Przygotuj stanowisko snajperskie z celownikiem optycznym i celuj przez 5 rund. Dopóki się nie poruszysz, maksymalny zasięg tej broni jest potrojony i nie masz Utrudnienia za daleki dystans.',

  'profession.mutanthunter.0':
    'Akcja: test Inteligencji (Przyroda) dotyczący napotkanego mutanta lub potwora ujawnia nazwę przy ST 10, słabe punkty przy ST 15 oraz trzy wybrane współczynniki przy ST 20.',
  'profession.mutanthunter.1':
    'Rozpoczynając walkę z mutantem lub potworem, dodajesz PB do Inicjatywy. Raz w rundzie możesz zaatakować taką istotę z Ułatwieniem. Reakcja po trafieniu przez nią pozwala zwiększyć swoją TT o PB wobec tego jednego ataku.',
  'profession.mutanthunter.2':
    'Budujesz Pogromcę za 100 G surowców i 100 godzin: 10 MK, 10 CE i 80 CZ. Broń ma zasięg 9/18 m, magazynek 1, ogień pojedynczy, Ładowanie i obrażenia 4k6 od trucizny, kwasu albo ognia. Trafienie mutanta lub potwora jest krytyczne. Podczas Długiego odpoczynku tworzysz do PB pocisków po 10 G (1 MK, 1 CZ, 8 CH) każdy. Tylko Łowca Mutantów ma biegłość w Pogromcy.',
  'profession.mutanthunter.3':
    'Gdy nie masz oswojonego zwierzęcia, szukasz przez 24 godziny: k6 daje 1–2 owada, 3–4 ssaka, 5–6 gada. Leczenie i oswajanie trwa 3 dni. Nadajesz mu imię, zapewniasz wodę i jedzenie; nie możesz go oddać ani sprzedać. W walce Akcja Bonusowa wydaje polecenie, po którym zwierzę wykonuje pełną turę tuż po tobie. Bez polecenia nie rusza się i Unika; walczy do utraty przytomności.',
  'profession.judge.0':
    'Miejscowi stróże prawa traktują cię jak swojego i przyjmują uzasadnienie konieczności działania przeciw przestępcom. Gdy próbujesz ich przekonać, masz Ułatwienie testów Wpływania.',
  'profession.judge.1':
    'Akcja Bonusowa: wydajesz rozkaz wybranemu człowiekowi w zasięgu 9 m. Cel wykonuje RO Mądrości o ST 8 + twój modyfikator Charyzmy + PB. Porażka oznacza natychmiastowe upuszczenie broni, położenie się na ziemi i Przerażenie do końca twojej następnej tury.',
  'profession.judge.2': ({ zwiadowca }) =>
    `Możesz mieć jednego ludzkiego albo psiego partnera; poszukiwania nowego trwają 24 godziny. Działa tuż po twojej turze po rozkazie wydanym w Akcji Bonusowej; bez rozkazu Unika i szuka osłony. Zapewniasz mu jedzenie i wodę, nie możesz go odstąpić ani sprzedać. Ludzki partner ma ${5 * zwiadowca} PW, ${zwiadowca}k6 KW, stałe PB +2, cechy 14/14/12/12/10/8 albo 24 punkty, lokalne pochodzenie, twoje biegłości broni/pancerza, dwa RO, dwie umiejętności/narzędzia i jedną sztuczkę, której wymagania spełnia. Psi partner korzysta z własnego profilu.`,
  'profession.machinehunter.0':
    'Budujesz Emiter EMP za 100 G surowców i 100 godzin (20 MK, 40 CE, 40 CZ). Zasięg 9/15 m, 6 strzałów, pojedynczy ogień, Ładowanie, 8k6 obrażeń elektrycznych; zasilanie 230 V. Ignoruje TT pochodzącą z opancerzenia maszyny. Trafiony cel wykonuje RO Kondycji ST 15 lub jest Obezwładniony do końca twojej następnej tury. Nie działa na żywe istoty ani sprzęt bez mikroprocesorów. Tylko Zabójca Maszyn ma biegłość w tej broni.',
  'profession.machinehunter.1':
    'Po trafieniu przez maszynę możesz w Reakcji podnieść swoją TT o PB wobec tego ataku. Masz także Ułatwienie RO przeciw efektom wywołanym przez maszyny.',
  'profession.machinehunter.2':
    'Akcja podczas walki z maszyną lub tuż przed nią: wykonujesz test Inteligencji (Technika). ST według rozmiaru: malutka/mała 5, średnia 10, duża 15, wielka 20, ogromna 25. Sukces pozwala poznać trzy wybrane współczynniki maszyny i atakować ją z Ułatwieniem raz w rundzie.',
};

export function describeCharacterRule(
  ruleId: string,
  classLevels: ClassLevels,
): string | undefined {
  const description =
    classRuleDescriptions[ruleId] ?? professionRuleDescriptions[ruleId];
  return typeof description === 'function'
    ? description(classLevels)
    : description;
}
