import {
  ABILITIES,
  abilityNames,
  colorHp,
  type Ability,
  type CharacterSheet,
  type ClassId,
} from './model';
import {
  classes,
  origins,
  professions,
  skills,
  tools,
  weaponCategories,
  weaponNames,
  armorNames,
  classRulePage,
  professionRulePage,
  xpThresholds,
} from './catalog';
import { feats, type Feat } from './feats';
import { describeCharacterRule } from './ruleDescriptions';

export interface Component {
  source: string;
  value: number;
}
export interface Value {
  value: number | null;
  components: Component[];
  conditions: string[];
  unresolvedRuleIds: string[];
}
export interface Issue {
  path: string;
  message: string;
}
export interface Option {
  id: string;
  label: string;
}
export interface Choice {
  level: number;
  key: string;
  label: string;
  count: number;
  options: Option[];
  freeText?: boolean;
}
export interface Grant {
  target: string;
  rank: 1 | 2;
  source: string;
  level: number;
}
export interface Rule {
  id: string;
  label: string;
  page: number;
  summary: string;
  level: number;
}
export const modifier = (score: number | null) =>
  score === null ? null : Math.floor((score - 10) / 2);
export const proficiencyBonus = (level: number) =>
  2 + Math.floor((level - 1) / 4);
const options = (
  entries: { id: string; label: string }[],
  prefix = '',
): Option[] => entries.map((x) => ({ id: prefix + x.id, label: x.label }));
const skillOptions = options(skills, 'skill:');
const toolOptions = options(tools, 'tool:');
const mixedOptions = [...skillOptions, ...toolOptions];
const weaponOptions = weaponCategories.map((id) => ({
  id: 'weapon:' + id,
  label: weaponNames[id]!,
}));
const abilityOptions = ABILITIES.map((id) => ({ id, label: abilityNames[id] }));
export const pointCosts: Record<number, number> = {
  8: 0,
  9: 1,
  10: 2,
  11: 3,
  12: 4,
  13: 5,
  14: 7,
  15: 9,
};
export const arrays = {
  'array-a': [15, 14, 13, 12, 10, 8],
  'array-b': [15, 15, 15, 8, 8, 8],
  'array-c': [15, 12, 12, 12, 12, 10],
};
export function deriveCharacter(
  sheet: CharacterSheet & {
    learned?: { target: string; afterLevel: number }[];
    healthAdjustments?: {
      group: 'disease' | 'phobia';
      ability: Ability;
      delta: number;
    }[];
  },
) {
  const issues: Issue[] = [],
    choices: Choice[] = [],
    grants: Grant[] = [],
    rules: Rule[] = [];
  const counts: Record<ClassId, number> = {
    brutal: 0,
    cwaniak: 0,
    spec: 0,
    twardziel: 0,
    zlodziej: 0,
    zwiadowca: 0,
  };
  const scores = { ...sheet.baseScores };
  const scoreParts = Object.fromEntries(
    ABILITIES.map((a) => [
      a,
      [{ source: 'Wartość bazowa', value: scores[a] ?? 0 }],
    ]),
  ) as Record<Ability, Component[]>;
  const activeFeats = new Set<string>(),
    originChosen = new Set<string>(),
    profChosen = new Set<string>();
  const professionByClass: Partial<Record<ClassId, string>> = {};
  const advantages: Record<string, string[]> = {};
  const styles = new Set<string>();
  const rank = (target: string) =>
    Math.max(
      0,
      ...grants.filter((g) => g.target === target).map((g) => g.rank),
    );
  const issue = (path: string, message: string) =>
    issues.push({ path, message });
  let level = 0;
  const grant = (target: string, source: string, upgrade = false) =>
    grants.push({
      target,
      rank: upgrade && rank(target) > 0 ? 2 : 1,
      source,
      level: level + 1,
    });
  const specialize = (target: string, source: string) =>
    grants.push({ target, rank: 2, source, level: level + 1 });
  const adv = (target: string, source: string) => {
    (advantages[target] ??= []).push(source);
  };
  function choose(
    key: string,
    label: string,
    count: number,
    list: Option[],
    freeText = false,
  ): string[] {
    const selected = sheet.levels[level]!.choices[key] ?? [];
    choices.push({ level, key, label, count, options: list, freeText });
    if (
      selected.length !== count ||
      new Set(selected.map((s) => s.trim().toLocaleLowerCase('pl'))).size !==
        selected.length ||
      selected.some(
        (s) => !s.trim() || (!freeText && !list.some((o) => o.id === s)),
      )
    )
      issue(
        `level-${level}-${key}`,
        `${label}: wybierz ${count} ${count === 1 ? 'pozycję' : 'różne pozycje'} z dostępnej listy.`,
      );
    return selected.filter(
      (s) => s.trim() && (freeText || list.some((o) => o.id === s)),
    );
  }
  function pickGrant(
    key: string,
    label: string,
    count: number,
    list: Option[],
    source: string,
    upgrade = false,
  ) {
    choose(key, label, count, list).forEach((t) => grant(t, source, upgrade));
  }
  function instruments(key: string, count: number, source: string) {
    if (count)
      choose(key, 'Instrumenty — nazwy', count, [], true).forEach((n) =>
        grant('instrument:' + n.trim(), source),
      );
  }
  function increase(a: Ability, value: number, source: string, cap = 20) {
    if (scores[a] !== null) {
      const delta =
        value > 0 ? Math.max(0, Math.min(value, cap - scores[a])) : value;
      scores[a] += delta;
      scoreParts[a].push({ source, value: delta });
    }
  }
  const available = (list: Option[], expertise = false) =>
    list.filter((o) => (expertise ? rank(o.id) === 1 : rank(o.id) === 0));
  function addOrigin(key: string) {
    const o = origins.find((o) => o.id === sheet.originId);
    if (!o) return;
    const selected = choose(
      key,
      'Zdolność pochodzenia',
      1,
      o.choices
        .filter((c) => !originChosen.has(c.id))
        .map((c) => ({ id: c.id, label: c.label })),
    )[0];
    if (!selected) return;
    originChosen.add(selected);
    const c = o.choices.find((c) => c.id === selected)!;
    const source = `${o.label}: ${c.label}`;
    rules.push({
      id: `origin.${o.id}.${selected}`,
      label: c.label,
      page: o.page,
      summary: c.description,
      level: level + 1,
    });
    const oid = `${o.id}.${selected}`;
    const fixed: Record<string, string[]> = {
      'asgard.nano': ['tool:electronics'],
      'desert.diet': ['tool:cook'],
      'desert.self': ['tool:smith'],
      'detroit.sweat': ['skill:vehicles'],
      'detroit.engine': ['tool:mechanic'],
      'appalachia.gun': ['tool:gunsmith'],
      'miami.wanderer': ['tool:cartographer'],
      'hegemony.dog': ['skill:intimidation', 'tool:butcher'],
      'saltlake.preacher': ['skill:persuasion'],
      'saltlake.before': ['skill:history', 'skill:medicine'],
      'texas.quinn': ['skill:medicine'],
      'texas.healthy': ['save:con'],
      'vegas.gambler': ['skill:sleight', 'skill:deception'],
      'vegas.telepath': ['skill:insight'],
    };
    for (const t of fixed[oid] ?? []) grant(t, source);
    const advantagesByOrigin: Record<string, string> = {
      'appalachia.miner': 'skill:athletics',
      'miami.sick': 'save:con',
      'hegemony.dog': 'skill:intimidation',
      'texas.quinn': 'skill:medicine',
      'texas.healthy': 'save:con',
      'vegas.telepath': 'skill:insight',
    };
    if (advantagesByOrigin[oid]) adv(advantagesByOrigin[oid], source);
    const lists: Record<string, { count: number; list: Option[] }> = {
      'asgard.education': { count: 1, list: toolOptions },
      'appalachia.noble': {
        count: 2,
        list: skillOptions.filter((o) =>
          [
            'skill:history',
            'skill:deception',
            'skill:persuasion',
            'skill:intimidation',
          ].includes(o.id),
        ),
      },
      'newyork.education': {
        count: 2,
        list: mixedOptions.filter(
          (o) =>
            o.id.startsWith('tool:') ||
            [
              'skill:nature',
              'skill:medicine',
              'skill:history',
              'skill:technology',
            ].includes(o.id),
        ),
      },
      'outpost.simulator': {
        count: 2,
        list: mixedOptions.filter((o) =>
          [
            'skill:vehicles',
            'skill:technology',
            'tool:mechanic',
            'tool:electronics',
          ].includes(o.id),
        ),
      },
      'texas.horse': {
        count: 2,
        list: skillOptions.filter((o) =>
          ['skill:athletics', 'skill:animals', 'skill:medicine'].includes(o.id),
        ),
      },
    };
    const list = lists[oid];
    if (list)
      pickGrant(
        key + '-grant',
        'Biegłości pochodzenia',
        list.count,
        list.list,
        source,
      );
  }
  function meets(requirement: string): boolean {
    const [kind, value] = requirement.split(':');
    if (ABILITIES.includes(kind as Ability))
      return (scores[kind as Ability] ?? 0) >= Number(value);
    if (kind === 'tools')
      return (
        new Set(
          grants
            .filter((g) => g.target.startsWith('tool:'))
            .map((g) => g.target),
        ).size >= Number(value)
      );
    return rank(requirement) > 0;
  }
  function takeFeat(key: string, allowMoney = false) {
    const eligible = feats.filter(
      (f) =>
        (f.id === 'practice' || !activeFeats.has(f.id)) &&
        f.requires.every((group) => group.some(meets)),
    );
    const chosen = choose(
      key,
      allowMoney ? 'Sztuczka początkowa lub 50 gb' : 'Sztuczka',
      1,
      [
        ...(allowMoney
          ? [
              {
                id: 'money',
                label: '50 gb zamiast sztuczki',
              },
            ]
          : []),
        ...eligible.map((f) => ({ id: f.id, label: f.label })),
      ],
    )[0];
    const f = eligible.find((f) => f.id === chosen);
    if (!f) return;
    activeFeats.add(f.id);
    rules.push({
      id: 'feat.' + f.id,
      label: f.label,
      page: f.page,
      summary: f.summary,
      level: level + 1,
    });
    if (f.increase.length) {
      const a = choose(
        key + '-ability',
        f.label + ' — zwiększ cechę o 1',
        1,
        abilityOptions.filter((a) => f.increase.includes(a.id as Ability)),
      )[0];
      if (a) increase(a as Ability, 1, f.label, level === 0 ? 18 : 20);
    }
    if (f.id === 'practice') {
      const mode = choose(key + '-mode', 'Rozwój cech', 1, [
        { id: 'one', label: '+2 jednej cesze' },
        { id: 'two', label: '+1 dwóm cechom' },
      ])[0];
      if (mode)
        choose(
          key + '-abilities',
          'Cechy do zwiększenia',
          mode === 'one' ? 1 : 2,
          abilityOptions,
        ).forEach((a) =>
          increase(
            a as Ability,
            mode === 'one' ? 2 : 1,
            f.label,
            level === 0 ? 18 : 20,
          ),
        );
    }
    if (f.id === 'expert')
      pickGrant(
        key + '-tools',
        'Narzędzia Fachowca',
        2,
        available(toolOptions),
        f.label,
      );
    if (f.id === 'study')
      pickGrant(
        key + '-skills',
        'Umiejętności',
        2,
        available(skillOptions),
        f.label,
      );
    if (f.id === 'musician') instruments(key + '-instruments', 2, f.label);
    if (f.id === 'weapontraining')
      pickGrant(
        key + '-weapons',
        'Kategoria broni',
        1,
        available(weaponOptions),
        f.label,
      );
    if (f.id === 'heavytraining') grant('armor:heavy', f.label);
    if (f.id === 'mediumtraining') grant('armor:medium', f.label);
    if (f.id === 'patriot') addOrigin(key + '-origin');
    if (f.id === 'blademaster')
      choose(key + '-weapon', 'Model broni białej', 1, [], true);
  }
  function professionGrants(p: string, source: string) {
    const fixed: Record<string, string[]> = {
      ganger: ['weapon:intermediate', 'skill:vehicles'],
      gladiator: ['weapon:improvised'],
      star: ['skill:performance'],
      preacher: ['weapon:long'],
      mafia: ['tool:tattoo'],
      chemist: ['tool:chemist', 'tool:gunsmith'],
      medic: ['skill:medicine'],
      engineer: ['skill:technology'],
      cowboy: ['tool:smith'],
      roadwarrior: ['skill:vehicles', 'tool:mechanic'],
      soldier: ['skill:technology'],
      courier: ['tool:mechanic', 'skill:vehicles'],
      rat: ['tool:chemist'],
      assassin: [
        'tool:disguise',
        ...weaponCategories.map((w) => 'weapon:' + w),
      ],
      judge: ['skill:investigation', 'skill:intimidation'],
      machinehunter: ['skill:technology', 'armor:heavy'],
    };
    (fixed[p] ?? []).forEach((t) =>
      grant(
        t,
        source,
        ['roadwarrior', 'courier'].includes(p) ||
          (p === 'machinehunter' && t === 'skill:technology'),
      ),
    );
    const sk = (key: string, n: number, list = skillOptions, upgrade = false) =>
      pickGrant(
        'profession-' + key,
        'Umiejętności profesji',
        n,
        list,
        source,
        upgrade,
      );
    const tl = (n: number, list = toolOptions) =>
      pickGrant('profession-tools', 'Narzędzia profesji', n, list, source);
    const wp = (n: number) =>
      pickGrant(
        'profession-weapons',
        'Kategorie broni profesji',
        n,
        weaponOptions,
        source,
      );
    const filter = (list: Option[], ids: string[]) =>
      list.filter((o) => ids.includes(o.id.split(':')[1]!));
    if (p === 'gladiator')
      sk('skills', 1, filter(skillOptions, ['athletics', 'acrobatics']), true);
    if (p === 'mercenary') {
      wp(2);
      tl(1);
    }
    if (p === 'star') {
      const selected = choose(
        'profession-mixed',
        'Dwie umiejętności lub umiejętność i narzędzie',
        2,
        available(mixedOptions),
      );
      if (selected.filter((s) => s.startsWith('tool:')).length > 1)
        issue(
          `level-${level}-profession-mixed`,
          'Gwiazda: co najmniej jedna umiejętność.',
        );
      selected.forEach((t) => grant(t, source));
      const inst = grants
        .filter((g) => g.target.startsWith('instrument:'))
        .map((g) => ({ id: g.target, label: g.target.slice(11) }));
      choose(
        'profession-instrument',
        'Specjalizacja instrumentu',
        1,
        inst,
      ).forEach((t) => specialize(t, source));
    }
    if (p === 'preacher') {
      sk('skills', 1);
      tl(1);
    }
    if (p === 'mafia') wp(2);
    if (p === 'medic') tl(1, filter(toolOptions, ['chemist', 'medic']));
    if (p === 'engineer') tl(2);
    if (p === 'cowboy') {
      sk('skills', 1, filter(skillOptions, ['vehicles', 'animals']));
      instruments('profession-instruments', 1, source);
    }
    if (p === 'soldier') tl(1, filter(toolOptions, ['gunsmith', 'smith']));
    if (p === 'rat')
      sk('skills', 1, filter(skillOptions, ['acrobatics', 'sleight']));
    if (p === 'mutanthunter') {
      sk('skills', 1, filter(skillOptions, ['nature', 'animals']));
      tl(1);
      wp(1);
    }
    if (p === 'judge' || p === 'machinehunter') {
      tl(1);
      wp(1);
    }
  }
  function professionAbility(p: string, key: string) {
    const def = professions[p];
    if (!def) return;
    const list = def.abilities
      .map((label, i) => ({ id: `${p}.${i}`, label }))
      .filter((o) => !profChosen.has(o.id));
    const id = choose(key, 'Zdolność profesji', 1, list)[0];
    if (!id) return;
    profChosen.add(id);
    const label = list.find((o) => o.id === id)!.label;
    rules.push({
      id: 'profession.' + id,
      label,
      page: professionRulePage(id),
      summary: '',
      level: level + 1,
    });
    if (id === 'rat.1')
      choose(
        key + '-grey',
        'Szary — dodatkowy modyfikator do Skradania',
        1,
        abilityOptions.filter((a) => a.id === 'int' || a.id === 'wis'),
      );
    if (id === 'medic.0') {
      const cost = choose(
        key + '-brain',
        'Doktor Brain — trwały koszt −2',
        1,
        abilityOptions.filter((a) => a.id === 'dex' || a.id === 'con'),
      )[0];
      if (cost) {
        increase('int', 4, label);
        increase(cost as Ability, -2, label);
      }
    }
    if (id === 'medic.3') grant('tool:apothecary', label);
    if (id === 'engineer.0') grant('tool:mechanic', label);
    if (id === 'engineer.1') grant('tool:hacker', label);
    if (id === 'engineer.2') grant('tool:electronics', label);
    if (id === 'ganger.2') grant('skill:intimidation', label, true);
  }
  if (!sheet.identity.name.trim())
    issue('identity-name', 'Wpisz imię lub nazwę postaci.');
  const base = ABILITIES.map((a) => sheet.baseScores[a]);
  ABILITIES.forEach((a) => {
    if (scores[a] === null)
      issue('ability-' + a, `Uzupełnij cechę: ${abilityNames[a]}.`);
  });
  if (
    sheet.method in arrays &&
    base.every((v) => v !== null) &&
    [...base].sort((a, b) => b! - a!).join() !==
      arrays[sheet.method as keyof typeof arrays].join()
  )
    issue(
      'creation-method',
      'Rozdziel dokładnie sześć wartości wybranej tablicy.',
    );
  const pointTotal = base.some((v) => v === null || pointCosts[v] === undefined)
    ? null
    : base.reduce<number>((sum, v) => sum + pointCosts[v!]!, 0);
  if (sheet.method === 'points' && (pointTotal === null || pointTotal > 27))
    issue(
      'creation-method',
      'Zakup cech: wartości 8–15 i najwyżej 27 punktów.',
    );
  if (base.some((v) => v !== null && v > 18))
    issue(
      'creation-method',
      'Na tworzeniu cecha nie może przekraczać 18. Dalszy wzrost zapisz w historii rozwoju.',
    );
  if (sheet.method === 'gm' && !sheet.methodReason.trim())
    issue('creation-method', 'Własne cechy wymagają uzasadnienia MG.');
  const origin = origins.find((o) => o.id === sheet.originId);
  if (!origin) issue('origin', 'Wybierz pochodzenie.');
  const first = classes[sheet.levels[0]!.classId];
  if ((scores[first.favorite] ?? 0) < 15)
    issue(
      'ability-' + first.favorite,
      `Pierwsza klasa wymaga ${abilityNames[first.favorite]} 15 przed pochodzeniem.`,
    );
  for (const adjustment of sheet.healthAdjustments ?? [])
    increase(
      adjustment.ability,
      adjustment.delta,
      adjustment.group === 'disease'
        ? 'Choroba początkowa'
        : 'Fobia początkowa',
      18,
    );
  origin?.abilities.forEach((a) => increase(a, 1, origin.label, 18));
  for (level = 0; level < sheet.levels.length; level++) {
    for (const t of sheet.learned ?? [])
      if (t.afterLevel === level) grant(t.target, 'Trening podczas postoju');
    const entry = sheet.levels[level]!,
      id = entry.classId,
      cl = classes[id],
      classLevel = ++counts[id];
    if (classLevel === 1) {
      if (level > 0 && (scores[cl.favorite] ?? 0) < 15)
        issue(
          `level-${level}-class`,
          `Nowa klasa ${cl.label} wymaga ${abilityNames[cl.favorite]} 15 przed wyborem jej zdolności.`,
        );
      const list = skillOptions.filter((o) =>
        cl.skills.includes(o.id.slice(6)),
      );
      if (level === 0) {
        cl.saves.forEach((a) => grant('save:' + a, cl.label));
        cl.weapons.forEach((w) => grant('weapon:' + w, cl.label));
        cl.armor.forEach((a) => grant('armor:' + a, cl.label));
        cl.tools.forEach((t) => grant('tool:' + t, cl.label));
        pickGrant(
          'class-skills',
          'Umiejętności klasy',
          cl.skillCount,
          list,
          cl.label,
        );
        if (cl.toolCount)
          pickGrant(
            'class-tools',
            'Narzędzia klasy',
            cl.toolCount,
            id === 'zwiadowca'
              ? toolOptions.filter((o) =>
                  ['tool:smith', 'tool:mechanic', 'tool:butcher'].includes(
                    o.id,
                  ),
                )
              : toolOptions,
            cl.label,
          );
        instruments('class-instruments', cl.instruments, cl.label);
        addOrigin('origin');
        takeFeat('start', true);
      } else {
        if (id === 'brutal') {
          cl.weapons.forEach((w) =>
            grant('weapon:' + w, 'Wieloklasowość: ' + cl.label),
          );
          grant('armor:shield', cl.label);
        } else
          pickGrant(
            'multiclass-skills',
            'Umiejętność nowej klasy',
            1,
            id === 'zwiadowca' ? available(skillOptions) : available(list),
            'Wieloklasowość: ' + cl.label,
          );
        if (id === 'cwaniak') {
          instruments('multiclass-instruments', 1, cl.label);
          grant('armor:light', cl.label);
        }
        if (id === 'spec')
          pickGrant(
            'multiclass-tools',
            'Narzędzie nowej klasy',
            1,
            available(toolOptions),
            cl.label,
          );
        if (id === 'zlodziej') {
          grant('tool:locksmith', cl.label);
          grant('armor:light', cl.label);
        }
        if (id === 'twardziel' || id === 'zwiadowca') {
          pickGrant(
            'multiclass-weapons',
            'Kategorie broni nowej klasy',
            2,
            weaponOptions,
            cl.label,
          );
          ['light', 'medium', 'shield'].forEach((a) =>
            grant('armor:' + a, cl.label),
          );
        }
      }
    }
    (cl.progression[classLevel] ?? []).forEach((label, i) =>
      rules.push({
        id: `class.${id}.${classLevel}.${i}`,
        label,
        page: classRulePage(id, classLevel, label),
        summary: '',
        level: level + 1,
      }),
    );
    if (classLevel === 3) {
      const p = choose(
        'profession',
        'Profesja',
        1,
        cl.professions.map((p) => ({ id: p, label: professions[p]!.label })),
      )[0];
      if (p) {
        professionByClass[id] = p;
        professionGrants(p, professions[p]!.label);
        professionAbility(p, 'profession-ability');
      }
    }
    if ((id === 'twardziel' ? [7, 11] : [6, 10]).includes(classLevel)) {
      const p = professionByClass[id];
      if (id === 'twardziel') {
        if (p) professionAbility(p, 'profession-ability');
      } else {
        const mode = choose('profession-or-feat', 'Rozwój profesji', 1, [
          { id: 'profession', label: 'Zdolność profesji' },
          { id: 'feat', label: 'Sztuczka zamiast zdolności' },
        ])[0];
        if (mode === 'feat') takeFeat('profession-feat');
        else if (mode === 'profession' && p)
          professionAbility(p, 'profession-ability');
      }
    }
    if (
      (id === 'twardziel' ? [4, 6, 8, 10, 12] : [4, 8, 12]).includes(classLevel)
    )
      takeFeat('feat');
    if (id === 'zlodziej' && classLevel === 1) {
      choose(
        'expert-skill',
        'Specjalizacja umiejętności',
        1,
        available(skillOptions, true),
      ).forEach((t) => specialize(t, 'Specjalizacja Złodzieja'));
      choose(
        'expert-tool',
        'Specjalizacja narzędzia',
        1,
        available(toolOptions, true),
      ).forEach((t) => specialize(t, 'Specjalizacja Złodzieja'));
    }
    if (
      (id === 'zlodziej' && classLevel === 5) ||
      (id === 'spec' && classLevel === 7) ||
      (id === 'cwaniak' && classLevel === 4)
    ) {
      const selected = choose(
        'expertise',
        'Specjalizacja',
        id === 'zlodziej' ? 1 : 2,
        available(mixedOptions, true),
      );
      if (id === 'cwaniak' && selected.every((t) => t.startsWith('tool:')))
        issue(
          `level-${level}-expertise`,
          'Ekspert: wybierz co najmniej jedną umiejętność.',
        );
      selected.forEach((t) => specialize(t, cl.label + ': specjalizacja'));
    }
    if (
      (id === 'spec' && classLevel === 5) ||
      (id === 'cwaniak' && classLevel === 9)
    ) {
      const selected = choose(
        'learning',
        'Nowe biegłości',
        2,
        available(mixedOptions),
      );
      const toolCount = selected.filter((s) => s.startsWith('tool:')).length;
      if (id === 'spec' && toolCount === 1)
        issue(
          `level-${level}-learning`,
          'Wykształciuch: dwie umiejętności albo dwa narzędzia.',
        );
      if (id === 'cwaniak' && toolCount === 2)
        issue(
          `level-${level}-learning`,
          'Samouk: co najmniej jedna umiejętność.',
        );
      selected.forEach((t) => grant(t, cl.label + ': nauka'));
      if (id === 'spec') addOrigin('extra-origin');
    }
    if (
      (id === 'twardziel' && [1, 7].includes(classLevel)) ||
      (id === 'zwiadowca' && [2, 11].includes(classLevel))
    ) {
      const list = [
        { id: 'armor', label: 'Obsługa pancerza (+2 TT)' },
        { id: 'butcher', label: 'Rzeźnik' },
        { id: 'eye', label: 'Sokole oko' },
        { id: 'wrist', label: 'Stalowy nadgarstek' },
        ...(id === 'zwiadowca'
          ? [
              { id: 'rider', label: 'Jeździec' },
              { id: 'ambush', label: 'Zasadzka' },
            ]
          : []),
      ];
      choose(
        'veteran',
        'Wyjadacz',
        1,
        list.filter((o) => !styles.has(o.id)),
      ).forEach((s) => styles.add(s));
    }
    if (
      (id === 'twardziel' && [1, 4, 7, 10].includes(classLevel)) ||
      (id === 'zwiadowca' && [1, 9].includes(classLevel)) ||
      (id === 'zlodziej' && classLevel === 2)
    )
      choose('favorite-weapon', 'Ulubiony model broni', 1, [], true);
    if (id === 'zwiadowca') {
      const prior = sheet.levels
        .slice(0, level)
        .flatMap((l) =>
          l.classId === 'zwiadowca' ? (l.choices['enemy'] ?? []) : [],
        );
      if ([1, 5, 9].includes(classLevel))
        choose(
          'enemy',
          'Mój wróg',
          1,
          [
            { id: 'human', label: 'Ludzie' },
            { id: 'machine', label: 'Maszyny' },
            { id: 'mutant', label: 'Mutanci' },
            { id: 'monster', label: 'Potwory' },
            { id: 'animal', label: 'Zwierzęta' },
          ].filter((o) => !prior.includes(o.id)),
        );
      if ([1, 4, 7, 10].includes(classLevel)) {
        const selected = sheet.levels
          .slice(0, level)
          .flatMap((l) =>
            l.classId === 'zwiadowca' ? (l.choices['biome'] ?? []) : [],
          );
        const biomes = [
          'Bagna',
          'Góry',
          'Las',
          'Miasto',
          'Neodżungla',
          'Podziemia',
          'Preria',
          'Pustynia',
          'Ruiny',
          'Tereny maszyn',
        ];
        choose(
          'biome',
          'Mój biom',
          classLevel === 1 ? 2 : 1,
          biomes
            .map((label, i) => ({ id: String(i), label }))
            .filter((o) => !selected.includes(o.id)),
        );
      }
    }
  }
  // Stale dependent choices are surfaced, never silently applied or discarded.
  sheet.levels.forEach((l, i) =>
    Object.keys(l.choices).forEach((key) => {
      if (!choices.some((c) => c.level === i && c.key === key))
        issue(
          `level-${i}-stale`,
          `Usuń nieaktualny wybór „${key}” po zmianie wcześniejszych danych.`,
        );
    }),
  );
  if (counts.twardziel >= 9) {
    let acquired = 0;
    level = sheet.levels.findIndex(
      (l) => l.classId === 'twardziel' && ++acquired === 9,
    );
    ABILITIES.forEach((a) => grant('save:' + a, 'Nie klękam'));
  }
  if (scores.con !== null && scores.con < 1)
    issue('ability-con', 'Kondycja musi pozostać dodatnia.');
  for (const t of sheet.learned ?? [])
    if (t.afterLevel >= sheet.levels.length)
      grant(t.target, 'Trening podczas postoju');
  const overrideTargets = [
    ...ABILITIES.map((a) => 'score:' + a),
    ...ABILITIES.map((a) => 'save:' + a),
    ...skills.map((s) => 'skill:' + s.id),
    ...tools.map((t) => 'tool:' + t.id),
    'hpMax',
    'initiative',
    'speed',
    'perception',
    'armor',
    'carry',
    'maxCarry',
    'longJump',
    'highJump',
  ];
  const replacementTargets = new Set<string>();
  for (const o of sheet.overrides) {
    if (
      !overrideTargets.includes(o.target) ||
      !o.reason.trim() ||
      (o.mode === 'replace' && replacementTargets.has(o.target))
    )
      issue(
        'overrides',
        'Nieprawidłowy zapis modyfikatora: wymagane pole i opis, najwyżej jedno zastąpienie na pole.',
      );
    if (
      (o.target.startsWith('score:') || o.target === 'hpMax') &&
      !Number.isInteger(o.value)
    )
      issue('overrides', 'Cechy i PW muszą być liczbami całkowitymi.');
    if (o.mode === 'replace') replacementTargets.add(o.target);
  }
  function result(
    target: string,
    components: Component[],
    unknown = false,
    conditions: string[] = [],
  ): Value {
    const corrections = sheet.overrides.filter(
      (o) => o.target === target && o.reason.trim(),
    );
    const replacement = corrections.find((o) => o.mode === 'replace');
    const parts = replacement
      ? [
          {
            source: `MG — zastąpienie: ${replacement.reason}`,
            value: replacement.value,
          },
        ]
      : components;
    const combined = [
      ...parts,
      ...corrections
        .filter((o) => o.mode === 'add')
        .map((o) => ({ source: `MG: ${o.reason}`, value: o.value })),
    ];
    return {
      value:
        unknown && !replacement
          ? null
          : combined.reduce((s, c) => s + c.value, 0),
      components: combined,
      conditions,
      unresolvedRuleIds: unknown && !replacement ? ['missing-input'] : [],
    };
  }
  const derivedScores = Object.fromEntries(
    ABILITIES.map((a) => [
      a,
      result('score:' + a, scoreParts[a], scores[a] === null),
    ]),
  ) as Record<Ability, Value>;
  for (const a of ABILITIES) {
    scores[a] = derivedScores[a].value;
    if (scores[a] !== null && (scores[a] < 1 || scores[a] > 30))
      issue('overrides', 'Wynik cechy musi mieścić się w zakresie 1–30.');
  }
  const modifiers = Object.fromEntries(
    ABILITIES.map((a) => [a, modifier(scores[a])]),
  ) as Record<Ability, number | null>;
  const totalLevel = sheet.levels.length,
    pb = proficiencyBonus(totalLevel);
  function check(target: string, ability: Ability): Value {
    const r = rank(target);
    const pbValue = r
      ? pb * r
      : target.startsWith('skill:') && counts.spec >= 9
        ? Math.floor(pb / 2)
        : 0;
    const parts = [
      { source: abilityNames[ability], value: modifiers[ability] ?? 0 },
      {
        source:
          r === 2
            ? 'Specjalizacja'
            : r === 1
              ? 'Biegłość'
              : pbValue
                ? 'Bystrzacha'
                : 'Bez biegłości',
        value: pbValue,
      },
    ];
    if (target === 'skill:stealth' && profChosen.has('rat.1')) {
      const ability = sheet.levels.flatMap(
        (l) => l.choices['profession-ability-grey'] ?? [],
      )[0] as Ability | undefined;
      if (ability && modifiers[ability] !== null)
        parts.push({ source: 'Szary', value: modifiers[ability]! });
    }
    if (target === 'skill:perception' && activeFeats.has('instinct'))
      parts.push({ source: 'Pierwotny instynkt', value: 5 });
    return result(
      target,
      parts,
      modifiers[ability] === null,
      (advantages[target] ?? []).map((s) => 'Ułatwienie: ' + s),
    );
  }
  if (counts.zwiadowca >= 7) adv('skill:perception', 'Wyczulone zmysły');
  const hpHistory = sheet.levels.map((entry, i) => {
    const cl = classes[entry.classId],
      base = i === 0 ? (cl.hitDie === 8 ? 16 : 12) : cl.hitDie === 8 ? 4 : 3,
      color = i === 0 ? 0 : colorHp[entry.color],
      raw = modifiers.con === null ? null : base + modifiers.con + color;
    return {
      level: i + 1,
      classId: entry.classId,
      color: entry.color,
      contextRevision: entry.contextRevision,
      base,
      constitution: modifiers.con,
      colorModifier: color,
      value: raw === null ? null : i === 0 ? raw : Math.max(0, raw),
    };
  });
  const hpMax = result(
    'hpMax',
    hpHistory.map((h) => ({
      source: `Poziom ${h.level}: ${classes[h.classId].label}`,
      value: h.value ?? 0,
    })),
    modifiers.con === null,
  );
  if (hpMax.value !== null && hpMax.value < 0)
    issue('overrides', 'Maksymalne PW nie mogą być ujemne.');
  const initiativeParts = [
    { source: 'Zręczność', value: modifiers.dex ?? 0 },
    ...(activeFeats.has('instinct')
      ? [{ source: 'Pierwotny instynkt', value: 5 }]
      : []),
    ...(activeFeats.has('bill') ? [{ source: 'Szybki Bill', value: pb }] : []),
  ];
  const speedParts = [
    { source: 'Szybkość bazowa', value: 9 },
    ...(counts.brutal >= 7 ? [{ source: 'Szaleńcza szarża', value: 3 }] : []),
    ...(counts.zlodziej >= 5 ? [{ source: 'Szybkość kota', value: 3 }] : []),
    ...(counts.zwiadowca >= 7 ? [{ source: 'Sportowiec', value: 3 }] : []),
    ...(activeFeats.has('stand')
      ? [{ source: 'Padnij/powstań', value: 3 }]
      : []),
  ];
  const jumpAbility: Ability = profChosen.has('rat.3') ? 'dex' : 'str';
  const perceptionCheck = check('skill:perception', 'wis');
  const perception = result(
    'perception',
    [
      { source: 'Podstawa', value: 10 },
      { source: 'Test Percepcji', value: perceptionCheck.value ?? 0 },
      ...(advantages['skill:perception']?.length
        ? [{ source: 'Stałe Ułatwienie Percepcji', value: 5 }]
        : []),
    ],
    perceptionCheck.value === null,
  );
  const carryMultiplier =
    1 +
    (origin?.id === 'appalachia' && originChosen.has('miner') ? 1 : 0) +
    (activeFeats.has('packing') ? 1 : 0);
  const sizeFactors = {
    tiny: [1, 2],
    small: [2, 4],
    medium: [5, 10],
    large: [10, 20],
    huge: [20, 40],
    gargantuan: [40, 80],
  }[sheet.identity.size];
  const carry = result(
    'carry',
    [
      { source: 'Siła × wielkość', value: (scores.str ?? 0) * sizeFactors[0]! },
      {
        source: 'Sumowane premie udźwigu',
        value: (scores.str ?? 0) * sizeFactors[0]! * (carryMultiplier - 1),
      },
    ],
    scores.str === null,
  );
  const maxCarry = result(
    'maxCarry',
    [
      { source: 'Siła × wielkość', value: (scores.str ?? 0) * sizeFactors[1]! },
      {
        source: 'Sumowane premie udźwigu',
        value: (scores.str ?? 0) * sizeFactors[1]! * (carryMultiplier - 1),
      },
    ],
    scores.str === null,
  );
  const armorBases = [
    {
      id: 'base',
      label: 'Bez pancerza',
      value: modifiers.dex === null ? null : 10 + modifiers.dex,
      conditions: ['Bez pancerza.'],
    },
  ];
  if (counts.brutal > 0)
    armorBases.push({
      id: 'bare',
      label: 'Goła klata',
      value:
        modifiers.dex === null || modifiers.con === null
          ? null
          : 10 + modifiers.dex + modifiers.con,
      conditions: ['Bez pancerza, hełmu i tarczy.'],
    });
  if (profChosen.has('preacher.3'))
    armorBases.push({
      id: 'faith',
      label: 'Tarcza Wiary',
      value:
        modifiers.dex === null || modifiers.cha === null
          ? null
          : 10 + modifiers.dex + modifiers.cha,
      conditions: ['Bez pancerza.'],
    });
  // Obsługa pancerza requires worn armor, so it is not part of any unarmored formula.
  const armorBonus = activeFeats.has('bulletproof') ? pb : 0;
  const armor = armorBases.map((base) => ({
    ...base,
    result: result(
      'armor',
      [
        { source: base.label, value: base.value ?? 0 },
        ...(armorBonus ? [{ source: 'Kuloodporność', value: armorBonus }] : []),
      ],
      base.value === null,
      [
        ...base.conditions,
        ...(activeFeats.has('bulletproof')
          ? ['Kuloodporność: bez pancerza, hełmu i tarczy.']
          : []),
      ],
    ),
  }));
  const xp = sheet.xp.reduce((s, e) => s + e.amount, 0);
  if (new Set(sheet.xp.map((x) => x.id)).size !== sheet.xp.length)
    issue('xp', 'Powtórzony identyfikator nagrody PD.');
  if (xp < 0) issue('xp', 'Suma PD nie może być ujemna.');
  if (sheet.advancementMode === 'xp' && xp < xpThresholds[totalLevel - 1]!)
    issue(
      'xp',
      `Poziom ${totalLevel} wymaga ${xpThresholds[totalLevel - 1]} PD.`,
    );
  return {
    issues,
    choices,
    grants,
    rules: rules.map((rule) => ({
      ...rule,
      summary: describeCharacterRule(rule.id, counts) ?? rule.summary,
    })),
    scores: derivedScores,
    modifiers,
    pb,
    totalLevel,
    classLevels: counts,
    professionByClass,
    pointTotal,
    xp,
    xpLevel: xpThresholds.filter((t) => t <= xp).length,
    hpHistory,
    hpMax,
    hitDice: {
      6: sheet.levels.filter((l) => classes[l.classId].hitDie === 6).length,
      8: sheet.levels.filter((l) => classes[l.classId].hitDie === 8).length,
    },
    initiative: result(
      'initiative',
      initiativeParts,
      modifiers.dex === null,
      counts.brutal >= 9 ? ['Ułatwienie: Paranoja'] : [],
    ),
    speed: result('speed', speedParts),
    perception,
    carry,
    maxCarry,
    longJump: result(
      'longJump',
      [
        {
          source: '0,3 × ' + abilityNames[jumpAbility],
          value: Math.max(0, 0.3 * (scores[jumpAbility] ?? 0)),
        },
      ],
      scores[jumpAbility] === null,
    ),
    highJump: result(
      'highJump',
      [
        {
          source: '0,3 × (2 + modyfikator ' + abilityNames[jumpAbility] + ')',
          value: Math.max(0, 0.3 * (2 + (modifiers[jumpAbility] ?? 0))),
        },
      ],
      modifiers[jumpAbility] === null,
    ),
    climb: profChosen.has('rat.3') ? result('speed', speedParts).value : null,
    swim: origin?.id === 'miami' && originChosen.has('alligator') ? 9 : null,
    armor,
    overrideTargets,
    check,
    rank,
    activeFeats: [...activeFeats],
  };
}
export function featRequirementLabels(f: Feat): string {
  return (
    f.requires
      .map((group) =>
        group
          .map((r) => {
            const [kind = '', id = ''] = r.split(':');
            return ABILITIES.includes(kind as Ability)
              ? `${abilityNames[kind as Ability]} ${id}`
              : kind === 'skill'
                ? (skills.find((s) => s.id === id)?.label ?? id)
                : kind === 'tool'
                  ? (tools.find((t) => t.id === id)?.label ?? id)
                  : kind === 'weapon'
                    ? weaponNames[id]
                    : kind === 'armor'
                      ? armorNames[id]
                      : `${id} narzędzia`;
          })
          .join(' lub '),
      )
      .join(', ') || 'Brak wymagań'
  );
}
export function deriveWeapon(
  ability: number | null,
  pb: number,
  proficient: boolean,
  series = false,
) {
  return {
    attack: ability === null ? null : ability + (proficient ? pb : 0),
    damageModifier: series ? 0 : ability,
  };
}
