import type { Character } from './model';
import { conditionView } from './condition';

// Only facts recorded on the sheet. Target, terrain, light and other fictional
// circumstances remain the player's responsibility (including My Enemy).
export function characterRollConditions(record: Character, targets: string[]) {
  const v = conditionView(record);
  const has = (id: string) => v.derived.rules.some((r) => r.id === id);
  const is = (target: string) => targets.includes(target);
  const save = is('save');
  const attack = is('attack');
  const abilityCheck = !save && !attack;
  const advantage: string[] = [],
    disadvantage: string[] = [];
  const add = (yes: boolean, label: string, bad = false) => {
    if (yes) (bad ? disadvantage : advantage).push(label);
  };
  add(
    has('origin.appalachia.miner') && is('skill:athletics') && is('str'),
    'Górnik z dziada pradziada',
  );
  add(
    has('origin.miami.sick') && save && is('con'),
    'Ja już swoje odchorowałem',
  );
  add(
    has('origin.hegemony.dog') && is('skill:intimidation'),
    'Wiesz, zjadłem własnego psa',
  );
  add(has('origin.texas.quinn') && is('skill:medicine'), 'Doktor Quinn');
  add(has('origin.texas.healthy') && save && is('con'), 'Zdrowa okolica');
  add(
    has('origin.vegas.telepath') && is('skill:insight') && is('wis'),
    'Telepata',
  );
  add(
    v.derived.classLevels.brutal >= 9 && is('initiative'),
    'Paranoja Brutala',
  );
  add(
    v.derived.classLevels.zwiadowca >= 7 && is('skill:perception'),
    'Wyczulone zmysły',
  );
  add(has('feat.immunity') && save && is('disease'), 'Immunitet');
  for (const d of v.state.care?.diseases ?? []) {
    if (!d.active || d.onsetAt > v.state.worldMinutes) continue;
    const physical = is('str') || is('con');
    if (d.kind === 'circulation')
      add(
        d.stage === 2 ||
          (physical && (abilityCheck || (d.stage >= 1 && save))) ||
          (d.stage >= 1 && attack && is('str')),
        'Niewydolność krążenia',
        true,
      );
    if (d.kind === 'thurman')
      add(
        (d.stage === 0 && is('int')) || (d.stage === 1 && is('cha')),
        'Syndrom Thurmana',
        true,
      );
    if (d.kind === 'boston') {
      add(d.stage === 0 && is('skill:intimidation'), 'Szaleństwo bostońskie');
      add(
        (d.stage === 0 && (is('skill:persuasion') || is('skill:deception'))) ||
          (d.stage === 1 && abilityCheck && (is('int') || is('cha'))),
        'Szaleństwo bostońskie',
        true,
      );
    }
    if (d.kind === 'osteoporosis')
      add(d.stage === 1 && is('str'), 'Osteoporoza', true);
    if (d.kind === 'paranoia') {
      add(
        d.stage === 0 && (is('skill:insight') || is('skill:perception')),
        'Paranoja — choroba',
      );
      add(
        (d.stage === 0 && (is('skill:persuasion') || is('skill:deception'))) ||
          (d.stage === 1 &&
            (is('int') ||
              is('wis') ||
              is('skill:persuasion') ||
              is('skill:deception') ||
              is('skill:intimidation'))),
        'Paranoja — choroba',
        true,
      );
    }
    if (d.kind === 'labyrinth')
      add(
        d.stage === 2 || (d.stage === 1 && attack),
        'Zaburzenia błędnika',
        true,
      );
    // Dracula, labyrinth passenger effects and fear require circumstances in
    // the fiction; they deliberately remain manual, with descriptions on card.
  }
  const benefits = (v.state.downtime?.benefits ?? []).filter(
    (b) => b.expiresAt === null || b.expiresAt > v.state.worldMinutes,
  );
  const meal = save
    ? benefits.find(
        (b) =>
          b.kind === 'mealSave' ||
          (!b.kind &&
            b.label === 'Posiłek: Ułatwienie najbliższego dowolnego RO'),
      )
    : undefined;
  add(!!meal, 'Posiłek');
  add(
    benefits.some(
      (b) =>
        b.kind === 'ar23Social' ||
        (!b.kind && b.label === 'AR-23: Utrudnienie Perswazji i Oszustwa'),
    ) &&
      (is('skill:persuasion') || is('skill:deception')),
    'AR-23',
    true,
  );
  return { advantage, disadvantage, consumedBenefits: meal ? [meal.id] : [] };
}
