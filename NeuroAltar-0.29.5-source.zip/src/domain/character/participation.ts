import { characterConditionEffects } from './conditionEffects';
import { z } from 'zod';
import { conditionSheet, initialCondition } from './condition';
import { deriveCharacter } from './derive';
import { deriveEquipment } from './equipped';
import { emptyInventory } from './inventoryModel';
import type { Character } from './model';
export const combatEffectSchema = z
  .object({
    id: z.uuid(),
    label: z.string().min(1).max(300),
    speedReduction: z.number().min(0).max(100).optional(),
    condition: z.enum(['bleeding', 'blinded']).optional(),
    recipientActorId: z.uuid().optional(),
    checkDice: z
      .string()
      .regex(/^1k(4|6|8|10|12)$/)
      .optional(),
    nextRoll: z.boolean().optional(),
    clockActorId: z.uuid().optional(),
    sourceRuleId: z.string().max(150).optional(),
    damageDice: z
      .string()
      .regex(/^([1-9]|[1-9][0-9])k(4|6|8|10|12|20)$/)
      .optional(),
    remaining: z.number().int().min(1).max(1000),
    phase: z.enum(['start', 'end', 'round', 'manual']),
    target: z.enum([
      'attackSave',
      'intTools',
      'tt',
      'all',
      'attack',
      'damage',
      'str',
      'dex',
      'con',
      'int',
      'wis',
      'cha',
      'save',
      'skill',
    ]),
    modifier: z.number().int().min(-100).max(100),
    mode: z.enum(['normal', 'advantage', 'disadvantage']),
  })
  .strict();
export const participationSchema = z
  .object({
    id: z.uuid(),
    characterId: z.uuid(),
    encounterId: z.number().int().min(1).max(5),
    actorId: z.uuid(),
    revision: z.number().int().min(0),
    state: z.enum(['prepared', 'active', 'ended']),
    budget: z
      .object({
        use: z.number().int().min(0),
        attacks: z.number().int().min(0).max(3),
        action: z.number().int().min(0),
        bonus: z.number().int().min(0),
        reaction: z.number().int().min(0),
        interaction: z.number().int().min(0),
      })
      .strict(),
    effects: z.array(combatEffectSchema),
    usedRound: z.array(z.string()),
    weapons: z.record(z.string(), z.unknown()),
    legacy: z.unknown(),
  })
  .strict();
export type Participation = z.infer<typeof participationSchema>;
export type CombatEffect = z.infer<typeof combatEffectSchema>;
export const costNames = {
  use: 'Dodatkowe Używanie',
  action: 'Akcja',
  bonus: 'Akcja Bonusowa',
  reaction: 'Reakcja',
  interaction: 'Interakcja',
};
export function characterCombatValues(c: Character, p?: Participation) {
  if (!c.sheet) return null;
  const condition = c.condition ?? initialCondition(c),
    sheet = conditionSheet(c.sheet, condition),
    derived = deriveCharacter(sheet),
    equipment = deriveEquipment(
      sheet,
      c.inventory ?? emptyInventory(),
      condition,
    );
  return {
    condition,
    sheet,
    derived,
    equipment,
    consequences: characterConditionEffects(condition),
    name: sheet.identity.name,
    hp: condition.hp,
    hpMax: Math.max(
      0,
      (derived.hpMax.value ?? 0) -
        condition.effects
          .filter((e) => e.target === 'hpMax')
          .reduce((s, e) => s + e.amount, 0),
    ),
    tt:
      (p?.effects
        .filter((e) => !e.recipientActorId && e.target === 'tt')
        .reduce((sum, e) => sum + e.modifier, 0) ?? 0) +
      Math.max(0, ...equipment.armor.map((a) => a.value ?? 0)) +
      (p?.effects.some((e) => e.label === 'Berserk') &&
      !c.inventory?.entries.some(
        (e) =>
          e.slot !== 'none' &&
          e.armor &&
          ['light', 'medium', 'heavy', 'helmet', 'shield'].includes(
            e.armor.kind,
          ),
      )
        ? (derived.modifiers.str ?? 0)
        : 0),
    speed:
      characterConditionEffects(condition).fatal ||
      p?.usedRound.includes('actor-turn:ability:feat.steady')
        ? 0
        : equipment.encumbrance.speed === null
          ? null
          : Math.max(
              0,
              equipment.encumbrance.speed -
                Math.max(
                  0,
                  ...(p?.effects
                    .filter((e) => !e.recipientActorId)
                    .map((e) => e.speedReduction ?? 0) ?? []),
                ),
            ),
  };
}
export function checkContext(
  effects: CombatEffect[],
  targets: string[],
  advantage = false,
  disadvantage = false,
) {
  const applicable = effects.filter(
    (e) =>
      !e.recipientActorId &&
      ((e.target === 'all' && !targets.includes('damage')) ||
        targets.includes(e.target) ||
        (e.target === 'attackSave' &&
          targets.some((t) => ['attack', 'save'].includes(t))) ||
        (e.target === 'intTools' &&
          targets.some((t) => t === 'int' || t === 'tool'))) &&
      !(e.label === 'Berserk' && targets.includes('attack')),
  );
  advantage ||= applicable.some((e) => e.mode === 'advantage');
  disadvantage ||= applicable.some((e) => e.mode === 'disadvantage');
  return {
    modifier: applicable.reduce((s, e) => s + e.modifier, 0),
    mode:
      advantage === disadvantage
        ? ('normal' as const)
        : advantage
          ? ('advantage' as const)
          : ('disadvantage' as const),
  };
}
export function bleedingPerTurn(color: string, injury: number) {
  return injury > 0 && ['rust', 'mercury'].includes(color) ? 1 : 0;
}
