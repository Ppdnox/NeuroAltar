import {
  itemWeight,
  medicineWithoutMass,
  medicineWeightReason,
} from '../medicineWeight';
import { z } from 'zod';
import { itemSchema, type Item } from '../item';

export const PLACES = {
  body: 'Przy sobie',
  handy: 'Pod ręką',
  backpack: 'Plecak',
  external: 'Juki / przechowywane',
} as const;
export const SLOTS = {
  none: 'Niewyposażony',
  armor: 'Pancerz',
  helmet: 'Hełm',
  arms: 'Ochraniacze rąk',
  legs: 'Ochraniacze nóg',
  shield: 'Tarcza',
  melee1: 'Broń Biała 1',
  melee2: 'Broń Biała 2',
  melee3: 'Broń Biała 3',
  melee4: 'Broń Biała 4',
  ranged1: 'Broń Dystansowa 1',
  ranged2: 'Broń Dystansowa 2',
  ranged3: 'Broń Dystansowa 3',
  handy1: 'Przedmiot Podręczny 1',
  handy2: 'Przedmiot Podręczny 2',
  handy3: 'Przedmiot Podręczny 3',
  mainHand: 'Prawa ręka',
  offHand: 'Lewa ręka',
  bothHands: 'Obie ręce',
} as const;
const text = z.string().max(300);
const integer = z.number().int().min(0).max(1_000_000_000);
export const weaponRulesSchema = z
  .object({
    category: z.enum([
      'melee',
      'thrown',
      'short',
      'intermediate',
      'long',
      'heavy',
      'special',
      'improvised',
    ]),
    model: text.min(1),
    family: z.enum(['revolver', 'smg', 'axe']).optional(),
    caliber: text,
    system: z.enum(['none', 'detachable', 'internal', 'loading', 'singleUse']),
    capacity: z.number().int().min(0).max(10000),
    modes: z
      .array(z.enum(['single', 'double', 'short', 'long', 'massive']))
      .min(1),
    cycle: z.boolean(),
    twoHanded: z.boolean(),
    handy: z.boolean(),
    source: text.min(1),
  })
  .strict();
export const armorRulesSchema = z
  .object({
    kind: z.enum([
      'light',
      'medium',
      'heavy',
      'helmet',
      'arms',
      'legs',
      'shield',
    ]),
    base: z.number().int().min(0).max(100),
    dexCap: z.number().int().min(0).max(30).nullable(),
    strength: z.number().int().min(0).max(30),
    penalty: z.enum(['none', 'disadvantage', 'impossible']),
    threshold: z.number().int().min(0).max(100),
    source: text.min(1),
  })
  .strict();
export const magazineSchema = z
  .object({
    capacity: z.number().int().min(1).max(10000),
    caliber: text.min(1),
    model: text.min(1),
    rounds: z
      .array(
        z
          .object({
            ammoId: z.uuid(),
            count: z.number().int().min(1).max(10000),
          })
          .strict(),
      )
      .max(1000),
  })
  .strict();
export const inventoryEntrySchema = z
  .object({
    id: z.uuid(),
    item: itemSchema,
    catalogId: z.uuid().nullable(),
    quantityMilli: integer,
    unit: text.min(1),
    weightMg: integer.nullable(),
    weightReason: text,
    massMode: z.enum(['unit', 'aggregate']),
    container: z.boolean(),
    location: z.enum(['body', 'handy', 'backpack', 'external']),
    parentId: z.uuid().nullable(),
    slot: z.enum([
      'none',
      'armor',
      'helmet',
      'arms',
      'legs',
      'shield',
      'melee1',
      'melee2',
      'melee3',
      'melee4',
      'ranged1',
      'ranged2',
      'ranged3',
      'handy1',
      'handy2',
      'handy3',
      'mainHand',
      'offHand',
      'bothHands',
    ]),
    grip: z.enum(['oneHanded', 'twoHanded']).optional(),
    paidMilli: integer.nullable(),
    notes: z.string().max(10000),
    caliber: text,
    weapon: weaponRulesSchema.nullable(),
    armor: armorRulesSchema.nullable(),
    magazine: magazineSchema.nullable(),
    installedMagazineId: z.uuid().nullable(),
    needsCycle: z.boolean(),
    cinematicLoaded: z.boolean(),
    spent: z.boolean(),
    combatState: z
      .object({
        jammed: z.boolean(),
        overheated: z.boolean(),
        heatPending: z.boolean(),
      })
      .strict()
      .optional(),
    armorDamage: z.number().int().min(0).max(100),
  })
  .strict();
export const inventorySchema = z
  .object({
    entries: z.array(inventoryEntrySchema).max(5000),
    ammoMode: z.enum(['auto', 'tracked', 'cinematic']),
    starterClaims: z.array(text.min(1)).max(100),
  })
  .strict();
export type Inventory = z.infer<typeof inventorySchema>;
export type InventoryEntry = z.infer<typeof inventoryEntrySchema>;
export type WeaponRules = z.infer<typeof weaponRulesSchema>;
export type ArmorRules = z.infer<typeof armorRulesSchema>;
export type FireMode = WeaponRules['modes'][number];
export const emptyInventory = (): Inventory => ({
  entries: [],
  ammoMode: 'auto',
  starterClaims: [],
});
export type InventoryAction =
  | {
      kind: 'weaponState';
      weaponId: string;
      operation: 'jam' | 'clearJam' | 'heat' | 'cool';
      face: number | null;
      reason: string;
    }
  | { kind: 'edit'; entry: InventoryEntry; reason: string }
  | { kind: 'remove'; entryId: string; reason: string }
  | { kind: 'load'; magazineId: string; ammoId: string; count: number }
  | { kind: 'unload'; magazineId: string }
  | { kind: 'attach'; weaponId: string; magazineId: string | null }
  | { kind: 'cycle'; weaponId: string }
  | {
      kind: 'shot';
      weaponId: string;
      mode: FireMode;
      count: number;
      favoriteBonus?: boolean;
    }
  | { kind: 'cinematic'; weaponId: string; loaded: boolean }
  | { kind: 'mode'; mode: Inventory['ammoMode'] }
  | { kind: 'starter'; key: string; entries: InventoryEntry[] };
export function newInventoryEntry(item: Item): InventoryEntry {
  const weight = itemWeight(item);
  return {
    id: crypto.randomUUID(),
    item: structuredClone(item),
    catalogId: item.id,
    quantityMilli: 1000,
    unit: 'szt.',
    weightMg: weight === null ? null : Math.floor(weight * 1_000_000),
    weightReason: medicineWithoutMass(item)
      ? medicineWeightReason
      : weight === null
        ? ''
        : 'Masa katalogowa',
    massMode: 'unit',
    container: false,
    location: 'backpack',
    parentId: null,
    slot: 'none',
    paidMilli: null,
    notes: '',
    caliber: '',
    weapon: null,
    armor: null,
    magazine: null,
    installedMagazineId: null,
    needsCycle: false,
    cinematicLoaded: false,
    spent: false,
    armorDamage: 0,
  };
}
