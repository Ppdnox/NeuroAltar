import type { Character } from './model';
import type { Participation } from './participation';
import { conditionView } from './condition';
import {
  abilityApplicationSchema,
  type AbilityResolution,
} from './combatAbility';
import type { ConditionAction } from './conditionModel';
export type ActiveAbilityKind =
  | 'trajectory'
  | 'catDefense'
  | 'sneakBleed'
  | 'sneakSlow'
  | 'sneakBlind'
  | 'matrix'
  | 'dodge';
export const activeAbilityLabels: Record<ActiveAbilityKind, string> = {
  trajectory: 'Trajektoria',
  catDefense: 'Koci odskok — premia TT',
  sneakBleed: 'Podstępny atak — krwawienie',
  sneakSlow: 'Podstępny atak — spowolnienie',
  sneakBlind: 'Podstępny atak — oślepienie',
  matrix: 'Matrix',
  dodge: 'Odskok — połowa obrażeń',
};
export function availableActiveAbilities(c: Character): ActiveAbilityKind[] {
  const levels = conditionView(c).derived.classLevels;
  return [
    ...(levels.spec >= 7 ? ['trajectory' as const] : []),
    ...(levels.zlodziej >= 3
      ? ['sneakBleed' as const, 'sneakSlow' as const, 'sneakBlind' as const]
      : []),
    ...(levels.zlodziej >= 5 ? ['dodge' as const] : []),
    ...(levels.zlodziej >= 7 ? ['matrix' as const] : []),
    ...(levels.zlodziej >= 9 ? ['catDefense' as const] : []),
  ];
}
export function activeAbilityCommand(
  c: Character,
  p: Participation,
  kind: ActiveAbilityKind,
  target: { id: string; revision: number; actorId?: string },
  resolution?: AbilityResolution,
): Extract<ConditionAction, { type: 'use' | 'combatAbility' }> {
  if (!availableActiveAbilities(c).includes(kind))
    throw Error('Ta zdolność nie jest dostępna na tym poziomie.');
  if (kind !== 'trajectory' && resolution?.kind !== kind)
    throw Error('Brak rozliczenia zdolności.');
  const v = conditionView(c),
    self = !kind.startsWith('sneak');
  if (self && (target.id !== p.id || target.actorId))
    throw Error('Ta zdolność działa na używającą postać.');
  const resourceId =
    kind === 'trajectory'
      ? 'trajectory'
      : kind === 'catDefense'
        ? 'cat'
        : kind === 'matrix'
          ? 'matrix'
          : null;
  const ruleId = resourceId
    ? 'resource:' + resourceId
    : kind === 'dodge'
      ? 'class.zlodziej.5.0'
      : 'class.zlodziej.3.0';
  const effectBase = {
    id: crypto.randomUUID(),
    label: activeAbilityLabels[kind],
    sourceRuleId: ruleId,
    clockActorId: p.actorId,
    ...(target.actorId ? { recipientActorId: target.actorId } : {}),
    remaining: 1,
    phase: 'manual' as const,
    target: 'all' as const,
    modifier: 0,
    mode: 'normal' as const,
    nextRoll: false,
  };
  let effect: Record<string, unknown> | null = null;
  if (kind === 'trajectory')
    effect = {
      ...effectBase,
      target: 'attack',
      modifier: v.derived.modifiers.int ?? 0,
      nextRoll: true,
    };
  if (resolution?.kind === 'catDefense') {
    const sides = 4 + 2 * Math.floor((v.derived.classLevels.zlodziej - 2) / 3);
    if (resolution.die > sides)
      throw Error('Wynik przekracza rozmiar Kociej kości.');
    effect = {
      ...effectBase,
      label: `Koci odskok — +${resolution.die} TT`,
      target: 'tt',
      modifier: resolution.die,
      phase: 'start',
    };
  }
  if (kind === 'sneakBleed')
    effect = {
      ...effectBase,
      label:
        'Podstępny atak — krwawienie 1k8 na początku tury celu; do opatrzenia',
      condition: 'bleeding',
    };
  if (resolution?.kind === 'sneakSlow')
    effect = {
      ...effectBase,
      label: `Podstępny atak — Szybkość −${resolution.die * 1.5} m`,
      speedReduction: resolution.die * 1.5,
      remaining: 2,
      phase: 'end',
    };
  if (kind === 'sneakBlind')
    effect = {
      ...effectBase,
      label: 'Podstępny atak — Oślepienie',
      condition: 'blinded',
      target: 'attack',
      mode: 'disadvantage',
      remaining: 2,
      phase: 'end',
    };
  const app = abilityApplicationSchema.parse({
    ruleId,
    label: activeAbilityLabels[kind],
    page: kind === 'trajectory' ? 79 : kind === 'catDefense' ? 93 : 92,
    cost: kind === 'catDefense' || kind === 'dodge' ? 'reaction' : 'none',
    once: kind.startsWith('sneak') ? 'turn' : 'none',
    confirmed: true,
    targetId: target.id,
    targetRevision: target.revision,
    effect,
    ...(resolution ? { resolution } : {}),
  });
  return resourceId
    ? {
        type: 'use',
        resourceId,
        amount: 1,
        healingRoll: null,
        combatApplication: app,
      }
    : { type: 'combatAbility', combatApplication: app };
}
export function resolutionSummary(
  resolution: AbilityResolution,
  cha = 0,
): string {
  switch (resolution.kind) {
    case 'catDefense':
      return `Kocia kość: ${resolution.die}; +${resolution.die} TT do początku następnej tury.`;
    case 'deadlyInsult':
      return `Śmiertelna obelga: k6 = ${resolution.die}; ${resolution.die} × CHA ${cha} = ${Math.max(0, resolution.die * cha)} obrażeń psychicznych.`;
    case 'sneakBleed':
      return 'Zamiast dodatkowych obrażeń: krwawienie 1k8 na początku tury celu, do opatrzenia.';
    case 'sneakSlow':
      return `Zamiast dodatkowych obrażeń: k6 = ${resolution.die}; Szybkość −${resolution.die * 1.5} m do końca następnej tury używającego.`;
    case 'sneakBlind':
      return 'Zamiast dodatkowych obrażeń: Oślepienie do końca następnej tury używającego.';
    case 'matrix':
      return `Matrix: ${resolution.incomingDamage} → ${resolution.saveSucceeded ? 0 : Math.floor(resolution.incomingDamage / 2)} obrażeń (${resolution.saveSucceeded ? 'udany' : 'nieudany'} RO na Zręczność).`;
    case 'dodge':
      return `Odskok: ${resolution.incomingDamage} → ${Math.floor(resolution.incomingDamage / 2)} obrażeń.`;
  }
}
