import { characterConditionEffects } from './conditionEffects';
import { weaponTrait } from './weaponTraits';
import {
  isLegacyHandSlot,
  weaponGrip,
  type WeaponGrip,
} from './inventorySlots';
import type { CharacterSheet } from './model';
import type { Condition } from './conditionModel';
import { deriveCharacter } from './derive';
import { calculateCarriedWeight, calculateEncumbrance } from './inventory';
import type { Inventory, InventoryEntry, FireMode } from './inventoryModel';
export function deriveEquipment(
  sheet: CharacterSheet,
  inventory: Inventory,
  condition?: Condition,
) {
  const d = deriveCharacter(sheet),
    worn = inventory.entries.filter((e) => e.slot !== 'none' && e.armor),
    body = worn.find((e) => e.slot === 'armor'),
    shield = worn.some((e) => e.armor?.kind === 'shield'),
    helmet = worn.some((e) => e.armor?.kind === 'helmet');
  const training = d.rules.some((r) => r.id === 'profession.soldier.2');
  const held = inventory.entries.filter(
    (e) => e.weapon && ['mainHand', 'offHand', 'bothHands'].includes(e.slot),
  );
  const guard =
    (d.activeFeats.includes('samurai') &&
    held.some(
      (e) =>
        e.item.weaponProfile?.attackKind === 'melee' &&
        e.item.weaponProfile.abilityRule === 'finesse' &&
        e.item.weaponProfile.damageModes.some((m) =>
          m.damageType.includes('cięte'),
        ),
    )
      ? 1
      : 0) +
    (d.activeFeats.includes('axes') &&
    held.filter((e) => weaponTrait(e, 'axe') && e.slot !== 'bothHands')
      .length === 2
      ? 1
      : 0);
  const style = sheet.levels.some((l) => l.choices.veteran?.includes('armor'));
  const armorBonus = (value: number | null) => {
    let out = value === null ? null : value + guard;
    for (const o of sheet.overrides.filter((o) => o.target === 'armor')) {
      if (out !== null) out = o.mode === 'replace' ? o.value : out + o.value;
    }
    return out;
  };
  const accessories = worn
    .filter((e) => ['arms', 'legs'].includes(e.armor!.kind))
    .reduce((s, e) => s + Math.max(0, e.armor!.base - e.armorDamage), 0);
  let options: { label: string; value: number | null }[];
  if (body) {
    const a = body.armor!;
    const dex =
      a.kind === 'heavy'
        ? 0
        : d.modifiers.dex === null
          ? null
          : Math.min(
              d.modifiers.dex,
              a.dexCap === null ? Infinity : a.dexCap + (training ? 1 : 0),
            );
    options = [
      {
        label: body.item.name,
        value: armorBonus(
          dex === null
            ? null
            : Math.max(0, a.base - body.armorDamage) +
                dex +
                accessories +
                (style ? 2 : 0),
        ),
      },
    ];
  } else {
    const bonus =
      d.activeFeats.includes('bulletproof') && !shield && !helmet ? d.pb : 0;
    options = d.armor
      .filter((a) => a.id !== 'bare' || (!helmet && !shield))
      .map((a) => ({
        label: a.label,
        value: armorBonus(
          a.value === null ? null : a.value + bonus + accessories,
        ),
      }));
  }
  const warnings: string[] = [];
  let strPenalty = false,
    untrained = false;
  for (const e of worn) {
    const a = e.armor!;
    if (d.scores.str.value !== null && d.scores.str.value < a.strength) {
      strPenalty = true;
      warnings.push(`${e.item.name}: za mała Siła, Szybkość −4,5 m.`);
    }
    const trainingKind = a.kind;
    if (
      ['light', 'medium', 'heavy'].includes(a.kind) &&
      d.rank('armor:' + trainingKind) === 0
    ) {
      untrained = true;
      warnings.push(
        `${e.item.name}: brak wyszkolenia — Utrudnienie testów k20 opartych na Sile i Zręczności.`,
      );
    }
    if (a.penalty !== 'none') {
      if (a.penalty === 'impossible')
        warnings.push(`${e.item.name}: pływanie niemożliwe.`);
      else warnings.push(`${e.item.name}: Utrudnienie pływania.`);
      if (!training && d.classLevels.zwiadowca < 3)
        warnings.push(`${e.item.name}: Utrudnienie Skradania.`);
    }
    if (a.kind === 'shield') {
      warnings.push(
        'Tarcza: Parowanie +5 TT wymaga Reakcji; nie jest stałą premią.',
      );
      if (
        d.rank('armor:shield') === 0 ||
        (d.scores.str.value ?? 0) < a.strength
      )
        warnings.push(
          'Tarcza: nie możesz korzystać ze zdolności tarczy bez biegłości i wymaganej Siły.',
        );
    }
    if (a.threshold)
      warnings.push(`${e.item.name}: próg obrażeń ${a.threshold}.`);
  }
  const weight = calculateCarriedWeight(inventory),
    encumbrance = calculateEncumbrance(
      weight.kg,
      weight.complete,
      d.carry.value,
      d.maxCarry.value,
      d.speed.value === null
        ? null
        : Math.max(
            0,
            d.speed.value -
              (strPenalty ? 4.5 : 0) -
              characterConditionEffects(condition).speedPenalty,
          ),
    );
  const diseases = condition?.care?.diseases.filter((d) => d.active) ?? [];
  if (encumbrance.speed !== null) {
    if (
      diseases.some(
        (d) => d.stage === 2 && ['circulation', 'labyrinth'].includes(d.kind),
      )
    )
      encumbrance.speed = 0;
    else if (diseases.some((d) => d.stage === 2 && d.kind === 'osteoporosis'))
      encumbrance.speed *= 0.5;
  }
  if (characterConditionEffects(condition).fatal) encumbrance.speed = 0;
  return {
    armor: options,
    warnings,
    untrained,
    weight,
    encumbrance,
    availabilityBonus: d.rules.some((r) => r.id === 'origin.newyork.gamble')
      ? 5
      : 0,
  };
}
export function deriveInventoryWeapon(
  sheet: CharacterSheet,
  entry: InventoryEntry,
  mode: FireMode = 'single',
  count = 1,
  ability: 'str' | 'dex' | 'auto' = 'auto',
  damageId?: string,
  inventory?: Inventory,
  distance: 'normal' | 'long' = 'normal',
  gripOverride?: WeaponGrip,
) {
  const d = deriveCharacter(sheet),
    p = entry.item.weaponProfile,
    w = entry.weapon;
  if (!p || !w) return null;
  const chosen =
    p.abilityRule === 'finesse'
      ? ability === 'auto'
        ? (d.modifiers.str ?? -99) >= (d.modifiers.dex ?? -99)
          ? 'str'
          : 'dex'
        : ability
      : p.abilityRule;
  const mod = d.modifiers[chosen],
    proficient = d.rank('weapon:' + w.category) > 0;
  const grip = w.twoHanded ? 'twoHanded' : (gripOverride ?? weaponGrip(entry));
  const damage =
    p.damageModes.find(
      (x) =>
        x.id ===
        (!damageId &&
        grip === 'twoHanded' &&
        p.damageModes.some((d) => d.id === 'two-hands')
          ? 'two-hands'
          : damageId),
    ) ?? p.damageModes[0]!;
  const mult =
    mode === 'short'
      ? 3
      : mode === 'double'
        ? 2
        : mode === 'long'
          ? (({ 10: 2, 15: 3, 20: 4, 25: 5, 30: 6 } as Record<number, number>)[
              count
            ] ?? 1)
          : mode === 'massive'
            ? count / 10
            : 1;
  const master =
    d.activeFeats.includes('blademaster') &&
    w.category === 'melee' &&
    sheet.levels.some((l) =>
      Object.entries(l.choices).some(
        ([key, values]) =>
          values.includes('blademaster') &&
          (l.choices[key + '-weapon'] ?? []).some((model) =>
            [w.model, entry.item.name].some(
              (name) =>
                name.trim().toLocaleLowerCase('pl') ===
                model.trim().toLocaleLowerCase('pl'),
            ),
          ),
      ),
    );
  const extraDie =
    (master ? 1 : 0) +
    (d.rules.some((r) => r.id === 'profession.cowboy.0') &&
    weaponTrait(entry, 'revolver')
      ? 1
      : 0);
  const dice = damage.dice.replace(
    /(\d+)k(\d+)/g,
    (_, n: string, s: string) =>
      `${(Number(n) + extraDie) * mult * (mode === 'long' && d.activeFeats.includes('mobile') ? 2 : 1)}k${s}`,
  );
  const series = ['short', 'long', 'massive'].includes(mode);
  const styles = new Set(sheet.levels.flatMap((l) => l.choices.veteran ?? []));
  const samurai =
    d.activeFeats.includes('samurai') && damage.damageType.includes('cięte')
      ? 1
      : 0;
  const otherWeapon = inventory?.entries.some(
    (e) =>
      e.id !== entry.id &&
      e.weapon &&
      ['mainHand', 'offHand', 'bothHands'].includes(e.slot),
  );
  // Prepared weapons do not establish what is wielded in the other hand.
  // Situational bonuses remain manual for the new storage-slot model.
  const butcher =
    styles.has('butcher') &&
    inventory &&
    isLegacyHandSlot(entry.slot) &&
    !otherWeapon
      ? 3
      : 0;
  const genius = d.classLevels.spec >= 11 ? d.modifiers.int : 0;
  const bonus =
    (!series && mod === null) || genius === null
      ? null
      : (series ? 0 : mod!) + samurai + butcher + genius;
  const thrower =
    p.attackKind === 'ranged' &&
    p.properties.some((property) => /\brzucana\b/i.test(property)) &&
    d.activeFeats.includes('thrower');
  const rangeMultiplier =
    (thrower ? 2 : 1) *
    (p.attackKind === 'ranged' &&
    weaponTrait(entry, 'axe') &&
    d.activeFeats.includes('axes')
      ? 2
      : 1);
  const sniper = p.attackKind === 'ranged' && d.activeFeats.includes('sniper');
  const oneHanded =
    ((w.category === 'short' || weaponTrait(entry, 'smg')) &&
      (styles.has('wrist') || d.activeFeats.includes('pulp'))) ||
    (weaponTrait(entry, 'revolver') &&
      d.rules.some((r) => r.id === 'profession.cowboy.1'));
  const eye = styles.has('eye') && p.attackKind === 'ranged' ? 3 : 0;
  return {
    attack:
      mod === null
        ? null
        : mod +
          (proficient ? d.pb : 0) +
          p.attackModifier +
          samurai +
          eye +
          (thrower ? 2 : 0),
    ability: chosen,
    proficient,
    damage: `${dice}${bonus === null ? ' + ?' : bonus ? ` ${bonus >= 0 ? '+' : '−'} ${Math.abs(bonus)}` : ''}`,
    damageType: damage.damageType,
    damageModeId: damage.id,
    disadvantage:
      (mode === 'short' &&
        !(distance === 'normal' && d.activeFeats.includes('assault'))) ||
      (distance === 'long' && !sniper) ||
      (['short', 'intermediate', 'long', 'heavy'].includes(w.category) &&
        !w.handy &&
        !oneHanded &&
        grip !== 'twoHanded'),
    range: {
      ...p.range,
      normal: p.range.normal === null ? null : p.range.normal * rangeMultiplier,
      long:
        p.range.long === null
          ? null
          : p.range.long * rangeMultiplier * (sniper ? 2 : 1),
    },
  };
}
