import { z } from 'zod';
import { inventoryEntrySchema } from './inventoryModel';
const id = z.uuid(),
  name = z.string().trim().min(1).max(300),
  n = z.number().int().min(0).max(1000000000),
  total = z.number().int().min(-100).max(200);
const material = z
  .object({ id, quantity: n, valueGb: z.number().min(0).max(1000000) })
  .strict();
export const projectSchema = z
  .object({
    id,
    label: name,
    output: inventoryEntrySchema,
    price: z.number().min(0).max(1000000),
    singleUse: z.boolean(),
    repairId: id.nullable().default(null),
    tools: name,
    proficient: z.boolean(),
    schematic: z.boolean(),
    materials: z.array(material).max(50),
    override: z
      .object({
        cost: n,
        minutes: n,
        dc: z.number().int().min(0).max(100),
        source: name,
      })
      .strict()
      .nullable(),
    cost: n,
    minutes: n,
    dc: z.number().int().min(0).max(100),
    progress: n,
    status: z.enum(['working', 'complete', 'cancelled']),
  })
  .strict();
export const downtimeSchema = z
  .object({
    projects: z.array(projectSchema).max(100),
    work: z.record(z.string(), n),
    restWork: z.record(z.string(), n),
    cleaned: z.array(id).max(5000),
    medicKitUses: z
      .record(z.string(), z.number().int().min(0).max(5))
      .optional(),
    medpakUses: z.record(z.string(), n),
    training: z
      .array(
        z
          .object({
            id,
            target: name,
            minutes: n,
            completed: z.boolean(),
            afterLevel: z.number().int().min(1).max(12),
          })
          .strict(),
      )
      .max(100),
    benefits: z
      .array(
        z
          .object({
            id,
            label: name,
            kind: z.enum(['mealSave', 'ar23Social']).optional(),
            expiresAt: n.nullable(),
            refresh: z.enum(['long', 'manual']),
          })
          .strict(),
      )
      .max(100),
  })
  .strict();
export type Downtime = z.infer<typeof downtimeSchema>;
export const emptyDowntime = (): Downtime => ({
  projects: [],
  work: {},
  restWork: {},
  cleaned: [],
  medpakUses: {},
  training: [],
  benefits: [],
});
export const downtimeCommandSchema = z.discriminatedUnion('kind', [
  z
    .object({
      kind: z.literal('quickProduction'),
      products: z
        .array(
          z
            .object({
              output: inventoryEntrySchema,
              price: z.number().positive().max(50),
            })
            .strict(),
        )
        .min(1)
        .max(50),
      tools: name,
      proficient: z.boolean(),
      schematic: z.boolean(),
      materials: z.array(material).min(1).max(50),
    })
    .strict(),
  z
    .object({
      kind: z.literal('medicalAid'),
      patient: name,
      kitId: id,
      inReach: z.boolean(),
      handsFree: z.boolean(),
      total,
      rolls: z.array(z.number().int().min(1).max(12)).max(5),
    })
    .strict(),
  z
    .object({
      kind: z.literal('refillMedicKit'),
      kitId: id,
      entryId: id,
    })
    .strict(),
  z
    .object({
      kind: z.literal('resuscitate'),
      patient: name,
      minutesSincePulse: z.number().positive().max(8),
      massiveDamage: z.boolean(),
      total,
    })
    .strict(),
  z
    .object({
      kind: z.literal('project'),
      project: projectSchema.omit({
        cost: true,
        minutes: true,
        dc: true,
        progress: true,
        status: true,
      }),
    })
    .strict(),
  z
    .object({
      kind: z.literal('work'),
      id,
      minutes: z.number().int().min(1).max(600),
      finish: z.boolean(),
      total: total.nullable(),
    })
    .strict(),
  z.object({ kind: z.literal('cancelProject'), id, reason: name }).strict(),
  z
    .object({ kind: z.literal('clean'), weaponId: id, tools: z.boolean() })
    .strict(),
  z
    .object({
      kind: z.literal('cook'),
      tools: z.boolean(),
      ingredients: z.array(material).min(1).max(50),
      total,
    })
    .strict(),
  z
    .object({
      kind: z.literal('healingItem'),
      entryId: id,
      formula: z.enum(['medpak', 'ar23']),
      rolls: z.array(z.number().int().min(1).max(6)).min(2).max(5),
      wisSave: total.nullable(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('training'),
      id,
      target: name,
      minutes: z.number().int().min(1).max(600),
      teacher: z.boolean(),
      paid: z.number().min(0).max(10000),
    })
    .strict(),
  z.object({ kind: z.literal('removeBenefit'), id, reason: name }).strict(),
]);
export type DowntimeCommand = z.infer<typeof downtimeCommandSchema>;
