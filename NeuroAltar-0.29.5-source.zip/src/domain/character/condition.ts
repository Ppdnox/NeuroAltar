import { characterConditionEffects } from './conditionEffects';
import { applyCombatHealth } from './combatHealth';
import { applyDowntime, expireDowntime } from './downtime';
import { applyCare, careSheet } from './care';
import type { Inventory } from './inventoryModel';
import {
  conditionActionSchema,
  conditionSchema,
  type Condition,
  type ConditionAction,
  type RestInput,
} from './conditionModel';
import { deriveResources, type ResourceDefinition } from './resources';
import { deriveCharacter } from './derive';
import type { Character, CharacterSheet } from './model';
export function initialCondition(record: Character): Condition {
  return {
    hp: record.sheet?.hpCurrent ?? record.draft?.hpCurrent ?? 0,
    hitDiceSpent: { 6: 0, 8: 0 },
    spent: {},
    manual: [],
    effects: [],
    injury: 0,
    exhaustion: [],
    restBlocks: [],
    rest: null,
    completedRests: [],
    longStreak: 0,
    fuks: [],
    startFuksClaimed: false,
    session: null,
    sessions: [],
    worldMinutes: 0,
    journal: [],
  };
}
export function conditionSheet(
  sheet: CharacterSheet,
  state?: Condition,
): CharacterSheet & { learned?: { target: string; afterLevel: number }[] } {
  if (!state) return sheet;
  sheet = careSheet(sheet, state.care);
  const learned =
    state.downtime?.training
      .filter((t) => t.completed)
      .map((t) => ({ target: t.target, afterLevel: t.afterLevel })) ?? [];
  const d = deriveCharacter(sheet);
  const targets = ['str', 'dex', 'con', 'int', 'wis', 'cha'] as const;
  return {
    ...sheet,
    learned,
    overrides: [
      ...sheet.overrides,
      ...targets.flatMap((target) => {
        const effects = state.effects.filter((e) => e.target === target);
        if (!effects.length) return [];
        return [
          {
            id: effects[0]!.id,
            target: 'score:' + target,
            mode: 'add' as const,
            value: -Math.min(
              effects.reduce((sum, e) => sum + e.amount, 0),
              Math.max(0, (d.scores[target].value ?? 1) - 1),
            ),
            reason: effects.map((e) => e.source).join('; '),
          },
        ];
      }),
    ],
  };
}
export function restDuration(color: string) {
  return color === 'rust'
    ? { short: 1440, long: 4320 }
    : color === 'chrome'
      ? { short: 60, long: 480 }
      : { short: 240, long: 1440 };
}
export function conditionView(record: Character) {
  const state = record.condition ?? initialCondition(record),
    base = record.sheet ?? record.draft!,
    sheet = conditionSheet(base, state),
    d = deriveCharacter(sheet);
  const max = Math.max(
    0,
    Math.floor(d.hpMax.value ?? 0) -
      state.effects
        .filter((e) => e.target === 'hpMax')
        .reduce((s, e) => s + e.amount, 0),
  );
  const resources: ResourceDefinition[] = [
    ...deriveResources(sheet),
    ...state.manual.map((e) => ({
      id: e.id,
      label: e.label,
      max: e.max,
      refresh: 'manual' as const,
      page: 0,
      costMax: 100000,
      note: 'Własny licznik MG.',
      unresolved: false,
    })),
  ];
  return {
    state,
    sheet,
    derived: d,
    max,
    resources,
    exhaustion: characterConditionEffects(state).exhaustion,
    consequences: characterConditionEffects(state),
  };
}
export function conditionContext(record: Character) {
  const v = conditionView(record),
    after = conditionView({
      ...record,
      condition: {
        ...v.state,
        effects: v.state.effects.filter((e) => e.refresh !== 'long'),
      },
    });
  return {
    hpMax: v.max,
    longHpMax: after.max,
    con: v.derived.modifiers.con ?? 0,
    hitDice: v.derived.hitDice,
    resources: v.resources,
    longResources: after.resources,
    toughLevel: v.derived.classLevels.twardziel,
  };
}
export type ConditionContext = ReturnType<typeof conditionContext>;
export class ConditionError extends Error {
  constructor(
    public field: string,
    message: string,
  ) {
    super(message);
  }
}
function need(ok: unknown, field: string, message: string): asserts ok {
  if (!ok) throw new ConditionError(field, message);
}
const remaining = (state: Condition, r: ResourceDefinition) =>
  Math.max(0, r.max - (state.spent[r.id] ?? 0));
export function previewCondition(
  record: Character,
  raw: ConditionAction,
  operationId: string,
) {
  const action = conditionActionSchema.parse(raw);
  need(
    record.sheet && !record.draft && !record.archived,
    'state',
    'Najpierw zatwierdź lub odrzuć szkic rozwoju.',
  );
  const ctx = conditionContext(record),
    s = structuredClone(record.condition ?? initialCondition(record)),
    color = record.sheet.rulesContext.gameColor,
    lines: string[] = [];
  const resource = (id: string) => {
    const r = ctx.resources.find((r) => r.id === id);
    need(r, 'resource', 'Zdolność nie jest dostępna dla tej postaci.');
    return r;
  };
  let inventory: Inventory | undefined;
  switch (action.type) {
    case 'combatAbility':
      lines.push(
        'Zdolność: ' +
          action.combatApplication.label +
          '; koszt: ' +
          action.combatApplication.cost,
      );
      break;
    case 'combatHealth':
      lines.push(
        applyCombatHealth(
          s,
          action.command,
          ctx.hpMax,
          conditionView(record).derived.scores.con.value ?? 0,
          color,
          operationId,
        ),
      );
      break;
    case 'downtime': {
      const result = applyDowntime(record, s, action.command, operationId);
      inventory = result.inventory;
      lines.push(...result.lines);
      break;
    }
    case 'care': {
      const result = applyCare(record, s, action.command, operationId);
      inventory = result.inventory;
      lines.push(...result.lines);
      break;
    }
    case 'use': {
      const r = resource(action.resourceId);
      need(
        action.amount <= r.costMax && action.amount <= remaining(s, r),
        'amount',
        'Za mało użyć lub przekroczony koszt jednego użycia.',
      );
      s.spent[r.id] = (s.spent[r.id] ?? 0) + action.amount;
      lines.push(r.label + ': zużycie ' + action.amount);
      if (action.healingRoll !== null) {
        need(
          r.id === 'stamina',
          'healingRoll',
          'Rzut leczenia dotyczy Kondychy.',
        );
        s.hp = Math.min(ctx.hpMax, s.hp + action.healingRoll + ctx.toughLevel);
        lines.push('Kondycha: PW → ' + s.hp);
      }
      break;
    }
    case 'correct':
      s.hp = action.hp;
      if (s.injury < 4 && action.injury >= 4)
        s.exhaustion.push({
          id: operationId,
          cause: 'ordinary',
          source: 'Czwarte Zranienie',
          level: 1,
        });
      s.injury = action.injury;
      s.hitDiceSpent = action.hitDiceSpent;
      lines.push('Zdrowie: ' + action.reason);
      break;
    case 'resourceStep': {
      const r = resource(action.id);
      const spent = s.spent[r.id] ?? 0;
      if (action.direction === 'use') {
        need(remaining(s, r) > 0, 'resource', 'Brak pozostałych użyć.');
        s.spent[r.id] = spent + 1;
        lines.push(r.label + ': użyto 1');
      } else {
        need(spent > 0, 'resource', 'Wszystkie użycia są już dostępne.');
        s.spent[r.id] = spent - 1;
        lines.push(r.label + ': przywrócono 1');
      }
      break;
    }
    case 'resource': {
      const r = resource(action.id);
      s.spent[r.id] = action.spent;
      lines.push(r.label + ': wydane ' + action.spent + ' — ' + action.reason);
      break;
    }
    case 'manual': {
      const old = s.manual.find((e) => e.id === action.entry.id);
      if (old) Object.assign(old, action.entry);
      else s.manual.push(action.entry);
      lines.push('Własny zasób: ' + action.entry.label + ' — ' + action.reason);
      break;
    }
    case 'effect':
      need(
        !s.effects.some((e) => e.id === action.entry.id),
        'effect',
        'Ten efekt jest już zapisany.',
      );
      s.effects.push(action.entry);
      lines.push(
        'Redukcja ' +
          action.entry.target +
          ': ' +
          action.entry.amount +
          ' — ' +
          action.entry.source,
      );
      break;
    case 'exhaustion':
      need(
        !s.exhaustion.some((e) => e.id === action.entry.id),
        'exhaustion',
        'Ta przyczyna jest już zapisana.',
      );
      s.exhaustion.push(action.entry);
      lines.push(
        'Wyczerpanie +' + action.entry.level + ': ' + action.entry.source,
      );
      break;
    case 'exhaustionReduce': {
      const entry = s.exhaustion.find((e) => e.id === action.id);
      need(entry, 'exhaustionId', 'Wskaż istniejącą przyczynę Wyczerpania.');
      entry.level--;
      s.exhaustion = s.exhaustion.filter((e) => e.level > 0);
      lines.push('Wyczerpanie −1: ' + entry.source);
      break;
    }
    case 'block':
      need(
        !s.restBlocks.some((e) => e.id === action.id),
        'block',
        'Ta blokada jest już zapisana.',
      );
      s.restBlocks.push({ id: action.id, source: action.source });
      lines.push('Blokada korzyści odpoczynku: ' + action.source);
      break;
    case 'remove': {
      const list = s[action.group];
      need(
        list.some((e) => e.id === action.id),
        'remove',
        'Brak wskazanego źródła.',
      );
      if (action.group === 'effects')
        s.effects = s.effects.filter((e) => e.id !== action.id);
      else if (action.group === 'exhaustion')
        s.exhaustion = s.exhaustion.filter((e) => e.id !== action.id);
      else s.restBlocks = s.restBlocks.filter((e) => e.id !== action.id);
      lines.push('Usunięcie efektu: ' + action.reason);
      break;
    }
    case 'restStart':
      need(!s.rest, 'rest', 'Najpierw rozlicz rozpoczęty odpoczynek.');
      need(s.hp >= 1, 'hp', 'Odpoczynek wymaga co najmniej 1 PW na początku.');
      need(
        !s.completedRests.includes(action.id),
        'rest',
        'Ten odpoczynek został już rozliczony.',
      );
      s.rest = {
        id: action.id,
        kind: action.kind,
        color,
        contextRevision: record.sheet.rulesContext.revision,
        hpAtStart: s.hp,
        startedAt: s.worldMinutes,
        elapsed: 0,
        lastShortAt: 0,
        interruptions: 0,
      };
      lines.push(
        'Rozpoczęto ' +
          (action.kind === 'short' ? 'krótki' : 'długi') +
          ' odpoczynek: ' +
          restDuration(color)[action.kind] / 60 +
          ' h. Czas podaje MG.',
      );
      break;
    case 'restCancel':
      need(s.rest, 'rest', 'Brak rozpoczętego odpoczynku.');
      s.completedRests.push(s.rest.id);
      s.rest = null;
      s.longStreak = 0;
      lines.push('Przerwano odpoczynek bez korzyści: ' + action.reason);
      break;
    case 'restApply':
      applyRest(
        s,
        action,
        ctx,
        color,
        record.sheet.rulesContext.revision,
        lines,
      );
      break;
    case 'fuksGrant': {
      need(color !== 'mercury', 'fuks', 'Rtęć: Fuksy są niedostępne.');
      need(
        !s.fuks.some((f) => f.id === action.entry.id),
        'fuks',
        'Ten Fuks już istnieje.',
      );
      need(
        action.entry.kind !== 'session',
        'fuks',
        'Fuksa sesyjnego przyznaje rozpoczęcie sesji.',
      );
      if (action.entry.kind === 'start') {
        need(
          !s.startFuksClaimed,
          'fuks',
          'Startowy Fuks został już przyznany.',
        );
        s.startFuksClaimed = true;
      }
      if (action.entry.kind === 'fant')
        need(
          s.fuks.filter((f) => f.kind === 'fant').length < 3,
          'fuks',
          'Maksymalnie 3 Fuksy z Fantów.',
        );
      if (['song', 'meal'].includes(action.entry.kind))
        need(
          action.entry.expiresAt === s.worldMinutes + 1440,
          'fuks',
          'Fuks z pieśni/posiłku wygasa po 24 godzinach gry.',
        );
      s.fuks.push(action.entry);
      lines.push('Fuks: ' + action.entry.source);
      break;
    }
    case 'fuksUse':
      need(color !== 'mercury', 'fuks', 'Rtęć: Fuksy są niedostępne.');
      need(
        s.fuks.some((f) => f.id === action.id),
        'fuks',
        'Brak tego Fuksa.',
      );
      s.fuks = s.fuks.filter((f) => f.id !== action.id);
      lines.push('Zużyto wskazanego Fuksa.');
      break;
    case 'session':
      need(
        !s.sessions.includes(action.id),
        'session',
        'Ta sesja została już rozpoczęta.',
      );
      s.sessions.push(action.id);
      s.session = action.id;
      s.fuks = s.fuks.filter((f) => f.kind !== 'session');
      if (color === 'steel' || color === 'chrome')
        s.fuks.push({
          id: operationId,
          kind: 'session',
          source: 'Kolor gry — sesja ' + action.id,
          session: action.id,
          expiresAt: null,
        });
      lines.push('Nowa sesja: ' + action.id);
      break;
    case 'sessionEnd':
      need(s.session, 'session', 'Brak aktywnej sesji.');
      s.fuks = s.fuks.filter((f) => f.kind !== 'session');
      s.session = null;
      lines.push('Zakończono sesję; wygasły jej Fuksy.');
      break;
    case 'worldTime':
      s.worldMinutes += action.minutes;
      expireDowntime(s.downtime, s.worldMinutes);
      s.fuks = s.fuks.filter(
        (f) => f.expiresAt === null || f.expiresAt > s.worldMinutes,
      );
      lines.push(
        'Upływ czasu gry: ' +
          action.minutes +
          ' min. Odpoczynki nie zostały zastosowane.',
      );
      break;
  }
  // A counter click changes only its pool and the journal, never health or effects.
  if (!['resourceStep', 'exhaustionReduce'].includes(action.type)) {
    if (s.combatHealth && s.hp > 0) {
      s.combatHealth.successes = 0;
      s.combatHealth.failures = 0;
      s.combatHealth.stable = false;
      if (action.type === 'correct' && s.injury < 5)
        s.combatHealth.dead = false;
    }
    if (s.care) s.care.day = Math.floor(s.worldMinutes / 1440);
    s.fuks = s.fuks.filter(
      (f) => f.expiresAt === null || f.expiresAt > s.worldMinutes,
    );
    expireDowntime(s.downtime, s.worldMinutes);
  }
  need(
    s.hitDiceSpent[6] <= 100000 && s.hitDiceSpent[8] <= 100000,
    'hitDice',
    'Niepoprawne wydane KW.',
  );
  s.journal.push({ id: operationId, text: lines.join('\n') });
  conditionSchema.parse(s);
  return { state: s, lines, context: ctx, ...(inventory ? { inventory } : {}) };
}
function applyRest(
  s: Condition,
  a: RestInput,
  ctx: ConditionContext,
  color: string,
  revision: number,
  lines: string[],
) {
  const session = s.rest;
  need(session, 'rest', 'Brak rozpoczętego odpoczynku.');
  need(
    session.id === a.sessionId && !s.completedRests.includes(a.sessionId),
    'rest',
    'Ten odpoczynek jest już rozliczony lub nieaktualny.',
  );
  need(
    session.color === color && session.contextRevision === revision,
    'rest',
    'Zmieniono Kolor w trakcie odpoczynku. Rozlicz lub anuluj rozpoczęty odpoczynek przed zmianą zasad.',
  );
  need(
    a.elapsed >= session.elapsed,
    'elapsed',
    'Czas odpoczynku nie może się cofać.',
  );
  const start =
    session.startedAt ?? Math.max(0, s.worldMinutes - session.elapsed);
  const previousTime = s.worldMinutes;
  s.worldMinutes = Math.max(s.worldMinutes, start + a.elapsed);
  session.startedAt = start;
  lines.push(
    'Czas gry: +' +
      (s.worldMinutes - previousTime) +
      ' min; łącznie ' +
      s.worldMinutes +
      ' min. Czas już rozliczony nie jest doliczany ponownie.',
  );
  const duration = restDuration(session.color);
  let benefit: 'short' | 'long' | null = null;
  if (a.outcome === 'complete') {
    need(
      a.elapsed >=
        (session.kind === 'short'
          ? duration.short
          : duration.long + session.interruptions * 60),
      'elapsed',
      'Za krótki odpoczynek; wymagane ' +
        (session.kind === 'short'
          ? duration.short
          : duration.long + session.interruptions * 60) +
        ' min.',
    );
    if (session.kind === 'long')
      need(a.sleep >= 360, 'sleep', 'Długi odpoczynek wymaga 6 godzin snu.');
    benefit = session.kind;
  } else if (
    session.kind === 'long' &&
    a.elapsed - session.lastShortAt >= duration.short
  )
    benefit = 'short';
  need(
    a.sleep <= a.elapsed,
    'sleep',
    'Sen nie może trwać dłużej niż odpoczynek.',
  );
  const count = a.rolls6.length + a.rolls8.length;
  if (
    s.restBlocks.length ||
    s.care?.diseases.some((d) => d.active && d.blocked)
  ) {
    lines.push(
      'Bez korzyści: ' +
        [
          ...s.restBlocks.map((b) => b.source),
          ...(s.care?.diseases
            .filter((d) => d.active && d.blocked)
            .map((d) => d.details) ?? []),
        ].join('; '),
    );
    benefit = null;
  }
  if (benefit === 'short') {
    for (const die of [6, 8] as const) {
      const rolls = die === 6 ? a.rolls6 : a.rolls8;
      need(
        rolls.length <= Math.max(0, ctx.hitDice[die] - s.hitDiceSpent[die]),
        'rolls' + die,
        'Brak tylu dostępnych KW k' + die,
      );
      s.hitDiceSpent[die] += rolls.length;
    }
    if (a.kolejkaLevel) {
      need(
        a.kolejkaLevel >= 2,
        'kolejkaLevel',
        'Kolejka wymaga Cwaniaka 2. poziomu.',
      );
      const sides = a.kolejkaLevel >= 9 ? 8 : a.kolejkaLevel >= 5 ? 6 : 4;
      need(
        a.kolejkaRolls.length === count &&
          a.kolejkaRolls.every((n) => n <= sides),
        'kolejkaRolls',
        'Kolejka: jeden wynik k' + sides + ' na każdą wydaną KW.',
      );
    } else
      need(
        a.kolejkaRolls.length === 0,
        'kolejkaRolls',
        'Podaj poziom Cwaniaka udzielającego Kolejki.',
      );
    if (count) {
      const heal = Math.max(
        1,
        [...a.rolls6, ...a.rolls8, ...a.kolejkaRolls].reduce(
          (x, y) => x + y,
          0,
        ) +
          count * ctx.con,
      );
      s.hp = Math.min(ctx.hpMax, s.hp + heal);
      lines.push(
        'Wydano ' + count + ' KW; leczenie ' + heal + ' PW (do maksimum).',
      );
    }
  } else
    need(
      count === 0 && a.kolejkaRolls.length === 0,
      'rolls6',
      'KW można wydawać tylko przy korzyściach krótkiego odpoczynku.',
    );
  if (benefit === 'long') {
    expireDowntime(s.downtime, s.worldMinutes, true);
    s.effects = s.effects.filter((e) => e.refresh !== 'long');
    s.hp = ctx.longHpMax;
    for (const die of [6, 8] as const)
      s.hitDiceSpent[die] -= a.armored
        ? Math.min(s.hitDiceSpent[die], Math.floor(ctx.hitDice[die] / 2))
        : s.hitDiceSpent[die];
    s.longStreak = a.consecutive ? s.longStreak + 1 : 1;
    if (!a.armored) {
      const removedCold =
        a.warm &&
        s.exhaustion.some((e) => e.id === a.exhaustionId && e.cause === 'cold');
      if (a.warm) s.exhaustion = s.exhaustion.filter((e) => e.cause !== 'cold');
      if (a.exhaustionId && !removedCold) {
        const e = s.exhaustion.find((e) => e.id === a.exhaustionId);
        need(e, 'exhaustionId', 'Wskaż istniejącą przyczynę Wyczerpania.');
        need(
          e.cause === 'ordinary' ||
            e.cause === 'cold' ||
            (e.cause === 'hunger' && a.food) ||
            (e.cause === 'thirst' && a.water),
          'exhaustionId',
          'Ta przyczyna wymaga osobnego usunięcia albo spełnienia normy żywienia.',
        );
        e.level--;
        s.exhaustion = s.exhaustion.filter((e) => e.level > 0);
      }
      if (a.healingSave !== null)
        need(
          s.longStreak >= 3,
          'healingSave',
          'Próba gojenia wymaga trzech kolejnych długich odpoczynków.',
        );
      const medical = a.medicProficient && a.medicTools,
        natural =
          s.longStreak >= 3 &&
          a.healingSave !== null &&
          a.healingSave >= 15 &&
          color !== 'rust' &&
          color !== 'mercury';
      if (s.injury > 0 && (medical || natural)) {
        s.injury--;
        s.longStreak = 0;
        lines.push('Zranienie −1.');
      }
    } else
      lines.push(
        'Pancerz: połowa maksymalnej puli KW w dół osobno dla każdej puli; bez regeneracji Wyczerpania i Zranień.',
      );
    lines.push(
      'PW do efektywnego maksimum; odnowienie KW i przemijających redukcji cech.',
    );
  }
  if (benefit) {
    for (const r of benefit === 'long' ? ctx.longResources : ctx.resources)
      if (r.refresh === 'short' || (benefit === 'long' && r.refresh === 'long'))
        s.spent[r.id] = 0;
    lines.push(
      'Korzyści ' +
        (benefit === 'long' ? 'długiego' : 'krótkiego') +
        ' odpoczynku.',
    );
  } else lines.push('Odpoczynek bez odnowienia zasobów.');
  if (a.outcome === 'interrupt' && session.kind === 'long') {
    session.elapsed = a.elapsed;
    session.lastShortAt = a.elapsed;
    session.interruptions++;
    lines.push('Kontynuacja wymaga dodatkowej godziny.');
  } else {
    s.completedRests.push(session.id);
    s.rest = null;
    if (benefit !== 'long' && session.kind === 'long') s.longStreak = 0;
  }
}
