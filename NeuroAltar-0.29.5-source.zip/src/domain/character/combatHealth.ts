import type { Condition, HealthCommand } from './conditionModel';
export const emptyCombatHealth = () => ({
  bleeding: false,
  successes: 0,
  failures: 0,
  stable: false,
  dead: false,
});
export function applyCombatHealth(
  s: Condition,
  a: HealthCommand,
  max: number,
  con: number,
  color: string,
  operationId: string,
) {
  const h = (s.combatHealth ??= emptyCombatHealth());
  if (h.dead) throw Error('Postać nie żyje. Sprawdź stan w sekcji Zdrowie.');
  if (a.kind === 'damage' || a.kind === 'bleed') {
    if (a.kind === 'bleed' && !h.bleeding)
      throw Error('Brak aktywnego krwawienia.');
    const n = a.kind === 'bleed' ? 1 : a.amount,
      before = s.hp;
    if (n > 0) {
      s.hp = Math.max(0, before - n);
      if (before === 0) {
        h.failures = Math.min(
          3,
          h.failures + (a.kind === 'damage' && a.melee ? 2 : 1),
        );
        h.stable = false;
      }
      if (
        a.kind === 'damage' &&
        (a.critical ||
          (before > 0 && s.hp === 0) ||
          (color === 'rust' && n >= con))
      ) {
        const previous = s.injury;
        s.injury = Math.min(5, s.injury + 1);
        if (previous < 4 && s.injury >= 4)
          s.exhaustion.push({
            id: operationId,
            cause: 'ordinary',
            source: 'Czwarte Zranienie',
            level: 1,
          });
        if (['rust', 'mercury'].includes(color)) h.bleeding = true;
      }
      if (n >= 2 * max) h.dead = true;
    }
  } else if (a.kind === 'healing') {
    s.hp = Math.min(max, s.hp + a.amount);
  } else if (a.kind === 'deathSave') {
    if (s.hp !== 0 || h.stable)
      throw Error(
        'Rzut przeciw śmierci dotyczy niestabilnej postaci przy 0 PW.',
      );
    if (a.face === 20) s.hp = 1;
    else if (a.face >= 10) h.successes = Math.min(3, h.successes + 1);
    else h.failures = Math.min(3, h.failures + (a.face === 1 ? 2 : 1));
  } else if (a.kind === 'stopBleeding') h.bleeding = false;
  else if (a.kind === 'stabilize') {
    if (s.hp !== 0) throw Error('Stabilizacja wymaga 0 PW.');
    h.stable = true;
  }
  if (s.hp > 0) {
    h.successes = 0;
    h.failures = 0;
    h.stable = false;
  }
  if (h.successes >= 3) {
    h.stable = true;
    h.successes = 0;
    h.failures = 0;
  }
  if (h.failures >= 3 || s.injury >= 5 || max === 0) h.dead = true;
  if (h.stable) {
    h.successes = 0;
    h.failures = 0;
  }
  return `Zdrowie po rozliczeniu: PW ${s.hp}/${max}, Zranienia ${s.injury}; krwawienie ${h.bleeding ? '1 PW/turę' : 'nie'}; RO przeciw śmierci ${h.successes}/${h.failures}${h.dead ? '; śmierć' : h.stable ? '; stabilny' : ''}.`;
}
