import { z } from 'zod';
import { inventoryEntrySchema } from './inventoryModel';
const uuid = z.uuid(),
  text = z.string().trim().min(1).max(300),
  n = z.number().int().min(0).max(1000000000),
  roll = z.number().int().min(1).max(20),
  total = z.number().int().min(-100).max(200);
export const diseaseKinds = [
  'hemophilia',
  'circulation',
  'dracula',
  'thurman',
  'boston',
  'osteoporosis',
  'paranoia',
  'labyrinth',
  'radiation',
  'rat',
  'infection',
  'death',
] as const;
export const phobiaKinds = [
  'heights',
  'spiders',
  'closed',
  'mutants',
  'dark',
  'fire',
  'machines',
  'rats',
] as const;
export const diseaseSchema = z
  .object({
    id: uuid,
    kind: z.enum(diseaseKinds),
    stage: z.number().int().min(0).max(2),
    active: z.boolean(),
    details: text,
    treatedDay: n.nullable(),
    treatmentDays: n,
    lastTreatmentDay: n.nullable(),
    lastCheckDay: n.nullable(),
    blocked: z.boolean(),
    onsetAt: n,
    bleeding: z.boolean(),
    successes: z.number().int().min(0).max(3),
  })
  .strict();
export const phobiaSchema = z
  .object({
    id: uuid,
    kind: z.enum(phobiaKinds),
    successes: z.number().int().min(0).max(3),
    active: z.boolean(),
    fear: z.boolean(),
    immuneUntil: n,
    attackUntil: n,
    lastCheckAt: n.nullable(),
    turns: z.array(text).max(10000),
  })
  .strict();
export const careSchema = z
  .object({
    diseases: z.array(diseaseSchema).max(100),
    phobias: z.array(phobiaSchema).max(100),
    starts: z
      .array(
        z
          .object({
            group: z.enum(['disease', 'phobia']),
            ability: z.enum(['str', 'dex', 'con', 'int', 'wis', 'cha']),
            delta: z.number().int().min(-1).max(1),
          })
          .strict(),
      )
      .max(2),
    day: n,
    days: z.array(text).max(10000),
    hungryDays: n,
    foodSatisfied: z.boolean(),
    waterSatisfied: z.boolean(),
    radiationFailures: n,
    exposures: z.array(text).max(10000),
  })
  .strict();
export type Care = z.infer<typeof careSchema>;
export const emptyCare = (): Care => ({
  diseases: [],
  phobias: [],
  starts: [],
  day: 0,
  days: [],
  hungryDays: 0,
  foodSatisfied: false,
  waterSatisfied: false,
  radiationFailures: 0,
  exposures: [],
});
export const careCommandSchema = z.discriminatedUnion('kind', [
  z
    .object({
      kind: z.literal('start'),
      group: z.enum(['disease', 'phobia']),
      choice: z.number().int().min(-1).max(7),
      ability: z.enum(['str', 'dex', 'con', 'int', 'wis', 'cha']),
      id: uuid,
      medicine: inventoryEntrySchema.nullable(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('disease'),
      id: uuid,
      disease: z.enum(diseaseKinds),
      details: text,
      onsetMinutes: n,
    })
    .strict(),
  z
    .object({
      kind: z.literal('diseaseCheck'),
      id: uuid,
      natural: roll,
      total,
      chronicRoll: z.number().int().min(1).max(8).nullable(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('medicine'),
      id: uuid,
      entryId: uuid,
      doses: z.number().int().min(1).max(100),
      treatment: z.enum([
        'daily',
        'antibiotic',
        'radoff',
        'exposure',
        'bleeding',
      ]),
      sideSave: total.nullable(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('bleeding'),
      id: uuid,
      mode: z.enum(['start', 'save', 'medicineCheck']),
      total: total.nullable(),
      tools: z.boolean(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('phobia'),
      id: uuid,
      phobia: z.enum(phobiaKinds),
    })
    .strict(),
  z.object({ kind: z.literal('phobiaAway'), id: uuid }).strict(),
  z
    .object({
      kind: z.literal('phobiaCheck'),
      id: uuid,
      total,
      turn: z.string().max(100),
      trigger: z.boolean(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('day'),
      id: text,
      foodMg: n,
      waterMl: n,
      hungerSave: total.nullable(),
      foodEntryId: uuid.nullable(),
      foodQuantity: n,
      waterEntryId: uuid.nullable(),
      waterQuantity: n,
    })
    .strict(),
  z
    .object({
      kind: z.literal('environment'),
      id: text,
      hazard: z.enum([
        'cold',
        'radiation',
        'suffocation',
        'breathe',
        'noSleep',
      ]),
      total: total.nullable(),
      dc: z.number().int().min(0).max(100),
      diseaseId: uuid,
    })
    .strict(),
  z
    .object({
      kind: z.literal('careCorrection'),
      group: z.enum(['disease', 'phobia']),
      id: uuid,
      reason: text,
    })
    .strict(),
]);
export type CareCommand = z.infer<typeof careCommandSchema>;
