import type { Character, CharacterSheet } from './model';
import type { Condition } from './conditionModel';
import { deriveCharacter } from './derive';
import { conditionView, ConditionError } from './condition';
import { emptyInventory } from './inventoryModel';
import { validateInventory } from './inventory';
import {
  emptyDowntime,
  type DowntimeCommand,
  type Downtime,
} from './downtimeModel';
const need = (yes: unknown, field: string, message: string) => {
  if (!yes) throw new ConditionError(field, message);
};
export function productionValues(
  price: number,
  singleUse: boolean,
  feats: string[],
) {
  return {
    cost: Math.floor(
      Math.floor(price / 2) * (feats.includes('supplies') ? 0.5 : 1),
    ),
    minutes: Math.floor(
      price * (singleUse ? 30 : 60) * (feats.includes('fabricator') ? 0.5 : 1),
    ),
    dc:
      price <= 10
        ? 5
        : price <= 25
          ? 10
          : price <= 50
            ? 15
            : price <= 75
              ? 20
              : price <= 100
                ? 25
                : 30,
  };
}
export function medicalAidProfile(sheet: CharacterSheet, total: number) {
  const d = deriveCharacter(sheet);
  const sides = d.rules.some((r) => r.id === 'profession.medic.1')
    ? 6 + 2 * Math.min(3, Math.floor(d.classLevels.spec / 3) - 1)
    : 4;
  const baseCount =
    total < 5 ? 0 : total < 15 ? 1 : Math.min(4, Math.floor(total / 5) - 1);
  return {
    sides,
    count: baseCount + (baseCount && d.activeFeats.includes('plaster') ? 1 : 0),
    modifier: total >= 10 ? (d.modifiers.int ?? 0) : 0,
    proficient: d.rank('tool:medic') > 0,
    resuscitate: d.rules.some((r) => r.id === 'profession.medic.2'),
  };
}
export function resuscitationDC(minutes: number) {
  return minutes <= 1 ? 15 : minutes <= 2 ? 20 : minutes <= 4 ? 25 : 30;
}
export function applyDowntime(
  record: Character,
  s: Condition,
  a: DowntimeCommand,
  op: string,
) {
  const d = structuredClone(s.downtime ?? emptyDowntime()),
    inv = structuredClone(record.inventory ?? emptyInventory()),
    lines: string[] = [];
  const sheet = record.sheet!,
    derived = deriveCharacter(sheet),
    day = String(Math.floor(s.worldMinutes / 1440));
  const work = (minutes: number) => {
    need(
      (d.work[day] ?? 0) + minutes <= 600,
      'minutes',
      'Maksymalnie 10 godzin pracy w jednej dobie. Rozlicz kolejną dobę, aby kontynuować.',
    );
    if (s.rest?.kind === 'short')
      need(
        (d.restWork[s.rest.id] ?? 0) + minutes <= 60,
        'minutes',
        'Krótki odpoczynek dopuszcza najwyżej godzinę takich czynności. Najpierw rozlicz przerwanie odpoczynku.',
      );
    d.work[day] = (d.work[day] ?? 0) + minutes;
    if (!s.rest) {
      need(
        Math.floor(s.worldMinutes / 1440) ===
          Math.floor((s.worldMinutes + minutes - 1) / 1440),
        'minutes',
        'Rozdziel pracę na dwie doby, aby poprawnie rozliczyć limit dzienny.',
      );
      s.worldMinutes += minutes;
      lines.push('Czas pracy: +' + minutes + ' min czasu gry.');
    } else
      lines.push('Czas pracy wlicz w łączny czas rozpoczętego odpoczynku.');
    if (s.rest) d.restWork[s.rest.id] = (d.restWork[s.rest.id] ?? 0) + minutes;
  };
  const consume = (id: string, quantity: number) => {
    const e = inv.entries.find((e) => e.id === id);
    need(
      e &&
        quantity > 0 &&
        e.quantityMilli >= quantity &&
        !e.weapon &&
        !e.magazine &&
        !e.container,
      'materials',
      'Za mało właściwych materiałów/środków.',
    );
    e!.quantityMilli -= quantity;
  };
  switch (a.kind) {
    case 'quickProduction': {
      const level = derived.classLevels.spec;
      need(
        level >= 3 && (s.spent.production ?? 0) < 1,
        'products',
        'Szybka produkcja wymaga Speca 3. poziomu i dostępnego użycia.',
      );
      need(
        a.proficient && a.tools.trim() && a.schematic,
        'tools',
        'Potwierdź odpowiednie narzędzia, biegłość i schematy.',
      );
      const price = a.products.reduce((sum, p) => sum + p.price, 0);
      need(
        price <= (level >= 11 ? 50 : 25),
        'price',
        'Przekroczono łączny limit wartości Szybkiej produkcji.',
      );
      need(
        new Set(a.products.map((p) => p.output.id)).size === a.products.length,
        'products',
        'Produkty muszą mieć różne identyfikatory.',
      );
      for (const { output, price: itemPrice } of a.products) {
        need(
          !inv.entries.some((e) => e.id === output.id) &&
            output.quantityMilli === 1000 &&
            !output.container &&
            output.parentId === null &&
            output.slot === 'none',
          'products',
          'Każdy produkt musi być nową pojedynczą niewyposażoną pozycją.',
        );
        const range = output.item.basePrice;
        need(
          !range || (itemPrice >= range.min && itemPrice <= range.max),
          'price',
          'Użyj bazowej ceny produktu.',
        );
      }
      const cost = productionValues(price, false, derived.activeFeats).cost;
      need(
        new Set(a.materials.map((m) => m.id)).size === a.materials.length &&
          a.materials.reduce((sum, m) => sum + m.valueGb, 0) >= cost,
        'materials',
        'Wskaż unikalne surowce o wymaganej wartości.',
      );
      // This feature replaces the ordinary duration; Fabrykator retains its agreed time reduction.
      const minutes = Math.floor(
        price * (derived.activeFeats.includes('fabricator') ? 0.5 : 1),
      );
      if (minutes > 0) work(minutes);
      for (const m of a.materials) consume(m.id, m.quantity);
      inv.entries.push(...a.products.map((p) => structuredClone(p.output)));
      s.spent.production = (s.spent.production ?? 0) + 1;
      lines.push(
        'Szybka produkcja: ' +
          a.products.map((p) => p.output.item.name).join(', ') +
          '; wartość ' +
          price +
          ' gb; ' +
          minutes +
          ' min; wykorzystano 1 użycie.',
      );
      break;
    }
    case 'medicalAid': {
      const profile = medicalAidProfile(conditionView(record).sheet, a.total),
        kit = inv.entries.find((e) => e.id === a.kitId);
      need(
        kit &&
          /medyk/i.test(kit.item.name) &&
          !/uzupełnienie/i.test(kit.item.name),
        'kitId',
        'Wybierz narzędzia małego medyka.',
      );
      need(
        profile.proficient && a.inReach && a.handsFree,
        'tools',
        'Leczenie wymaga biegłości w narzędziach medyka, obu wolnych rąk i pacjenta w zasięgu 1,5 m.',
      );
      const spent = s.downtime?.medicKitUses?.[a.kitId] ?? 0;
      need(spent < 5, 'kitId', 'Zestaw medyka wymaga uzupełnienia.');
      need(
        a.rolls.length === profile.count &&
          a.rolls.every((r) => r <= profile.sides),
        'rolls',
        'Ten wynik wymaga ' + profile.count + 'k' + profile.sides + '.',
      );
      d.medicKitUses ??= {};
      d.medicKitUses[a.kitId] = spent + 1;
      const hp = Math.max(
        0,
        a.rolls.reduce((sum, n) => sum + n, 0) + profile.modifier,
      );
      lines.push(
        'Narzędzia medyka — pacjent: ' +
          a.patient +
          '; wynik testu ' +
          a.total +
          '; leczenie ' +
          hp +
          ' PW (' +
          profile.count +
          'k' +
          profile.sides +
          (profile.modifier >= 0 ? '+' : '') +
          profile.modifier +
          '). Pozostało ' +
          (4 - spent) +
          '/5 użyć. PW pacjenta zatwierdź na jego karcie.',
      );
      break;
    }
    case 'refillMedicKit': {
      const kit = inv.entries.find((e) => e.id === a.kitId),
        refill = inv.entries.find((e) => e.id === a.entryId);
      need(
        kit &&
          /medyk/i.test(kit.item.name) &&
          !/uzupełnienie/i.test(kit.item.name),
        'kitId',
        'Wybierz narzędzia małego medyka.',
      );
      need(
        refill && /uzupełnienie.*medyk/i.test(refill.item.name),
        'entryId',
        'Wybierz uzupełnienie narzędzi medyka.',
      );
      need(
        (d.medicKitUses?.[a.kitId] ?? 0) > 0,
        'kitId',
        'Zestaw ma już pełny zapas.',
      );
      consume(a.entryId, 1000);
      d.medicKitUses ??= {};
      d.medicKitUses[a.kitId] = Math.max(0, (d.medicKitUses[a.kitId] ?? 0) - 1);
      lines.push('Uzupełniono jedno użycie narzędzi medyka.');
      break;
    }
    case 'resuscitate': {
      need(
        medicalAidProfile(conditionView(record).sheet, a.total).resuscitate,
        'patient',
        'Reanimacja wymaga zdolności Łapiduch.',
      );
      need(
        !a.massiveDamage,
        'massiveDamage',
        'Łapiduch nie działa po Olbrzymich obrażeniach.',
      );
      const dc = resuscitationDC(a.minutesSincePulse);
      work(1);
      lines.push(
        'Łapiduch — pacjent: ' +
          a.patient +
          '; ST ' +
          dc +
          ', wynik ' +
          a.total +
          ': ' +
          (a.total >= dc
            ? 'przywrócono funkcje życiowe; pacjent pozostaje niestabilny.'
            : 'reanimacja nieudana.') +
          ' Stan pacjenta zatwierdź na jego karcie.',
      );
      break;
    }
    case 'project': {
      const p = a.project;
      need(
        !d.projects.some((x) => x.id === p.id),
        'id',
        'Ten projekt już istnieje.',
      );
      need(
        p.proficient && p.tools.trim(),
        'tools',
        'Potwierdź biegłość i właściwe narzędzia.',
      );
      need(
        p.price <= 10 || p.schematic,
        'schematic',
        'Przedmiot droższy niż 10 gb wymaga schematu.',
      );
      if (p.output.item.basePrice)
        need(
          p.price >= p.output.item.basePrice.min &&
            p.price <= p.output.item.basePrice.max,
          'price',
          'Cena musi mieścić się w bazowym przedziale przedmiotu, bez modyfikatorów handlu.',
        );
      if (p.repairId) {
        const old = inv.entries.find((e) => e.id === p.repairId);
        need(
          old &&
            JSON.stringify({ ...old, armorDamage: 0 }) ===
              JSON.stringify(p.output) &&
            p.override,
          'output',
          'Naprawa wymaga istniejącego przedmiotu i reguły kosztu/czasu.',
        );
      } else
        need(
          p.output.quantityMilli === 1000 &&
            !p.output.container &&
            p.output.parentId === null &&
            p.output.slot === 'none',
          'output',
          'Projekt produkuje jeden niewyposażony przedmiot poza pojemnikiem.',
        );
      const values =
        p.override ??
        productionValues(p.price, p.singleUse, derived.activeFeats);
      need(
        p.materials.reduce((n, m) => n + m.valueGb, 0) >= values.cost,
        'materials',
        'Wartość surowców jest niższa od wymaganego kosztu.',
      );
      need(
        new Set(p.materials.map((m) => m.id)).size === p.materials.length,
        'materials',
        'Nie wskazuj dwa razy tego samego zapasu.',
      );
      for (const m of p.materials) {
        const e = inv.entries.find((e) => e.id === m.id);
        need(
          e && m.quantity > 0 && e.quantityMilli >= m.quantity,
          'materials',
          'Brak zapasu wskazanego surowca.',
        );
      }
      d.projects.push({
        ...p,
        cost: values.cost,
        minutes: values.minutes,
        dc: values.dc,
        progress: 0,
        status: 'working',
      });
      lines.push(
        'Projekt: ' +
          p.label +
          '; materiały ' +
          values.cost +
          ' gb; ' +
          values.minutes +
          ' min; ST ' +
          values.dc +
          (p.override ? ' — ' + p.override.source : ''),
      );
      break;
    }
    case 'work': {
      const p = d.projects.find((p) => p.id === a.id && p.status === 'working');
      need(p, 'id', 'Wybierz trwający projekt.');
      work(a.minutes);
      p!.progress += a.minutes;
      if (a.finish) {
        need(
          p!.progress >= p!.minutes && a.total !== null,
          'total',
          'Najpierw wypracuj wymagany czas i podaj końcowy wynik testu narzędzi.',
        );
        if (a.total! >= p!.dc) {
          for (const m of p!.materials) consume(m.id, m.quantity);
          if (p!.repairId) {
            const index = inv.entries.findIndex((e) => e.id === p!.repairId);
            need(
              index >= 0 &&
                JSON.stringify({ ...inv.entries[index], armorDamage: 0 }) ===
                  JSON.stringify(p!.output),
              'output',
              'Przedmiot zmienił się podczas naprawy; rozpocznij nowy projekt.',
            );
            inv.entries[index] = p!.output;
          } else {
            need(
              !inv.entries.some((e) => e.id === p!.output.id),
              'output',
              'Przedmiot o tym ID już istnieje.',
            );
            inv.entries.push(p!.output);
          }
          p!.status = 'complete';
          lines.push(
            p!.repairId
              ? 'Naprawa udana; surowce zużyte, egzemplarz naprawiony.'
              : 'Produkcja udana; surowce zużyte, przedmiot dodany do inwentarza.',
          );
        } else {
          p!.progress = 0;
          lines.push(
            'Nieudana produkcja: czas od początku, surowce zachowane.',
          );
        }
      } else
        lines.push(
          'Praca: ' +
            a.minutes +
            ' min; łącznie ' +
            p!.progress +
            '/' +
            p!.minutes,
        );
      break;
    }
    case 'cancelProject': {
      const p = d.projects.find((p) => p.id === a.id && p.status === 'working');
      need(p, 'id', 'Brak trwającego projektu.');
      p!.status = 'cancelled';
      lines.push('Anulowano produkcję bez zużycia surowców: ' + a.reason);
      break;
    }
    case 'clean': {
      const w = inv.entries.find((e) => e.id === a.weaponId);
      need(
        w?.weapon &&
          !['melee', 'thrown', 'improvised'].includes(w.weapon.category) &&
          a.tools,
        'weaponId',
        'Wybierz broń palną i potwierdź posiadanie środków do konserwacji.',
      );
      work(60);
      if (!d.cleaned.includes(a.weaponId)) d.cleaned.push(a.weaponId);
      lines.push(
        'Wyczyszczono ' +
          w!.item.name +
          ': jeden przerzut zacięcia podczas najbliższej walki.',
      );
      break;
    }
    case 'cook': {
      need(a.tools, 'tools', 'Wymagane narzędzia małego kucharza.');
      work(120);
      for (const m of a.ingredients) consume(m.id, m.quantity);
      if (a.total >= 10)
        d.benefits.push({
          id: op,
          label: 'Posiłek: Ułatwienie najbliższego dowolnego RO',
          kind: 'mealSave',
          expiresAt: null,
          refresh: 'manual',
        });
      if (a.total >= 20 && sheet.rulesContext.gameColor !== 'mercury')
        s.fuks.push({
          id: op,
          source: 'Posiłek — wynik ' + a.total,
          kind: 'meal',
          expiresAt: s.worldMinutes + 1440,
          session: null,
        });
      lines.push(
        'Gotowanie: wynik ' +
          a.total +
          (a.total >= 10
            ? '; korzyści zapisane dla tej postaci. Pozostałych odbiorców rozlicz na ich kartach.'
            : '; bez korzyści.'),
      );
      break;
    }
    case 'healingItem': {
      need(
        sheet.rulesContext.gameColor !== 'mercury',
        'entryId',
        'Rtęć: medpak i AR-23 nie działają.',
      );
      const e = inv.entries.find((e) => e.id === a.entryId),
        ar = a.formula === 'ar23';
      need(
        e && (ar ? /^AR[ -]?23$/i : /^medpak$/i).test(e.item.name),
        'entryId',
        'Wybierz właściwy środek z inwentarza.',
      );
      need(
        a.rolls.length ===
          (ar ? 4 : 2) + (derived.activeFeats.includes('plaster') ? 1 : 0),
        'rolls',
        'Medpak wymaga 2k6, AR-23 4k6; Pan Plaster dodaje jedną kość.',
      );
      need(
        (d.medpakUses[day] ?? 0) < 2,
        'entryId',
        'Dzienny limit dwóch zastosowań medpaka/AR-23 został wykorzystany.',
      );
      consume(a.entryId, 1000);
      d.medpakUses[day] = (d.medpakUses[day] ?? 0) + 1;
      const factor = derived.rules.some((r) => r.id === 'origin.desert.diet')
        ? 2
        : 1;
      const hp = factor * (a.rolls.reduce((n, r) => n + r, 0) + (ar ? 4 : 2));
      s.hp = Math.min(conditionView(record).max, s.hp + hp);
      if (ar) {
        need(a.wisSave !== null, 'wisSave', 'AR-23 wymaga RO MDR ST 15.');
        if (a.wisSave! < 15)
          d.benefits.push({
            id: op,
            label: 'AR-23: Utrudnienie Perswazji i Oszustwa',
            kind: 'ar23Social',
            expiresAt: null,
            refresh: 'long',
          });
      }
      lines.push('Środek zużyty; leczenie ' + hp + ' PW, do maksimum.');
      break;
    }
    case 'training': {
      need(
        a.teacher && a.paid >= a.minutes / 60,
        'paid',
        'Trening wymaga trenera i 1 gb za godzinę.',
      );
      need(
        /^(skill|tool|weapon|armor):[a-z]+$/.test(a.target),
        'target',
        'Wybierz rodzaj biegłości.',
      );
      work(a.minutes);
      let t = d.training.find((t) => t.id === a.id);
      if (!t) {
        t = {
          id: a.id,
          target: a.target,
          minutes: 0,
          completed: false,
          afterLevel: sheet.levels.length,
        };
        d.training.push(t);
      }
      need(
        !t.completed && t.target === a.target,
        'target',
        'To szkolenie zostało zakończone lub ma inny cel.',
      );
      t.minutes += a.minutes;
      t.completed = t.minutes >= 18000;
      if (t.completed) t.afterLevel = sheet.levels.length;
      lines.push(
        'Nauka ' +
          a.target +
          ': ' +
          t.minutes / 60 +
          '/300 h; koszt ' +
          a.paid +
          ' gb potwierdzony.' +
          (t.completed ? ' Biegłość odblokowana.' : ''),
      );
      break;
    }
    case 'removeBenefit': {
      need(
        d.benefits.some((b) => b.id === a.id),
        'id',
        'Brak wskazanego efektu.',
      );
      d.benefits = d.benefits.filter((b) => b.id !== a.id);
      lines.push('Rozliczono efekt: ' + a.reason);
      break;
    }
  }
  validateInventory(inv);
  s.downtime = d;
  return { inventory: inv, lines };
}
export function expireDowntime(
  d: Downtime | undefined,
  now: number,
  long = false,
) {
  if (d)
    d.benefits = d.benefits.filter(
      (b) =>
        (b.expiresAt === null || b.expiresAt > now) &&
        !(long && b.refresh === 'long'),
    );
}
