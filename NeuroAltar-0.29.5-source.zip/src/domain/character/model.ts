import { z } from 'zod';
import { conditionSchema, type ConditionAction } from './conditionModel';
import type { ConditionContext } from './condition';
import { inventorySchema, type InventoryAction } from './inventoryModel';

export const ABILITIES = ['str', 'dex', 'con', 'int', 'wis', 'cha'] as const;
export type Ability = (typeof ABILITIES)[number];
export const abilityNames: Record<Ability, string> = {
  str: 'Siła',
  dex: 'Zręczność',
  con: 'Kondycja',
  int: 'Inteligencja',
  wis: 'Mądrość',
  cha: 'Charyzma',
};
export const CLASSES = [
  'brutal',
  'cwaniak',
  'spec',
  'twardziel',
  'zlodziej',
  'zwiadowca',
] as const;
export type ClassId = (typeof CLASSES)[number];
export const COLORS = ['none', 'rust', 'mercury', 'steel', 'chrome'] as const;
export type GameColor = (typeof COLORS)[number];
export const colorNames: Record<GameColor, string> = {
  none: 'N/D',
  rust: 'Rdza',
  mercury: 'Rtęć',
  steel: 'Stal',
  chrome: 'Chrom',
};
export const colorHp: Record<GameColor, number> = {
  none: 0,
  rust: -2,
  mercury: -3,
  steel: 1,
  chrome: 2,
};
export const SOURCE = {
  title: 'Neuroshima: Ostatnia Era',
  fingerprint:
    '714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34',
  version: 1,
};
const short = z.string().max(300);
const text = z.string().max(20000);
const score = z.number().int().min(1).max(30).nullable();
export const scoresSchema = z
  .object({
    str: score,
    dex: score,
    con: score,
    int: score,
    wis: score,
    cha: score,
  })
  .strict();
export const levelSchema = z
  .object({
    classId: z.enum(CLASSES),
    color: z.enum(COLORS),
    contextRevision: z.number().int().nonnegative(),
    choices: z.record(z.string().max(100), z.array(short).max(30)),
  })
  .strict();
export const sheetSchema = z
  .object({
    identity: z
      .object({
        name: short,
        description: text,
        age: z.number().int().min(0).max(1000).nullable(),
        height: z.number().min(0).max(1000).nullable(),
        bodyWeight: z.number().min(0).max(10000).nullable(),
        size: z.enum([
          'tiny',
          'small',
          'medium',
          'large',
          'huge',
          'gargantuan',
        ]),
        portrait: z
          .string()
          .max(1500000)
          .refine(
            (s) => s === '' || /^data:image\/(png|jpeg|webp);base64,/.test(s),
            'Wybierz lokalny obraz PNG, JPEG lub WebP.',
          ),
      })
      .strict(),
    method: z.enum(['array-a', 'array-b', 'array-c', 'points', 'gm']),
    methodReason: short,
    baseScores: scoresSchema,
    originId: short,
    levels: z.array(levelSchema).min(1).max(12),
    rulesContext: z
      .object({
        gameColor: z.enum(COLORS),
        revision: z.number().int().nonnegative(),
        sourceFingerprint: z.literal(SOURCE.fingerprint),
      })
      .strict(),
    advancementMode: z.enum(['xp', 'milestones']),
    xp: z
      .array(
        z
          .object({
            id: z.uuid(),
            amount: z.number().int().min(-100000).max(100000),
            reason: short,
          })
          .strict(),
      )
      .max(1000),
    hpCurrent: z.number().int().min(0).max(100000).nullable(),
    notes: text,
    contacts: text,
    discoveries: text,
    overrides: z
      .array(
        z
          .object({
            id: z.uuid(),
            target: short,
            mode: z.enum(['add', 'replace']),
            value: z.number().min(-10000).max(10000),
            reason: short,
          })
          .strict(),
      )
      .max(100),
  })
  .strict();
export type CharacterSheet = z.infer<typeof sheetSchema>;
export type Advancement = z.infer<typeof levelSchema>;
export const characterSchema = z
  .object({
    id: z.uuid(),
    schemaVersion: z.literal(1),
    revision: z.number().int().nonnegative(),
    createdAt: z.string(),
    updatedAt: z.string(),
    archived: z.boolean(),
    // Narrative entries are independent of a development draft. Legacy sheets remain readable.
    journal: z
      .object({ notes: text, contacts: text, discoveries: text })
      .strict()
      .optional(),
    inventory: inventorySchema.optional(),
    condition: conditionSchema.optional(),
    sheet: sheetSchema.nullable(),
    draft: sheetSchema.nullable(),
  })
  .strict()
  .refine(
    (v) => v.sheet !== null || v.draft !== null,
    'Karta wymaga danych lub szkicu.',
  );
export type Character = z.infer<typeof characterSchema>;
export type CharacterJournal = Pick<
  CharacterSheet,
  'notes' | 'contacts' | 'discoveries'
>;
export function characterJournal(character: Character): CharacterJournal {
  const source = character.journal ?? character.draft ?? character.sheet;
  return {
    notes: source?.notes ?? '',
    contacts: source?.contacts ?? '',
    discoveries: source?.discoveries ?? '',
  };
}
export interface CharacterMutation {
  participationRevision?: number;
  operationId: string;
  expectedRevision: number | null;
  character: Character;
  kind: 'draft' | 'publish' | 'discard' | 'archive' | 'inventory' | 'condition';
  conditionAction?: ConditionAction;
  conditionContext?: ConditionContext;
  inventoryAction?: InventoryAction;
  correctionReason?: string;
}
export function newSheet(): CharacterSheet {
  return {
    identity: {
      name: '',
      description: '',
      age: null,
      height: null,
      bodyWeight: null,
      size: 'medium',
      portrait: '',
    },
    method: 'array-a',
    methodReason: '',
    baseScores: {
      str: null,
      dex: null,
      con: null,
      int: null,
      wis: null,
      cha: null,
    },
    originId: '',
    levels: [
      { classId: 'brutal', color: 'none', contextRevision: 0, choices: {} },
    ],
    rulesContext: {
      gameColor: 'none',
      revision: 0,
      sourceFingerprint: SOURCE.fingerprint,
    },
    advancementMode: 'milestones',
    xp: [],
    hpCurrent: null,
    notes: '',
    contacts: '',
    discoveries: '',
    overrides: [],
  };
}
export function newCharacter(): Character {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    schemaVersion: 1,
    revision: 0,
    createdAt: now,
    updatedAt: now,
    archived: false,
    sheet: null,
    draft: newSheet(),
  };
}
export function withGameColor(
  sheet: CharacterSheet,
  color: GameColor,
  retrospective: boolean,
): CharacterSheet {
  const revision = sheet.rulesContext.revision + 1;
  return {
    ...sheet,
    rulesContext: { ...sheet.rulesContext, gameColor: color, revision },
    levels: retrospective
      ? sheet.levels.map((l, i) =>
          i === 0 ? l : { ...l, color, contextRevision: revision },
        )
      : sheet.levels,
  };
}
