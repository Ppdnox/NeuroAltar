import { xpThresholds } from './catalog';

/** Progress from the current character level to its next handbook threshold. */
export function experienceProgress(xp: number, level: number) {
  const current = Math.max(1, Math.min(12, Math.floor(level)));
  const floor = xpThresholds[current - 1]!;
  const target = xpThresholds[current] ?? null;
  return {
    nextLevel: target === null ? null : current + 1,
    target,
    remaining: target === null ? 0 : Math.max(0, target - xp),
    percent:
      target === null
        ? 100
        : Math.max(0, Math.min(100, ((xp - floor) / (target - floor)) * 100)),
  };
}
