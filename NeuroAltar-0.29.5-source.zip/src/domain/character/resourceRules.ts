import type { ResourceDefinition } from './resources';

/** One pool belongs to one original ability, including its later upgrades. */
export const resourceRuleIds: Readonly<Record<string, string>> = {
  berserk: 'class.brutal.1.0',
  rage: 'class.brutal.2.1',
  motivation: 'class.cwaniak.1.0',
  luck: 'class.cwaniak.1.1',
  heckle: 'class.cwaniak.2.1',
  insult: 'class.cwaniak.5.1',
  advice: 'class.spec.1.0',
  defense: 'class.spec.1.1',
  brain: 'class.spec.2.0',
  production: 'class.spec.3.0',
  hands: 'class.spec.4.0',
  trajectory: 'class.spec.7.1',
  stamina: 'class.twardziel.1.1',
  surge: 'class.twardziel.2.0',
  toughness: 'class.twardziel.3.0',
  cat: 'class.zlodziej.2.1',
  matrix: 'class.zlodziej.7.0',
  sapper: 'class.zlodziej.11.0',
  amen: 'profession.preacher.0',
  concert: 'profession.star.3',
  clint: 'profession.cowboy.0',
  patriot: 'origin.newyork.patriot',
  stubborn: 'origin.hegemony.stubborn',
  believe: 'origin.saltlake.believe',
  fart: 'origin.vegas.luck',
  song: 'feat.musician',
};

export function resourcesForRule(
  resources: readonly ResourceDefinition[],
  ruleId: string,
): ResourceDefinition[] {
  return resources.filter(
    (resource) => resourceRuleIds[resource.id] === ruleId,
  );
}

/** Keep custom pools and any future unmapped resource visible as their own card. */
export function unassignedResources(
  resources: readonly ResourceDefinition[],
  rules: readonly { id: string }[],
): ResourceDefinition[] {
  const visibleIds = new Set(rules.map((rule) => rule.id));
  return resources.filter(
    (resource) => !visibleIds.has(resourceRuleIds[resource.id] ?? ''),
  );
}

/** Bound large custom pools; normal class pools fit in a single row of dots. */
export function resourceDotPage(
  max: number,
  spent: number,
  requestedPage: number | null,
) {
  const pageSize = 24;
  const remaining = Math.max(0, max - spent);
  const lastPage = Math.max(0, Math.ceil(max / pageSize) - 1);
  const page = Math.min(
    lastPage,
    Math.max(
      0,
      requestedPage ?? Math.floor(Math.max(0, remaining - 1) / pageSize),
    ),
  );
  const start = page * pageSize;
  return {
    remaining,
    page,
    lastPage,
    start,
    end: Math.min(max, start + pageSize),
  };
}

/** Dot positions are presentation only; persisted state remains a spent count. */
export interface ResourceDotLayout {
  max: number;
  spent: number;
  baseSpent: number;
  available: Record<number, boolean>;
}

export function resourceDotAvailable(
  layout: ResourceDotLayout | null,
  max: number,
  spent: number,
  index: number,
): boolean {
  if (index < 0 || index >= max) return false;
  if (layout?.max === max && layout.spent === spent)
    return (
      layout.available[index] ?? index < Math.max(0, max - layout.baseSpent)
    );
  return index < Math.max(0, max - spent);
}

export function toggleResourceDot(
  layout: ResourceDotLayout | null,
  max: number,
  spent: number,
  index: number,
): ResourceDotLayout | null {
  if (index < 0 || index >= max) return null;
  const previous =
    layout?.max === max && layout.spent === spent
      ? layout
      : { max, spent, baseSpent: spent, available: {} };
  const available = resourceDotAvailable(previous, max, spent, index);
  const nextSpent = spent + (available ? 1 : -1);
  if (nextSpent < 0) return null;
  // Historical uses above a reduced maximum must be cleared before a dot refills.
  if (spent > max) return null;
  return {
    ...previous,
    spent: nextSpent,
    available: { ...previous.available, [index]: !available },
  };
}
