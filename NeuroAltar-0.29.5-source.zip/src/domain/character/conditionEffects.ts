import type { Condition } from './conditionModel';

// Neuroshima: Ostatnia Era, s. 32 i 36. Każdy wyższy stopień zachowuje wcześniejsze skutki.
export const characterInjurySteps = [
  { level: 1, label: 'Lekkie', effect: 'Szybkość −4,5 m' },
  { level: 2, label: 'Znaczne', effect: 'Brak Reakcji' },
  { level: 3, label: 'Poważne', effect: 'Brak Akcji Bonusowej' },
  { level: 4, label: 'Krytyczne', effect: '+1 Wyczerpania przy otrzymaniu' },
  { level: 5, label: 'Śmiertelne', effect: 'Śmierć' },
] as const;

export function characterConditionEffects(condition?: Condition) {
  const injury = condition?.injury ?? 0;
  const exhaustion = Math.min(
    6,
    condition?.exhaustion.reduce((sum, e) => sum + e.level, 0) ?? 0,
  );
  const injurySpeedPenalty = injury > 0 ? 4.5 : 0;
  const exhaustionSpeedPenalty = exhaustion * 1.5;
  const fatal =
    injury >= 5 || exhaustion >= 6 || !!condition?.combatHealth?.dead;
  return {
    injury,
    exhaustion,
    injurySpeedPenalty,
    exhaustionSpeedPenalty,
    speedPenalty: injurySpeedPenalty + exhaustionSpeedPenalty,
    testPenalty: exhaustion * 2,
    reactionBlocked: injury >= 2 || fatal,
    bonusBlocked: injury >= 3 || fatal,
    fatal,
    injuryLabel:
      characterInjurySteps.find((step) => step.level === injury)?.label ??
      'Brak',
    messages: [
      ...(injury > 0 ? ['Zranienia: Szybkość −4,5 m'] : []),
      ...(injury >= 2 ? ['Brak Reakcji'] : []),
      ...(injury >= 3 ? ['Brak Akcji Bonusowej'] : []),
      ...(exhaustion > 0
        ? [
            `Wyczerpanie: testy k20 −${exhaustion * 2}, Szybkość −${String(exhaustionSpeedPenalty).replace('.', ',')} m`,
          ]
        : []),
      ...(fatal ? ['Śmierć'] : []),
    ],
  };
}
