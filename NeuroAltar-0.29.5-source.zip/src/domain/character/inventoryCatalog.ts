import { withItemDisplayName } from '../catalogNames';
import rawProfiles from '../../data/character/equipment-profiles.v1.json';
import { type Item, weaponProfileSchema } from '../item';
import {
  newInventoryEntry,
  weaponRulesSchema,
  armorRulesSchema,
} from './inventoryModel';
import type { ClassId } from './model';
const profiles = rawProfiles as Record<
  string,
  { weapon?: unknown; armor?: unknown; profile?: unknown }
>;
export function customItem(name = 'Nowy przedmiot'): Item {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    name,
    type: 'other',
    category: 'Własne',
    economicCategory: '',
    basePrice: null,
    baseAvailability: null,
    weight: null,
    description: '',
    properties: [],
    createdAt: now,
    updatedAt: now,
  };
}
const ammo: Record<string, string> = {
  '5dec34a8-773d-5871-96a7-f58b29f18cec': '.22 LR',
  '8029c4f0-551b-505d-903b-da4735a1f930': '.38 SPL',
  'f2605316-9c5c-5d60-8db9-eaa567c50f95': '9 mm',
  '2aff4c3d-2729-5abd-a39b-ac2bd81f0688': '.45 ACP',
  'd6a2b5d5-4b56-5e7a-a25f-130016d8dcef': '.44 Mag',
  '34435794-8b66-51bc-b298-421f1c532993': '5,56 mm',
  'f8570661-4efa-5136-bd44-e6dce553cdaf': '7,62×39 mm',
  'e14115f7-d852-59de-a4ed-16befe31907b': '7,62 mm',
  '1988e3ac-2861-5c34-87e2-d46a4a72fa9c': '.30-06',
  '565e8ac1-053f-5ed7-b807-144dd5c824a0': '.50 BMG',
  '33cb4a98-83df-5ec4-b46b-3f393629026f': '.12 Ga',
  '9672f855-3544-584d-b892-0abcee9a6c13': '.12 Ga',
  'bd55be4a-cc61-53ec-b289-3c702216ec1f': 'Granat 40 mm',
  'e7c1492b-421f-535d-93eb-1f3b4a3d39fb': 'Pocisk 60 mm',
  '92862e11-e056-5eab-83b2-92c1d9bfa0ca': 'Pocisk 120 mm',
  'f01c7bc4-9616-5741-ac9b-0f5c9f9eb03f': 'igła',
  '358c024b-f53d-515b-bdc0-91a56b51e14f': 'kulka stalowa',
  '045ff21e-aa95-5de5-938a-b96f097aa689': 'pocisk-strzykawka',
  'f8e2c98f-828c-5a45-8ed2-6e8f55d4ebdd': 'strzała',
  '17d5fad1-94ac-53aa-b129-c5c921c656d0': 'bełt',
};
export function catalogEntry(item: Item) {
  const e = newInventoryEntry(withItemDisplayName(item)),
    p = profiles[item.id];
  if (p?.weapon) {
    e.weapon = weaponRulesSchema.parse(p.weapon);
    e.item.weaponProfile = weaponProfileSchema.parse(p.profile);
    if (['internal', 'loading'].includes(e.weapon.system))
      e.magazine = {
        capacity: e.weapon.capacity,
        caliber: e.weapon.caliber,
        model: e.weapon.model,
        rounds: [],
      };
  }
  if (p?.armor) e.armor = armorRulesSchema.parse(p.armor);
  if (item.name === 'Antybiotyk (10 dawek)') {
    e.quantityMilli = 10000;
    e.item.name = 'Antybiotyk';
    if (e.item.basePrice)
      e.item.basePrice = {
        min: e.item.basePrice.min / 10,
        max: e.item.basePrice.max / 10,
      };
    e.item.description +=
      '\nOpakowanie: 10 dawek; ilość i cena w inwentarzu dotyczą jednej dawki.';
  }
  e.caliber = ammo[item.id] ?? '';
  return e;
}
const packs: Record<
  ClassId,
  { name: string; kg: number; page: number; contents: string }
> = {
  brutal: {
    name: 'Plecak turysty',
    kg: 22,
    page: 67,
    contents:
      '3 kg prowiantu, 4 l wody, 3 m stalowej linki, smar, oliwa, kompas, lina 15 m, czołówka, manierka, menażka, saperka, scyzoryk, śpiwór, WD-Tabs (10), zestaw rozpalania ognia, żyłka 20 m.',
  },
  cwaniak: {
    name: 'Plecak oszusta',
    kg: 10,
    page: 72,
    contents:
      '2 kg prowiantu, 2 l wody, trzy przebrania, dzwoneczek, olej, grzebień, czołówka, lusterko, manierka, menażka, notatnik, ołówek, piersiówka, śpiwór, karty, WD-Tabs (10).',
  },
  spec: {
    name: 'Plecak naukowca',
    kg: 10,
    page: 78,
    contents:
      '2 kg prowiantu, 2 l wody, książki, czołówka, linijka, manierka, miarka, notatnik, nożyczki, piórnik, klej, suwak logarytmiczny, taśma klejąca, termometr, waga stołowa, WD-Tabs (10), zapałki.',
  },
  twardziel: {
    name: 'Plecak żołnierza',
    kg: 15,
    page: 86,
    contents:
      '2 kg prowiantu, 4 l wody, kompas, lina 15 m, czołówka, manierka, menażka, pałatka, saperka, scyzoryk, WD-Tabs (10), zestaw rozpalania ognia.',
  },
  zlodziej: {
    name: 'Plecak włamywacza',
    kg: 15,
    page: 91,
    contents:
      '2 kg prowiantu, 2 l wody, 5 świec, 1 l odrdzewiacza, 1 l denaturatu, smar, dzwoneczek, hak, czołówka, lina 5 m, łom, manierka, menażka, WD-Tabs (10), zapałki.',
  },
  zwiadowca: {
    name: 'Plecak turysty',
    kg: 21,
    page: 96,
    contents:
      '2 kg prowiantu, 4 l wody, 3 m stalowej linki, smar, oliwa, kompas, lina 15 m, czołówka, manierka, menażka, saperka, scyzoryk, śpiwór, WD-Tabs (10), zestaw rozpalania ognia, żyłka 20 m.',
  },
};
export function starterPack(classId: ClassId) {
  const p = packs[classId],
    item = customItem('Zestaw startowy — ' + p.name);
  item.weight = p.kg;
  item.description = p.contents;
  item.source = `Neuroshima: Ostatnia Era, s. ${p.page}`;
  const e = newInventoryEntry(item);
  e.catalogId = null;
  e.massMode = 'aggregate';
  e.container = true;
  e.weightReason = item.source;
  return e;
}
