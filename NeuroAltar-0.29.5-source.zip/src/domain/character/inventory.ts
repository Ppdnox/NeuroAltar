import { inventoryWeight } from '../medicineWeight';
import {
  inventorySchema,
  type Inventory,
  type InventoryAction,
  type InventoryEntry,
  type FireMode,
} from './inventoryModel';
import type { GameColor } from './model';
import {
  allowedSlots,
  canUseHandySlot,
  isHandySlot,
  isLegacyHandSlot,
  isNumberedWeaponSlot,
  isReadyWeapon,
  weaponSlotKind,
} from './inventorySlots';

export class InventoryError extends Error {
  constructor(
    public entryId: string | null,
    message: string,
  ) {
    super(message);
  }
}
function fail(e: InventoryEntry | undefined, message: string): never {
  throw new InventoryError(
    e?.id ?? null,
    `${e?.item.name ? e.item.name + ' — ' : ''}${message}`,
  );
}
export const countRounds = (e: InventoryEntry) =>
  e.magazine?.rounds.reduce((s, l) => s + l.count, 0) ?? 0;
export const cinematic = (i: Inventory, color: GameColor) =>
  i.ammoMode === 'cinematic' || (i.ammoMode === 'auto' && color === 'chrome');
export function findEntry(i: Inventory, id: string): InventoryEntry {
  const e = i.entries.find((e) => e.id === id);
  if (!e) return fail(undefined, 'Nie znaleziono przedmiotu.');
  return e;
}
/** The installed magazine follows its weapon; other containers follow their parent. */
export function parentEntry(
  i: Inventory,
  e: InventoryEntry,
): InventoryEntry | undefined {
  return (
    i.entries.find((w) => w.installedMagazineId === e.id) ??
    i.entries.find((p) => p.id === e.parentId)
  );
}
export function ancestry(i: Inventory, e: InventoryEntry): InventoryEntry[] {
  const seen = new Set([e.id]),
    out: InventoryEntry[] = [];
  let p = parentEntry(i, e);
  while (p) {
    if (seen.has(p.id)) fail(e, 'Pojemniki tworzą cykl.');
    seen.add(p.id);
    out.push(p);
    p = parentEntry(i, p);
  }
  return out;
}
export const effectivePlace = (i: Inventory, e: InventoryEntry) =>
  ancestry(i, e).at(-1)?.location ?? e.location;
export function validateInventory(input: Inventory): Inventory {
  const i = inventorySchema.parse(input);
  const ids = new Set<string>(),
    slots = new Set<string>();
  let melee = 0,
    ranged = 0,
    handy = 0;
  if (new Set(i.starterClaims).size !== i.starterClaims.length)
    fail(undefined, 'Powtórzone przyznanie zestawu.');
  for (const e of i.entries) {
    if (ids.has(e.id)) fail(e, 'Powtórzony identyfikator.');
    ids.add(e.id);
    if (e.weightMg !== null && !e.weightReason.trim())
      fail(e, 'Podaj źródło lub uzasadnienie masy.');
    if (
      e.massMode === 'aggregate' &&
      (!e.container || e.quantityMilli !== 1000)
    )
      fail(e, 'Masa całego zestawu wymaga jednego pojemnika.');
    if (
      (e.weapon || e.magazine || e.slot !== 'none' || e.container) &&
      e.quantityMilli !== 1000
    )
      fail(
        e,
        'Egzemplarz broni, magazynek, pojemnik i wyposażony przedmiot wymagają ilości 1.',
      );
    if (
      e.caliber &&
      (e.quantityMilli % 1000 !== 0 ||
        e.weapon ||
        e.magazine ||
        e.item.type !== 'ammunition')
    )
      fail(e, 'Zapas amunicji wymaga całkowitej liczby naboi.');
    if (e.weapon && e.item.type !== 'weapon')
      fail(e, 'Profil broni wymaga typu Broń.');
    if (e.armor && e.item.type !== 'armor')
      fail(e, 'Profil pancerza wymaga typu Pancerz.');
    if (e.parentId) {
      const p = findEntry(i, e.parentId);
      if (!p.container) fail(e, 'Rodzic musi być pojemnikiem.');
    }
    const ancestors = ancestry(i, e),
      place = effectivePlace(i, e);
    if (
      ancestors.some((p) => p.massMode === 'aggregate') &&
      (e.caliber || e.magazine || e.weapon || e.slot !== 'none')
    )
      fail(
        e,
        'Amunicję i wyposażenie wyodrębnij z masy zestawu przed użyciem.',
      );
    const installed = i.entries.some(
      (weapon) => weapon.installedMagazineId === e.id,
    );
    if (e.slot !== 'none') {
      if (place === 'external' || place === 'backpack' || e.parentId)
        fail(e, 'Wyposażenie musi być przy sobie, poza pojemnikiem.');
      if (
        slots.has(e.armor?.kind === 'shield' ? 'shield' : e.slot) ||
        (['mainHand', 'offHand'].includes(e.slot) && slots.has('bothHands')) ||
        (e.slot === 'bothHands' &&
          (slots.has('mainHand') || slots.has('offHand')))
      )
        fail(e, 'To miejsce wyposażenia jest już zajęte.');
      slots.add(e.armor?.kind === 'shield' ? 'shield' : e.slot);
      // Historical hand occupation remains valid; numbered places describe storage.
      if (isLegacyHandSlot(e.slot)) slots.add(e.slot);
      if (
        isNumberedWeaponSlot(e.slot) &&
        (place !== 'body' || !allowedSlots(e).includes(e.slot))
      )
        fail(e, 'Typ broni nie pasuje do wybranego slotu.');
      if (isHandySlot(e.slot) && (place !== 'handy' || !canUseHandySlot(e)))
        fail(e, 'Przedmiot nie pasuje do miejsca podręcznego.');
      const armorSlot = (
        {
          light: 'armor',
          medium: 'armor',
          heavy: 'armor',
          helmet: 'helmet',
          arms: 'arms',
          legs: 'legs',
          shield: e.slot === 'offHand' ? 'offHand' : 'shield',
        } as const
      )[e.armor?.kind ?? 'light'];
      if (
        ['armor', 'helmet', 'arms', 'legs', 'shield'].includes(e.slot) &&
        (!e.armor || armorSlot !== e.slot)
      )
        fail(e, 'Profil nie pasuje do miejsca wyposażenia.');
      if (e.armor && armorSlot !== e.slot)
        fail(e, 'Nieprawidłowe miejsce pancerza lub tarczy.');
      if (
        e.weapon?.twoHanded &&
        ((isLegacyHandSlot(e.slot) && e.slot !== 'bothHands') ||
          (!isLegacyHandSlot(e.slot) && e.grip === 'oneHanded'))
      )
        fail(e, 'Broń wymaga obu rąk.');
    }
    if (isHandySlot(e.slot)) handy++;
    else if (place === 'handy' && !e.weapon && !e.parentId && !installed)
      handy += e.quantityMilli / 1000;
    if (isNumberedWeaponSlot(e.slot)) {
      if (weaponSlotKind(e) === 'melee') melee++;
      else ranged++;
    } else if (
      !isHandySlot(e.slot) &&
      (place === 'body' || place === 'handy') &&
      e.weapon &&
      !e.parentId
    ) {
      if (e.weapon.category === 'melee') melee++;
      else ranged++;
    }
    if (e.installedMagazineId) {
      const m = findEntry(i, e.installedMagazineId);
      const w = e.weapon;
      if (
        !w ||
        w.system !== 'detachable' ||
        !m.magazine ||
        m.weapon ||
        m.parentId ||
        m.slot !== 'none' ||
        m.id === e.id
      )
        fail(e, 'Nieprawidłowy magazynek wymienny.');
      if (
        m.magazine!.model !== w!.model ||
        m.magazine!.caliber !== w!.caliber ||
        m.magazine!.capacity !== w!.capacity
      )
        fail(
          e,
          'Magazynek nie pasuje do modelu, kalibru lub pojemności broni.',
        );
      if (i.entries.filter((x) => x.installedMagazineId === m.id).length !== 1)
        fail(e, 'Magazynek jest już w innej broni.');
    }
    if (e.weapon) {
      const w = e.weapon;
      if (
        ['internal', 'loading'].includes(w.system) &&
        (!e.magazine ||
          e.magazine.capacity !== w.capacity ||
          e.magazine.caliber !== w.caliber ||
          e.magazine.model !== w.model)
      )
        fail(e, 'Uzupełnij zgodny magazynek wewnętrzny.');
      if (!['internal', 'loading'].includes(w.system) && e.magazine)
        fail(e, 'Ten system broni nie ma magazynka wewnętrznego.');
    }
    if (e.magazine) {
      if (countRounds(e) > e.magazine.capacity)
        fail(e, 'Przekroczona pojemność magazynka.');
      for (const l of e.magazine.rounds) {
        const a = findEntry(i, l.ammoId);
        if (
          !a.caliber ||
          a.caliber !== e.magazine.caliber ||
          a.weapon ||
          a.magazine ||
          a.item.type !== 'ammunition'
        )
          fail(e, 'Niekompatybilny nabój.');
      }
    }
  }
  if (handy > 3)
    fail(
      undefined,
      'Pod ręką mieszczą się 3 przedmioty. Pozostałe przenieś do plecaka.',
    );
  if (melee > 4 || ranged > 3)
    fail(
      undefined,
      'Przy sobie: maksymalnie 4 bronie białe i 3 dystansowe. Pozostałe przenieś do plecaka.',
    );
  const heavy = i.entries.some(
    (e) => e.slot === 'armor' && e.armor?.kind === 'heavy',
  );
  if (heavy && i.entries.some((e) => e.slot === 'arms' || e.slot === 'legs'))
    fail(undefined, 'Ciężkiego pancerza nie łączy się z ochraniaczami.');
  return i;
}
export function shotCost(mode: FireMode, count: number): number {
  const allowed: Record<FireMode, number[]> = {
    single: [1],
    double: [2],
    short: [3],
    long: [10, 15, 20, 25, 30],
    massive: [50, 100, 150, 200],
  };
  if (!allowed[mode].includes(count))
    fail(undefined, 'Nieprawidłowa liczba naboi dla tego trybu.');
  return count;
}
export function weaponMagazine(i: Inventory, w: InventoryEntry) {
  return w.installedMagazineId
    ? findEntry(i, w.installedMagazineId)
    : w.magazine
      ? w
      : undefined;
}
export function applyInventoryAction(
  before: Inventory,
  action: InventoryAction,
  color: GameColor,
  ignoreCycle = false,
): Inventory {
  validateInventory(before);
  const i = structuredClone(before);
  const edit = (entry: InventoryEntry) => {
    const idx = i.entries.findIndex((e) => e.id === entry.id);
    if (idx < 0) i.entries.push(structuredClone(entry));
    else i.entries[idx] = structuredClone(entry);
  };
  switch (action.kind) {
    case 'weaponState': {
      const w = findEntry(i, action.weaponId);
      if (!w.weapon || w.weapon.system === 'none')
        fail(w, 'Wybierz broń strzelecką.');
      const state = (w.combatState ??= {
        jammed: false,
        overheated: false,
        heatPending: false,
      });
      if (action.operation === 'jam') {
        if (color === 'chrome') fail(w, 'Chrom: broń się nie zacina.');
        if (state.jammed) fail(w, 'Broń jest już zacięta.');
        state.jammed = true;
      } else if (action.operation === 'clearJam') {
        if (!state.jammed) fail(w, 'Broń nie jest zacięta.');
        state.jammed = false;
      } else if (action.operation === 'heat') {
        if (
          !state.heatPending ||
          action.face === null ||
          !Number.isInteger(action.face) ||
          action.face < 1 ||
          action.face > 6
        )
          fail(w, 'Podaj wynik k6 po serii.');
        state.heatPending = false;
        state.overheated = action.face! < 5;
      } else {
        if (!action.reason.trim())
          fail(w, 'Podaj uzasadnienie ostygnięcia broni.');
        state.overheated = false;
        state.heatPending = false;
      }
      break;
    }
    case 'edit': {
      if (!action.reason.trim() || action.reason.length > 300)
        fail(undefined, 'Podaj powód nabycia lub korekty.');
      const old = i.entries.find((e) => e.id === action.entry.id);
      if (
        old &&
        JSON.stringify(old.magazine?.rounds ?? []) !==
          JSON.stringify(action.entry.magazine?.rounds ?? [])
      )
        fail(old, 'Naboje przenoś przyciskami ładowania i rozładowania.');
      if (
        !old &&
        (countRounds(action.entry) > 0 || action.entry.installedMagazineId)
      )
        fail(action.entry, 'Nowy magazynek musi być pusty.');
      if (
        old &&
        ancestry(i, old).some((p) => p.massMode === 'aggregate') &&
        (old.parentId !== action.entry.parentId ||
          old.quantityMilli !== action.entry.quantityMilli)
      )
        fail(
          old,
          'Najpierw zmień masę zestawu na sumę składników i uzupełnij ich masy.',
        );
      edit(action.entry);
      break;
    }
    case 'remove': {
      const e = findEntry(i, action.entryId);
      if (!action.reason.trim()) fail(e, 'Podaj powód usunięcia.');
      if (
        countRounds(e) ||
        e.installedMagazineId ||
        i.entries.some(
          (p) =>
            p.parentId === e.id ||
            p.installedMagazineId === e.id ||
            p.magazine?.rounds.some((l) => l.ammoId === e.id),
        )
      )
        fail(
          e,
          'Najpierw opróżnij pojemnik, rozładuj naboje i odłącz magazynek.',
        );
      if (ancestry(i, e).some((p) => p.massMode === 'aggregate'))
        fail(e, 'Najpierw rozdziel masę całego zestawu.');
      i.entries = i.entries.filter((p) => p.id !== e.id);
      break;
    }
    case 'load': {
      const m = findEntry(i, action.magazineId),
        a = findEntry(i, action.ammoId),
        n = action.count;
      if (!m.magazine || !a.caliber || a.caliber !== m.magazine.caliber)
        fail(m, 'Niekompatybilna amunicja.');
      if (
        !Number.isSafeInteger(n) ||
        n < 1 ||
        a.quantityMilli < n * 1000 ||
        countRounds(m) + n > m.magazine.capacity
      )
        fail(m, 'Brakuje naboi lub miejsca w magazynku.');
      a.quantityMilli -= n * 1000;
      const lot = m.magazine.rounds.find((l) => l.ammoId === a.id);
      if (lot) lot.count += n;
      else m.magazine.rounds.push({ ammoId: a.id, count: n });
      break;
    }
    case 'unload': {
      const m = findEntry(i, action.magazineId);
      if (!m.magazine) fail(m, 'Brak magazynka.');
      for (const l of m.magazine.rounds)
        findEntry(i, l.ammoId).quantityMilli += l.count * 1000;
      m.magazine.rounds = [];
      break;
    }
    case 'attach': {
      const w = findEntry(i, action.weaponId);
      if (w.weapon?.system !== 'detachable')
        fail(w, 'Ta broń nie ma wymiennego magazynka.');
      if (w.installedMagazineId === action.magazineId) break;
      const incoming = action.magazineId
        ? findEntry(i, action.magazineId)
        : undefined;
      const handyPlace =
        incoming && isHandySlot(incoming.slot)
          ? {
              slot: incoming.slot,
              location: incoming.location,
              parentId: incoming.parentId,
            }
          : null;
      if (w.installedMagazineId) {
        const old = findEntry(i, w.installedMagazineId);
        if (handyPlace) Object.assign(old, handyPlace);
        else {
          old.location = effectivePlace(i, w);
          old.parentId = w.parentId;
        }
      }
      if (incoming && handyPlace) incoming.slot = 'none';
      w.installedMagazineId = action.magazineId;
      break;
    }
    case 'cycle': {
      const w = findEntry(i, action.weaponId);
      if (!w.weapon?.cycle || !w.needsCycle)
        fail(w, 'Broń nie wymaga przeładowania mechanizmu.');
      w.needsCycle = false;
      break;
    }
    case 'shot': {
      const w = findEntry(i, action.weaponId),
        n = shotCost(action.mode, action.count);
      if (
        !w.weapon ||
        !w.weapon.modes.includes(action.mode) ||
        w.weapon.system === 'none'
      )
        fail(w, 'Broń nie obsługuje tego strzału.');
      if (!isReadyWeapon(w))
        fail(w, 'Najpierw umieść broń w odpowiednim slocie.');
      if (w.combatState?.jammed) fail(w, 'Broń jest zacięta.');
      if (
        ['long', 'massive'].includes(action.mode) &&
        (w.combatState?.overheated || w.combatState?.heatPending)
      )
        fail(w, 'Przegrzanie: rozlicz lub ostudź broń przed następną serią.');
      if (w.spent) fail(w, 'Przedmiot został już zużyty.');
      if (w.needsCycle && !ignoreCycle)
        fail(w, 'Najpierw przeładuj mechanizm.');
      if (w.weapon.system === 'singleUse') w.spent = true;
      else if (cinematic(i, color)) {
        if (!w.cinematicLoaded) fail(w, 'Pusta broń — przeładuj.');
      } else {
        const m = weaponMagazine(i, w);
        if (!m?.magazine || countRounds(m) < n)
          fail(w, 'Pusty magazynek lub za mało naboi — przeładuj.');
        let left = n;
        for (const l of m.magazine.rounds) {
          const used = Math.min(left, l.count);
          l.count -= used;
          left -= used;
        }
        m.magazine.rounds = m.magazine.rounds.filter((l) => l.count > 0);
      }
      w.needsCycle = w.weapon.cycle && !ignoreCycle;
      if (cinematic(i, color) && ['long', 'massive'].includes(action.mode)) {
        w.combatState ??= {
          jammed: false,
          overheated: false,
          heatPending: false,
        };
        w.combatState.heatPending = true;
      }
      break;
    }
    case 'cinematic': {
      const w = findEntry(i, action.weaponId);
      if (
        !cinematic(i, color) ||
        !w.weapon ||
        ['none', 'singleUse'].includes(w.weapon.system)
      )
        fail(w, 'Tryb nieliczonego zapasu nie jest aktywny.');
      w.cinematicLoaded = action.loaded;
      break;
    }
    case 'mode':
      i.ammoMode = action.mode;
      break;
    case 'starter': {
      const complete = [
        'initial-loadout:equipment',
        'initial-loadout:gamble',
      ].includes(action.key);
      if (
        (!complete && action.key !== 'initial-equipment') ||
        i.starterClaims.includes(action.key) ||
        (complete &&
          i.starterClaims.some((key) =>
            ['initial-loadout:equipment', 'initial-loadout:gamble'].includes(
              key,
            ),
          )) ||
        (!action.entries.length &&
          (!complete || !i.starterClaims.includes('initial-equipment')))
      )
        fail(undefined, 'Zestaw startowy przyznaje się tylko raz.');
      for (const e of action.entries) {
        if (
          i.entries.some((x) => x.id === e.id) ||
          countRounds(e) ||
          e.installedMagazineId
        )
          fail(
            e,
            'Nowe wyposażenie startowe musi mieć niezależne ID i puste magazynki.',
          );
        edit(e);
      }
      if (complete && !i.starterClaims.includes('initial-equipment'))
        i.starterClaims.push('initial-equipment');
      i.starterClaims.push(action.key);
      break;
    }
  }
  return validateInventory(i);
}
export function calculateCarriedWeight(i: Inventory) {
  validateInventory(i);
  let mg = 0n;
  const unknown = new Set<string>();
  const add = (e: InventoryEntry, quantityMilli: number) => {
    if (!quantityMilli) return;
    const weight = inventoryWeight(e);
    if (weight === null) unknown.add(e.id);
    else mg += (BigInt(weight) * BigInt(quantityMilli)) / 1000n;
  };
  for (const e of i.entries) {
    if (
      effectivePlace(i, e) === 'external' ||
      ancestry(i, e).some((p) => p.massMode === 'aggregate')
    )
      continue;
    add(e, e.quantityMilli);
    for (const l of e.magazine?.rounds ?? [])
      add(findEntry(i, l.ammoId), l.count * 1000);
  }
  if (mg > BigInt(Number.MAX_SAFE_INTEGER))
    fail(undefined, 'Masa przekracza bezpieczny zakres.');
  return {
    knownMg: Number(mg),
    kg: Number(mg) / 1_000_000,
    unknownIds: [...unknown],
    complete: unknown.size === 0,
  };
}
export function calculateEncumbrance(
  kg: number,
  complete: boolean,
  user: number | null,
  max: number | null,
  speed: number | null,
) {
  if (!complete || user === null || max === null || speed === null)
    return {
      speed: null,
      attackDisadvantage: false,
      label: 'Niepełne dane masy lub udźwigu',
    };
  if (kg >= max)
    return {
      speed: 0,
      attackDisadvantage: true,
      label: 'Osiągnięty udźwig maksymalny',
    };
  if (kg > user)
    return {
      speed: speed / 2,
      attackDisadvantage: true,
      label: 'Przeciążenie: połowa Szybkości i Utrudnienie ataków',
    };
  return { speed, attackDisadvantage: false, label: 'Bez przeciążenia' };
}
