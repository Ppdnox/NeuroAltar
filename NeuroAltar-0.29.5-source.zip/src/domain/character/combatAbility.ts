import { z } from 'zod';

// Only rules with a concrete combat path belong in the combat-use selector.
// Other learned rules stay visible on the character sheet; a generic form must
// not turn a narrative description into an arbitrary roll modifier.
const combatRuleIds = new Set([
  'class.zlodziej.1.1',
  'profession.star.1',
  'profession.preacher.1',
  'profession.preacher.2',
  'feat.neo',
  'feat.steady',
]);
const combatResourceIds = new Set([
  'berserk',
  'rage',
  'motivation',
  'luck',
  'heckle',
  'insult',
  'advice',
  'defense',
  'brain',
  'hands',
  'stamina',
  'surge',
  'trajectory',
]);
export function hasCombatAbilityPath(ruleId: string): boolean {
  return ruleId.startsWith('resource:')
    ? combatResourceIds.has(ruleId.slice('resource:'.length))
    : combatRuleIds.has(ruleId);
}

export const abilityResolutionSchema = z.discriminatedUnion('kind', [
  z
    .object({
      kind: z.literal('catDefense'),
      die: z.number().int().min(1).max(12),
    })
    .strict(),
  z
    .object({
      kind: z.literal('deadlyInsult'),
      die: z.number().int().min(1).max(6),
    })
    .strict(),
  z.object({ kind: z.literal('sneakBleed') }).strict(),
  z
    .object({
      kind: z.literal('sneakSlow'),
      die: z.number().int().min(1).max(6),
    })
    .strict(),
  z.object({ kind: z.literal('sneakBlind') }).strict(),
  z
    .object({
      kind: z.literal('matrix'),
      incomingDamage: z.number().int().min(0).max(100000),
      saveSucceeded: z.boolean(),
    })
    .strict(),
  z
    .object({
      kind: z.literal('dodge'),
      incomingDamage: z.number().int().min(0).max(100000),
    })
    .strict(),
]);
export type AbilityResolution = z.infer<typeof abilityResolutionSchema>;
export const abilityApplicationSchema = z
  .object({
    ruleId: z.string().min(1).max(150),
    label: z.string().min(1).max(200),
    page: z.number().int().min(1).max(1000),
    cost: z.enum(['none', 'action', 'bonus', 'reaction', 'interaction', 'use']),
    once: z.enum(['none', 'turn', 'round']),
    confirmed: z.literal(true),
    additionalTargets: z
      .array(
        z.object({ id: z.uuid(), revision: z.number().int().min(0) }).strict(),
      )
      .max(99)
      .optional(),
    targetId: z.uuid(),
    targetRevision: z.number().int().min(0),
    resolution: abilityResolutionSchema.optional(),
    effect: z
      .object({
        speedReduction: z.number().min(0).max(100).optional(),
        condition: z.enum(['bleeding', 'blinded']).optional(),
        recipientActorId: z.uuid().optional(),
        checkDice: z
          .string()
          .regex(/^1k(4|6|8|10|12)$/)
          .optional(),
        nextRoll: z.boolean().optional(),
        clockActorId: z.uuid().optional(),
        sourceRuleId: z.string().max(150).optional(),
        damageDice: z
          .string()
          .regex(/^([1-9]|[1-9][0-9])k(4|6|8|10|12|20)$/)
          .optional(),
        id: z.uuid(),
        label: z.string().min(1).max(300),
        remaining: z.number().int().min(1).max(1000),
        phase: z.enum(['start', 'end', 'round', 'manual']),
        target: z.enum([
          'attackSave',
          'intTools',
          'tt',
          'all',
          'attack',
          'damage',
          'str',
          'dex',
          'con',
          'int',
          'wis',
          'cha',
          'save',
          'skill',
        ]),
        modifier: z.number().int().min(-100).max(100),
        mode: z.enum(['normal', 'advantage', 'disadvantage']),
      })
      .strict()
      .nullable(),
  })
  .strict();
export type AbilityApplication = z.infer<typeof abilityApplicationSchema>;
