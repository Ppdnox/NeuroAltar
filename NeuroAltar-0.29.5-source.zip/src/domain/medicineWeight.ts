import catalog from '../data/equipment/catalog.v1.json';
import supplement from '../data/equipment/moloch-city.v1.json';
import type { Item } from './item';
// MG ruling: medicines without a handbook mass count as 0 kg.
const medicines = new Set([
  'Desmopresyna',
  'Aspiryna K',
  'Dracophen',
  'Reminex',
  'Relanium',
  'Wapniak',
  'Psychotropy',
  'Actinix',
  'RadOff',
  'Antybiotyki',
]);
export const medicineWithoutMass = (item: Item) =>
  item.weight === null &&
  (item.category === 'Prochy i używki / Środki lecznicze' ||
    medicines.has(item.name));
const weaponMasses = new Map(
  [...catalog.entries, ...supplement.entries]
    .filter((i) => i.type === 'weapon')
    .map((i) => [
      i.id,
      i.weight ??
        Number(
          i.properties
            .find((p) => /^Waga: ok\. \d/.test(p))
            ?.match(/[\d,]+/)?.[0]
            ?.replace(',', '.') ?? NaN,
        ),
    ]),
);
export function fixedWeaponWeight(item: Item): number | null {
  const value = item.type === 'weapon' ? weaponMasses.get(item.id) : undefined;
  return value !== undefined && Number.isFinite(value) ? value : null;
}
export const weightlessAmmo = (entry: {
  item: Item;
  magazine?: unknown;
  weapon?: unknown;
  caliber?: string;
}) =>
  !entry.magazine &&
  !entry.weapon &&
  (entry.item.type === 'ammunition' || !!entry.caliber);
export const itemWeight = (item: Item) =>
  item.type === 'ammunition'
    ? 0
    : (fixedWeaponWeight(item) ??
      item.weight ??
      (medicineWithoutMass(item) ? 0 : null));
export const inventoryWeight = (entry: {
  weightMg: number | null;
  item: Item;
  magazine?: unknown;
  weapon?: unknown;
  caliber?: string;
}) =>
  weightlessAmmo(entry)
    ? 0
    : ((fixedWeaponWeight(entry.item) === null
        ? entry.weightMg
        : Math.round(fixedWeaponWeight(entry.item)! * 1_000_000)) ??
      (medicineWithoutMass(entry.item) ? 0 : null));
export const medicineWeightReason =
  'Decyzja MG: lek bez masy w podręczniku = 0 kg';
