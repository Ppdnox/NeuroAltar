import { z } from 'zod';
import { parsePartyLevels } from './difficulty';
import { encounterIdSchema, partyLevelsSchema } from './encounter';

export type SlotId = z.infer<typeof encounterIdSchema>;
export const encounterDetailsSchema = z
  .object({
    name: z
      .string()
      .refine((value) => value.trim().length > 0, 'Wpisz nazwę potyczki.'),
    notes: z.string(),
    partyLevels: partyLevelsSchema.optional(),
  })
  .strict();
export type EncounterDetails = z.infer<typeof encounterDetailsSchema>;
export function sameDetails(a: EncounterDetails, b: EncounterDetails) {
  return (
    a.name === b.name &&
    a.notes === b.notes &&
    (a.partyLevels === undefined ||
      JSON.stringify(a.partyLevels) === JSON.stringify(b.partyLevels))
  );
}

export type EncounterDetailsDraft = Omit<EncounterDetails, 'partyLevels'> & {
  partyLevelsText: string;
};
export function parseEncounterDetailsDraft(
  draft: EncounterDetailsDraft,
): EncounterDetails {
  return encounterDetailsSchema.parse({
    name: draft.name,
    notes: draft.notes,
    partyLevels: parsePartyLevels(draft.partyLevelsText),
  });
}
export function detailsDraftError(draft: EncounterDetailsDraft): string | null {
  try {
    parseEncounterDetailsDraft(draft);
    return null;
  } catch {
    return 'Popraw nazwę potyczki i poziomy BG (dodatnie liczby całkowite). Dane czekają na zapis.';
  }
}
