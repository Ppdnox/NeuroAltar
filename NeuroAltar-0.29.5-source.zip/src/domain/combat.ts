import { parseSP } from './difficulty';
import { tickMachineFailures } from './machineFailures';
import { parseFailureThreshold } from './machineFailureSchema';
import { refreshCapabilities } from './capabilities';
import { instantiateCapabilities } from './capabilitySchema';
import { statusListSchema, tickStatuses, type Status } from './status';
import { applyInjuryLevel } from './injury';
import { z } from 'zod';
import {
  enemyInstanceSchema,
  enemyTemplateSchema,
  parseSpeeds,
  parseCowardice,
  formatSpeeds,
  type EnemyInstance,
  type EnemyTemplate,
} from './enemy';
import { encounterIdSchema, SLOT_IDS } from './encounter';
import { advanceTurn, moveWithinTie } from './initiative';

const integer = z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
const actorCoreSchema = z
  .object({
    id: z.uuid(),
    displayName: z
      .string()
      .refine((value) => value.trim().length > 0, 'Wpisz nazwę postaci.'),
    ttCurrent: integer,
    hpCurrent: integer,
    hpMaxCurrent: integer.min(1),
    initiativeValue: z.number().int().nullable(),
    initiativeTieOrder: integer,
    statuses: z.array(z.string().trim().min(1)),
    effects: statusListSchema.optional(),
    enemy: enemyInstanceSchema.optional(),
  })
  .strict()
  .refine(
    (pc) => pc.hpCurrent <= pc.hpMaxCurrent,
    'Aktualne PW nie mogą przekraczać maksymalnych.',
  );
export const actorSchema = actorCoreSchema
  .safeExtend({
    prepared: actorCoreSchema.optional(),
  })
  .superRefine((actor, ctx) => {
    if (
      actor.prepared &&
      (actor.prepared.id !== actor.id ||
        actor.prepared.enemy?.template.id !== actor.enemy?.template.id ||
        JSON.stringify(actor.prepared.enemy?.template) !==
          JSON.stringify(actor.enemy?.template))
    )
      ctx.addIssue({
        code: 'custom',
        message:
          'Stan przygotowany musi należeć do tej samej postaci i szablonu.',
      });
  });
export type PreparedActor = z.infer<typeof actorCoreSchema>;
export type Actor = z.infer<typeof actorSchema>;
export const combatSchema = z
  .object({
    encounterId: encounterIdSchema,
    revision: integer,
    roundNumber: integer.min(1),
    currentTurnActorId: z.uuid().nullable(),
    actors: z.array(actorSchema),
  })
  .strict()
  .superRefine((combat, ctx) => {
    if (new Set(combat.actors.map((pc) => pc.id)).size !== combat.actors.length)
      ctx.addIssue({
        code: 'custom',
        message: 'Powtórzony identyfikator postaci.',
      });
    if (
      new Set(combat.actors.map((pc) => pc.initiativeTieOrder)).size !==
      combat.actors.length
    )
      ctx.addIssue({
        code: 'custom',
        message: 'Powtórzone miejsce w kolejce.',
      });
    if (
      combat.currentTurnActorId !== null &&
      !combat.actors.some(
        (pc) =>
          pc.id === combat.currentTurnActorId && pc.initiativeValue !== null,
      )
    )
      ctx.addIssue({
        code: 'custom',
        message:
          'Aktywna tura musi wskazywać postać z inicjatywą w tej potyczce.',
      });
  });
export type Combat = z.infer<typeof combatSchema>;
export const combatSlotsSchema = z
  .array(combatSchema)
  .length(5)
  .refine(
    (slots) =>
      SLOT_IDS.every((id) => slots.some((slot) => slot.encounterId === id)),
    'Wymagane są wszystkie sloty 1–5.',
  );

export interface ActorDraft {
  id: string;
  displayName: string;
  ttCurrent: string;
  hpCurrent: string;
  hpMaxCurrent: string;
  initiativeValue: string;
  initiativeTieOrder: number;
  statusesText: string;
  effects?: Status[];
  enemy?: EnemyInstance;
  speedsText?: string;
  cowardicePercentText?: string;
  spText?: string;
  failureThresholdText?: string;
  prepared?: PreparedActor;
}
export interface CombatDraft {
  roundNumber: number;
  currentTurnActorId: string | null;
  actors: ActorDraft[];
}
export function toActorDraft(pc: Actor): ActorDraft {
  return {
    ...pc,
    ttCurrent: String(pc.ttCurrent),
    hpCurrent: String(pc.hpCurrent),
    hpMaxCurrent: String(pc.hpMaxCurrent),
    initiativeValue:
      pc.initiativeValue === null ? '' : String(pc.initiativeValue),
    statusesText: pc.statuses.join('\n'),
    ...(pc.enemy
      ? {
          speedsText: formatSpeeds(pc.enemy.speeds),
          spText: pc.enemy.sp == null ? '' : String(pc.enemy.sp),
          failureThresholdText:
            pc.enemy.failureThreshold == null
              ? ''
              : String(pc.enemy.failureThreshold),
          cowardicePercentText:
            pc.enemy.cowardicePercent == null
              ? ''
              : String(pc.enemy.cowardicePercent),
        }
      : {}),
  };
}
export function toCombatDraft(combat: Combat): CombatDraft {
  return {
    roundNumber: combat.roundNumber,
    currentTurnActorId: combat.currentTurnActorId,
    actors: combat.actors.map(toActorDraft),
  };
}
function numericText(value: string) {
  return /^-?\d+$/.test(value.trim()) ? Number(value) : NaN;
}
export function parseActorDraft(pc: ActorDraft): Actor {
  return actorSchema.parse({
    ...(pc.prepared ? { prepared: pc.prepared } : {}),
    ...(pc.enemy
      ? {
          enemy: {
            ...pc.enemy,
            ...(pc.spText === undefined ||
            (pc.spText.trim() === '' && pc.enemy.sp === undefined)
              ? {}
              : { sp: parseSP(pc.spText) }),
            speeds: parseSpeeds(pc.speedsText ?? ''),
            ...(pc.failureThresholdText === undefined ||
            (pc.failureThresholdText.trim() === '' &&
              pc.enemy.failureThreshold === undefined)
              ? {}
              : {
                  failureThreshold: parseFailureThreshold(
                    pc.failureThresholdText,
                  ),
                }),
            ...(pc.cowardicePercentText === undefined ||
            (pc.cowardicePercentText.trim() === '' &&
              pc.enemy.cowardicePercent === undefined)
              ? {}
              : { cowardicePercent: parseCowardice(pc.cowardicePercentText) }),
          },
        }
      : {}),
    effects: pc.effects,
    id: pc.id,
    displayName: pc.displayName,
    ttCurrent: numericText(pc.ttCurrent),
    hpCurrent: numericText(pc.hpCurrent),
    hpMaxCurrent: numericText(pc.hpMaxCurrent),
    initiativeValue:
      pc.initiativeValue.trim() === '' ? null : numericText(pc.initiativeValue),
    initiativeTieOrder: pc.initiativeTieOrder,
    statuses: [
      ...new Set(
        pc.statusesText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
      ),
    ],
  });
}
export function parseCombatDraft(draft: CombatDraft, saved: Combat): Combat {
  return combatSchema.parse({
    ...draft,
    encounterId: saved.encounterId,
    revision: saved.revision,
    actors: draft.actors.map(parseActorDraft),
  });
}
export function nextCombatTurn(combat: Combat): Combat {
  const turn = advanceTurn(
    combat.actors,
    combat.roundNumber,
    combat.currentTurnActorId,
  );
  if (!turn.currentTurnActorId) return { ...combat, ...turn };
  return {
    ...combat,
    ...turn,
    actors: combat.actors.map((actor) => {
      let next = tickMachineFailures(
        actor,
        actor.id === combat.currentTurnActorId,
      );
      if (turn.roundNumber > combat.roundNumber)
        next = refreshCapabilities(next, 'round');
      if (actor.id === turn.currentTurnActorId)
        next = refreshCapabilities(next, 'turn');
      return {
        ...next,
        ...(actor.effects
          ? {
              effects: tickStatuses(
                actor.effects,
                actor.id === combat.currentTurnActorId,
                turn.roundNumber > combat.roundNumber,
                actor.id === turn.currentTurnActorId,
              ),
            }
          : {}),
      };
    }),
  };
}
export function reorderTie(
  combat: Combat,
  id: string,
  direction: -1 | 1,
): Combat {
  return { ...combat, actors: moveWithinTie(combat.actors, id, direction) };
}
export function removeActor(combat: Combat, id: string): Combat {
  return {
    ...combat,
    actors: combat.actors.filter((pc) => pc.id !== id),
    currentTurnActorId:
      combat.currentTurnActorId === id ? null : combat.currentTurnActorId,
  };
}

export function prepareActor(actor: Actor): Actor {
  const prepared = actorCoreSchema.parse({
    id: actor.id,
    displayName: actor.displayName,
    ttCurrent: actor.ttCurrent,
    hpCurrent: actor.hpCurrent,
    hpMaxCurrent: actor.hpMaxCurrent,
    initiativeValue: actor.initiativeValue,
    initiativeTieOrder: actor.initiativeTieOrder,
    statuses: actor.statuses,
    effects: actor.effects,
    ...(actor.enemy ? { enemy: actor.enemy } : {}),
  });
  return { ...actor, prepared: structuredClone(prepared) };
}
export function prepareCombat(combat: Combat): Combat {
  return { ...combat, actors: combat.actors.map(prepareActor) };
}
export function resetEncounter(combat: Combat): Combat {
  if (combat.actors.some((actor) => !actor.prepared))
    throw new Error('Najpierw zapisz stan przygotowany potyczki.');
  // Keep membership; normalize saved tie ranks after actors have been removed/added.
  const actors = [...combat.actors]
    .sort(
      (a, b) =>
        a.prepared!.initiativeTieOrder - b.prepared!.initiativeTieOrder ||
        a.id.localeCompare(b.id),
    )
    .map((actor, index) => ({
      ...structuredClone(actor.prepared!),
      initiativeTieOrder: index,
      prepared: structuredClone(actor.prepared!),
    }));
  return combatSchema.parse({
    ...combat,
    actors,
    roundNumber: 1,
    currentTurnActorId: null,
  });
}
export function instantiateEnemy(
  template: EnemyTemplate,
  order: number,
  id = crypto.randomUUID(),
): Actor {
  const base = enemyTemplateSchema.parse(template);
  const actor: Actor = {
    id,
    displayName: base.name,
    ttCurrent: base.tt,
    hpCurrent: base.hpMax,
    hpMaxCurrent: base.hpMax,
    initiativeValue: null,
    initiativeTieOrder: order,
    statuses: [],
    enemy: {
      template: structuredClone(base),
      ...(base.sp === undefined ? {} : { sp: base.sp }),
      ...(base.failureThreshold === undefined
        ? {}
        : { failureThreshold: base.failureThreshold }),
      ...(base.statblock ? { statblock: structuredClone(base.statblock) } : {}),
      ...(base.loadout ? { loadout: structuredClone(base.loadout) } : {}),
      ...(base.capabilities
        ? { capabilities: instantiateCapabilities(base.capabilities) }
        : {}),
      speeds: structuredClone(base.speeds),
      ...(base.cowardicePercent === undefined
        ? {}
        : { cowardicePercent: base.cowardicePercent }),
      ...(base.injuryTrack
        ? {
            injury: {
              enabled: base.injuryTrack.enabled,
              level: 0,
              deathWarning: false,
            },
          }
        : {}),
    },
  };
  return prepareActor(
    applyInjuryLevel(actor, base.injuryTrack?.initialLevel ?? 0),
  );
}
