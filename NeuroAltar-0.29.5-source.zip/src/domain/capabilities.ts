import { machineActionRestriction } from './machineFailures';
import type { Actor } from './combat';
import { injuryConsequences } from './injury';
import {
  actionLabels,
  capabilityStateSchema,
  instantiateCapabilities,
  type ActionKind,
  type CapabilityState,
} from './capabilitySchema';
export function capabilities(actor: Actor): CapabilityState {
  return (
    actor.enemy?.capabilities ??
    instantiateCapabilities(
      actor.enemy?.template.capabilities ?? {
        resources: [],
        abilities: [],
        legendaryMax: 0,
      },
    )
  );
}
export function actionRestriction(
  actor: Actor,
  kind: ActionKind,
): string | null {
  const failure = machineActionRestriction(actor, kind);
  if (failure) return failure;
  const injury = injuryConsequences(actor);
  if (kind === 'reaction' && injury.reactionsBlocked)
    return 'Zranienie: brak Reakcji.';
  if (kind === 'bonus' && injury.bonusActionsBlocked)
    return 'Zranienie: brak Akcji Bonusowych.';
  const blocked = actor.effects?.some(
    (s) =>
      s.systemKey &&
      ['incapacitated', 'unconscious', 'stunned', 'paralyzed'].includes(
        s.systemKey,
      ),
  );
  return blocked ? 'Stan systemowy: postać jest obezwładniona.' : null;
}
export function consumeCapability(
  actor: Actor,
  key: string,
  override = false,
): Actor {
  if (!actor.enemy) return actor;
  const c = capabilities(actor);
  const ability = c.abilities.find((a) => a.id === key);
  const kind =
    ability?.kind ??
    (Object.hasOwn(actionLabels, key) ? (key as ActionKind) : null);
  if (!kind) throw new Error('Nie znaleziono akcji.');
  if (kind === 'legendary' && c.legendaryMax === 0)
    throw new Error('Brak puli legendarnej.');
  const cost = kind === 'legendary' ? (ability?.legendaryCost ?? 1) : 1;
  const unlimited = kind === 'reaction' && c.unlimitedReactions === true;
  if (
    !override &&
    (actionRestriction(actor, kind) || (!unlimited && c.budget[kind] < cost))
  )
    throw new Error('Akcja jest zablokowana lub zużyta.');
  const resource = ability?.resourceId
    ? c.resources.find((r) => r.id === ability.resourceId)
    : undefined;
  if (
    ability?.resourceId &&
    (!resource || resource.currentValue < ability.resourceCost)
  )
    throw new Error('Za mało zasobu. Najpierw skoryguj licznik.');
  if (c.usageNumber === Number.MAX_SAFE_INTEGER)
    throw new Error('Osiągnięto limit zapisów użycia.');
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      capabilities: capabilityStateSchema.parse({
        ...c,
        budget: {
          ...c.budget,
          [kind]: unlimited
            ? c.budget[kind]
            : Math.max(0, c.budget[kind] - cost),
        },
        resources: c.resources.map((r) =>
          r.id === resource?.id
            ? { ...r, currentValue: r.currentValue - ability!.resourceCost }
            : r,
        ),
        usageNumber: c.usageNumber + 1,
        lastUse: { name: ability?.name ?? actionLabels[kind], kind, override },
      }),
    },
  };
}
export function adjustResource(actor: Actor, id: string, delta: -1 | 1): Actor {
  if (!actor.enemy) return actor;
  const c = capabilities(actor);
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      capabilities: {
        ...c,
        resources: c.resources.map((r) =>
          r.id === id
            ? {
                ...r,
                currentValue: Math.min(
                  r.maxValue,
                  Math.max(0, r.currentValue + delta),
                ),
              }
            : r,
        ),
      },
    },
  };
}
export function restoreBudget(actor: Actor, kind: ActionKind): Actor {
  if (!actor.enemy) return actor;
  const c = capabilities(actor);
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      capabilities: {
        ...c,
        budget: {
          ...c.budget,
          [kind]: kind === 'legendary' ? c.legendaryMax : 1,
        },
      },
    },
  };
}
export function refreshCapabilities(
  actor: Actor,
  event: 'round' | 'turn' | 'encounter' | 'day',
): Actor {
  if (!actor.enemy?.capabilities) return actor;
  const c = actor.enemy.capabilities;
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      capabilities: {
        ...c,
        resources: c.resources.map((r) =>
          r.refreshRule === event ? { ...r, currentValue: r.maxValue } : r,
        ),
        budget:
          event === 'turn'
            ? { ...c.budget, action: 1, bonus: 1, reaction: 1 }
            : event === 'round'
              ? { ...c.budget, legendary: c.legendaryMax }
              : c.budget,
      },
    },
  };
}
