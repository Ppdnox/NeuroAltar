import { z } from 'zod';
export const failureThresholdSchema = z
  .number()
  .int()
  .min(0)
  .max(Number.MAX_SAFE_INTEGER)
  .nullable();
export function parseFailureThreshold(text: string): number | null {
  return failureThresholdSchema.parse(
    text.trim() === '' ? null : /^\d+$/.test(text.trim()) ? Number(text) : NaN,
  );
}
export const machineFailureSchema = z
  .object({
    id: z.uuid(),
    result: z.number().int().min(1).max(20),
    weaponId: z.uuid().nullable(),
    weaponName: z.string().trim().min(1).nullable(),
    blockedAction: z.enum(['bonus', 'legendary']).nullable(),
    remainingEnds: z.number().int().min(1).max(2).nullable(),
    note: z.string(),
  })
  .strict()
  .superRefine((f, ctx) => {
    if (
      (f.result === 1
        ? !f.weaponId || !f.weaponName
        : f.weaponId !== null || f.weaponName !== null) ||
      (f.result === 4 ? f.blockedAction === null : f.blockedAction !== null) ||
      ([5, 10, 12].includes(f.result)
        ? f.remainingEnds === null
        : f.remainingEnds !== null)
    )
      ctx.addIssue({
        code: 'custom',
        message: 'Niepoprawny cel lub czas awarii.',
      });
  });
export const machineFailuresSchema = z
  .array(machineFailureSchema)
  .max(1000)
  .refine(
    (v) => new Set(v.map((f) => f.id)).size === v.length,
    'Powtórzone ID awarii.',
  );
export type MachineFailure = z.infer<typeof machineFailureSchema>;
export interface FailureDraft {
  result: string;
  damage: string;
  weaponId: string;
  blockedAction: '' | 'bonus' | 'legendary';
  note: string;
}
export const newFailureDraft = (): FailureDraft => ({
  result: '',
  damage: '',
  weaponId: '',
  blockedAction: '',
  note: '',
});
export function parseFailureResult(raw: string) {
  return z
    .number()
    .int()
    .min(1)
    .max(20)
    .parse(/^\d+$/.test(raw.trim()) ? Number(raw) : NaN);
}
