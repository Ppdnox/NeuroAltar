import { z } from 'zod';

export const ABILITIES = ['str', 'dex', 'con', 'int', 'wis', 'cha'] as const;
export const abilityLabels = {
  str: 'SIŁ',
  dex: 'ZRC',
  con: 'KON',
  int: 'INT',
  wis: 'MDR',
  cha: 'CHA',
};
const number = z
  .number()
  .int()
  .min(-Number.MAX_SAFE_INTEGER)
  .max(Number.MAX_SAFE_INTEGER);
const score = number.nonnegative().nullable();
const bonus = number.nullable();
const scores = z
  .object({
    str: score,
    dex: score,
    con: score,
    int: score,
    wis: score,
    cha: score,
  })
  .strict();
const bonuses = z
  .object({
    str: bonus,
    dex: bonus,
    con: bonus,
    int: bonus,
    wis: bonus,
    cha: bonus,
  })
  .strict();
const lines = z.array(z.string().trim().min(1).max(1000)).max(100).nullable();
export const statblockSchema = z
  .object({
    traits: lines.optional(),
    subtype: z.string().trim().min(1).max(200).nullable(),
    abilityScores: scores,
    savingThrows: bonuses,
    skills: lines,
    senses: lines,
    resistances: lines,
    vulnerabilities: lines,
    damageImmunities: lines,
    conditionImmunities: lines,
    damageThreshold: number.nonnegative().nullable(),
  })
  .strict();
export type Statblock = z.infer<typeof statblockSchema>;
export const statblockListLabels = {
  skills: 'Umiejętności',
  senses: 'Zmysły',
  resistances: 'Odporności na obrażenia',
  vulnerabilities: 'Wrażliwości na obrażenia',
  damageImmunities: 'Niewrażliwości na obrażenia',
  conditionImmunities: 'Niewrażliwości na stany',
};
export type StatblockList = keyof typeof statblockListLabels;
export type StatblockDraft = {
  traits?: string;
  subtype: string;
  abilityScores: Record<(typeof ABILITIES)[number], string>;
  savingThrows: Record<(typeof ABILITIES)[number], string>;
  damageThreshold: string;
} & Record<StatblockList, string>;
export function toStatblockDraft(value?: Statblock): StatblockDraft {
  return {
    ...(value?.traits === undefined
      ? {}
      : {
          traits:
            value.traits === null
              ? ''
              : value.traits.length
                ? value.traits.join('\n')
                : 'brak',
        }),
    subtype: value?.subtype ?? '',
    abilityScores: Object.fromEntries(
      ABILITIES.map((key) => [
        key,
        value?.abilityScores[key] == null
          ? ''
          : String(value.abilityScores[key]),
      ]),
    ) as StatblockDraft['abilityScores'],
    savingThrows: Object.fromEntries(
      ABILITIES.map((key) => [
        key,
        value?.savingThrows[key] == null ? '' : String(value.savingThrows[key]),
      ]),
    ) as StatblockDraft['savingThrows'],
    damageThreshold:
      value?.damageThreshold == null ? '' : String(value.damageThreshold),
    ...(Object.fromEntries(
      Object.keys(statblockListLabels).map((key) => {
        const entries = value?.[key as StatblockList];
        return [
          key,
          entries == null ? '' : entries.length ? entries.join('\n') : 'brak',
        ];
      }),
    ) as Record<StatblockList, string>),
  };
}
export function parseStatblockDraft(draft: StatblockDraft): Statblock {
  const integer = (s: string) =>
    s.trim() === '' ? null : /^[+-]?\d+$/.test(s.trim()) ? Number(s) : NaN;
  return statblockSchema.parse({
    ...(draft.traits === undefined
      ? {}
      : {
          traits:
            draft.traits.trim() === ''
              ? null
              : draft.traits.trim().toLocaleLowerCase('pl') === 'brak'
                ? []
                : draft.traits
                    .split('\n')
                    .map((s) => s.trim())
                    .filter(Boolean),
        }),
    subtype: draft.subtype.trim() || null,
    abilityScores: Object.fromEntries(
      ABILITIES.map((key) => [key, integer(draft.abilityScores[key])]),
    ),
    savingThrows: Object.fromEntries(
      ABILITIES.map((key) => [key, integer(draft.savingThrows[key])]),
    ),
    damageThreshold: integer(draft.damageThreshold),
    ...Object.fromEntries(
      Object.keys(statblockListLabels).map((key) => {
        const text = draft[key as StatblockList].trim();
        return [
          key,
          text === ''
            ? null
            : text.toLocaleLowerCase('pl') === 'brak'
              ? []
              : text
                  .split('\n')
                  .map((s) => s.trim())
                  .filter(Boolean),
        ];
      }),
    ),
  });
}
// Display only. Explicit attack and final saving-throw bonuses are not modified.
export function abilityModifier(
  score: number | null | undefined,
): number | null {
  return score == null ? null : Math.floor((score - 10) / 2);
}
export const signedBonus = (value: number | null | undefined) =>
  value == null ? 'N/D' : value >= 0 ? `+${value}` : String(value);
