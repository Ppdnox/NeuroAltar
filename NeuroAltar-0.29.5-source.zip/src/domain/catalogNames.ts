import type { Item } from './item';

// Display aliases only: stable source IDs, saved prices and user edits stay intact.
const magazineNames: Record<string, [string, string]> = {
  '263dfcb8-1ad9-5c2f-ab1c-b7246d51d08e': ['Broń palna krótka', 'BPK'],
  'c53f0835-ce69-5889-bfac-d0820938e91e': ['Broń palna pośrednia', 'BPP'],
  '50ea1417-b32b-5a5c-a2d4-8a71d8b6eca5': ['Broń palna długa', 'BPD'],
  '957c94b4-b797-56ea-a178-c6d4a96ab5b4': ['Broń palna ciężka', 'BPC'],
};
export function itemDisplayName(item: Pick<Item, 'id' | 'name'>): string {
  const alias = magazineNames[item.id];
  return alias && item.name === alias[0]
    ? `Magazynek (${alias[1]})`
    : item.name;
}
export function withItemDisplayName(item: Item): Item {
  const name = itemDisplayName(item);
  return name === item.name ? item : { ...item, name };
}
