import { z } from 'zod';
export function withIssuePath<T>(path: (string | number)[], run: () => T): T {
  try {
    return run();
  } catch (e) {
    throw new z.ZodError(
      e instanceof z.ZodError
        ? e.issues.map((i) => ({ ...i, path: [...path, ...i.path] }))
        : [
            {
              code: 'custom',
              path,
              message: e instanceof Error ? e.message : 'Niepoprawna wartość.',
            },
          ],
    );
  }
}
const labels: Record<string, string> = {
  statblock: 'Statblock',
  subtype: 'Podtyp',
  traits: 'Zdolności stałe i uwagi źródłowe',
  abilityScores: 'Cechy',
  savingThrows: 'Rzuty obronne (końcowe)',
  str: 'SIŁ',
  dex: 'ZRC',
  con: 'KON',
  int: 'INT',
  wis: 'MDR',
  cha: 'CHA',
  skills: 'Umiejętności',
  senses: 'Zmysły',
  resistances: 'Odporności',
  vulnerabilities: 'Wrażliwości',
  damageImmunities: 'Niewrażliwości na obrażenia',
  conditionImmunities: 'Niewrażliwości na stany',
  damageThreshold: 'Próg Obrażeń',
  name: 'Nazwa',
  category: 'Kategoria',
  size: 'Rozmiar',
  tt: 'Bazowe TT',
  hpMax: 'Maksymalne PW',
  sp: 'SP',
  speeds: 'Ruch',
  mode: 'Rodzaj ruchu',
  meters: 'Metry',
  failureThreshold: 'Próg awarii',
  injuryTrack: 'Zranienia',
  initialLevel: 'Stopień Zranienia',
  cowardicePercent: 'Tchórzliwość',
  capabilities: 'Zasoby i akcje',
  resources: 'Zasób',
  abilities: 'Akcja',
  maxValue: 'Maksimum',
  currentValue: 'Pozostało',
  legendaryMax: 'Pula Legendarna',
  legendaryCost: 'Koszt legendarny',
  resourceCost: 'Koszt zasobu',
  resourceId: 'Powiązany zasób',
  loadout: 'Broń',
  items: 'Przedmiot',
  item: 'Dane',
  weaponProfile: 'Profil',
  damageModes: 'Formuła',
  dice: 'Formuła kości',
  damageType: 'Typ obrażeń',
  label: 'Nazwa',
  average: 'Średnia',
  attackModifier: 'Modyfikator ataku',
  range: 'Zasięg',
  normal: 'Zwykły',
  long: 'Długi',
  pb: 'PB',
  strModifier: 'Modyfikator SIŁ',
  dexModifier: 'Modyfikator ZRC',
  fireModes: 'Tryb ognia',
  ammoVariants: 'Wariant amunicji',
  damageModeId: 'Wybrana formuła',
  fireModeId: 'Wybrany tryb ognia',
  ammoVariantId: 'Wybrana amunicja',
  id: 'Identyfikator',
};
export function validationIssues(error: unknown) {
  if (!(error instanceof z.ZodError))
    return [
      {
        path: '',
        label: 'Formularz',
        message: error instanceof Error ? error.message : 'Niepoprawne dane.',
      },
    ];
  return error.issues.map((i) => {
    let message = i.message;
    if (i.path.join('.') === 'sp') message = message.replace(/^SP:\s*/i, '');
    if (i.code === 'invalid_type')
      message =
        i.expected === 'string'
          ? 'Wpisz tekst.'
          : 'Wpisz poprawną liczbę; dla wartości całkowitych bez ułamka.';
    if (i.code === 'too_small')
      message =
        i.origin === 'string'
          ? 'Pole nie może być puste.'
          : `Minimum: ${i.minimum}.`;
    if (i.code === 'too_big') message = `Maksimum: ${i.maximum}.`;
    if (i.code === 'invalid_value')
      message = 'Wybierz jedną z dostępnych wartości.';
    return {
      path: i.path.join('.'),
      label: i.path
        .map((p) =>
          typeof p === 'number'
            ? String(p + 1)
            : (labels[String(p)] ?? String(p)),
        )
        .join(' → '),
      message,
    };
  });
}
export function validationMessage(e: unknown) {
  return validationIssues(e)
    .map((i) => `${i.label}: ${i.message}`)
    .join('\n');
}
