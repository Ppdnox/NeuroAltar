import { parseSpeeds, type EnemyTemplate } from './enemy';

/** Display corrections also apply to saved snapshots; persisted source data stays intact. */
export function presentRule(text: string, tt?: number): string {
  let value = text
    .replace(
      'Limity „na walkę” i „na dzień” są użyciami zdolności z podręcznika, nie liczbą nabojów. Efekty trafień, zniszczenie broni i powiązane tryby tej samej broni uwzględnia MG; kliknięcie zdolności zużywa tylko jej budżet/zasób.',
      '',
    )
    .replace(/Inicjatywa z podręcznika:/g, 'Inicjatywa:')
    .replace(/Wynik każdej kopii wpisuje MG\./g, '')
    .replace(
      /Wpisz wynik osobno dla każdej kopii; aplikacja nie losuje ani nie ustawia go automatycznie\./g,
      '',
    )
    .replace(
      /Źródłowy statblock nie podaje toru Zranień(?: ani Tchórzliwości)?\./g,
      '',
    )
    .replace(/(?:Inicjatywa|PW) [^.\n]*zachowan[^.\n]*\./g, '')
    .replace(
      /(?:; | — )zachowano (?:zapis źródłowy|obie wartości z podręcznika)\./g,
      '.',
    )
    .replace(/Jedna Akcja; (?:pod-ataki|cele i pod-ataki) rozstrzyga MG\./g, '')
    .replace(
      /Bez Testu Ataku(?: i bez podanych obrażeń|; obszar i obrażenia rozlicza MG|; obrażenia rozlicza MG|; PW rozlicza MG)?\./g,
      '',
    )
    .replace(
      /(?:Zmiany PW|Cele i PW|PW i chorobę|Obciążenie|Obrażenia|PW|Zmianę|Moment i cel reakcji) (?:rozlicza|rozstrzyga) MG\./g,
      '',
    )
    .replace(/MG rozstrzyga skutki\./g, '')
    .replace(/Awarie, odporności i skutki zdolności rozstrzyga MG\./g, '')
    .replace(/; rozstrzyga MG\./g, '.')
    .replace(/Rozlicza MG\./g, '')
    .replace(/ {2,}/g, ' ')
    .trim();
  if (tt !== undefined && Number.isFinite(tt))
    value = value.replace(/^TT: ([^\d.][^.]+)\./, `TT: ${tt} ($1).`);
  return value;
}
export function speedDraftLabel(text: string): string {
  return text.replace(/^Chód(?=:)/gm, 'Szybkość');
}
export function displaySpeeds(speeds: EnemyTemplate['speeds']): string {
  return speeds
    .map(
      (s) =>
        `${s.mode === 'Chód' ? 'Szybkość' : s.mode} ${s.meters.toLocaleString('pl-PL', { maximumFractionDigits: 2 })}m`,
    )
    .join('\n');
}
export function displaySpeedDraft(text: string): string {
  try {
    return displaySpeeds(parseSpeeds(text));
  } catch {
    return speedDraftLabel(text);
  }
}
export function fixedHandbookSp(template: EnemyTemplate): boolean {
  return (
    template.sp != null &&
    !!template.statblock?.traits?.some(
      (t) =>
        t.startsWith('Źródło: Neuroshima 5e') ||
        t.startsWith('Suplement Moloch City —'),
    )
  );
}
