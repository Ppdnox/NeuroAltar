import { z } from 'zod';
import { encounterIdSchema } from './encounter';

export const DICE_SIDES = [4, 6, 8, 10, 12, 20, 100] as const;
export const HISTORY_LIMIT = 100;
export interface DiceGroup {
  count: number;
  sides: number;
}
export interface DiceFormula {
  groups?: DiceGroup[];
  count: number;
  sides: number;
  modifier: number;
  formula: string;
}
export function parseDiceFormula(input: string): DiceFormula {
  if (input.length > 64) throw Error('Formuła może mieć najwyżej 64 znaki.');
  const token = '(?:\\d{1,3}\\s*)?[kd](?:4|6|8|10|12|20|100)';
  const expression = new RegExp(
    `^\\s*(${token}(?:\\s*\\+\\s*${token})*)\\s*(?:([+-])\\s*(\\d{1,5}))?\\s*$`,
    'i',
  );
  const match = expression.exec(input);
  if (!match)
    throw Error(
      'Wpisz np. 2k6+3, 2k8+2k6+4 lub k20-1. Dostępne kości: k4, k6, k8, k10, k12, k20, k100.',
    );
  const groups = match[1]!.split('+').map((group) => {
    const m = /^\s*(\d{1,3})?\s*[kd](\d+)\s*$/i.exec(group)!;
    return { count: Number(m[1] ?? 1), sides: Number(m[2]) };
  });
  const count = groups.reduce((sum, g) => sum + g.count, 0),
    sides = groups[0]!.sides;
  const modifier = Number(match[3] ?? 0) * (match[2] === '-' ? -1 : 1);
  if (groups.some((g) => g.count < 1) || count > 100)
    throw Error('Liczba kości musi wynosić od 1 do 100.');
  if (Math.abs(modifier) > 10000)
    throw Error('Modyfikator musi wynosić od −10000 do 10000.');
  return {
    count,
    sides,
    modifier,
    formula:
      groups.map((g) => `${g.count}k${g.sides}`).join('+') +
      (modifier ? `${modifier > 0 ? '+' : ''}${modifier}` : ''),
    ...(groups.length > 1 ? { groups } : {}),
  };
}
export function diceFaceSides(formula: DiceFormula): number[] {
  return (
    formula.groups ?? [{ count: formula.count, sides: formula.sides }]
  ).flatMap((g) => Array.from({ length: g.count }, () => g.sides));
}
// Rejection sampling avoids modulo bias. Test callers can supply exact uint32 values.
export function randomDie(
  sides: number,
  next = () => crypto.getRandomValues(new Uint32Array(1))[0]!,
) {
  if (!(DICE_SIDES as readonly number[]).includes(sides))
    throw Error('Nieobsługiwana kość.');
  const range = 2 ** 32,
    limit = range - (range % sides);
  for (let i = 0; i < 128; i++) {
    const value = next();
    if (!Number.isInteger(value) || value < 0 || value >= range)
      throw Error('Nieprawidłowe źródło losowości.');
    if (value < limit) return (value % sides) + 1;
  }
  throw Error('Nie udało się wylosować wyniku. Spróbuj ponownie.');
}
export function rollDice(input: string, die = randomDie) {
  const parsed = parseDiceFormula(input);
  const values = diceFaceSides(parsed).map((sides) => {
    const value = die(sides);
    if (!Number.isInteger(value) || value < 1 || value > sides)
      throw Error('Wynik kości jest poza zakresem.');
    return value;
  });
  return {
    ...parsed,
    values,
    total: values.reduce((sum, value) => sum + value, parsed.modifier),
  };
}
export const diceRollSchema = z
  .object({
    characterCheck: z
      .object({
        characterId: z.uuid(),
        targets: z.array(z.string().min(1).max(80)).min(1).max(12),
        expectedRevision: z.number().int().min(0).optional(),
        consumedBenefits: z.array(z.uuid()).max(1).optional(),
      })
      .strict()
      .optional(),
    supplement: z
      .object({
        originalRollId: z.uuid(),
        characterId: z.uuid(),
        expectedRevision: z.number().int().min(0),
        resourceId: z.enum(['toughness', 'amen', 'cat']),
        originalTotal: z.number().int(),
        originalNatural: z.number().int().min(1).max(20),
        originalLabel: z.string().min(1).max(500),
        failed: z.boolean(),
      })
      .strict()
      .optional(),
    context: z
      .object({
        encounterId: encounterIdSchema,
        actorId: z.uuid(),
        actorName: z.string().trim().min(1).max(200),
        roundNumber: z.number().int().positive(),
        label: z.string().trim().min(1).max(500),
        purpose: z.enum(['attack', 'damage', 'initiative']).optional(),
        sourceKey: z.string().min(1).max(500).optional(),
        consumedEffects: z.array(z.uuid()).max(100).optional(),
        rerollOf: z.uuid().optional(),
        effectOwnerActorId: z.uuid().optional(),
        participationRevision: z.number().int().min(0).optional(),
        criticalAt: z.union([z.literal(19), z.literal(20)]).optional(),
        criticalMultiplier: z.union([z.literal(2), z.literal(3)]).optional(),
      })
      .strict()
      .nullable(),
    characterContext: z
      .object({
        characterId: z.uuid(),
        name: z.string().trim().min(1).max(300),
        label: z.string().trim().min(1).max(500),
      })
      .strict()
      .optional(),
    checkDice: z
      .object({
        mode: z.enum(['advantage', 'disadvantage']),
        values: z.tuple([
          z.number().int().min(1).max(20),
          z.number().int().min(1).max(20),
        ]),
      })
      .strict()
      .optional(),
    critical: z
      .object({ attackRollId: z.uuid(), originalFormula: z.string().max(64) })
      .strict()
      .optional(),
    id: z.uuid(),
    createdAt: z.iso.datetime(),
    formula: z.string().max(64),
    groups: z
      .array(
        z
          .object({
            count: z.number().int().min(1).max(100),
            sides: z.number().int(),
          })
          .strict(),
      )
      .min(2)
      .max(100)
      .optional(),
    count: z.number().int().min(1).max(100),
    sides: z.number().int(),
    modifier: z.number().int().min(-10000).max(10000),
    values: z.array(z.number().int().min(1).max(100)).min(1).max(100),
    total: z.number().int(),
  })
  .strict()
  .superRefine((roll, ctx) => {
    try {
      const parsed = parseDiceFormula(roll.formula);
      if (
        roll.characterCheck &&
        (roll.count !== 1 || roll.sides !== 20 || roll.supplement)
      )
        throw Error();
      if (
        roll.supplement &&
        (roll.count !== 1 ||
          ![4, 6, 8, 10, 12].includes(roll.sides) ||
          roll.modifier !== roll.supplement.originalTotal ||
          roll.critical ||
          roll.checkDice ||
          roll.context?.purpose)
      )
        throw Error();
      if (
        roll.checkDice &&
        (roll.count !== 1 ||
          roll.sides !== 20 ||
          roll.values[0] !==
            (roll.checkDice.mode === 'advantage'
              ? Math.max(...roll.checkDice.values)
              : Math.min(...roll.checkDice.values)))
      )
        throw Error();
      if (
        roll.context &&
        Boolean(roll.context.purpose) !== Boolean(roll.context.sourceKey)
      )
        throw Error();
      if (
        roll.context?.purpose === 'initiative' &&
        (roll.count !== 1 ||
          roll.sides !== 20 ||
          roll.context.sourceKey !== 'initiative')
      )
        throw Error();
      if (roll.characterContext && roll.context) throw Error();
      if (
        roll.critical &&
        (roll.context?.purpose !== 'damage' ||
          doubleDamageDice(
            roll.critical.originalFormula,
            roll.context?.criticalMultiplier ?? 2,
          ) !== roll.formula)
      )
        throw Error();
      if (
        parsed.count !== roll.count ||
        parsed.sides !== roll.sides ||
        parsed.modifier !== roll.modifier ||
        roll.formula !== parsed.formula ||
        roll.values.length !== roll.count ||
        JSON.stringify(roll.groups) !== JSON.stringify(parsed.groups) ||
        roll.values.some((v, i) => v > diceFaceSides(parsed)[i]!) ||
        roll.total !== roll.values.reduce((s, v) => s + v, roll.modifier)
      )
        throw Error();
    } catch {
      ctx.addIssue({ code: 'custom', message: 'Niespójny zapis rzutu.' });
    }
  });
export type DiceRoll = z.infer<typeof diceRollSchema>;
export const diceHistorySchema = z
  .object({
    version: z.literal(1),
    rolls: z.array(diceRollSchema).max(HISTORY_LIMIT),
  })
  .strict()
  .refine(
    (h) => new Set(h.rolls.map((r) => r.id)).size === h.rolls.length,
    'Powtórzone ID rzutu.',
  );

export function doubleDamageDice(
  formula: string,
  multiplier: 2 | 3 = 2,
): string {
  const parsed = parseDiceFormula(formula);
  const groups = parsed.groups ?? [
    { count: parsed.count, sides: parsed.sides },
  ];
  const doubled =
    groups.map((g) => `${g.count * multiplier}k${g.sides}`).join('+') +
    (parsed.modifier
      ? `${parsed.modifier > 0 ? '+' : ''}${parsed.modifier}`
      : '');
  return parseDiceFormula(doubled).formula;
}
