import { z } from 'zod';
export const refreshLabels = {
  round: 'Co rundę',
  encounter: 'Na potyczkę',
  day: 'Na dzień',
  manual: 'Ręcznie',
} as const;
export const actionLabels = {
  action: 'Akcja',
  bonus: 'Akcja Bonusowa',
  reaction: 'Reakcja',
  legendary: 'Akcja Legendarna',
} as const;
export const actionKindSchema = z.enum([
  'action',
  'bonus',
  'reaction',
  'legendary',
]);
export type ActionKind = z.infer<typeof actionKindSchema>;
export const refreshSchema = z.enum(['round', 'encounter', 'day', 'manual']);
const count = z.number().int().min(0).max(999);
export const resourceDefinitionSchema = z
  .object({
    id: z.uuid(),
    name: z.string().trim().min(1),
    maxValue: count.min(1),
    refreshRule: refreshSchema,
  })
  .strict();
export const resourceSchema = resourceDefinitionSchema
  .extend({ currentValue: count })
  .refine((r) => r.currentValue <= r.maxValue, 'Zasób przekracza maksimum.');
export const abilitySchema = z
  .object({
    id: z.uuid(),
    name: z.string().trim().min(1),
    description: z.string(),
    kind: actionKindSchema,
    legendaryCost: count.min(1),
    resourceId: z.uuid().nullable(),
    resourceCost: count.min(1),
  })
  .strict()
  .refine(
    (a) => a.kind === 'legendary' || a.legendaryCost === 1,
    'Koszt legendarny dotyczy tylko akcji legendarnych.',
  );
function validLinks(v: {
  resources: { id: string; maxValue: number }[];
  abilities: z.infer<typeof abilitySchema>[];
  legendaryMax: number;
}) {
  return (
    new Set(v.resources.map((r) => r.id)).size === v.resources.length &&
    new Set(v.abilities.map((a) => a.id)).size === v.abilities.length &&
    v.abilities.every(
      (a) =>
        (a.resourceId === null ||
          v.resources.some(
            (r) => r.id === a.resourceId && r.maxValue >= a.resourceCost,
          )) &&
        (a.kind !== 'legendary' || a.legendaryCost <= v.legendaryMax),
    )
  );
}
export const capabilitySetupSchema = z
  .object({
    resources: z.array(resourceDefinitionSchema),
    abilities: z.array(abilitySchema),
    legendaryMax: count,
    unlimitedReactions: z.boolean().optional(),
  })
  .strict()
  .superRefine((v, ctx) => {
    for (const key of ['resources', 'abilities'] as const) {
      const ids = new Set<string>();
      v[key].forEach((row, i) => {
        if (ids.has(row.id))
          ctx.addIssue({
            code: 'custom',
            path: [key, i, 'id'],
            message: 'Powtórzony identyfikator. Utwórz tę pozycję ponownie.',
          });
        ids.add(row.id);
      });
    }
    v.abilities.forEach((a, i) => {
      if (a.kind === 'legendary' && a.legendaryCost > v.legendaryMax)
        ctx.addIssue({
          code: 'custom',
          path: ['abilities', i, 'legendaryCost'],
          message: `Koszt ${a.legendaryCost} przekracza pulę Legendarnych ${v.legendaryMax}. Zwiększ pulę lub zmniejsz koszt.`,
        });
      if (a.resourceId) {
        const r = v.resources.find((r) => r.id === a.resourceId);
        if (!r)
          ctx.addIssue({
            code: 'custom',
            path: ['abilities', i, 'resourceId'],
            message: 'Wybierz istniejący zasób.',
          });
        else if (a.resourceCost > r.maxValue)
          ctx.addIssue({
            code: 'custom',
            path: ['abilities', i, 'resourceCost'],
            message: `Koszt ${a.resourceCost} przekracza maksimum zasobu „${r.name}” (${r.maxValue}).`,
          });
      }
    });
  });
export const capabilityStateSchema = z
  .object({
    resources: z.array(resourceSchema),
    abilities: z.array(abilitySchema),
    legendaryMax: count,
    unlimitedReactions: z.boolean().optional(),
    budget: z
      .object({
        action: count.max(1),
        bonus: count.max(1),
        reaction: count.max(1),
        legendary: count,
      })
      .strict(),
    usageNumber: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
    lastUse: z
      .object({
        name: z.string().trim().min(1),
        kind: actionKindSchema,
        override: z.boolean(),
      })
      .strict()
      .nullable(),
  })
  .strict()
  .refine(
    (v) =>
      validLinks(v) &&
      v.budget.legendary <= v.legendaryMax &&
      (v.usageNumber === 0) === (v.lastUse === null),
    'Niepoprawne zasoby, pula lub zapis użycia.',
  );
export type CapabilitySetup = z.infer<typeof capabilitySetupSchema>;
export type CapabilityState = z.infer<typeof capabilityStateSchema>;
export interface CapabilityDraft {
  legendaryMax: string;
  unlimitedReactions?: boolean;
  resources: {
    id: string;
    name: string;
    maxValue: string;
    currentValue: string;
    refreshRule: keyof typeof refreshLabels;
  }[];
  abilities: {
    id: string;
    name: string;
    description: string;
    kind: ActionKind;
    legendaryCost: string;
    resourceId: string;
    resourceCost: string;
  }[];
}
export const emptyCapabilityDraft = (): CapabilityDraft => ({
  legendaryMax: '0',
  resources: [],
  abilities: [],
});
const numeric = (s: string) => (/^\d+$/.test(s.trim()) ? Number(s) : NaN);
export function toCapabilityDraft(c: CapabilityState): CapabilityDraft {
  return {
    legendaryMax: String(c.legendaryMax),
    ...(c.unlimitedReactions === undefined
      ? {}
      : { unlimitedReactions: c.unlimitedReactions }),
    resources: c.resources.map((r) => ({
      ...r,
      maxValue: String(r.maxValue),
      currentValue: String(r.currentValue),
    })),
    abilities: c.abilities.map((a) => ({
      ...a,
      legendaryCost: String(a.legendaryCost),
      resourceId: a.resourceId ?? '',
      resourceCost: String(a.resourceCost),
    })),
  };
}
export function parseCapabilitySetup(d: CapabilityDraft): CapabilitySetup {
  return capabilitySetupSchema.parse({
    legendaryMax: numeric(d.legendaryMax),
    ...(d.unlimitedReactions === undefined
      ? {}
      : { unlimitedReactions: d.unlimitedReactions }),
    resources: d.resources.map((r) => ({
      id: r.id,
      name: r.name,
      maxValue: numeric(r.maxValue),
      refreshRule: r.refreshRule,
    })),
    abilities: d.abilities.map((a) => ({
      ...a,
      legendaryCost: a.kind === 'legendary' ? numeric(a.legendaryCost) : 1,
      resourceId: a.resourceId || null,
      resourceCost: a.resourceId ? numeric(a.resourceCost) : 1,
    })),
  });
}
export function instantiateCapabilities(
  setup: CapabilitySetup,
): CapabilityState {
  return capabilityStateSchema.parse({
    ...structuredClone(setup),
    resources: setup.resources.map((r) => ({ ...r, currentValue: r.maxValue })),
    budget: { action: 1, bonus: 1, reaction: 1, legendary: setup.legendaryMax },
    usageNumber: 0,
    lastUse: null,
  });
}
export function parseCapabilityDraft(
  d: CapabilityDraft,
  previous: CapabilityState,
): CapabilityState {
  const setup = parseCapabilitySetup(d);
  return capabilityStateSchema.parse({
    ...previous,
    ...setup,
    resources: setup.resources.map((r) => ({
      ...r,
      currentValue: numeric(
        d.resources.find((v) => v.id === r.id)!.currentValue,
      ),
    })),
    budget: {
      ...previous.budget,
      legendary: Math.min(
        setup.legendaryMax,
        previous.budget.legendary +
          Math.max(0, setup.legendaryMax - previous.legendaryMax),
      ),
    },
  });
}
