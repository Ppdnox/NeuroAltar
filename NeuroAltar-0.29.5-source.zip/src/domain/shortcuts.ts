/** Keyboard intent only; no state mutation, rolls, or timer advancement. */
export interface ShortcutInput {
  key: string;
  code: string;
  altKey: boolean;
  ctrlKey: boolean;
  metaKey: boolean;
  shiftKey: boolean;
  repeat: boolean;
  isComposing: boolean;
  defaultPrevented: boolean;
}
export function combatShortcut(
  event: ShortcutInput,
  context: { editing: boolean; interactive: boolean; dialog: boolean },
) {
  if (
    event.repeat ||
    event.isComposing ||
    event.defaultPrevented ||
    context.dialog ||
    context.editing
  )
    return null;
  if (event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey) {
    if (event.key === 'ArrowUp') return 'previous-card';
    if (event.key === 'ArrowDown') return 'next-card';
  }
  if (
    event.code === 'Space' &&
    !event.altKey &&
    !event.ctrlKey &&
    !event.metaKey &&
    !event.shiftKey &&
    !context.interactive
  )
    return 'next-turn';
  return null;
}
export function adjacentCard(
  ids: string[],
  selected: string | null | undefined,
  direction: -1 | 1,
): string | null {
  if (!ids.length) return null;
  const index = ids.indexOf(selected ?? '');
  return ids[
    index < 0 ? 0 : Math.max(0, Math.min(ids.length - 1, index + direction))
  ]!;
}

/** Help must not cover another modal, including a pending persistence error. */
export function helpShortcut(event: ShortcutInput, dialogOpen: boolean) {
  return (
    event.key === 'F1' &&
    !dialogOpen &&
    !event.repeat &&
    !event.isComposing &&
    !event.defaultPrevented &&
    !event.altKey &&
    !event.ctrlKey &&
    !event.metaKey &&
    !event.shiftKey
  );
}
