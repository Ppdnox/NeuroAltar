import { z } from 'zod';
import { itemSchema, type Item } from './item';

export const tradeContextSchema = z
  .object({
    region: z.discriminatedUnion('kind', [
      z.object({ kind: z.literal('none') }).strict(),
      z.object({ kind: z.literal('region'), id: z.string().min(1) }).strict(),
    ]),
    location: z.discriminatedUnion('kind', [
      z.object({ kind: z.literal('none') }).strict(),
      z.object({ kind: z.literal('location'), id: z.string().min(1) }).strict(),
    ]),
    color: z.enum(['none', 'rust', 'mercury', 'steel', 'chrome']),
  })
  .strict();
export type TradeContext = z.infer<typeof tradeContextSchema>;
export const BASE_TRADE_CONTEXT: TradeContext = {
  region: { kind: 'none' },
  location: { kind: 'none' },
  color: 'none',
};
export const marketRulesSchema = z
  .object({
    regions: z.record(
      z.string(),
      z
        .object({
          label: z.string().min(1),
          priceMultipliers: z.record(
            z.string(),
            z.number().finite().nonnegative(),
          ),
        })
        .strict(),
    ),
    locations: z.record(
      z.string(),
      z
        .object({
          label: z.string().min(1),
          availabilityDelta: z.number().finite(),
        })
        .strict(),
    ),
  })
  .strict();
export type MarketRules = z.infer<typeof marketRulesSchema>;
export const TRADE_COLORS = {
  none: { label: 'N/D — brak modyfikacji', price: 1, availability: 1 },
  rust: { label: 'Rdza', price: 2, availability: 0.5 },
  mercury: { label: 'Rtęć', price: 1, availability: 1 },
  steel: { label: 'Stal', price: 0.5, availability: 2 },
  chrome: { label: 'Chrom', price: 1, availability: 2 },
} as const;

export function marketFactors(
  item: Item,
  context: TradeContext,
  rules: MarketRules,
) {
  itemSchema.parse(item);
  const c = tradeContextSchema.parse(context);
  const r = marketRulesSchema.parse(rules);
  let region = 1,
    location = 0;
  if (c.region.kind === 'region') {
    const selected = Object.hasOwn(r.regions, c.region.id)
      ? r.regions[c.region.id]
      : undefined;
    if (!selected) throw new Error('Region: nieznany wybór.');
    if (!Object.hasOwn(selected.priceMultipliers, item.economicCategory))
      throw new Error(
        `Region: brak mnożnika dla kategorii ${item.economicCategory || 'N/D'}.`,
      );
    region = selected.priceMultipliers[item.economicCategory]!;
  }
  if (c.location.kind === 'location') {
    const selected = Object.hasOwn(r.locations, c.location.id)
      ? r.locations[c.location.id]
      : undefined;
    if (!selected) throw new Error('Lokalizacja: nieznany wybór.');
    location = selected.availabilityDelta;
  }
  const color =
    c.color === 'steel' && !['weapon', 'ammunition'].includes(item.type)
      ? TRADE_COLORS.none
      : TRADE_COLORS[c.color];
  return {
    region,
    location,
    colorPrice:
      c.color === 'chrome' &&
      item.category === 'Prochy i używki / Środki lecznicze'
        ? 0.5
        : color.price,
    colorAvailability: color.availability,
  };
}
type Range = { min: number; max: number };
function mapRange(
  value: Range | null,
  transform: (n: number) => number,
): Range | null {
  if (value === null) return null;
  const result = { min: transform(value.min), max: transform(value.max) };
  if (
    ![result.min, result.max].every(
      (n) => Number.isFinite(n) && n <= Number.MAX_SAFE_INTEGER,
    )
  )
    throw new Error('Wynik przekracza bezpieczny zakres liczb.');
  return result;
}
export function calculateMarketValues(
  item: Item,
  context: TradeContext,
  rules: MarketRules,
  availabilityBonus = 0,
) {
  if (!Number.isFinite(availabilityBonus) || Math.abs(availabilityBonus) > 100)
    throw new Error('Nieprawidłowa premia dostępności.');
  const f = marketFactors(item, context, rules);
  return {
    price: mapRange(item.basePrice, (n) => n * f.region * f.colorPrice),
    availability: mapRange(item.baseAvailability, (n) =>
      Math.max(
        0,
        Math.min(
          100,
          (n + f.location + availabilityBonus) * f.colorAvailability,
        ),
      ),
    ),
  };
}
export function calculateMarketPrice(
  item: Item,
  context: TradeContext,
  rules: MarketRules,
) {
  return calculateMarketValues(item, context, rules).price;
}
export function calculateMarketAvailability(
  item: Item,
  context: TradeContext,
  rules: MarketRules,
  availabilityBonus = 0,
) {
  return calculateMarketValues(item, context, rules, availabilityBonus)
    .availability;
}
export function formatMarketRange(range: Range | null, unit: string) {
  if (range === null) return 'N/D';
  const format = (n: number) =>
    n.toLocaleString('pl-PL', { maximumFractionDigits: 2 });
  return `${format(range.min)}${range.min === range.max ? '' : `–${format(range.max)}`} ${unit}`;
}
