import { failureModifiers } from './machineFailures';
import {
  machineFailuresSchema,
  type MachineFailure,
} from './machineFailureSchema';
import { z } from 'zod';
const text = z.string().trim().min(1);
const finite = z.number().finite().min(0).max(Number.MAX_SAFE_INTEGER);
const bonus = z.number().int().min(-99).max(99);
export const valueRangeSchema = z
  .object({ min: finite, max: finite })
  .strict()
  .refine((r) => r.min <= r.max, 'Od musi być ≤ do.');
export const weaponRangeSchema = z
  .object({
    normal: finite.nullable(),
    long: finite.nullable(),
    unit: z.literal('m'),
  })
  .strict()
  .refine((r) => r.long === null || (r.normal !== null && r.long >= r.normal), {
    message: 'Długi zasięg wymaga zwykłego i nie może być mniejszy.',
    path: ['long'],
  });
const damageModeSchema = z
  .object({
    id: text,
    label: text,
    dice: text,
    average: finite.nullable(),
    damageType: text,
    condition: z.string().nullable(),
  })
  .strict();
const variantSchema = z
  .object({
    id: text,
    label: text,
    attackModifier: bonus,
    damageModeId: text.nullable(),
    range: weaponRangeSchema.nullable(),
    effect: z.string(),
  })
  .strict();
export const weaponProfileSchema = z
  .object({
    attackKind: z.enum(['melee', 'ranged']),
    abilityRule: z.enum(['str', 'dex', 'finesse']),
    attackModifier: bonus,
    range: weaponRangeSchema,
    damageModes: z.array(damageModeSchema).min(1),
    properties: z.array(text),
    fireModes: z.array(variantSchema),
    ammoVariants: z.array(variantSchema),
  })
  .strict()
  .superRefine((p, ctx) => {
    for (const list of [p.damageModes, p.fireModes, p.ammoVariants])
      if (new Set(list.map((v) => v.id)).size !== list.length)
        ctx.addIssue({ code: 'custom', message: 'Powtórzone ID wariantu.' });
    for (const v of [...p.fireModes, ...p.ammoVariants])
      if (
        v.damageModeId !== null &&
        !p.damageModes.some((d) => d.id === v.damageModeId)
      )
        ctx.addIssue({
          code: 'custom',
          message: 'Wariant wskazuje nieistniejącą formułę obrażeń.',
        });
  });
export const itemSchema = z
  .object({
    id: z.uuid(),
    name: text,
    type: z.enum([
      'weapon',
      'armor',
      'ammunition',
      'tool',
      'electronics',
      'food',
      'fuel',
      'other',
    ]),
    category: z.string(),
    economicCategory: z.string(),
    basePrice: valueRangeSchema.nullable(),
    baseAvailability: valueRangeSchema.refine((r) => r.max <= 100).nullable(),
    weight: finite.nullable(),
    description: z.string(),
    properties: z.array(text),
    weaponProfile: weaponProfileSchema.optional(),
    source: z.string().optional(),
    createdAt: text,
    updatedAt: text,
  })
  .strict()
  .refine(
    (i) => !i.weaponProfile || i.type === 'weapon',
    'Profil bojowy należy do typu weapon.',
  );
export const equippedItemSchema = z
  .object({
    item: itemSchema,
    damageModeId: text.nullable(),
    fireModeId: text.nullable(),
    ammoVariantId: text.nullable(),
  })
  .strict()
  .superRefine((e, ctx) => {
    const p = e.item.weaponProfile;
    for (const [field, id, list] of [
      ['damageModeId', e.damageModeId, p?.damageModes],
      ['fireModeId', e.fireModeId, p?.fireModes],
      ['ammoVariantId', e.ammoVariantId, p?.ammoVariants],
    ] as const)
      if (id !== null && !list?.some((v) => v.id === id))
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: 'Wybrany wariant nie istnieje w tym przedmiocie.',
        });
    if (p && e.damageModeId === null)
      ctx.addIssue({
        code: 'custom',
        path: ['damageModeId'],
        message: 'Wybierz formułę obrażeń.',
      });
  });
export const combatLoadoutSchema = z
  .object({
    pb: z.number().int().min(0).max(99).nullable(),
    strModifier: bonus.nullable(),
    dexModifier: bonus.nullable(),
    items: z.array(equippedItemSchema),
  })
  .strict()
  .refine(
    (l) => new Set(l.items.map((e) => e.item.id)).size === l.items.length,
    'Każdy przedmiot w zestawie musi mieć osobne ID.',
  );
export type Item = z.infer<typeof itemSchema>;
export type WeaponProfile = z.infer<typeof weaponProfileSchema>;
export type WeaponVariant = WeaponProfile['fireModes'][number];
export type EquippedItem = z.infer<typeof equippedItemSchema>;
export type CombatLoadout = z.infer<typeof combatLoadoutSchema>;
export const emptyLoadout = (): CombatLoadout => ({
  pb: null,
  strModifier: null,
  dexModifier: null,
  items: [],
});
export function calculateWeaponAttackProfile(
  equipped: EquippedItem,
  stats: Pick<CombatLoadout, 'pb' | 'strModifier' | 'dexModifier'>,
  failures: readonly MachineFailure[] = [],
) {
  const e = equippedItemSchema.parse(equipped);
  const p = e.item.weaponProfile;
  if (!p) throw new Error('Przedmiot nie ma profilu broni.');
  const validStats = combatLoadoutSchema.parse({ ...stats, items: [] });
  const mod =
    p.abilityRule === 'str'
      ? validStats.strModifier
      : p.abilityRule === 'dex'
        ? validStats.dexModifier
        : validStats.strModifier === null || validStats.dexModifier === null
          ? null
          : Math.max(validStats.strModifier, validStats.dexModifier);
  if (validStats.pb === null || mod === null)
    throw new Error('Uzupełnij PB i modyfikator wymaganej cechy.');
  const fire = p.fireModes.find((v) => v.id === e.fireModeId);
  const ammo = p.ammoVariants.find((v) => v.id === e.ammoVariantId);
  const damage = p.damageModes.find(
    (d) =>
      d.id === (ammo?.damageModeId ?? fire?.damageModeId ?? e.damageModeId),
  )!;
  return {
    attack:
      validStats.pb +
      mod +
      p.attackModifier +
      (fire?.attackModifier ?? 0) +
      (ammo?.attackModifier ?? 0) +
      failureModifiers(machineFailuresSchema.parse(failures)).attack,
    pb: validStats.pb,
    abilityModifier: mod,
    range: structuredClone(ammo?.range ?? fire?.range ?? p.range),
    damage: structuredClone(damage),
    effects: [
      e.item.description,
      damage.condition,
      fire?.effect,
      ammo?.effect,
    ].filter((s): s is string => !!s),
    properties: [...e.item.properties, ...p.properties],
  };
}
export function selectWeaponVariant(
  loadout: CombatLoadout,
  itemId: string,
  patch: Partial<
    Pick<EquippedItem, 'damageModeId' | 'fireModeId' | 'ammoVariantId'>
  >,
): CombatLoadout {
  if (!loadout.items.some((e) => e.item.id === itemId))
    throw new Error('Brak przedmiotu.');
  return combatLoadoutSchema.parse({
    ...structuredClone(loadout),
    items: loadout.items.map((e) =>
      e.item.id === itemId ? { ...e, ...patch } : e,
    ),
  });
}
export function formatWeaponRange(range: WeaponProfile['range']) {
  if (range.normal === null) return 'zasięg: brak danych';
  return `${range.normal.toLocaleString('pl')}${range.long === null ? '' : ` / ${range.long.toLocaleString('pl')}`} m`;
}
