import { parseActorDraft, type ActorDraft } from './combat';
import { effectiveMachineTT } from './machineFailures';
export function draftMachineTT(actor: ActorDraft) {
  try {
    return effectiveMachineTT(parseActorDraft(actor));
  } catch {
    return actor.ttCurrent || '—';
  }
}
