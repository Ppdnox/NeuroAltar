import { toStatblockDraft } from './statblock';
import { toLoadoutDraft } from './itemDraft';
import { z } from 'zod';
import {
  enemyTemplateSchema,
  formatSpeeds,
  type EnemyTemplate,
  type EnemyTemplateDraft,
} from './enemy';
import { toCapabilityDraft, instantiateCapabilities } from './capabilitySchema';
export const catalogEntrySchema = z
  .object({
    template: enemyTemplateSchema,
    revision: z.number().int().nonnegative(),
  })
  .strict();
export type CatalogEntry = z.infer<typeof catalogEntrySchema>;
export type CatalogMutation = {
  template: EnemyTemplate;
  expectedRevision: number | null;
  deleted: boolean;
};
export function templateDraft(t: EnemyTemplate): EnemyTemplateDraft {
  return {
    name: t.name,
    ...(t.statblock ? { statblock: toStatblockDraft(t.statblock) } : {}),
    ...(t.sp === undefined ? {} : { sp: t.sp === null ? '' : String(t.sp) }),
    ...(t.failureThreshold === undefined
      ? {}
      : {
          failureThreshold:
            t.failureThreshold === null ? '' : String(t.failureThreshold),
        }),
    ...(t.loadout ? { loadout: toLoadoutDraft(t.loadout) } : {}),
    category: t.category,
    size: t.size,
    tt: String(t.tt),
    hpMax: String(t.hpMax),
    speedsText: formatSpeeds(t.speeds),
    injuryEnabled: t.injuryTrack?.enabled ?? false,
    initialInjuryLevel: String(t.injuryTrack?.initialLevel ?? 0),
    cowardicePercent:
      t.cowardicePercent == null ? '' : String(t.cowardicePercent),
    ...(t.capabilities
      ? {
          capabilities: toCapabilityDraft(
            instantiateCapabilities(t.capabilities),
          ),
        }
      : {}),
  };
}
const normalize = (s: string) =>
  s
    .toLocaleLowerCase('pl')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replaceAll('ł', 'l');
export function filterCatalog(
  entries: CatalogEntry[],
  query: string,
  category: string,
  size: string,
) {
  const words = normalize(query).trim().split(/\s+/);
  return entries
    .filter(
      ({ template: t }) =>
        (category === '' || t.category === category) &&
        (size === '' || t.size === size) &&
        words.every((w) =>
          normalize(
            [
              t.name,
              t.size,
              t.statblock?.subtype ?? '',
              ...(t.statblock?.traits ?? []),
              ...(t.capabilities?.abilities.map(
                (a) => `${a.name} ${a.description}`,
              ) ?? []),
            ].join(' '),
          ).includes(w),
        ),
    )
    .sort(
      (a, b) =>
        a.template.name.localeCompare(b.template.name, 'pl') ||
        a.template.id.localeCompare(b.template.id),
    );
}
