import { parseDiceFormula } from './dice';
export interface RuleRoll {
  start: number;
  end: number;
  formula: string;
  kind: 'attack' | 'damage' | 'roll';
}
// Recognize explicit numbers only. A target's RO/ST does not supply its modifier.
export function ruleRolls(text: string): RuleRoll[] {
  const found: RuleRoll[] = [];
  for (const m of text.matchAll(
    /\bAtak(?:i|ów)?(?:\s+(?:wręcz|dystansowy|bronią|palną|białą|lub|czarem|na|odległość|piłą|w|jeden|więcej|cel|celów))*:?\s+([+−-]\s*\d+)\b/giu,
  )) {
    const bonus = m[1]!.replace(/\s/g, '').replace('−', '-');
    found.push({
      start: m.index! + m[0].lastIndexOf(m[1]!),
      end: m.index! + m[0].length,
      formula: `1k20${bonus}`,
      kind: 'attack',
    });
  }
  for (const m of text.matchAll(
    /(?<![\p{L}\p{N}_])(?:\d+\s*)?[kd]\d+(?:\s*\+\s*(?:\d+\s*)?[kd]\d+)*(?:\s*[+−-]\s*\d+)?(?![\p{L}\p{N}_])/giu,
  )) {
    const start = m.index!,
      end = start + m[0].length;
    // Never turn a fragment of a compound expression into a misleading roll.
    if (
      /[+−*/-]\s*$/.test(text.slice(0, start)) ||
      /^\s*[+−*/-]/.test(text.slice(end))
    )
      continue;
    try {
      const parsed = parseDiceFormula(m[0].replace('−', '-'));
      found.push({
        start,
        end,
        formula: parsed.formula,
        kind: parsed.sides === 20 || parsed.sides === 100 ? 'roll' : 'damage',
      });
    } catch {
      /* Unsupported notation remains readable. */
    }
  }
  return found.sort((a, b) => a.start - b.start);
}
