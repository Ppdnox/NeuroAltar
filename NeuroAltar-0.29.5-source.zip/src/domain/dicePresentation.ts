import { diceFaceSides, type DiceRoll } from './dice';
export function naturalDieClass(sides: number, value: number): string {
  if (sides !== 20) return '';
  return value === 20 ? 'natural-twenty' : value === 1 ? 'natural-one' : '';
}
export function naturalRollClass(roll: DiceRoll): string {
  if (roll.supplement)
    return naturalDieClass(20, roll.supplement.originalNatural);
  return roll.values.length === 1
    ? naturalDieClass(diceFaceSides(roll)[0]!, roll.values[0]!)
    : '';
}
export function naturalRollLabel(roll: DiceRoll): string {
  const tone = naturalRollClass(roll);
  return tone === 'natural-twenty'
    ? 'Naturalne 20'
    : tone === 'natural-one'
      ? 'Naturalna 1'
      : '';
}
