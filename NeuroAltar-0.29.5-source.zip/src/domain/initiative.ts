export interface InitiativeActor {
  id: string;
  initiativeValue: number | null;
  initiativeTieOrder: number;
}

export function initiativeOrder<T extends InitiativeActor>(
  actors: readonly T[],
): T[] {
  return actors
    .filter((actor) => actor.initiativeValue !== null)
    .sort(
      (a, b) =>
        b.initiativeValue! - a.initiativeValue! ||
        a.initiativeTieOrder - b.initiativeTieOrder,
    );
}

export function advanceTurn(
  actors: readonly InitiativeActor[],
  roundNumber: number,
  currentTurnActorId: string | null,
) {
  const ordered = initiativeOrder(actors);
  if (!ordered.length) return { roundNumber, currentTurnActorId: null };
  const index = ordered.findIndex((actor) => actor.id === currentTurnActorId);
  const wrapped = index === ordered.length - 1;
  if (wrapped && roundNumber === Number.MAX_SAFE_INTEGER)
    throw new Error('Osiągnięto maksymalny numer rundy.');
  return {
    roundNumber: wrapped ? roundNumber + 1 : roundNumber,
    currentTurnActorId: ordered[wrapped ? 0 : index + 1]!.id,
  };
}

export function moveWithinTie<T extends InitiativeActor>(
  actors: readonly T[],
  id: string,
  direction: -1 | 1,
): T[] {
  const ordered = initiativeOrder(actors);
  const index = ordered.findIndex((actor) => actor.id === id);
  const actor = ordered[index];
  const neighbor = ordered[index + direction];
  if (!actor || !neighbor || actor.initiativeValue !== neighbor.initiativeValue)
    return [...actors];
  return actors.map((entry) =>
    entry.id === actor.id
      ? { ...entry, initiativeTieOrder: neighbor.initiativeTieOrder }
      : entry.id === neighbor.id
        ? { ...entry, initiativeTieOrder: actor.initiativeTieOrder }
        : entry,
  );
}
