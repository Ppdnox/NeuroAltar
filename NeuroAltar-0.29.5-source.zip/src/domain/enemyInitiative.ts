import type { ActorDraft } from './combat';
import { abilityModifier } from './statblock';
import { exhaustionEffects } from './status';

export function enemyInitiative(actor: ActorDraft) {
  if (!actor.enemy) return null;
  const statblock = actor.enemy.statblock;
  const lines = (statblock?.traits ?? []).filter((line) =>
    /^Inicjatywa(?: z podręcznika)?\s*:/i.test(line.trim()),
  );
  const bonuses = lines.map((line) => {
    const match =
      /^Inicjatywa(?: z podręcznika)?\s*:\s*([+−-]?\d+)(?=\s|[.(]|$)/i.exec(
        line.trim(),
      );
    return match ? Number(match[1]!.replace('−', '-')) : null;
  });
  // An explicit handbook bonus is final; the number in parentheses is not a die bonus.
  const base = lines.length
    ? bonuses.every((v) => v !== null && v === bonuses[0])
      ? bonuses[0]!
      : null
    : abilityModifier(statblock?.abilityScores.dex);
  if (base === null) return null;
  const penalty = exhaustionEffects(actor.effects ?? []).testPenalty;
  const modifier = base - penalty;
  if (!Number.isSafeInteger(modifier) || Math.abs(modifier) > 10000)
    return null;
  return {
    base,
    penalty,
    modifier,
    formula: `1k20${modifier >= 0 ? '+' : ''}${modifier}`,
  };
}
