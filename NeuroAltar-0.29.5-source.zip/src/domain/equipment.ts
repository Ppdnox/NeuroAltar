import { withItemDisplayName } from './catalogNames';
import { itemWeight } from './medicineWeight';
import type { Item } from './item';
export const ITEM_TYPES: Record<Item['type'], string> = {
  weapon: 'Broń',
  armor: 'Pancerz',
  ammunition: 'Amunicja',
  tool: 'Narzędzia',
  electronics: 'Elektronika',
  food: 'Żywność',
  fuel: 'Paliwo',
  other: 'Inne',
};
export function equipmentWeight(item: Item) {
  const weight = itemWeight(item);
  if (weight !== null)
    return `${weight.toLocaleString('pl-PL', { maximumFractionDigits: 2 })} kg`;
  return item.properties.find((p) => p.startsWith('Waga: '))?.slice(6) ?? 'N/D';
}
const normalize = (text: string) =>
  text
    .toLocaleLowerCase('pl')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replaceAll('ł', 'l');
export function filterEquipment(
  items: Item[],
  query: string,
  type: Item['type'] | '',
  category: string,
) {
  const words = normalize(query.trim()).split(/\s+/).filter(Boolean);
  return items
    .map(withItemDisplayName)
    .filter(
      (item) =>
        (!type || item.type === type) &&
        (!category || item.category === category) &&
        words.every((word) =>
          normalize(
            [
              item.name,
              item.category,
              item.economicCategory,
              item.description,
              ...item.properties,
            ].join(' '),
          ).includes(word),
        ),
    )
    .sort(
      (a, b) => a.name.localeCompare(b.name, 'pl') || a.id.localeCompare(b.id),
    );
}
