import { failureModifiers } from './machineFailures';
import type { Actor } from './combat';
import { injuryStateSchema } from './enemy';
import {
  exhaustionEffects,
  newStatusDraft,
  parseStatusDraft,
  type Status,
} from './status';
export const injuryLabels = [
  'Brak',
  'Lekki',
  'Znaczny',
  'Poważny',
  'Krytyczny',
] as const;
export function changeExhaustion(
  effects: readonly Status[],
  delta: -1 | 1,
  id?: string,
): Status[] {
  const old = effects.find((s) => s.systemKey === 'exhaustion');
  const level = Math.max(0, Math.min(6, (old?.level ?? 0) + delta));
  if (level === (old?.level ?? 0)) return [...effects];
  const remaining = effects.filter((s) => s.systemKey !== 'exhaustion');
  if (!level) return remaining;
  const effect = old
    ? { ...old, level }
    : parseStatusDraft(
        { ...newStatusDraft(), systemKey: 'exhaustion', level: String(level) },
        false,
        id,
      );
  return [...remaining, effect].sort((a, b) => a.id.localeCompare(b.id));
}
// A fifth wound is represented by a warning on level 4, never an actor removal.
export function applyInjuryLevel(
  actor: Actor,
  level: number,
  exhaustionId?: string,
): Actor {
  if (!actor.enemy?.injury?.enabled) return actor;
  if (!Number.isInteger(level) || level < 0 || level > 5)
    throw new Error('Stopień zranienia poza zakresem.');
  const old = actor.enemy.injury;
  const injury = injuryStateSchema.parse({
    enabled: true,
    level: Math.min(4, level),
    deathWarning: level === 5,
  });
  return {
    ...actor,
    enemy: { ...actor.enemy, injury },
    ...(old.level < 4 && injury.level === 4
      ? { effects: changeExhaustion(actor.effects ?? [], 1, exhaustionId) }
      : {}),
  };
}
export function setInjuryEnabled(actor: Actor, enabled: boolean): Actor {
  if (!actor.enemy || (actor.enemy.injury?.enabled ?? false) === enabled)
    return actor;
  return {
    ...actor,
    enemy: {
      ...actor.enemy,
      injury: { enabled, level: 0, deathWarning: false },
    },
  };
}
export function injuryConsequences(actor: Actor) {
  const injury = actor.enemy?.injury;
  const level = injury?.enabled ? injury.level : 0;
  const exhaustion = exhaustionEffects(actor.effects ?? []);
  const speedPenalty = (level >= 1 ? 4.5 : 0) + exhaustion.speedPenalty;
  return {
    level,
    speedPenalty,
    reactionsBlocked: level >= 2,
    bonusActionsBlocked: level >= 3,
    deathWarning: Boolean(injury?.enabled && injury.deathWarning),
    speeds: (actor.enemy?.speeds ?? []).map((s) => ({
      ...s,
      meters:
        Math.max(0, s.meters - speedPenalty) *
        failureModifiers(actor.enemy?.machineFailures).speed,
    })),
  };
}
export function cowardiceWarning(actor: Actor) {
  const percent = actor.enemy?.cowardicePercent;
  if (percent === null || percent === undefined) return null;
  // Integer PW: exact comparison, even at the largest allowed HP.
  const threshold = Number(
    (BigInt(actor.hpMaxCurrent) * BigInt(percent)) / 100n,
  );
  return { percent, threshold, active: actor.hpCurrent <= threshold };
}
