import { z } from 'zod';
import { encounterIdSchema } from './encounter';
export const saveReasonSchema = z.enum([
  'edit',
  'advance',
  'new_day',
  'renew_encounter',
  'prepare',
  'reset',
  'clear_log',
]);
export type SaveReason = z.infer<typeof saveReasonSchema>;
export const combatLogEntrySchema = z
  .object({
    id: z.number().int().positive(),
    encounterId: encounterIdSchema,
    roundNumber: z.number().int().positive(),
    actorId: z.uuid().nullable(),
    eventType: z.enum([
      'dice_rolled',
      'character',
      'actor_added',
      'actor_removed',
      'name_changed',
      'hp_changed',
      'tt_changed',
      'initiative_changed',
      'tie_changed',
      'statuses_changed',
      'movement_changed',
      'injury_changed',
      'capabilities_changed',
      'resource_changed',
      'equipment_changed',
      'statblock_changed',
      'sp_changed',
      'failure_threshold_changed',
      'machine_failures_changed',
      'budget_changed',
      'action_used',
      'resources_refreshed',
      'cowardice_changed',
      'cowardice_warning',
      'turn_changed',
      'round_changed',
      'prepared',
      'reset',
      'status_added',
      'status_removed',
      'status_updated',
      'status_expired',
      'burning_reminder',
    ]),
    message: z.string().min(1),
    payload: z.object({ before: z.unknown(), after: z.unknown() }).strict(),
    createdAt: z.iso.datetime(),
  })
  .strict();
export type CombatLogEntry = z.infer<typeof combatLogEntrySchema>;
export const LOG_PAGE_SIZE = 100;
