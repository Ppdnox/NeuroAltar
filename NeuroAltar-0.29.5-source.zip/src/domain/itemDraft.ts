import {
  combatLoadoutSchema,
  emptyLoadout,
  itemSchema,
  type CombatLoadout,
  type EquippedItem,
  type Item,
  type WeaponProfile,
  type WeaponVariant,
} from './item';
export type RangeDraft = { normal: string; long: string };
export type VariantDraft = Omit<WeaponVariant, 'attackModifier' | 'range'> & {
  attackModifier: string;
  overrideRange: boolean;
  range: RangeDraft;
};
export type ProfileDraft = Omit<
  WeaponProfile,
  | 'range'
  | 'attackModifier'
  | 'damageModes'
  | 'properties'
  | 'fireModes'
  | 'ammoVariants'
> & {
  attackModifier: string;
  range: RangeDraft;
  damageModes: (Omit<WeaponProfile['damageModes'][number], 'average'> & {
    average: string;
  })[];
  propertiesText: string;
  fireModes: VariantDraft[];
  ammoVariants: VariantDraft[];
};
export type EquippedDraft = Omit<EquippedItem, 'item'> & {
  original: Item;
  name: string;
  category: string;
  description: string;
  propertiesText: string;
  profile: ProfileDraft | null;
};
export interface LoadoutDraft {
  pb: string;
  strModifier: string;
  dexModifier: string;
  items: EquippedDraft[];
}
const display = (v: number | null) => (v === null ? '' : String(v));
const rangeDraft = (r: WeaponProfile['range']): RangeDraft => ({
  normal: display(r.normal),
  long: display(r.long),
});
const variantDraft = (v: WeaponVariant): VariantDraft => ({
  ...v,
  attackModifier: String(v.attackModifier),
  overrideRange: v.range !== null,
  range: v.range ? rangeDraft(v.range) : { normal: '', long: '' },
});
export function toLoadoutDraft(l: CombatLoadout): LoadoutDraft {
  return {
    pb: display(l.pb),
    strModifier: display(l.strModifier),
    dexModifier: display(l.dexModifier),
    items: l.items.map((e) => {
      const p = e.item.weaponProfile;
      return {
        ...e,
        original: structuredClone(e.item),
        name: e.item.name,
        category: e.item.category,
        description: e.item.description,
        propertiesText: e.item.properties.join('\n'),
        profile: p
          ? {
              ...structuredClone(p),
              attackModifier: String(p.attackModifier),
              range: rangeDraft(p.range),
              damageModes: p.damageModes.map((d) => ({
                ...d,
                average: display(d.average),
              })),
              propertiesText: p.properties.join('\n'),
              fireModes: p.fireModes.map(variantDraft),
              ammoVariants: p.ammoVariants.map(variantDraft),
            }
          : null,
      };
    }),
  };
}
const numeric = (s: string) => (/^[-+]?\d+$/.test(s.trim()) ? Number(s) : NaN);
const optional = (s: string) => (s.trim() === '' ? null : numeric(s));
const decimal = (s: string) =>
  s.trim() === ''
    ? null
    : /^\d+(?:[.,]\d+)?$/.test(s.trim())
      ? Number(s.replace(',', '.'))
      : NaN;
const parseRange = (r: RangeDraft) => ({
  normal: decimal(r.normal),
  long: decimal(r.long),
  unit: 'm' as const,
});
const lines = (s: string) =>
  s
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
const parseVariant = (v: VariantDraft): WeaponVariant => ({
  id: v.id,
  label: v.label,
  attackModifier: numeric(v.attackModifier),
  damageModeId: v.damageModeId,
  range: v.overrideRange ? parseRange(v.range) : null,
  effect: v.effect,
});
export function parseLoadoutDraft(
  d: LoadoutDraft,
  now = new Date().toISOString(),
): CombatLoadout {
  return combatLoadoutSchema.parse({
    pb: optional(d.pb),
    strModifier: optional(d.strModifier),
    dexModifier: optional(d.dexModifier),
    items: d.items.map((e) => {
      const { weaponProfile: old, ...base } = e.original;
      void old;
      const p = e.profile;
      const item = {
        ...base,
        name: e.name,
        category: e.category,
        description: e.description,
        properties: lines(e.propertiesText),
        ...(p
          ? {
              weaponProfile: {
                attackKind: p.attackKind,
                abilityRule: p.abilityRule,
                attackModifier: numeric(p.attackModifier),
                range: parseRange(p.range),
                damageModes: p.damageModes.map((m) => ({
                  ...m,
                  average: decimal(m.average),
                })),
                properties: lines(p.propertiesText),
                fireModes: p.fireModes.map(parseVariant),
                ammoVariants: p.ammoVariants.map(parseVariant),
              },
            }
          : {}),
      };
      if (
        JSON.stringify(itemSchema.safeParse(item).data) !==
        JSON.stringify(itemSchema.safeParse(e.original).data)
      )
        item.updatedAt = now;
      return {
        item,
        damageModeId: e.damageModeId,
        fireModeId: e.fireModeId,
        ammoVariantId: e.ammoVariantId,
      };
    }),
  });
}
export function newWeaponDraft(): EquippedDraft {
  const now = new Date().toISOString();
  const mode = crypto.randomUUID();
  const item: Item = {
    id: crypto.randomUUID(),
    name: '',
    type: 'weapon',
    category: '',
    economicCategory: '',
    basePrice: null,
    baseAvailability: null,
    weight: null,
    description: '',
    properties: [],
    createdAt: now,
    updatedAt: now,
    weaponProfile: {
      attackKind: 'ranged',
      abilityRule: 'dex',
      attackModifier: 0,
      range: { normal: null, long: null, unit: 'm' },
      damageModes: [
        {
          id: mode,
          label: 'Standard',
          dice: '',
          average: null,
          damageType: '',
          condition: null,
        },
      ],
      properties: [],
      fireModes: [],
      ammoVariants: [],
    },
  };
  return toLoadoutDraft({
    pb: null,
    strModifier: null,
    dexModifier: null,
    items: [
      { item, damageModeId: mode, fireModeId: null, ammoVariantId: null },
    ],
  }).items[0]!;
}
export const newVariantDraft = (): VariantDraft => ({
  id: crypto.randomUUID(),
  label: '',
  attackModifier: '0',
  damageModeId: null,
  overrideRange: false,
  range: { normal: '', long: '' },
  effect: '',
});

export const emptyLoadoutDraft = () => toLoadoutDraft(emptyLoadout());
