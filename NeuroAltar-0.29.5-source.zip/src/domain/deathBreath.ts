import { enemyTemplateSchema, type EnemyTemplate } from './enemy';
import { toStatblockDraft, parseStatblockDraft } from './statblock';
import { templateDraft } from './bestiary';

export const deathBreath = {
  name: 'Zombie — nakładka Death Breath',
  source: 'Neuroshima 5e — Notatnik Łowcy, s. 242 (PDF 244)',
  rules: [
    'Średni potwór. Nakładka na człowieka lub mutanta; nie ma własnych bazowych PW.',
    'TT nosiciela -2; PW, Szybkość, zmysły i PB nosiciela; SP nosiciela +2. Inicjatywa źródłowa: -4 (6), wynik wpisuje MG.',
    'SIŁ, ZRC, KON i MDR nosiciela; INT 4 (-3), CHA 2 (-4).',
    'Odporności: cięte, kłute, obuchowe. Niewrażliwość na Przerażenie.',
    'Pierwsze spotkanie: RO MDR ST 14; porażka — Przerażenie, ponowienie RO na końcu własnej tury (s. 205).',
    'Macka: TT 10, PW 5, niewrażliwość na obrażenia obuchowe.',
    'Tylko zwarcie: brak ataków dystansowych, nawet jeśli nosiciel je posiadał.',
    'Trzeba dobić: przy 0 PW Nieprzytomność przez 1 minutę, następnie powrót z 1 PW. Zabija dopiero dekapitacja, zniszczenie mózgu lub całkowite spalenie. MG rozstrzyga ręcznie.',
    'Atak wielokrotny: jeden atak macką i ataki wręcz nosiciela.',
    'Macka: średnia lub mniejsza istota do 1,5 m; RO SIŁ lub ZRC o ST równym PB + modyfikator SIŁ; porażka — Pochwycenie. Nie dodawaj 8 do ST.',
    'Ugryzienie: atak wręcz PB + modyfikator SIŁ, zasięg 1,5 m; obrażenia 1k4 + modyfikator SIŁ kłute. RO KON ST 10; porażka — zakażenie Death Breath.',
  ],
} as const;

// A new reviewed catalog draft, never a mutation of the host or a combat actor.
export function prepareDeathBreath(
  host: EnemyTemplate,
  meleeAbilityIds: string[],
) {
  if (host.category !== 'human' && host.category !== 'mutant')
    throw new Error('Wybierz człowieka lub mutanta jako nosiciela.');
  const original = enemyTemplateSchema.parse(host);
  const s = parseStatblockDraft(toStatblockDraft(original.statblock));
  s.subtype = 'Potwór — Death Breath';
  s.abilityScores.int = 4;
  s.abilityScores.cha = 2;
  s.resistances = [
    ...new Set([...(s.resistances ?? []), 'cięte', 'kłute', 'obuchowe']),
  ];
  s.conditionImmunities = [
    ...new Set([...(s.conditionImmunities ?? []), 'Przerażenie']),
  ];
  s.traits = [
    `Źródło: ${deathBreath.source}. Nosiciel: ${original.name}.`,
    ...deathBreath.rules,
    'Sprawdź odziedziczone umiejętności i końcowe RO po zmianie INT i CHA. Pozostałe zdolności nosiciela przenieś tylko, jeśli należą do jego ataków wręcz. Nie stosuj nakładki ponownie do gotowego Zombie.',
  ];
  const selected =
    original.capabilities?.abilities.filter((a) =>
      meleeAbilityIds.includes(a.id),
    ) ?? [];
  if (selected.length !== new Set(meleeAbilityIds).size)
    throw new Error(
      'Wybrana zdolność nosiciela już nie istnieje. Wybierz nosiciela ponownie.',
    );
  const abilities = structuredClone(selected);
  const str =
    original.loadout?.strModifier ??
    (original.statblock?.abilityScores.str == null
      ? null
      : Math.floor((original.statblock.abilityScores.str - 10) / 2));
  const pb = original.loadout?.pb ?? null;
  const total = str === null || pb === null ? null : str + pb;
  const add = (name: string, description: string) =>
    abilities.push({
      id: crypto.randomUUID(),
      name,
      description,
      kind: 'action',
      legendaryCost: 1,
      resourceId: null,
      resourceCost: 1,
    });
  add(
    'Atak wielokrotny',
    'Jeden atak macką i ataki wręcz nosiciela; jedna Akcja. Pod-ataki rozstrzyga MG.',
  );
  add(
    'Macka',
    `Średnia lub mniejsza istota do 1,5 m: RO SIŁ lub ZRC ST ${total ?? 'N/D (PB + modyfikator SIŁ nosiciela)'}; porażka — Pochwycenie.`,
  );
  add(
    'Ugryzienie',
    `Atak wręcz ${total == null ? 'N/D (PB + modyfikator SIŁ nosiciela)' : total >= 0 ? '+' + total : total}; zasięg 1,5 m; 1k4 ${str == null ? '+ modyfikator SIŁ nosiciela' : str < 0 ? '- ' + Math.abs(str) : '+ ' + str} kłute. RO KON ST 10 albo zakażenie Death Breath.`,
  );
  const draft = templateDraft({
    ...original,
    id: crypto.randomUUID(),
    name: `Zombie — ${original.name}`,
    category: 'monster',
    size: 'Średni',
    statblock: s,
    capabilities: {
      abilities,
      resources: structuredClone(
        original.capabilities?.resources.filter((r) =>
          abilities.some((a) => a.resourceId === r.id),
        ) ?? [],
      ),
      legendaryMax: abilities.some((a) => a.kind === 'legendary')
        ? original.capabilities!.legendaryMax
        : 0,
    },
    ...(original.loadout
      ? {
          loadout: {
            ...structuredClone(original.loadout),
            items: structuredClone(
              original.loadout.items.filter(
                (e) => e.item.weaponProfile?.attackKind === 'melee',
              ),
            ),
          },
        }
      : {}),
  });
  draft.tt = String(original.tt - 2);
  const sp = original.sp == null ? null : original.sp + 2;
  draft.sp = sp == null ? '' : String(sp);
  // Draft validation catches negative TT/unsafe SP instead of silently clamping.
  return draft;
}
