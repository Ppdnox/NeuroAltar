import {
  statblockSchema,
  parseStatblockDraft,
  type StatblockDraft,
} from './statblock';
import { withIssuePath } from './validation';
import { spSchema, parseSP } from './difficulty';
import {
  failureThresholdSchema,
  machineFailuresSchema,
  parseFailureThreshold,
} from './machineFailureSchema';
import { combatLoadoutSchema } from './item';
import { parseLoadoutDraft, type LoadoutDraft } from './itemDraft';
import {
  capabilitySetupSchema,
  capabilityStateSchema,
  parseCapabilitySetup,
  type CapabilityDraft,
} from './capabilitySchema';
import { z } from 'zod';

export const speedSchema = z
  .object({
    mode: z.string().trim().min(1),
    meters: z.number().finite().min(0).max(Number.MAX_SAFE_INTEGER),
  })
  .strict();
export const speedsSchema = z.array(speedSchema).superRefine((speeds, ctx) => {
  if (
    new Set(speeds.map((s) => s.mode.toLocaleLowerCase('pl'))).size !==
    speeds.length
  )
    ctx.addIssue({ code: 'custom', message: 'Każdy rodzaj ruchu wpisz raz.' });
});
export const injuryTrackSchema = z
  .object({
    enabled: z.boolean(),
    initialLevel: z.number().int().min(0).max(4),
  })
  .strict()
  .refine(
    (v) => v.enabled || v.initialLevel === 0,
    'Wyłączone zranienia mają poziom 0.',
  );
export const injuryStateSchema = z
  .object({
    enabled: z.boolean(),
    level: z.number().int().min(0).max(4),
    deathWarning: z.boolean(),
  })
  .strict()
  .refine(
    (v) =>
      (!v.deathWarning || v.level === 4) &&
      (v.enabled || (v.level === 0 && !v.deathWarning)),
    'Niepoprawny stan zranienia.',
  );
export const cowardicePercentSchema = z
  .number()
  .int()
  .min(0)
  .max(100)
  .nullable();
export function parseCowardice(text: string): number | null {
  return cowardicePercentSchema.parse(
    text.trim() === '' ? null : /^\d+$/.test(text.trim()) ? Number(text) : NaN,
  );
}
export const enemyTemplateSchema = z
  .object({
    id: z.uuid(),
    name: z.string().trim().min(1),
    category: z.enum([
      'human',
      'machine',
      'mutant',
      'monster',
      'animal',
      'beast',
      'other',
    ]),
    size: z.string().trim().min(1),
    tt: z.number().int().nonnegative(),
    hpMax: z.number().int().positive(),
    capabilities: capabilitySetupSchema.optional(),
    statblock: statblockSchema.optional(),
    loadout: combatLoadoutSchema.optional(),
    sp: spSchema.optional(),
    failureThreshold: failureThresholdSchema.optional(),
    injuryTrack: injuryTrackSchema.optional(),
    cowardicePercent: cowardicePercentSchema.optional(),
    speeds: speedsSchema,
  })
  .strict();
export const enemyInstanceSchema = z
  .object({
    template: enemyTemplateSchema,
    capabilities: capabilityStateSchema.optional(),
    statblock: statblockSchema.optional(),
    loadout: combatLoadoutSchema.optional(),
    sp: spSchema.optional(),
    failureThreshold: failureThresholdSchema.optional(),
    machineFailures: machineFailuresSchema.optional(),
    injury: injuryStateSchema.optional(),
    cowardicePercent: cowardicePercentSchema.optional(),
    speeds: speedsSchema,
  })
  .strict()
  .refine(
    (e) => !e.machineFailures?.length || e.template.category === 'machine',
    'Awarie dotyczą maszyn.',
  );
export type EnemyTemplate = z.infer<typeof enemyTemplateSchema>;
export type EnemyInstance = z.infer<typeof enemyInstanceSchema>;
export const categoryLabels: Record<EnemyTemplate['category'], string> = {
  human: 'Ludzie',
  beast: 'Bestia (starszy wpis)',
  machine: 'Maszyny',
  other: 'Inny (starszy wpis)',
  mutant: 'Mutanci',
  monster: 'Potwory',
  animal: 'Zwierzęta',
};
export const currentCategories = [
  'human',
  'machine',
  'mutant',
  'monster',
  'animal',
] as const;
export function categoryOptions(legacy: string[] = []) {
  return Object.entries(categoryLabels).filter(
    ([key]) =>
      (currentCategories as readonly string[]).includes(key) ||
      legacy.includes(key),
  );
}
export function formatSpeeds(speeds: EnemyTemplate['speeds']): string {
  return speeds.map((s) => `${s.mode}: ${s.meters}`).join('\n');
}
export function parseSpeeds(text: string): EnemyTemplate['speeds'] {
  return speedsSchema.parse(
    text
      .split('\n')
      .filter((line) => line.trim())
      .map((line) => {
        const match = /^(.+):\s*(\d+(?:[.,]\d+)?)\s*m?\s*$/.exec(line.trim());
        if (!match)
          throw new Error('Wpisz ruch jako rodzaj: metry, np. Szybkość: 9.');
        return {
          mode: match[1]!.trim(),
          meters: Number(match[2]!.replace(',', '.')),
        };
      }),
  );
}

export interface EnemyTemplateDraft {
  name: string;
  category: EnemyTemplate['category'];
  size: string;
  tt: string;
  hpMax: string;
  speedsText: string;
  capabilities?: CapabilityDraft;
  statblock?: StatblockDraft;
  loadout?: LoadoutDraft;
  injuryEnabled?: boolean;
  initialInjuryLevel?: string;
  cowardicePercent?: string;
  sp?: string;
  failureThreshold?: string;
}
export const newEnemyTemplateDraft = (): EnemyTemplateDraft => ({
  name: '',
  category: 'human',
  size: 'Średni',
  tt: '',
  hpMax: '',
  speedsText: '',
  injuryEnabled: false,
  initialInjuryLevel: '0',
  cowardicePercent: '',
});
export function parseEnemyTemplateDraft(
  draft: EnemyTemplateDraft,
  id: string,
): EnemyTemplate {
  const integer = (text: string) =>
    /^\d+$/.test(text.trim()) ? Number(text) : NaN;
  const issues: z.core.$ZodIssue[] = [];
  function field<T>(path: string, run: () => T): T | undefined {
    try {
      return withIssuePath([path], run);
    } catch (e) {
      if (e instanceof z.ZodError) issues.push(...e.issues);
      else throw e;
      return undefined;
    }
  }
  const fields = enemyTemplateSchema.shape;
  const candidate = {
    id,
    name: field('name', () => fields.name.parse(draft.name)),
    category: field('category', () => fields.category.parse(draft.category)),
    size: field('size', () => fields.size.parse(draft.size)),
    tt: field('tt', () => fields.tt.parse(integer(draft.tt))),
    hpMax: field('hpMax', () => fields.hpMax.parse(integer(draft.hpMax))),
    ...(draft.sp === undefined
      ? {}
      : { sp: field('sp', () => parseSP(draft.sp!)) }),
    ...(draft.failureThreshold === undefined
      ? {}
      : {
          failureThreshold: field('failureThreshold', () =>
            parseFailureThreshold(draft.failureThreshold!),
          ),
        }),
    ...(draft.statblock
      ? {
          statblock: field('statblock', () =>
            parseStatblockDraft(draft.statblock!),
          ),
        }
      : {}),
    ...(draft.loadout
      ? { loadout: field('loadout', () => parseLoadoutDraft(draft.loadout!)) }
      : {}),
    ...(draft.capabilities
      ? {
          capabilities: field('capabilities', () =>
            parseCapabilitySetup(draft.capabilities!),
          ),
        }
      : {}),
    speeds: field('speeds', () => parseSpeeds(draft.speedsText)),
    injuryTrack: field('injuryTrack', () =>
      injuryTrackSchema.parse({
        enabled: draft.injuryEnabled ?? false,
        initialLevel: draft.injuryEnabled
          ? integer(draft.initialInjuryLevel ?? '0')
          : 0,
      }),
    ),
    cowardicePercent: field('cowardicePercent', () =>
      parseCowardice(draft.cowardicePercent ?? ''),
    ),
  };
  if (issues.length) throw new z.ZodError(issues);
  return enemyTemplateSchema.parse(candidate);
}
