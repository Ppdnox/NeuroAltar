import { applyHandbookCorrections } from './handbookCorrections';
import handbook from './handbook-pages.v1.json';
import tables from './tables.v1.json';
import handbookTables from './handbook-tables.v1.json';
import notes from './trade-notes.v1.json';
import rawRules from '../equipment/market-rules.v1.json';
import { marketRulesSchema, TRADE_COLORS } from '../../domain/market';
import {
  knowledgeEntriesSchema,
  type KnowledgeEntry,
  type KnowledgeTable,
} from '../../domain/knowledge';

function tradeTable(
  id: string,
  title: string,
  range: string,
  headers: string[],
  rows: string[][],
  explanation = notes.notes,
): Omit<KnowledgeEntry, 'handbook'> {
  const table: KnowledgeTable = {
    kind: 'table',
    columns: headers.map((label) => ({ label, unit: null, source: range })),
    rows: rows.map((row, i) => ({
      id: String(i),
      cells: row.map((text) => ({ text, source: range })),
    })),
  };
  return {
    id,
    title,
    category: 'Handel',
    tags: ['MODYFIKATORY'],
    blocks: [table, { kind: 'text', text: explanation, source: 'J13' }],
    source: { sheet: 'MODYFIKATORY', range },
    createdAt: '2026-09-12T00:00:00Z',
    updatedAt: '2026-09-12T00:00:00Z',
  };
}
export function listKnowledge(): KnowledgeEntry[] {
  const rules = marketRulesSchema.parse(rawRules);
  const categories = Object.keys(rules.regions.detroit!.priceMultipliers);
  const mult = (n: number) =>
    `×${n.toLocaleString('pl-PL', { maximumFractionDigits: 2 })}`;
  const trades = [
    tradeTable(
      '967c6081-0d1a-48e4-a1e0-4d16407be701',
      'Modyfikatory cen regionalnych',
      'A4:H17',
      ['Region', ...categories],
      [
        ['N/D — brak modyfikacji', ...categories.map(() => '×1')],
        ...Object.values(rules.regions).map((r) => [
          r.label,
          ...categories.map((category) => mult(r.priceMultipliers[category]!)),
        ]),
      ],
    ),
    tradeTable(
      '967c6081-0d1a-48e4-a1e0-4d16407be702',
      'Modyfikatory dostępności',
      'J4:L10',
      ['Lokalizacja', 'Zmiana dostępności (p.p.)', 'Przykład handlarza'],
      [
        ['N/D — brak modyfikacji', '0', '—'],
        ...Object.entries(rules.locations).map(([id, r]) => [
          r.label,
          `${r.availabilityDelta > 0 ? '+' : ''}${r.availabilityDelta}`,
          notes.traders[id as keyof typeof notes.traders],
        ]),
      ],
    ),
    tradeTable(
      '967c6081-0d1a-48e4-a1e0-4d16407be703',
      'Kolory Neuroshimy',
      'N4:Q11',
      ['Kolor', 'Mnożnik ceny', 'Mnożnik dostępności', 'Zakres'],
      Object.entries(TRADE_COLORS).map(([id, c]) => [
        c.label,
        mult(c.price),
        mult(c.availability),
        id === 'steel' ? 'Tylko broń i amunicja' : 'Wszystkie przedmioty',
      ]),
    ),
  ];
  return knowledgeEntriesSchema
    .parse([
      ...[...tables.entries, ...trades].map((entry) => ({
        ...entry,
        handbook: {
          title: handbook.title,
          pages: handbook.entries[entry.id as keyof typeof handbook.entries],
        },
      })),
      ...handbookTables.entries,
    ])
    .map(applyHandbookCorrections);
}
