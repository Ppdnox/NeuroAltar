# Źródło Wiedzy MG

Uzupełnienie 2026-09-27: 29 statycznych tabel z podręcznika w
`handbook-tables.v1.json`, udostępnionych obok dotychczasowych 50 wpisów.
Zakres, strony i luka wyniku 85 Tabeli Fantów: `docs/TABELE_PODRECZNIKA.md`.
Z działu postaci dodano tylko Zranienia, choroby i fobie.

Jednorazowo opracowany Suplement tabelaryczny, SHA256
829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22.
Spis wszystkich tabel, zakresów i wyłączeń: docs/WIEDZA_MG_ZRODLA.md.
47 wpisów z 13 arkuszy, 362 wiersze. Trzy dodatkowe tabele handlu generowane
z kanonicznych danych Ekwipunku; trade-notes zawiera tylko objaśnienia/przykłady.
Zachowano nagłówki, puste komórki, liczby/zakresy i procentowy format źródła.
Komórki mają własne odsyłacze źródłowe; wpisy stabilne UUIDv5, wersję i daty.
Wiedza jest katalogiem tylko do odczytu dostarczanym z aplikacją, bez reimportu.
Oryginał XLSX, kontrolne obrazy i skrypty przygotowania pozostają poza repo.

Etap 23: `handbookCorrections.ts` poprawia w pamięci dwa wpisy na zlecenie MG:
Hełmy — zniszczenie po Krytycznej ochronie (podręcznik s. 115), właściwość Długa —
wyjątek przy Szybkości celu 0 (s. 118). Bloki otrzymują dokładne źródła korekty.
Oryginalne dane Excela pozostają niezmienione; brak migracji, synchronizacji i reimportu.
