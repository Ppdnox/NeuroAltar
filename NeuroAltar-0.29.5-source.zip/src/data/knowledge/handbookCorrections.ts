import type { KnowledgeEntry } from '../../domain/knowledge';

// The immutable Excel transcription stays available for provenance checks.
// These two handbook corrections were explicitly approved by the GM.
export function applyHandbookCorrections(
  entry: KnowledgeEntry,
): KnowledgeEntry {
  const helmet = entry.id === '33a17d05-eab6-5863-9cd7-f0d4ce0d9dfe';
  const longWeapon = entry.id === '492d831e-7e24-52be-8c24-5e47994302ad';
  if (!helmet && !longWeapon) return entry;
  return {
    ...entry,
    updatedAt: '2026-09-13T00:00:00Z',
    blocks: entry.blocks.map((block) => {
      if (block.kind !== 'text') return block;
      return {
        ...block,
        text: helmet
          ? block.text + ' Hełm ulega wtedy zniszczeniu.'
          : block.text.replace(
              'chyba że Zręczność tej istoty wynosi 0.',
              'chyba że Szybkość tej istoty wynosi 0.',
            ),
        source: `Neuroshima: Ostatnia Era, s. ${helmet ? 115 : 118}`,
      };
    }),
  };
}
