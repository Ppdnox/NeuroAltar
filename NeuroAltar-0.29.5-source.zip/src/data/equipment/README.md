# Dane Ekwipunku v1

Źródło: Neuroshima_Suplement_Tabelaryczny_ulepszony (1).xlsx, jednorazowe
opracowanie 2026-09-12. SHA256:
829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22.
Oryginał pozostaje prywatny, poza repozytorium i aplikacją.

KATALOG: 299 kolejnych wierszy 5–303, każdy ma stabilne UUIDv5 i odsyłacz do wiersza.
D = nazwa, B/C = kategoria, I = kategoria ekonomiczna, J/K = cena od/do w gb,
L/M = dostępność od/do (ułamek Excela pomnożony przez 100, bez zaokrąglania),
G = opis, E/F = opisane parametry. Dla pancerzy E to TT, F to wymagana SIŁ;
dla broni palnej F to nabój. Pozycje K100/K12 są oznaczeniami źródłowej tabeli,
nie mechanizmem losowania. Formuły N–U i wybory PANEL MG nie są kopiowane.

H = waga: dokładna liczba kg w Item.weight; zakresy jako właściwość „Waga: …”.
Przy braku H, podana w C przybliżona waga pozostaje „ok.”; nie zamieniamy
jej na pewną liczbę. Inne braki = null. Nie bierzemy środka zakresu.

Typy: broń (wszystkie kategorie zaczynające się od Broń) 75; pancerz 17;
amunicja 26; narzędzia (w tym instrumenty) 34; elektronika 29; żywność 23;
paliwo 4; inne 91 (lekarstwa/prochy/różności/żywe istoty/akcesoria broni).
Żywe istoty nie stają się jedzeniem z powodu kategorii ekonomicznej ŻYWNOŚĆ.
Akcesoria broni nie otrzymują Stali; pancerze z kategorią ekonomiczną BROŃ także nie.
Nie zgadujemy kompletnego weaponProfile z mieszanych kolumn Excela.

MODYFIKATORY: regiony A7:H17, lokalizacje J7:K10 (Brak = +0 p.p.).
Kolory N7:P11 zweryfikowane z wiążącą decyzją MG; wspólna implementacja w market.ts.
Seed v1 jest niezmiennym artefaktem wydania. Transakcja i znacznik partii chronią
przed częściowym zapisem, duplikacją, przywracaniem usunięć i nadpisaniem późniejszych
zmian. Przyszłe korekty wymagają osobno zaprojektowanej migracji/wersji, nie reimportu.

W 0.25.4 `handbook-sources.v1.json` przypisuje drukowane strony podręcznika
do wszystkich 299 ID. Jest to mapa prezentacji źródeł, nie nowa wersja seedu.
`equipmentSource` zastępuje wyłącznie oryginalne źródło z katalogu; źródła MG
pozostają bez zmian. Dowody: `docs/EKWIPUNEK_STRONY.md`.
