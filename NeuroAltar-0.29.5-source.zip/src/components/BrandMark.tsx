export function BrandMark() {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      className="brand-mark"
    >
      <path
        d="M12 46V12h10l20 28V12h10v40H42L22 24v22H12Z"
        fill="currentColor"
      />
      <path d="M8 56h48" stroke="currentColor" strokeWidth="4" />
      <path d="M30 12h4M30 52h4" stroke="currentColor" strokeWidth="3" />
    </svg>
  );
}
