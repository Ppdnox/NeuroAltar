import type { CSSProperties } from 'react';
import './dedicatedIcon.css';

/** Local, decorative artwork. The mask keeps the original shape and app palette. */
export function DedicatedIcon({
  path,
  className = '',
}: {
  path: string;
  className?: string;
}) {
  const style = {
    '--dedicated-icon': `url("${import.meta.env.BASE_URL}icons/fvtt-noe/${path}")`,
  } as CSSProperties;

  return (
    <span
      className={`dedicated-icon ${className}`.trim()}
      style={style}
      aria-hidden="true"
    />
  );
}
