import { useEffect, useId, useMemo, useRef, type ReactNode } from 'react';
import {
  parseEnemyTemplateDraft,
  type EnemyTemplateDraft,
} from '../domain/enemy';
import { validationIssues } from '../domain/validation';
function target(root: HTMLElement, path: string) {
  return [...root.querySelectorAll<HTMLElement>('[data-validation-path]')]
    .filter(
      (el) =>
        path === el.dataset.validationPath ||
        path.startsWith(`${el.dataset.validationPath}.`),
    )
    .sort(
      (a, b) =>
        b.dataset.validationPath!.length - a.dataset.validationPath!.length,
    )[0];
}
function reveal(root: HTMLElement, path: string) {
  const el = target(root, path);
  if (!el) return;
  let parent: HTMLElement | null = el;
  while (parent) {
    if (parent instanceof HTMLDetailsElement) parent.open = true;
    parent = parent.parentElement;
  }
  const control = el.matches('input,select,textarea')
    ? el
    : el.querySelector<HTMLElement>('input,select,textarea,button');
  (control ?? el).focus();
  el.scrollIntoView({ block: 'center', behavior: 'smooth' });
}
export function TemplateValidation({
  value,
  error,
  children,
}: {
  value: EnemyTemplateDraft;
  error?: string | null;
  children: ReactNode;
}) {
  const issues = useMemo(() => {
    if (!error) return [];
    try {
      parseEnemyTemplateDraft(value, '00000000-0000-4000-8000-000000000001');
      return [];
    } catch (e) {
      return validationIssues(e);
    }
  }, [value, error]);
  return (
    <FieldValidation issues={issues} error={error}>
      {children}
    </FieldValidation>
  );
}
export function FieldValidation({
  issues,
  error,
  children,
}: {
  issues: ReturnType<typeof validationIssues>;
  error?: string | null;
  children: ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  const id = useId();
  useEffect(() => {
    const node = root.current;
    if (!node || !issues.length) return;
    const marked: HTMLElement[] = [];
    issues.forEach((issue, i) => {
      const el = target(node, issue.path);
      if (!el) return;
      el.classList.add('validation-target');
      el.setAttribute('aria-invalid', 'true');
      el.setAttribute('aria-describedby', `${id}-${i}`);
      marked.push(el);
    });
    reveal(node, issues[0]!.path);
    return () =>
      marked.forEach((el) => {
        el.classList.remove('validation-target');
        el.removeAttribute('aria-invalid');
        el.removeAttribute('aria-describedby');
      });
  }, [issues, id]);
  return (
    <div ref={root}>
      {error && (
        <div className="validation-errors" role="alert">
          {issues.length ? (
            <>
              <strong>Popraw wskazane pola:</strong>
              <ul>
                {issues.map((issue, i) => (
                  <li id={`${id}-${i}`} key={`${issue.path}-${i}`}>
                    <button
                      type="button"
                      onClick={() =>
                        root.current && reveal(root.current, issue.path)
                      }
                    >
                      {issue.label}: {issue.message}
                    </button>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p>{error}</p>
          )}
        </div>
      )}
      {children}
    </div>
  );
}
