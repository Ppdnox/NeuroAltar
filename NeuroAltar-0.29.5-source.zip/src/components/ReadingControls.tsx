import { useEffect, useState } from 'react';
const key = 'neuroaltar:reading-scale:v1';
const levels = [100, 115, 130, 150] as const;
function readScale() {
  try {
    const value = Number(localStorage.getItem(key));
    return levels.find((v) => v === value) ?? 100;
  } catch {
    return 100;
  }
}
export function ReadingControls() {
  const [scale, setScale] = useState(readScale);
  const index = levels.indexOf(scale);
  useEffect(() => {
    document.documentElement.style.setProperty(
      '--reading-scale',
      String(scale / 100),
    );
    try {
      localStorage.setItem(key, String(scale));
    } catch {
      /* Optional display preference. */
    }
  }, [scale]);
  return (
    <div className="reading-controls" role="group" aria-label="Rozmiar tekstu">
      <span>Tekst</span>
      <button
        type="button"
        disabled={index === 0}
        aria-label="Zmniejsz tekst"
        onClick={() => setScale(levels[index - 1]!)}
      >
        A−
      </button>
      <output aria-live="polite" aria-label="Powiększenie tekstu">
        {scale === 100 ? 'Auto' : `${scale}%`}
      </output>
      <button
        type="button"
        disabled={index === levels.length - 1}
        aria-label="Powiększ tekst"
        onClick={() => setScale(levels[index + 1]!)}
      >
        A+
      </button>
      {scale !== 100 && (
        <button type="button" onClick={() => setScale(100)}>
          Przywróć Auto
        </button>
      )}
    </div>
  );
}
