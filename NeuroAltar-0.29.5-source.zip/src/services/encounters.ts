import { openDatabase } from '../db/connection';
import { createEncounterRepository } from '../db/encounterRepository';
import type { EncounterDetails, SlotId } from '../domain/encounterDetails';

export async function saveEncounterDetails(
  id: SlotId,
  details: EncounterDetails,
  expected?: EncounterDetails,
) {
  return createEncounterRepository(await openDatabase()).updateDetails(
    id,
    details,
    expected,
  );
}
