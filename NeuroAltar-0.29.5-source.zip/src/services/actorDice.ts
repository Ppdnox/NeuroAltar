import { useParticipationStore } from '../stores/participationStore';
import { useNpcAbilityRollStore } from '../stores/npcAbilityRollStore';
import { checkContext } from '../domain/character/participation';
import { failureModifiers } from '../domain/machineFailures';
import { useDiceStore } from '../stores/diceStore';
import { useCombatStore } from '../stores/combatStore';
import { useEncounterStore } from '../stores/encounterStore';
import { useEncounterMaintenanceStore } from '../stores/encounterMaintenanceStore';
import { parseDiceFormula } from '../domain/dice';
import { exhaustionEffects } from '../domain/status';
import type { SlotId } from '../domain/encounterDetails';
import type { ActorDraft } from '../domain/combat';
export type ActorRollHandler = (
  formula: string,
  label: string,
  kind: 'test' | 'damage' | 'attack' | 'weaponAttack' | 'roll',
) => void;
export function actorRollHandler(
  slotId: SlotId,
  actor: ActorDraft,
): ActorRollHandler {
  return (formula, label, kind) => {
    if (
      useEncounterStore.getState().closing ||
      useCombatStore.getState().closing ||
      useEncounterMaintenanceStore.getState().slotId !== null
    )
      return;
    const roundNumber =
      useCombatStore.getState().drafts[slotId]?.value.roundNumber;
    if (!roundNumber) return;
    const parsed = parseDiceFormula(formula);
    const penalty =
      kind === 'test' || kind === 'attack' || kind === 'weaponAttack'
        ? exhaustionEffects(actor.effects ?? []).testPenalty
        : 0;
    const failurePenalty =
      kind === 'attack'
        ? failureModifiers(actor.enemy?.machineFailures ?? []).attack
        : 0;
    const chosenId = useNpcAbilityRollStore.getState().selected[actor.id];
    const owner = useParticipationStore
      .getState()
      .entries.find(
        (p) =>
          p.encounterId === slotId &&
          p.state === 'active' &&
          p.effects.some(
            (e) => e.id === chosenId && e.recipientActorId === actor.id,
          ),
      );
    const effect = owner?.effects.find((e) => e.id === chosenId);
    const targets =
      kind === 'damage'
        ? ['damage']
        : kind === 'attack' || kind === 'weaponAttack'
          ? ['attack']
          : label.startsWith('RO ')
            ? ['save']
            : ['skill'];
    const applies =
      effect &&
      ((effect.target === 'all' && kind !== 'damage') ||
        targets.includes(effect.target) ||
        (effect.target === 'attackSave' &&
          targets.some((t) => ['attack', 'save'].includes(t))));
    const ctx = checkContext(
      applies ? [{ ...effect, recipientActorId: undefined }] : [],
      targets,
    );
    const modifier = parsed.modifier - penalty + failurePenalty + ctx.modifier;
    const input = `${(parsed.groups ?? [{ count: parsed.count, sides: parsed.sides }]).map((g) => `${g.count}k${g.sides}`).join('+')}${modifier >= 0 ? '+' : ''}${modifier}`;
    const purpose =
      kind === 'attack' || kind === 'weaponAttack'
        ? 'attack'
        : kind === 'damage'
          ? 'damage'
          : undefined;
    const name = label.replace(/^(?:Atak|Obrażenia|Rzut) — /, '');
    const weapon = actor.enemy?.loadout?.items
      .filter(
        (e) => name === e.item.name || name.startsWith(e.item.name + ' — '),
      )
      .sort((a, b) => b.item.name.length - a.item.name.length)[0];
    const sourceKey = weapon
      ? `item:${weapon.item.id}`
      : `ability:${name.toLocaleLowerCase('pl-PL')}`;
    const state = useDiceStore.getState();
    state.setOpen(true);
    void state.roll(
      input,
      {
        ...(purpose ? { purpose, sourceKey } : {}),
        ...(actor.enemy?.statblock?.traits?.some(
          (t) => /^Krwawa łaźnia:/i.test(t) && /potraja/.test(t),
        )
          ? { criticalMultiplier: 3 as const }
          : {}),
        ...(applies && effect.nextRoll && owner
          ? {
              consumedEffects: [effect.id],
              effectOwnerActorId: owner.actorId,
              participationRevision: owner.revision,
            }
          : {}),
        encounterId: slotId,
        actorId: actor.id,
        actorName: actor.displayName.trim(),
        roundNumber,
        label: `${label}${penalty ? ` (Wyczerpanie −${penalty})` : ''}${failurePenalty ? ` (awarie ${failurePenalty})` : ''}`,
      },
      undefined,
      parsed.count === 1 && parsed.sides === 20
        ? { mode: ctx.mode }
        : undefined,
    );
  };
}
