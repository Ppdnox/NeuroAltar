import { invoke } from '@tauri-apps/api/core';
import { openDatabase } from '../db/connection';
import { diceRollSchema, type DiceRoll } from '../domain/dice';
export async function saveInitiativeRoll(roll: DiceRoll, revision: number) {
  await openDatabase();
  await invoke('save_initiative_roll', {
    roll: diceRollSchema.parse(roll),
    revision,
  });
}
