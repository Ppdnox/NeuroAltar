import { openDatabase } from '../db/connection';
import { createCombatLogRepository } from '../db/combatLogRepository';
export async function loadCombatLog(encounterId: number, beforeId?: number) {
  return createCombatLogRepository(await openDatabase()).page(
    encounterId,
    beforeId,
  );
}
