import { create } from 'zustand';
import type { Character } from '../domain/character/model';
import {
  characterCombatValues,
  checkContext,
  type Participation,
} from '../domain/character/participation';
import { useDiceStore } from '../stores/diceStore';
import { useCombatStore } from '../stores/combatStore';
import { parseDiceFormula, rollDice, type DiceRoll } from '../domain/dice';
import type { SlotId } from '../domain/encounterDetails';
import { characterRollConditions } from '../domain/character/rollConditions';
export const defaultRollSettings = { adv: false, dis: false, manual: '' };
export const characterRollSettings = create<{
  values: Record<string, typeof defaultRollSettings>;
  set: (id: string, p: Partial<typeof defaultRollSettings>) => void;
}>((set) => ({
  values: {},
  set: (id, p) =>
    set((s) => ({
      values: {
        ...s.values,
        [id]: { ...defaultRollSettings, ...s.values[id], ...p },
      },
    })),
}));
export async function rollCharacter(
  record: Character,
  p: Participation | undefined,
  formula: string,
  label: string,
  targets: string[],
  purpose?: 'attack' | 'damage',
  sourceKey?: string,
  disadvantage = false,
) {
  const dice = useDiceStore.getState();
  if (dice.busy || dice.pending) return;
  try {
    const { adv, dis, manual } =
      characterRollSettings.getState().values[record.id] ?? defaultRollSettings;
    const v = characterCombatValues(record, p)!;
    const fixed =
      purpose !== 'damage'
        ? characterRollConditions(record, targets)
        : { advantage: [], disadvantage: [], consumedBenefits: [] };
    if (record.draft && fixed.consumedBenefits.length)
      throw Error(
        'Zapisz lub odrzuć rozwój przed rzutem zużywającym efekt posiłku.',
      );
    const slot = p?.encounterId as SlotId | undefined;
    const combat = slot
      ? useCombatStore.getState().drafts[slot]?.value
      : undefined;
    const actor = combat?.actors.find((a) => a.id === p?.actorId);
    const statuses = new Set(actor?.effects?.map((e) => e.systemKey));
    const penalty =
      2 *
      Math.min(
        6,
        v.condition.exhaustion.reduce((n, e) => n + e.level, 0),
      );
    const selectedWeapon = record.inventory?.entries.find(
      (e) => sourceKey?.split(':')[1] === e.id,
    );
    const sourceMode = sourceKey?.split(':')[2];
    const applicable = (p?.effects ?? [])
      .filter(
        (e) =>
          (e.target === 'all' && purpose !== 'damage') ||
          targets.includes(e.target) ||
          (e.target === 'attackSave' &&
            targets.some((t) => ['attack', 'save'].includes(t))) ||
          (e.target === 'intTools' &&
            targets.some((t) => t === 'int' || t === 'tool')),
      )
      .filter((e) => {
        if (e.recipientActorId) return false;
        if (e.sourceRuleId === 'resource:trajectory')
          return (
            purpose === 'attack' &&
            selectedWeapon?.item.weaponProfile?.attackKind === 'ranged'
          );
        if (e.sourceRuleId === 'resource:rage')
          return purpose === 'damage' && targets.includes('str');
        if (e.sourceRuleId === 'class.zlodziej.1.1')
          return purpose === 'damage' && targets.includes('dex');
        if (e.sourceRuleId === 'profession.preacher.2')
          return (
            purpose === 'damage' &&
            !!selectedWeapon?.weapon &&
            ['short', 'intermediate', 'long', 'heavy'].includes(
              selectedWeapon.weapon.category,
            )
          );
        if (e.sourceRuleId === 'feat.steady')
          return (
            purpose === 'attack' &&
            selectedWeapon?.item.weaponProfile?.attackKind === 'ranged' &&
            !['short', 'long', 'massive'].includes(sourceMode ?? '')
          );
        return true;
      });
    const checkBonuses =
      purpose !== 'damage'
        ? applicable
            .filter((e) => e.checkDice)
            .map((e) => ({ label: e.label, roll: rollDice(e.checkDice!) }))
        : [];
    const ctx = checkContext(
      applicable,
      targets,
      adv ||
        fixed.advantage.length > 0 ||
        (p?.state === 'active' &&
          targets.includes('save') &&
          targets.some((t) => t === 'dex' || t === 'wis') &&
          v.derived.rules.some((r) => r.id === 'profession.soldier.1')) ||
        (targets.includes('skill:perception') &&
          v.derived.classLevels.zwiadowca >= 7),
      dis ||
        fixed.disadvantage.length > 0 ||
        disadvantage ||
        (targets.includes('attack') &&
          ['blinded', 'prone', 'restrained'].some((s) =>
            statuses.has(s as never),
          )) ||
        (!targets.includes('save') &&
          ['poisoned', 'frightened'].some((s) => statuses.has(s as never))) ||
        (v.equipment.untrained &&
          targets.some((t) => ['str', 'dex'].includes(t))) ||
        (targets.includes('attack') &&
          v.equipment.encumbrance.attackDisadvantage),
    );
    ctx.modifier += checkBonuses.reduce(
      (sum, bonus) => sum + bonus.roll.total,
      0,
    );
    const consumed = applicable.filter(
      (e) => e.nextRoll && e.sourceRuleId !== 'resource:luck',
    );
    const bonusDice =
      purpose === 'damage'
        ? applicable
            .filter((e) => e.target === 'damage' && e.damageDice)
            .map((e) => '+' + e.damageDice)
            .join('')
        : '';
    const check = purpose !== 'damage';
    const base = check ? Number(formula) : 0;
    const weapon = record.inventory?.entries.find(
      (e) => sourceKey?.split(':')[1] === e.id,
    );
    const multiplier =
      weapon?.item.weaponProfile?.attackKind === 'melee' &&
      v.derived.classLevels.brutal >= 11
        ? 3
        : 2;
    const berserk =
      purpose === 'damage' &&
      targets.includes('str') &&
      (p?.effects ?? []).some((e) => e.label === 'Berserk')
        ? `+1k${6 + 2 * Math.floor((v.derived.classLevels.brutal - 1) / 3)}`
        : '';
    const parsed = check ? null : parseDiceFormula(formula.replace(/−/g, '-'));
    const damageModifier = (parsed?.modifier ?? 0) + ctx.modifier;
    const damageBase = parsed
      ? (parsed.groups ?? [{ count: parsed.count, sides: parsed.sides }])
          .map((g) => `${g.count}k${g.sides}`)
          .join('+') +
        berserk +
        bonusDice
      : '';
    const final = check
      ? `1k20${base - penalty + ctx.modifier >= 0 ? '+' : ''}${base - penalty + ctx.modifier}`
      : damageBase +
        (damageModifier
          ? `${damageModifier >= 0 ? '+' : ''}${damageModifier}`
          : '');
    const context: DiceRoll['context'] =
      p && combat
        ? {
            encounterId: p.encounterId as SlotId,
            actorId: p.actorId,
            ...(consumed.length
              ? {
                  consumedEffects: consumed.map((e) => e.id),
                  participationRevision: p.revision,
                }
              : {}),
            actorName: v.name.slice(0, 200),
            roundNumber: combat.roundNumber,
            label: (
              label +
              (manual && check ? ' — wynik ręczny' : '') +
              checkBonuses
                .map((b) => `; ${b.label}: ${b.roll.formula}=${b.roll.total}`)
                .join('')
            ).slice(0, 200),
            ...(purpose
              ? {
                  purpose,
                  sourceKey,
                  criticalMultiplier: multiplier,
                  criticalAt:
                    v.sheet.rulesContext.gameColor === 'steel' ? 19 : 20,
                }
              : {}),
          }
        : null;
    dice.setOpen(true);
    await dice.roll(
      final,
      context,
      context ? undefined : { characterId: record.id, name: v.name, label },
      check
        ? {
            mode: ctx.mode,
            ...(manual ? { manual: Number(manual) } : {}),
            characterCheck: {
              characterId: record.id,
              targets,
              ...(fixed.consumedBenefits.length
                ? {
                    expectedRevision: record.revision,
                    consumedBenefits: fixed.consumedBenefits,
                  }
                : {}),
            },
          }
        : undefined,
    );
  } catch (e) {
    useDiceStore.setState({ inputError: String(e) });
    useDiceStore.getState().setOpen(true);
  }
}
