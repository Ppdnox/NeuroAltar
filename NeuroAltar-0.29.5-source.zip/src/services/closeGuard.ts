import { useNavigationStore } from '../stores/navigationStore';
import { invoke, isTauri } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { useEncounterStore } from '../stores/encounterStore';
import { useCombatStore } from '../stores/combatStore';
import { prepareAppClose } from './prepareAppClose';

let installation: Promise<void> | undefined;
export function installCloseGuard(): Promise<void> {
  if (!isTauri()) return Promise.resolve();
  installation ??= (async () => {
    let handling = false;
    const unlisten = await listen('neuroaltar-close-requested', async () => {
      if (handling) return;
      handling = true;
      try {
        if (await prepareAppClose()) {
          await invoke('finish_exit');
        }
      } catch {
        useNavigationStore.getState().revealCloseIssue();
        useCombatStore.setState({ closing: false });
        useEncounterStore.setState({
          closing: false,
          closeError: 'Nie udało się zamknąć aplikacji. Spróbuj ponownie.',
        });
      } finally {
        handling = false;
      }
    });
    try {
      await invoke('enable_close_guard');
    } catch (error) {
      unlisten();
      throw error;
    }
  })().catch((error: unknown) => {
    installation = undefined;
    throw error;
  });
  return installation;
}
