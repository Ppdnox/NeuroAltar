import { useCombatStore } from '../stores/combatStore';
import { useDiceStore } from '../stores/diceStore';
import type { SlotId } from '../domain/encounterDetails';
// A roll fills only the existing draft. Applying a failure remains a separate command.
export async function rollFailure(
  slotId: SlotId,
  dice = useDiceStore,
  combat = useCombatStore,
) {
  const form = combat.getState().failureForm;
  const actor = combat
    .getState()
    .drafts[slotId]?.value.actors.find((a) => a.id === form?.actorId);
  const roundNumber = combat.getState().drafts[slotId]?.value.roundNumber;
  if (
    !form ||
    form.slotId !== slotId ||
    !actor ||
    !roundNumber ||
    dice.getState().busy ||
    dice.getState().pending
  )
    return;
  dice.getState().setOpen(true);
  const saved = await dice.getState().roll('1k20', {
    encounterId: slotId,
    actorId: actor.id,
    actorName: actor.displayName.trim(),
    roundNumber,
    label: 'Tabela awarii k20',
  });
  const result = saved ? dice.getState().history[0] : dice.getState().pending;
  const current = combat.getState().failureForm;
  if (result && current === form)
    combat.getState().editFailureForm({ result: String(result.total) });
}
