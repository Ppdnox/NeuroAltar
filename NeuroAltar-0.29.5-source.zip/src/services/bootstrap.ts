import { openDatabase } from '../db/connection';
import { createEncounterRepository } from '../db/encounterRepository';

export async function loadEncounterSlots() {
  const database = await openDatabase();
  return createEncounterRepository(database).listSlots();
}
