import { prepareParticipationClose } from '../stores/participationStore';
import { useCharacterStore } from '../stores/characterStore';
import { useInitiativeStore } from '../stores/initiativeStore';
import { useDiceStore } from '../stores/diceStore';
import { useNavigationStore } from '../stores/navigationStore';
import { useEncounterMaintenanceStore } from '../stores/encounterMaintenanceStore';
import { useBestiaryStore } from '../stores/bestiaryStore';
import { SLOT_IDS } from '../domain/encounter';
import { useEncounterStore } from '../stores/encounterStore';
import { useCombatStore } from '../stores/combatStore';

export async function prepareAppClose(
  encounters = useEncounterStore,
  combat = useCombatStore,
  bestiary = useBestiaryStore,
  dice = useDiceStore,
) {
  if (!prepareParticipationClose()) return false;
  const characters = useCharacterStore.getState();
  if (
    (characters.status === 'ready' || characters.dirty.length > 0) &&
    !(await characters.prepareClose())
  )
    return false;
  if (useEncounterMaintenanceStore.getState().slotId !== null) return false;
  if (!(await useInitiativeStore.getState().prepareClose())) return false;
  try {
    const [detailsSaved, combatSaved, bestiarySaved, diceSaved] =
      await Promise.all([
        encounters.getState().prepareClose(),
        combat.getState().prepareClose(),
        bestiary.getState().prepareClose(),
        dice.getState().prepareClose(),
      ]);
    if (detailsSaved && combatSaved && bestiarySaved && diceSaved) return true;
    if (!diceSaved) dice.getState().setOpen(true);
    if (bestiarySaved) bestiary.getState().setView('combat');
    const failed =
      combat.getState().failureForm?.slotId ??
      combat.getState().statblockForm?.slotId ??
      combat.getState().loadoutForm?.slotId ??
      combat.getState().capabilityForm?.slotId ??
      combat.getState().statusForm?.slotId ??
      combat.getState().enemyForm?.slotId ??
      SLOT_IDS.find((id) =>
        ['error', 'invalid'].includes(
          combat.getState().drafts[id]?.status ?? '',
        ),
      );
    encounters.setState({
      closing: false,
      ...(!combatSaved && failed ? { activeId: failed } : {}),
      closeError:
        !combatSaved || !detailsSaved
          ? 'Aplikacja pozostaje otwarta: popraw zaznaczone dane lub ponów zapis przed zamknięciem.'
          : null,
    });
    combat.setState({ closing: false });
    useNavigationStore.getState().revealCloseIssue();
    return false;
  } catch (error) {
    encounters.setState({ closing: false });
    combat.setState({ closing: false });
    bestiary.getState().setView('combat');
    useNavigationStore.getState().revealCloseIssue();
    throw error;
  }
}
