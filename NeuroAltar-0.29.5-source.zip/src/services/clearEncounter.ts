import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';
import type { SlotId } from '../domain/encounterDetails';
import { openDatabase } from '../db/connection';

export interface ClearRequest {
  encounterId: SlotId;
  revision: number;
  name: string;
  notes: string;
  partyLevels: number[];
}
export async function clearEncounter(request: ClearRequest) {
  await openDatabase();
  return z
    .object({
      revision: z.number().int().nonnegative(),
      updatedAt: z.iso.datetime(),
    })
    .strict()
    .parse(await invoke('clear_encounter', { request }));
}
