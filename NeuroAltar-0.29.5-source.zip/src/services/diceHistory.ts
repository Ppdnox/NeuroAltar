import { z } from 'zod';
import { invoke } from '@tauri-apps/api/core';
import { diceRollSchema, type DiceRoll } from '../domain/dice';
import { openDatabase } from '../db/connection';
import { useCombatLogStore } from '../stores/combatLogStore';
export interface DiceHistoryRepository {
  read(): Promise<DiceRoll[]>;
  criticalAttack?(
    context: NonNullable<DiceRoll['context']>,
  ): Promise<string | null>;
  write(roll: DiceRoll): Promise<void>;
}
export const localDiceHistory: DiceHistoryRepository = {
  async criticalAttack(context) {
    const db = await openDatabase();
    const rows = z.array(z.object({ payload_json: z.string() })).parse(
      await db.selectRows(
        `SELECT payload_json FROM dice_rolls
      WHERE json_extract(payload_json,'$.context.encounterId')=?
      AND json_extract(payload_json,'$.context.actorId')=?
      AND json_extract(payload_json,'$.context.sourceKey')=?
      AND json_extract(payload_json,'$.context.purpose') IN ('attack','damage')
      ORDER BY sequence DESC LIMIT 1`,
        [context.encounterId, context.actorId, context.sourceKey!],
      ),
    );
    if (!rows[0]) return null;
    const roll = diceRollSchema.parse(JSON.parse(rows[0].payload_json));
    return roll.context?.purpose === 'attack' &&
      roll.count === 1 &&
      roll.sides === 20 &&
      roll.values[0]! >= (roll.context?.criticalAt ?? 20)
      ? roll.id
      : null;
  },
  async read() {
    const db = await openDatabase();
    const rows = z
      .array(z.object({ payload_json: z.string() }))
      .parse(
        await db.selectRows(
          'SELECT payload_json FROM dice_rolls ORDER BY sequence DESC LIMIT 100',
        ),
      );
    return rows.map((row) =>
      diceRollSchema.parse(JSON.parse(row.payload_json)),
    );
  },
  async write(roll) {
    await openDatabase();
    await invoke('save_dice_roll', { roll: diceRollSchema.parse(roll) });
    if (roll.supplement || roll.characterCheck?.consumedBenefits?.length) {
      const [{ loadCharacters }, { useCharacterStore }] = await Promise.all([
        import('../db/characterRepository'),
        import('../stores/characterStore'),
      ]);
      const state = useCharacterStore.getState();
      if (!state.dirty.length && !state.locked)
        useCharacterStore.setState({ records: await loadCharacters() });
      if (roll.supplement && roll.context) {
        const [{ loadCombatSlots }, { useCombatStore }, { toCombatDraft }] =
          await Promise.all([
            import('./combat'),
            import('../stores/combatStore'),
            import('../domain/combat'),
          ]);
        const slot = (await loadCombatSlots()).find(
          (s) => s.encounterId === roll.context!.encounterId,
        );
        const draft =
          useCombatStore.getState().drafts[roll.context.encounterId];
        if (slot && draft?.status === 'saved')
          useCombatStore.setState((s) => ({
            slots: s.slots.map((v) =>
              v.encounterId === slot.encounterId ? slot : v,
            ),
            drafts: {
              ...s.drafts,
              [slot.encounterId]: {
                value: toCombatDraft(slot),
                status: 'saved',
                error: null,
              },
            },
          }));
      }
    }
    if (roll.context?.consumedEffects?.length)
      await (
        await import('../stores/participationStore')
      ).useParticipationStore
        .getState()
        .load();
    if (
      roll.context?.sourceKey?.startsWith('weapon:') &&
      roll.values[0] === 1
    ) {
      const [{ loadCharacters }, { useCharacterStore }] = await Promise.all([
        import('../db/characterRepository'),
        import('../stores/characterStore'),
      ]);
      const s = useCharacterStore.getState();
      if (!s.dirty.length && !s.locked)
        useCharacterStore.setState({ records: await loadCharacters() });
    }
    if (roll.context)
      void useCombatLogStore.getState().refresh(roll.context.encounterId);
  },
};
