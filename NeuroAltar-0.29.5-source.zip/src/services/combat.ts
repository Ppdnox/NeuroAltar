import { saveReasonSchema, type SaveReason } from '../domain/combatLog';
import { invoke } from '@tauri-apps/api/core';
import { z } from 'zod';
import { openDatabase } from '../db/connection';
import { createCombatRepository } from '../db/combatRepository';
import { combatSchema, type Combat } from '../domain/combat';

// This exact backend guard rejects before commit; other failures remain uncertain.
export const PARTICIPATION_RESET_REJECTION =
  'Najpierw zakończ udział kart BG w tej walce. Reset i czyszczenie nie odnawiają postaci.';
export function isParticipationResetRejection(error: unknown): boolean {
  return (
    (error instanceof Error ? error.message : error) ===
    PARTICIPATION_RESET_REJECTION
  );
}

export async function loadCombatSlots() {
  return createCombatRepository(await openDatabase()).listSlots();
}
export async function saveCombat(
  combat: Combat,
  reason: SaveReason = 'edit',
): Promise<number> {
  const valid = combatSchema.parse(combat);
  await openDatabase();
  // A Rust transaction owns a single pooled connection for the complete write.
  const revision = z
    .number()
    .int()
    .nonnegative()
    .parse(
      await invoke('save_combat', {
        combat: valid,
        reason: saveReasonSchema.parse(reason),
      }),
    );
  if (reason === 'advance') {
    const [{ loadCharacters }, { useCharacterStore }] = await Promise.all([
      import('../db/characterRepository'),
      import('../stores/characterStore'),
    ]);
    const state = useCharacterStore.getState();
    if (!state.locked && !state.dirty.length)
      useCharacterStore.setState({ records: await loadCharacters() });
  }
  window.dispatchEvent(new Event('character-combat-saved'));
  return revision;
}
