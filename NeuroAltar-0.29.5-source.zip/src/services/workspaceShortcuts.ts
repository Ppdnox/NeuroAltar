import { useDiceStore } from '../stores/diceStore';
import { useNavigationStore } from '../stores/navigationStore';
import { useBestiaryStore } from '../stores/bestiaryStore';

export function combatWorkspaceActive() {
  return (
    !useDiceStore.getState().open &&
    useNavigationStore.getState().page === 'gm' &&
    useBestiaryStore.getState().view === 'combat'
  );
}
