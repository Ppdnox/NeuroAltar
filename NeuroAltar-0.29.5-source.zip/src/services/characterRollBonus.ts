import type { Character } from '../domain/character/model';
import type { DiceRoll } from '../domain/dice';
import { conditionView } from '../domain/character/condition';
import { useDiceStore } from '../stores/diceStore';

export function rollBonusOptions(record: Character, original: DiceRoll) {
  if (
    !record.sheet ||
    record.draft ||
    record.archived ||
    original.supplement ||
    original.count !== 1 ||
    original.sides !== 20
  )
    return [];
  const v = conditionView(record);
  const targets =
    original.characterCheck?.targets ??
    (original.context?.purpose === 'initiative' ? ['dex', 'initiative'] : []);
  if (!targets.length) return [];
  const thief = v.derived.classLevels.zlodziej;
  const available = (id: string) =>
    v.resources.some((r) => r.id === id && r.max > (v.state.spent[id] ?? 0));
  const result: {
    id: 'toughness' | 'amen' | 'cat';
    label: string;
    sides: number;
    requiresFailure: boolean;
  }[] = [];
  if (available('toughness') && targets.includes('save'))
    result.push({
      id: 'toughness',
      label: 'Twardość',
      sides: 2 + 2 * Math.floor(v.derived.classLevels.twardziel / 3),
      requiresFailure: true,
    });
  if (available('amen'))
    result.push({ id: 'amen', label: 'Amen', sides: 6, requiresFailure: true });
  if (
    available('cat') &&
    (targets.includes('skill:acrobatics') ||
      (thief >= 5 && targets.includes('initiative')) ||
      (thief >= 9 && targets.includes('save')))
  )
    result.push({
      id: 'cat',
      label: 'Kocie kości',
      sides: 4 + 2 * Math.floor((thief - 2) / 3),
      requiresFailure: false,
    });
  return result;
}

export async function addCharacterRollBonus(
  record: Character,
  original: DiceRoll,
  id: 'toughness' | 'amen' | 'cat',
  failed: boolean,
) {
  const option = rollBonusOptions(record, original).find((o) => o.id === id);
  if (!option || (option.requiresFailure && !failed)) return false;
  const label = `${option.label}: ${original.total} + 1k${option.sides}`;
  const old = original.context;
  const context = old
    ? {
        encounterId: old.encounterId,
        actorId: old.actorId,
        actorName: old.actorName,
        roundNumber: old.roundNumber,
        label,
      }
    : null;
  const supplement = {
    originalRollId: original.id,
    characterId: record.id,
    expectedRevision: record.revision,
    resourceId: id,
    originalTotal: original.total,
    originalNatural: original.values[0]!,
    originalLabel:
      original.context?.label ?? original.characterContext?.label ?? 'Test',
    failed,
  };
  return useDiceStore
    .getState()
    .roll(
      `1k${option.sides}${original.total < 0 ? '' : '+'}${original.total}`,
      context,
      context
        ? undefined
        : { characterId: record.id, name: record.sheet!.identity.name, label },
      { supplement },
    );
}
