import { CharacterWorkspace } from '../features/character/CharacterWorkspace';
import { InitiativeRollStatus } from '../features/combat/InitiativeRoll';
import { DiceDock } from '../features/dice/DiceDock';
import { KnowledgeWorkspace } from '../features/reference/KnowledgeWorkspace';
import { EquipmentWorkspace } from '../features/equipment/EquipmentWorkspace';
import { VehicleWorkspace } from '../features/vehicles/VehicleWorkspace';
import { ReadingControls } from '../components/ReadingControls';
import { useNavigationStore } from '../stores/navigationStore';
import { ShortcutHelp } from '../features/help/ShortcutHelp';
import { useEncounterMaintenanceStore } from '../stores/encounterMaintenanceStore';
import { BestiaryWorkspace } from '../features/bestiary/BestiaryWorkspace';
import { useBestiaryStore } from '../stores/bestiaryStore';
import { useEffect } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  BookOpen,
  Car,
  Database,
  Home,
  Package,
  ShieldCheck,
  Skull,
  Swords,
  UserRound,
} from 'lucide-react';
import { useEncounterStore } from '../stores/encounterStore';
import { useCombatStore } from '../stores/combatStore';
import { installCloseGuard } from '../services/closeGuard';
import { EncounterWorkspace } from '../features/encounters/EncounterWorkspace';

async function start() {
  try {
    await installCloseGuard();
    await useEncounterStore.getState().initialize();
    if (useEncounterStore.getState().status === 'ready')
      await useCombatStore.getState().initialize();
  } catch {
    useEncounterStore.setState({
      status: 'error',
      error: 'Nie udało się uruchomić ochrony autozapisu. Ponów odczyt.',
    });
  }
}
export function App() {
  const { page, navigate, closeIssue } = useNavigationStore();
  useEffect(() => {
    const root = document.getElementById(
      page === 'gm' ? 'gm-panel' : 'home-panel',
    );
    const error =
      closeIssue && (page === 'gm' || page === 'character')
        ? (root?.querySelector<HTMLElement>('[aria-invalid="true"]') ??
          root?.querySelector<HTMLElement>(
            'form .editor-error, form .validation-errors, .enemy-form, form[aria-label]',
          ) ??
          root?.querySelector<HTMLElement>('.editor-error'))
        : null;
    const target = error || root?.querySelector<HTMLElement>('h1');
    if (!target) return;
    for (
      let parent: HTMLElement | null = target;
      parent;
      parent = parent.parentElement
    ) {
      if (parent instanceof HTMLDetailsElement) parent.open = true;
    }
    const control = target.matches('input,select,textarea')
      ? target
      : target.querySelector<HTMLElement>('input,select,textarea,button');
    if (!control && !target.matches('input,select,textarea'))
      target.tabIndex = -1;
    (control ?? target).focus({ preventScroll: true });
    if (error) target.scrollIntoView({ block: 'start' });
    else window.scrollTo({ top: 0 });
  }, [page, closeIssue]);
  const maintenance = useEncounterMaintenanceStore((s) => s.slotId !== null);
  const { view, setView } = useBestiaryStore();
  const { status, error } = useEncounterStore();
  useEffect(() => {
    void start();
  }, []);

  const openModule = (next: typeof view) => {
    setView(next);
    navigate('gm');
  };
  const library = [
    { view: 'bestiary', label: 'Bestiariusz', icon: Skull },
    { view: 'equipment', label: 'Ekwipunek', icon: Package },
    { view: 'vehicles', label: 'Pojazdy', icon: Car },
    { view: 'reference', label: 'Wiedza MG', icon: BookOpen },
  ] as const;

  return (
    <div className={`app-shell session-shell app-page-${page}`}>
      <header className="app-header session-header">
        <div className="brand-lockup">
          <div>
            <p className="brand-name">
              Neuro<span>Altar</span>
            </p>
            <p className="brand-caption">Ty prowadzisz, Altar pamięta</p>
          </div>
        </div>
        <div className="session-header-tools">
          <ReadingControls />
          <div className="header-meta">
            <span className="system-label">NEUROSHIMA 5E</span>
            <span className="local-label">
              <span className="status-dot" /> Działa lokalnie
            </span>
          </div>
        </div>
      </header>
      {page !== 'home' && status === 'ready' && <DiceDock />}
      <InitiativeRollStatus />
      <div className="workspace-frame session-layout">
        <aside className="session-sidebar">
          <nav className="session-navigation" aria-label="Obszar aplikacji">
            <div className="session-nav-group">
              <p className="session-nav-heading">Przy stole</p>
              <button
                className="session-nav-button"
                title="Start"
                aria-pressed={page === 'home'}
                disabled={maintenance}
                onClick={() => navigate('home')}
              >
                <Home size={18} aria-hidden="true" /> <span>Start</span>
              </button>
              <button
                className="session-nav-button"
                title="Karta postaci"
                aria-pressed={page === 'character'}
                disabled={maintenance}
                onClick={() => navigate('character')}
              >
                <UserRound size={18} aria-hidden="true" />{' '}
                <span>Karta postaci</span>
              </button>
              <button
                className="session-nav-button"
                title="Panel MG"
                aria-pressed={page === 'gm' && view === 'combat'}
                disabled={maintenance}
                onClick={() => openModule('combat')}
              >
                <Swords size={18} aria-hidden="true" /> <span>Panel MG</span>
              </button>
            </div>
            <div className="session-nav-group">
              <p className="session-nav-heading">Biblioteka</p>
              {library.map(({ view: next, label, icon: Icon }) => (
                <button
                  key={next}
                  className="session-nav-button"
                  title={label}
                  aria-pressed={page === 'gm' && view === next}
                  disabled={maintenance}
                  onClick={() => openModule(next)}
                >
                  <Icon size={18} aria-hidden="true" /> <span>{label}</span>
                </button>
              ))}
            </div>
          </nav>
          <div className="session-sidebar-utilities">
            <ShortcutHelp />
          </div>
          <footer className="session-sidebar-footer">
            <span>NeuroAltar · v0.29.5</span>
            <span>
              Made by Dominik
              <br />
              &quot;<em>Polakko</em>&quot; Stanisławski
            </span>
          </footer>
        </aside>
        <main className="workspace session-main">
          <div className="workspace-inner">
            <section id="home-panel" hidden={page === 'gm'}>
              {page === 'character' ? (
                <>
                  <h1 className="session-sr-only" tabIndex={-1}>
                    Karta postaci BG
                  </h1>
                  <CharacterWorkspace />
                </>
              ) : (
                <div className="session-welcome">
                  <p className="session-eyebrow">NeuroAltar</p>
                  <h1 tabIndex={-1}>Witaj przy stole</h1>
                  <p className="workspace-intro">
                    Wybierz swoją postać lub przygotuj sesję.
                  </p>
                  <div className="home-choices">
                    <button
                      className="home-choice"
                      disabled={maintenance}
                      onClick={() => navigate('character')}
                    >
                      <UserRound
                        className="home-choice-icon"
                        size={30}
                        aria-hidden="true"
                      />
                      <strong>Karta postaci</strong>
                      <span>Twoje cechy, zdolności, ekwipunek i rozwój.</span>
                      <span className="home-choice-action">
                        Otwórz karty{' '}
                        <ArrowUpRight size={18} aria-hidden="true" />
                      </span>
                    </button>
                    <button
                      className="home-choice"
                      disabled={maintenance}
                      onClick={() => openModule('combat')}
                    >
                      <Swords
                        className="home-choice-icon"
                        size={30}
                        aria-hidden="true"
                      />
                      <strong>Panel MG</strong>
                      <span>
                        Potyczki, inicjatywa i wszystko, czego potrzebujesz do
                        prowadzenia walki.
                      </span>
                      <span className="home-choice-action">
                        Przejdź do potyczek{' '}
                        <ArrowUpRight size={18} aria-hidden="true" />
                      </span>
                    </button>
                  </div>
                </div>
              )}
            </section>
            <section id="gm-panel" data-view={view} hidden={page !== 'gm'}>
              {view !== 'combat' && (
                <div className="session-page-heading">
                  <p className="session-eyebrow">Biblioteka</p>
                  <h1 tabIndex={-1}>
                    {library.find((item) => item.view === view)?.label}
                  </h1>
                  <p className="workspace-intro">
                    {view === 'bestiary'
                      ? 'Przeciwnicy gotowi do Twojej potyczki.'
                      : view === 'equipment'
                        ? 'Przedmioty, ceny i dostępność.'
                        : view === 'vehicles'
                          ? 'Pojazdy z podręcznika w jednej tabeli.'
                          : 'Zasady i tabele pod ręką.'}
                  </p>
                </div>
              )}
              <section
                className="encounters-section"
                aria-label={
                  view === 'combat'
                    ? 'Walka i potyczki'
                    : 'Zawartość biblioteki'
                }
              >
                {(status === 'idle' || status === 'loading') && (
                  <div
                    className="connection-state"
                    data-state={status}
                    role="status"
                  >
                    <Database size={15} aria-hidden="true" /> Otwieranie bazy
                    potyczek…
                  </div>
                )}
                {status === 'error' && (
                  <div role="alert" className="error-panel">
                    <AlertTriangle size={22} aria-hidden="true" />
                    <div>
                      <h3>Nie można otworzyć bazy</h3>
                      <p>{error}</p>
                      <button
                        type="button"
                        className="retry-button"
                        onClick={() => {
                          void start();
                        }}
                      >
                        Ponów odczyt{' '}
                        <ArrowUpRight size={16} aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                )}
                {status === 'ready' &&
                  (view === 'combat' ? (
                    <EncounterWorkspace />
                  ) : view === 'bestiary' ? (
                    <BestiaryWorkspace />
                  ) : view === 'equipment' ? (
                    <EquipmentWorkspace />
                  ) : view === 'vehicles' ? (
                    <VehicleWorkspace />
                  ) : (
                    <KnowledgeWorkspace />
                  ))}
              </section>
            </section>
            <div className="session-save-status" role="status">
              {status === 'ready' && (
                <>
                  <ShieldCheck size={14} aria-hidden="true" /> Zapis lokalny
                </>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
