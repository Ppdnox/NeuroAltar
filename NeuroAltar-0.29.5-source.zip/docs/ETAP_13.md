# Etap 13 — obsługa i czytelność interfejsu (0.14.0)

## Zakres

Zlecony Etap 13 po czystym commicie de17e53. Etap 14 nie został rozpoczęty.

- Alt/⌥ + ↑/↓ wybiera poprzednią/następną kartę w kolejności inicjatywy,
  następnie karty bez wyniku. Skraje nie zawijają. Wybór nie zmienia tury,
  statusów, liczników ani runtime. Nie działa podczas pisania, w modalu lub
  przy otwartych formularzach; ignoruje powtórzenia i kompozycję tekstu.
- F1 lub przycisk „Skróty i obsługa” otwiera pomoc. Dialog ma fokus, obsługę
  Tab/Shift+Tab i Escape; nie anuluje innych szkiców. Skróty slotów i walki
  nie wykonują się pod dialogiem. Spacja nie przewija tury w kontrolkach,
  a otwarty formularz przeciwnika także blokuje przechodzenie tury.
- „Pokaż bieżącą postać” wybiera kartę właściciela tury i przewija do jej
  statystyk. Fokus ustawiany po synchronicznej aktualizacji widoku, także
  gdy okno nie otrzymuje klatek animacji. Wybrana karta ma wyraźny obrys.
- Pasek rundy pozostaje widoczny podczas przewijania walki. Na dużym oknie
  również lista inicjatywy pozostaje pod ręką. W niskim oknie pasek jest
  statyczny, a przy wąskim układ przechodzi do jednej kolumny.
- Log domyślnie zwinięty przy wejściu do slotu; podsumowanie pokazuje ostatni
  wpis. Rozwinięcie udostępnia istniejącą historię, paginację i potwierdzane
  czyszczenie. Błąd odczytu odsłania panel. Zwinięcie nie usuwa wpisów.
- Bardziej zwarty nagłówek i rama, mniej miejsca na dekorację; zachowane
  kolory papier/turkus/metal. Lepszy fokus na ciemnym pasku i większe odstępy
  między przyciskami potwierdzeń. Uaktualnione instrukcje i roadmapa.

## Dane i migracje

Brak migracji. Niezmienione migracje 001–006, Rust implementujący mechaniki,
repozytoria i store autozapisu, prepared/runtime, pięć slotów, identyfikator
oraz adres bazy. Zmiany dotyczą prezentacji i intencji klawiatury. Nie ma nowych
skrótów usuwania, dice rollera, licznika amunicji ani modułów v1.1/v1.2.
Baza użytkownika nie była otwierana do testów ani zastępowana.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i **177 testów w 33 plikach — OK**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **35/35 — OK**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: produkcyjny bundle **arm64 0.14.0**, podpis ad hoc — OK.
- `git diff --check`, niezmienione migracje i kod persistence — OK.

Nowe testy sprawdzają Spację, Alt+strzałki, ochronę pól/kontrolek/dialogu,
dodatkowe modyfikatory, autorepeat, kompozycję i anulowane zdarzenia. Nawigacja
sprawdza kolejność remisów, postacie bez inicjatywy, skraje, pusty skład i brak
mutacji listy wejściowej. Pozostałe testy regresyjne pozostają aktywne.

## Test natywny

Osobny bundle i baza `pl.neuroshima.combat-tracker.stage13-smoke`.
Sprawdzono standardowe okno 1100×760 i zmniejszone do około 683×524. Pomoc jest
czytelna, przy małej wysokości przewijana; Tab + Enter pozwala ją zamknąć.
F1, Escape i blokada ⌘2 pod modalem działają. Zrzuty potwierdziły obrys fokusu,
widoczny pasek tury i statystyki po przejściu do karty.

Dwie testowe postacie: Żaneta zwiadowczyni (inicjatywa16) i Łukasz konwojent
(inicjatywa8). Alt+↓ wybrało Łukasza, pozostawiając turę Żanety i rundę1.
Przycisk powrotu wybrał Żanetę i odsłonił statystyki. Wpisywanie polskiego tekstu
wielowierszowego oraz Alt+↑ i Spacja w polu nie zmieniły karty ani tury.
Spacja poza kontrolkami później poprawnie przesunęła turę do Łukasza.

Log zwinięty pokazywał aktualny ostatni wpis; rozwinięcie zachowało pełną
historię. Restart odtworzył postacie, polskie statusy, inicjatywy, turę i log.
Zweryfikowano ⌘Q oraz przycisk zamknięcia okna. Niedokończony formularz
przeciwnika zatrzymał ⌘Q i wyłączył nawigację/next turn. Po wpisaniu testowego
Strażnika żółtego mostu (TT14/PW28/SP8) formularz zapisano i zamknięto aplikację.

## Dostarczenie i ograniczenia

Docelowe repozytorium: `/Users/dominik/Desktop/Combat Tracker`.
Prace, testy i build wykonano w odrębnej kopii. Procedura zastosowania sprawdza
czysty bazowy HEAD, sumę patcha, zgodność końcowego drzewa i podpis aplikacji.
Docelowy bundle: `src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.14.0).
Poprzednia aplikacja pozostaje jako `NeuroAltar 0.13.0.app`; nie jest to kopia bazy.

Stan rozwinięcia logu jest lokalnym stanem widoku; powrót do slotu otwiera go
ponownie jako zwinięty. Na klawiaturach Mac F1 może wymagać Fn; zawsze dostępny
jest przycisk pomocy. Walidacja wizualna dotyczy macOS; Windows pozostaje poza
zakresem. Podpis lokalny ad hoc, bez notaryzacji dystrybucyjnej. Etap 14 wymaga
nowego zlecenia i pozostaje końcową rundą QA całej aplikacji.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DECISIONS.md`
- `docs/ETAP_13.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/UI_GUIDELINES.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/domain/shortcuts.ts`
- `src/features/combat/CombatLog.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/features/help/ShortcutHelp.tsx`
- `tests/shortcuts.test.ts`
