# Etap 9 — Broń i profile ataku (0.10.0)

## Rezultat

Ogólny Item z opcjonalnym weaponProfile oraz niezależny zestaw broni w szablonie,
instancji i stanie przygotowanym. Bestiariusz i formularz przeciwnika współdzielą
edytor PB, modyfikatorów SIŁ/ZRC, broni, formuł obrażeń, zasięgów, właściwości,
trybów ognia i wariantów amunicji. Karta walki pozwala podmienić broń i wybierać
warianty, z autozapisem i atomowym wpisem w logu.

Atak = PB + wybrany modyfikator cechy + jawne premie broni, trybu i amunicji.
Finezyjna wybiera wyższy modyfikator. Puste dane oznaczają brak danych.
Formuła obrażeń jest kompletnym tekstem MG, z ikoną kości, bez obliczania rzutu
lub dopisywania cechy. Zasięg i formułę nadpisuje kolejno amunicja, tryb, baza;
premie do ataku sumują się. N/D zeruje wybór niezależnie dla obu wariantów.

Nie powstał osobny katalog weapons. Item zachowuje typy i dane przyszłego
Ekwipunku, w tym przedziały ceny/dostępności. Edycja bojowa zachowuje metadane
handlowe. Nie dodano UI handlu, seeda, importera, kości, liczenia amunicji ani
mechaniki Etapu 10. Profile nie zmieniają PW, statusów i zasobów akcji.

## Dostarczenie i dane

Repozytorium docelowe: `/Users/dominik/Desktop/Combat Tracker`.
Baza prac: czysty commit Etapu 8 `38884fd`.
Przygotowanie i weryfikacja odbyły się w izolowanej kopii. Zastosowanie do repo
sprawdza bazowy HEAD, czystość drzewa, hash patcha oraz końcowe drzewo Git.
Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.10.0.
Poprzedni bundle zostaje jako `NeuroAltar 0.9.0.app`.

**Brak nowej migracji SQL.** Migracje 001–006 bez zmian. Opcjonalny loadout jest
przechowywany w istniejących JSON szablonu, instancji i snapshotu; stare rekordy
bez tego pola pozostają poprawne. Baza użytkownika nie była otwierana ani
odtwarzana w testach lub dostarczeniu. Zachowane pięć slotów, kolejki zapisu,
rewizje, immutable kopie szablonów, statusy, zasoby i zabezpieczenia zamykania.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i **123 testy w 25 plikach — OK**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **27/27 — OK**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: produkcyjny bundle macOS arm64 **0.10.0**, podpis ad hoc.
- Kontrola `codesign --verify --deep --strict` oraz `git diff --check`.

Nowe testy sprawdzają PB/cechy, unknown/zero, finezję, premie i priorytety wariantów,
powrót N/D, zakresy i referencje, unikalność identyfikatorów, Item bez profilu,
zachowanie metadanych/czasów oraz niezależność szablonu, instancji i prepared.
Test store sprawdza niepoprawny szkic, close guard, autozapis i reset. Rust używa
wspólnego fixture z TS i sprawdza walidację, trwałość zestawu, log oraz reset.

## Test natywny macOS

Osobna aplikacja i baza `pl.neuroshima.combat-tracker.stage9-smoke`:

- Utworzenie „Strzelec Żółw”, TT 15, PW 88, PB 4, SIŁ 2, ZRC 5.
  „Karabin Żółw”: 30/90 m, `2k8 + 3`, kłute, polski wielowierszowy opis.
  Profil pokazał +9 i czytelną ikonę kości obok formuły.
- Wybór „Seria próbna” z jawną karą −2 pokazał +7 i zapis w logu.
  PW i pule akcji pozostały niezmienione.
- „Zastąp nową bronią”: Pistolet Rdza, `1k6 + 1`. Długi zasięg 5 przy zwykłym
  10 został odrzucony; ⌘Q zachowało otwarty formularz i wszystkie wpisy.
  Poprawa do 10/30 pozwoliła zapisać zestaw, dając +9.
- Druga kopia szablonu zachowała Karabin, +9 i N/D. Stan przygotowany pierwszej
  postaci również zachował wcześniejszy Karabin, niezależnie od podmiany.
- ⌘Q zakończyło proces po zatwierdzeniu. Restart zachował dwie postacie, Pistolet,
  PB/cechy, log, PW 88 oraz wcześniejszy prepared. Bestiariusz nadal pokazał
  oryginalny Karabin, +9 i polski wielowierszowy opis.
- Zamknięcie przyciskiem okna zakończyło proces. Reset i walidację pozostałych
  wariantów sprawdzono automatycznie; nie wykonywano resetu bazy użytkownika.

## Ograniczenia przed Etapem 10

- Formuły i efekty definiuje MG. Warianty nie są prywatnym seedem reguł;
  program stosuje wyłącznie wpisane jawne modyfikatory. Brak automatycznych
  efektów specjalnych i rzutów. Pełny Ekwipunek pozostaje w v1.1.
- Szkic formularza jest chroniony przy zwykłym zamknięciu i ⌘Q, ale nie przetrwa
  wymuszonego zabicia procesu. Zatwierdzone dane zapisują się w SQLite.
- Nie używać 0.9.0 i starszych do zapisu bazy z nowymi profilami: nie znają pola
  loadout. Kopia starego bundle'a nie cofa danych.
- Podpis ad hoc, bez notaryzacji Apple. FinderInfo dopisywane przez Pulpit jest
  sprawdzane przy dostarczeniu i usuwane wyłącznie z wygenerowanego bundle'a.
- Etap 10 wymaga osobnego zlecenia.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_9.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/item.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/domain/bestiary.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/enemy.ts`
- `src/domain/item.ts`
- `src/domain/itemDraft.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/equipment/LoadoutFields.tsx`
- `src/features/equipment/LoadoutPanel.tsx`
- `src/features/equipment/README.md`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/fixtures/loadout.json`
- `tests/loadoutStore.test.ts`
- `tests/weaponProfile.test.ts`
