## Aktualny zakres 24E — decyzja MG po przeglądzie braków

Teraz: obsługa zdolności i sztuczek w walce oraz wspólne obliczanie rzutów
z karty BG i potyczki. Gracz potwierdza warunki sytuacyjne, cel i efekt;
nie rozstrzygamy automatycznie trafienia ani nie odejmujemy PW po rzucie.

Towarzysze (BG-42) przechodzą do listy pomysłów na przyszłość, bez terminu
realizacji i bez blokowania 24E. Wykreślone z wymagań tego etapu:
automatyczne przerywanie Berserka przez stany, dalsza automatyzacja zacięć
oraz przegrzania, integracja leków z walką i tworzenie pełnej karty ze starego
uproszczonego BG. Przerwanie Berserka śledzi gracz. Zachowane już działające
ręczne funkcje nie są usuwane. Powiązanie z istniejącą kartą BG pozostaje.

Pełny odbiór testowy nastąpi po zakończeniu buildu i dalszych poprawkach,
zgodnie z ustalonym harmonogramem. Bieżące sprawdzenie kompilacji nie stanowi odbioru.
Ta decyzja ma pierwszeństwo przed starszą matrycą kompletności i historycznymi
wymaganiami testów dla każdego podetapu. Stan: [raport 24E](ETAP_24E.md).

# Karta BG — specyfikacja mechanik (Etap 24A)

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.

Stan: projekt do dalszej implementacji, 2026-09-13. Aplikacja pozostaje
w wersji 0.26.0. Żaden opisany poniżej kalkulator ani trwała karta nie jest jeszcze
wdrożony. Etapy realizacji: 24B dane i obliczenia, 24C inwentarz, 24D zasoby
i odpoczynki, 24E integracja i odbiór. Windows dopiero 25.

## Stan wdrożenia24B

Wdrożono wybory tworzenia i awansu, wieloklasowość, biegłości, statyczne
obliczenia, jawne korekty MG i dziennik. Zakres testów: ETAP_24B.md.
Decyzja MG: każdy późniejszy przyrost PW ma minimum0 po KON i Kolorze;
zmiana KON przelicza historię, ale nie leczy bieżących PW. Samouk9, Twardziel3/7/11.
Matryca obejmuje wdrożone 24B–24D oraz planowaną integrację walki w 24E. Zakres odbioru opisują raporty etapów i POPRAWKI_0.29.1.md.

## Źródła i pierwszeństwo

Źródłem zasad jest lokalny **Neuroshima: Ostatnia Era**, DarkRabbit,
`reference/NOE_dla_dominadiinteriapl.pdf`, 281 stron PDF. Wszystkie numery stron
w tej specyfikacji oznaczają strony **drukowane**; strona PDF = drukowana + 2.
SHA-256: `714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
Nie zastępować tego źródła standardowym D&D ani starszą Neuroshimą.

Wzorzec układu: [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md), cztery strony,
436 pól PDF. Arkusz Google jest pomocniczy; nie pozyskano jego formuł.
Nie wdrażamy synchronizacji/importera arkusza. Prywatne źródła pozostają poza Gitem
i dystrybucją. Poniższe zapisy są technicznymi streszczeniami reguł, nie kopią książki.

**Ostateczna decyzja MG z 2026-09-13:** Samouk Cwaniaka jest na poziomie **9**,
a profesje Twardziela rozwijają się na **3/7/11**. Ta korekta zastępuje wcześniejszą
odpowiedź z tej samej rozmowy. W tych dwóch rozbieżnościach przyjmujemy wartości
z tabel rozwoju; nie ustanawia to ogólnego pierwszeństwa tabel ani opisów.

Każda implementowana reguła otrzymuje stabilny identyfikator, nazwę źródła,
stronę, wersję definicji i test. W rejestrze rozróżnić `specified`, `needs-ruling`,
`implemented`, `verified`. Stan początkowy tego etapu: `specified` lub
`needs-ruling`, nigdy `implemented`. Testy poniżej to wymagane przypadki przyszłych
etapów, a nie raport z uruchomionych testów.

## Obliczenia i wybory

Poniższa macierz podaje bazę **N/D**. Nakładki i testy COL-01…12 określa
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md): m.in. Rdza−2PW za awans,
Rtęć−3, Stal+1, Chrom+2, zmienione odpoczynki i krytyki. Nie wyciągać z tej
bazowej tabeli wniosku, że odpoczynek zawsze trwa4/24h.

Przechowujemy wartości wejściowe i oddzielnie wyliczamy wynik ze składnikami.
Wyliczenie zwraca `value`, `components`, `conditions`, `unresolvedRuleIds`.
Brak to `null`/„Brak danych”, nie 0. Niepełny profil pokazuje, czego brakuje.
Ręczna korekta MG ma powód, zakres i informację o zastępowaniu lub dodawaniu.
Nie zapisujemy wyliczonego wyniku jako drugiego, niezależnego pola edycji.

Kolejność: historia rozwoju → stałe cechy i wybory → wyposażenie → aktywne efekty
→ kontekst konkretnego testu → korekta MG. Zastąpienia wartości nie dodają się
jak premie; alternatywne wzory TT wybiera się oddzielnie. Wariant finezyjny pozwala
wybrać SIŁ/ZRC; korzystniejszy może być podpowiedzią, nie nieodwołalnym wyborem.
Ułatwienie i Utrudnienie mają listy przyczyn; obecność obu znosi je niezależnie
od liczby źródeł. Nie kasować przyczyn podczas wyliczania wyniku.

Wartości prezentacyjne pokazywać do najwyżej dwóch miejsc po przecinku.
Nie zaokrąglać składników przed sumowaniem. **Decyzja MG: gdy mechanika wymaga
zaokrąglenia, zawsze w dół**, również przy produkcji; zastępuje to podręcznikowe
wyjątki zaokrąglania w górę. Nie oznacza zamiany masy0,25kg na0kg ani usunięcia
poprzedniego wymagania prezentacji do dwóch miejsc po przecinku.

| ID / etap   | Reguła i źródło                                      | Obliczenie / decyzja                                                                                                                                                        | Wymagany test                                                                                                                               |
| ----------- | ---------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| BG-01 / B   | Cechy, s. 12–13, 49–51                               | SIŁ, ZRC, KON, INT, MDR, CHA; modyfikator `floor((cecha−10)/2)`                                                                                                             | 8→−1, 9→−1, 10→0, 17→3, 20→5; null pozostaje null                                                                                           |
| BG-02 / B   | Tworzenie, s. 49–51                                  | Tablice 15/14/13/12/10/8, 15/15/15/8/8/8, 15/12/12/12/12/10 albo zakup za 27 pkt; koszty 8:0, 9:1, 10:2, 11:3, 12:4, 13:5, 14:7, 15:9                                       | Sześć przypisań bez duplikowania pozycji; 15/15/15/8/8/8 koszt 27; 28 odrzucone                                                             |
| BG-03 / B   | Kolejność tworzenia, s. 48–54                        | Klasa, cechy, pochodzenie, sztuczka lub 50 gb, uzupełnienie; ulubiona cecha klasy ≥15; na starcie limit cechy 18                                                            | Premia tej samej dopiero wybieranej sztuczki nie służy spełnieniu jej wymagania; brak wyboru blokuje zakończenie, nie zapis szkicu          |
| BG-04 / B   | Pochodzenia, s. 60–65                                | +1 do dwóch wskazanych cech i jedna z trzech zdolności; zachowanie opisowe/losowane k4                                                                                      | 12 pochodzeń × 3 wybory; druga zdolność wymaga Patrioty/Speca, nie przyznawać wszystkich                                                    |
| BG-05 / B   | Awans, s. 56–59                                      | Progi PD poziomów 1–12: 0/50/150/300/500/800/1100/1400/1900/2400/2900/3400; PB=2+floor((łączny poziom−1)/4)                                                                 | 49/50, 499/500, 1899/1900, 3399/3400; PB na 4/5/8/9; brak poziomu 13                                                                        |
| BG-06 / B   | Rozwój i wieloklasowość, s. 58–59                    | Kolejność nabywania poziomów zachowana; ulubiona cecha nowej klasy ≥15; PB z sumy poziomów; zdolności z poziomu klasy                                                       | Brutal 3/Złodziej 2: PB3, zdolności odpowiednio 3/2; nie dostaje pełnego zestawu startowego drugiej klasy                                   |
| BG-07 / B   | PW/KW, s. 51–52, 58–59 i klasy                       | Pierwszy poziom 16+KON (B/T/Zwi) albo 12+KON (C/S/Zło); dalsze 4+KON lub 3+KON. KW k8/k6 osobno                                                                             | Brutal3/Złodziej2, KON14: 16+2+2×6+2×5=40 PW, 3k8 i 2k6; nie 52 PW                                                                          |
| BG-08 / B   | Zmiana KON, s. 58                                    | Stały wzrost modyfikatora KON przelicza PW za każdy poziom. Przeliczyć historię, nie dopisywać premii drugi raz                                                             | Poprzednia postać KON14→16: 40→45 PW; zapis/restart nie daje kolejnych +5; bieżące PW nie leczą się od samego przeliczenia                  |
| BG-09 / B   | Biegłość, s. 17–20                                   | Brak=0, biegłość=PB, specjalizacja=2PB; nie dodawać PB wielokrotnie; zmiana cechy testu zachowuje biegłość                                                                  | INT16/PB3/Medycyna specjalizacja: +9; siłowe Zastraszanie zachowuje wyszkolenie                                                             |
| BG-10 / B   | Narzędzia, s. 20                                     | 22 zestawy z cechami z tabeli; instrumenty osobne wybory; brak wymaganego narzędzia uniemożliwia czynność z wyjątkami                                                       | Mały elektronik używa ZRC, nie INT; Aspiryna i miętusy dopuszcza pustą torbę z Utrudnieniem                                                 |
| BG-11 / B,E | Testy, s. 13–17                                      | k20+premia, Ułatwienie=max(2k20), Utrudnienie=min; przerzut całego testu i przyjęcie nowego wyniku                                                                          | Ułatwienie×2 + Utrudnienie×1 → zwykły rzut; naturalne 20 nie gwarantuje zwykłego testu cechy                                                |
| BG-12 / B,E | Inicjatywa i percepcja, s. 51–52, 98, 105, 107, 259  | Inicjatywa ZRC plus uprawnione premie; PP=10+Percepcja, stałe Ułatwienie +5; Zaskoczenie utrudnia inicjatywę                                                                | MDR12/PB2/biegłość PP13; Wyczulone zmysły PP18; Szybki Bill dodaje PB tylko do inicjatywy                                                   |
| BG-13 / B,C | TT, s. 51, 114–115 i klasy                           | Jedna baza (bez pancerza 10+ZRC, pancerz wg profilu, Goła klata lub Tarcza Wiary), potem dozwolone dodatki                                                                  | ZRC3/KON2 Goła klata15; nie dodawać CHA do tej bazy; hełm wyłącza Gołą klatę; brak profilu pancerza to brak wyniku                          |
| BG-14 / B,C | Pancerz, s. 114–115                                  | Ograniczenie ZRC, SIŁ poniżej wymagania −4,5m, brak wyszkolenia Utrudnienie testów SIŁ/ZRC; tarcza wymaga ręki, siły i biegłości                                            | Zdjęcie pancerza usuwa tylko jego kary; Trening w zbroi usuwa karę skradania, nie automatycznie pływania                                    |
| BG-15 / B,E | Atak i obrażenia, s. 19, 32, 53–54, 117–120          | Atak: cecha+PB jeśli biegły+premie; zwykłe obrażenia: kości+ta sama cecha+premie. Rzucana broń zachowuje cechę kategorii, finezyjna daje wybór                              | SIŁ16/PB2 siekierka rzucona: atak+5, obrażenia k6+3; brak biegłości atak+3                                                                  |
| BG-16 / E   | Krytyki, s. 32, 69, 102                              | Standard: podwójne wszystkie kwalifikujące kości, modyfikatory raz. Brutal11 krytyk wręcz: potrójne kości. Krytyk wymuszony nie mnoży ponownie krytyka z 20                 | 1k6+2k6+3 → 6k6+3; Brutal11→9k6+3; Barbarka i naturalne20 dają jeden krytyk; token raz dla aktora/broni/ataku                               |
| BG-17 / E   | Redukcja/leczenie, s. 32–34                          | Obrażenia nieujemne, połowa w dół, powielone odporności raz; leczenie do efektywnego maksimum. Rzut nie zmienia PW                                                          | 15/2→7; dwie odporności nie dają 3; wynik rzutu i krytyk nie odejmują PW celowi                                                             |
| BG-18 / D,E | Zranienia/stany, s. 32–36                            | Kumulatywnie: −4,5m; brak R; brak B; +1 Wyczerpania przy wejściu na 4; piąte śmiertelne. Każda instancja stanu osobny czas, bez wzmacniania samego stanu                    | Dwa źródła Zatrucia, usunięcie jednego nie usuwa drugiego; odświeżenie widoku nie dokłada Wyczerpania                                       |
| BG-19 / D,E | Wyczerpanie, s. 36, 258–259                          | −2×poziom do Testów k20, −1,5m×poziom; 6 śmierć; pamiętać przyczynę każdego poziomu i regułę usuwania                                                                       | Dwa poziomy: −4 i −3m; odwodnienie nie znika przed wypiciem dziennej normy; wznowienie oddechu usuwa tylko poziomy duszenia                 |
| BG-20 / D,E | Śmierć, s. 34                                        | Rzut przeciw śmierci nie jest Testem k20 ani RO z cechy; ≥10 sukces, 1 dwie porażki, 20 daje1PW; 3 sukcesy stabilizacja, 3 porażki śmierć/Ostatnia Akcja                    | Brak automatycznego PB/KON/kary zwykłych Testów k20; Twardość/Kocia nieśmiertelność działają jako jawne wyjątki; ręczne wyniki zachowane    |
| BG-21 / D,E | Zero PW i duże obrażenia, s. 34                      | Propozycja skutków jawnego wpisu: zero PW, śmierć gdy jednorazowe obrażenia ≥2×max albo max0, przy 0PW kolejny cios +1 porażka (wręcz +2)                                   | Max20: 39/40; samo ustawienie PW nie odtwarza nieznanego typu ciosu ani wielkości wcześniejszych obrażeń                                    |
| BG-22 / B,C | Udźwig, s. 257                                       | Użytkowy/maksymalny według rozmiaru: SIŁ×(1/2, 2/4, 5/10, 10/20, 20/40, 40/80) kg. Ponad użytkowy: połowa szybkości i Utrudnienie ataków; przy max: szybkość0               | Średni SIŁ14: 70kg bez kary, 70,01 połowa, 139,99 połowa, 140 zero; masa nieznana nie udaje pełnej sumy                                     |
| BG-23 / B,C | Ruch, s. 32, 36, 114, 255–259                        | Baza9m, dodatki i potrącenia z przyczynami; blokada ruchu ma pierwszeństwo; skok w dal0,3×SIŁ, wzwyż0,3×(2+modSIŁ), bez rozbiegu połowa                                     | SIŁ14: dal4,2m; wzwyż1,2m; pływanie/wspinanie oddzielne szybkości; brak ujemnego dystansu; sporne kombinacje patrz rejestr                  |
| BG-24 / C   | Inwentarz, s. 53–54                                  | Wyposażone, podręczne, niesione, plecak, zewnętrzne juki; 3 przedmioty podręczne, 4 bronie białe, 3 dystansowe; brak limitu posiadanych wierszy                             | 5. broń biała może być w plecaku; nie liczyć tej samej sztuki jako plecak+wyposażenie                                                       |
| BG-25 / C   | Masa, s. 54, 125, 144, 257                           | Suma mas jednostkowych×ilość; brak jednostki/masy widoczny. Broń, magazynki, naboje, kontenery i zawartość liczone raz                                                      | 30 naboi po0,012kg=0,36kg; przeładowanie w ramach niesionego sprzętu nie zmienia sumy; to dane testowe, nie masa podręcznikowa              |
| BG-26 / C,E | Magazynki, s. 118–120                                | Ilość ≤pojemność; zapas kompatybilny; P1, dublet2, KS3; DS 10/15/20/25/30 z mnożnikami2/3/4/5/6; MS50/100/150/200 z5/10/15/20                                               | 2 naboje nie wystarczają na KS; 1→0 wyraźny alarm; powtórzenie operacji nie zużywa drugiego naboju; nie interpolować DS12                   |
| BG-27 / C,E | Ogień i przeładowanie, s. 118–120                    | Ładowanie ≠ przeładowanie ≠ wymiana magazynka; KS/DS/MS bez modyfikatorów obrażeń, ograniczenia rundy; wyjątki sztuczek                                                     | Broń2k6: KS6k6, krytyk12k6 bez ZRC; DS20→8k6; osobny k20 DS nie jest testem trafienia; zacięcie zużywa akcję i0naboi według decyzji MG Q-08 |
| BG-28 / D   | Fuksy, s. 16, 51, 105                                | Tokeny z własnym źródłem/wygaśnięciem; pierwszy Fuks, maksymalnie3 z Fanta; jawny przerzut nie przenosi Fuksa innej postaci                                                 | Muzyk daje1+CHA odbiorców, termin24h świata; otwarcie aplikacji jutro nie kasuje tokenów                                                    |
| BG-29 / D   | Krótki odpoczynek, s. 45                             | 4h, startPW≥1, przerwania i limity aktywności; wybrane KW, KON na każdą, minimum1 łącznie; własne reguły zasobów                                                            | 2k8 wyniki3/5,KON2→12; zużywa2k8; zranienia/maxPW nie znikają; przerwany nie daje korzyści                                                  |
| BG-30 / D   | Długi odpoczynek, s. 45–46                           | 24h, sen≥6h, startPW≥1; odbudowa KW, PW do efektywnego max, uprawnione redukcje cech, zasoby i Wyczerpanie                                                                  | PW5/max30/redukcja10→20; trwała cena Doktora Braina nie znika; ręczny zasób nie odnawia się                                                 |
| BG-31 / D   | Przerwanie, s. 45–46                                 | Po≥4h przerwanego długiego korzyści krótkiego; kontynuacja+1h za przerwę; identyfikator sesji i osobnych zastosowań                                                         | 3h59 bez krótkiego,4h z krótkim; restart/retry nie przyznaje go ponownie                                                                    |
| BG-32 / D   | Odpoczynek w pancerzu, s. 115                        | Połowa KW, brak regeneracji Wyczerpania i Zranienia; zaokrąglenie/podstawa połowy patrz Q-04                                                                                | Podgląd wyjaśnia zablokowane korzyści; brak cichego „pełnego odpoczynku”                                                                    |
| BG-33 / D   | Gojenie, s. 32–33, 46                                | 3 kolejne długie odpoczynki→KON ST15, sukces−1 Zranienie, po porażce kolejna próba po następnym długim; pomoc medyczna warunkowa                                            | Dwie noce nie leczą; trzecia tylko otwiera test; brak narzędzi/proficjencji nie daje pomocy                                                 |
| BG-34 / D   | Choroby i fobie, s. 109–112                          | Dwie propozycje k8, wybór jednej; +1 cechy do18 albo odrzucenie obu−1; choroba start3dawki; szczegóły katalogu                                                              | Ponowny zapis nie daje nowych dawek/+1; etap choroby i licznik sukcesów fobii zachowane                                                     |
| BG-35 / D   | Choroba bez leków, s. 109                            | Jawny zachód słońca: KON ST10, porażka+1 stan, naturalne1+2,20 powrót do przewlekłego; hemofilia bez tego testu                                                             | 20 działa mimo modyfikatorów; to wyjątek od BG-11; brak automatycznej dawki lub postępu czasu                                               |
| BG-36 / D   | Fobie, s. 112                                        | Bodziec→MDR ST15; ponowienie koniec tury albo10min; przełamanie wg rodzaju; 3 kolejne sukcesy leczą                                                                         | Sukces/sukces/porażka/sukces nie leczy; akrofobia/pirofobia8h, pozostałe1h; wybrane ataki z premią1min                                      |
| BG-37 / D   | Choroby nabyte, s. 111                               | Popromienna ST20, szczurza ST15; porażka blokuje korzyści odpoczynków i daje Wyczerpanie; zakaźne/Death Breath z osobnymi następstwami                                      | Odpoczynek z blokadą nie odnawia klasowych pul ani PW; leczenie/licznik dni nie zależy od zegara systemowego                                |
| BG-38 / D   | Żywienie i środowisko, s. 258–259                    | Normy wg rozmiaru; średni0,5kg/2l; Dieta cud0,25kg/1l; oddzielne przyczyny głodu/pragnienia/zimna/radiacji/duszenia                                                         | Równe połowie normy nie jest „mniej niż połowa”; ciepły długi odpoczynek usuwa wszystkie poziomy z zimna, nie z głodu                       |
| BG-39 / C,D | Postój/produkcja, s. 46–47, 80–84, 144–146           | Receptura/narzędzia/surowce/czas/test; ogólnie surowce floor(cena książkowa/2), 0,5h/gb jednorazowy lub1h/gb wielorazowy, max10h pracy/dzień; szczególne schematy nadrzędne | Nie używać ceny po regionie/Kolorze; porażka zachowuje surowce wg s.145; efekt Przydasie zmienia koszt, nie czas                            |
| BG-40 / D   | Naprawa, leki, gotowanie, trening, s. 46–47, 130–146 | Jawne czynności z narzędziami, składnikami i podglądem; czyszczenie1broni/1h→1przerzut awarii najbliższej walki                                                             | Nie odnawiać każdej broni przy odpoczynku; wynik gotowania20 daje Fuks24h; medpak zużyty raz                                                |
| BG-41 / B,D | Rozwój fabularny, s. 54–58                           | Dziennik PD/spotkań/obszarów/znajomych, deduplikacja nagrody; tryb PD lub kamienie milowe; awans zatwierdzony po wyborach                                                   | Otworzenie Bestiariusza nie daje PD; pierwsze spotkanie/obszar po potwierdzeniu +5 tylko raz; zapis szkicu nie awansuje                     |
| BG-42 / E   | Towarzysze, s. 76, 83–84, 99–101, 257                | Osobny profil, właściciel/komenda i polityka tury; partner po właścicielu, wierzchowiec zrównuje inicjatywę; wyjątek tylko dla powiązanej roli                              | Zwykli przeciwnicy nadal mają niezależną inicjatywę; dron nie atakuje bez sterowania; brak liczenia amunicji NPC                            |

## Przypisania cech

Umiejętności (s. 18): SIŁ — Atletyka; ZRC — Akrobatyka, Skradanie się, Zwinne
dłonie; INT — Historia, Medycyna, Przyroda, Śledztwo, Technika; MDR — Intuicja,
Percepcja, Pojazdy, Survival, Tresura; CHA — Oszustwo, Perswazja, Występy,
Zastraszanie. KON nie ma standardowej umiejętności. Sytuacyjna zmiana cechy
przez MG nie zmienia domyślnego przypisania całej karty.

Narzędzia (s. 20), każde „małego”: SIŁ — kowala; INT — aptekarza, chemika,
hakera, jubilera, medyka, szklarza; MDR — gorzelnika, kartografa, kucharza,
rzeźnika, szulera; ZRC — charakteryzatora, elektronika, fałszerza, kłusownika,
krawca, mechanika, rusznikarza, stolarza, ślusarza, tatuażysty.

## Rejestr interpretacji — decyzje MG i pozostałe braki

Rozstrzygnięcie niepewnej kombinacji jest wymagane przed jej automatyzacją,
nie blokuje stworzenia pozostałych danych i pól w 24B. Można zapisać szkic
lub jawną korektę MG z powodem; nie ogłaszać pełnej zgodności w 24E bez rozwiązania.

| ID                           | Problem / źródło                                                                      | Zachowanie do rozstrzygnięcia                                                                                                                                                          |
| ---------------------------- | ------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Q-01 — rozstrzygnięte        | Saper, s.93                                                                           | Decyzja MG: **jedno użycie**, odnowienie po krótkim lub długim odpoczynku. Test: drugi test bez odnowienia nie dostaje efektu; krótki i długi przywracają1                             |
| Q-02                         | Pochodzenie/choroba i wiek, s. 54 vs 56                                               | Jawne opcje kampanii: choroby/fobie i uwzględnienie wieku; nie wyprowadzać automatycznie choroby z handlowego TradeContext                                                             |
| Q-03                         | Limity równe modyfikatorowi cechy bez podanego minimum (np. Spec Szybkie ręce, s. 79) | Licznik nieujemny; przy wyliczeniu ≤0 oznaczyć brak zasady minimum, nie dopisywać standardowego „minimum1”                                                                             |
| Q-04 — rozstrzygnięte24D     | Połowa KW przy spaniu w pancerzu, s.115                                               | MG: odzysk min(wydane, floor(maksimum/2)), osobno k6/k8. Maks6k8/wydane2k8 oddaje2k8; nie ma minimum1KW                                                                                |
| Q-05 — rozstrzygnięte        | Odnowienie zdolności, s.45                                                            | Decyzja MG: **długi odnawia także wszystkie zasoby odnawiane krótkim**. Nie uzupełnia amunicji ani ręcznych liczników; zachowuje jawne blokady odpoczynku choroby/pancerza             |
| Q-06 — rozstrzygnięte        | Łączenie mnożników, np. Pakowanie+Górnik, s.61,105                                    | Decyzja MG: sumować premie, nie mnożyć ich kolejno. Dwa podwojenia to baza×(1+1+1)=×3; dwa +50% to×2. Test: SIŁ14 średni,70/140kg→210/420kg, nie280/560kg                              |
| Q-07 — rozwiązane dla paczek | Masa zestawów startowych i składników                                                 | Decyzja MG: jeden Item „Zestaw startowy X” o podanej masieY, zawartość w opisie. Bez fikcyjnych mas elementów; nie doliczać jej ponownie. Dla innych przedmiotów nadal jawny brak masy |
| Q-08 — rozstrzygnięte        | Zacięcie przy pierwszym wystrzale, s.120                                              | Decyzja MG: **akcja zużyta, amunicja nie**. Atomowe zatwierdzenie zacięcia zachowuje wszystkie naboje i zużywa właściwy budżet; sam luźny rzut k20 nie jest zadeklarowanym strzałem    |
| Q-09                         | Regeneracja obniżonych cech, s. 45, kontra stała cena Doktora Braina i choroby        | Każda redukcja ma powód/odnowienie; trwałe i aktywne chorobowe zastąpienia nie znikają. Nieoznaczone legacy wymaga kwalifikacji MG                                                     |
| Q-10 — rozstrzygnięte        | Zaokrąglenia produkcji, s.145; Fabrykator s.103; Gambling we krwi s.63                | Decyzja MG: wszystkie wymagane zaokrąglenia w dół. Gambling rozstrzygnięte24C: +5pp przed mnożnikiem Koloru. Fabrykator rozstrzygnięty24D: czas−50%, 6h→3h.                            |

Nazwane zdolności, profesje, pochodzenia i sztuczki:
[KARTA_BG_KATALOG_REGUL.md](KARTA_BG_KATALOG_REGUL.md).
Trwałość i transakcje: [KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md).

### Kolejność składników ruchu i mnożników

Projekt obliczenia: najpierw bazowa szybkość plus wszystkie płaskie premie/kary,
potem suma procentowych zmian względem tej podstawy, na końcu ograniczenia
i blokady (minimum0, wymuszone0 nadrzędne). Dwie identyczne instancje tego
samego niekumulującego się stanu nie dają dwóch kar. Wyjątek konkretnej
zdolności może wymagać innego etapu działania i ma własną definicję.
To doprecyzowanie techniczne sumowania z Q-06, nie zmiana obecnych reguł NPC.
Test: baza9m,+3m,−4,5m daje7,5m; pojedyncza kara50%→3,75m; Pochwycenie→0.
Przypisana Szybkość pływania/wspinania wskazuje, czy bazuje na ruchu bazowym,
czy aktualnym, zgodnie z konkretnym opisem, bez cyklicznych zależności.

## Doprecyzowanie MG — Etap 24D, 2026-09-20

Początkową chorobę wybiera się bezpośrednio z listy albo wybiera „Nie wybieram — −1 do cechy”. Bez formularza wyników k8; analogicznie wybór fobii. Jednorazowość premii/kary i dawek pozostaje. Leki bez masy w podręczniku mają 0 kg także na istniejących kartach; jawnej masy MG nie nadpisujemy. Fabrykator: czas −50% (6 h → 3 h).
