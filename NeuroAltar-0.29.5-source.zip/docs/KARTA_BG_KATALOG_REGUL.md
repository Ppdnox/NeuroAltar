## Uzupełnienie zakresu — 2026-11-08

Katalog poniżej opisuje reguły, nie obietnicę automatyzacji każdej czynności.
Truciciel i Pogromca pozostają opisowi: produkcję, koszt i wpisanie przedmiotów
rozlicza ręcznie gracz. Zatwierdzony zakres: [STATUS](STATUS.md).

## Aktualny zakres 24E — decyzja MG po przeglądzie braków

Teraz: obsługa zdolności i sztuczek w walce oraz wspólne obliczanie rzutów
z karty BG i potyczki. Gracz potwierdza warunki sytuacyjne, cel i efekt;
nie rozstrzygamy automatycznie trafienia ani nie odejmujemy PW po rzucie.

Towarzysze (BG-42) przechodzą do listy pomysłów na przyszłość, bez terminu
realizacji i bez blokowania 24E. Wykreślone z wymagań tego etapu:
automatyczne przerywanie Berserka przez stany, dalsza automatyzacja zacięć
oraz przegrzania, integracja leków z walką i tworzenie pełnej karty ze starego
uproszczonego BG. Przerwanie Berserka śledzi gracz. Zachowane już działające
ręczne funkcje nie są usuwane. Powiązanie z istniejącą kartą BG pozostaje.

Pełny odbiór testowy nastąpi po zakończeniu buildu i dalszych poprawkach,
zgodnie z ustalonym harmonogramem. Bieżące sprawdzenie kompilacji nie stanowi odbioru.
Ta decyzja ma pierwszeństwo przed starszą matrycą kompletności i historycznymi
wymaganiami testów dla każdego podetapu. Stan: [raport 24E](ETAP_24E.md).

# Karta BG — katalog reguł do implementacji

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.

Etap 24A, 2026-09-13. Źródło i interpretacje:
[KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md). Numery stron drukowane.
Katalog określa pokrycie całej karty. W24B wdrożono katalog wyborów i statyczne
obliczenia. Ekwipunek, zasoby i odpoczynki wdrożono w 24C–24D; integracja walki pozostaje w 24E.
Nazwy są kluczami do odnalezienia reguły, skróty opisują skutki mechaniczne.
Nie generować silnika reguł przez parsowanie tych zdań ani nazw z PDF.

Każdy wybór potrzebuje `ruleId`, `sourcePage`, wymagań, poziomu nabycia,
parametrów wyboru, efektów i testu. Stabilne ID tworzyć z poniższej rodziny
i nazwy (np. `origin.asgard.nano-tech`, `class.brutal.berserk`), niezależnie od
etykiety polskiej. Każdą pozycję rozwinąć do definicji przy implementacji jej etapu.
Podpozycje (np. kilka skutków profesji) muszą dostać własne effectId.
Nie wolno pominąć zdolności fabularnej tylko dlatego, że nie dodaje liczby.

Rodziny przypadków testowych:

- **Wybór (B)**: próg wymagania −1/równo; dozwolona lista/liczba; brak duplikatów;
  nabycie tylko raz; ponowny zapis bez nowych premii; wynik po wycofaniu wyboru.
- **Stałe (B/C)**: osobne składniki; założenie/zdjęcie, typ broni, ręce, zasięg,
  próg cechy; warunek fałszywy nie daje premii; korekta nie zmienia katalogu.
- **Kontekst (E)**: właściwy cel/kategoria/odległość/zmysł; użycie własnej tury
  versus rundy; sprawdzenie obu stron progu i brak automatycznych skutków PW.
- **Pula (D)**: koszt i akcja atomowo; 0/1/max; właściwy odpoczynek; retry/restart
  bez ponownego zużycia; zmiana maksimum zachowuje historię wydatków.
- **Przerzut (E)**: właściwe kości i moment, przyjęcie nowego wyniku, zachowany
  pierwszy wynik w logu, limit użyć; naturalne 1/20 oceniane na użytej kości.
- **Postój (C/D)**: narzędzia, czas, koszty, kwalifikacja i podgląd wyniku;
  bez zasobów brak wytworzenia; ta sama operacja zastosowana raz.
- **Towarzysz (E)**: reguła zależna od właściciela, odrębne zdrowie, komenda/tura,
  brak darmowego odtwarzania/leczenia przez ponowne dodanie do slotu.

Testy pozycji dziedziczą rodzinę i dodają konkretny wyjątek wymieniony w wierszu.
Zaliczenie samych wspólnych testów nie oznacza obsługi całego katalogu.

## Kolor gry

Każda definicja działa w kontekście zasad karty.
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md) nakłada modyfikacje przyrostu PW,
odpoczynku, Fuksów, awaryjności, leczenia i krytyków. To nie tylko mnożniki cen.

## Start sześciu klas

| Klasa / strona | Wymóg; PW/KW                | RO; wybory umiejętności                                                                                                        | Narzędzia, broń, pancerz                                                         | Wieloklasowość — tylko te dodatkowe wyszkolenia               |
| -------------- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| Brutal / 67    | SIŁ15;16+KON, dalej4+KON;k8 | SIŁ/KON;2: Atletyka,Tresura,Percepcja,Przyroda,Survival,Zastraszanie                                                           | Bez narzędzi; biała/krótka; lekkie/średnie/tarcze                                | Broń i tarcze, bez nowych RO/umiejętności/pancerzy            |
| Cwaniak / 72   | CHA15;12+KON, dalej3+KON;k6 | CHA/ZRC;4: Akrobatyka,Skradanie się,Historia,Oszustwo,Perswazja,Występy,Zastraszanie,Zwinne dłonie                             | 2 instrumenty+1 zestaw; biała/krótka; lekkie                                     | 1 umiejętność z listy,1 instrument,lekkie                     |
| Spec / 78      | INT15;12+KON, dalej3+KON;k6 | INT/MDR;4: Historia,Intuicja,Medycyna,Pojazdy,Przyroda,Śledztwo,Technika                                                       | 2 zestawy; biała/krótka; lekkie                                                  | 1 umiejętność z listy,1 zestaw                                |
| Twardziel / 86 | KON15;16+KON, dalej4+KON;k8 | KON/ZRC;2: Akrobatyka,Atletyka,Intuicja,Percepcja,Pojazdy,Survival,Tresura,Zastraszanie                                        | Bez narzędzi; wszystkie bronie; wszystkie pancerze/tarcze                        | 1 umiejętność z listy,2 kategorie broni,lekkie/średnie/tarcze |
| Złodziej / 91  | ZRC15;12+KON, dalej3+KON;k6 | INT/ZRC;4: Akrobatyka,Intuicja,Oszustwo,Percepcja,Perswazja,Skradanie się,Śledztwo,Technika,Występy,Zastraszanie,Zwinne dłonie | Ślusarz; biała/miotana/krótka; lekkie                                            | 1 umiejętność z listy,ślusarz,lekkie                          |
| Zwiadowca / 96 | MDR15;16+KON, dalej4+KON;k8 | KON/MDR;3: Atletyka,Intuicja,Percepcja,Przyroda,Survival,Skradanie się,Śledztwo,Tresura                                        | Kłusownik+1 z kowal/mechanik/rzeźnik; biała/miotana/krótka/długa; lekkie/średnie | 1 wybrana umiejętność,2 kategorie broni,lekkie/średnie/tarcze |

Nowa klasa daje także swoją KW i zdolności 1. poziomu, ale nie kolejny pakiet
pełnych początkowych PW ani sprzętu. Biegłości RO nie podwajają się.
Startowy sprzęt: właściwy pakiet klasy plus wybór A (gamble) albo B (przedmioty)
z tych samych stron; należy rozdzielić pakiet obowiązkowy od alternatywy A/B.
Przykład kontrolny: Spec otrzymuje plecak i narzędzia także przy wyborze170gb.
Nazwy/masy paczek nie są globalną definicją jednego Item: „plecak turysty” Brutala
ma inną podaną masę niż Zwiadowcy. Zgodnie z decyzją MG Q-07 paczka to pojedynczy przedmiot „Zestaw startowy X”
o masieY; składniki wymienione w opisie, bez zgadywania mas każdego elementu.

## Rozwój klas

Numery oznaczają poziom **danej klasy**. Dla wszystkich poza Twardzielem:
profesja wybrana na3, dalsze zdolności na6/10 z możliwością sztuczki zamiast
zdolności na6/10; sztuczki klasy na4/8/12. Profesja raz wybrana pozostaje stała.
Twardziel: profesje **3/7/11** według ostatecznej decyzji MG, sztuczki4/6/8/10/12.
Na6 dostaje sztuczkę, na7 zdolność profesji i drugi wybór Wyjadacza.
Na każdym progu wybiera się jedną nieposiadaną zdolność danej profesji z pełnej
listy; kolejność zapisu zdolności w podręczniku nie narzuca kolejności nabywania.
Sama profesja pozostaje ustalona; korekta historii wymaga powodu MG.

| Rodzina / źródło        | Pełna lista progów i zdolności                                                                                                                                                                                                                                                                            | Parametry oraz szczególne testy                                                                                                                                                                         |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| class.brutal / 67–69    | 1 Berserk, Goła klata;2 Z bara, Wściekły cios;3 Szósty zmysł, profesja;4 sztuczka;5 Drugi atak, Brutalny cios;6 profesja/sztuczka;7 Szaleńcza szarża, Solówa;8 sztuczka;9 Paranoja;10 profesja/sztuczka;11 Zabójczy cios;12 sztuczka                                                                      | Berserk: B,10rund,2/3/4/5 użyć od1/4/7/10,kość k6/k8/k10/k12 od1/4/7/10; tylko ataki SIŁ. Wściekły cios: pula poziom×k6, max3 na atak i raz/rundę. Zabójczy cios: krytyk wręcz×3 kości, nie×2           |
| class.cwaniak / 72–73   | 1 Motywacja,Szczęście;2 Kolejka,Spieprzysz to!;3 Szybka gadka,profesja;4 Ekspert,sztuczka;5 Cwaniacki zwód,Obelga;6 profesja/sztuczka;7 Głowa do góry!;8 sztuczka;9 Samouk;10 profesja/sztuczka;11 Śmiertelna obelga;12 sztuczka                                                                          | Samouk9 wg ostatecznej decyzji MG. Motywacja k6/k8/k10 od1/5/9; Kolejka k4/k6/k8 od2/5/9 na każdą zużytą KW. Śmiertelna obelga `wynik1k6×modCHA`, nie `modCHA k6`                                       |
| class.spec / 78–79      | 1 Dobra rada,Inteligentna obrona;2 Łeb jak sklep,Szybkie badanie;3 profesja,Szybka produkcja;4 sztuczka,Szybkie ręce;5 Wykształciuch,Zdolność z pochodzenia;6 profesja/sztuczka;7 Specjalizacja,Trajektoria;8 sztuczka;9 Bystrzacha;10 profesja/sztuczka;11 W czuły punkt,Szybka produkcja(2);12 sztuczka | Łeb k4/k6/k8/k10/k12 od2/4/6/8/10. Szybka produkcja limit25gb,na11 50gb,1min/gb. Bystrzacha floor(PB/2) tylko bez biegłości. W czuły punkt +INT, z kontrolą zakazu premii obrażeń serii                 |
| class.twardziel / 86–87 | 1 Wyjadacz,Kondycha,Ulubiona broń;2 Zryw,Przycelowanie;3 profesja,Twardość;4 sztuczka;5 Drugi atak;6 sztuczka;7 profesja,Wyjadacz(2);8 sztuczka;9 Nie klękam;10 Trzeci atak+sztuczka;11 profesja;12 sztuczka                                                                                              | Ulubione modele1/2/3/4 od1/4/7/10; zamiana jednego po1h treningu podczas długiego. Twardość k4/k6/k8/k10 od3/6/9/12. Nie klękam: wszystkie RO, ale bez automatycznej biegłości w rzucie przeciw śmierci |
| class.zlodziej / 91–93  | 1 Specjalizacja,Bolesny atak,Szybkie nogi;2 Ulubiona broń,Kocie kości;3 Podstępny atak,profesja;4 Elektronik,sztuczka;5 Szybkość kota,Specjalizacja(2);6 profesja/sztuczka;7 Matrix;8 sztuczka;9 Dziewięć żyć;10 profesja/sztuczka;11 Saper;12 sztuczka                                                   | Bolesny ceil(poziom/2)k6 raz/turę, ZRC i warunek przewagi/sojusznika; Kocie k4/k6/k8/k10 od2/5/8/11. Podstępny efekt zastępuje dodatkowe obrażenia, nie dokłada ich. Saper:1użycie,odnowienieS/L (Q-01) |
| class.zwiadowca / 96–98 | 1 Mój wróg,Mój biom,Ulubiona broń;2 Kłusownik,Wyjadacz;3 Cichy krok,profesja;4 sztuczka;5 Drugi atak,Mój wróg(2);6 profesja/sztuczka;7 Sportowiec,Wyczulone zmysły;8 sztuczka;9 Mój wróg(3),Ulubiona broń(2);10 profesja/sztuczka;11 Wyjadacz(2),Pogoń;12 sztuczka                                        | Wróg1/2/3 kategorii i +1/2/3 ataku oraz1/2/3k6 od1/5/9; biomy2/3/4/5 od1/4/7/10. Sportowiec+3m, Wyczulone zmysły PP+5. Nieznana kategoria celu nie przyznaje premii                                     |

Mój wróg używa istniejących pięciu kategorii: ludzie, maszyny, mutanci, potwory,
zwierzęta. Biomy: bagna, góry, las, miasto, neodżungla, podziemia, preria,
pustynia, ruiny, tereny maszyn. Nie utożsamiać biomu z lokalizacją handlową.
Wyjadacz Twardziela: Obsługa pancerza (+2TT), Rzeźnik (+3 obrażeń przy braku
drugiej broni), Sokole oko (+3 ataku dystansowego/rzucanego), Stalowy nadgarstek
(obsługa jedną ręką, lekka krótka broń). Zwiadowca ma te cztery oraz Jeźdźca
i Zasadzkę. Powtórzony wybór tej samej opcji niedozwolony w danej liście;
łączenie zdublowanej zdolności z dwóch klas wymaga kontroli tożsamości efektu;
procentowe premie sumować wg decyzji MG Q-06, nie mnożyć kolejno.

## Zasoby i odpoczynki

`S`=krótki, `L`=długi, `S/L`=oba wymienione w opisie. `S` oznacza też odnowienie po długim — zgodnie z decyzją MG Q-05.
Zapis źródłowy zachowujemy, ale efektywny zbiór odnowień rozszerzamy o długi. „Raz na turę” i „raz na rundę”
są odrębnymi ograniczeniami, nie pulą odnowienia po odpoczynku.

| Zasób / strona                                    | Maksimum i koszt                                  | Odnowienie / ograniczenie                                           |
| ------------------------------------------------- | ------------------------------------------------- | ------------------------------------------------------------------- |
| Berserk / 67–68                                   | 2/3/4/5 od1/4/7/10;1 użycie+B                     | L;10rund, koniec w określonych stanach                              |
| Wściekły cios / 67                                | poziom Brutala kości k6;1–3                       | L;raz/rundę                                                         |
| Motywacja / 72                                    | modCHA;1+R                                        | S;18m, przed poznaniem wyniku                                       |
| Szczęście / 72–73                                 | 1/2/3/4 od1/4/7/10;1                              | L;raz/rundę                                                         |
| Spieprzysz to! / 72                               | modCHA;1+R                                        | S;po sukcesie celu, gorszy wynik                                    |
| Obelga / 73                                       | PB;1+A                                            | S;18m                                                               |
| Dobra rada / 78                                   | PB;1+B                                            | S;do początku następnej tury                                        |
| Inteligentna obrona / 78                          | modINT;1+R                                        | S;przed obrażeniami, TT+INT                                         |
| Łeb jak sklep / 78–79                             | PB kości o zmiennej wielkości;1                   | L;test INT/narzędzi                                                 |
| Szybka produkcja / 79                             | 1 użycie;limit wartości25/50gb                    | S/L;narzędzia,schemat,surowce                                       |
| Szybkie ręce / 79                                 | modZRC;1                                          | S;dodatkowe Używanie, nie dowolny Atak                              |
| Trajektoria / 79                                  | PB;1                                              | L;dodatkowo INT do ataku dystansowego                               |
| Kondycha / 86                                     | modKON;1+B                                        | L;leczenie1k8+poziom Twardziela po zatwierdzeniu                    |
| Zryw Twardziela / 87                              | 1;1                                               | S/L;dodatkowa A albo B                                              |
| Twardość / 87                                     | modKON kości;1                                    | L;po nieudanym RO, także przeciw śmierci                            |
| Kocie kości / 91–93                               | modZRC kości;1 lub więcej wg konkretnej zdolności | L;różne momenty i koszt R                                           |
| Matrix / 92                                       | PB;1                                              | L;obszarowy RO ZRC, sukces0/porażka połowa                          |
| Saper / 93                                        | 1 użycie, wg MG Q-01                              | S/L;wynik k20≤9 traktowany jako10 w umiejętności ze specjalizacją   |
| Amen / 75                                         | modCHA;1                                          | L;1k6 po nieudanym teście                                           |
| Clint — Poprawka / 88                             | 1                                                 | Na walkę;przerzut ataku bronią palną                                |
| Czas patriotów, Zawzięty sukinkot, Wierzę / 63–64 | 1 każdy                                           | L;odpowiednio +5 testu, powstanie z1PW, przedmiot≤5gb               |
| Fart / 65                                         | 1                                                 | S;przerzut naturalnej1                                              |
| Muzyk — Pieśń otuchy / 105                        | 1 wykonanie                                       | L;tokeny Fuksa odbiorców wygasają po24h gry                         |
| Czyszczenie / 46                                  | 1 przerzut dla egzemplarza                        | Najbliższa walka po wykonaniu czynności; nie uniwersalna pula klasy |

Zdolności bez limitu użyć, a z kosztem A/B/R, nie dostają sztucznej puli
„1/odpoczynek”. Każdy limit zależny od cechy obejmuje Q-03. Odpoczynek nie
tworzy amunicji/surowców/leków przez sam fakt posiadania receptury.

## Profesje — wszystkie 18

| Klasa / profesja / strony             | Dodatkowe wybory i pełna lista zdolności                                                                                        | Rodziny testów i wyjątki                                                                                                                                                                       |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Brutal/Ganger / 69                    | Pośrednia,Pojazdy; Dwóch na jednego; Ja i mój gang; Jeden z nich; Odważny czy głupi                                             | Wybór/Kontekst: +2 wręcz po ataku sojusznika, aura Berserku3m, Zastraszanie→specjalizacja jeśli biegły, strach i aura9m                                                                        |
| Brutal/Gladiator / 69–70              | Atletyka lub Akrobatyka (specjalizacja przy posiadanej), improwizowana; Nie do zdarcia; Łyżeczka; Zew areny; Zawołajcie kolegów | Stałe/Kontekst: redukcja krytyka, improwizowana wg masy i SIŁ, skoki×2 w Berserku, co najmniej2wrogów w1,5m                                                                                    |
| Brutal/Najemnik / 70                  | 2 kategorie broni,1 zestaw; Maszyna do zabijania; Reputacja; Skuteczny cios                                                     | Kontekst/Pula: B atak w Berserku, przewaga raz/rundę; negocjacje1k4×10%; kość Wściekłego ciosu wydana na efekt, nie podwójnie                                                                  |
| Cwaniak/Gwiazda / 74                  | Występy+2 umiejętności albo1+narzędzie, specjalizacja instrumentu; Kakofonia; Let’s Rock; Stylówa; Za garść gambli              | Kontekst/Postój: Kakofonia KON ST8+CHA+PB9m; Let’s Rock bonusy1–5 od wyniku5/10/15/20/25; +1/50gb luksusu na sobie; koncert4h raz/dzień                                                        |
| Cwaniak/Kaznodzieja Nowej Ery / 75    | Długa,1 umiejętność,1 zestaw; Amen; Łaska Boża; Mój Bóg kule nosi; Tarcza Wiary                                                 | Pula/Kontekst: Amen po porażce; Łaska B,18m,1k4,liczba odbiorców≤poziom; +1k10 bronią palną raz/turę; alternatywna TT10+ZRC+CHA                                                                |
| Cwaniak/Mafiozo / 75–76               | 2 kategorie broni,tatuażysta; Bezlitosny przywódca; Renoma; Moja prawa ręka                                                     | Kontekst/Towarzysz: reakcja podwładnego wymaga komendy; status członka mafii; PW pomocnika5×poziom Cwaniaka,PB stałe2                                                                          |
| Spec/Chemik / 80–81                   | Chemik,rusznikarz; Smakuje jak arszenik; Pirotechnika; Rusznikarstwo                                                            | Stałe/Postój: odporności kwas/trucizna, Ułatwienia RO; osobne receptury, narzędzia, koszty i czas                                                                                              |
| Spec/Medyk / 81–82                    | Medycyna,chemik lub medyk; Doktor Brain; Krwawy anioł; Łapiduch; Farmacja                                                       | Wybór/Postój: INT+4 max20 i stałe KON/ZRC−2; medyczna kość k6/k8/k10/k12 od3/6/9/12; reanimacja ST15/20/25/30 do1/2/4/8min, bez olbrzymich obrażeń; aptekarz                                   |
| Spec/Monter / 82–84                   | Technika,2 zestawy; Mechanika; Hakerstwo; Serwisowanie                                                                          | Postój/Towarzysz: osobne receptury i dodatkowe biegłości; dron zależny od twórcy/operatora, nie standardowa postać z klasą                                                                     |
| Twardziel/Kowboj / 88                 | Pojazdy lub Tresura,kowal,instrument; Clint; Rewolwerowiec; Zawsze w siodle                                                     | Przerzut/Stałe/Postój: dodatkowa kość rewolweru; brak zacięcia, +5 inicjatywy pod warunkiem rewolweru, pełny szybkoładowacz+B; zdobycie wierzchowca wymaga zdarzenia, nie darmowego klonowania |
| Twardziel/Wojownik Autostrady / 88–89 | Pojazdy,mechanik (specjalizacja gdy posiadane); Drzwi w drzwi; Kaskader; Pancerna fura                                          | Kontekst: prędkość pojazdu×1,5; stabilność ataku; manewry ST15; TT pasażerów+MDR tylko przy ruchu i osłonie; B sterowania                                                                      |
| Twardziel/Żołnierz / 89               | Technika,rusznikarz lub kowal; Jak dbasz, tak masz; Rutyna; Trening w zbroi                                                     | Postój/Kontekst: brak zacięcia/naprawa B, broń biała po krótkim; Ułatwienie ZRC/MDR w walce; limit ZRC pancerza+1, brak utrudnienia skradania                                                  |
| Złodziej/Kurier / 93                  | Mechanik,Pojazdy (specjalizacja gdy posiadane); Skrytka; Slang; Znajomości                                                      | Kontekst: ukrycie do małego rozmiaru; społeczne warunki; znajomość z CHA progami10/15/20                                                                                                       |
| Złodziej/Szczur / 93–94               | Chemik,Akrobatyka lub Zwinne dłonie; A co mi tam!; Szary; Truciciel; Zwinność szczura                                           | Stałe/Postój: odporności nie leczą przewlekłej choroby; INT albo MDR do skradania; trucizna10ml/długi i ST8+INT+PB; wspinanie, skoki po ZRC                                                    |
| Złodziej/Zabójca / 94                 | Charakteryzator,wszystkie bronie; Jeden strzał; Kamuflaż; Strzelec                                                              | Kontekst: pierwsza runda/przed celem albo B bez ruchu; pasujący kamuflaż;5rund celowania+celownik→daleki×3 do ruchu                                                                            |
| Zwiadowca/Łowca Mutantów / 98–99      | Przyroda lub Tresura,1 zestaw,1 kategoria broni; Bez tajemnic; Mutant na śniadanie; Pogromca; Oswajanie zwierząt                | Kontekst/Postój/Towarzysz: wiedza ST10/15/20; inicjatywa+PB tylko mutanci/potwory; Pogromca4k6,9/18m,mag1,100h/100gb, naboje za10gb każdy doPB/długi;3 profile zwierzęcia                      |
| Zwiadowca/Sędzia / 100–101            | Śledztwo,Zastraszanie,1 zestaw,1 kategoria broni; Jeden z nas; Rzuć broń i gleba!; Partner                                      | Kontekst/Towarzysz: lokalna władza; człowiek9m,MDR ST8+CHA+PB; człowiek lub pies po turze z komendąB, bez niej Unikanie                                                                        |
| Zwiadowca/Zabójca Maszyn / 101        | Technika (specjalizacja gdy posiadana),1 zestaw,1 kategoria broni,ciężkie pancerze; Emiter EMP; Empiryk; Słaby punkt            | Kontekst/Postój: EMP8k6,9/15m,6ładunków,100h/100gb; ignoruje TT pancerza, KON15; reakcjaTT+PB; wiedza ST5/10/15/20/25 wg rozmiaru                                                              |

Receptury Speca są zależnością pełnej karty, nie osobnym niezamówionym modułem
Wiedzy MG: użytkownik zapisuje uprawnienia, posiadane schematy, postęp pracy,
zużycie i wynik. Nie potrzeba symulatora warsztatu ani generatora projektów.
Przepisy ze stron80–84 mają pierwszeństwo przed ogólnym kosztem połowy ceny.
Towarzysze obejmują człowieka mafioza/sędziego, psa, owada/ssaka/gada oraz
drona kroczącego/latającego. Wymagają własnych definicji i testów s.76,83–84,99–101,
nie używać omyłkowo statblocka zwykłego psa ani automatycznych poziomów klasy.

## Pochodzenia — 12 i 36 zdolności

Każdy wiersz: dwa przyrosty +1 oraz dokładnie jeden początkowy wybór z trzech.
Test Wybór dla wszystkich; dla każdej zdolności również wymieniony warunek skutku.

| Pochodzenie / strona      | Cechy   | Zdolności i skutki do pokrycia                                                                                                                                                                          |
| ------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Asgard / 60               | KON,INT | Nówka sztuka (przedmiot≤100gb); Przedwojenna edukacja (wiedza+narzędzie); Nano-Tech (elektronika i biegłość)                                                                                            |
| Człowiek Pustyni / 60     | KON,MDR | Dieta cud (0,25kg/1l, środki lecznicze×2,kucharz); Duch pustyni (Skradanie/Survival w piachu); Polegam tylko na sobie (kowal,+1 atak/obrażenia własnoręcznej niepalnej)                                 |
| Detroit / 61              | ZRC,MDR | Siódme poty (Pojazdy,prędkość×1,5); Jeśli ma silnik, to ruszy (mechanik i prace pojazdowe); Ale jazda! (zniesienie niestabilnego podłoża)                                                               |
| Federacja Appalachów / 61 | SIŁ,CHA | Górnik z dziada pradziada (Atletyka Ułatwienie,udźwig×2); Wychuchana spluwa (jeden egzemplarz bez zacięcia,rusznikarz,zamiana/długi); Szlachetne urodzenie (2 z4 umiejętności społecznych/wiedzy)       |
| Miami / 62                | SIŁ,ZRC | Człowiek-aligator (pływanie=bazowa szybkość); Ja już swoje odchorowałem (RO KON Ułatwienie); Włóczykij (piasek/bagna,kartograf)                                                                         |
| Missisipi / 62            | SIŁ,MDR | Coś mi tu śmierdzi (mutant9m,Percepcja15 identyfikacja); Kwas w żyłach (RO trucizny/kwasy); Chodźmy, na pewno już utonął (oddech2min×KON,pływanie Ułatwienie)                                           |
| Nowy Jork / 63            | INT,CHA | Edukacja (2 biegłości z listy); Gambling we krwi (dostępność+5%,Q-10); Czas patriotów (+5 test cechy/RO raz/długi)                                                                                      |
| Południowa Hegemonia / 63 | SIŁ,KON | Urodzony morderca (jedynka kości obrażeń przerzut raz); Wiesz, zjadłem własnego psa (Zastraszanie+biegłość/Ułatwienie,rzeźnik); Zawzięty sukinkot (przed rzutem przeciw śmierci powstanie1PW raz/długi) |
| Posterunek / 64           | INT,MDR | Na symulatorach to działało (2 z4 biegłości); Hi-Tech (obsługa elektroniki Ułatwienie); Moloch? Coś słyszałem (wiedza i RO przeciw maszynom Molocha)                                                    |
| Salt Lake City / 64       | MDR,CHA | Cholerny kaznodzieja (Perswazja,warunki wiary); Przed wojną wszystko było lepsze (Historia,Medycyna,wiedza przedwojenna); Wierzę (przedmiot≤5gb raz/długi)                                              |
| Teksas / 65               | KON,CHA | Człowiek zwany koniem (2 z Atletyka,Tresura,Medycyna); Doktor Quinn (Medycyna+biegłość/Ułatwienie); Zdrowa okolica (RO KON+biegłość/Ułatwienie)                                                         |
| Vegas / 65                | ZRC,CHA | Hazardzista (Zwinne dłonie,Oszustwo); Telepata (Intuicja+biegłość/Ułatwienie); Fart (naturalna1 przerzut raz/krótki)                                                                                    |

## Sztuczki — wymagania i wyjątki

Każda: Wybór oraz Stałe/Kontekst/Pula/Postój zgodnie ze skutkiem.
Przyrosty cech na awansie z limitem20, na tworzeniu globalny limit18.
Brak powtórnego wyboru, poza Ćwiczenie czyni mistrza. Nie przyznawać
domyślnie +1 cechy sztuczkom, których opis go nie podaje.

| Strona | Sztuczka                     | Wymagania                                       | Skutki do pokrycia                                                                                   |
| ------ | ---------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| 102    | Aramis                       | SIŁ15 lub ZRC15                                 | +1SIŁ/ZRC; WytrącenieB; utrudniony RO rozbrojenia                                                    |
| 102    | Aspiryna i miętusy           | Medycyna i Oszustwo                             | +1INT/CHA; leczenie pustą torbą z Utrudnieniem                                                       |
| 102    | Barbarka                     | SIŁ15                                           | głowa k4;B wymuszony krytyk bez ponownego mnożenia; powalenie ST8+SIŁ+PB                             |
| 102    | Bez trzymanki                | ZRC15,Pojazdy                                   | +1ZRC/MDR; kierowanie bez rąk, Utrudnienie Pojazdów                                                  |
| 102    | Benzyna zamiast krwi         | MDR13,Pojazdy                                   | TT pojazdu+MDR; reakcja przejęcia ataku; Unikanie/Odstąpienie pojazdu                                |
| 102    | Ciszej niż cień              | ZRC15,Skradanie                                 | +1ZRC; przeciwnik utrudniona Percepcja                                                               |
| 102    | Człowiek-pająk               | Atletyka                                        | +1SIŁ/ZRC; wspinanie z wolnymi rękami/zestawem; schody, RO upadku                                    |
| 103    | Ćwiczenie czyni mistrza      | brak                                            | +2 jednej/+1 dwóm; jedyna jawnie wielokrotna                                                         |
| 103    | Fabrykator                   | INT18,3 narzędzia                               | +1INT/ZRC; tempo produkcji Q-10                                                                      |
| 103    | Fachowiec                    | INT11                                           | +1 dowolnej;2 narzędzia                                                                              |
| 103    | Grad ołowiu                  | ZRC15,SIŁ15                                     | KS w ramach Atakowania, według liczby ataków                                                         |
| 103    | Grenadier                    | brak                                            | +1SIŁ; odrzut granatu R w4,5m; podwojenie zasięgu rzutu                                              |
| 103    | Gunfight                     | ZRC17                                           | +1ZRC; zniesienie utrudnienia strzału przy wrogu1,5m                                                 |
| 103    | Immunitet                    | KON13,Medycyna                                  | +1KON; brak nowych chorób, Ułatwienie RO starych                                                     |
| 103    | Jest zajebiście              | CHA15,Oszustwo                                  | A test sporny kontra Intuicja; najbliższy test z Ułatwieniem tylko po porażce odbiorcy               |
| 104    | Karateka                     | brak                                            | pięść/noga k6,SIŁ albo ZRC;B atak                                                                    |
| 104    | Kuloodporność                | ZRC15 i CHA/MDR/INT15;bez pancerza/hełmu/tarczy | +PB do TT tylko przy spełnionym wyposażeniu                                                          |
| 104    | Ławnik                       | SIŁ17                                           | improwizowana ciężka≥10kg3k4,biegłość/Ułatwienie;1 niszczy; powalenie ST8+SIŁ+PB                     |
| 104    | Miotacz                      | SIŁ15,miotana                                   | zasięgi rzucanej×2;atak+2                                                                            |
| 104    | Mistrz broni białej          | INT13,ZRC15                                     | +1INT/ZRC; wybrany model dodatkowa kość; zamiana po treningu/długim                                  |
| 104    | Mistrz walki wręcz           | brak                                            | B manewr; R +k4TT wobec jednego ataku wręcz                                                          |
| 105    | Muzyk                        | CHA13                                           | +1CHA;2 instrumenty; Pieśń otuchy raz/długi                                                          |
| 105    | Neo                          | INT15,ZRC15                                     | R+5TT przed obrażeniami jednego trafienia                                                            |
| 105    | Nożownik                     | ZRC17                                           | po trafieniu nożem B kolejny atak ten sam cel, trafienie krytyczne                                   |
| 105    | Padnij/powstań               | ZRC15,KON13                                     | wstawanie bez kosztu,+3m,brak ataków okazyjnych przy odejściu                                        |
| 105    | Pakowanie                    | INT13 lub MDR13                                 | +1INT/MDR; dobycie z plecaka I;udźwig×2                                                              |
| 105    | Pancerny                     | SIŁ13,ciężki pancerz                            | przy ciężkim próg10 cięte/kłute/obuchowe, sumuje próg pancerza                                       |
| 105    | Pan Plaster                  | Medycyna                                        | +1INT/MDR;środki lecznicze dodatkowa kość; pół dawki leku wystarcza                                  |
| 105    | Patriota                     | brak                                            | +1 dowolnej; druga wybrana zdolność pochodzenia                                                      |
| 105    | Pewna ręka                   | ZRC17                                           | +1ZRC;B przed ruchem i atakiem: szybkość0,przewaga jednego ataku bez serii;stabilizacja              |
| 105    | Pierwotny instynkt           | ZRC15,MDR15,Percepcja                           | +5 inicjatywy i +5 Percepcji                                                                         |
| 105    | Plug & Play                  | Technika,haker                                  | Ułatwienie przejęcia elektroniki; haker zamiast Pojazdów przez laptop                                |
| 106    | Przycelowanie                | ZRC15                                           | +1ZRC;B,wybrana część ciała modyfikuje TT i skutek; nie kumuluje się z tą samą zdolnością klasy      |
| 106    | Robin Hood                   | ZRC15,miotana                                   | ładowanie I;B celowanie łuk/kusza                                                                    |
| 106    | Rodeo                        | MDR13,Tresura                                   | +1MDR;ujeżdżanie przyjaznego większego ST10+SIŁ celu;TT wierzchowca+PB                               |
| 106    | Przydasie                    | MDR13,Percepcja                                 | +1INT/MDR;surowce−50%, czas bez zmiany                                                               |
| 106    | Pulp Fiction                 | ZRC15                                           | +1ZRC;palna krótka/PM jedną ręką bez kary;krótka lekka                                               |
| 107    | Rozróba                      | SIŁ17                                           | +1SIŁ/KON;B osobny atak na każdego przy≥3 wrogach w1,5m                                              |
| 107    | Ruchome gniazdo CKM          | SIŁ15,KON15,pośrednia lub ciężka                | DS podwojone kości; rzeczywisty koszt dodatkowych naboi wymaga reguły, nie wnioskować z liczby kości |
| 107    | Samuraj                      | ZRC13                                           | +1SIŁ/ZRC;cięte atak/obrażenia+1;finezyjna cięta dobycie bezI,TT+1                                   |
| 107    | Siekierezada                 | SIŁ13                                           | +1SIŁ/ZRC;2siekierki dobycieI,zasięgi×2,TT+1 przy dwóch                                              |
| 107    | Snajper                      | ZRC17,MDR15                                     | +1ZRC/MDR;daleki×2 bez kary                                                                          |
| 107    | Szybkie palce                | ZRC15                                           | +1ZRC;magazynek/szybkoładowaczB;ignorowanie przeładowania,pojedynczy nabójB                          |
| 107    | Szachista                    | INT15                                           | Unikanie dajeTT+3 i brak prowokowania do początku następnej tury                                     |
| 107    | Szturmowiec                  | ZRC15,SIŁ15                                     | KS w normalnym zasięgu bez wynikającego z niej Utrudnienia                                           |
| 107    | Szybki Bill                  | ZRC15,KON17                                     | +1ZRC/KON;PB do inicjatywy;B Bieganie                                                                |
| 107    | Szkolenie w broni            | brak                                            | +1SIŁ/ZRC;1 kategoria broni                                                                          |
| 107    | Szkolenie w ciężkim pancerzu | SIŁ13,średni pancerz                            | +1SIŁ/KON;ciężki                                                                                     |
| 108    | Szkolenie w średnim pancerzu | SIŁ10,lekki pancerz                             | +1SIŁ/KON;średni                                                                                     |
| 108    | Ucz się, ucz                 | INT10                                           | +1 dowolnej;2 umiejętności                                                                           |
| 108    | Ukryty cel                   | MDR15,Percepcja                                 | ignoruje osłonę½/¾ i Utrudnienie z Unikania                                                          |
| 108    | Wrestler                     | SIŁ15                                           | +1SIŁ;Ułatwienie ataku na pochwyconego,duszenie1+SIŁ,przewrócenie ST8+SIŁ+PB                         |
| 108    | Złomiarz                     | INT13,Śledztwo                                  | +1INT/MDR;Ułatwienia wyceny/szabrowania                                                              |

## Choroby i fobie — stan oraz źródło efektu

8 przewlekłych (s.109–111): Hemofilia (krwawienie, lek/medyk/3 kolejne RO),
Niewydolność krążenia (SIŁ/KON→wszystkie testy, ruch0), Syndrom Draculi
(światło, noktowizja18m, obrażenia od ekspozycji), Syndrom Thurmana
(INT Utrudnienie→INT6→INT2 i ograniczenie broni), Szaleństwo bostońskie
(umiejętności społeczne, warunkowa furia), Osteoporoza (upadek×2/×4,
ograniczenia SIŁ/ruchu), Paranoja (Intuicja/Percepcja, społeczne, następnie
Przerażenie i tylko Unikanie), Zaburzenia błędnika (pasażer, ataki, ruch).
Każdy stan choroby ma osobny zestaw effectId; po zmianie stanu stare efekty
muszą być zastąpione zgodnie z regułą, nie bezmyślnie zsumowane lub skasowane
wraz z niezależnymi efektami. Jeśli ciągłość skutków między stanami nie jest
jednoznaczna, definicja wymaga decyzji MG przed automatyzacją.

8 fobii (s.112): Akrofobia, Arachnofobia, Klaustrofobia, Mutkofobia, Nyktofobia,
Pirofobia, Robofobia, Rodentofobia. Każda ma swój bodziec, czas przełamania,
opcjonalny bonus przeciw danemu celowi i licznik kolejnych sukcesów.
Nie zastępować wszystkich jednym stanem Przerażenie: fobie nakładają opisane
Utrudnienia, nie każdą własność Przerażenia. Test: zwykły strach i fobia mają
różne źródła; wyleczenie fobii nie usuwa efektu innej zdolności.

Nabyte: popromienna, zakaźne, Death Breath, szczurza gorączka (s.111).
Pozostałe zagrożenia i Upojenie s.256,258–259: osobne przyczyny, dawki,
przyjęte lekarstwo i termin **w świecie gry**, nigdy timer zegara komputera.
Lista musi dopuszczać więcej niż jedną chorobę/fobię mimo jednego pola na PDF.

## Bramka kompletności

Odbiór24E wymaga odwzorowania wszystkich powyższych wyborów, wyjątków i zależności,
z testami poszczególnych definicji, nie tylko działania sześciu podstawowych pól.
W24B można pokazać niewdrożony jeszcze efekt jako jawny brak związany z etapem
C/D/E. Dodatkowe niejasności znalezione podczas wdrożenia dopisywać do rejestru
Q z dokładną stroną; nie wybierać reguły z innego systemu. Nie uogólniać sukcesu
pojedynczej profesji na pełną obsługę klasy.
