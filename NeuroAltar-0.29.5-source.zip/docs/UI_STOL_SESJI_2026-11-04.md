# UI „Stół gracza + Tryb sesji” — 24E Roboczy

Prace rozpoczęte 4 listopada 2026; zakończenie i weryfikacja 5 listopada 2026.
Zakres: przebudowa prezentacji istniejącego 24E Roboczego według zaakceptowanej
makiety, z zachowaniem papierowej palety NeuroAltara.

## Zmiany widoczne w aplikacji

- Jedna lewa nawigacja: Start, Karta postaci, Panel MG oraz biblioteki.
  Przy szerokości do 780 px pozostaje wąski pasek ikon z nazwami dostępnymi
  dla czytnika ekranu i w podpowiedziach. Większe okna pokazują również tekst.
- Karta BG ma poziomy nagłówek z tożsamością, PW, TT, Inicjatywą i Szybkością.
  PW prowadzi do zdrowia; TT do zestawienia obrony. Alternatywne poprawne wartości
  TT pozostają widoczne, zamiast automatycznego wyboru pancerza za gracza.
- Główne zakładki: Broń, Testy, Zdolności, Ekwipunek. Pozostały również
  zdrowie i odpoczynek, postój, podsumowanie oraz rozwój i dane.
  Nowy szkic otwiera rozwój; zatwierdzona karta otwiera broń.
- Zakładki obsługują strzałki lewo/prawo oraz Home/End. Formularze pozostają
  zamontowane przy zmianie sekcji; Broń i Ekwipunek współdzielą jeden panel.
- Broń pokazuje wyraźne przyciski ataku i obrażeń, tryb, zasięg oraz magazynek
  z przeładowaniem. Zachowano dotychczasowy koszt amunicji i potwierdzanie operacji.
- Pasek ostatniego rzutu dotyczy wybranej postaci i prowadzi do pełnej historii.
  Dotychczasowy panel Kości nadal otwiera się przy rzucie.
- Panel MG ma poziome pięć slotów, czytelniejszy nagłówek potyczki, pasek tury
  oraz kolejkę inicjatywy obok karty uczestnika, gdy szerokość na to pozwala.
- Ujednolicono typografię, odstępy, karty i przyciski. Zachowano powiększanie
  tekstu, podpis autora oraz pozostałe moduły aplikacji. Zaktualizowano pomoc.

## Zachowanie danych i mechaniki

Przed zmianami utworzono checkpoint istniejącej implementacji:
`bd417e4 chore: checkpoint current 24E working build before session UI`.
Zmiany interfejsu stanowią osobny commit.

Nie zmieniono domeny, katalogów, usług, store'ów ani backendu Rust.
**Brak migracji SQL**; migracje 001–014 i identyfikator roboczej aplikacji
`pl.neuroshima.combat-tracker.stage24d-smoke` pozostają bez zmian.
Nie kasowano ani nie odtwarzano bazy użytkownika. Zachowano pięć slotów,
autozapis, trwałe operacje, blokady zamknięcia i ochronę rozwoju podczas walki.

Testy operacji wykonywano w osobnej aplikacji `NeuroAltar UI QA`, na kopii bazy.
Testowa karta i jej amunicja nie należą do bazy 24E Roboczego.

## Weryfikacja

- TypeScript, ESLint i formatowanie: poprawne.
- Vitest: **475/475 testów**, 69 plików.
- Rust: **91/91 testów**; `cargo fmt --check` poprawny.
- Build frontendowy: poprawny. Pozostały dotychczasowe ostrzeżenia o wielkości
  paczek i mieszaniu importów statycznych z dynamicznymi.
- W macOS sprawdzono przełączanie modułów i sekcji, kartę BG, widok broni,
  panel MG, blokadę zatwierdzenia rozwoju uczestnika aktywnej walki oraz
  otwarcie i zamknięcie aplikacji.
- Na karcie testowej atak AR zużył ostatni nabój, zablokował kolejny strzał
  i zapisał wynik. Przeładowanie przeniosło nabój z zapasu do magazynka.
  PW pozostały bez zmian. Pasek ostatniego rzutu wskazał właściwy atak.
- Sprawdzono okna 1280×850 i minimalne 680×520, tekst do 150% oraz zmianę
  zakładki klawiszem strzałki. Na małym ekranie sloty potyczek przewija się
  poziomo. Poprawiono kontrast aktywnej pozycji menu pod kursorem.
- Końcowy build macOS `NeuroAltar 24E Roboczy.app` ukończony i podmieniony
  w dotychczasowym miejscu. Sprawdzono uruchomienie z oryginalną bazą,
  istniejącą kartę i potyczkę, zamknięcie oraz ponowne uruchomienie.
- Podpis aplikacji przeszedł `codesign --verify --deep --strict`. Po kontroli
  oryginalna baza ma identyczny SHA-256 jak kopia sprzed prac, a WAL ma 0 bajtów.

## Pliki

- `src/app/App.tsx`, `src/app/session-shell.css`, `src/main.tsx` — wspólna rama.
- `src/features/character/CharacterWorkspace.tsx`,
  `src/features/character/character-session.css` — karta i zakładki.
- `src/features/character/InventoryPanel.tsx`,
  `src/features/character/inventory.css` — broń i inwentarz.
- `src/features/encounters/EncounterWorkspace.tsx`,
  `src/features/combat/combat-session.css` — potyczka i walka.
- `src/features/help/ShortcutHelp.tsx` — aktualna pomoc.
- `README.md`, `AGENTS.md`, `docs/UI_GUIDELINES.md`, `docs/DECISIONS.md`,
  `docs/ROADMAP.md`, niniejszy raport — dokumentacja wdrożenia.
- `docs/POPRAWKI_UI_24E_2026-10-21.md` — wyłącznie formatowanie tabel.

## Granice tej partii

Jest to ukończenie przebudowy interfejsu, nie końcowy odbiór całego Etapu 24E.
Pełna próba sesyjna mechaniki pozostaje osobnym zadaniem. Nie dodano wersji web,
kont, synchronizacji, portu Windows ani nowych reguł gry. Lokalny build jest
podpisany ad hoc, bez notaryzacji Apple, tak jak dotychczasowy build roboczy.
