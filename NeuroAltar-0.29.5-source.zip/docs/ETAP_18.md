# Etap 18 — potwory i kategorie, 0.19.0

## Zakres i dostarczenie

Projekt: `/Users/dominik/Desktop/Combat Tracker`. Start z czystego Git `c470315`
(Etap 17,0.18.0). Zmiany przygotowane w oddzielnym checkout, następnie zapisane
bezpośrednio do tego folderu. Końcowe testy i oba buildy wykonano w realnym repo.
Docelowa aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`,0.19.0.
Kopia poprzedniego buildu: sąsiedni `NeuroAltar 0.18.0.app`.

- 12 kompletnych samodzielnych statblocków działu **Potwory**, plus źródłowa
  nakładka **Zombie — Death Breath**. Razem 13 pozycji podręcznikowych tej partii.
- Zgodnie z najnowszą korektą MG: **Ludzie, Maszyny, Mutanci, Potwory, Zwierzęta**.
  Wszystkie pozycje działu Potwory są w kategorii Potwory. Starsze beast/other
  zachowane jako „Bestia/Inny (starszy wpis)”, bez zgadywania własnych klasyfikacji.
- Dwa rozmiary Techmorwy to dwa rzeczywiste statblocki. Szczękowij zachowuje
  losowane 1k4+1 ataków w jednym wpisie, najwyżej jeden kolcem jadowym.
- Cechy, ruch, SP, obrony, zmysły, pasywy, obrażenia/warunki, akcje i limity
  przeniesione z podręcznika. Niepodane RO/odporności pozostają N/D.
- Megator: zionięcie 2/walkę, Legendarna odporność 3/dzień, trzy Legendarne/rundę.
  Odporność ma ręczny licznik, nie zużywa Reakcji. Zionięcie ma własny koszt,
  nie jest darmowym wariantem przycisku wielokrotnego ataku.
- Mała Techmorwa: 10 jaj/dzień (limit w akapicie taktyki), Owipozycja zużywa jajko.
  Średnia Techmorwa nie otrzymuje tego zasobu.
- Zombie: wybór człowieka/mutanta, wybór jego zdolności wręcz i nowy formularz
  do przeglądu. PW/ruch/zmysły/PB nosiciela, TT-2, SP+2, INT 4, CHA 2. Brakujące
  wartości N/D. Brak ujemnego TT/fikcyjnych PW w katalogu; niewłaściwy szkic
  zatrzymuje standardowa walidacja. Zapis tworzy nowy UUID, bez zmiany nosiciela.
- Przenoszone są profile broni wręcz; opisy bez profilu i odziedziczone końcowe
  RO/umiejętności po zmianie INT/CHA wymagają przeglądu MG w formularzu.
  Gotowy Zombie jest zwykłym edytowalnym szablonem, bez aktywnego powiązania z bazą.
- Nakładka źródłowa jest stałą kartą pomocniczą, a nie usuwalnym/seedowanym
  EnemyTemplate. Nie dostaje fikcyjnych liczb i nie można dodać jej bez nosiciela.

Na pustej bazie: 23 szablony (11 maszyn + 12 potworów) i 1 nakładka, wynik 24 w katalogu.
Prywatne szablony MG zostają dodatkowo. Pakiet 11 maszyn v1 pozostaje bajtowo identyczny.
Etap 18A Mutanci oraz18B Zwierzęta dopisane jako osobne partie przed 19 Ludzie,
bez zmiany numeracji modułów 20–25. Nie rozpoczęto tych partii ani innych modułów.

## Źródło i inwentaryzacja

Prywatny `reference/NOE_dla_dominadiinteriapl.pdf`, 281 stron; dział Potwory s.232–242.
Sprawdzono ekstrakcję tekstu i obrazy wszystkich 11 stron PDF 234–244, w tym kolumny.
SHA-256: `714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
PakietJSON zawiera stabilne UUID, klucze, wersję 1, strony i hash źródła.
PDF, ilustracji ani pełnych opisów fabularnych nie dołączono do Gita/bundla.
Zapisano dane gry i własne zwięzłe przypomnienia reguł.

| Wpis                           | Druk / PDF | TT          | PW        | SP          |
| ------------------------------ | ---------- | ----------- | --------- | ----------- |
| Alahama                        | 232 / 234  | 14          | 102       | 23          |
| Bit-Boys (aka Croats)          | 233 / 235  | 12          | 24        | 5           |
| Bit-Boy Przewodnik             | 234 / 236  | 16          | 60        | 13          |
| Kitchin                        | 234 / 236  | 15          | 8         | 2           |
| Harpie (aka Wampiry)           | 235 / 237  | 12          | 48        | 12          |
| Korzec                         | 236 / 238  | 18          | 144       | 27          |
| Megator                        | 237 / 239  | 21          | 240       | 102         |
| Pies mutek                     | 238 / 240  | 12          | 28        | 4           |
| Szczękowij                     | 239 / 241  | 16          | 96        | 25          |
| Taran                          | 240 / 242  | 18          | 104       | 25          |
| Techmorwa (malutka)            | 241 / 243  | 13          | 16        | 10          |
| Techmorwa (średnia)            | 242 / 244  | 10          | 84        | 20          |
| Zombie — nakładka Death Breath | 242 / 244  | nosiciel -2 | nosiciela | nosiciel +2 |

Źródłowe średnie i formuły zachowane, np. Alahama 102 PW (16k10 + 32), ryjossawka 18 (6k6).
Nie poprawiano ich według klasycznej wartości oczekiwanej. Inicjatywa źródłowa
jest uwagą, a kopie nadal mają niezależny, pusty wynik do wpisania przez MG.
Taran: Próg Obrażeń 10, nie Próg Awarii. Żądło Kitchina: zasięg 0 m i 1 obrażenie.
Drugie typy obrażeń (kolec Szczękowija, macka Techmorwy) widoczne w opisie profilu.
Ataki oparte wyłącznie na RO/automatycznym skutku są opisami, bez fikcyjnego bonusu.

## Migracja i ochrona danych

**Jedna addytywna migracja: 008_enemy_categories.sql.** Dodaje nullable
`enemy_templates.official_category` z CHECK pięciu wartości. Nie przebudowuje tabel.
Migracje 001–007 pozostają niezmienione. Odczyt COALESCE z historyczną kategorią,
zapis jawnej kategorii i technicznej wartości zgodnej ze starym CHECK.
Stare wiersze, revision, timestampy, tombstones i JSON nie są masowo przepisywane.

Start po migracjach stosuje maszyny v1, następnie potwory v1, transakcyjnie dla każdej partii.
Awaria nowej partii wycofuje jej katalog i ledger; wcześniejsza partia zostaje.
Retry nie dubluje wpisów. Korekty tylko nietkniętych poprzednich seedów; edycje,
usunięcia i brakujące rekordy pozostają chronione. Bez downgrade.

Zachowano pięć stałych slotów, autozapis, kopie template/runtime/original/prepared,
log i ochronę zamykania. Produkcyjnej bazy użytkownika nie otwierano ani nie
podmieniano. Testy korzystały wyłącznie z pamięci i oddzielnej bazy QA.

## Kontrole

| Kontrola w realnym repo | Wynik                                              |
| ----------------------- | -------------------------------------------------- |
| pnpm check              | PASS: typy, ESLint, format, 197 testów / 40 plików |
| Rust release lib        | PASS: 45 testów                                    |
| cargo fmt check         | PASS                                               |
| git diff --check        | PASS                                               |
| pnpm build:macos        | PASS: 0.19.0, arm64, lokalny podpis ad hoc         |
| SQLite QA               | integrity_check=ok,foreign_key_check bez błędów    |

Pierwsze uruchomienie testów wskazało brak migracji 008 w historycznych fixture'ach
oraz dwa błędy nowych fixture'ów. Poprawiono konfigurację testowych baz/danych;
pełne ponowne kontrole przeszły. Dostęp do plików tymczasowych testów i odczyt
SQLite QA wymagały zgody sandboxa; powtórzone operacje zakończyły się poprawnie.

Nowe testy: inwentaryzacja/liczby/formuły/końcowe ataki, roundtrip formularzy,
limity i odnowienia bez zmiany PW, niezależność/reset, pięć kategorii i legacy,
nowy Zombie/N/D/wybór nosiciela, migracja bez utraty danych, seed drugiej partii,
rollback/retry/korekty z ochroną edycji/usunięć/aktorów/logów, CRUD kategorii.

## Odbiór natywny

Osobna aplikacja `pl.neuroshima.combat-tracker.stage18-smoke`. Baza z zamkniętego
poprzedniego testu 17, bez danych produkcyjnych. Migracja 1–7 → 1–8 przez aplikację.

- Start: 24 pozycje; filtr Potwory 13. Menu zawiera pięć uzgodnionych kategorii.
- Add ×2 Megatora do slotu 4. Użycie Zionięcia: tylko Akcja i zasób 2→1,
  bez zmiany 240 PW. Następnie ręczne -5 PW tylko pierwszej kopii: 235/240,
  druga 240/240. Przygotowane/oryginalne kopie nadal 240 PW i pełne zasoby.
- Opis katalogu Megatora zmieniono na dwa wiersze z „Żółć, Łódź”. Runtime
  i snapshoty obu wcześniejszych kopii zachowały 8 oryginalnych uwag źródłowych.
- Duplikat testowego nosiciela zapisany jako Mutant; nakładka z zaznaczonymi
  Pazurami tworzy Zombie TT 14, PW 60, SP 15, INT 4, CHA 2. Zachowuje tylko jeden
  profil wręcz i wybrane Pazury, dodaje Atak wielokrotny/Mackę/Ugryzienie.
  Macka ma ST 6 (PB 3 + SIŁ 3, bez dopisywania 8). Dodanie gotowego Zombie do slotu 5 działa.
- Niedokończony formularz Zombie: ⌘Q z ekranu głównego wraca do Bestiariusza
  i ujawnia formularz. Zatwierdzenie zapisuje nowy szablon.
- Wizualnie sprawdzono 1100×760 i 760×580: tekst zawija się, pole wyboru nosiciela
  i dolne kontrolki są dostępne; małe okno używa jednej kolumny.
- Zwykłe zamknięcie kończy proces. Restart zachowuje ręczne opisy, kopie i Zombie,
  nie odtwarza źródłowego opisu Megatora. Następne ⌘Q również kończy proces.
- Odczyt zamkniętej bazy QA: 25 szablonów (23 źródłowe + nosiciel + Zombie),
  ledger11 maszyn + 12 potworów. Pięć slotów: 2 stare Mobsprzęty w 3, 2 Megatory w 4, 1 Zombie w 5.
  Wiersze maszyn i całość runtime/original/prepared slotu 3 są bajtowo identyczne
  z testem 17. Edycje Megatora i jego niezależne zasoby potwierdzone w bazie.

## Ograniczenia i dalsze kroki

- Reguły warunkowe, obrażenia, infekcje, regeneracja i losowania pozostają decyzją MG;
  nie dodano automatycznego PW, rollera, amunicji NPC ani nowego modułu.
- Nakładka Zombie przygotowuje szkic do przeglądu, nie automatyzuje każdej możliwej
  zdolności własnego nosiciela. Wybór wyłącznie ataków wręcz i korekta odziedziczonych
  końcowych wartości pozostają po stronie MG.
- Stare beast/other mogą wymagać ręcznej klasyfikacji. Nowy statblock zapisany
  z mutant/monster/animal nie jest obsługiwany przez stare buildy. Nie cofać .app
  na zaktualizowanej bazie; kopia aplikacji nie jest backupem danych.
- Lokalny build arm64/ad hoc; brak notaryzacji i odbioru Intel/Windows.
- Mutanci i Zwierzęta nie są pominięte w planie: 18A/18B, osobne zlecenia.
  Dane Ludzi pozostają 19, Ekwipunek 20, Wiedza MG 21, roller 22, QA 23, Windows 24, BG 25.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_18.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/008_enemy_categories.sql`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/bestiary_seed.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/bestiary/monsters.v1.json`
- `src/db/bestiaryRepository.ts`
- `src/domain/deathBreath.ts`
- `src/domain/enemy.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/DeathBreathPanel.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `tests/bestiary.test.ts`
- `tests/categoryMigration.test.ts`
- `tests/monsterSeed.test.ts`
