# Etap 14 — końcowe QA i build macOS (0.15.0)

## Wynik i zakres

Zlecenie po czystym commicie `2f38a29def681eff0e01c7bacb9f3ec1a14c5bd5`.
Zakończono rundę QA istniejących funkcji, sprawdzenie restartu i lokalny build.
**177 testów TS i 35 testów Rust przechodzi.** Nie wykryto regresji wymagającej
zmiany implementacji mechanik lub persistence. Zmieniono numer pakietu i stopkę,
uporządkowano instrukcje, dodano niniejszy raport i jawny wykaz braków.

**0.15.0 jest punktem kontrolnym QA, a nie deklaracją pełnego zakresu v1.0.**
Porównanie PRODUCT_SPEC z `enemyTemplateSchema` i edytorem ujawniło brak osobnych
pól pełnego statblocka: podtyp, sześć cech, rzuty obronne, umiejętności, zmysły,
odporności/wrażliwości/niewrażliwości (w tym na stany) oraz Próg Obrażeń.
PB i modyfikatory SIŁ/ZRC są dostępne w uzbrojeniu; Próg Awarii jest wdrożony
jako odrębna reguła. To otwarty punkt implementacji przed pełnym v1.0, nie zmiana
specyfikacji. Nie przeniesiono go automatycznie do Ekwipunku v1.1.

Nie rozpoczęto v1.1 ani v1.2. Nie dodano importera, danych prywatnych, rzutów,
liczenia amunicji ani nowych mechanik. Istniejąca implementacja testów pozostała
bez zmian; nie dodawano testów odtwarzających kosmetyczną zmianę stopki.

## Macierz kontroli

| Obszar                               | Dowód z tej rundy                                                     | Wynik           |
| ------------------------------------ | --------------------------------------------------------------------- | --------------- |
| Pięć stałych ID, metadane, migracje  | encounterDatabase/encounterStore, Rust; osobna baza native            | OK              |
| BG, PW, niezależna inicjatywa, runda | combat/initiative/combatStore; native 17 i 9, runda 1 → 2             | OK              |
| Statusy, czas i Podpalenie           | status/statusStore/statusDatabase, Rust; native licznik i wygaśnięcie | OK              |
| Zranienia i Tchórzliwość             | injury/injuryStore, Rust; native 44/88 i Lekki                        | OK              |
| Zasoby i akcje                       | capabilities/capabilityStore, Rust; native Akcja 0/1 po restarcie     | OK              |
| Bestiariusz, kopie i snapshoty       | bestiary/enemy/enemyDatabase, Rust; native wyszukiwanie i ×3          | OK              |
| Item, atak, warianty                 | weaponProfile/loadoutStore, walidacja i transakcje Rust               | OK w automatyce |
| Awarie 1–20                          | machineFailures/failureStore, Rust                                    | OK w automatyce |
| SD/SP, progi, zaokrąglenia           | difficulty/difficultyStore/difficultyPresentation; native 176%, SD=0  | OK              |
| Reset/clear, rollback i konflikt     | encounterMaintenance, prepared_state/encounter_clear Rust             | OK w automatyce |
| Potwierdzenia reset/clear            | native slot 3, trzy postacie, treść i Anuluj                          | OK              |
| Log i kolejność zapisów              | combatLogDatabase/combatLogStore, Rust; native trwała historia        | OK              |
| Zamknięcie i ochrona formularza      | closeGuard/prepareAppClose; native ⌘Q i przycisk okna                 | OK              |
| Nawigacja, pomoc, małe okno          | shortcuts, native Alt+↓, Spacja, F1, Escape, Tab+Enter                | OK              |
| Pełny statblock z PRODUCT_SPEC       | porównanie aktualnego modelu i edytora                                | Otwarty brak    |

Próby natywne są scenariuszami smoke, nie pełnym ręcznym powtórzeniem każdego
przypadku automatycznego. W tej rundzie wykonanie reset/clear oraz warianty broni
i wszystkie awarie zweryfikowano testami automatycznymi; GUI reset/clear tylko
otwarto i anulowano. Nie traktujemy tego jako ręcznej próby usunięcia danych.

## Scenariusz natywny i restart

Testy wykonano na macOS 26.2, arm64.
Osobny bundle `NeuroAltar Stage 14 Test.app`, identyfikator i katalog danych
`pl.neuroshima.combat-tracker.stage14-smoke`. Baza produkcyjna nie była otwierana
ani kopiowana do testów. Scenariusz zaczęto od pustej bazy utworzonej przez plugin.

- Slot 1 „Żółty Most — QA”: poziomy 4/5/6, polskie notatki w dwóch wierszach.
  Łucja zwiadowczyni: inicjatywa 17, PW 44 → 34, statusy opisowe z polskimi znakami
  i nową linią. Konwojent Żółty Most: inicjatywa 9, PW 88 → 44, TT16, SP26,4.
- Niepełny formularz przeciwnika zatrzymał ⌘Q. Błędy wskazały nazwę/TT/PW;
  kliknięcie błędu ustawiło kursor w polu, a poprawione dane zapisano.
- SD15/SP26,4 dało dokładnie 176%, „Ryzykowna”. Pole aktualnego SP jest osobną,
  czytelną kontrolką; zrzut potwierdził brak wcześniejszego zlania etykiety z liczbą.
- Lekki stopień Zranienia zmienił podgląd ruchu 9 → 4,5 m i 4,5 → 0 m,
  pozostawiając bazę. Tchórzliwość 50% ostrzegła przy PW44/88, bez usunięcia postaci.
- Podpalenie z opisem w dwóch wierszach i czasem do końca następnej tury:
  wybór karty Alt+↓ nie zmienił tury. Spacja rozpoczęła turę przeciwnika i pokazała
  przypomnienie 1k4; PW pozostały 44. Użyto Akcji, pozostawiając 0/1.
- Slot 2 otrzymał inne poziomy 2/3; bezpośrednie ⌘Q po edycji zakończyło autozapis.
  Po ustaniu procesu skopiowano wyłącznie zamkniętą bazę testową do katalogu QA.
- Restart odtworzył turę, PW, Zranienie, czas Podpalenia, Akcję0/1 i metadane.
  Plik bazy po samym uruchomieniu był identyczny bajtowo z zamkniętą kopią.
  Kontrola integralności SQLite: `ok`; `foreign_key_check`: brak wyników.
- Następna tura po restarcie dała rundę2 i turę Łucji. Podpalenie wygasło;
  baza zawierała wpis `status_expired`, bez automatycznej zmiany PW.
- Wyszukiwanie `zolty` odnalazło „Żółty”. Szablon wciąż miał PW88 i Zranienia0.
  Dodaj ×3 do aktywnego slotu3 utworzyło trzy kopie PW88 z pustymi inicjatywami.
  Pierwsza potyczka pozostała niezależna. Slot3 miał SP79,2 i brak ratio przy SD0.
- F1 zablokowało ⌘5 pod modalem; Escape zachowało slot3. Okno zmniejszono
  z 1100×760 do około 683×525. Pomoc przewijała się i zamykała przez Tab+Enter.
  Czerwony przycisk okna zakończył aplikację; ponownie sprawdzono kopię bazy.

Po ustaleniu ostatecznej wersji przebudowano osobny bundle 0.15.0 i ponownie
uruchomiono go na zachowanej bazie testowej: stopka, dane i tura poprawne; ⌘Q
zakończyło aplikację. Mechaniki pozostały identyczne z pełnym scenariuszem.

Końcowa kopia zawierała pięć slotów, dwie postacie w slocie1, trzy w slocie3,
niezmieniony szablon i poprawną historię. Obie kontrole SQLite przeszły.

Automatyzacja natywnego rozwijanego menu docelowego slotu zwracała niejednoznaczny
wybór. Potwierdzono dodawanie do slotu3 przez wcześniejsze uaktywnienie go w Walce
oraz ponowne wejście do Bestiariusza. Samo przełączanie tego menu nie ma w tej
rundzie jednoznacznego zaliczenia; nie uznano ograniczenia sterowania GUI za dowód
błędu modelu. Pozostaje punkt do ręcznej weryfikacji.

## Kontrole techniczne

- `pnpm check`: TypeScript, ESLint, Prettier, 177 testów / 33 pliki — OK.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: 35/35 — OK.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: produkcyjny arm64 0.15.0, podpis ad hoc — OK.
- `git diff --check`, zgodność numerów pakietu i podpis bundle — OK.
- Domena, backend, repozytoria, store i migracje 001–006 niezmienione względem
  checkpointu Etapu13. Adres SQLite i identyfikator produkcyjny bez zmian.

## Dostarczenie

Praca i build w kontrolowanej kopii, następnie zastosowanie do
`/Users/dominik/Desktop/Combat Tracker`. Procedura sprawdza czysty bazowy HEAD,
sumę patcha, końcowe drzewo Git, wersję i podpis aplikacji oraz brak uruchomionego
procesu docelowego. Kod jest commitowany w repozytorium na Biurku.

Bundle: `src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.15.0).
Poprzedni bundle pozostaje jako `NeuroAltar 0.14.0.app`. To kopia aplikacji,
nie bazy danych; brak migracji i jakiegokolwiek zastępowania bazy użytkownika.

## Ograniczenia przed dalszą pracą

1. Domknąć osobne pola pełnego statblocka przed deklaracją pełnego v1.0.
2. Ręcznie potwierdzić wybór innej potyczki z menu w Bestiariuszu.
3. Build i próby dotyczą lokalnego macOS Apple Silicon. Brak notaryzacji,
   certyfikatu dystrybucyjnego, testów Intel, Windows i innych wersji macOS.
4. Niepełne szkice są chronione przy zwykłym zamknięciu i ⌘Q, lecz wymuszone
   zabicie procesu może je utracić. Wydanie nie dodaje backupu GUI ani eksportu.
5. Ekwipunek v1.1 i Wiedza MG v1.2 nadal wymagają osobnego zlecenia.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_14.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
