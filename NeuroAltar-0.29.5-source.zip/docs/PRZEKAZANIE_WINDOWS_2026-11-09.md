# NeuroAltar — przekazanie projektu na Windows

Stan przekazania: **10 listopada 2026**, linia **24E Roboczy / 0.29.5**.
Instrukcja dotyczy źródeł po ośmiu poprawkach karty BG i ich zbudowania na
**Windows 11 x64 (Intel/AMD)**. Przygotowanie paczki na Macu nie oznacza,
że instalator Windows został zbudowany lub sprawdzony.

## Tożsamość paczki

- Commit: odczytaj `MANIFEST.json` z głównego katalogu paczki; po odtworzeniu
  Git porównaj go z wynikiem `git rev-parse HEAD`.
- Wersja: **0.29.5**. `package.json`, `src-tauri/tauri.conf.json` i
  `src-tauri/Cargo.toml` muszą zawierać tę samą wersję.
- Kontrole macOS: **569 testów TypeScript i 107 testów Rust — PASS**;
  **natywny build QA macOS — PASS**. Pełny odbiór sesyjny pozostaje otwarty.
- Instalator i odbiór Windows: **niewykonane w ramach przekazania**.

Porównaj commit i sumy SHA-256 z `MANIFEST.json`. Przekazanie obejmuje
**jeden ZIP**: folder `NeuroAltar/` ze śledzonymi źródłami oraz umieszczone
obok niego `NeuroAltar.bundle`, `MANIFEST.json` i instrukcje rozpoczęcia pracy. ZIP nie zawiera `reference/`,
surowych podręczników, baz użytkownika, `node_modules/`, `dist/` ani
`src-tauri/target/`. Bundle przenosi historię Git, nie dane z aplikacji.
Nie publikuj paczki, bundle ani źródeł w publicznym repozytorium.

## Dla użytkownika

1. Przenieś jeden ZIP na Windows i rozpakuj go do `C:\Przekazanie`.
   Przenieś znajdujący się w paczce folder `NeuroAltar` do `C:\NeuroAltar`;
   bundle, manifest i instrukcje pozostaw w `C:\Przekazanie`. Bezpośrednio
   w `C:\NeuroAltar` mają być `package.json`, `AGENTS.md`, `src/` i
   `src-tauri/`, bez dodatkowego zagnieżdżonego folderu.
2. Uruchom Codex na Windows i otwórz **ten folder jako projekt**. Samo
   załączenie ZIP w zwykłej rozmowie nie daje dostępu do kompilatora i plików
   na komputerze.
3. Wklej poniższe polecenie. Instrukcja jest również w
   `docs/PRZEKAZANIE_WINDOWS_2026-11-09.md`.
4. Pierwsze pobranie zależności i ewentualna instalacja WebView2 wymagają
   internetu. Gotowa aplikacja ma działać lokalnie także offline.

## Polecenie do kontynuacji

```text
Kontynuujemy NeuroAltar 24E Roboczy przeniesiony z macOS na Windows 11 x64.
Przeczytaj AGENTS.md, docs/PRZEKAZANIE_WINDOWS_2026-11-09.md,
docs/BUILD_WINDOWS.md i aktualny raport zmian/status.
Zweryfikuj folder, commit z manifestu, stan Git i narzędzia. Zachowaj lokalne
zmiany użytkownika. Jeżeli ZIP nie zawiera .git, odtwórz historię z dołączonego
Git bundle, bez nadpisywania plików roboczych.
Przygotuj środowisko, wykonaj kontrole i zbuduj istniejącym skryptem
build:windows instalator NSIS dla x86_64-pc-windows-msvc. Napraw potrzebne
problemy zgodności platformowej i ponów stosowne kontrole.
Nie przerabiaj aplikacji na web ani nie rozszerzaj mechaniki. Nie zmieniaj
identyfikatora docelowej aplikacji ani bazy. Testy interfejsu prowadź na osobnym
profilu/bazie. Nie usuwaj, nie odtwarzaj i nie modyfikuj ręcznie bazy użytkownika.
Nie importuj danych z Maca bez osobnego polecenia.
Sprawdź instalację, uruchomienie, przepływy MG/BG, osiem ostatnich poprawek,
zapis, restart, aktualizację i zamknięcie na Windows. Sam build nie jest odbiorem.
Raport ma podać ścieżkę instalatora, SHA-256, wersję/commit, wyniki testów,
otwarte problemy i pliki zmienione dla Windows. Pracuj bezpośrednio w folderze.
Nie publikuj kodu ani wydania.
```

## Środowisko zgodne z repozytorium

Wersje wynikają z `package.json` i istniejącego workflow. Nie aktualizuj ich
przy okazji portowania.

| Element    | Wymaganie                                                                             |
| ---------- | ------------------------------------------------------------------------------------- |
| System/cel | Windows 11 x64; `x86_64-pc-windows-msvc`                                              |
| Git        | Git for Windows, także do odtworzenia bundle                                          |
| Node.js    | 24.x; `package.json`: `>=24 <25`                                                      |
| pnpm       | Dokładnie `11.19.0`                                                                   |
| Rust       | `1.98.1`, MSVC, komponent `rustfmt`                                                   |
| C++        | Visual Studio Build Tools: „Desktop development with C++”, MSVC x64/x86 i Windows SDK |
| Webview    | Microsoft Edge WebView2 Runtime                                                       |
| Instalator | NSIS, `src-tauri/tauri.windows.conf.json`                                             |

Po instalacji narzędzi systemowych otwórz ponownie PowerShell/Codex, aby
odświeżyć PATH. Xcode, Apple SDK, konto Apple, klucze Apple i notaryzacja nie
są potrzebne. Nie przenoś certyfikatów ani poświadczeń z Maca.

PowerShell, po przygotowaniu Git, Node, rustup i C++ Build Tools:

```powershell
Set-Location C:\NeuroAltar
$ErrorActionPreference = 'Stop'
git --version
node --version
npm --version
npm install --global pnpm@11.19.0
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się przygotować pnpm.' }
pnpm --version
rustup toolchain install 1.98.1 --profile minimal --component rustfmt --target x86_64-pc-windows-msvc
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się przygotować Rust.' }
rustup override set 1.98.1
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się wybrać toolchainu.' }
rustc --version
cargo --version
```

`$ErrorActionPreference` nie zastępuje sprawdzania kodu zakończenia programów
zewnętrznych. Przerwij po każdym błędzie.

## Odtworzenie Git

Jeżeli istnieje `.git`, odczytaj `git status` i `git rev-parse HEAD`; nie
inicjalizuj repozytorium ponownie i nie wykonuj resetu.

Dla świeżo rozpakowanego ZIP **bez `.git`** można odtworzyć historię bez
nadpisywania źródeł. Zmień przykładową ścieżkę bundle na rzeczywistą:

```powershell
Set-Location C:\NeuroAltar
$bundlePath = 'C:\Przekazanie\NeuroAltar.bundle'
if (Test-Path .git) { throw 'Folder ma Git — najpierw sprawdź jego stan.' }
git init
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się zainicjalizować Git.' }
git bundle verify $bundlePath
if ($LASTEXITCODE -ne 0) { throw 'Bundle nie przeszedł weryfikacji.' }
git fetch $bundlePath HEAD
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się odczytać historii.' }
git reset --mixed FETCH_HEAD
if ($LASTEXITCODE -ne 0) { throw 'Nie udało się odtworzyć indeksu Git.' }
git rev-parse HEAD
git status --short
```

`reset --mixed` ustawia indeks i commit, zachowując pliki robocze. **Nie używaj
`reset --hard` ani `git clean`.** Porównaj commit z manifestem, a różnice
wyjaśnij przed pracą. Lokalne budowanie nie wymaga zdalnego repozytorium;
nie dodawaj go i niczego nie wysyłaj.

## Kontrole i instalator

Konfiguracja Windows już istnieje: NSIS, ikona ICO, instalacja dla bieżącego
użytkownika, język PL/EN. Nie kopiuj ustawień podpisu macOS do Windows.
Wykonuj kolejno w katalogu projektu:

```powershell
pnpm install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { throw 'Błąd instalacji zależności.' }
pnpm check
if ($LASTEXITCODE -ne 0) { throw 'Nie przeszły kontrole frontendu.' }
cargo fmt --manifest-path src-tauri/Cargo.toml --check
if ($LASTEXITCODE -ne 0) { throw 'Niepoprawne formatowanie Rust.' }
cargo test --manifest-path src-tauri/Cargo.toml --release --lib --locked
if ($LASTEXITCODE -ne 0) { throw 'Nie przeszły testy Rust.' }
pnpm build:windows
if ($LASTEXITCODE -ne 0) { throw 'Build Windows nie powiódł się.' }
```

`pnpm check` obejmuje TypeScript, ESLint, formatowanie i Vitest.
`build:windows` wybiera MSVC x64, NSIS, tryb CI i Cargo `--locked`.
Nie usuwaj lockfile w celu obejścia błędu. Nie uruchamiaj `build:macos` na Windows.
Oczekiwany plik:

```text
C:\NeuroAltar\src-tauri\target\x86_64-pc-windows-msvc\release\bundle\nsis\*-setup.exe
```

Sprawdź rzeczywisty instalator i jego sumę:

```powershell
$installerDir = 'src-tauri\target\x86_64-pc-windows-msvc\release\bundle\nsis'
$installers = @(Get-ChildItem -LiteralPath $installerDir -Filter '*-setup.exe' -File)
if ($installers.Count -eq 0) { throw 'Nie znaleziono instalatora.' }
$installers | Get-FileHash -Algorithm SHA256
```

Zapisz commit, wersję, narzędzia, nazwę instalatora i SHA-256. Certyfikat
Windows nie jest skonfigurowany; prywatny instalator może pokazać informację
o nierozpoznanym wydawcy. Nie wyłączaj zabezpieczeń systemu. Brakujący
WebView2 jest pobierany przez instalator.

Alternatywą pozostaje ręczny `.github/workflows/windows-build.yml`. Nie
publikuj projektu tylko po to, aby uruchomić workflow. Lokalny build nie
wymaga GitHub ani konta Apple.

## Dane i granice zmian

- Docelowy identyfikator: `pl.neuroshima.combat-tracker`. Baza:
  `sqlite:combat-tracker.db`. Zachowaj pięć slotów i dotychczasowe migracje.
- Osiem poprawek nie wymaga nowej migracji SQL. Nowe pola JSON mają odczyt
  zgodny ze starszymi kartami. Nie twórz od nowa bazy ani jej struktury.
- Windows nie otrzymuje automatycznie kart i potyczek z Maca. Paczka nie
  zawiera bazy; transfer danych jest osobnym zadaniem.
- QA prowadź na osobnym profilu/bazie. Tymczasowy identyfikator QA stosuj
  wyłącznie w osobnej konfiguracji testowej, nigdy w docelowym instalatorze.
  Sprawdź rzeczywistą ścieżkę danych przed uruchomieniem; nie zakładaj, że
  odpowiada lokalizacji macOS.
- Reset, aktualizację i deinstalację testuj na danych testowych. Przed
  transferem danych zamknij aplikację i zachowaj bazę oraz ewentualne
  pliki SQLite WAL/SHM. Nie zmieniaj danych przez ręczne polecenia SQL.
- Nie dołączaj prywatnych źródeł ani sekretów do instalatora. Ikony FVTT-NOE
  zachowują własny NOTICE, manifest i oryginalne pliki.
- Truciciel i Pogromca pozostają opisami; produkcję rozlicza gracz.
  Premie sytuacyjne, m.in. Mój wróg, także pozostają ręczne. To przyjęte
  granice, nie zadania do automatycznego uzupełnienia podczas portu.
- Prywatnego PDF nie ma w paczce. Jeżeli następne zadanie wymaga sprawdzenia
  mechaniki, użytkownik udostępnia podręcznik na Windows tylko do odczytu.
  Nie zgaduj zasad ani nie używaj pomocniczego arkusza jako nadrzędnego źródła.

## Osiem ostatnich poprawek — odbiór

| Obszar             | Co sprawdzić                                                                                                                                                                                                                 |
| ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1. Zakup cech      | 28/27 daje wyraźne ostrzeżenie i blokuje zatwierdzenie błędnej karty. Baza w metodzie punktowej 8–15; premie pochodzenia/sztuczki mogą dać wynik powyżej 15.                                                                 |
| 2. Sprzęt startowy | Sześć klas, przedmioty albo właściwa kwota gambli. Plecak i obowiązkowe narzędzia/instrument także przy gamblach. Bez ponownego plecaka; możliwość pominięcia wcześniej przyznanych przedmiotów. Ręczne rozliczanie zakupów. |
| 3. Magazynki       | Magazynek (BPK/BPP/BPD/BPC) w katalogu i ekwipunku, wyszukiwanie po nazwie/skrócie. Własne nazwy oraz ID i zapisane kopie zachowane.                                                                                         |
| 4. Postój          | Kafelki z ikonami; trwały postęp treningu/nauki. Nieukończone szkolenie nie daje biegłości; po 300 h doliczana jest wybrana biegłość. Trening nie przyznaje poziomu postaci.                                                 |
| 5. Zranienia       | Stosowanie skutków stopni: Szybkość, Reakcja, Akcja Bonusowa i pozostałe skutki; spójność karty i powiązanej potyczki.                                                                                                       |
| 6. Wyczerpanie     | Ręczne dodanie/zmiana, widoczne źródła, skutki mechaniczne. Zachowanie istniejących przyczyn oraz odczyt starszej karty.                                                                                                     |
| 7. Doświadczenie   | Pasek do następnego poziomu, brakujące PD, aktualizacja po zmianie PD i poprawny stan na maksymalnym poziomie.                                                                                                               |
| 8. Notatki         | Notatki, znajomi i pierwsze spotkania edytowalne bez edycji całej karty. Trwały zapis; odrzucenie szkicu rozwoju nie cofa treści.                                                                                            |

## Odbiór portu Windows

- [ ] Instalacja, pierwsze uruchomienie, numer wersji i zamknięcie.
- [ ] Polskie znaki, ikony, czcionki, niezmieniona papierowo-zielona paleta.
- [ ] Małe i maksymalne okno, skala 100/125/150/200%; bez obciętych pól i akcji.
- [ ] Klawiatura, fokus, skróty, ochrona niezapisanych zmian przy Alt+F4.
- [ ] Tworzenie/rozwój BG, sloty broni, amunicja, przeładowanie, rzuty ataku
      i obrażeń, zasoby przy zdolnościach oraz odpoczynki.
- [ ] Panel MG: 5 slotów, przeciwnicy, inicjatywa, powiązanie BG, tury,
      zakończenie udziału i zapis szkicu podczas walki bez błędnego koła.
- [ ] Zapis/restart; reset potyczki nie cofa trwałych danych BG.
- [ ] Bestiariusz, Ekwipunek, Pojazdy, Wiedza MG, ikony i rzuty działają offline.
- [ ] Aktualizacja/ponowna instalacja zachowuje testową bazę; zachowanie
      deinstalacji sprawdzone wyłącznie na danych testowych.
- [ ] Wyniki ośmiu poprawek zapisane oddzielnie od wyniku kompilacji.
- [ ] Potrzebna regresja macOS wskazana po ewentualnych zmianach wspólnego kodu.

Raport rozdziela: **skompilowano**, **powstał instalator**, **zainstalowano**,
**sprawdzono na Windows** oraz otwarte problemy. Nie oznaczaj punktu jako
zaliczonego tylko dlatego, że pozostałe testy przeszły.
