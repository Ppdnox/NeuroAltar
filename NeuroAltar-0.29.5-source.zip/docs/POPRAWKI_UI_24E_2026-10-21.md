# Czytelność i obsługa UI — 24E Roboczy, 2026-10-21

Zmiany dotyczą aktualnej aplikacji **NeuroAltar 24E Roboczy** (0.29.4).
Zachowano papierową kolorystykę, istniejące mechaniki, dane użytkownika oraz
wcześniejsze niezacommitowane poprawki 24E. Ten zakres nie oznacza zakończenia
ani pełnego odbioru Etapu 24E.

## Karta BG

- Zwarty nagłówek zatwierdzonej postaci pokazuje imię, poziomy klas i Kolor gry;
  pola edycji pozostają dostępne w szkicu karty.
- Przełączanie sekcji ustawia fokus i przewija do odpowiedniej części karty.
  Nawigacja i wybór postaci zajmują mniej miejsca, zachowując dostęp w wąskim oknie.
- Cechy i podległe testy tworzą dwie kolumny, a w wąskiej przestrzeni jedną.
  Wybór cechy dla umiejętności jest razem z jej szczegółami i źródłami premii.
  Rzuty Obronne zachowują oznaczenie tarczą.
- Zdrowie ma cztery czytelne kafelki: PW, Zranienia, Wyczerpanie i KW.
  Przyciski zdrowia, zasoby i odpoczynki są pogrupowane. Ostrzeżenia pozostają widoczne.
- Broń pokazuje atak i obrażenia jako wyraźne przyciski. Przeładowanie znajduje
  się przy stanie magazynka i rozwija potrzebne kontrolki. Ustawienia handlu,
  tryb liczenia amunicji i obsługa stanu broni zajmują mniej miejsca.
- Formularze, podglądy zmian, blokady i mechanika zużywania amunicji pozostają zachowane.

## Panel MG i potyczka

- Zmniejszono nagłówki, odstępy oraz karty pięciu potyczek. Trudność jest
  domyślnie zwinięta; błędy nadal ujawniają wymagające poprawy pola.
- Kolejka inicjatywy jest bardziej zwarta i wyraźnie oznacza bieżącą turę.
- Karta uczestnika otrzymała skróty do najczęściej potrzebnych sekcji.
  Pola PW, TT i inicjatywy oraz szybkie zmiany PW są pogrupowane.
- Informacje o bazowym szablonie przeniesiono niżej. Pełny statblock instancji,
  akcje, statusy i awarie pozostają dostępne.
- Na szerokim ekranie karta uczestnika korzysta z osobnego przewijania;
  w mniejszym oknie układ przechodzi do jednej kolumny. Log znajduje się pod
  obszarem uczestników.

## Pliki implementacji

| Obszar                  | Zmienione pliki                                                                             |
| ----------------------- | ------------------------------------------------------------------------------------------- |
| Karta BG i nawigacja    | `src/features/character/CharacterWorkspace.tsx`, `src/features/character/character.css`     |
| Ekwipunek BG            | `src/features/character/InventoryPanel.tsx`, `src/features/character/inventory.css`         |
| Zdrowie BG              | `src/features/character/ConditionPanel.tsx`, `src/features/character/condition.css`         |
| Wspólny układ aplikacji | `src/app/App.tsx`, `src/app/styles.css`                                                     |
| Potyczka i uczestnicy   | `src/features/combat/CombatWorkspace.tsx`, `src/features/encounters/EncounterWorkspace.tsx` |

Nie dodano migracji SQL i nie zmieniono kodu domenowego ani bazy użytkownika.
Pozostawiono pięć slotów, autosave, istniejące migracje i ochronę niedokończonych formularzy.

## Sprawdzenie

| Sprawdzenie                                   | Wynik                                                                                                                      |
| --------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| TypeScript                                    | Poprawnie                                                                                                                  |
| ESLint zmienionych plików                     | Poprawnie                                                                                                                  |
| Prettier zmienionych plików                   | Poprawnie                                                                                                                  |
| `git diff --check`                            | Poprawnie                                                                                                                  |
| Vitest                                        | **437 testów w 66 plikach — zaliczone**                                                                                    |
| Vite — build frontendowy                      | Poprawnie                                                                                                                  |
| Tauri — aplikacja macOS                       | Poprawnie                                                                                                                  |
| `codesign --verify --deep --strict`           | Poprawnie                                                                                                                  |
| Natywna Karta BG                              | Sprawdzono nagłówek, dwie kolumny testów, kafelki zdrowia, rozwijanie przeładowania i zmianę sekcji z fokusem/przewijaniem |
| Natywny Panel MG                              | Poprawnie: skrót Akcje przewija samą kartę, zachowuje jej nawigację; kolejka kończy się nad logiem                         |
| Ponowny build po ostatniej poprawce Panelu MG | TypeScript, ESLint, Vite i Tauri — poprawnie                                                                               |
| Powiększenie tekstu                           | Sprawdzono 115%, 130% i 150%; przy 150% testy BG i panel MG przechodzą do jednej kolumny. Przywrócono Auto                 |

Pełne 437 testów zaliczono po integracji zmian UI. Po końcowej korekcie samego
przewijania i ograniczenia sticky ponowiono kontrolę typów, lint, build i test natywny.
Sprawdzenie interfejsu nie wykonywało operacji zmieniających
stan rozgrywki: PW, amunicję, zasoby ani przebieg tur.

## Build i kopie bezpieczeństwa

- Aktualizowana aplikacja:
  `/Users/dominik/.codex/.chatgpt-projects/g-p-689488ecd4448191b76fc99f91b4fdd2/work/stage2-target/release/bundle/macos/NeuroAltar 24E Roboczy.app`
- Zachowany identyfikator aplikacji: `pl.neuroshima.combat-tracker.stage24d-smoke`.
- Kopia aplikacji sprzed zmian:
  `/Users/dominik/.codex/.chatgpt-projects/g-p-689488ecd4448191b76fc99f91b4fdd2/work/backups/NeuroAltar 24E Roboczy przed UI 2026-10-21.app`
- Kopie plików źródłowych sprzed zmian:
  `/Users/dominik/.codex/.chatgpt-projects/g-p-689488ecd4448191b76fc99f91b4fdd2/work/ui-2026-10-21/before`

## Ograniczenia sprawdzenia

Sprawdzono standardowe okno 1100×760, powiększenie okna oraz zmianę skali tekstu.
Nie wykonano pełnego odbioru rozgrywki 24E ani testów wszystkich kombinacji klas
i formularzy. Natywne sprawdzenie obejmowało nawigację i rozwijanie kontrolek.
Build zachowuje wcześniejsze ostrzeżenia o wielkości bundla, importach dynamicznych
oraz nieudanym usuwaniu symboli debugowania przez rust-objcopy; kompilacja zakończyła
się sukcesem. Aplikacja ma podpis ad hoc, bez notaryzacji.
