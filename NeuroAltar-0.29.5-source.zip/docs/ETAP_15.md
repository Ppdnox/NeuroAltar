# Etap 15 — ekran główny, 0.16.0

## Zmiany

Praca bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`, z czystego
checkpointu `11a037a`. Ekran główny prowadzi do Panelu MG i jawnej zapowiedzi
karty BG. Powrót zachowuje zamontowany panel, szkice i wybrany moduł.
Nie zmienia tury ani statusów. Skróty walki/slotów są aktywne tylko w widocznej
walce; F1 tylko w Panelu MG. Globalny zapis i ochrona zamykania działają na
każdej stronie; niepełny formularz ujawnia właściwy moduł/slot i błędne pole.
Aktualizacja instrukcji i statusu planu: Etap 16 jest już zlecony po tym raporcie.

## Dane i migracje

Brak migracji, nowych tabel, zmian identyfikatora lub resetowania bazy.
Nawigacja jest sesyjna. Pięć slotów, kolejki, autosave, katalog i snapshoty
zachowują dotychczasowe kontrakty. Testowano wyłącznie osobną bazę
`pl.neuroshima.combat-tracker.stage15-smoke`, skopiowaną z zamkniętej bazy QA14.
Nie otwierano bazy użytkownika.

## Kontrole

- `pnpm check`: zaliczone — TypeScript, ESLint, formatowanie, 179 testów / 34 pliki.
- Rust release lib: 35 testów zaliczonych; cargo fmt check zaliczone.
- `pnpm build:macos`: zaliczone, arm64, podpis ad hoc.
- Natywnie: ekran główny i BG, powroty, brak wpływu ⌘4/5, spacji i Alt+Down
  poza walką; zachowana runda 2, Łucja, slot 1 i wcześniejsze polskie notatki.
- Ukryty szkic „Strażnik Żółtej Bramy — QA 15”: ⌘Q ujawnia Bestiariusz i
  fokusuje błędne TT; nazwa zachowana. Po poprawieniu TT 14, PW 42 i ruchu
  Chód 9 / Wspinaczka 4,5 zwykły przycisk zamknięcia nadal chroni
  niezatwierdzony formularz. Zapis i późniejsze ⌘Q kończą proces.
- Zamknięta baza QA: integrity_check = ok, brak naruszeń FK; pięć ID 1–5,
  niezmieniona bieżąca tura, nowy szablon zapisany.
- `git diff --check`: zaliczone.

## Dostarczenie i ograniczenia

Podmieniono `src-tauri/target/release/bundle/macos/NeuroAltar.app` w realnym
repo na 0.16.0. Poprzednia aplikacja zachowana jako `NeuroAltar 0.15.0.app`.
Zweryfikowano identyfikator, wersję i podpis po skopiowaniu; nie uruchamiano
produkcji w celu testowania danych. Pliki źródłowe i dokumentacja są w repo.

Mac zablokował się przed ostatnim ponownym uruchomieniem testowej aplikacji.
Ten punkt restartu GUI pozostaje **niezweryfikowany**; użytkownik został poproszony
o odblokowanie, pozostała praca trwa. Nie utożsamiać kontroli zamkniętej SQLite
z zaliczonym restartem interfejsu. Pełne statblocki/menu Bestiariusza: Etap 16.
Karta BG nadal jest zapowiedzią; brak seeda, rollera, Ekwipunku i Wiedzy MG.
Brak notaryzacji oraz odbioru Intel/Windows; lokalny build nie jest wydaniem publicznym.

## Pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_15.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/features/help/ShortcutHelp.tsx`
- `src/services/closeGuard.ts`
- `src/services/prepareAppClose.ts`
- `src/services/workspaceShortcuts.ts`
- `src/stores/navigationStore.ts`
- `tests/navigation.test.ts`
- `tests/prepareAppClose.test.ts`

## Uzupełnienie QA po odblokowaniu Maca

Podczas Etapu 16 wykonano brakujący restart aplikacji testowej 0.16.0. Ekran
główny wrócił, Panel MG odtworzył rundę 2, Łucję, slot 1 i polskie notatki.
Bestiariusz odtworzył „Strażnik Żółtej Bramy — QA 15”, TT 14, PW 42 i dwa rodzaje
ruchu. Punkt restartu GUI z poprzedniego raportu jest teraz zaliczony.
