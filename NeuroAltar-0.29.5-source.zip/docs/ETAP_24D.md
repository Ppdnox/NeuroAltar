# Etap 24D — zdrowie, zasoby, odpoczynki i postój

Data: 2026-09-20. Wersja **0.29.0**. Punkt wyjścia: `776f4ab` (czysty Git,
ukończony24C). Zmiany w lokalnym `/Users/dominik/Desktop/Combat Tracker`.
Etap wdrożony i odebrany w poniższym zakresie. Integracja walki pozostaje Etapem 24E.

## Zakres

- Pule klasowe/profesji/pochodzenia/sztuczek, zużycie, korekty z powodem,
  ręczne liczniki; odnowienie według rodzaju odpoczynku. Zdolności bez limitu
  nie otrzymują fikcyjnej puli. Nieujemne pule bez dopisanego minimum1.
- Jawne rozpoczęcie, ukończenie, przerwanie i anulowanie odpoczynku. N/D,
  Rtęć, Stal4/24h; Rdza24/72h; Chrom1/8h. Długi wymaga6h snu i dodaje godzinę
  za przerwę; przerwany długi przyznaje krótki według progu Koloru. Każda
  operacja ma podgląd i identyfikator zabezpieczający przed powtórzeniem.
- PW, KW k6/k8, Kolejka Cwaniaka, Zranienia, źródła Wyczerpania, czasowe i
  trwałe redukcje cech/maksPW, medyczne i naturalne gojenie. Długi odnawia
  wszystkie pule krótkiego, ale nie amunicję ani ręczne liczniki. Chorobowe
  blokady zatrzymują korzyści. Pancerz ogranicza KW i nie regeneruje ran ani
  Wyczerpania. Czwarte Zranienie dodaje Wyczerpanie tylko przy przekroczeniu progu.
- Fuksy ze źródłem i terminem w czasie gry, startowy raz, Fanty maks3, sesyjny
  w Stali/Chromie, zamknięcie sesji. Rtęć blokuje każde źródło i użycie.
- Osiem chorób przewlekłych, choroby nabyte i osiem fobii, wybór początkowy
  z listy nazw albo „Nie wybieram — −1 do cechy”; bez wpisywania wyników kości. Premia/kara cechy i trzy dawki leku przy chorobie.
  Choroby mają stadium, dobowy test i leki; fobie serię sukcesów, okres
  przełamania i ustanie bodźca. Naturalne1/20 w dobowym teście choroby mają
  osobne skutki. Hemofilia ma własne krwawienie i serię trzech sukcesów.
- Dobowe leki, ciągłość kuracji, uzupełnianie jedzenia/wody z opcjonalnym
  zużyciem pozycji inwentarza, próg ściśle poniżej połowy normy, pięć dni bez
  jedzenia, oddzielne przyczyny środowiskowego Wyczerpania. Zakończenie doby
  przesuwa jawny czas gry; zegar komputera nie rozlicza żadnej z tych rzeczy.
- Projekty produkcji, bazowa cena i ST, materiały, postęp max10h/dobę,
  szczególne receptury z podanym źródłem, sukces dodający produkt i zużywający
  surowce wspólnie. Porażka zachowuje surowce. Naprawa aktualizuje istniejący
  egzemplarz zamiast go kopiować; zmiana egzemplarza podczas pracy blokuje zapis.
- Fabrykator skraca czas o połowę; Przydasie zmniejsza koszt materiałów.
  Czyszczenie zapisuje przerzut dla danego egzemplarza. Gotowanie zużywa
  składniki i nadaje korzyści tej karcie. Medpak/AR-23 leczą i zużywają zapas
  wspólnie, z dziennym limitem. Trening300h z nauczycielem odblokowuje biegłość.
- Poprawiona premia Gambling we krwi: odwołanie do zdolności Nowego Jorku,
  zgodnie z katalogiem, zamiast nieistniejącej zdolności Vegas.

## Granice automatyzacji i Etap24E

Wyniki rzutów zdrowia/postoju wpisuje się ręcznie. Roller, wspólny udział BG
w potyczce, budżet A/B/R, automatyczne końce tur, wykorzystanie przerzutu po
czyszczeniu i kontekstowe Ułatwienia/Utrudnienia pozostają24E. Ich opis i stan
są zachowane; nie deklarujemy jeszcze pełnej automatyzacji walki BG.

Narzędzia, schematy, fachową pomoc i opłatę za nauczyciela użytkownik jawnie
potwierdza. Szczególne receptury oraz wariant naprawy wymagają parametrów
z podręcznika/MG; aplikacja nie wybiera ich na podstawie nazwy przedmiotu.
Przygotowanie Szybkiej produkcji wymaga osobnego rozliczenia jej puli i
szczególnej receptury. Nie wprowadzono katalogu wszystkich schematów profesji.
Gotowanie nadaje korzyści otwartej postaci, odbiorcy na innych kartach wymagają
jawnego rozliczenia. Objawy opisowe (w tym przemiana Death Breath) nie powodują
automatycznej utraty PW ani podmiany postaci. Dobowy lek zapobiega testowi
postępu; nie cofamy automatycznie istniejącego stadium bez reguły źródłowej.
Decyzja MG: leki bez masy w podręczniku liczymy jako 0 kg, także w istniejącym inwentarzu i Ekwipunku MG. Ręcznie podane masy pozostają zachowane.

## Dane

Opcjonalne `condition` poza szkicem zawiera zdrowie, odpoczynki, zasoby, Fuksy,
`care` i `downtime`. Brak na starszej karcie nie wywołuje automatycznego zapisu.
Od pierwszej operacji aktualne PW są własnością zdrowia; szkic nie może ich
cofnąć. Leczenie, produkcja, dziennik, rewizja i inwentarz zapisują się w jednej
transakcji. Ponowienie używa tego samego polecenia i operationId. Rust niezależnie
przelicza wynik, kontroluje kontekst i porównuje go z podglądem.

Migracja013 przebudowuje wyłącznie ograniczenie rodzajów poleceń przez
kopiowanie całej historii. Nie kasuje kart, wpisów ani bazy. Migracje001–012
pozostają bez zmian. Wszystkie testy natywne wykonujemy na izolowanej bazie QA.

## Weryfikacja i dostarczenie

- `pnpm check`: **395 testów, 60 plików — PASS**; TypeScript, ESLint i Prettier PASS.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **78 testów — PASS**. Zgodność TS/Rust, nieprawidłowy kontekst, zapis atomowy zdrowia i zapasu, ponowienie, konflikt i rollback.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: PASS.
- `pnpm build:macos`: PASS, produkcyjny bundle 0.29.0. `codesign --verify --deep --strict`: PASS. Podpis lokalny ad hoc; bez notaryzacji Apple.
- Ostrzeżenie Vite: główny plik JS 871,67 kB (256,13 kB gzip), ponad próg 500 kB. Nie blokuje buildu; podział pakietu pozostaje optymalizacją.
- Testy interfejsu wyłącznie w aplikacji `NeuroAltar Stage 24D Test`, na izolowanej kopii bazy 24C. Nie używano bazy użytkownika jako środowiska testowego.
- Rdza: zużycie Berserka, krótki odpoczynek 24 h z k8=3,5 i leczeniem 7→19 PW; długi 72 h w pancerzu 19→22 PW, Berserk 1→2, KW 0→1 przy maksimum 2k8. Nieprawidłowy wynik kości zachowany z komunikatem i fokusem; niedokończony formularz blokował ⌘Q. Restart zachował wynik i historię.
- Wybór choroby: Charyzma 8→9 oraz trzy dawki Aspiryny K zapisane razem; przyjęcie jednej dawki 3→2. Zamknięcie i ponowne otwarcie zachowało cechę, chorobę i dawki. Test wykrył i pozwolił poprawić blokadę przycisku „Zastosuj”.
- Po decyzjach MG sprawdzono uproszczony formularz z listą nazw, bez pól k8, oraz odmowę wyboru fobii: Charyzma 9→8, bez dodatkowych leków. Istniejąca Aspiryna wyświetla 0 kg/dawkę; obciążenie 27,05 kg i Szybkość 9 m są ponownie określone.
- Integralność SQLite kopii QA: `ok`, brak błędów kluczy obcych, migracje 1–13. Porównanie z bazą 24C: dokładnie zachowane 5 potyczek, 7 aktorów, 52 szablony, 32 logi walki, 51 wpisów seedu Bestiariusza, 299 przedmiotów, 1 partia Ekwipunku i 6 rzutów. Wszystkie dawne operacje BG, pierwotny opublikowany arkusz oraz pięć wcześniejszych pozycji inwentarza pozostały identyczne.

Aplikację **podmieniono w miejscu docelowym**:
`src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.29.0).
Poprzednia wersja została zachowana obok jako `NeuroAltar 0.28.0.app`.
SHA-256 dostarczonego pliku wykonywalnego:
`6ed27ae8ab79dfbf184d9dde1e2b0925cfdaa9e6dbc203ffa45b74ad9b356acf`.
Migracja 013 na właściwej bazie nastąpi przy uruchomieniu nowej wersji; testy jej bezpieczeństwa wykonano na bazach izolowanych.

Nie rozpoczęto 24E ani portu Windows. Pozostałe granice automatyzacji opisano wyżej; szczególne receptury i przesłanki mechaniki nadal wymagają jawnych decyzji MG.

## Pliki zmienione i dodane

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_24D.md`
- `docs/KARTA_BG_KATALOG_REGUL.md`
- `docs/KARTA_BG_KOLORY.md`
- `docs/KARTA_BG_KONTRAKT.md`
- `docs/KARTA_BG_MECHANIKA.md`
- `docs/KARTA_BG_WZORZEC.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/013_character_condition.sql`
- `src-tauri/src/character.rs`
- `src-tauri/src/character_care.rs`
- `src-tauri/src/character_condition.rs`
- `src-tauri/src/character_downtime.rs`
- `src-tauri/src/character_tests.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/character/condition-constants.v1.json`
- `src/domain/character/care.ts`
- `src/domain/character/careModel.ts`
- `src/domain/character/condition.ts`
- `src/domain/character/conditionModel.ts`
- `src/domain/character/derive.ts`
- `src/domain/character/downtime.ts`
- `src/domain/character/downtimeModel.ts`
- `src/domain/character/equipped.ts`
- `src/domain/character/feats.ts`
- `src/domain/character/inventory.ts`
- `src/domain/character/inventoryModel.ts`
- `src/domain/character/model.ts`
- `src/domain/character/resources.ts`
- `src/domain/equipment.ts`
- `src/domain/medicineWeight.ts`
- `src/features/character/CarePanel.tsx`
- `src/features/character/CharacterWorkspace.tsx`
- `src/features/character/ConditionPanel.tsx`
- `src/features/character/InventoryPanel.tsx`
- `src/features/character/condition.css`
- `src/stores/characterStore.ts`
- `tests/care.test.ts`
- `tests/characterStore.test.ts`
- `tests/condition.test.ts`
- `tests/fixtures/character-care.json`
- `tests/fixtures/character-condition-parity.json`
- `tests/fixtures/character-condition.json`
- `tests/inventory.test.ts`
