# 24E Roboczy — uzupełnienie mechaniki i opisów, 2026-10-21

Kontynuacja zaakceptowanego roboczego 24E, z zachowaniem wcześniejszych niezatwierdzonych zmian i papierowego UI. Wersja techniczna pozostaje 0.29.4. Podstawa: Neuroshima: Ostatnia Era, drukowane s. 60–107, zasady leczenia i produkcji oraz dotychczasowe rozstrzygnięcia MG.

## Wdrożenie

- Pełne opisy wszystkich pozycji katalogu zdolności sześciu klas i osiemnastu profesji: warunki, koszt, zasięg, czas, skala i strona. Opisy kości/liczby użyć skalują się poziomem odpowiedniej klasy, nie całkowitym poziomem wieloklasowej postaci. Sztuczki zachowują istniejące opisy i uzupełnione powiązania mechaniczne.
- Twardość, Amen i Kocie kości: dodatkowa kość do konkretnego zapisanego testu. Przycisk jest przy wyniku/historii kości. Nie losuje ponownie k20, zachowuje naturalną 1/20 i zużywa użycie dopiero wraz z zapisem nowego wyniku. Twardość i Amen wymagają potwierdzenia niepowodzenia. Kocie kości sprawdzają poziom oraz Akrobatykę/Inicjatywę/RO.
- Trajektoria: INT do następnego ataku dystansowego, ze zużyciem właściwej puli; atak wręcz nie zużywa przygotowanego efektu.
- Koci odskok: kość TT, Reakcja i wygaśnięcie na początku następnej tury. Podstępny atak: krwawienie, spowolnienie albo oślepienie zamiast dodatkowych obrażeń; cel BG lub przeciwnik, limit tury, termin efektu i bez automatycznego ubytku PW.
- Matrix i Odskok: wyliczenie redukcji (połowa w dół), koszt zasobu lub Reakcji oraz zapis rozliczenia. Śmiertelna obelga: jedna k6 × modyfikator CHA, z zapisem wyniku i kosztem Obelgi.
- Stałe Ułatwienia pochodzenia i klasy oraz jednoznaczne skutki zapisanych chorób trafiają do wspólnego rollera karty i potyczki. Efekt posiłku zużywa pierwszy odpowiedni RO; skutki AR-23 mają sprawdzany czas.
- Pan Plaster: dodatkowa kość leczenia i połowa dawki w dziennej kuracji choroby. RadOff używany doraźnie na ekspozycję pozostaje osobnym zastosowaniem. Rtęć nadal blokuje środki lecznicze.
- Immunitet: blokada nowego zachorowania, zachowanie chorób początkowych i nadal działające Wyczerpanie od radiacji. RO istniejącej choroby ma opis Ułatwienia w formularzu ręcznego rozliczenia.
- Szybka produkcja: limit 25/50 G, czas, surowce, użycie odnawiane odpoczynkiem i gotowe przedmioty zapisywane razem. Krwawy anioł: właściwa kość narzędzi medyka k6/k8/k10/k12; pięć użyć zestawu i uzupełnienie zapasu. Łapiduch: ST według czasu, minuta reanimacji i wykluczenie Olbrzymich obrażeń. Wynik leczenia/reanimacji jest zapisany; zdrowie wskazanego pacjenta zatwierdza gracz.
- Wyjadacz: ten sam wariant nie jest oferowany ponownie przy wieloklasowości. Istniejące wybory pozostają zachowane i mogą być poprawione jawnie.

## Granice automatyzacji

Zgodnie z ostatnią decyzją MG premie sytuacyjne, w tym Mój wróg, właściwy biom, rozpoznany cel, zasięg, widoczność i fabularne warunki pozostają po stronie gracza. Opisy podają liczby i warunki. Zdolności fabularne pozostają opisami; normalne akcje i skutki wymagające decyzji MG rozlicza się istniejącymi kontrolkami. Nie dodano automatycznego trafiania ani zmiany PW po rzucie. Nie rozszerzano ustalonej obsługi przerzutów ani łączenia efektów przeciwników. Dodatkowe kości do testu są oddzielnym mechanizmem.

Towarzysze, Windows, web i wcześniejsze wyłączenia MG pozostają poza tą aktualizacją. Obsługiwany rozwój obejmuje poziomy 1–12. Pełny odbiór sesyjny wszystkich kombinacji kart nie jest zastąpiony testami automatycznymi.

## Dane i zgodność zapisu

Bez nowej migracji SQL; migracje 001–014 nie zmieniają się. Nowe pola efektów, wyników i zapasu zestawu medyka są opcjonalne, a stare zapisy efektu posiłku rozpoznawane. Dotychczasowe pięć slotów, karty i inwentarze pozostają zachowane. Zapis dodatkowej kości/zużycie zasobu oraz posiłku/testu są transakcyjne, sprawdzają rewizję i identyfikator operacji. Ponowienie nie losuje ani nie pobiera kosztu ponownie. Nie edytowano bezpośrednio bazy użytkownika.

## Weryfikacja

- TypeScript: 475/475 testów, 69 zestawów.
- Rust: 91/91 testów, w tym zgodność podglądu i zapisu leczenia/produkcji, wycofanie całości przy błędzie zapisu, ponowienia, konflikt rewizji i jednorazowe zużycie zasobu/posiłku.
- Typecheck i ESLint bez błędów; formatowanie zmienionych plików.
- Build web i macOS zakończone powodzeniem; `codesign --verify --deep --strict` bez błędów. Natywny smoke test: otwarcie karty BG (zachowana wersja 49), opis Berserka, Postój, pięć potyczek w Panelu MG oraz zamknięcie i ponowne uruchomienie. Nie wykonano testowych rzutów ani zmian PW na danych użytkownika.
- Ostrzeżenie istniejącego lokalnego toolchaina: brak libLLVM przy zdejmowaniu symboli przez rust-objcopy; testy Rust zakończyły się powodzeniem. Bundler ostrzega o wielkości paczki i importach współdzielonych.

## Pliki tej partii

- `src-tauri/src/character.rs`
- `src-tauri/src/character_care.rs`
- `src-tauri/src/character_condition.rs`
- `src-tauri/src/character_downtime.rs`
- `src-tauri/src/character_participation.rs`
- `src-tauri/src/character_tests.rs`
- `src-tauri/src/dice.rs`
- `src-tauri/src/dice_supplements.rs`
- `src/domain/character/activeAbilities.ts`
- `src/domain/character/care.ts`
- `src/domain/character/combatAbility.ts`
- `src/domain/character/derive.ts`
- `src/domain/character/downtime.ts`
- `src/domain/character/downtimeModel.ts`
- `src/domain/character/participation.ts`
- `src/domain/character/rollConditions.ts`
- `src/domain/character/ruleDescriptions.ts`
- `src/domain/dice.ts`
- `src/domain/dicePresentation.ts`
- `src/features/character/ActiveAbilityPanel.tsx`
- `src/features/character/CarePanel.tsx`
- `src/features/character/CharacterWorkspace.tsx`
- `src/features/character/CombatAbilities.tsx`
- `src/features/character/ConditionPanel.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/features/dice/RollSupplements.tsx`
- `src/services/characterRollBonus.ts`
- `src/services/characterRolls.ts`
- `src/services/diceHistory.ts`
- `src/stores/diceStore.ts`
- `tests/characterDescriptions.test.ts`
- `tests/fixtures/character-care.json`
- `tests/fixtures/character-health-mechanics.json`
- `tests/fixtures/character-roll-mechanics.json`
- `tests/healthMechanics.test.ts`
- `tests/rollMechanics.test.ts`

Dokumentacja: ten raport, AGENTS.md, docs/24E_BRAKI_ZDOLNOSCI.md, docs/ETAP_24E.md, docs/ROADMAP.md i docs/CODEX_INSTRUCTIONS.md. Lista dotyczy tej partii; repozytorium zawiera również wcześniejsze zmiany roboczego 24E.

## Dostarczenie

Zaktualizowana aplikacja: `work/stage2-target/release/bundle/macos/NeuroAltar 24E Roboczy.app` w projekcie ChatGPT Neuroshima 5e. Zachowano identyfikator `pl.neuroshima.combat-tracker.stage24d-smoke`; nie przełączono na inną bazę. Baza przed uruchomieniem miała integralność `ok`, jedną kartę BG i pięć slotów. Poprzedni bundle i spójna kopia SQLite znajdują się w `work/backups/`.

Pliki źródłowe aktualizowane bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`, z kontrolą niezmienionych od początku pracy hashy i kopią nadpisywanych plików. Nie wykonywano commita zamykającego całe 24E; wcześniej rozpoczęte zmiany robocze pozostają zachowane. Brak notaryzacji; podpis lokalny.
