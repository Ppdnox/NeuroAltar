# Poprawki mechaniki 24E — partia 1, 2026-09-24

Podstawa: zaakceptowany przez MG roboczy 24E. Bez cofania UI i bez podmiany produkcyjnego 0.29.4. Źródło: Neuroshima: Ostatnia Era, drukowane s. 79, 86, 88, 98, 103–107; zachowane decyzje MG.

## Wdrożone

- Wspólne obliczanie broni w karcie i potyczce: Rzeźnik +3 z kontrolą drugiej broni w ręce; W czuły punkt Speca 11 dodaje INT; Clint dodaje kość rewolweru; Mistrz broni białej dodaje kość wybranego modelu.
- Ruchome gniazdo CKM podwaja kości długiej serii. Nie zwiększa zużycia amunicji ani krótkiej/miażdżącej serii.
- Szturmowiec znosi Utrudnienie KS w normalnym zasięgu. Przy broni dystansowej w potyczce dodano wybór normalnego/dalekiego zasięgu. Snajper podwaja daleki zasięg i znosi jego Utrudnienie.
- Miotacz zwiększa atak i zasięg broni faktycznie rzucanej, nie każdej broni z kategorii biegłości „miotana” (łuki i kusze nie otrzymują tej premii).
- Wyjątki jednoręcznego używania: Pulp Fiction, Stalowy nadgarstek i Rewolwerowiec. Rewolwery i PM rozpoznawane po jawnych identyfikatorach modeli katalogowych, a nie nazwie zmienionej przez gracza.
- Samuraj i Siekierezada dodają warunkową premię TT za trzymane bronie. Cichy krok usuwa ostrzeżenie o karze skradania z pancerza.
- Backend: bez Gradu ołowiu KS zużywa osobną Akcję i jest ograniczona do jednej na rundę; Grad pozwala korzystać z puli ataków. Serie obszarowe nadal wykluczają inne serie.
- Robin Hood: poprawiony identyfikator przy ładowaniu. Dostępne dodatkowe Używanie ze Szybkich rąk może opłacić obsługę broni zamiast zwykłej akcji.
- Wyczulone zmysły przekazują Ułatwienie do rzutu Percepcji z karty i potyczki.
- Zwykły kolejny test nie zużywa już oczekującego Szczęścia; wybór przerzutu ograniczony do tej samej potyczki. To częściowa poprawka, nie kompletne zamknięcie tej zdolności.
- Usunięto nieprawdziwą deklarację, że wszystkie premie każdej zdolności klasowej są już automatycznie uwzględnione.

## Pliki

- src/domain/character/equipped.ts — premie, TT, zasięgi, warunki.
- src/domain/character/weaponTraits.ts — identyfikatory modeli rewolwerów, PM i siekierki.
- src/domain/character/derive.ts — rzetelny komunikat o obsłudze zdolności.
- src/features/character/InventoryPanel.tsx — przekazanie wyposażenia do obliczeń.
- src/features/character/CharacterCombatRolls.tsx — dystans i dokładny identyfikator umiejętności.
- src/features/character/CharacterWorkspace.tsx — identyfikator umiejętności przy rzucie.
- src/features/character/CombatAbilities.tsx — ograniczenie historii Szczęścia do potyczki.
- src/services/characterRolls.ts — Percepcja i ochrona oczekującego Szczęścia.
- src-tauri/src/character_participation.rs — serie i koszty obsługi broni.
- tests/characterWeaponRules.test.ts — 10 nowych scenariuszy; dodatkowy test serii w module Rust.
- docs/ETAP_24E.md, docs/AUDYT_24E_MECHANIKA.md i ten raport — bieżący status.

## Weryfikacja

Zaliczone: 28 ukierunkowanych testów TypeScript (nowe reguły broni i istniejący inwentarz), 4 testy Rust modułu udziału w potyczce, typecheck i lint. Nie jest to pełna regresja ani natywny odbiór UI. Pełny odbiór pozostaje odroczony zgodnie z decyzją MG.

## Pozostały zakres i ograniczenia

24E pozostaje w toku. Nadal wymagają pracy: Ulubiona broń z poprawnym kosztem bonusowego strzału; kompletne Szczęście (wybór konkretnego rzutu, inicjatywa, moment użycia); pozostałe wrodzone i sytuacyjne Ułatwienia; rzeczywiste opisy i gotowe ustawienia wszystkich zdolności; efekty na przeciwników i wiele celów przy jednym koszcie. Pełny raport audytu pozostaje listą kontrolną.

Rzucanie bronią białą, np. siekierką, nadal wymaga osobnego profilu ataku dystansowego: nie podwajamy zasięgu ataku wręcz. Własne rewolwery/PM bez identyfikatora modelu katalogowego wymagają dalszej jawnej klasyfikacji. Mistrz broni białej korzysta z zapisanego modelu/wybranej nazwy; zmiana nazwy własnej broni może wymagać aktualizacji wyboru modelu.

Bez nowej migracji, kasowania danych i zmian w bazie użytkownika. Nie wykonano commita zamykającego 24E. Dotychczasowe niezatwierdzone zmiany zostały zachowane.

Build macOS 24E Roboczy i kontrola lokalnego podpisu zakończone powodzeniem. Artefakt: `/Users/dominik/.codex/.chatgpt-projects/g-p-689488ecd4448191b76fc99f91b4fdd2/work/stage2-target/release/bundle/macos/NeuroAltar 24E Roboczy.app`. Pozostały ostrzeżenia bundlera o rozmiarze paczki i współdzielonych importach. Brak notaryzacji i nowego ręcznego testu natywnego interfejsu.
