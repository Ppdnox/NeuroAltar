# Ekwipunek — źródła podręcznikowe 0.25.4

Sprawdzono rozdział Ekwipunek w **Neuroshima: Ostatnia Era** (Dark Rabbit),
PDF z prywatnego katalogu reference/. Numery poniżej są drukowanymi numerami
stron; numer strony pliku PDF jest większy o 2.

Wszystkie 299 pozycji mają przypisanie po stabilnym ID. W UI zastąpiono
„Suplement tabelaryczny • KATALOG, wiersz …” tytułem książki, stroną oraz nazwą
tabeli/sekcji. Granaty i miny występują w książce jako opisy z ceną, wagą i
dostępnością — nie nazywamy ich nieistniejącą tabelą. Koktajl Mołotowa ma także
wiersz w Tabeli różności, dlatego wskazuje dwie strony. Elektronika wskazuje
stronę tabeli 130, a nie stronę 132 z dalszym ciągiem opisów.

To korekta cytowań; ceny, dostępność, waga, opisy, mnożniki i ID nie ulegają
zmianie. Nie deklarujemy, że wszystkie wartości opracowania Excel są identyczne
z podręcznikiem. Pierwotny seed i metadane importu są zachowane do audytu.
Przypisanie prezentacji działa na dotychczasowej bazie bez migracji/reimportu.
Własne źródło MG lub przedmiot spoza seedu pozostaje bez zmian.

| Tabela / sekcja                                   | Strony   | Liczba pozycji | Wiersze dawnego katalogu (audyt) |
| ------------------------------------------------- | -------- | -------------- | -------------------------------- |
| Tabela pancerzy                                   | 113      | 17             | 5–21                             |
| Tabela broni białej                               | 116      | 20             | 22–41                            |
| Tabela broni miotanej                             | 119      | 10             | 42–51                            |
| Broń palna krótka (BPK)                           | 122      | 13             | 52–64                            |
| Broń palna pośrednia (BPP)                        | 122      | 8              | 65–72                            |
| Broń palna długa (BPD)                            | 123      | 12             | 73–84                            |
| Tabela amunicji                                   | 125      | 20             | 85–104                           |
| Magazynki wymienne                                | 126      | 5              | 105–109                          |
| Granaty i im podobne — opisy przedmiotów          | 126      | 4              | 110–113                          |
| Granaty i im podobne — opisy przedmiotów          | 127      | 3              | 114–116                          |
| Koktajl Mołotowa — opis; Tabela różności          | 127, 139 | 1              | 117–117                          |
| Miny i ładunki wybuchowe — opisy przedmiotów      | 127      | 4              | 118–121                          |
| Elektronika                                       | 130      | 26             | 122–147                          |
| Lekarstwa                                         | 132      | 8              | 148–155                          |
| Przykładowe instrumenty                           | 132      | 12             | 156–167                          |
| Tabela zestawów narzędzi                          | 134      | 22             | 168–189                          |
| Tabela mat. pirotechnicznych, narkotyków i używek | 137      | 26             | 190–215                          |
| Tabela różności                                   | 139      | 55             | 216–270                          |
| Żywność                                           | 144      | 21             | 271–291                          |
| Żywe istoty                                       | 143      | 12             | 292–303                          |

SHA256 sprawdzonego PDF: `714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`. Surowy PDF nie jest dystrybuowany.
