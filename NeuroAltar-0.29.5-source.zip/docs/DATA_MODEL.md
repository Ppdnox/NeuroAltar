# DATA MODEL — NeuroAltar

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.


Uzupełnienie MG: wybór **Koloru gry** w rogu karty (N/D, Rdza, Rtęć, Stal, Chrom),
odrębny od handlu, z wpływem na rozwój i odpoczynki. Kontrakt i testy:
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).

## Etap 24C — inwentarz, masa i amunicja BG (0.28.0)

Karty BG mają niezależny inwentarz: kopie przedmiotów z katalogu i własne wpisy,
ilości, masę, cenę zapłaconą, miejsca przechowywania, pojemniki i wyposażenie.
Przyznanie plecaka startowego jest jednorazowe; masę jego opisanej zawartości
liczymy łącznie. Dodatkową broń, pancerz i narzędzia klasy dodaje się osobno.
Zweryfikowane profile 79 pozycji (62 bronie, 17 pancerzy/akcesoriów) dotyczą kopii BG.
Przeciążenie, pancerz i wyszkolenie wpływają na widoczne TT/Szybkość/ataki.
Nieznana masa wskazuje pozycję do uzupełnienia i nie udaje pełnego obciążenia.

Dokładny zapas i magazynki są rozłączne. Ładowanie, rozładowanie, wymiana,
przeładowanie mechanizmu i jawny zapis strzału mają podgląd i trwałe operationId.
Chrom domyślnie używa nieliczonego zapasu; ręczne oznaczenie naturalnej1 ustawia
pustą broń, przeładowanie przywraca gotowość. Dokładne ilości pozostają zachowane.
Decyzje MG: środki leczące w Chromie cena×0,5 (MG i BG); Gambling we krwi
+5 punktów procentowych **przed** mnożnikiem Koloru, ograniczenie0–100 na końcu.
Kolor gry i warunki handlu pozostają niezależne.

`Character.inventory` jest osobne od `sheet` i `draft`: odrzucenie rozwoju nie
cofa amunicji. Migracja012 rozszerza rodzaje poleceń, zachowując pełną historię;
001–011 i dane Panelu MG pozostają bez zmian. Raport: docs/ETAP_24C.md.
Minimum0PW na awans, Samouk9, Twardziel3/7/11 i cały Etap24B są zachowane.
Następny osobno zlecany podetap: **24D — zasoby i odpoczynki**;
potem24E integracja walki i odbiór macOS,25Windows. Zasady zacięcia/kosztów akcji,
krytyków i ograniczeń rundy zostaną połączone z udziałem BG w24E.
Nie deklarować pełnej karty ani wszystkich efektów Kolorów przed odbiorem24E.

## Stan implementacji

Etapy 0–1: `encounters` (migracja 001). Etap 1.5 nie zmieniał schematu.
Etap 2: `encounter_actors` i `encounters.combat_revision` (migracja 002), wyłącznie BG.
Etap 3: enemy_templates oraz encounter_actors.reset_snapshot_json (migracja 003).
Etap 4: combat_log i indeks slotu/kolejności (migracja 004).
Etap 5: actor_statuses, indeks aktora i ochrona tożsamości statusu (migracja 005).
Etap 8: revision/deleted w enemy_templates (migracja 006).
Etapy 6–7 i 9–14 korzystają z istniejących tabel/JSON, bez kolejnej migracji.
Pozostałe tabele są projektem przyszłych etapów, nie deklaracją istniejących tabel.
Nowe modele Etapu 2 mają typy TypeScript i walidację Zod oraz walidację polecenia Rust.

## encounters
Stałe 5 rekordów:
- id 1..5
- name
- notes
- round_number
- current_turn_actor_id
- party_levels_json
- combat_revision: nieujemna wersja optymistycznej kontroli zapisu BG/tury (Etap 2)
- created_at
- updated_at

## enemy_templates — model docelowy
- id UUID
- name
- category: human | beast | machine | other
- subtype
- size
- tt
- hp_max
- initiative_modifier
- initiative_average
- pb
- sp
- statblock_json
- timestamps

`statblock_json`:
```json
{
  "abilityScores": {},
  "speeds": [],
  "savingThrows": [],
  "skills": [],
  "senses": [],
  "damageResistances": [],
  "damageVulnerabilities": [],
  "damageImmunities": [],
  "conditionImmunities": [],
  "items": [],
  "cowardicePercent": null,
  "injuryTrack": {"enabled": false, "initialLevel": 0},
  "damageThreshold": null,
  "failureThreshold": null,
  "traits": [],
  "actions": [],
  "bonusActions": [],
  "reactions": [],
  "legendaryActions": [],
  "legendaryActionPool": null
}
```

## items / Item — wspólny model Ekwipunku

Przyszła tabela `items` i repozytorium Ekwipunku zastępują plan osobnej tabeli
`weapons`. Broń nie ma drugiej tożsamości poza Item.

- id: UUID
- name: niepusta nazwa
- type: `weapon | armor | ammunition | tool | electronics | food | fuel | other`
- category: opisowa podkategoria przedmiotu
- economicCategory: stabilny klucz kategorii ekonomicznej do reguł regionu
- basePrice: PriceRange | null, gambli
- baseAvailability: AvailabilityRange | null, procentów
- weight: nieujemna liczba | null, kg
- description: tekst
- properties: lista właściwości opisowych
- weaponProfile?: WeaponProfile — opcjonalny; używany dla `type: weapon`
- source: opcjonalne odniesienie do pochodzenia danych
- createdAt / updatedAt

```ts
type PriceRange = { min: number; max: number };
type AvailabilityRange = { min: number; max: number };
type MarketValues = {
  price: PriceRange | null;
  availability: AvailabilityRange | null;
};
```

Min/max to skończone liczby, `min <= max`. Cena >= 0, dostępność 0–100.
Wartość pojedyncza to `min === max`. `null` oznacza brak informacji, nie cenę 0
ani 0% dostępności; nie zgaduj brakującej granicy. Zakresy nigdy nie są spłaszczane
do średniej. Item może istnieć bez danych handlowych, także w v1.0.

### WeaponProfile

Przykładowa wartość opcjonalnego `weaponProfile`:

```json
{
  "attackKind": "melee",
  "abilityRule": "str",
  "range": {"normal": null, "long": null, "unit": "m"},
  "damageModes": [
    {"id":"default","label":"standard","dice":"1k8","average":null,"damageType":"kłute","condition":null}
  ],
  "properties": [],
  "fireModes": [],
  "ammoVariants": []
}
```

`abilityRule`: `str | dex | finesse`. NPC zawsze traktowany jako biegły.
Brak profilu oznacza brak profilu bojowego, nie automatycznie zerowe obrażenia.
Warianty amunicji opisują wpływ na profil; nie ewidencjonują liczby nabojów.
Wyposażenie szablonu może wskazywać Item, ale prepared snapshot kopiuje potrzebne
dane. Edycja katalogu lub podmiana runtime nie zmienia szablonu ani innych instancji.

## TradeContext — kontekst handlu (wdrożony w Etapie 20)

```ts
type TradeColor = 'none' | 'rust' | 'mercury' | 'steel' | 'chrome';
type RegionSelection = { kind: 'none' } | { kind: 'region'; id: string };
type LocationSelection = { kind: 'none' } | { kind: 'location'; id: string };
type TradeContext = {
  region: RegionSelection;
  location: LocationSelection;
  color: TradeColor;
};
const BASE_TRADE_CONTEXT: TradeContext = {
  region: { kind: 'none' },
  location: { kind: 'none' },
  color: 'none',
};
```

`none` prezentujemy jako N/D / brak modyfikacji dla każdego wymiaru niezależnie.
Jest to stan domyślny pierwszego wejścia do Ekwipunku. Konkretne regiony i lokalizacje
(np. Dzicz, Wioska, Miasteczko, Miasto) pochodzą ze zweryfikowanego katalogu reguł;
nie dopisuj mnożników na podstawie samej nazwy. `none` regionu daje ×1 ceny,
`none` lokalizacji daje +0 punktów procentowych dostępności, `none` Koloru daje ×1 obu wartości.

### Kolory

Potwierdzone przez MG na podstawie aktualnego Excela (2026-09-07):

| Kolor | Klucz | Mnożnik ceny | Mnożnik dostępności | Zakres |
| --- | --- | --- | --- | --- |
| N/D | `none` | ×1 | ×1 | wszystkie przedmioty, brak modyfikacji |
| Rdza | `rust` | ×2 | ×0,5 | wszystkie przedmioty |
| Rtęć | `mercury` | ×1 | ×1 | wszystkie przedmioty |
| Stal | `steel` | ×0,5 | ×2 | tylko `weapon` i `ammunition` |
| Chrom | `chrome` | ×1 | ×2 | wszystkie przedmioty |

Dla Stali pozostałe typy (`armor`, `tool`, `electronics`, `food`, `fuel`, `other`)
mają mnożniki ×1 / ×1. O zastosowaniu Stali decyduje `Item.type`, nie obecność
weaponProfile ani kategoria ekonomiczna. Modyfikatory regionu i lokalizacji nadal
obowiązują także dla tych pozostałych typów. Rtęć jest osobnym wyborem mimo
identycznych mnożników jak N/D; nie utożsamiaj obu zapisanych wartości.

### Obliczenia zakresów

Dla każdej granicy min i max niezależnie:

```text
cena = cena bazowa × mnożnik regionu dla economicCategory × mnożnik ceny Koloru
dostępność = clamp((dostępność bazowa + poprawka lokalizacji) × mnożnik dostępności Koloru, 0, 100)
```

Najpierw dodaj poprawkę lokalizacji, potem zastosuj Kolor, na końcu clamp.
Poprawka lokalizacji jest w punktach procentowych. Mnożniki są nieujemne, skończone.
Nie zaokrąglaj wyników w domenie i nie zmieniaj bazowego Item.
Brak ceny lub dostępności (`null`) propaguje się niezależnie do odpowiedniego wyniku.
Zatem `none/none/none` zwraca dokładnie bazową cenę i dostępność, łącznie z granicami
zakresu i brakiem danych. Kontrakty funkcji: `docs/TECH_SPEC.md`.

## knowledge_entries / KnowledgeEntry — v1.2

Przyszły lokalny wpis Wiedzy MG:

- id: UUID
- title: niepusty tytuł
- category: klucz kategorii wiedzy
- content: tekst wpisu
- tags: lista tagów
- source: opcjonalne odniesienie (np. tytuł i strona)
- createdAt / updatedAt

`ReferenceEntry` jest aliasem `KnowledgeEntry`, nie odrębną tabelą ani drugim
modelem. Brak UI, seeda i tabel wiedzy w Etapie 1.5. Główny prywatny katalog
`reference/` nie jest źródłem automatycznie publikowanym lub bundlowanym.

## Jednorazowy seed Excel — v1.1

Excel służy raz do przygotowania zwalidowanych rekordów Item, bez zależności
od arkusza w działającej aplikacji. Nie projektujemy runtime sync, obserwowania
pliku ani ponownego importu. Wydanie v1.1 dostarczy dane startowe; sposób ich
wersjonowanego zastosowania musi zachować dane użytkownika i snapshoty.
Nowe tabele/seed zostaną dodane bez kasowania lub odtwarzania istniejącej bazy.

## encounter_actors
- id UUID
- encounter_id 1..5
- kind: pc | enemy
- template_id nullable
- display_name
- initiative_value nullable
- initiative_tie_order
- tt_current
- hp_current
- hp_max_current
- prepared_snapshot_json
- runtime_overrides_json
- timestamps

Etap 2 nie implementował resetu. Etap 3 używa aktywnego reset_snapshot_json z fallbackiem
do niezmiennego prepared_snapshot_json. Zasady poniżej.

### Zaimplementowany PcActor / Combat — Etap 2

`PcActor`: UUID, displayName, ttCurrent, hpCurrent, hpMaxCurrent, initiativeValue
(nullable), initiativeTieOrder, statuses (lista nazw). TT >= 0, maks. PW >= 1,
0 <= aktualne PW <= maks. PW; liczby całkowite w bezpiecznym zakresie JavaScript.
Puste pole inicjatywy = null, także 0/ujemne wyniki są poprawne. UUID i pozycje
w remisie są unikalne w potyczce; duplikaty imion są dozwolone.

`Combat`: encounterId (1–5), revision, roundNumber, currentTurnActorId, actors.
Wskazana tura musi należeć do aktora z inicjatywą w tym slocie. Ręczne przesunięcie
remisu nie zmienia tożsamości aktywnego aktora. Brak inicjatywy lub usunięcie
aktywnego BG zwalnia bieżącą turę; numer rundy pozostaje.

W tabeli `encounter_actors` `kind` = pc i template_id = null w tym etapie.
`prepared_snapshot_json` zawiera PcActor z pierwszego zapisu; kolejne zmiany
runtime nie nadpisują tej kopii. `runtime_overrides_json` ma aktualnie postać
`{ "manualStatuses": ["Przerażenie"] }`. To osobny, zwalidowany wariant Etapu 2;
przykład modyfikatorów bojowych niżej jest projektem kolejnych etapów.
Tabela actor_statuses i czas statusów powstaną w Etapie 5 z zachowaniem ręcznych wpisów.

Zapisywana jest cała potyczka bojowa w jednej transakcji Rust/SQLx na wspólnym
poolu pluginu SQL. Aktualizacja wymaga zgodnej revision, zwiększa ją o 1, upsertuje
aktorów, zapisuje rundę/turę i usuwa tylko pominiętych BG tego slotu. Błąd dowolnego
kroku wycofuje całość. Nazwa i notatki nadal mają niezależny zapis Etapu 1.
Nie wolno używać osobnych `BEGIN`/`COMMIT` przez frontendowy pool pluginu.


## actor_statuses — pierwotny projekt (aktualny kontrakt Etapu 5 poniżej)
- id
- actor_id
- system_key nullable
- name
- description
- is_system_status
- duration_type: manual | rounds | until_start_of_turn | until_end_of_turn | until_end_of_next_turn
- duration_value nullable
- source_text nullable
- metadata_json
- created_at

## actor_resources
- id
- actor_id
- resource_key
- name
- current_value
- max_value
- refresh_rule: round | encounter | day | manual
- metadata_json

## combat_log — Etap 4
- id: INTEGER PRIMARY KEY AUTOINCREMENT, stabilna kolejność i kursor
- encounter_id
- round_number
- actor_id nullable
- event_type
- message
- payload_json
- created_at

## app_settings
- key
- value_json

## runtime_overrides_json — przykład
```json
{
  "injuryLevel": 0,
  "exhaustionLevel": 0,
  "weaponOverrides": [],
  "machineFailures": [],
  "attackModifier": 0,
  "speedMultiplier": 1,
  "ttModifier": 0,
  "reactionBlocked": false,
  "bonusActionsBlocked": false,
  "legendaryActionsBlocked": false,
  "meleeAttacksBlocked": false,
  "meleeDamageMultiplier": 1
}
```

Wszystkie JSON-y muszą mieć typ TypeScript i schemat Zod.

## Difficulty
`SD = sum(party levels)`
`SP = sum(enemy SP)`
`ratio = SP / SD`
Dla SD=0 nie pokazuj NaN/Infinity.

## Zaimplementowany Actor i szablon — Etap 3

Actor zachowuje pola BG Etapu 2 i dodaje opcjonalne:
- `enemy: { template: EnemyTemplate, speeds: Speed[] }` — brak = BG;
- `prepared: PreparedActor` — kopia pól Actor bez zagnieżdżonego prepared.

EnemyTemplate: id UUID, name, category human/beast/machine/other, size, tt (int ≥ 0),
hpMax (int ≥ 1), speeds. Speed: mode (niepusty tekst), meters (skończone ≥ 0).
Nazwy ruchu są unikalne bez rozróżniania wielkości liter, wartości w metrach.
Ruch może być ułamkowy. JSON-y mają typy/Zod i zgodną walidację Rust.

Minimalna tabela enemy_templates w 003 zawiera id/name/category/size/tt/hp_max,
statblock_json `{ "speeds": [...] }` i created_at/updated_at. Pozostałe pola modelu
DOC powyżej są przyszłe. Instancja ma kind enemy, template_id i kopię szablonu
w runtime_overrides_json `{ "manualStatuses": [...], "enemy": { "template": ..., "speeds": [...] } }`.
BG zachowują wariant `{ "manualStatuses": [...] }`, kind pc, template_id null.

`prepared_snapshot_json` pozostaje niezmiennym zapisem pierwszego utworzenia.
`reset_snapshot_json` (nullable) zawiera aktualnie przygotowany punkt powrotu,
zastępowany przy jawnym prepare. Przy null czytamy oryginalny snapshot z Etapu 2.
Nowe postacie otrzymują punkt powrotu już przy utworzeniu; MG może go później zastąpić.
Runtime edycje zachowują prepared. Reset odtwarza pola obecnych aktorów i normalizuje
kolejność remisów po zmianach składu, ustawia roundNumber 1/currentTurnActorId null.
Rewizja zapisu zwiększa się; nazwy/notatki slotów pozostają niezależne.
Oryginalne snapshoty nie są przepisywane podczas migracji ani prepare/reset.

## Kontrakt logu — Etap 4

CombatLogEntry: id (dodatnia bezpieczna liczba całkowita), encounterId 1–5,
roundNumber ≥ 1, actorId UUID|null, eventType, message, payload, createdAt (UTC ISO).
Payload ma `{ before: unknown, after: unknown }` w zależności od typu zdarzenia;
JSON jest zwalidowany jako obiekt. PW używa current/max, ruch listy mode/meters,
inicjatywa number|null, statusy listy nazw. Wpisy składu przechowują kopię danych
instancji bez prepared. UI formatuje czas lokalnie; zapis timestamp pozostaje UTC.

EventType: actor_added, actor_removed, name_changed, hp_changed, tt_changed,
initiative_changed, tie_changed, statuses_changed, movement_changed, turn_changed,
round_changed, prepared, reset. Kolejne mechaniki rozszerzą kontrakt w swoich etapach.
actor_id celowo nie ma FK ani kaskady, więc usunięcie aktora nie zmienia historii.
encounter_id wskazuje stały slot z RESTRICT. Indeks (encounter_id, id DESC).
Wyczyść log usuwa tylko rekordy tego slotu; AUTOINCREMENT nie używa ponownie ID.
Czyszczenie nie tworzy nowego wpisu, więc wynik jest pusty. Przy migracji log jest pusty.

## Status / effects — Etap 5

Actor i PreparedActor mają opcjonalne effects: Status[]. Brak pola oraz [] oznaczają
brak statusów strukturalnych; starsze snapshoty pozostają poprawne. ActorDraft kopiuje
effects niezależnie od statusesText. Właścicielem statusu jest instancja, nie szablon.
Dotychczasowe statuses: string[] / runtime manualStatuses nadal służą opisowym wpisom.

Status: id UUID, systemKey (klucz katalogu lub null), name (niepuste), description,
sourceText, durationType, durationValue (1–999 tylko dla rounds, inaczej null),
remaining, level (1–6 tylko dla Wyczerpania, inaczej null).
remaining: null dla manual/start, 1..durationValue dla rounds, 1 dla end,
1..2 dla end_next. Zakończenie przy remaining=1 usuwa wpis, nie zapisuje zera.
Wyczerpanie wymaga manual i jednego wpisu na aktora. Inne stany mogą mieć wiele źródeł.
SystemKey musi należeć do katalogu, a name odpowiadać jego polskiej nazwie.
Wszystkie UUID w aktualnym składzie są unikalne; snapshoty zawierają własną kopię.

actor_statuses: id TEXT PRIMARY KEY, actor_id FK encounter_actors ON DELETE CASCADE,
status_json (pełny Status bez actor_id), created_at UTC. Indeks (actor_id,id).
Trigger odrzuca zmianę id/actor_id; upsert nie przenosi statusu między postaciami.
Czytanie aktorów, statusów i tury w repozytorium to jeden SELECT z agregacją JSON,
a zapis odbywa się w istniejącej transakcji Rust. Migracja nie zmienia starych wierszy.

Nowe typy logu: status_added, status_updated (także pozostały czas), status_removed,
status_expired i burning_reminder. Payload przed/po ma pełny Status albo null;
przypomnienie Podpalenia ma after {dice:'1k4'}. Dodanie aktora obejmuje jego effects
w zdarzeniu actor_added. Historyczne statuses_changed nadal zawiera listy nazw.
SaveReason rozszerzono o advance. Zmiana powodu nie omija walidacji ani rewizji.

## Kontrakt wdrożony w Etapie 6 (0.7.0)

Powyższy pełny model docelowy nie oznacza wdrożenia wszystkich pól. W bieżącym
EnemyTemplate (i statblock_json tabeli enemy_templates) dodano opcjonalnie:

```ts
injuryTrack?: { enabled: boolean; initialLevel: number }; // całkowite 0–4
cowardicePercent?: number | null; // całkowite 0–100; null/brak = bez progu
```

EnemyInstance (w runtime_overrides_json.enemy i snapshotach aktora):

```ts
injury?: { enabled: boolean; level: number; deathWarning: boolean };
cowardicePercent?: number | null;
```

Level 0–4. deathWarning dozwolone wyłącznie przy enabled=true i level=4.
Wyłączony tor ma poziom 0 i brak ostrzeżenia (także initialLevel=0 w szablonie).
Brak pól w historycznych JSON oznacza wyłączone mechaniki, bez uzupełniania danych.
Pole runtime jest niezależne od szablonu; nowe kopie kopiują konfigurację szablonu.
Rust pomija null przy serializacji procentu; null i brak mają identyczne znaczenie.

Wyczerpanie po wejściu na 4 używa tego samego effects/actor_statuses co Etap 5;
bez drugiego licznika. Prepared snapshot zawiera jego UUID i poziom oraz injury
i procent instancji. Reset niczego nie nalicza, tylko odtwarza snapshot.
Wyniki kar/próg nie są zapisanymi statystykami. Log dodaje trzy eventType:
injury_changed, cowardice_changed, cowardice_warning; payload nadal before/after.
Bez migracji SQL: użyte istniejące typowane JSON; migracje 001–005 niezmienione.

## Kontrakt wdrożony w Etapie 7 (0.8.0)

EnemyTemplate.capabilities?: CapabilitySetup zawiera:

```ts
interface ResourceDefinition { id: string; name: string; maxValue: number; refreshRule: 'round' | 'encounter' | 'day' | 'manual' }
interface Ability { id: string; name: string; description: string; kind: 'action' | 'bonus' | 'reaction' | 'legendary'; legendaryCost: number; resourceId: string | null; resourceCost: number }
interface CapabilitySetup { resources: ResourceDefinition[]; abilities: Ability[]; legendaryMax: number }
```

EnemyInstance.capabilities?: CapabilityState zawiera te definicje, przy czym każdy
Resource dodatkowo ma currentValue. Ponadto:

```ts
budget: { action: number; bonus: number; reaction: number; legendary: number };
usageNumber: number;
lastUse: { name: string; kind: Ability['kind']; override: boolean } | null;
```

UUID definicji unikatowe wewnątrz konfiguracji. Zasób 0–max, max 1–999. A/B/R 0–1,
Legendarnych 0–legendaryMax (0–999). Koszty całkowite 1–999 i nie większe niż dana
pula; nielendarne mają legendaryCost=1. resourceId musi wskazywać zasób aktora.
usageNumber 0–MAX_SAFE_INTEGER; lastUse=null wtedy i tylko wtedy, gdy usageNumber=0.
Brak capabilities w historycznym JSON jest poprawny; puste pule A/B/R są prezentowane
jako gotowe, a dane zapisują się dopiero przy pierwszym użyciu/edycji. Legendarnych
0, bez dodatkowych zasobów. Snapshot kopiuje wszystkie definicje i aktualne liczniki.

Zapis w istniejących JSON zamiast planowanej oddzielnej actor_resources; brak
podwójnego źródła prawdy i migracji SQL. Schematy Zod/serde walidują oba kontrakty.
Nowe eventType: capabilities_changed, resource_changed, budget_changed, action_used,
resources_refreshed. SaveReason rozszerzone o new_day i renew_encounter.

## Kontrakt wdrożony w Etapie 8 (0.9.0)

EnemyTemplate zachowuje kontrakt Etapów 3/6/7. CatalogEntry to
`{ template: EnemyTemplate, revision: number }`. Dane pól podstawowych nadal są
w kolumnach, a ruch/Zranienia/Tchórzliwość/capabilities w statblock_json.
Migracja 006 dodaje `revision INTEGER NOT NULL DEFAULT 0` (nieujemne) oraz
`deleted INTEGER NOT NULL DEFAULT 0` (0/1) i indeks `(deleted,name)`.
Wszystkie stare szablony są widoczne z revision=0; rekordy aktorów są nietknięte.

CatalogMutation: `{template, expectedRevision: number|null, deleted: boolean}`.
Null oznacza utworzenie z nowym UUID; edycja/usunięcie wymaga odczytanej rewizji.
Każda zmiana istniejącego rekordu zwiększa revision o 1. Usunięcie zachowuje dane
wzorca i zaznacza deleted=1. Odczyt katalogu zwraca deleted=0; ponowny zapis aktora
nie odtwarza usuniętej pozycji. Nie zmienia się żadna tożsamość template_id.

Kopie `enemy.template` w runtime i obu snapshotach są odrębnymi wersjami danych,
których nie porównujemy już do bieżącej edytowalnej treści katalogu przy zapisie
istniejącego aktora. Porównanie dotyczy własnej zapisanej kopii tej postaci.
Archiwalna kopia z karty walki może tworzyć kolejnych niezależnych przeciwników.
Brak kaskadowej edycji/usunięcia, ponownego seeda, migracji danych lub logów wstecz.

## Kontrakt wdrożony w Etapie 9 (0.10.0)

Item implementuje opisany wyżej ogólny kontrakt, z null dla brakującej ceny,
dostępności i wagi; source opcjonalne, createdAt/updatedAt tekst czasu utworzenia
oraz edycji (aplikacja wpisuje UTC ISO). Profile mogą istnieć bez danych handlowych.
W Etapie 9 Item są kopiami osadzonymi w loadout, bez osobnej tabeli/katalogu.

```ts
type CombatLoadout = {
  pb: number | null; strModifier: number | null; dexModifier: number | null;
  items: EquippedItem[];
};
type EquippedItem = {
  item: Item;
  damageModeId: string | null;
  fireModeId: string | null;
  ammoVariantId: string | null;
};
```

EnemyTemplate.loadout? i EnemyInstance.loadout? są niezależne. Nowa instancja
kopiuje cały zestaw przed przygotowaniem snapshotu. UUID Item są unikatowe w jednym
zestawie; rodzeństwo może mieć te same ID definicji i niezależne dane.

WeaponProfile: attackKind melee/ranged, abilityRule str/dex/finesse,
attackModifier (całkowite −99…99), range {normal,long,unit:'m'}, damageModes
(co najmniej jeden), properties: string[], fireModes/ammoVariants: WeaponVariant[].
DamageMode jest zgodny z przykładem powyżej: id,label,dice,average,damageType,condition.
Formuła dice jest niepustym tekstem, average nieujemną skończoną liczbą lub null.
Range: nieujemne skończone normal/long lub null; long wymaga normal i long ≥ normal.

```ts
type WeaponVariant = {
  id: string; label: string; attackModifier: number;
  damageModeId: string | null;
  range: {normal: number|null; long: number|null; unit:'m'} | null;
  effect: string;
};
```

ID formuł/trybów/amunicji unikatowe w każdej liście. Wskazania muszą istnieć
w danym profilu. Broń z profilem wymaga wybranego damageModeId; przedmiot bez
profilu ma wszystkie wybory null. N/D trybu/amunicji to null.
Brak runtime fallback do zmienionego katalogu; oryginalny i reset snapshot zawierają
pełny zestaw. equipment_changed przechowuje jego before/after w istniejącym logu.
Brak zmiany SQL schema i wcześniejszych migracji.

## Zaimplementowane awarie — Etap 10

EnemyTemplate i EnemyInstance: `failureThreshold?: number | null`, całkowite
0..MAX_SAFE_INTEGER. W template to statblock_json; runtime i prepared zawierają
niezależną kopię. Brak pola zachowany przy odczycie starych JSON.

EnemyInstance: `machineFailures?: MachineFailure[]`, maks. 1000 aktywnych wpisów,
unikalne ID wewnątrz listy; niepusta lista dozwolona wyłącznie dla kategorii machine.

```ts
type MachineFailure = {
  id: string; // UUID; także ID powiązanego statusu dla 5/8/11/12
  result: number; // integer 1..20
  weaponId: string | null; // UUID tylko dla 1
  weaponName: string | null; // historyczna nazwa tylko dla 1
  blockedAction: 'bonus' | 'legendary' | null; // wymagane tylko dla 4
  remainingEnds: number | null; // 1 lub 2 tylko dla 5/10/12
  note: string;
};
```

Id broni jest historycznym celem, więc usunięcie/podmiana broni nie kasuje wpisu.
Wymagane jest istniejące Item przy Zastosuj, nie przy odczycie dawnej awarii.
Nie utrwalamy wtórnych attackModifier/speedMultiplier/ttModifier ani kopii
blokad z wcześniejszego przykładu modelu docelowego. Są pochodną aktywnych wpisów.
TT bieżące pole bazowe + kara daje TT efektywne; speeds pozostają przed karami.
Wyniki 6/20 zapisują HP bezpośrednio. Reset odtwarza wartości i listę ze snapshotu.

Log: `failure_threshold_changed`, `machine_failures_changed`, before/after w JSON.
Zastosowanie 6/20 również emituje hp_changed; statusy zachowują istniejące zdarzenia.
Naprawa i upływ czasu to różnice listy. Brak migracji SQL; 001–006 niezmienione.


## Etap 11 — implementacja 0.12.0

EnemyTemplate.sp?: number | null; EnemyInstance.sp?: number | null.
Nieujemna skończona liczba ≤ MAX_SAFE_INTEGER; opcjonalność zachowuje stare JSON.
Puste w edytorze oznacza null/brak, jawne 0 oznacza znane zerowe SP.
Prepared kopiuje runtime SP bez związku z późniejszą edycją katalogu.
Encounter.partyLevels: number[] już istnieje jako party_levels_json; dodatnie
bezpieczne liczby całkowite. Pusta tablica to SD=0. Reset walki nie zmienia listy.
Calculator: sd:number, knownSP:number, missingSP:number, sp:number|null,
ratio:number|null, percent:number|null, markerPercent:number|null, label:string|null.
Przy brakującym SP wynik pozostaje nieokreślony; przy pustym składzie SP=0.
Nazwy w zakresach [0,126), [126,176), [176,251), [251,+∞); cztery punkty podręcznika.
Nowy event_type sp_changed mieści się w istniejącym logu, atomowy z runtime.
Brak nowych tabel lub migracji, 001–006 pozostają niezmienione.

## Etap 12 — trwałość operacji na slocie

Bez nowej tabeli, kolumny ani migracji. Clear aktualizuje istniejący encounter
(notes='', round_number=1, current_turn_actor_id=NULL, combat_revision+1), zachowując
name, party_levels_json, created_at i ID. Usuwa tylko jego encounter_actors wraz
ze snapshotami i FK actor_statuses oraz combat_log. Enemy_templates pozostają.
Reset/Prepare korzystają z istniejących JSON i nie przepisują oryginalnego snapshotu.
Zmieniony punkt powrotu istniejącej postaci wymaga jawnego Prepare; Reset nie może
być częściowym runtime patchem. Nie odtwarza usuniętych aktorów.

## Przyszłe dane po zatwierdzeniu planu 15–25

Poniższe modele seeda, wiedzy, rollera i karty BG pozostają projektem. Migracje
001–006 są niezmienione także w 0.17.0. Ekran główny sam nie wymaga nowych tabel.

- Seed partii Bestiariusza: identyfikator partii (maszyny/potwory/ludzie), wersja,
  ID wpisu i odniesienie do źródła. Zachować rozróżnienie seeda, edycji MG,
  tombstone katalogu oraz niezmiennych kopii aktorów. Potwory mapować na kategorie
  według źródła; nie zmieniać istniejących enumów wyłącznie dla nazwy partii.
- KnowledgeEntry/ReferenceEntry: tabele Excela wymagają modelu kolumn, wierszy,
  typów/jednostek i przypisów oraz źródła arkusz/tabela. Finalny kontrakt ustalić
  po inwentaryzacji danych. Nie spłaszczać wszystkiego do zrzutu lub tekstu.
- RollResult: identyfikator, czas, formuła/parametry, wyniki kości, modyfikatory,
  suma i opcjonalna etykieta. Brak polecenia zmiany PW, amunicji lub target damage.
- Character (Etap 24, na macOS przed portem Windows): własny ID, rozwój/wybory, cechy i biegłości,
  zdolności, zasoby i reguły odpoczynków, inwentarz. Actor pozostaje instancją
  uczestnika walki; powiązanie po jawnym ID, nigdy automatycznie po nazwie.
- InventoryEntry: własność Character, kopia/odniesienie do Item, ilość i miejsce
  przechowywania/wyposażenia. Masa uwzględnia ilości; brak wagi nie jest zerem.
- Stan amunicji tylko Character: powiązanie z bronią, pojemność, naboje w magazynku,
  kompatybilny zapas; jawna operacja zużycia/przeładowania z ochroną retry.
  Nie dodawać liczników NPC. Stan 0 powoduje alarm pustego magazynka w karcie.
- RestRule/Resource: rodzaj odpoczynku, warunki i sposób odnowienia. Różne zasoby
  nie muszą wracać do maksimum. Polecenie odpoczynku nie jest zdarzeniem zegara.

W Etapie 24A ustalić kontrakt synchronizacji PW/statusów/zasobów, udział jednej
postaci w kilku slotach i ochronę resetu/clear. Nie kasować trwałej postaci wraz
z aktorem i nie cofać rozwoju/inwentarza resetem. Item/TradeContext i reguły rynku
powyżej pozostają obowiązujące. Nowe modele wprowadzać tylko wraz z ich funkcją.

## Etap 15 — dane bez zmian

Nawigacja sesyjna nie trafia do bazy. Brak migracji i tabel karty BG; wszystkie istniejące JSON i pięć slotów pozostają bez zmian.

## Etap 16 — kontrakt statblocka (wdrożony w 0.17.0)

`EnemyTemplate.statblock?: Statblock` i `EnemyInstance.statblock?: Statblock`.
Stare rekordy bez pola pozostają poprawne; nie dopisujemy im domyślnych cech.
Nowa instancja dostaje głęboką kopię szablonu. Osobne kopie w prepared i oryginalnym
snapshotcie; brak odwołania na żywo do zmienianego Bestiariusza.

- `subtype: string | null` (do 200 znaków UTF-16 po trim).
- `abilityScores: {str,dex,con,int,wis,cha}` — każda wartość `number | null`.
  Liczby całkowite 0…MAX_SAFE_INTEGER; jest to granica techniczna, nie reguła
  dozwolonych statystyk danego przeciwnika. Brak wartości to null, nigdy 10/0.
- `savingThrows` — ten sam komplet kluczy, końcowe premie całkowite ze znakiem
  w zakresie ±MAX_SAFE_INTEGER albo null. Nie dodawać PB ani modyfikatora drugi raz.
- `skills`, `senses`, `resistances`, `vulnerabilities`, `damageImmunities`,
  `conditionImmunities`: `string[] | null`. Null = nieznane, [] = jawny brak.
  Umiejętności przechowują końcowe premie i warunki w treści pozycji, np.
  „Skradanie: +4 (w cieniu)”; w tym etapie nie są silnikiem obliczania testów.
  Do 100 pozycji, każda 1–1000 znaków UTF-16 po trim; puste wiersze pomijamy.
- `damageThreshold: number | null`: całkowite 0…MAX_SAFE_INTEGER, odrębne od
  `failureThreshold`. Zero jest prawdziwą wartością. Nie wykonuje zmian PW.

Przy obecnym statblocku jego pola i sześć kluczy obu zestawów są wymagane;
nieznane wartości są jawne null. TS/Zod i Rust odrzucają obce pola, ułamki,
ujemne cechy/progi, niebezpieczne liczby i przekroczone limity opisów.
W formularzu puste pole listy oznacza N/D; pojedyncze słowo „brak” daje [].
Modyfikator cechy to floor((cecha−10)/2), wyłącznie do prezentacji. Jawne dane
ataku w loadout pozostają niezależne; bez cichego zastępowania STR/DEX/PB.

Zapis w istniejących `statblock_json`, `runtime_overrides_json` i snapshotach.
Bez migracji DDL; 001–006 bez zmian. Log `statblock_changed` zapisuje przed/po
w jednej transakcji z runtime i revision. Błąd logu wycofuje całą zmianę.
Starsza aplikacja nie zna nowego kontraktu JSON/logu: po zapisaniu statblocków
nie używać starego buildu do pracy na tej samej bazie. Backup .app nie jest backupem danych.

## Etap 17 — uwagi statblocka i rejestr seeda

`statblock.traits?: string[] | null`: pasywy, uwagi źródłowe i warunki; maks. 100
wierszy, każdy po trim 1–1000 jednostek UTF-16. Starsze brakujące pole zachowane;
null = N/D, [] = brak. TS i Rust walidują identycznie. Runtime/prepared posiadają
niezależne kopie; formularz „brak” ustawia [], pusty tekst null.

Nie dodano variants ani osobnej tabeli konfiguracji. Mobsprzęt zawiera sześć
ponumerowanych Items z opisami, ruch opisuje alternatywne podwozia. Zdolność Atak
przypomina o użyciu jednej wylosowanej broni. Item bez weaponProfile wyświetla
swój opis/properties; nie dostaje fikcyjnego Testu Ataku. Zasady RO i skutki tekstowe.

Migracja 007 tworzy `bestiary_seed_entries`: entry_id (PK), batch_id,
version (>0), offered_json, source_json, installed_revision (nullable).
Źródło zawiera klucz wpisu, tytuł, strony druk/PDF i SHA-256 pliku referencyjnego.
Pierwszy seed: INSERT tylko nieistniejącej tożsamości. Kolizja zachowuje wpis
z installed_revision=null. Ta sama wersja/payload = no-op; inny payload w tej
samej wersji = błąd pakietu. Wersja starsza nigdy nie cofa katalogu.
Nowa wersja aktualizuje tylko nieusunięty wiersz o dokładnie zgodnym poprzednim
payloadzie oraz installed_revision; revision rośnie. Każda edycja MG (także
ręcznie cofnięta), usunięcie, brak wiersza czy zmiana poza aplikacją wyłącza korekty
przez installed_revision=null. Brakujące wpisy z rejestrem nie są przywracane.
Pominięcie wpisu w nowym pakiecie niczego nie usuwa. Transakcja obejmuje katalog
oraz ledger; nie dotyka aktorów/snapshotów/logów. Brak UI reimportu/synchronizacji.

## Etap 18 — kategorie i nakładka

EnemyTemplate.category: human/machine/mutant/monster/animal, historycznie także
beast/other. Nowy formularz proponuje tylko pięć kategorii; istniejący stary wpis
zachowuje swoją kategorię do świadomej edycji MG. Runtime i snapshoty bez konwersji.
Migracja 008: enemy_templates.official_category nullable TEXT, CHECK pięciu kategorii.
Odczyt: COALESCE(official_category,category). Zapis: jawna kategoria + wartość zgodna
ze starym CHECK (animal→beast, mutant/monster→other, pozostałe bez zmian).
To mapowanie techniczne zapisu, nie klasyfikacja starych rekordów. Legacy zapis
czyści official_category. Nie przebudowujemy ani nie kasujemy tabel/bazy.
Zombie jest źródłową nakładką w domain/deathBreath.ts; brak samodzielnego EnemyTemplate
przed wyborem nosiciela. Nowy szkic kopiuje PW, ruch, zmysły, wybrane ataki wręcz,
zmienia TT o -2, SP o +2, INT na4, CHA na2. Nieznane wartości pozostają nieznane.
Po zatwierdzeniu zapisuje się zwykły niezależny EnemyTemplate z nowym UUID.
Nakładka źródłowa jest stała, nie uczestniczy w CRUD/ledger katalogu; gotowe Zombie
podlegają standardowemu CRUD i ochronie snapshotów. Brak runtime powiązania z nosicielem.

## Etap 18A — mutanci v1

Siedem nowych tożsamości w istniejących enemy_templates i bestiary_seed_entries,
batchId noe-mutants, version 1. Kategoria mutant / kompatybilne other zgodnie
z migracją 008. Brak nowej migracji. Statblock, Item/loadout i CapabilitySetup
korzystają z dotychczasowych kontraktów i niezależnych kopii runtime/prepared.
Dane niepodane w statblocku pozostają null; nie dodajemy fikcyjnego obrażenia 0
łańcuchowi ani Testów Ataku zdolnościom psychicznym opartym na RO.
Źródłowy zakres: strony drukowane 226–231, PDF 228–233. Szczegóły: ETAP_18A.md.

## Etap 18B — zwierzęta (0.21.0)

Nowa partia noe-animals v2 ma 12 wpisów z kategorią animal, stabilnymi UUID,
SHA256 podręcznika i stronami PDF 246–253 / druk 244–251. Seed ledger bez zmian.
CapabilitySetup/State: opcjonalne unlimitedReactions boolean; brak = zwykły limit.
Rust Option<bool> pomijane przy None; starsze JSON nie otrzymują nowego pola.
Budżet reaction nadal 0–1; przy true zachowany, lecz niewydawany. Koszty zasobów,
usageNumber i lastUse pozostają aktywne. Wartość obecna we wszystkich snapshotach.
Żadnej migracji SQL. Starszego programu nie uruchamiać na bazie zawierającej
nowe pole JSON; kopia starej aplikacji nie jest migracją wstecz bazy.

## Poprawki czytelności — 0.21.1

Zlecono wyłącznie korekty tekstów i widoków, bez Etapu 19. „Chód” w interfejsie
zastępuje „Szybkość”; prezentacja ruchu zawiera m. SP podręcznikowej kopii z
podaną wartością jest nieedytowalne w karcie walki; ręczne tworzenie i własne
wpisy zachowują pole. Wartości, liczenie trudności i dane pozostają niezmienione.
Usunięto wskazane dopiski administracyjne i dekoracyjny licznik slotów,
skrócono nagłówki. Pancerz: TT z wartością i opisem w nawiasie.
Wspólna prezentacja działa także na starych snapshotach; seed i SQL nietknięte.
Raport/kryteria odbioru: CZYTELNOSC_0.21.1.md. Następny etap wymaga zlecenia.

## Etap 19 — ludzie (0.22.0)

Zlecony po poprawkach 0.21.1. Dziewięć statblocków z s. 207–213 (PDF 209–215):
Cyngiel, Cywil, Gangus żołnierz, Gangus kapo, Gangus boss, Konwojent (strażnik),
Kanibal, Szeryf i Żołnierz Posterunku. Katalog startowy: 51 szablonów + nakładka Zombie.
Wariant farmera pozostaje bronią Cywila. Ofiara jest Reakcją; dodatkowy nóż Cyngla
Akcją Bonusową. Trzy długie serie mają osobne limity 2/walkę i są opisane przez RO,
bez fikcyjnego Testu Ataku. Przedmioty noszone są opisem, bez liczenia amunicji.
Nie sumować ponownie premii Kuloodpornego i Brutalnego ciosu; wartości końcowe
pozostają źródłowe. Warunkowe premie, przywołania, rzuty i obrażenia nie są automatyczne.
Nowa partia noe-humans v1, bez zmiany kontraktów ani migracji 001–008. Starsze partie,
edycje/usunięcia MG, instancje i snapshoty zachowane. Obowiązują poprawki czytelności 0.21.1.
Historyczny raport: ETAP_19.md. Etap 20 wdrożono następnie w 0.23.0.

## Etap 20 — Ekwipunek (0.23.0)

Wdrożono katalog 299 pozycji z tabelarycznego Excela: wszystkie osiem typów Item,
wyszukiwanie nazw/opisów/właściwości, filtry typu i kategorii, waga oraz zakresy
ceny i dostępności. Panel MG → Ekwipunek. Jedenaście regionów, cztery lokalizacje
i pięć Kolorów; niezależne N/D, domyślnie none/none/none. Stal modyfikuje tylko
Item.type weapon/ammunition, także gdy brak weaponProfile.

Katalog w tym etapie służy do przeglądania i obliczeń handlu. Nie zmienia
przedmiotów osadzonych w Bestiariuszu, walce ani przygotowanych kopiach.
Warunki handlu i filtry zachowują się w sesji przy przełączaniu modułów;
nowe uruchomienie zaczyna od wartości bazowych. Brak edytora katalogu,
liczenia inwentarza/amunicji, rollera, importu/synchronizacji Excela i UI Wiedzy MG.
Wagi zakresowe/przybliżone pozostają tekstem, brak danych = N/D, nigdy zero.

Migracja 009 dodaje items i equipment_seed_batches; migracje 001–008 pozostają
niezmienione. Jednorazowy, transakcyjny seed po migracjach i przed udostępnieniem
repozytoriów. Ponowny start nie nadpisuje wpisów ani nie odtwarza usunięć.
Raport: ETAP_20.md. Następny etap: 21 — Wiedza MG; tylko po nowym zleceniu.

## Etap 21 — Wiedza MG (0.24.0)

Panel MG → Wiedza MG: 50 wpisów, działy, wyszukiwanie po treści, tabelach i
nagłówkach (także bez polskich znaków), pasujące wiersze z zachowaniem kontekstu.
47 tabel/opisów z 13 arkuszy oraz trzy tabele MODYFIKATORÓW wyprowadzane z
istniejących reguł Ekwipunku. Spis zakresów: WIEDZA_MG_ZRODLA.md.
Długie opisy mają rozwijane akapity; nagłówki, jednostki, uwagi oraz odsyłacze
do arkusza/komórek pozostają dostępne. Na węższym panelu wiersze przechodzą
w karty z etykietami kolumn. Link do Ekwipunku prowadzi do przeliczania cen.

KnowledgeEntry zawiera strukturalne blocks: table (columns/rows/cells) i text;
ReferenceEntry to alias tego modelu. Wpisy są zwalidowane przez Zod i dostarczane
z aplikacją jako niezmienny katalog tylko do odczytu, bez nowej tabeli SQL.
Stan wyszukiwania/działu/wyboru trwa w sesji; nie zmienia potyczek ani ich bazy.
Migracje 001–009, identyfikator aplikacji, Bestiariusz, Item i TradeContext bez zmian.
Kolory i mnożniki handlu mają jedno źródło prawdy współdzielone z Ekwipunkiem.

Nie dodano kalkulatora, rollera, automatycznych efektów, liczników amunicji,
edycji wiedzy ani importu/synchronizacji Excela. Opisy rzutów i „Rzuć dwa razy”
są treścią tabel źródłowych; niczego nie uruchamiają. Raport: ETAP_21.md.
Następny etap: 22 — prosty roller, wyłącznie po osobnym zleceniu.

## Etap 22 — roller i strony podręcznika (0.25.0)

Zlecony po Etapie 21 (`c41dece`). Rozwijany panel Kości w prawym dolnym rogu:
k4/k6/k8/k10/k12/k20/k100, 1–100 kości, modyfikator ±10000 i pełne formuły
NkS±N (także d). Pokazuje każdą kość, sumę i 100 ostatnich wyników po restarcie.
Kliknięcie ataku, obsługiwanej formuły obrażeń, cechy, RO lub umiejętności
z jawną premią rzuca z kontekstem postaci i zapisuje wynik w logu jej potyczki.
Atak korzysta z bieżącego profilu; cecha z jej modyfikatora, RO/skill z podanej
premii końcowej. Liczbowa kara Wyczerpania dotyczy testów, nie obrażeń/awarii.
Pozostałe warunki i ułatwienia/utrudnienia ocenia MG. Nieobsługiwane, złożone
lub opisowe formuły pozostają tekstem; brak częściowego zgadywania rzutu.
Rzuć awarię k20 wypełnia istniejący formularz. Ręczne wpisanie i zmiana wyniku
pozostają dostępne. Tylko osobne „Zastosuj awarię” zmienia stan maszyny.
Rzuty nie zmieniają PW, zasobów, amunicji, tur, statusów ani wyboru celów.
Ponowienie z historii jest nowym rzutem samej formuły bez starej postaci/rundy.

Migracja 010 dodaje wyłącznie tabelę dice_rolls. 001–009 pozostają nietknięte.
Historia i opcjonalny wpis dice_rolled powstają w jednej transakcji; stabilne
UUID umożliwia ponowienie zapisu bez losowania i duplikowania. Nie zmieniamy
rewizji ani snapshotów walki. Zamknięcie czeka na zapis; błąd ujawnia panel
z zachowanym wynikiem. Skróty walki są zablokowane przy otwartym panelu kości.

Wiedza MG pokazuje tytuł „Neuroshima: Ostatnia Era” i drukowane strony zamiast
arkusza/komórek. 50 przypisań udokumentowano w WIEDZA_MG_STRONY.md. Treść tabel
pozostaje adaptacją Excela; samo dodanie odsyłaczy nie koryguje różnic mechaniki.
Surowe źródła pozostają poza repo/bundle; brak synchronizacji/reimportu.
Raport: ETAP_22.md. Następny Etap 23 — odbiór Panelu MG na macOS — wymaga zlecenia.


## Poprawki kart walki — 0.25.1

Zlecone po Etapie 22 (2cd2926), dla wszystkich przeciwników, także istniejących
instancji i wpisów MG. Bieżące cechy/RO, obrona i zmysły są stale widoczne przed
„Parametry i notatki postaci”. Opisy zdolności, reguł i broni mają klikalne jawne
premie ataku i formuły kości, także mieszane np. 2k8+2k6+4. ST/RO celu pozostaje
opisem; nie przypisuj rzutu obronnego do atakującego. Rzut nie zużywa zdolności
ani nie zmienia PW/zasobów; log zachowuje nazwę zdolności i postaci. Tekstowa
premia ataku uwzględnia liczbowe kary awarii i Wyczerpania bez doliczania PB.
Własne opisy korzystają z tej samej obsługi jawnych zapisów. Nieznanych wartości
nie zgadujemy. W historii opcjonalne groups opisuje mieszane kości; stare wpisy
bez groups nadal działają. Bez migracji i bez zmian seedów/snapshotów.
Raport: POPRAWKI_0.25.1.md. Etap 23 nadal wymaga osobnego zlecenia.


## Jednorazowy krytyk — uzupełnienie 0.25.2

Naturalne 20 w pojedynczym k20 ataku przygotowuje podwojenie kości kolejnego
rzutu obrażeń tej samej postaci i broni/zdolności. Np. 2k6+3 → 4k6+3, także
mieszane grupy; premie stałe pozostają bez zmian. Opis zdolności i profil tej
samej broni współdzielą powiązanie po ID przedmiotu. Cechy, RO, awarie i ogólny
roller nie przygotowują krytyka. Kolejny test ataku tej broni zastępuje poprzedni.
Inna postać/broń nie zużywa krytyka. Pierwszy zapisany rzut obrażeń zużywa go;
retry zapisuje identyczny wynik i nie zużywa go ponownie. Historia SQLite jest
źródłem stanu, więc wznowienie aplikacji zachowuje gotowy krytyk. Opcjonalne
purpose/sourceKey w kontekście i critical w zapisie rzutu; bez migracji SQL.
To nie rozstrzyga trafienia, celu ani PW. Raport POPRAWKI_0.25.2.md.


## Wyszukiwarka przeciwników i rzut inicjatywy — 0.25.3

„Dodaj przeciwnika” otwiera wyszukiwarkę Bestiariusza w bieżącej potyczce.
Nazwa (także bez polskich znaków) i kategoria zawężają wyniki; „Dodaj” tworzy
jedną niezależną instancję i zamyka okno. „Dodaj własnego” otwiera dotychczasowy
formularz ręczny. Escape anuluje wybór, bez zmiany składu.

Przycisk inicjatywy przy statblocku i ręcznym polu wyniku rzuca 1k20 z jawną
premią „Inicjatywa: ±N” (również dawny zapis „z podręcznika”). Liczba w nawiasie
nie jest premią. Gdy brak tej pozycji, używany jest modyfikator Zręczności;
nieznana lub sprzeczna premia wymaga ręcznego wyniku. Odejmowana jest liczbowa
kara Wyczerpania. MG nadal ocenia pozostałe warunki testu.

Wynik, historia kości, log i rewizja potyczki zapisują się w jednej transakcji.
Kolejność inicjatywy aktualizuje się bez zmiany rundy, bieżącej tury, remisów,
PW, zasobów ani przygotowanych snapshotów. Inicjatywa nie przygotowuje krytyka.
Przed rzutem kończy się autozapis; podczas zapisu edycja i zamknięcie czekają.
Błąd zachowuje dokładny wynik do ponowienia, bez kolejnego losowania. Odczyt
aktualnego stanu pozwala rozstrzygnąć niepewny zapis lub porzucić niezapisany rzut.
Ręczny wpis pozostaje dostępny. Brak migracji; 001–010 pozostają niezmienione.
Raport: POPRAWKI_0.25.3.md. Etap 23 nadal wymaga osobnego zlecenia.


## Korekta miejsca inicjatywy i źródeł Ekwipunku — 0.25.4

Zlecenie MG po 0.25.3: interaktywny jest wyłącznie istniejący wpis
„Inicjatywa: …” w „Zdolnościach stałych i zasadach” karty przeciwnika.
Usunięto dodatkowe przyciski z pola wyniku i nagłówka statblocku. Pole wyniku
ma zwykłą etykietę i ręczną edycję; cztery pola oraz przyciski „Dodaj przeciwnika”
i „Dodaj własnego” są wyrównane. Atomowy zapis inicjatywy z 0.25.3 pozostaje.
Nie dodawaj drugiego wpisu inicjatywy ani nowego przycisku poza istniejącą zasadą.

Źródła wszystkich 299 pozycji Ekwipunku pokazują „Neuroshima: Ostatnia Era”,
drukowane strony oraz właściwą tabelę/sekcję. Granaty i miny wskazują swoje
opisy, gdy książka nie zawiera tabeli. Mapa: EKWIPUNEK_STRONY.md i
src/data/equipment/handbook-sources.v1.json. Powiązanie po ID i oryginalnym
źródle seedu działa także na istniejącej bazie. Własnych źródeł MG nie nadpisujemy.
Bez zmiany danych mechanicznych, seedu, migracji lub reimportu. Raport
POPRAWKI_0.25.4.md. Etap 23 nadal wymaga nowego zlecenia.

## Etap 24A — projekt Character, nie migracja

Wiążący kontrakt: [KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md).
Character/Participation/Companion są projektami logicznymi. W24A nie utworzono
tabel, pól JSON ani typów aplikacji. Trwałe PW i zasoby należą do Character;
lokalne inicjatywa/budżety/terminy walki do Participation. Rozróżnić stary
niepowiązany BG od nowego uczestnika, żeby checkpoint nie nadpisywał karty.
Masa/ilości/jednostki, źródła efektów, rewizje i historia idempotentnych poleceń
są elementami kontraktu. Implementacja i test migracji dopiero z używającym je etapem.


## Schemat wdrożony w24B

011_characters.sql dodaje characters (UUID, revision, archived, payload_json,
created_at, updated_at) i character_operations (operation_id, character_id,
kind, request_json, result_json, created_at). FK do Character; brak FK do aktorów.

Payload Character ma schemaVersion1, metadane i sheet/draft, z których
co najmniej jeden istnieje. Sheet jest ostatnim zatwierdzonym kompletem; draft
może mieć braki. Charakterystyka: identity, method/methodReason, baseScores,
originId, levels(classId,color,contextRevision,choices), rulesContext,
advancementMode, xp, hpCurrent, notes, contacts, discoveries, overrides.
Pola pochodne wylicza deriveCharacter; nie są drugą edytowalną kopią danych.
Kości Wytrzymałości to obecnie wyłącznie wyliczone pule maksymalne, bez zużycia.

Polecenia draft/publish/discard/archive wymagają expectedRevision i operationId.
Od 2026-11-05 zmiana wcześniejszego rozwoju nie wymaga powodu ani dodatkowego
potwierdzenia. Opcjonalne correctionReason pozostaje obsługiwane dla zgodności
z istniejącymi poleceniami i historią; nowy interfejs go nie wysyła.
Pole reason w wpisie PD może być puste; opis nie jest warunkiem awansu.
Zachowane starsze overrides nadal wpływają na obliczenia, lecz od 2026-11-05
interfejs nie udostępnia edytora Korekt MG.
Transakcja zapisuje postać i dokładny wynik operacji. Dziennik nie jest kasowany
przy kolejnych zapisach; historyczne retry X po Y nie cofa Y.
Pełny przyszły model z KARTA_BG_KONTRAKT nie oznacza istnienia tabel C–E.

## Schemat wdrożony w24C

Opcjonalne `Character.inventory` (brak=empty) zawiera `entries`, `ammoMode`,
`starterClaims`; wersja starych kart pozostaje1, odczyt nie zapisuje niczego.
Każdy wpis ma niezależne ID i snapshot Item, opcjonalny catalogId,
quantityMilli, unit, weightMg/null, weightReason, massMode, container,
location/parentId, slot, paidMilli/null, notes, armor/weapon, caliber,
magazine.rounds[{ammoId,count}], installedMagazineId i stan broni.
Luźny zapas to quantityMilli; rounds to odrębne naboje. Magazynek zamontowany
podąża za bronią, pojemnik za rodzicem. Cykle i wielokrotne użycie odrzucane.
Kategoria handlowa środków leczących jest jawnym znacznikiem Item.category;
79 profili BG przypisano po stabilnych ID, bez parsowania nazw w runtime.
Migracja012 kopiuje wszystkie kolumny character_operations w transakcji,
rozszerzając CHECK rodzaju o inventory; nie przepisuje payloadów kart.

## Notatki niezależne od rozwoju — 0.29.5 (2026-11-09)

Opcjonalny `Character.journal = {notes, contacts, discoveries}` przechowuje trzy
teksty po maksymalnie 20000 znaków. Gdy brak tego pola, odczyt korzysta z dawnych
wartości `draft ?? sheet`; pierwszy zapis przenosi bieżące teksty do journal.
Stare pola zachowujemy dla zgodności historii. Autosave używa istniejącego
polecenia draft, rewizji i operationId, bez tworzenia szkicu ani publikacji.
Odrzucenie rozwoju nie usuwa journal; zapis podczas walki nie dotyka udziału,
budżetu ani logu walki. Zmiana journal innymi operacjami jest odrzucana.
Nie ma migracji SQL; istniejące migracje001–014 pozostają identyczne.

Sprzęt startowy rozszerza `inventory.starterClaims` o rozłączne znaczniki
`initial-loadout:equipment` / `initial-loadout:gamble`; dawny `initial-equipment`
oznacza już otrzymany plecak. Wyczerpanie ma nową komendę `exhaustionReduce`
odejmującą jeden poziom wskazanej przyczyny bez usuwania pozostałych wpisów.
