# Czytelność opisu przedmiotu — 24E Roboczy, 2026-11-05

Sekcja „Opis, cena i źródło” w Karcie BG ma osobne, podpisane pola
z minimalistycznymi ikonami: pojemność magazynka, zasięg, masa,
obrażenia bazowe i nabój. Wycena oraz dostępność są na osobnym pasku;
właściwości, notatki i źródła mają własne grupy. Zachowana papierowa paleta.

Zmiana obejmuje wspólny widok przedmiotu w zakładkach Broń i Ekwipunek.
Pola zawijają się zależnie od dostępnej szerokości i rozmiaru tekstu.
Ikony są dekoracyjne; znaczenie podają tekstowe etykiety. Sekcja nadal
jest zwijana i dostępna z klawiatury.

## Zachowanie danych

- Techniczne „Mag.” i „Zasięg” wydzielono wyłącznie z krótkiego zapisu
  katalogowego. Tryby ognia, SM i pozostałe właściwości pozostają widoczne.
- Pełne opisy, warunki, własne notatki i wielowierszowe dane są zachowane.
  Profil broni nie zastępuje treści opisu źródłowego.
- Masa katalogowej broni korzysta z dotychczasowego ustalenia stałej masy
  kategorii. Nie dodano masy amunicji. Leki zachowują 0 kg.
- Dokładne powtórzenia źródeł oraz sam odsyłacz do identycznych stron
  podręcznika są pokazywane raz. Inne zakresy stron i własne adnotacje zostają.
- Cena i dostępność korzystają z dotychczasowego przeliczenia rynku.
  Zero nie jest zastępowane przez N/D.
- Bez migracji SQL, zmian mechaniki, danych katalogu, zapisu i obsługi rzutów.

## Pliki

- `src/features/character/InventoryPanel.tsx` — podłączenie wspólnej sekcji.
- `src/features/character/InventoryItemDetails.tsx` — układ, ikony i etykiety.
- `src/features/character/inventory.css` — siatka i oprawa sekcji.
- `src/features/character/inventoryDetails.ts` — przygotowanie danych do wyświetlenia.
- `src/features/character/inventorySources.ts` — usuwanie powtórzeń odsyłaczy.
- `tests/inventoryDetails.test.ts`, `tests/inventorySources.test.ts` — regresje
  zachowania treści, masy amunicji i odrębnych źródeł.
- Ten raport.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier oraz **499 testów / 71 plików — PASS**.
- Rust `cargo test --release --lib`: **93 testy — PASS**.
- Frontend i natywne buildy macOS QA oraz 24E Roboczy — PASS.
- Końcowa weryfikacja podpisu `codesign --verify --deep --strict` — PASS.
- Natywny widok AR: zwykły tekst i 150%; parametry zawijają się bez nakładania.
  Sprawdzono przełączanie Broń/Ekwipunek oraz szczegóły amunicji i Aspiryny K.
- W zaktualizowanym 24E Roboczym sprawdzono M14 z przykładu użytkownika:
  20, 90/780, 4 kg, 2k8 kłute, 7,62 mm, 100 G, 25% i jedno źródło s. 123.
- Zachowano kopię poprzedniej aplikacji i bazy. Porównanie wszystkich
  **15 tabel SQLite** przed/po uruchomieniu: bez zmian zawartości.

Zaktualizowana aplikacja pozostaje pod dotychczasową nazwą „NeuroAltar 24E
Roboczy”, wersja 0.29.4. Build zachowuje wcześniejsze ostrzeżenia Vite
o wielkości paczki/mieszanych importach i lokalny podpis ad hoc; nie jest
notaryzowanym wydaniem. Ta poprawka UI nie oznacza pełnego odbioru etapu 24E.
