# Przygotowanie Windows — 2026-11-08

Baza: `1aeab92`, 24E Roboczy / 0.29.4. Użytkownik zatwierdził produkcję
Truciciela i Pogromcy jako ręczną i zlecił uporządkowanie dokumentacji oraz
przygotowanie do buildu Windows.

## Wykonane

- W README/README_FIRST, AGENTS, instrukcjach Codex/Work i promptach startowych
  zastąpiono powielone stare polecenia zwięzłym aktualnym zakresem. Dawne wersje
  są w historii Git; datowane raporty etapów i decyzje zachowano.
- STATUS, ROADMAP i PLAN_DALSZYCH_PRAC rozdzielają wdrożenia, ręczne rozliczenia,
  oczekujący odbiór 24E, przygotowanie Windows oraz przyszłe pomysły.
- DECISIONS, zakres zdolności, audyt limitów i katalog reguł zawierają decyzję:
  produkcja Truciciela/Pogromcy jest ręczna, nie stanowi braku do zaimplementowania.
- Dodano instrukcję BUILD_WINDOWS, platformową konfigurację NSIS dla x64,
  ikonę ICO z istniejącego SVG i polecenie `pnpm build:windows`.
- Dodano ręcznie uruchamiany workflow Windows: kontrole, testy, instalator,
  SHA-256 i metadane commitu; bez automatycznego Release. Konfiguracja używa
  Node24, pnpm11.19.0, Rust1.98.1 i lockfile. Brak uruchomienia w GitHub Actions.
- Dodano LF dla źródeł przez .gitattributes, z wyłączeniem oryginalnych plików
  ikon weryfikowanych sumami. Źródła prywatne i bazy nadal są ignorowane.

## Sprawdzenia wykonane na Macu

| Kontrola                                                                   | Wynik                                                         |
| -------------------------------------------------------------------------- | ------------------------------------------------------------- |
| TypeScript                                                                 | PASS                                                          |
| ESLint                                                                     | PASS                                                          |
| Prettier — cały dotychczasowy zakres i zmienione aktywne instrukcje        | PASS                                                          |
| Vitest                                                                     | 536/536 PASS, 78 plików                                       |
| Rust format                                                                | PASS                                                          |
| Rust testy release/lib z lockfile, offline                                 | 102/102 PASS                                                  |
| Frontend build Vite                                                        | PASS                                                          |
| Scalona konfiguracja Windows względem lokalnego schematu Tauri, pliki ikon | PASS                                                          |
| Odsyłacze lokalne zmienionych dokumentów i git diff --check                | PASS                                                          |
| Przegląd workflow/PowerShell/ścieżek NSIS                                  | Bez stwierdzonego blokera; nie zastępuje uruchomienia Windows |

Kontrole frontendowe uruchomiono bezpośrednio lokalnymi narzędziami Node zamiast
wrappera pnpm, który w tym środowisku próbował odświeżać instalację zależności.
Zakres odpowiada skryptowi `pnpm check`; zależności i lockfile nie zostały zmienione.
Początkowy brak wskazania domyślnego toolchainu Rust rozwiązano przez wskazanie
istniejącej instalacji; nie pobierano nowych narzędzi. Vite nadal zgłasza znane
nieblokujące ostrzeżenia o modułach importowanych jednocześnie statycznie i dynamicznie.

## Dane i ograniczenia

Bez zmian kodu mechaniki/UI, wersji, identyfikatora macOS i migracji001–014.
Nie uruchamiano aplikacji ani nie otwierano/zmieniano bazy użytkownika.
Nie podmieniono buildu macOS. Nieśledzony `ItemIllustration 2.tsx` był obecny
przed pracą, nie jest importowany i pozostaje nietknięty poza commitem.

**Nie utworzono jeszcze instalatora Windows.** Nie ma Git remote, Windows VM
ani narzędzi do cross-builda. Przygotowany workflow wymaga umieszczenia kodu
w wybranym/autoryzowanym repozytorium GitHub lub można budować bezpośrednio na
Windows zgodnie z BUILD_WINDOWS. Nie publikowano projektu ani wydania.

Nie wykonano natywnego buildu/testu Windows, nowego natywnego buildu/smoke macOS
ani końcowego odbioru sesyjnego24E. Te pozycje pozostają jawne; 638 lokalnych
zaliczonych testów nie stanowi ich zaliczenia.
