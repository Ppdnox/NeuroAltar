# Etap 21 — Wiedza MG (NeuroAltar 0.24.0)

## Wynik i zakres

Wdrożono moduł Panel MG → Wiedza MG w rzeczywistym repozytorium
`/Users/dominik/Desktop/Combat Tracker`. Stan początkowy Git był czysty,
Etap 20 zapisany w `b931573`; dodatkowy checkpoint nie był potrzebny.
Zlecenie obejmuje wyłącznie Etap 21. Etap 22 (roller) wymaga nowego zlecenia.

Katalog zawiera **50 wpisów**: 47 tabel/opisów z 13 arkuszy suplementu
oraz 3 tabele handlowe ze wspólnych reguł Ekwipunku. 47 wpisów źródłowych
zawiera 362 wiersze tabel. Dostępne są działy, wyszukiwanie bez polskich
znaków, przeszukiwanie nagłówków i treści oraz pasujące wiersze z kontekstem.
Długie opisy są podzielone na rozwijane akapity. Zachowano nagłówki,
jednostki, uwagi i zakresy źródłowe; puste komórki są pokazane jako brak danych.
Na szerokim ekranie są tabele, w wąskim panelu — karty z etykietami kolumn.
Spis i czytnik mają własne przewijanie w układzie dwóch kolumn.

Wybrany dział, wpis i hasło pozostają po przejściu do innego modułu w tej
samej sesji. Restart przywraca pełny katalog. Z tabel handlu i cen można
przejść do istniejącego przelicznika Ekwipunku. Nawigacja i zamykanie
zachowują ochronę wcześniejszych formularzy i blokadę skrótów walki poza walką.

## Źródło i model danych

Źródło: `Neuroshima_Suplement_Tabelaryczny_ulepszony (1).xlsx`.
SHA256: `829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22`.
Spis wszystkich zakresów i decyzji ekstrakcji: [WIEDZA_MG_ZRODLA.md](WIEDZA_MG_ZRODLA.md).
Jednorazowa weryfikacja 1951 nagłówków, komórek i opisów z plikiem Excel:
**zgodność potwierdzona**. Źródłowy skoroszyt pozostaje niezmieniony i nie jest
pakowany do aplikacji; arkusze PANEL MG i KATALOG obsługuje istniejący Ekwipunek.

KnowledgeEntry/ReferenceEntry zawiera typowane bloki tekstu i tabel oraz
odsyłacze do arkusza/komórek. Zod kontroluje m.in. unikalne ID i liczbę
komórek zgodną z nagłówkami. Katalog jest lokalnym zasobem tylko do odczytu.
Modyfikatory regionów/lokalizacji i Kolorów pochodzą z reguł już używanych
przez Ekwipunek. N/D pozostaje bazowe; Stal dotyczy wyłącznie broni i amunicji.

**Brak migracji SQL.** Migracje 001–009 i istniejące repozytoria danych
pozostają bez zmian. Wiedza MG nie wymaga nowej tabeli ani zapisu do SQLite.
Nie dodano edycji wiedzy, synchronizacji/reimportu Excela, rollera,
automatycznych efektów, zmian PW ani śledzenia amunicji. Źródłowe polecenia
rzutów, w tym „Rzuć dwa razy”, pozostają wyłącznie czytaną treścią.

## Weryfikacja

- `pnpm check`: PASS — TypeScript, ESLint, Prettier, **258 testów w 49 plikach**.
- Rust `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`:
  PASS — **57 testów**; `cargo fmt --check`: PASS.
- Nowe testy obejmują komplet katalogu, jednostki/puste pola/przypisy,
  wspólne reguły handlu, walidację, wyszukiwanie, retry i izolację store oraz
  renderowanie opisów. Rozszerzono testy nawigacji i ochrony zamykania.
- Natywny test wykrył zawijanie tytułu tabeli litera po literze w układzie
  kart. Poprawiono styl caption, sprawdzono format i przebudowano oba bundle;
  ponowna wizualna kontrola małego okna potwierdziła poprawkę.
- Końcowe `pnpm build:macos`: PASS, macOS ARM64, wersja 0.24.0.
- Test aplikacji Tauri na osobnym identyfikatorze i bazie: wejście do panelu,
  50 wpisów, rozwinięcie Biegania, wyszukiwanie `niewidocznosc` (3 wpisy,
  1 z 12 wierszy typowych akcji), filtr Handel (3 wpisy), tabela podróży z
  czterema tempami i uwagami, reguły Kolorów z wyjątkiem Stali.
- Przejście do Ekwipunku: 299 pozycji, N/D we wszystkich trzech wymiarach;
  cena 2 gb i dostępność 50% przykładowej amunicji zgodne z wartościami bazowymi.
  Powrót zachowuje dział Handel i wybrany wpis Kolorów.
- Widok około 1100 px, wąskie okno około 760 px, pełny ekran i tekst 115%:
  PASS. Rozwijanie opisów i polskie treści: PASS.
- `⌘Q`, ponowne otwarcie, pełny katalog z wyczyszczonym filtrem oraz
  zamknięcie przez systemowe Okno → Zamknij: PASS; proces kończy działanie.
- Porównanie wszystkich tabel testowej bazy przed/po: **identyczne dane**.
  Zachowano 5 potyczek, 9 aktorów, 2 statusy, 43 logi, 51 szablonów i 51
  wpisów rejestru Bestiariusza, 299 przedmiotów, 1 partię Ekwipunku,
  9 wpisów migracji oraz sekwencję SQLite. `PRAGMA integrity_check`: `ok`.
  Natywne testy nie korzystały z produkcyjnej bazy użytkownika.

## Dostarczenie i ograniczenia

Aktualizacja plików bezpośrednio w dotychczasowym repo. Gotowy bundle:
`src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzednia aplikacja zachowana obok jako `NeuroAltar 0.23.0.app`.
Podpis lokalny ad hoc sprawdzany przed i po skopiowaniu; bez notaryzacji Apple.

Build zgłasza ostrzeżenie o głównym pakiecie JS większym niż 500 kB
(597,05 kB, około 168,48 kB gzip). Nie blokuje uruchomienia ani testów;
przy dalszym powiększaniu katalogu warto rozważyć ładowanie modułów na żądanie.
Nie przeprowadzono odbioru Windows — port pozostaje Etapem 24.
Wiedza przedstawia zasady suplementu; nie rozstrzyga automatycznie walki ani
nie zastępuje istniejących obliczeń. Nie rozpoczęto Etapu 22.

## Pliki zmienione lub dodane

- `.prettierignore`
- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WIEDZA_MG_ZRODLA.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/knowledge/README.md`
- `src/data/knowledge/catalog.ts`
- `src/data/knowledge/tables.v1.json`
- `src/data/knowledge/trade-notes.v1.json`
- `src/domain/knowledge.ts`
- `src/features/reference/KnowledgeWorkspace.tsx`
- `src/features/reference/README.md`
- `src/features/reference/knowledge.css`
- `src/stores/bestiaryStore.ts`
- `src/stores/knowledgeStore.ts`
- `tests/knowledge.test.ts`
- `tests/navigation.test.ts`
- `tests/prepareAppClose.test.ts`
- `docs/ETAP_21.md`
