# Zapis szkicu BG i udział w potyczce — 2026-11-05

## Zgłoszenie i przyczyna

Odrzucone zatwierdzenie rozwoju podczas aktywnej walki pozostawało jako operacja
oczekująca. Blokowało edycję karty i `flush`, którego wymaga zakończenie udziału.
Analogicznie odrzucony reset potyczki pozostawał w kolejce zapisu potyczki.

## Zakres

- Szkic nadal zapisuje się podczas aktywnej walki; zatwierdzenie rozwoju dopiero po jej zakończeniu.
- Odrzucenie zatwierdzenia lub archiwizacji z powodu aktywnego udziału nie blokuje kolejki.
- Przycisk na karcie otwiera dokładnie ten slot i uczestnika, do którego należy aktywny udział.
- Sekcja zakończenia udziału jest u góry panelu uczestnika i otwiera się przy szkicu karty.
- Zakończenie udziału dopuszcza szkic. Nie wymaga odłączania ani usuwania postaci; nadal wymaga rozliczenia jej efektów.
- Reset i czyszczenie sprawdzają aktywny udział przed rozpoczęciem operacji. Odrzucony reset jest wycofywany także z późniejszych szkiców, zachowując ich pozostałe edycje; odrzucone czyszczenie zwalnia blokady.
- Komunikat reguły bez oczekującego zapisu nie wyświetla niepotrzebnych przycisków ponawiania i porównania.

## Bezpieczeństwo

Nie zmieniono schematu bazy ani reguł walki. Nie kończymy udziału, nie usuwamy
efektów ani nie odnawiamy zasobów automatycznie. Nieznane błędy zapisu nadal
zachowują operację do bezpiecznego ponowienia. Baza i poprzednia aplikacja mają
kopie w `work/participation-deadlock-2026-11-05` w środowisku roboczym.

Przed aktualizacją odzyskano szkic w starej aplikacji przez porównanie zapisów.
Porównanie payloadów postaci potwierdziło identyczność wszystkich danych poza
numerem rewizji i datą zapisu. Stary proces wymagał zakończenia po zabezpieczeniu
bazy: odrzucony reset uniemożliwiał normalne zamknięcie. Reset nie został wykonany.

## Weryfikacja

Test natywny na osobnej bazie: odrzuć zatwierdzenie podczas aktywnego udziału,
przejdź do właściwego slotu, rozlicz Berserk i zmęczenie, zakończ udział,
zatwierdź zachowany szkic bez odłączania postaci — wynik prawidłowy.

- `pnpm check`: typy, lint, formatowanie i 488/488 testów w 69 plikach — OK.
- `cargo test --release --lib`: 93/93 — OK.
- `pnpm build`: OK; pozostają znane ostrzeżenia bundlera o mieszanych importach.
- Build natywny QA i „NeuroAltar 24E Roboczy” oraz kontrola podpisu ad hoc — OK.
- Test natywny odmowy resetu przy aktywnym BG, następnie zakończenia udziału — OK; odrzucony reset nie wrócił przy zapisie.
- Brak migracji. Dotychczasowe PW, wyposażenie, efekty i szkic użytkownika zachowane.

Lista plików: `src/stores/characterStore.ts`, `src/stores/combatStore.ts`,
`src/stores/encounterMaintenanceStore.ts`, `src/services/combat.ts`,
`src/features/character/CharacterWorkspace.tsx`,
`src/features/character/ParticipationPanel.tsx`, `tests/characterStore.test.ts`,
`tests/combatStore.test.ts`, `tests/encounterMaintenance.test.ts`,
`src-tauri/src/character_participation.rs` (tylko test), `AGENTS.md`,
`docs/DECISIONS.md` i ten raport.
