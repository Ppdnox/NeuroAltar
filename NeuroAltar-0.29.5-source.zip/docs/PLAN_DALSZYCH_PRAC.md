# NeuroAltar — plan dalszych prac

Aktualizacja **2026-11-09**, baza **24E Roboczy / 0.29.5**.
[Status](STATUS.md) · [Roadmapa](ROADMAP.md) · [Windows](BUILD_WINDOWS.md)

## Teraz: build i odbiór na komputerze Windows

Osiem poprawek karty BG wdrożono: [raport](POPRAWKI_8_2026-11-09.md).
Przekazanie i polecenie dla Codexa: [Windows](PRZEKAZANIE_WINDOWS_2026-11-09.md).
Produkcja Truciciela i Pogromcy pozostaje ręczna: zachować opisy, bez dedykowanych
liczników, automatycznych kosztów i dopisywania produktów podczas odpoczynku.
To świadomie przyjęty zakres, nie niedokończona mechanika.

- Konfiguracja Windows x64/MSVC, instalator NSIS `.exe`, istniejąca ikona w ICO.
- Powtarzalne polecenie budowania i ręcznie uruchamiany workflow na Windows.
- Budowanie z przypiętych zależności i bez surowych źródeł, baz czy prywatnych plików.
- Wynik: instalator, informacja o wersji/commicie i suma SHA-256.
- Zachować wariant macOS 24E Roboczy, jego identyfikator i bazę. Windows
  rozpoczyna z własną bazą, bez automatycznego importu danych z Maca.
- Repozytorium nie ma obecnie zdalnego adresu. Wybór miejsca i uprawnienia
  do wysłania kodu są oddzielnym krokiem przed uruchomieniem GitHub Actions.

## Odbiór, którego jeszcze nie zamykamy

1. Uruchomić pełne kontrole w środowisku Windows i zbudować instalator.
2. Sprawdzić na Windows: instalację, uruchamianie, karty/ekwipunek, pięć potyczek,
   roller, zapis po restarcie, zamykanie z niezapisanym formularzem, klawiaturę
   i skalowanie. Sprawdzić ponowną instalację/aktualizację bez utraty danych.
3. Domknąć próbę sesyjną 24E: karty sześciu klas i reprezentatywnych profesji,
   wieloklasowość, poziomy 1–12, zmiana Cech i limitów zasobów, odpoczynki/Kolory,
   inwentarz/amunicja, powiązanie/odłączenie i zapis udziału w potyczce.
4. Poprawić tylko potwierdzone problemy; zachować regresję macOS. Dopiero raport
   potwierdzający te próby może zamknąć odpowiedni odbiór.

## Przyjęte ograniczenia

Premie sytuacyjne rozlicza gracz. Zdolności narracyjne są opisami. Przerzuty
w obecnym zakresie wystarczają; nie dodajemy łączenia efektów. Nie planujemy
automatycznego trafienia/odejmowania PW, przerywania Berserka, dalszej automatyzacji
zacięć/przegrzania, integracji leków z walką ani konwersji dawnych uproszczonych BG.
Już działające funkcje ręczne pozostają. Dokładnie pięć slotów; bez animacji 3D.

## Oddzielny przyszły backlog

| Pomysł                                                   | Status                                                     |
| -------------------------------------------------------- | ---------------------------------------------------------- |
| Towarzysze BG: właściciel, profil, rozkazy i tura        | Odłożone, bez terminu; nie blokują 24E.                    |
| Wersja web z kontami MG/graczy i synchronizacją potyczki | Rozważana; wymaga osobnego projektu i zlecenia.            |
| Backup/import/eksport przez GUI                          | Do decyzji; nie jest nową biblioteką dodatkowych potyczek. |
| Publiczna dystrybucja i podpisy/notaryzacja              | Do osobnej decyzji.                                        |
| Dedykowane grafiki pozostałych 45 przedmiotów            | Opcjonalne; obecne piktogramy działają.                    |

Starsze briefy i ustalenia zachowuje historia Git:
`git show 1aeab92:docs/PLAN_DALSZYCH_PRAC.md`. Raporty ETAP_* pozostają w repo.
