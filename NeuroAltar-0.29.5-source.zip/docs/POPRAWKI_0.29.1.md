# NeuroAltar 0.29.1 — czytelność i Suplement Moloch City

Data: 2026-09-20. Punkt wyjścia: 38cf0df (0.29.0). Praca w rzeczywistym repozytorium Desktop/Combat Tracker.

## Zmiany interfejsu

- Karta BG: sekcje Postać, Ekwipunek, Zdrowie i odpoczynek, Postój, Rozwój i dane. Przełączanie zachowuje formularze i szkic; komunikaty walidacji otwierają odpowiednią sekcję.
- Stałe podsumowanie PW, szybkości, niesionej masy i poziomu. Lżejsze obramowania i czytelniejsze grupowanie bez zmiany papierowej, rdzawej i turkusowej palety.
- Skrócony nagłówek; odnośnik do broni przełącza sekcję Ekwipunek.
- Panel MG: przy szerokim oknie rozwinięty log zajmuje boczną kolumnę, przy mniejszym mieści się pod kartą. Zamknięty log nie zabiera szerokości statblockowi.

## Korekty mechaniki

- Medpak i AR-23 nie działają w Rtęci. Odrzucenie operacji nie zużywa leku.
- Leki: sztuka jest dawką; zachowano obsługę jednostki „dawka”. Dodanie opakowania antybiotyku z katalogu do BG daje 10 sztuk po 1/10 ceny opakowania. Dotychczasowe kopie w inwentarzu nie są przeliczane wstecz.
- RadOff można zastosować bez tworzenia choroby: usuwa skutki napromieniowania, wykonuje RO KON ST 15 na skutek uboczny i zużywa wskazaną dawkę. Nie usuwa Wyczerpania z innych przyczyn. Zachowano osobną kurację choroby popromiennej.
- Zatwierdzanie rozwoju uwzględnia biegłości nabyte treningiem, tak samo jak podgląd.
- Odpoczynek przesuwa czas gry i wygasza efekty czasowe. Zapamiętuje początek, aby nie doliczać ponownie czasu przesuniętego ręcznie. Starsze rozpoczęte odpoczynki mają zgodny wstecznie punkt odniesienia przy pierwszym rozliczeniu.
- Praca podczas postoju przesuwa czas gry; praca podczas odpoczynku jest częścią zadeklarowanego czasu tego odpoczynku. Pracę przecinającą granicę doby należy rozbić na dwa wpisy — formularz odrzuca niejednoznaczny wpis.

## Nowe dane

Źródło: fotografie użytkownika, **Suplement Moloch City**, strony drukowane:

| Strona | Przeciwnicy                                                           |
| ------ | --------------------------------------------------------------------- |
| 37     | Glut                                                                  |
| 38     | Thinboy                                                               |
| 39     | Mutkornica                                                            |
| 40     | Modliszka                                                             |
| 41     | Matka (ATOM-A)                                                        |
| 42     | Żuk                                                                   |
| 43     | Lekarz Asgardu, Strażnik Asgardu, Autonomiczne działko laserowe (ADL) |
| 44     | Generacja II. Genotyp kreci (Kretolud)                                |
| 45     | Generacja III. Krecia Mutamać                                         |

Łącznie 11 nowych statblocków, w odpowiednich kategoriach. Zachowano drukowane wartości, także nietypowe inicjatywy, PW, zasięgi i premie. Uzupełnienie MG: **Mutkornica TT 15**; macki nadal TT 12 i PW 10. Zdolności, akcje, zasoby na potyczkę/dzień oraz profile obrażeń współpracują z dotychczasowym panelem walki. Opisowe skutki nadal rozstrzyga MG; nie wprowadzono automatycznego odejmowania PW ani automatycznego stosowania statusów.

Thinboy: naturalne 20 przygotowuje **potrojenie kości** następnych obrażeń tej broni; modyfikator pozostaje pojedynczy. Pozostali zachowują mnożnik ×2. Zapis i ponowienie operacji nie zużywają krytyka drugi raz.

| Broń       | Cena bazowa | Masa     | Obrażenia       | Zasięg    | Magazynek | Dostępność bazowa |
| ---------- | ----------- | -------- | --------------- | --------- | --------- | ----------------- |
| Beamgun    | 200 gb      | ok. 1 kg | 1k10 od światła | 90/180 m  | 10        | 0%                |
| BigBeamgun | 400 gb      | ok. 5 kg | 2k10 od światła | 200/600 m | 15        | 0%                |

Dostępność obu broni jest decyzją MG. Źródło: tabela „Broń laserowa Asgardu” z suplementu. Numer tej strony nie jest widoczny na zdjęciu — nie dopisano domyślnego numeru. Właściwość Przepalająca i Długa BigBeamguna są zachowane. Profile dostępne również dla kopii BG. To nie jest automatyczne rozstrzyganie trafienia przeciw pancerzowi celu.

`sourceSha256` nowych partii identyfikuje kanoniczną transkrypcję `entries` (JSON UTF-8, sortowane klucze, bez odstępów), nie plik fotografii. `pdfPage: null` oznacza brak numeru PDF. Zdjęcia nie są dołączone do aplikacji.

## Dane i zgodność

Bez nowej migracji SQL i bez zmian dotychczasowych migracji. Nowe partie są dodawane transakcyjnie przez istniejący rejestr importów; ponowny start nie duplikuje wpisów. Edycje MG i usunięcia pozostają chronione. Opcjonalne pola początku odpoczynku i mnożnika krytyka zachowują odczyt wcześniejszych zapisów. Pięć slotów, zapis i historia pozostają zachowane.

## Weryfikacja i wydanie

- `pnpm check`: kontrola typów, lint, formatowanie i **405 testów — OK**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **81 testów — OK**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: OK, aplikacja arm64 0.29.1. Pozostaje wcześniejsze ostrzeżenie rozmiaru pakietu JS i brak notaryzacji Apple; podpis lokalny sprawdzony.
- Natywny test na osobnej bazie `pl.neuroshima.combat-tracker.stage24d-smoke`: przełączanie sekcji BG, formularz zdrowia i Escape, sekcja postoju; nowe pozycje w Bestiariuszu i Ekwipunku; Mutkornica TT 15, kopia w slocie 5, interaktywne rzuty ataku/obrażeń i wpisy logu. Katalog testowy ma 301 przedmiotów; widok Bestiariusza zawiera 62 wpisy źródłowe, wcześniejszy własny szablon i nakładkę Zombie.
- Zamknięcie przez ⌘Q i ponowne uruchomienie: OK; Mutkornica, TT 15 i wynik obrażeń 13 pozostały w slocie 5. Po restarcie nadal 11 wpisów suplementu, 301 przedmiotów oraz sloty 1–5. Baza użytkownika nie była używana do testów.
- Dostarczono `src-tauri/target/release/bundle/macos/NeuroAltar.app`. Poprzednia wersja zachowana jako `NeuroAltar 0.29.0.app` obok.
- SHA256 pliku wykonywalnego: `76362ffc9daa8466e689016291df7224dce80c9341c127fff1861df6611f0d02`.

## Pozostały zakres

24E (integracja BG z walką, budżetem akcji i rollerem) nie jest wykonany. Port Windows następuje po ukończeniu karty BG. Szczegółowe receptury i sytuacyjne rozstrzygnięcia nadal wymagają MG. Starsze opakowania antybiotyku w inwentarzu wymagają jawnej korekty jednostek, jeżeli były wpisane jako całe opakowania. Numer strony tabeli nowych broni pozostaje do uzupełnienia na podstawie pełnej strony.

## Pliki zmienione

- `AGENTS.md`
- `README.md`
- `docs/DECISIONS.md`
- `docs/KARTA_BG_KATALOG_REGUL.md`
- `docs/KARTA_BG_KOLORY.md`
- `docs/KARTA_BG_KONTRAKT.md`
- `docs/KARTA_BG_MECHANIKA.md`
- `docs/POPRAWKI_0.29.1.md`
- `docs/ROADMAP.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary_seed.rs`
- `src-tauri/src/character_care.rs`
- `src-tauri/src/character_condition.rs`
- `src-tauri/src/character_downtime.rs`
- `src-tauri/src/dice.rs`
- `src-tauri/src/equipment.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/data/bestiary/moloch-city.v1.json`
- `src/data/character/equipment-profiles.v1.json`
- `src/data/equipment/moloch-city.v1.json`
- `src/domain/character/care.ts`
- `src/domain/character/careModel.ts`
- `src/domain/character/condition.ts`
- `src/domain/character/conditionModel.ts`
- `src/domain/character/downtime.ts`
- `src/domain/character/inventoryCatalog.ts`
- `src/domain/dice.ts`
- `src/domain/presentation.ts`
- `src/features/character/CarePanel.tsx`
- `src/features/character/CharacterWorkspace.tsx`
- `src/features/character/ConditionPanel.tsx`
- `src/features/character/character.css`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/features/dice/RollLogMessage.tsx`
- `src/services/actorDice.ts`
- `src/stores/characterStore.ts`
- `src/stores/diceStore.ts`
- `tests/care.test.ts`
- `tests/characterStore.test.ts`
- `tests/condition.test.ts`
- `tests/dice.test.ts`
- `tests/fixtures/character-care.json`
- `tests/fixtures/character-condition.json`
- `tests/molochCity.test.ts`
- `tests/ruleRolls.test.ts`
