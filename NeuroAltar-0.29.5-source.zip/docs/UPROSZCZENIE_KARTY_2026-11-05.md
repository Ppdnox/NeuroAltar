# Uproszczenie karty BG — 2026-11-05

Zmiany do bieżącego 24E Roboczego po przebudowie UI (`e5d4ae2`):

- Usunięto dodatkowy dialog „Korekta wcześniejszego rozwoju” i wymaganie
  powodu w interfejsie, store oraz backendzie. Wcześniejsze cechy, pochodzenie
  i wybory zatwierdza zwykłe „Zatwierdź kartę”.
- PD i awans nie wymagają uzasadnienia. Usunięto pole „Powód” przy PD
  i walidację jego niepustości. Pozostają progi PD, ograniczenia wartości,
  wymagania klas i kompletność wyborów.
- Usunięto edytor „Korekty MG”. Historyczne modyfikatory oraz ich wpływ
  na istniejące karty pozostają zachowane; nie kasowano danych.
  Czynności zdrowia mają nazwy „Zakończ chorobę” i „Zakończ fobię”.
  Tylko niepoprawny, niedokończony zapis ze starszej wersji ujawnia możliwość
  usunięcia wskazanej pozycji ze szkicu, aby nie blokować zatwierdzenia.
- Kafelek Obrona pokazuje jedną bieżącą TT, np. **13 zamiast 11 / 13**.
  Korzysta z tych samych obliczeń co udział w walce: założony pancerz,
  właściwa formuła bez pancerza i działające efekty. Poza walką pokazuje
  podgląd szkicu; w aktywnej walce zatwierdzoną kartę. Brak danych to „—”.

Zachowane: zapis kompletnego szkicu, autozapis, kontrola rewizji, historia
operacji i bezpieczne ponawianie, blokada rozwoju podczas aktywnej walki,
ochrona zdrowia i inwentarza. Opcjonalne dawne `correctionReason` oraz opisy
PD pozostają zgodne z zapisanymi operacjami. **Brak migracji SQL.**

Weryfikacja automatyczna: TypeScript, ESLint, Prettier oraz **477 testów
frontendowych i 92 backendowe**. Testy obejmują zatwierdzenie korekty bez
uzasadnienia, zapis PD i awansu bez powodu, zachowanie progów PD,
kompatybilność dawnych opisów i idempotencję zapisu.

Test natywny na osobnej bazie QA: kafelek pokazał TT 13, po zmianie cech
podgląd TT 12. Zmiana wcześniejszej Kondycji/Inteligencji i dodanie 50 PD
zostały zatwierdzone jednym przyciskiem, bez dialogu i bez pola powodu.

Przed podmianą aplikacji zastano zablokowaną próbę publikacji Łucji podczas
aktywnej walki. Przez istniejące porównanie wersji zachowano jej zapisany
szkic i wycofano nieudaną próbę publikacji. Porównanie danych przed/po
potwierdziło identyczną zawartość wszystkich kart, z wyjątkiem technicznej
rewizji i daty zapisu. Nie zakończono walki ani nie zatwierdzono rozwoju.

Build macOS ukończony i podmieniony w dotychczasowym miejscu. Podpis ad hoc
przeszedł `codesign --verify --deep --strict`. Po ponownym uruchomieniu
roboczej aplikacji potwierdzono zachowany szkic, brak usuniętych pól i pojedynczą
TT uwzględniającą aktywne efekty. Samo uruchomienie nowego buildu nie zmieniło
bazy (porównano SHA-256 z kopią po odzyskaniu szkicu).
