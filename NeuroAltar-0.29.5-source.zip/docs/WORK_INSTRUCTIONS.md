# Koordynacja NeuroAltar

Aktualizacja: 2026-11-09. Kod i dokumentacja są w istniejącym repozytorium
`/Users/dominik/Desktop/Combat Tracker`. Obowiązujące zasady pracy:
[AGENTS.md](../AGENTS.md). Nie powielaj historycznych poleceń etapowych
w bieżących briefach.

## Stan i bieżące zlecenie

24E Roboczy zawiera Panel MG, kartę BG i ostatnie poprawki interfejsu,
slotów ekwipunku, zasobów oraz zielonych ikon. Pełny odbiór sesyjny pozostaje
otwarty. Osiem poprawek karty BG z 9 listopada wdrożono w 0.29.5.
Przygotowano [przekazanie na Windows](PRZEKAZANIE_WINDOWS_2026-11-09.md).
Przygotowanie instalatora nie zamyka automatycznie odbioru 24E lub portu.

Truciciel i Pogromca są zamknięte jako zakres opisowy: gracz ręcznie rozlicza
produkcję, koszt i zapis przedmiotów. Nie wpisuj ich ponownie jako braków.
Premie sytuacyjne są ręczne, zdolności narracyjne opisowe; bez rozszerzania
zaakceptowanych przerzutów i automatycznego łączenia efektów.

## Prowadzenie planu

- Aktualizuj [DECISIONS](DECISIONS.md), [PLAN_DALSZYCH_PRAC](PLAN_DALSZYCH_PRAC.md)
  i [ROADMAP](ROADMAP.md) zgodnie z nowymi decyzjami. Rozdzielaj zakres wdrożony,
  zaakceptowane ręczne rozliczenie, otwarte błędy, odbiór i przyszłe pomysły.
- Najnowsze ustalenie MG zastępuje starszy plan. Sam wpis na roadmapie nie
  rozpoczyna niepowiązanej funkcji; wykonuj zakres już zlecony przez użytkownika.
- Windows obejmuje wszystkie obecne moduły i ochronę istniejących danych.
  Wymaga instalacji, zapisu/ponownego odczytu, aktualizacji, skalowania,
  skrótów i zamknięcia sprawdzonych na Windows oraz regresji macOS.
- Sprawdzaj, czy raport dotyczy aktualnego repo i rzeczywistego buildu.
  Konfiguracja CI, wykonanie kompilacji, gotowy plik i test użytkowy są
  osobnymi stanami; nie przypisuj sukcesu etapowi bez dowodów.
- Dokumentacja sama nie wymaga nowej wersji, migracji, buildu ani podmiany
  aplikacji. Implementacja zachowuje wymagane kontrole z AGENTS.

## Granice

Zachowaj dokładnie pięć slotów, BG-only amunicję, trwałą kartę niezależną od
potyczki, ręczne PW i decyzje gracza. Nie przywracaj dodatkowych zapisanych
potyczek, 3D, automatycznych obrażeń ani usuniętych pól „Korekty MG”.
Towarzysze są przyszłym backlogiem. Web, konta, synchronizacja, backup GUI,
import/eksport i publiczna dystrybucja wymagają odrębnego zakresu; nie wynikają
z wersji Windows. Nie publikuj prywatnych źródeł ani bazy użytkownika.

Końcowy raport ma wskazać pliki, stan danych/migracji, rzeczywiste wyniki
testów i buildu, miejsce dostarczenia oraz to, czego jeszcze nie sprawdzono.

Poprzednia wersja instrukcji jest zachowana w historii Git (commit 1aeab92).
