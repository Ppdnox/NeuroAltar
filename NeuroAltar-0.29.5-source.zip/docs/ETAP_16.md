# Etap 16 — pełne statblocki i QA, 0.17.0

## Wykonany zakres

Praca bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`, po raporcie
Etapu 15 i commicie `0b914a1`. Użytkownik jawnie zlecił oba etapy kolejno.

- Statblock szablonu: podtyp, sześć cech, końcowe RO, umiejętności z premiami
  i warunkami, zmysły, odporności, wrażliwości, niewrażliwości na obrażenia/stany
  i Próg Obrażeń. Próg Awarii pozostaje osobnym istniejącym polem.
- Podgląd w Bestiariuszu i zwijanej karcie instancji. Tabela cecha/modyfikator/RO,
  polskie opisy i zachowane nowe wiersze. Brak danych = N/D, zero nie jest brakiem.
  Puste listy mają jawne „Brak”. Wprowadzanie „brak” ustawia pustą listę.
- Modyfikatory cech wyłącznie do prezentacji. Końcowe RO i umiejętności nie
  dostają ponownie PB/modyfikatora; jawne dane ataków w loadout zachowane.
- Odrębny formularz runtime, precyzyjne ścieżki błędów, blokada konfliktujących
  poleceń, szkic zachowany przy zmianie strony i obu sposobach zamykania.
  Otwarcie edytora ustawia kursor w jego pierwszym polu. Ochrona zamknięcia
  pomija ukryty formularz okna pomocy przy szukaniu problematycznego formularza.
- Pięć jawnych opcji docelowego slotu w Bestiariuszu zamiast natywnego menu.
  Nawigacja klawiaturą i Add ×N nadal dotyczą wyłącznie wskazanego slotu.
- Uaktualnione specyfikacje, model, roadmapa i instrukcje Codex/Work; Etap 17
  pozostaje do osobnego zlecenia. Uzupełniony brakujący restart GUI Etapu 15.

## Dane i migracje

**Brak migracji DDL.** Migracje 001–006, identyfikator aplikacji, ścieżka bazy
oraz ID slotów 1–5 pozostają bez zmian. Nowe opcjonalne `statblock` w szablonie
oraz runtime trafia do istniejących kolumn JSON i snapshotów. Starsze rekordy
bez pola są poprawne i nie otrzymują zgadywanych statystyk.

Każda instancja kopiuje dane; zmiana katalogu nie aktualizuje jej wstecznie.
Przygotowanie/reset uwzględniają statblock, oryginalny snapshot zostaje zachowany.
`statblock_changed` z wartościami przed/po zapisuje się w jednej transakcji
z runtime i revision. Niepowodzenie logu wycofuje całość, ponowienie nie dubluje wpisu.
Kontrakt i granice techniczne: DATA_MODEL.md, sekcja Etap 16.

Testy tylko na oddzielnych bazach. Natywne QA:
`pl.neuroshima.combat-tracker.stage16-smoke`, kopia zamkniętej bazy QA15.
Bazy użytkownika nie otwierano ani nie podmieniano. Nie wykonano GUI reset/clear
na danych użytkownika; poprawność resetu i rollbacku weryfikują testy transakcyjne.

## Wyniki kontroli

| Kontrola         | Wynik                                               |
| ---------------- | --------------------------------------------------- |
| pnpm check       | PASS: typy, ESLint, format, 185 testów / 37 plików  |
| Rust release lib | PASS: 38 testów                                     |
| cargo fmt check  | PASS                                                |
| pnpm build:macos | PASS: arm64, lokalny podpis ad hoc                  |
| git diff --check | PASS                                                |
| SQLite QA        | integrity_check = ok; foreign_key_check bez wyników |

Nowe testy obejmują współdzielony payload TS/Rust, null/zero/puste listy,
walidację liczb i rozmiarów opisów, dokładne ścieżki błędów, odczyt starego
oraz rozszerzonego katalogu/runtime/prepared, niezależność kopii, ochronę szkicu,
retry zapisu, brak zmian PW/uzbrojenia, reset oraz rollback logu i edycji katalogu.

## Natywny odbiór

- Odczyt starej bazy: slot 1, runda 2, Łucja, PW 34/44, polskie wielowierszowe
  notatki; stare szablony pokazują N/D w nowych polach.
- Szablon „Strażnik Żółtej Bramy — QA 15”: rozszerzono o SIŁ 15/ZRC 12/KON 14/
  INT 9/MDR 10/CHA N/D, końcowe RO +5/+4/−1, warunkowe umiejętności, zmysły
  i obronę. SIŁ 15,5 odrzucona; zwinięta sekcja otwarta, fokus na SIŁ.
- Zachowano polski podtyp i dwa wiersze umiejętności. Wyświetlane modyfikatory
  +2/+1/+2/−1/+0/N/D, bez podwójnego doliczania do RO.
- Wybór slotu 3 myszą i Add ×2: dokładnie dwie niezależne kopie tylko w slocie 3.
  Strzałka w radio wybiera slot 4; klik slotu 5 i Add ×1 tworzy jedną kopię w 5.
- Edycja runtime slotu 5: błędna SIŁ zachowana po home; ⌘Q ujawnia slot 5,
  formularz i pole SIŁ. Poprawiono na 18, Próg Obrażeń na 0; końcowe RO +5,
  PW 42, szablon SIŁ 15/próg 10 i kopie w slocie 3 bez zmian.
- Zamknięta baza potwierdza runtime 18/0, katalog i prepared 15/10 oraz dokładnie
  jeden statblock_changed w slocie 5 z pełnym before/after. Pięć wierszy potyczek.
- Zwykłe zamknięcie chroni również ukryty poprawny, ale niezatwierdzony formularz;
  po zatwierdzeniu zarówno zamknięcie okna, jak i ⌘Q kończą proces.
- Restart odtwarza katalog, instancję 18/0, jej RO +5 i log. Auto-fokus otwartego
  edytora działa. Tabela oraz formularz sprawdzone wizualnie przy 1100×760
  i około 760×580; pola cech przechodzą z trzech do dwóch kolumn.

Historyczna niejednoznaczność natywnego menu nie była dowodem błędnego zapisu
w innym slocie: wcześniejszy wybór pokazał się dopiero w późniejszym odczycie.
Finalne radio opcje dają natychmiastowy, widoczny wybór, sprawdzony w GUI i SQLite.

## Dostarczenie i ryzyka przed Etapem 17

Docelowa aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.17.0.
Poprzedni build 0.16.0 zachowany obok. Podpis i identyfikator sprawdzane po
skopiowaniu. Źródła i dokumentacja w realnym repo; raport nie zastępuje dostarczenia.

- Po zapisaniu nowych pól/logów wcześniejsze buildy nie obsługują tego kontraktu
  JSON. Nie wracać do nich na tej samej bazie; zachowane .app nie są backupem danych.
- Brak notaryzacji i odbioru Intel/Windows. Jest to lokalny build arm64.
- Nowe pola wymagają wpisania lub późniejszego seeda. Nie importowano danych
  podręcznika/Excela i nie stworzono Ekwipunku, Wiedzy MG, rollera ani pełnej karty BG.
- Etap 17 musi zacząć od inwentaryzacji maszyn i stron właściwego podręcznika,
  weryfikacji wartości oraz polityki jednorazowego seeda/aktualizacji. Nie zgadywać
  braków i nie nadpisywać edycji MG ani istniejących kopii.

Źródła zakresu: aktualne dokumenty projektu i decyzje użytkownika. Dane QA są
syntetyczne; nie przedstawiają zweryfikowanego katalogu z podręcznika.

## Pliki zmienione lub dodane

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_15.md`
- `docs/ETAP_16.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/UI_GUIDELINES.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/statblock.rs`
- `src-tauri/src/statblock_tests.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/components/TemplateValidation.tsx`
- `src/domain/bestiary.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/enemy.ts`
- `src/domain/statblock.ts`
- `src/domain/validation.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/equipment/LoadoutPanel.tsx`
- `src/features/machine-failures/FailurePanel.tsx`
- `src/features/statblocks/StatblockFields.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `src/stores/encounterMaintenanceStore.ts`
- `tests/fixtures/statblock.json`
- `tests/prepareAppClose.test.ts`
- `tests/statblock.test.ts`
- `tests/statblockDatabase.test.ts`
- `tests/statblockStore.test.ts`
