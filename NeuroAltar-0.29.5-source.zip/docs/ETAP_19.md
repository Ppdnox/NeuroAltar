# Etap 19 — ludzie z podręcznika

Wersja 0.22.0, 2026-09-12. Zlecony kolejny etap po poprawkach czytelności 0.21.1.
Baza: czysty commit `81da2a0`. Repo: `/Users/dominik/Desktop/Combat Tracker`.

## Zakres i dane

Dodano 9 szablonów w kategorii Ludzie. Katalog startowy zawiera teraz 51
statblocków oraz nakładkę Zombie. Wcześniejsze poprawki czytelności zachowane.

| Wpis                 | PDF / druk | TT  | PW  | SP  | PB  | Zranienia |
| -------------------- | ---------- | --- | --- | --- | --- | --------- |
| Cyngiel              | 209 / 207  | 19  | 88  | 26  | 4   | tak       |
| Cywil                | 210 / 208  | 11  | 9   | 1   | 2   | nie       |
| Gangus żołnierz      | 210 / 208  | 13  | 18  | 3   | 2   | nie       |
| Gangus kapo          | 211 / 209  | 15  | 60  | 14  | 3   | tak       |
| Gangus boss          | 212 / 210  | 20  | 108 | 25  | 4   | tak       |
| Konwojent (strażnik) | 212 / 210  | 15  | 24  | 3   | 2   | nie       |
| Kanibal              | 213 / 211  | 13  | 26  | 3   | 2   | nie       |
| Szeryf               | 214 / 212  | 16  | 93  | 19  | 4   | tak       |
| Żołnierz Posterunku  | 215 / 213  | 18  | 52  | 15  | 3   | tak       |

Komplet cech, źródłowych RO, umiejętności, zmysłów, ruchu, inicjatywy,
Tchórzliwości, PW/formuł, zasad, broni, akcji, bonusów i reakcji.
Widły farmera są warunkowym profilem Cywila. Ogólne sugestie zmiany sprzętu
lub specjalizacji oddziału nie tworzą dodatkowych wymyślonych szablonów.
Przedmioty noszone, w tym granaty i zapas naboi, widnieją w opisach statblocków.

Ofiara kapo zużywa Reakcję. Dodatkowy nóż Cyngla jest Akcją Bonusową z warunkiem
trzymania szabli i noża. Serie UZI, Tommy gun i AR mają odrębne zasoby 2/walkę
oraz opis RO, obszaru i obrażeń; Item bez fikcyjnego profilu Testu Ataku.
Ich limity nie są licznikiem naboi. Szybkie palce pozostają opisową Akcją Bonusową,
bez automatycznego odnawiania limitu serii. Zastępcy szeryfa nie są przywoływani
przez program. Warunki, rzuty, PW i statusy rozstrzygane poza użyciem zdolności.

## Źródło i niejasności

Prywatny `reference/NOE_dla_dominadiinteriapl.pdf`, SHA256
`714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
Przejrzano cały dział Ludzie, tekst i wszystkie rendery PDF 209–215;
PDF 216 rozpoczyna Maszyny. PDF i obrazy nie są częścią repo ani buildu.

Wartości końcowe są przepisane z podręcznika, bez poprawiania rachunków:
np. Cywil PW 9 (1k4 + 1), Gangus żołnierz PW 18 (1k8 + 2), Konwojent
PW 24 (2k8 + 2), Szeryf PW 93 (12k8 + 33) i Pasywna Percepcja 11,
Gangus kapo Atletyka +6. Podręcznik nie podaje typu obrażeń wideł
ani Utwardzonego Crasha — profil pokazuje N/D, nie zgaduje typu.
U Szeryfa zasięgi broni otrzymują wspólną jednostkę metrów.

Goła klata bossa ma źródłowy opis formuły przy zachowanym TT 20.
Nie dopisano brakującej w zdaniu stałej 10 i nie obniżono TT.
Premie Kuloodpornego/Brutalnego ciosu nie są ponownie dodawane do gotowych
wartości. Dodatkowe warunkowe obrażenia Cyngla, Kanibala i Żołnierza pozostają
w pełnych opisach; wyświetlane podstawowe profile nie sumują ich automatycznie.

## Bezpieczeństwo danych

Nowa niezależna partia `noe-humans` v1 z deterministycznymi ID i metadanymi źródła.
Istniejący mechanizm instaluje ją atomowo, zachowuje edycje, usunięcia i kolizje
ID, nie zmienia starych kopii w potyczkach. Ponowne uruchomienie nie duplikuje
wpisów. Bez nowej migracji SQL ani zmiany kontraktów JSON. Cztery wcześniejsze
partie i osiem migracji pozostały identyczne bajtowo. Baza użytkownika nie była
usuwana, odtwarzana ani używana do testów.

## Kontrole

- pnpm check: 222/222 testy, 46 plików; TypeScript, lint i formatowanie OK.
- Rust: 53/53 testy; cargo fmt --check OK.
- pnpm build:macos: OK; osobny build QA również OK.
- Natywny smoke: 0.22.0, filtr Ludzie 9/52, pełna karta kapo, dwie kopie w slocie 5, pierwsza z nazwą „Gangus kapo — Żółć QA” i użyciem UZI (1/2, Akcja 0), druga nadal 2/2 i Akcja 1; obie PW 60 i prepared 2/2. Podgląd RO serii czytelny w panelu Akcji. Polskie dwuwierszowe notatki zapisane. ⌘Q, ponowne uruchomienie, ⌘5 i zamknięcie przyciskiem okna OK. Poprzednie 42 szablony i wpisy ledger, 7 postaci, 37 logów, 2 statusy i sloty 1–4 identyczne. Po drugim zamknięciu wszystkie osiem tabel identycznych względem zapisu przed restartem; integrity_check/FK OK. Dowody w work/stage19-before.db, stage19-installed.db, stage19-restarted.db w katalogu zadania; wyłącznie identyfikator QA pl.neuroshima.combat-tracker.readability-smoke.

Nowe testy sprawdzają komplet wpisów, wartości i profile, zapis/odczyt edytora,
niezależność kopii, limity zasobów, reset do stanu przygotowanego, brak zmian PW,
instalację partii, powtarzanie, rollback awarii i ochronę edycji/usunięć MG.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary_seed.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/bestiary/humans.v1.json`
- `tests/humanSeed.test.ts`
- `docs/ETAP_19.md`

## Dostarczenie i zakres dalszy

Build: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, wersja 0.22.0.
Poprzedni build 0.21.1 zachowany obok. Podpis gotowej aplikacji sprawdzony.
Commit: `feat: add handbook humans to bestiary`; hash w raporcie końcowym zadania.
Lokalny build arm64 z podpisem ad hoc; bez publicznej notaryzacji i testu Windows/Intel.
Etap 20 — Ekwipunek — nie został rozpoczęty i wymaga nowego zlecenia.
