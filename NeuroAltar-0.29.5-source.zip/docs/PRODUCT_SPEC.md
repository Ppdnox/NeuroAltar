# PRODUCT SPEC — NeuroAltar

## Zdolności BG — kryterium 24E

Karta pokazuje opisy wszystkich wybranych zdolności. Funkcje aktywne w walce dotyczą tylko zdolności o skutku możliwym do rozliczenia w aplikacji, takim jak rzut, przerzut, wydatek zasobu albo koszt akcji. Zdolność fabularna pozostaje opisem; jej użycie nie dopisuje premii do testów. Mechaniczne reguły bez pełnej obsługi są oznaczone jako zakres do uzupełnienia, nie jako działający przycisk.

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.


Uzupełnienie MG: wybór **Koloru gry** w rogu karty (N/D, Rdza, Rtęć, Stal, Chrom),
odrębny od handlu, z wpływem na rozwój i odpoczynki. Kontrakt i testy:
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).

## Etap 24C — inwentarz, masa i amunicja BG (0.28.0)

Karty BG mają niezależny inwentarz: kopie przedmiotów z katalogu i własne wpisy,
ilości, masę, cenę zapłaconą, miejsca przechowywania, pojemniki i wyposażenie.
Przyznanie plecaka startowego jest jednorazowe; masę jego opisanej zawartości
liczymy łącznie. Dodatkową broń, pancerz i narzędzia klasy dodaje się osobno.
Zweryfikowane profile 79 pozycji (62 bronie, 17 pancerzy/akcesoriów) dotyczą kopii BG.
Przeciążenie, pancerz i wyszkolenie wpływają na widoczne TT/Szybkość/ataki.
Nieznana masa wskazuje pozycję do uzupełnienia i nie udaje pełnego obciążenia.

Dokładny zapas i magazynki są rozłączne. Ładowanie, rozładowanie, wymiana,
przeładowanie mechanizmu i jawny zapis strzału mają podgląd i trwałe operationId.
Chrom domyślnie używa nieliczonego zapasu; ręczne oznaczenie naturalnej1 ustawia
pustą broń, przeładowanie przywraca gotowość. Dokładne ilości pozostają zachowane.
Decyzje MG: środki leczące w Chromie cena×0,5 (MG i BG); Gambling we krwi
+5 punktów procentowych **przed** mnożnikiem Koloru, ograniczenie0–100 na końcu.
Kolor gry i warunki handlu pozostają niezależne.

`Character.inventory` jest osobne od `sheet` i `draft`: odrzucenie rozwoju nie
cofa amunicji. Migracja012 rozszerza rodzaje poleceń, zachowując pełną historię;
001–011 i dane Panelu MG pozostają bez zmian. Raport: docs/ETAP_24C.md.
Minimum0PW na awans, Samouk9, Twardziel3/7/11 i cały Etap24B są zachowane.
Następny osobno zlecany podetap: **24D — zasoby i odpoczynki**;
potem24E integracja walki i odbiór macOS,25Windows. Zasady zacięcia/kosztów akcji,
krytyków i ograniczeń rundy zostaną połączone z udziałem BG w24E.
Nie deklarować pełnej karty ani wszystkich efektów Kolorów przed odbiorem24E.

## Cel
NeuroAltar to lokalny warsztat macOS dla MG prowadzącego Neuroshimę 5e. Priorytet v1.0: szybkie prowadzenie walki bez kartkowania statblocków i ręcznego pilnowania PW, inicjatywy, statusów, Stopni Zranienia, zasobów i awarii.

## Moduły i wydania

| Moduł | Katalog | Zakres / wydanie |
| --- | --- | --- |
| Walka | `combat` | v1.0: stan i prowadzenie walki |
| Potyczki | `encounters` | v1.0: pięć stałych slotów i przygotowanie |
| Bestiariusz | `bestiary` | v1.0: szablony przeciwników |
| Ekwipunek | `equipment` | wspólny model Item; v1.0 profile bojowe, v1.1 katalog i handel |
| Wiedza MG | `reference` | v1.2: lokalne wpisy wiedzy |

Zaimplementowano Etapy 0–17, w tym architekturę 1.5, ekran główny i pełne pola statblocków w 0.17.0. Dokładny zakres wdrożonych pól i mechanik opisują sekcje wykonania etapów
poniżej. Bieżący raport weryfikacji i ograniczeń: `docs/ETAP_16.md`.

## Widoki v1.0
### WALKA
- 5 aktywnych potyczek.
- inicjatywa, runda, aktualna tura,
- PW, statusy, Stopień Zranienia,
- zasoby, statblock, log, notatki.

### POTYCZKI
- przygotowanie 5 slotów,
- BG i przeciwnicy,
- nazwa, wyposażenie, notatki,
- kalkulator trudności SP/SD.

### BESTIARIUSZ
- szablony przeciwników,
- CRUD, wyszukiwanie, filtry, duplikowanie.

Profile broni potrzebne do walki korzystają ze wspólnego modelu Item.
Pełny widok Ekwipunku i handel należą do v1.1; nie ma osobnego modułu Biblioteka/Broń.

Biblioteka zapisanych potyczek ponad pięć slotów jest wykreślona z całego planu.

## 5 slotów
Stałe: Potyczka 1–5. Każdy przechowuje niezależnie skład, inicjatywę, rundę, turę, PW, statusy, Stopnie Zranienia, zasoby, awarie, log, notatki.
`⌘1`–`⌘5` przełącza slot.

## Reset / Wyczyść
### RESET
Przywraca prepared state: PW, bazowe statusy, bazowe wyposażenie, zasoby, modyfikatory, awarie, runda 1. Skład pozostaje.
### WYCZYŚĆ
Usuwa skład, log, notatki i runtime. Wymaga potwierdzenia.

## Inicjatywa
- osobna dla każdej istoty,
- żadnego grupowania identycznych przeciwników,
- MG wpisuje wynik,
- sortowanie malejące,
- remisy rozstrzyga MG ręcznie.

## Tura
Duży przycisk `NASTĘPNA TURA`. Po ostatnim aktorze nowa runda. `Space` działa, gdy fokus nie jest w polu tekstowym.

## BG — obecny uproszczony widok bojowy
Do wdrożenia pełnej karty w Etapie 24 na macOS:
- Imię,
- TT,
- aktualne/maks. PW,
- inicjatywa,
- statusy.

## Przeciwnik — pola
- nazwa, typ/kategoria, rozmiar,
- TT, PW, inicjatywa, PB, SP,
- wiele rodzajów ruchu,
- SIŁ/ZRC/KON/INT/MDR/CHA,
- RO, umiejętności, zmysły,
- odporności/wrażliwości/niewrażliwości,
- niewrażliwości na stany,
- przedmioty,
- Tchórzliwość,
- Stopień Zranienia,
- Próg Obrażeń,
- Próg Awarii,
- zdolności, akcje, bonusowe, reakcje, legendarne.

Sekcje opcjonalne.

## Typy UI
Człowiek / Bestia / Maszyna-Moloch jako profile prezentacji, nie osobne modele techniczne.

## Template vs instance
Szablon w Bestiariuszu nigdy nie jest modyfikowany zmianami runtime potyczki. Instancja ma prepared snapshot oraz runtime state.

## Przedmioty i profile broni
Broń to `Item` typu `weapon`. Nazwa i kategoria należą do Item; opcjonalny
`weaponProfile` zawiera:
- obrażenia, typ obrażeń,
- zasięgi,
- właściwości,
- tryby ognia,
- warianty amunicji wpływające na profil.

Nie liczymy liczby nabojów w v1.0.

## Podmiana broni
Przeciwnik jest zawsze biegły w przypisanej broni. PB doliczany automatycznie.
Zmiana runtime nie modyfikuje szablonu.

## Prezentacja ataku
Czytelny wiersz:
`+atak · zasięg · [ikona kości] formuła · typ obrażeń`
+ krótki efekt.
Program nie rzuca.

## Zasoby
Uniwersalne liczniki z odnowieniem:
- runda,
- potyczka,
- dzień,
- ręcznie.

## PW
Duże aktualne/maks.
Skróty: -1, -5, -10, +1 + własna wartość obrażeń/leczenia + ręczne ustawienie.
Odporności i Progi są przypomnieniem; MG podaje finalną wartość obrażeń.

## Stopień Zranienia
0–4:
1 Lekki — Szybkość -4,5 m
2 Znaczny — brak Reakcji
3 Poważny — brak Akcji Bonusowych
4 Krytyczny — +1 Wyczerpania
kolejny — śmierć.
MG zmienia poziom ręcznie.

## Tchórzliwość
Po osiągnięciu progu % PW pokaż warning. Nie usuwaj aktora automatycznie.

## Statusy
Systemowe:
Nieprzytomność, Niewidoczność, Obezwładnienie, Ogłuchnięcie, Ogłuszenie, Oślepienie, Pochwycenie, Powalenie, Przerażenie, Sparaliżowanie, Unieruchomienie, Wyczerpanie, Zatrucie, Zauroczenie.

Własne statusy dozwolone.
Krwawienie: opisowy efekt konkretnego statblocka, bez globalnej mechaniki.
Podpalenie: systemowe przypomnienie o `1k4` na początku tury, bez rzutu.

## Czas statusu
manual / X rund / do początku tury / do końca tury / do końca następnej tury.

## Maszyny — awarie
MG uruchamia awarię po obrażeniach jednego ataku przekraczających Próg Awarii. Program nie rzuca k20. MG wpisuje 1–20; aplikacja pokazuje efekt i opcjonalnie `ZASTOSUJ`.

Efekty:
1 zniszczenie broni
2 ruch x0,5
3 -2 atak
4 blokada Bonusowych lub Legendarnych
5 Sparaliżowanie do końca następnej tury
6 -50 PW + brak amunicji
7 -1 atak w multiataku
8 Oślepienie
9 brak Reakcji
10 blokada Akcji i Bonusowych do końca następnej tury
11 Podpalenie
12 Powalenie do końca następnej tury
13 TT -2
14 -4 atak
15 1/2 obrażeń wręcz — przypomnienie
16 brak ataków wręcz
17 efekt opisowy: wycofanie
18 efekt opisowy: atak najbliższych
19 wyłączenie do naprawy
20 zniszczenie + przypomnienie autodestrukcji

## Log
Osobny dla potyczki. Loguje: PW, statusy, injury, tury/rundy, zasoby, awarie, zmiany broni, runtime modyfikatory.
Możliwość `WYCZYŚĆ LOG`.

## Trudność
SD = suma poziomów BG.
SP = suma SP przeciwników.
Pokazuj SD, SP, SP/SD oraz ciągły pasek:
~100% Łatwa, ~150% Wyczerpująca, ~200% Ryzykowna, ~300% Zabójcza.
Zielony → żółty → pomarańczowy → czerwony.

## Bestiariusz
Dodaj/edytuj/usuń/duplikuj/wyszukaj/filtruj.
`Dodaj do potyczki`, `Dodaj ×N`.
Każda kopia ma osobną inicjatywę i runtime.

## Poza v1.0
- dice roller,
- automatyczne rzuty,
- liczenie amunicji i magazynków,
- automatyczne rozstrzyganie serii,
- mapa taktyczna,
- chmura,
- multiplayer,
- mobile,
- import/export kampanii,
- Windows build (ale kod ma być przenośny).

## v1.1 — Ekwipunek

- Typy Item: broń, pancerz, amunicja, narzędzia, elektronika, żywność, paliwo, inne.
- Cena bazowa od/do, dostępność bazowa od/do, kategoria ekonomiczna, waga, opis i właściwości.
- Opcjonalny weaponProfile pozwala wykorzystać przedmiot w funkcjach bojowych; brak profilu nie tworzy domyślnego ataku.
- TradeContext wybiera niezależnie region, lokalizację i Kolor. Każdy ma `none` / N/D / brak modyfikacji; domyślnie wszystkie trzy są `none`.
- Cena: baza × region × Kolor. Dostępność: (baza + lokalizacja) × Kolor, ograniczona do 0–100%.
- Reguły Kolorów i zakresów są zdefiniowane w `docs/DATA_MODEL.md`; Stal zmienia tylko broń i amunicję.
- Excel jest jednorazowym źródłem seed data przygotowanych w v1.1. Brak zależności od pliku Excel w działającej aplikacji, synchronizacji i funkcji ponownego importu.

## v1.2 — Wiedza MG

Lokalne KnowledgeEntry (alias ReferenceEntry): tytuł, kategoria, treść, tagi i odniesienie do źródła.
Moduł prezentuje wiedzę i przypomnienia; nie rzuca kośćmi ani nie podejmuje decyzji MG.
Nie jest automatyczną publikacją prywatnych materiałów z `reference/`.

## Granice Etapu 1.5

Wyłącznie architektura, specyfikacja i struktura przyszłych modułów. Bez UI Ekwipunku,
Wiedzy MG, regionu/lokalizacji/Koloru, k100, skryptu importu Excel, dice rollera,
liczenia amunicji i funkcji Etapu 2. Pięć slotów, persistence, autozapis i migracja 001 pozostają bez zmian.

## Wykonanie Etapu 2

BG mają imię, TT, aktualne/maks. PW, inicjatywę i ręczne statusy. Kolejność jest
malejąca; remisy ustawia MG strzałkami. Brak wyniku nie wchodzi do kolejki,
0 PW nie pomija aktora. Pierwsza tura nie zwiększa rundy; przejście za ostatnią
postać zwiększa ją o 1. Wybranie karty nie zmienia aktywnej tury.
Szczegóły edycji, zapisu i ręcznych korekt: `README.md` i `docs/ETAP_2.md`.
Etapy 3–5 opisano poniżej.

## Wykonanie Etapu 3

Dodawanie podstawowego szablonu (nazwa, kategoria, rozmiar, TT, maks. PW, ruch)
i pojedynczych niezależnych kopii. Bez pełnego UI Bestiariusza i pełnych statblocków.
Edycja instancji: nazwa, aktualne/maks. PW, TT, ruch, inicjatywa i ręczne statusy.
Jawne przygotowanie zapisuje punkt powrotu obecnych BG/przeciwników; reset po
potwierdzeniu przywraca ten punkt, rundę 1 i brak bieżącej tury. Nazwa potyczki,
notatki i obecny skład zostają. Szczegółowa obsługa: README, weryfikacja: ETAP_3.

## Wykonanie Etapu 4

Log walki pod kartami postaci: trwała historia danego slotu, runda/czas/opis,
od najnowszego wpisu z możliwością wczytania starszych. Rejestruje istniejące
funkcje bojowe, w tym reset i przygotowanie. Injury, zasoby i awarie zostaną
objęte logiem dopiero w swoich etapach; nie są jeszcze zaimplementowane.
Wyczyść log wymaga potwierdzenia i usuwa wyłącznie historię tego slotu.
Reset nie usuwa historii. Nie ma dopisywania zdarzeń wstecz dla Etapów 0–3.

## Wykonanie Etapu 5

Statusy systemowe i własne mają opis, źródło, wybór czasu i niezależne instancje.
Automatycznie odliczany jest wyłącznie czas; zasady stanów są przypomnieniami.
Podpalenie przypomina 1k4, Wyczerpanie ma licznik 0–6 z wyświetleniem kar i śmierci.
Brak automatycznego rzutu, obrażeń, zmiany wpisanych statystyk lub usuwania postaci.
Ręczne opisy ze starszych etapów zachowane. Obsługa czasu, resetu i formularzy: README.
Pełne mechaniki zranienia, zasobów i awarii nadal należą do kolejnych etapów.

## Zrealizowany Etap 6

Opcjonalne Zranienia i Tchórzliwość dotyczą przeciwników; BG zachowują ograniczony
zestaw pól. Szablon ustala początkowy tor 0–4 i próg; instancja ma własne wartości.
Ręczne −1/+1 stosują narastające konsekwencje. Krytyczny dodaje 1 Wyczerpania przy
wejściu, następne Zranienie daje ostrzeżenie o śmierci. Obniżenie/wyłączenie toru
nie zmniejsza Wyczerpania. Reset przywraca oba liczniki ze snapshotu.
Podgląd ruchu uwzględnia Zranienia/Wyczerpanie bez nadpisywania wpisanych metrów.
Tchórzliwość: całkowite 0–100% aktualnego maksimum PW, puste = brak; ostrzeżenie
na karcie i w kolejce przy PW ≤ próg. Decyzja o losie przeciwnika należy do MG.
Zapis i log są atomowe. Zasoby/odświeżanie akcji pozostają w Etapie 7.

## Zrealizowany Etap 7

Przeciwnicy mają uniwersalne zasoby z odnowieniem runda/potyczka/dzień/ręcznie,
pule A/B/R oraz Legendarnych i własne opisy zdolności z opcjonalnym kosztem zasobu.
Setup szablonu tworzy pełne niezależne liczniki kopii; runtime ma własny edytor.
Zwykłe użycie sprawdza pulę, koszt oraz blokady Zranień/Obezwładnienia. Jawny wyjątek
MG jest odrębnie potwierdzany i logowany. Bez ujemnych liczników i automatycznych
obrażeń/efektów. Odnowienie do maksimum dotyczy wyłącznie wskazanej reguły; reset
odtwarza przygotowane wartości, także zużyte. Szczegółowa konwencja w DECISIONS.
Etap 8 opisano poniżej. Profile broni opisano w Etapie 9 poniżej.

## Zrealizowany Etap 8

Katalog szablonów istnieje niezależnie od składu potyczek. Tworzenie, edycja,
podgląd, potwierdzane usunięcie, duplikowanie; wyszukiwanie po nazwie i zdolnościach
z normalizacją polskich znaków, łączne filtry kategorii i rozmiaru.
Dodaj ×N (1–100) do jawnie wskazanego slotu tworzy niezależne kopie jednym zapisem.
Katalog korzysta z dotychczasowego zestawu pól. Nie dodaje profili broni, awarii,
kalkulatora trudności ani seeda statblocków. Usunięcie szablonu nie zmienia potyczek.
Edytor zatwierdza kompletny wzorzec; odrębny szkic chroniony przy zamykaniu.

## Zrealizowany Etap 9

Profile bojowe Item na szablonie i instancji: PB, modyfikatory SIŁ/ZRC, broń,
zasięgi, formuły z ikoną kości, typ obrażeń, właściwości i opisy. Jawne tryby ognia
oraz warianty amunicji z N/D. Podmiana/edycja w potyczce nie zmienia Bestiariusza.
Snapshot obejmuje cały zestaw, a log zapisuje zmianę atomowo. Nieznane dane nie są
zerowym atakiem. BG zachowują dotychczasowy ograniczony kontrakt.
Pełny Ekwipunek/handel, awarie i trudność pozostają w swoich etapach.

## Zrealizowany Etap 10

Formularz wyniku, podgląd 20 efektów i jawne Zastosuj; listy awarii i naprawy na
karcie maszyny. Próg w Bestiariuszu i osobno w instancji. Kary TT/ruchu/ataku są
widoczne bez nadpisywania wartości bazowych. Wyniki 6 i 20 zmieniają PW dopiero
po zatwierdzeniu MG. Wyniki czasowe obsługuje kolejka tur; naprawa nie leczy PW.
Granice i konwencje powtórzeń: DECISIONS, kontrakt: DATA_MODEL, dowody: ETAP_10.


## Etap 11 — implementacja 0.12.0

Panel Trudność potyczki nad walką: edytor poziomów BG (spacja/wiersz/przecinek/średnik),
SD, SP, SP/SD, procent i nazwa. SP szablonu w Bestiariuszu, Aktualne SP na karcie.
Puste SP = N/D; przy brakach pokaż znane SP i liczbę brakujących przeciwników.
Poziomy są osobne dla slotów i nie zmieniają pól kart BG. Licz cały skład przeciwników,
także przy 0 PW. Ciągły pasek 0–300%, wynik liczbowy także powyżej skali.
Nazwy według doprecyzowania użytkownika: [0,126) Łatwa, [126,176) Wyczerpująca,
[176,251) Ryzykowna, od 251 Zabójcza. Kotwice ~100/~150/~200/~300 bez nowych kresek.


## Poprawki Etapu 11 — 0.12.1

- Prezentacja wyników trudności: maksymalnie 2 miejsca po przecinku, bez zmiany
  surowych danych ani progów. Zapisane liczby zachowują pełną precyzję.
- Panel „Karta potyczki — trudność” zwijany; wybór rozwinięcia osobny dla slotów
  podczas sesji, błędne dane odsłaniają panel. Walka pozostaje dostępna.
- Mały pasek i procent/nazwa przy każdym z pięciu slotów, także nieaktywnych.
  Puste SD/brak SP to N/D, niepoprawny szkic „Popraw dane”.
- Aktualne SP korzysta z obramowania i odstępu etykiety jak pozostałe statystyki.
- Bestiariusz i formularz nowego przeciwnika pokazują konkretne pola, numery
  przedmiotów/formuł/akcji oraz przyczynę. Pierwszy błąd odsłania pole i ustawia
  kursor; kliknięcie błędu prowadzi do danej pozycji, także w zwiniętej sekcji.
- Walidacja zachowuje reguły: puste wymagane teksty, liczby, zakresy, koszty
  większe niż pule/zasoby i zasięgi. Błędy nie usuwają szkicu ani nie zapisują
  niepoprawnych danych. Brak migracji i zmian bazy, pięć slotów bez zmian.

## Etap 12 — obsługa operacji na potyczce

Przyciski „Zapisz stan przygotowany”, „Reset potyczki” i „Wyczyść potyczkę”
mają odrębne potwierdzenia z nazwą, numerem slotu i liczbą postaci. Zmienione
dane wymagają ponownego otwarcia potwierdzenia. Otwarte formularze blokują akcje.
Clear usuwa skład, jego punkty powrotu i bieżące dane, statusy, log i notatki;
runda 1, brak tury. Nazwa slotu i poziomy BG pozostają. Reset nie odwraca Clear.
Clear działa także dla pustego składu z notatkami/logiem. Błędne szkice trzeba
najpierw poprawić; poprawne oczekujące dane zapisują się przed operacją.
Po błędzie wyświetlamy ponowienie tej samej operacji lub odczyt stanu slotu.


## Etap 13 — obsługa przy stole (0.14.0)

Skróty Alt/⌥+↑/↓ wybierają karty w kolejności inicjatywy, z postaciami bez wyniku
na końcu, bez zawijania na skraju. Nie zmieniają tury ani danych. Pola edycji,
kompozycja tekstu, dodatkowe modyfikatory, przytrzymanie i otwarty formularz
blokują skrót. „Pokaż bieżącą postać” ustawia fokus na jej karcie.
F1/przycisk otwierają pomoc modalną; Escape zamyka pomoc i nie anuluje formularza.
Spacja zachowuje ochronę kontrolek; także formularz przeciwnika blokuje turę.
Skróty slotów oraz walki nie działają pod modalem pomocy.
Log domyślnie zwinięty przy wejściu do slotu; podsumowanie pokazuje ostatni wpis.
Rozwinięcie nie usuwa/odświeża liczników, zapis logu trwa niezależnie od widoku.
Błąd odczytu odsłania historię i ponowienie. Stan rozwinięcia pozostaje lokalny.
Pasek rundy jest przyklejony podczas przewijania walki, lecz statyczny w oknie
niższym niż 581px. Lewa inicjatywa przyklejona tylko na szerokim/wysokim ekranie.
Nagłówek bardziej zwarty, oprawa papier/turkus/metal zachowana; fokus kontrolek
czytelny. Brak nowej mechaniki, migracji i skrótów usuwających dane.

## Etap 14 — historyczny wynik QA (domknięty w Etapie 16)

Weryfikacja zachowania, autozapisu, restartu i buildu: `docs/ETAP_14.md`.
Na etapie 14 EnemyTemplate nie implementował wszystkich opcjonalnych pól
z sekcji „Przeciwnik — pola”: podtyp, sześć cech, RO, umiejętności, zmysły,
odporności/wrażliwości/niewrażliwości i Próg Obrażeń. To brak implementacyjny,
nie zmiana specyfikacji ani przeniesienie do v1.1. PB oraz modyfikatory SIŁ/ZRC
są częścią uzbrojenia; Próg Awarii jest odrębny i działa. Pakiet 0.15.0 zamyka
rundę QA istniejących funkcji. Ten punkt uzupełniono w Etapie 16 opisanym poniżej.

## Docelowa aplikacja po aktualizacji planu

Ekran główny → Panel MG albo Karta postaci BG. Panel MG zawiera Walkę, Potyczki,
Bestiariusz, Ekwipunek, Wiedzę MG i roller. Przy wczesnym wdrożeniu ekranu karta
BG ma czytelną zapowiedź, nie działający formularz. Brak kont i podziału uprawnień.

Bestiariusz ma otrzymać dane z podręcznika w trzech etapach: maszyny, potwory,
ludzie. Wcześniej komplet pól statblocka. Dane źródłowe wymagają weryfikacji,
a aktualizacje nie mogą nadpisywać własnych szablonów i instancji MG.
Wiedza MG to zawartość tabelarycznego Excela: czytelne tabele, nagłówki, jednostki,
przypisy, filtrowanie/wyszukiwanie. Zakres kalkulatorów określić według realnego arkusza.

Roller uruchamiany jawnie, prosty interfejs bez 3D: kości, liczba, modyfikator,
formuła, składowe i historia. Wynik nie odejmuje PW i nie rozstrzyga trafienia.
Aplikacja zachowuje dotychczasowe ręczne PW i jawne zastosowanie awarii.

Po odbiorze Panelu MG powstaje pełna karta BG na macOS (Etap 24),
a następnie port całej aplikacji i odbiór Windows (Etap 25). Karta obejmuje wszystkie reguły używanej gry,
rozwój, cechy i ich modyfikatory, umiejętności/RO/wartości bojowe, ekwipunek,
wagę i obciążenie, zasoby klasowe oraz krótki/długi odpoczynek według reguł zasobów.
Wyłącznie karta BG śledzi amunicję: pojemność i stan magazynka, zapas, zużycie,
przeładowanie i masę. Przy zerze alarm „Pusty magazynek — przeładuj”. Sam rzut
nie zużywa nabojów. Rzuty z karty używają jej obliczeń, nadal bez rozliczania PW.

Karta jest trwała poza pięcioma potyczkami. Reset/clear walki nie kasuje postaci
ani nie cofa jej rozwoju/inwentarza. Wartości pochodne mają widoczne składniki
obliczenia i jawne korekty. Powiązanie starych uproszczonych BG wymaga bezpiecznej
migracji/operacji, bez automatycznego utożsamiania postaci o tej samej nazwie.

## Etap 16 — pełne pola przeciwnika

Wdrożono podtyp, SIŁ/ZRC/KON/INT/MDR/CHA z podglądem modyfikatorów, końcowe RO, umiejętności z premiami i warunkami, zmysły, odporności/wrażliwości/niewrażliwości oraz Próg Obrażeń. Każda pozycja jest opcjonalna jako znane dane; N/D nie jest zerem. Edycja szablonu dotyczy przyszłych kopii, edycja statblocka instancji tylko tej postaci. Obecne PB/ataki pozostają w profilu broni. Statblocki nie rozstrzygają ataków, odporności ani PW automatycznie. Pięć docelowych slotów w Bestiariuszu jest stale widocznych. Luka odnotowana w QA14 dotycząca dedykowanych pól jest zamknięta; seed podręcznika należy do Etapów 17–19.

## Etap 17 — maszyny z podręcznika (0.18.0)

**11 wpisów, tyle co typów maszyn w podręczniku.** Mobsprzęt ma jeden statblock,
pełną listę sześciu ponumerowanych broni oraz adnotację „rzuć 1k6 i wybierz jedną”.
W opisie ruchu zachowano tabelę trzech podwozi i warunki. Spawacz ma jeden wpis
z lotem opisanym „tylko SMART”. Aplikacja nie wymusza selektora wariantu i nie losuje.
MG rozstrzyga wybór i może usunąć niewylosowane pozycje w edytorze uzbrojenia kopii.
Dane katalogu oraz inne kopie pozostają niezależne.

Statblock otrzymuje opcjonalne, edytowalne „Zdolności stałe i uwagi źródłowe”.
Tu zachowano pasywy, warunki, inicjatywę, formułę PW i strony podręcznika. Lista
jest widoczna w katalogu/karcie i objęta wyszukiwaniem oraz precyzyjną walidacją.
Broń oparta na RO celu to Item bez fikcyjnego weaponProfile/premii do Testu Ataku;
wyświetla opis, ST, obszar i skutki oraz może być wskazana w awarii niszczącej broń.
Nie dodano automatycznych rzutów, obrażeń, leczenia ani amunicji. Limity zdolności
na walkę/dzień pozostają zasobami; przy ataku wielokrotnym MG ręcznie odejmuje
zużycia pod-ataków, wykorzystując jeden budżet Akcji.

Seed inicjuje się po migracjach, przed odczytem potyczek. Migracja 007 dodaje tylko
rejestr danych startowych. Edycje i usunięcia MG, pięć potyczek, snapshoty oraz
logi są zachowane. Pełna polityka korekt i odbiór: ETAP_17.md (w katalogu docs).
Etap 18 nadal wymaga odrębnego zlecenia.

## Etap 18 — potwory i pięć kategorii

Kategorie przeciwników: Ludzie, Maszyny, Mutanci, Potwory, Zwierzęta.
Starsze „Bestia”/„Inny” oznaczone jako starszy wpis, do świadomej klasyfikacji MG.
Dział Potwory: Alahama, Bit-Boys, Bit-Boy Przewodnik, Kitchin, Harpie, Korzec,
Megator, Pies mutek, Szczękowij, Taran, Techmorwa malutka, Techmorwa średnia,
Zombie — nakładka Death Breath. Źródłowa nakładka wymaga nosiciela; osobny
formularz do przeglądu, następnie zapis nowego szablonu. Nie zmienia źródła.
Na pustej bazie: 23 szablony (11 maszyn, 12 potworów) i jedna źródłowa nakładka.
Ruch warunkowy, drugie typy obrażeń, pasywy, RO i limity dostępne w statblocku.
Zachowane źródłowe średnie/formuły, inicjatywa każdej kopii nadal ręczna.

## Etap 18A — mutanci (0.20.0)

Bestiariusz obejmuje dodatkowo 7 mutantów: Nocny ghul, Gadolud, Wilkolud,
Grubas, Techmutas, Szpieg i Mesmeryta. Na pustej bazie 30 szablonów oraz
nakładka Zombie. Sześć cech, końcowe RO, zmysły, odporności, zdolności stałe,
przedmioty opisowe i wszystkie akcje z podręcznika są dostępne w statblockach.
Własne opisy/ruch/zdolności oraz kopie w potyczkach nadal są niezależne.
Mesmeryta ma Posiłki 2/dzień i pulę 3 Legendarnych/rundę. Użycie przycisku
zmienia wyłącznie właściwy budżet/zasób. Przybycie posiłków i skutki rozstrzyga MG.
Partię zwierząt (18B) następnie zlecono i wdrożono.

## Etap 18B — zwierzęta (0.21.0)

12 zwierząt: Gigamut, Gigantyczny pająk, Koń (skażony), Koń (teksańczyk),
Koń (zdrowy), Mrokoszczur, Myślący szczur, Neokot, Neogator, Neoniedźwiedź,
Pies bojowy, Rój szczurów. Łącznie 42 szablony startowe i nakładka Zombie.
Zaciekłość roju: Reakcje bez limitu, każda zapisana w logu, inne blokady i koszty
nadal obowiązują. Jawny przełącznik w edytorze zasobów, widoczna etykieta w kartach.
Dwa ręczne warianty ugryzienia roju; przy dokładnie 50% PW decyzję podejmuje MG.
Nie automatyzujemy odporności, chorób, trucizny, przywołań ani udźwigu.

## Poprawki czytelności — 0.21.1

Zlecono wyłącznie korekty tekstów i widoków, bez Etapu 19. „Chód” w interfejsie
zastępuje „Szybkość”; prezentacja ruchu zawiera m. SP podręcznikowej kopii z
podaną wartością jest nieedytowalne w karcie walki; ręczne tworzenie i własne
wpisy zachowują pole. Wartości, liczenie trudności i dane pozostają niezmienione.
Usunięto wskazane dopiski administracyjne i dekoracyjny licznik slotów,
skrócono nagłówki. Pancerz: TT z wartością i opisem w nawiasie.
Wspólna prezentacja działa także na starych snapshotach; seed i SQL nietknięte.
Raport/kryteria odbioru: CZYTELNOSC_0.21.1.md. Następny etap wymaga zlecenia.

## Etap 19 — ludzie (0.22.0)

Zlecony po poprawkach 0.21.1. Dziewięć statblocków z s. 207–213 (PDF 209–215):
Cyngiel, Cywil, Gangus żołnierz, Gangus kapo, Gangus boss, Konwojent (strażnik),
Kanibal, Szeryf i Żołnierz Posterunku. Katalog startowy: 51 szablonów + nakładka Zombie.
Wariant farmera pozostaje bronią Cywila. Ofiara jest Reakcją; dodatkowy nóż Cyngla
Akcją Bonusową. Trzy długie serie mają osobne limity 2/walkę i są opisane przez RO,
bez fikcyjnego Testu Ataku. Przedmioty noszone są opisem, bez liczenia amunicji.
Nie sumować ponownie premii Kuloodpornego i Brutalnego ciosu; wartości końcowe
pozostają źródłowe. Warunkowe premie, przywołania, rzuty i obrażenia nie są automatyczne.
Nowa partia noe-humans v1, bez zmiany kontraktów ani migracji 001–008. Starsze partie,
edycje/usunięcia MG, instancje i snapshoty zachowane. Obowiązują poprawki czytelności 0.21.1.
Historyczny raport: ETAP_19.md. Etap 20 wdrożono następnie w 0.23.0.

## Etap 20 — Ekwipunek (0.23.0)

Wdrożono katalog 299 pozycji z tabelarycznego Excela: wszystkie osiem typów Item,
wyszukiwanie nazw/opisów/właściwości, filtry typu i kategorii, waga oraz zakresy
ceny i dostępności. Panel MG → Ekwipunek. Jedenaście regionów, cztery lokalizacje
i pięć Kolorów; niezależne N/D, domyślnie none/none/none. Stal modyfikuje tylko
Item.type weapon/ammunition, także gdy brak weaponProfile.

Katalog w tym etapie służy do przeglądania i obliczeń handlu. Nie zmienia
przedmiotów osadzonych w Bestiariuszu, walce ani przygotowanych kopiach.
Warunki handlu i filtry zachowują się w sesji przy przełączaniu modułów;
nowe uruchomienie zaczyna od wartości bazowych. Brak edytora katalogu,
liczenia inwentarza/amunicji, rollera, importu/synchronizacji Excela i UI Wiedzy MG.
Wagi zakresowe/przybliżone pozostają tekstem, brak danych = N/D, nigdy zero.

Migracja 009 dodaje items i equipment_seed_batches; migracje 001–008 pozostają
niezmienione. Jednorazowy, transakcyjny seed po migracjach i przed udostępnieniem
repozytoriów. Ponowny start nie nadpisuje wpisów ani nie odtwarza usunięć.
Raport: ETAP_20.md. Następny etap: 21 — Wiedza MG; tylko po nowym zleceniu.

## Etap 21 — Wiedza MG (0.24.0)

Panel MG → Wiedza MG: 50 wpisów, działy, wyszukiwanie po treści, tabelach i
nagłówkach (także bez polskich znaków), pasujące wiersze z zachowaniem kontekstu.
47 tabel/opisów z 13 arkuszy oraz trzy tabele MODYFIKATORÓW wyprowadzane z
istniejących reguł Ekwipunku. Spis zakresów: WIEDZA_MG_ZRODLA.md.
Długie opisy mają rozwijane akapity; nagłówki, jednostki, uwagi oraz odsyłacze
do arkusza/komórek pozostają dostępne. Na węższym panelu wiersze przechodzą
w karty z etykietami kolumn. Link do Ekwipunku prowadzi do przeliczania cen.

KnowledgeEntry zawiera strukturalne blocks: table (columns/rows/cells) i text;
ReferenceEntry to alias tego modelu. Wpisy są zwalidowane przez Zod i dostarczane
z aplikacją jako niezmienny katalog tylko do odczytu, bez nowej tabeli SQL.
Stan wyszukiwania/działu/wyboru trwa w sesji; nie zmienia potyczek ani ich bazy.
Migracje 001–009, identyfikator aplikacji, Bestiariusz, Item i TradeContext bez zmian.
Kolory i mnożniki handlu mają jedno źródło prawdy współdzielone z Ekwipunkiem.

Nie dodano kalkulatora, rollera, automatycznych efektów, liczników amunicji,
edycji wiedzy ani importu/synchronizacji Excela. Opisy rzutów i „Rzuć dwa razy”
są treścią tabel źródłowych; niczego nie uruchamiają. Raport: ETAP_21.md.
Następny etap: 22 — prosty roller, wyłącznie po osobnym zleceniu.

## Etap 22 — roller i strony podręcznika (0.25.0)

Zlecony po Etapie 21 (`c41dece`). Rozwijany panel Kości w prawym dolnym rogu:
k4/k6/k8/k10/k12/k20/k100, 1–100 kości, modyfikator ±10000 i pełne formuły
NkS±N (także d). Pokazuje każdą kość, sumę i 100 ostatnich wyników po restarcie.
Kliknięcie ataku, obsługiwanej formuły obrażeń, cechy, RO lub umiejętności
z jawną premią rzuca z kontekstem postaci i zapisuje wynik w logu jej potyczki.
Atak korzysta z bieżącego profilu; cecha z jej modyfikatora, RO/skill z podanej
premii końcowej. Liczbowa kara Wyczerpania dotyczy testów, nie obrażeń/awarii.
Pozostałe warunki i ułatwienia/utrudnienia ocenia MG. Nieobsługiwane, złożone
lub opisowe formuły pozostają tekstem; brak częściowego zgadywania rzutu.
Rzuć awarię k20 wypełnia istniejący formularz. Ręczne wpisanie i zmiana wyniku
pozostają dostępne. Tylko osobne „Zastosuj awarię” zmienia stan maszyny.
Rzuty nie zmieniają PW, zasobów, amunicji, tur, statusów ani wyboru celów.
Ponowienie z historii jest nowym rzutem samej formuły bez starej postaci/rundy.

Migracja 010 dodaje wyłącznie tabelę dice_rolls. 001–009 pozostają nietknięte.
Historia i opcjonalny wpis dice_rolled powstają w jednej transakcji; stabilne
UUID umożliwia ponowienie zapisu bez losowania i duplikowania. Nie zmieniamy
rewizji ani snapshotów walki. Zamknięcie czeka na zapis; błąd ujawnia panel
z zachowanym wynikiem. Skróty walki są zablokowane przy otwartym panelu kości.

Wiedza MG pokazuje tytuł „Neuroshima: Ostatnia Era” i drukowane strony zamiast
arkusza/komórek. 50 przypisań udokumentowano w WIEDZA_MG_STRONY.md. Treść tabel
pozostaje adaptacją Excela; samo dodanie odsyłaczy nie koryguje różnic mechaniki.
Surowe źródła pozostają poza repo/bundle; brak synchronizacji/reimportu.
Raport: ETAP_22.md. Następny Etap 23 — odbiór Panelu MG na macOS — wymaga zlecenia.


## Poprawki kart walki — 0.25.1

Zlecone po Etapie 22 (2cd2926), dla wszystkich przeciwników, także istniejących
instancji i wpisów MG. Bieżące cechy/RO, obrona i zmysły są stale widoczne przed
„Parametry i notatki postaci”. Opisy zdolności, reguł i broni mają klikalne jawne
premie ataku i formuły kości, także mieszane np. 2k8+2k6+4. ST/RO celu pozostaje
opisem; nie przypisuj rzutu obronnego do atakującego. Rzut nie zużywa zdolności
ani nie zmienia PW/zasobów; log zachowuje nazwę zdolności i postaci. Tekstowa
premia ataku uwzględnia liczbowe kary awarii i Wyczerpania bez doliczania PB.
Własne opisy korzystają z tej samej obsługi jawnych zapisów. Nieznanych wartości
nie zgadujemy. W historii opcjonalne groups opisuje mieszane kości; stare wpisy
bez groups nadal działają. Bez migracji i bez zmian seedów/snapshotów.
Raport: POPRAWKI_0.25.1.md. Etap 23 nadal wymaga osobnego zlecenia.

## Wzorzec karty BG — decyzja MG 2026-09-12

Przy projektowaniu Etapu 24 zachować strukturę czterostronicowej karty
`reference/karta-postaci-Neuro-2025-NEW-8-Interactive (1).pdf`: grupy, nazwy
i hierarchię pól, z responsywnym układem i interaktywnymi obliczeniami.
Mapa stron, wymagania i ocena pomocniczego arkusza Google: [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md).
Oryginał PDF pozostaje tylko do odczytu i poza dystrybucją. Zlecono ustalenie
wzorca przyszłych prac, bez rozpoczynania implementacji karty.


## Wyszukiwarka przeciwników i rzut inicjatywy — 0.25.3

„Dodaj przeciwnika” otwiera wyszukiwarkę Bestiariusza w bieżącej potyczce.
Nazwa (także bez polskich znaków) i kategoria zawężają wyniki; „Dodaj” tworzy
jedną niezależną instancję i zamyka okno. „Dodaj własnego” otwiera dotychczasowy
formularz ręczny. Escape anuluje wybór, bez zmiany składu.

Przycisk inicjatywy przy statblocku i ręcznym polu wyniku rzuca 1k20 z jawną
premią „Inicjatywa: ±N” (również dawny zapis „z podręcznika”). Liczba w nawiasie
nie jest premią. Gdy brak tej pozycji, używany jest modyfikator Zręczności;
nieznana lub sprzeczna premia wymaga ręcznego wyniku. Odejmowana jest liczbowa
kara Wyczerpania. MG nadal ocenia pozostałe warunki testu.

Wynik, historia kości, log i rewizja potyczki zapisują się w jednej transakcji.
Kolejność inicjatywy aktualizuje się bez zmiany rundy, bieżącej tury, remisów,
PW, zasobów ani przygotowanych snapshotów. Inicjatywa nie przygotowuje krytyka.
Przed rzutem kończy się autozapis; podczas zapisu edycja i zamknięcie czekają.
Błąd zachowuje dokładny wynik do ponowienia, bez kolejnego losowania. Odczyt
aktualnego stanu pozwala rozstrzygnąć niepewny zapis lub porzucić niezapisany rzut.
Ręczny wpis pozostaje dostępny. Brak migracji; 001–010 pozostają niezmienione.
Raport: POPRAWKI_0.25.3.md. Etap 23 nadal wymaga osobnego zlecenia.


## Korekta miejsca inicjatywy i źródeł Ekwipunku — 0.25.4

Zlecenie MG po 0.25.3: interaktywny jest wyłącznie istniejący wpis
„Inicjatywa: …” w „Zdolnościach stałych i zasadach” karty przeciwnika.
Usunięto dodatkowe przyciski z pola wyniku i nagłówka statblocku. Pole wyniku
ma zwykłą etykietę i ręczną edycję; cztery pola oraz przyciski „Dodaj przeciwnika”
i „Dodaj własnego” są wyrównane. Atomowy zapis inicjatywy z 0.25.3 pozostaje.
Nie dodawaj drugiego wpisu inicjatywy ani nowego przycisku poza istniejącą zasadą.

Źródła wszystkich 299 pozycji Ekwipunku pokazują „Neuroshima: Ostatnia Era”,
drukowane strony oraz właściwą tabelę/sekcję. Granaty i miny wskazują swoje
opisy, gdy książka nie zawiera tabeli. Mapa: EKWIPUNEK_STRONY.md i
src/data/equipment/handbook-sources.v1.json. Powiązanie po ID i oryginalnym
źródle seedu działa także na istniejącej bazie. Własnych źródeł MG nie nadpisujemy.
Bez zmiany danych mechanicznych, seedu, migracji lub reimportu. Raport
POPRAWKI_0.25.4.md. Etap 23 nadal wymaga nowego zlecenia.

## Etap 24A — pełna karta gracza, kryterium produktu

Układ [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md), mechaniki i katalog
KARTA_BG_MECHANIKA/KARTA_BG_KATALOG_REGUL określają kryteria24B–24E.
Wynik pokazuje składniki i brakujące dane. Statusy wybierane z menu, błędy prowadzą
do konkretnej pozycji/pola. Odpoczynek ma jawny podgląd, a brak masy nie daje
pozornej sumy0. Poziom, ekwipunek i amunicja przetrwają reset/clear slotu.
Karta nie jest jeszcze dostępna; zapowiedź na ekranie głównym pozostaje prawdziwa.
