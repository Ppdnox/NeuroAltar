# Statusy na karcie BG — NeuroAltar 0.19.3

Poprawka czytelności istniejącej karty BG w panelu inicjatywy. Stan wyjściowy: commit `1ee6078`, wersja 0.19.2. Zakres nie obejmuje kolejnego etapu planu ani pełnej przyszłej karty postaci.

## Zmiany

- Bezpośrednio na karcie znajduje się rozwijane menu „Dodaj status z listy”, obejmujące wszystkie 15 statusów systemowych oraz własny status.
- Wybranie pozycji otwiera formularz pod menu na karcie tej postaci. Efekt zostaje dodany dopiero po zatwierdzeniu. Dostępne pozostają opis, źródło, czas trwania, liczba rund i poziom Wyczerpania.
- Aktywne statusy pokazują nazwę, poziom i czas w krótkich kartach. Pełne reguły i własne opisy rozwija się przez „Opis i źródło”. Ogólna instrukcja jest schowana pod „Zasady statusów”.
- Formularz pozostaje aktywny, gdy pozostałe kontrolki karty są zablokowane na czas edycji. Próba zamknięcia z niezapisanym formularzem przywraca do niego fokus.
- Układ statusów dopasowuje liczbę kolumn do szerokości karty. Wspólny panel zapewnia ten sam sposób obsługi u przeciwników.
- Zaktualizowano numer wersji i dokumentację.

## Pliki

- `src/features/statuses/StatusPanel.tsx` — menu, formularz na karcie, krótkie karty aktywnych statusów.
- `src/features/statuses/StatusForm.tsx` — fokus i przewinięcie do formularza, również po zatrzymaniu zamknięcia.
- `src/features/combat/CombatWorkspace.tsx` — osadzenie panelu poza blokadą pozostałych pól.
- `src/app/styles.css` — układ menu, kart i formularza.
- `tests/combatPresentation.test.ts` — dwa testy regresji prezentacji i formularza BG.
- `src/app/App.tsx`, `package.json`, `src-tauri/Cargo.toml`, `src-tauri/Cargo.lock`, `src-tauri/tauri.conf.json` — wersja 0.19.3; bez aktualizacji zależności.
- `README.md`, `README_FIRST.md`, `AGENTS.md`, `docs/UI_GUIDELINES.md` oraz niniejszy raport — opis i zakres poprawki.

## Weryfikacja

- `pnpm check`: 205 testów w 42 plikach — PASS; TypeScript, ESLint i Prettier — PASS.
- Testy Rust w trybie release: 45 — PASS; `cargo fmt --check` — PASS.
- `pnpm build:macos`: PASS, aplikacja macOS Apple Silicon (arm64), podpis lokalny ad hoc.
- Natywny test macOS wykonano na osobnej aplikacji i bazie QA: wybór Zatrucia z menu, polski opis wielowierszowy, ustawienie dwóch rund, dodanie Wyczerpania na poziomie 2, rozwinięcie opisu i edycja istniejącego statusu — PASS.
- Błędna liczba rund 0 zatrzymała zapis bez utraty opisu. Próba `⌘Q` z niezapisanym formularzem wróciła do właściwego pola — PASS.
- Zmiana okna z 1100 × 760 na 760 × 580 zachowała wpisy w formularzu. Oględziny krótkich kart po zapisie — PASS.
- Zapis, wyjście przez `⌘Q`, ponowne otwarcie i odczyt statusów, rund oraz wielowierszowego opisu — PASS. Zamknięcie przyciskiem okna po zakończonej edycji — PASS.
- Kopia zamkniętej bazy QA: integralność `ok`, brak naruszeń kluczy obcych, sloty 1–5 i 23 wpisy bestiariusza zachowane.

## Dane i ograniczenia

Brak migracji. Nie zmieniono schematu, reguł statusów, odliczania rund, mechaniki Wyczerpania ani danych startowych. Testy interakcji korzystały z osobnej bazy QA; baza użytkownika nie była modyfikowana przez testy.

Statusy nadal przypominają o regułach zgodnie z dotychczasowym zachowaniem; ta poprawka nie dodaje automatycznego przeliczania PW, TT ani ruchu. Build pozostaje lokalny, bez notaryzacji Apple. Natywne testy obejmują macOS; nie testowano Windows.

## Dostarczenie

Źródła zaktualizowano bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`. Aplikacja 0.19.3 trafia do `src-tauri/target/release/bundle/macos/NeuroAltar.app`, a poprzednia 0.19.2 zostaje zachowana obok jako `NeuroAltar 0.19.2.app`. Podpis aplikacji jest weryfikowany przed podmianą i po niej. Commit: `fix: simplify status selection on combat cards`.
