# Wiedza MG — odsyłacze do podręcznika, Etap 22

W UI źródło wskazuje **Neuroshima: Ostatnia Era** (Dark Rabbit), drukowane
numery stron. W sprawdzonym PDF strony pliku mają numer o 2 większy.
Okładkę i numerację stron 114–115 sprawdzono również wizualnie.
Metadane arkuszy i komórek pozostają tylko w zasobach technicznych dla audytu.

Odsyłacze wskazują odpowiednie fragmenty podręcznika. Dotychczasowe tabele
aplikacji nadal są opracowaniem z Excela, nie deklaracją dosłownego przedruku.
W Etapie 23 MG zlecił poprawienie dwóch rozbieżności: Krytyczna ochrona niszczy
hełm (s. 115), a wyjątek od utrudnienia broni Długiej dotyczy Szybkości celu 0
(s. 118), nie Zręczności. `handbookCorrections.ts` stosuje je przy odczycie katalogu,
zachowując oryginalne 47 wpisów Excela w `tables.v1.json` do porównań źródłowych.
Pozostałe wpisy zachowują dotychczasowe opracowanie z Excela.
Kolory zawierają również uzgodniony z MG wariant N/D. Ceny i mnożniki pozostają
wspólne z Ekwipunkiem; nie zmieniono mechanik przy podmianie źródła.

| Wpis                                                                            | Strony drukowane |
| ------------------------------------------------------------------------------- | ---------------- |
| Tabela typowych akcji                                                           | 21               |
| Tabela zestawów narzędzi                                                        | 20               |
| Tabela stanów                                                                   | 35, 36           |
| Tempo podróży                                                                   | 42, 43           |
| Hełmy                                                                           | 114, 115         |
| Tarcze                                                                          | 115              |
| Właściwości broni białej                                                        | 117              |
| Właściwości broni dystansowej                                                   | 118              |
| Serie i ogień zaporowy                                                          | 119, 120, 121    |
| Tabela obrażeń długiej serii                                                    | 120              |
| Ogień zaporowy                                                                  | 121              |
| LEKKIE PANCERZE (1 akcja na założenie/ściągnięcie)                              | 113              |
| ŚREDNIE PANCERZE (2 akcje na założenie/ściągnięcie)                             | 113              |
| CIĘŻKIE PANCERZE (4 akcje na założenie/ściągnięcie)                             | 113              |
| AKCESORIA (1 akcja na założenie/ściągnięcie)                                    | 113              |
| Tabela broni białej                                                             | 116              |
| Tabela broni miotanej                                                           | 119              |
| Broń Palna Krótka (BPK) — Pistolety (waga ok. 1 kg)                             | 122              |
| Broń Palna Krótka (BPK) — Rewolwery (waga ok. 1 kg)                             | 122              |
| Broń Palna Krótka (BPK) — Broń kombinowana (waga ok. 2 kg)                      | 122              |
| Broń Palna Pośrednia (BPP) — Pistolety maszynowe (waga ok. 3 kg)                | 122              |
| Broń Palna Pośrednia (BPP) — karabinki automatyczne (waga ok. 3 kg)             | 122              |
| Broń Palna Długa (BPD) — Karabiny powtarzalne (waga ok. 4kg)                    | 123              |
| Broń Palna Długa (BPD) — Karabiny automatyczne i samopowtarzalne (waga ok. 4kg) | 123              |
| Broń Palna Długa (BPD) — Strzelby (waga ok. 4kg)                                | 123              |
| Amunicja do broni krótkiej                                                      | 125              |
| Amunicja do broni długiej                                                       | 125              |
| Amunicja do granatników i broni ppanc                                           | 125              |
| Amunicja do broni miotanej                                                      | 125              |
| Ceny magazynków wymiennych                                                      | 126              |
| GRANATY I IM PODOBNE                                                            | 126              |
| MINY I ŁADUNKI WYBUCHOWE                                                        | 127              |
| OBSZAR EKSPLOZJI (NA PRZYKŁADZIE SZEŚCIANU)                                     | 127              |
| Tabela granatów, min i ładunków                                                 | 126, 127         |
| ELEKTRONIKA                                                                     | 130, 132         |
| TABELA ZESTAWÓW NARZĘDZI                                                        | 134              |
| Materiały pirotechniczne                                                        | 137              |
| Narkotyki                                                                       | 137              |
| Używki                                                                          | 137              |
| Środki lecznicze                                                                | 137              |
| LEKARSTWA                                                                       | 132              |
| PROCHY I UŻYWKI                                                                 | 137              |
| TABELA RÓŻNOŚCI                                                                 | 139              |
| INSTRUMENTY MUZYCZNE                                                            | 132              |
| PRZYKŁADOWE INSTRUMENTY                                                         | 132              |
| ŻYWNOŚĆ                                                                         | 144              |
| ŻYWE ISTOTY                                                                     | 143              |
| Modyfikatory cen regionalnych                                                   | 44               |
| Modyfikatory dostępności                                                        | 43               |
| Kolory Neuroshimy                                                               | 201–203          |

SHA256 sprawdzonego PDF: `714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`. Surowy PDF pozostaje poza Git i aplikacją.
