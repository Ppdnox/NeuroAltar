# Etap 17 — maszyny z podręcznika, 0.18.0

## Wykonany zakres

Docelowy projekt: `/Users/dominik/Desktop/Combat Tracker`. Start z czystego Git,
commit `ea12489` (Etap 16). Przygotowaną i przetestowaną zmianę zapisano w tym
folderze po zgodzie na dostęp; końcowe testy i build również z realnego repo.

- Dokładnie **11 wpisów podręcznikowych**, po jednym na typ maszyny.
- Mobsprzęt: jeden statblock, tabela podwozi, sześć ponumerowanych broni,
  adnotacja „rzuć 1k6 i wybierz jedną”. Bez osobnych wpisów ani selektora konfiguracji.
- Spawacz: jeden statblock, lot 36 m opisany warunkiem „tylko SMART”.
- Zweryfikowane TT, PW, SP, cechy, końcowe RO, ruch, zmysły, obrona, progi,
  tchórzliwość, uzbrojenie, Akcje/Bonusowe/Reakcje/Legendarne i limity zdolności.
- Ogólne pole „Zdolności stałe i uwagi źródłowe”: edytor, podgląd katalogu/kopii,
  wyszukiwanie oraz błędy wskazujące konkretną pozycję. Pasywy nie zużywają Akcji.
- Item bez weaponProfile pokazuje opis i właściwości. Pozwala odwzorować broń
  rozstrzyganą RO celu bez fikcyjnej premii ataku, z zachowaniem ST i skutków.
  Taką broń można wskazać w awarii nr 1. Pozostałe profile zachowują dotychczasowe liczenie.
- Nazwa kategorii „Maszyna” obejmuje Molocha i SMART-a; twórca w polu podtyp.
- Bez automatycznych rzutów/PW, amunicji, Ekwipunku, Wiedzy MG ani Etapu 18.

Wpisy prywatne MG nie są usuwane. Na pustej bazie katalog ma 11 pozycji;
na istniejącej dochodzi 11 wpisów źródłowych, poza ewentualnymi kolizjami stabilnych ID.
Nie utożsamiamy prywatnego szablonu z seedem wyłącznie na podstawie takiej samej nazwy.

## Inwentaryzacja i źródło

`reference/NOE_dla_dominadiinteriapl.pdf` (281 stron). Sprawdzono tekst oraz
wyrenderowane strony wszystkich statblocków. Notatnik Łowcy: zasady maszyn s. 214,
statblocki s. 215–225; pomocnicze zasady s. 204–205. Tytuł/strony i SHA-256
źródła znajdują się w `src/data/bestiary/machines.v1.json`.
PDF, ilustracje i pełne opisy fabularne nie trafiają do Git ani aplikacji.
Zapisano potrzebne dane gry i zwięzłe przypomnienia mechaniki.

| Maszyna    | Strona druk / PDF | TT  | PW  | SP  | Próg Awarii |
| ---------- | ----------------- | --- | --- | --- | ----------- |
| Biodroid   | 215 / 217         | 15  | 72  | 20  | 20          |
| Juggernaut | 217 / 219         | 22  | 320 | 125 | 40          |
| Pająk      | 218 / 220         | 15  | 16  | 6   | N/D         |
| Kidnaper   | 219 / 221         | 15  | 84  | 18  | 20          |
| Łowca      | 220 / 222         | 12  | 40  | 11  | N/D         |
| Mobsprzęt  | 221 / 223         | 12  | 48  | 8   | 15          |
| Gladiator  | 222 / 224         | 18  | 108 | 22  | 30          |
| Obrońca    | 223 / 225         | 20  | 144 | 38  | 25          |
| Pulser     | 224 / 226         | 16  | 56  | 15  | 20          |
| Spawacz    | 225 / 227         | 16  | 32  | 1   | 10          |
| Kurczak    | 225 / 227         | 15  | 12  | 5   | N/D         |

Łącznie 28 pozycji uzbrojenia, w tym 17 z profilem Testu Ataku i 11 opartych
na opisach RO. Pozycje Mobsprzętu są alternatywami, nie sześcioma broniami
używanymi jednocześnie. Kurczaki na jego kadłubie mają wspólną pozycję z opisem
czterech strzałów w turze Mobsprzętu; nie tworzą automatycznie czterech aktorów.

Statblock ma pierwszeństwo przed przykładami: Biodroid SP20, inicjatywa +3 (12).
Zachowano drukowane średnie i formuły, np. działo Juggernauta 20 (4k20),
bez przeliczania ich na klasyczną wartość oczekiwaną. Niepodane wartości pozostają
N/D; nie dopisano progów Pająkowi, Łowcy i Kurczakowi ani cechy CHA zamiast kreski.
Inicjatywa źródłowa jest uwagą; każda kopia nadal wymaga własnego wyniku MG.

## Zapis, migracja i polityka korekt

**Jedna nowa, addytywna migracja: `007_bestiary_seed.sql`.** Dodaje wyłącznie
`bestiary_seed_entries`. Migracje 001–006, identyfikator produkcyjny i ścieżka bazy
pozostają bez zmian. Bazy użytkownika nie otwierano, nie podmieniano i nie odtwarzano.

Seed uruchamia się po migracjach, przed udostępnieniem repozytoriów. Błąd pokazuje
istniejący ekran nieudanego startu i pozwala ponowić. Katalog i ledger zapisują się
w jednej transakcji; awaria w połowie wycofuje całość.

Rejestr zawiera stabilny identyfikator, batch/version, poprzedni oferowany szablon,
źródło oraz zainstalowaną revision. Pierwszy import nie nadpisuje kolizji ID.
Ponowny start tej samej wersji niczego nie dubluje. Zmiana danych bez zwiększenia
wersji pakietu jest błędem, starsza wersja nie cofa katalogu.

Przyszła korekta może zmienić tylko nietknięty wpis, którego revision i cała treść
zgadzają się z poprzednim seedem. Edycja MG (także cofnięta ręcznie), tombstone,
usunięty wiersz, kolizja lub zmiana poza aplikacją trwale wyłącza automatyczne
korekty wpisu. Usunięć nie przywracamy. Brak wpisu w kolejnym pakiecie nie kasuje
katalogu. Wersję podnosi programista po weryfikacji danych; brak UI reimportu.

Seed nie modyfikuje pięciu potyczek, aktorów, kopii szablonów, runtime,
oryginalnych/przygotowanych snapshotów ani logów. `statblock.traits` jest opcjonalne
w dotychczasowych kolumnach JSON; TS/Rust zachowują brak pola/null/pustą listę.

## Wyniki kontroli

| Kontrola                              | Wynik                                              |
| ------------------------------------- | -------------------------------------------------- |
| pnpm check w realnym repo             | PASS: typy, ESLint, format, 191 testów / 38 plików |
| cargo test release lib w realnym repo | PASS: 42 testy                                     |
| cargo fmt check                       | PASS                                               |
| pnpm build:macos                      | PASS: 0.18.0, arm64, podpis lokalny ad hoc         |
| git diff --check                      | PASS                                               |
| SQLite QA                             | integrity_check = ok, foreign_key_check bez błędów |

Nowe testy: inwentaryzacja 11 wpisów i parametrów źródłowych, sześć broni
Mobsprzętu, lot warunkowy, końcowe premie ataków, roundtrip formularzy,
niezależność opisów/uzbrojenia/zasobów, reset, precyzyjne błędy, startup retry,
jednorazowy seed, kolizje, edycje/usunięcia, brak downgrade, walidacja całej paczki,
bezpieczna migracja na istniejących danych i rollback importu/korekty.

## Odbiór natywny

Oddzielny identyfikator `pl.neuroshima.combat-tracker.stage17-smoke`, nowa baza QA.

- Pierwszy start: 11/11, pięć slotów. Mobsprzęt: wszystkie sześć broni z pełnymi
  opisami i zasadą 1k6. Broń z RO bez błędu „brak profilu” i bez fikcyjnej premii.
- Add ×2 do slotu 3: dwie kopie, SP16. Pierwsza: PW43/48, inicjatywa13;
  druga: PW48/48, inicjatywa N/D. Pozostałe sloty puste.
- Zmiana opisu katalogu na dwie linie „Notatka MG: Żółć, Łódź…” nie zmieniła
  opisów istniejących kopii ani ich pierwotnych/przygotowanych snapshotów.
- Wiersz 1001 znaków: odrzucony, komunikat wskazuje Statblock → Zdolności stałe
  i uwagi źródłowe → 1; focus na właściwym polu. ⌘Q z ekranu głównego ujawnia
  niedokończony formularz; po poprawieniu zapis działa.
- Wpisywanie polskich znaków i dwóch wierszy sprawdzone przez zwykłe wpisywanie.
  Narzędzie wklejania raz wprowadziło inną treść niż żądana; wykryto to w QA,
  poprawiono pole i dopiero ponowny test potwierdził walidację oraz właściwy zapis.
- Wizualny odbiór przy 1100×760 i około 760×580: opisy i profile zawijają się,
  małe okno ma jedną kolumnę. Skrót wyboru następnej karty działa.
- Zwykłe zamknięcie kończy proces. Restart zachowuje 11 pozycji, opis MG,
  obie kopie i ich wartości; seed nie odtwarza źródłowego opisu po edycji.
  Następne ⌘Q również kończy proces.
- Odczyt zamkniętej kopii bazy QA potwierdza 11 wpisów i 11 rekordów ledger v1,
  sloty1–5, obu aktorów tylko w3 oraz niezmienione sześć broni i dziesięć uwag
  źródłowych w runtime/original/prepared obu aktorów.

Finalna etykieta kategorii „Maszyna” została poprawiona po odbiorze GUI i objęta
końcowym sprawdzeniem/buildem. Testowy build GUI miał jeszcze starą etykietę.

## Dostarczenie i ryzyka przed Etapem 18

Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.18.0,
`pl.neuroshima.combat-tracker`. Poprzedni build 0.17.0 zachowany obok jako kopia.
Podpis weryfikowany po skopiowaniu; źródła i raport zapisane w realnym repo.

- Reguły warunkowe, losowania i pod-ataki nadal rozstrzyga MG. Limity zdolności
  nie są śledzeniem nabojów. Spawanie/naprawy/autodestrukcja nie zmieniają PW same.
- Opis ogólny Progu Awarii na s.205 różni się od reguły maszyn na s.214.
  Zachowano uzgodniony Etap10: obrażenia > próg, jawne zastosowanie przez MG.
- Starsze buildy nie obsługują nowych pól JSON po ich zapisaniu. Kopia .app nie
  jest kopią bazy; nie używać starej wersji do cofania danych.
- Lokalny build arm64 bez notaryzacji; brak odbioru Intel/Windows.
- Etap18 (potwory) pozostaje niezlecony. Weryfikacja ich specyficznych statblocków
  należy do następnej partii; obecny odbiór obejmuje komplet maszyn.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_17.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/007_bestiary_seed.sql`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/bestiary_seed.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/src/statblock.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/bestiary/machines.v1.json`
- `src/db/connection.ts`
- `src/domain/bestiary.ts`
- `src/domain/enemy.ts`
- `src/domain/statblock.ts`
- `src/domain/validation.ts`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/statblocks/StatblockFields.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `tests/connection.test.ts`
- `tests/machineSeed.test.ts`
