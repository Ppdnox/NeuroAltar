# Dedykowane ikony — 2026-11-05

Aktualizacja **24E Roboczego**, baza `dbef7e2`, na zlecenie użytkownika.

## Wygląd i zakres

Z repozytorium kolegi pobrano 457 oryginalnych ikon SVG. Ich białe sylwetki
aplikacja wyświetla jako maski w istniejącym kolorze `--color-teal` (#006b65).
Nie zmieniono palety ani samych plików graficznych. Grafiki są lokalną częścią
buildu i nie wymagają połączenia z GitHubem podczas używania aplikacji.

256 z 301 pozycji katalogu ma przypisaną grafikę z nowego zestawu.
Te same grafiki pojawiają się w katalogu Panelu MG, wyszukiwarce BG,
inwentarzu i przy broni. Dodatkowe aliasy obsługują zestawy startowe,
magazynki oraz pojedyncze dawki antybiotyku. Nazwy własne i brakujące
w źródle przedmioty zachowują istniejące piktogramy.

220 wpisów zdolności klasowych, profesji, pochodzenia i sztuczek
korzysta z 210 grafik. Ikony przy nazwach mają 2 rem; opisy pozostają
rozwijane, a kropki zasobów zachowują swoje działanie i dynamiczne limity.
Ogólny znacznik wyboru Speca „Zdolność z pochodzenia” zachowuje symbol
ogólny; wybrana konkretna zdolność pochodzenia ma dedykowaną ikonę.

Ikony są dekoracyjne, bez dodatkowych pozycji w nawigacji klawiaturą.
Czytnik ekranu nadal odczytuje nazwę przedmiotu lub zdolności.

## Źródło

Jacek Janiszewski / jjanisze, [FVTT-NOE](https://github.com/jjanisze/FVTT-NOE),
commit `3ec33f00147220aaecbcf111a45e916d4cae96a3`.
Użytkownik przekazał zgodę kolegi na użycie grafik w aplikacji.
Według CREDITS.md źródła większość ikon powstała przy pomocy modeli
Google Gemini i OpenAI. Licencja MIT kodu upstream nie obejmuje
wygenerowanych ikon; nie oznaczamy grafik tą licencją.
Informacja towarzysząca grafikom i pełne sumy SHA-256 znajdują się w
`public/icons/fvtt-noe/NOTICE.txt` i `manifest.json`.

Nie zaimportowano kodu Foundry, zasad, tabel, fontów, audio ani portretów.
Pliki SVG nie zawierają zewnętrznych odwołań, skryptów ani handlerów zdarzeń.

## Pozycje bez dedykowanej grafiki w źródle

Poniższe 45 pozycji nadal ma dotychczasowe piktogramy:

Analizator chemiczny, Gwizdek, Hamak, Książka, Koc, Koc gaśniczy, Kostium, Lina (15 m), Lusterko z klapką, Mapa, Maska przeciwgazowa, Megafon/mikrofon, Nafta (1 l), Namiot, Narty i kijki, Perfumy, Skafander ochronny, Sieć, Siodło, Sprzęt do nurkowania, Zapałki (50 szt.), Cukier (1 kg), Herbata (0,5 kg), Jajko (50 g), Kawa (0,5 kg), Kawa zbożowa (1 kg), Masło (200 g), Olej roślinny (1 l), Przyprawy (100 g), Sól (1 kg), Ziarno (1 kg), Koń (skażony), Koń (zdrowy), Koń (teksańczyk), Koza, Krowa, Neokot, Kura, Owca, Pies bojowy, Szczur, Świnia, Wół, Beamgun, BigBeamgun.

## Dane i weryfikacja

Zmiana wyłącznie prezentacyjna: bez migracji SQL, zmiany danych katalogu,
reguł gry, zapisanych kart, amunicji, zasobów lub potyczek.

- `pnpm check`: TypeScript, ESLint, Prettier oraz **536/536 testów** — PASS.
- `cargo test --release --lib`: **102/102 testów** — PASS; `cargo fmt --check` — PASS.
- `pnpm build` i build macOS **NeuroAltar 24E Roboczy.app** — PASS.
- Podpis ad hoc (`codesign --verify --deep --strict`) — PASS.
- Natywna kontrola osobnej wersji QA: zielone ikony amunicji, broni i akordeonu,
  wyszukiwanie, rozwijanie opisów zdolności, ikony obok zachowanych kropek — PASS.
- Zaktualizowany 24E Roboczy uruchomiony i poprawnie zamknięty; ikony widoczne
  przy istniejącej karcie użytkownika — PASS.
- Wszystkie 15 tabel bazy użytkownika identyczne z kopią sprzed tej aktualizacji;
  `integrity_check` = `ok`.

Testy przypisań obejmują rozróżnienie .44 Mag / .44 Magnum, aliasy dawek,
zestawy startowe, magazynki i odmienne klasowe warianty zdolności.
Dodatkowa weryfikacja sprawdza lokalne pliki i ich sumy SHA-256. Magazynki
karabinków AK/AR/Scar/XM-8 i Light Fifty używają symbolu magazynka karabinowego,
zamiast mylącego pistoletowego lub skrzynki z taśmą.

Wcześniejsze ostrzeżenia bundlera pozostają nieblokujące. Aplikacja nie została
notaryzowana; ta zmiana wyglądu nie stanowi pełnego odbioru sesyjnego 24E.
