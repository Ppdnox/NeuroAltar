# NeuroAltar — przygotowanie buildu Windows

Stan: **2026-11-10**, baza **24E Roboczy / 0.29.5**.
Przygotowano konfigurację, workflow oraz paczkę źródeł do pracy na Windows.
**Instalator Windows jeszcze nie powstał i nie wykonano odbioru na Windows.**
Na macOS przeszło 569 testów TypeScript, 107 testów Rust i natywny build QA;
pełny odbiór sesyjny pozostaje otwarty.
Instrukcja przeniesienia i polecenie dla Codexa: [przekazanie projektu](PRZEKAZANIE_WINDOWS_2026-11-09.md).

## Docelowy wynik

Instalator NSIS `*-setup.exe` dla **Windows x64 (Intel/AMD)**. Można go pobrać
na Macu, przesłać na Windows i tam uruchomić. Windows ARM64 nie jest w tej
partii deklarowany jako natywnie obsługiwany. Aplikacja pozostaje lokalna;
instalator nie przenosi kart i potyczek z Maca ani ich nie synchronizuje.

Pliki przygotowania:

- `src-tauri/tauri.windows.conf.json`: platformowa nakładka NSIS; nie zmienia
  konfiguracji macOS, wersji ani identyfikatora aplikacji.
- `src-tauri/icons/icon.ico`: wygenerowane z istniejącego `source.svg` narzędziem Tauri.
- `pnpm build:windows`: cel `x86_64-pc-windows-msvc`, NSIS, bez pytań, Cargo `--locked`.
- `.github/workflows/windows-build.yml`: wyłącznie ręczne `workflow_dispatch`,
  kontrole i build na Windows, do pobrania tylko instalator, SHA-256 i opis buildu.
  Workflow nie tworzy publicznego Release. Artefakt do pobrania nie zawiera
  źródeł ani danych użytkownika; kod kompiluje się na runnerze Windows GitHub.
- `.gitattributes`: jednolite LF dla źródeł; oryginalne ikony zachowane bajtowo.

## Budowanie sterowane z Maca

Użytkownik wybrał kontynuację bezpośrednio na komputerze Windows, zgodnie
z instrukcją przekazania. Windows w GitHub Actions pozostaje alternatywą.
W repo nie ma skonfigurowanego `remote`. Przed wysłaniem kodu należy wskazać
repozytorium i autoryzować jego użycie; lokalne przygotowanie nie publikuje projektu.

Po udostępnieniu wybranego repo z tymi plikami na domyślnej gałęzi:

1. Otwórz Actions → **Windows installer (manual)** → Run workflow.
2. Workflow instaluje Node 24, pnpm 11.19.0, Rust 1.98.1 oraz zależności z lockfile.
3. Uruchamia kontrole frontendowe, testy Rust na Windows i buduje instalator.
4. Po sukcesie pobierz `NeuroAltar-Windows-x64-<commit>` z Artifacts.
5. Rozpakuj, zachowaj `build-info.json` i `SHA256SUMS.txt`, przenieś instalator
   na Windows. Artefakty tego workflow są przechowywane przez 14 dni.

Cross-build bezpośrednio na Macu jest możliwy dla NSIS `.exe`, ale wymaga
dodatkowego toolchainu (cargo-xwin, MSVC target, LLVM/LLD, NSIS). Na sprawdzonym
Macu tych narzędzi i Windows VM nie znaleziono. Nie instalowano ich w tej partii.
MSI wymaga Windows. Dokumentacja Tauri preferuje Windows/VM/CI nad cross-buildem:
[Windows Installer](https://v2.tauri.app/distribute/windows-installer/),
[GitHub Actions](https://v2.tauri.app/distribute/pipelines/github/).

## Budowanie lokalnie na Windows

Wymagane są Node 24, pnpm 11.19.0, Rust MSVC, Microsoft C++ Build Tools z Windows
SDK oraz WebView2. Zobacz [wymagania Tauri](https://v2.tauri.app/start/prerequisites/#windows).
Po przygotowaniu narzędzi, w katalogu projektu (PowerShell):

```powershell
pnpm install --frozen-lockfile
rustup toolchain install 1.98.1 --profile minimal --component rustfmt --target x86_64-pc-windows-msvc
rustup override set 1.98.1
pnpm check
cargo fmt --manifest-path src-tauri/Cargo.toml --check
cargo test --manifest-path src-tauri/Cargo.toml --release --lib --locked
pnpm build:windows
```

Przerwij po każdym błędzie; wynik buildu nie zastępuje niezaliczonych kontroli.
Instalator powstaje w `src-tauri/target/x86_64-pc-windows-msvc/release/bundle/nsis/`.
Nie trzeba używać skryptu `build:macos`. Repozytorium zdalne nie jest wymagane,
jeśli budowanie odbywa się bezpośrednio na komputerze Windows.

Instalacja jest dla bieżącego użytkownika, po polsku lub angielsku zależnie od
systemu. Brakujący WebView2 jest pobierany, więc jego pierwsza instalacja wymaga
internetu. Nie skonfigurowano certyfikatu podpisu Windows; pierwszy prywatny
instalator może wyświetlać ostrzeżenie o nierozpoznanym wydawcy. Nie wyłączać
zabezpieczeń systemowych w procedurze budowania.

## Odbiór Windows

Każdy punkt wymaga wyniku z faktycznie działającego Windows; testy Maca nie wystarczą.

- [ ] Instalacja, uruchomienie i zamknięcie; numer wersji, ikony i polskie znaki.
- [ ] Utworzenie karty, rozwój, zasoby, odpoczynki, ekwipunek, przeładowanie i rzuty.
- [ ] Pięć slotów, przeciwnicy, inicjatywa, powiązanie BG, tury i zakończenie udziału.
- [ ] Zapis/restart; reset potyczki nie cofa trwałej karty.
- [ ] Niezapisany formularz i zapis w toku poprawnie chronią zamknięcie (Alt+F4).
- [ ] Klawiatura, fokus, małe okno oraz skalowanie Windows 100/125/150/200%.
- [ ] Bestiariusz, Ekwipunek, Pojazdy, Wiedza MG i ikony działają offline.
- [ ] Aktualizacja/ponowna instalacja zachowuje bazę; deinstalacja nie kasuje
      danych bez jawnej decyzji. Próba na danych testowych, nie bazie użytkownika.
- [ ] Regresja macOS po ewentualnych poprawkach platformowych.
- [ ] Zapisany raport z wersją/commitem, systemem, sumą instalatora i pozostałymi błędami.

Truciciel i Pogromca pozostają opisowi; ręczne rozliczenie produkcji jest
zaakceptowane i nie blokuje budowania. Pełny odbiór sesyjny 24E jest odrębny
od powodzenia kompilacji i instalacji.
