# NeuroAltar 0.29.2 — ekwipunek i rzuty BG

2026-09-20. Punkt wyjścia: 8959d23. Zmiany w rzeczywistym repozytorium.

## Zakres

- Usunięto z formularza przedmiotu pola „Powód nabycia lub korekty”, „Źródło / uzasadnienie masy” i „Zapłacono za całą pozycję (G)”. Wcześniejsze dane pozostają w zapisie; nowe operacje mają automatyczny opis historii. Masa własnego przedmiotu nie wymaga uzasadnienia.
- Broń katalogowa używa stałej masy: zapis „ok. X kg” oznacza X kg, zgodnie z decyzją MG. Dotyczy też obliczeń udźwigu istniejących kopii. W formularzu masa jest tylko do odczytu, np. pistolet 1 kg, AR 3 kg. Własne przedmioty nadal mogą mieć ręcznie określoną masę. Oryginalny jednorazowy seed nie jest przepisywany.
- Przycisk „Przeładuj” znajduje się przy stanie magazynka. Dla zamontowanego magazynka otwiera wybór zapasu i liczby naboi bez szukania osobnego wpisu w inwentarzu. Bez magazynka pokazuje dalszą drogę: dodanie, załadowanie i zamontowanie. Zachowano wymianę magazynka, przeładowanie mechanizmu i nieliczony zapas Chromu.
- Cechy, umiejętności i rzuty obronne w sekcji „Cechy i umiejętności” są klikalne. Rzut cechy używa modyfikatora, nie wartości cechy. Umiejętność uwzględnia wybraną cechę i Biegłość. Kara Wyczerpania jest doliczana raz i opisana w wyniku. Panel kości jest dostępny przy BG; historia zachowuje nazwę postaci i testu. Rzut BG nie zmienia żadnej potyczki. Sytuacyjne Ułatwienia/Utrudnienia i pełna integracja walki nadal należą do 24E.
- Nowsza decyzja MG: Mutkornica TT 12. Partia Bestiariusza zwiększona do wersji 2; aktualizacja zmienia nietknięty wzorzec, zachowuje edycje MG i wcześniejsze kopie w potyczkach.

## Dane i testy

Brak migracji SQL. Dodano opcjonalne `characterContext` w zapisie rzutu; wcześniejsze rzuty zachowują zgodność. Nie kasowano ani nie odtwarzano bazy użytkownika.

- Pełne `pnpm check`: 407 testów, typy, lint i formatowanie — OK.
- Rust release: 82 testy — OK; `cargo fmt --check` — OK.
- Build macOS 0.29.2 oraz weryfikacja podpisu lokalnego — OK. Pozostają wcześniejsze ostrzeżenie rozmiaru JS oraz brak notaryzacji Apple.
- Native QA na osobnej bazie: RO Siła `1k20+4` → naturalne20/wynik24, podpis postaci w historii; ładowanie AR 0→1 naboju i zapas29→28; brak trzech usuniętych pól, masa AR3kg tylko do odczytu. Katalog Mutkornicy12, istniejąca kopia15 zachowana.
- Stara baza QA miała roboczy hash transkrypcji Ekwipunku z pierwszego buildu 0.29.1. Po potwierdzeniu identyczności obu zapisanych przedmiotów uzgodniono wyłącznie hash w rejestrze tej bazy testowej. To nie jest migracja produkcyjna; wydana 0.29.1 miała już ostateczny hash.
- Dostarczona aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`; poprzednia zachowana obok jako `NeuroAltar 0.29.1.app`.
- SHA256 pliku wykonywalnego: `f8d64b0a67b3d75b6e8223be76d0713c6db3609b3a40d0a4cefd03f4d3ef72fc`.

## Pliki

- `AGENTS.md`
- `README.md`
- `docs/DECISIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/dice.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/bestiary/moloch-city.v1.json`
- `src/domain/dice.ts`
- `src/domain/medicineWeight.ts`
- `src/features/character/CharacterWorkspace.tsx`
- `src/features/character/InventoryPanel.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/stores/diceStore.ts`
- `tests/dice.test.ts`
- `tests/equipment.test.ts`
- `tests/molochCity.test.ts`
- `docs/POPRAWKI_0.29.2.md`
