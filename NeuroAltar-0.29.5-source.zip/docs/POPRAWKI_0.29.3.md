# NeuroAltar 0.29.3 — amunicja bez masy

Decyzja MG z 2026-09-20: amunicja nie ma pola masy w formularzu ani masy wyświetlanej w katalogu MG i inwentarzu BG. Nie obciąża postaci, zarówno w zapasie, jak i w magazynku. Dotyczy też wcześniejszych zapisów z podaną lub nieznaną wagą; amunicja nie wywołuje ostrzeżenia o niepełnym udźwigu. Puste magazynki pozostają osobnymi przedmiotami.

Bez migracji SQL. Zachowano zapisane dane, ilości, kalibry, strzelanie i przeładowanie. Wewnętrzne obliczenia traktują amunicję jako zerowy wkład do masy; interfejs nie przedstawia jej jako przedmiotu z polem „waga 0”.

Weryfikacja: pełne pnpm check (407 testów), Rust release (82 testy), build macOS — OK. Native QA na osobnej bazie: 28 naboi w zapasie i 1 w magazynku; masa karty bez amunicji 26,7 kg; formularz 5,56 mm bez pola masy. Produkcyjna baza nie była używana do testów.

Dostarczono `src-tauri/target/release/bundle/macos/NeuroAltar.app` 0.29.3; kopia 0.29.2 zachowana obok. Podpis lokalny zweryfikowany. SHA256 binarium: `1e3ab51e878c670f5bcec4a84edf1753e87867cc338e4434e46a3b234aa90857`.

Zmiany: wspólne obliczanie masy (`medicineWeight.ts`), prezentacja i formularz inwentarza (`InventoryPanel.tsx`), katalog MG (`EquipmentWorkspace.tsx`), testy inwentarza, rejestr decyzji i numery wersji. Następny etap nie został rozpoczęty.
