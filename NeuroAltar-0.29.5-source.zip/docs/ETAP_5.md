# Etap 5 — NeuroAltar 0.6.0

Etap 5 rozszerza działający Etap 4 (`ec3efb4`) o statusy, czas ich trwania,
Podpalenie i Wyczerpanie. Bazowe drzewo Git było czyste. Prace i testy wykonano
w kopii roboczej; sprawdzony commit i aplikację dostarczono bezpośrednio do
`/Users/dominik/Desktop/Combat Tracker`. Etap 6 wymaga osobnego zlecenia.

## Zmiany

- Katalog 14 stanów ze specyfikacji i Podpalenie, własne statusy, opis i źródło.
  Formularz dodawania/edycji z walidacją i fokusem klawiatury; usuwanie za potwierdzeniem.
- Czas: ręcznie, 1–999 rund, początek tury, koniec tury, koniec następnej tury.
  Konwencje i przykłady opisano w README. Liczniki rund maleją przy globalnej zmianie
  rundy; początek/koniec odnoszą się do właściciela. Ręczna korekta tury jest neutralna.
- Kolejne źródła tego samego statusu mają osobne czasy, bez wzmacniania jego reguł.
  Wyczerpanie ma jeden ręczny licznik 0–6: −2/poziom do k20 i −1,5 m/poziom szybkości,
  minimum szybkości 0 oraz przypomnienie o śmierci na poziomie 6. MG redukuje licznik.
- Podpalenie przypomina 1k4 na początku tury. Nie rzuca kością ani nie odejmuje PW.
  Wygasły przed początkiem tury status nie wywołuje przypomnienia. Kilka źródeł
  Podpalenia tworzy jedno przypomnienie na turę tej postaci.
- Zapis statusów, postaci, przygotowania, tury i logu odbywa się atomowo. Log obejmuje
  dodanie, aktualizację, usunięcie, wygaśnięcie i przypomnienia o Podpaleniu.
- Reset przywraca przygotowane statusy i pozostały czas, zachowując historię.
  Czyszczenie logu zachowuje statusy. Szablony i inne instancje są niezależne.
- Stare statusy opisowe, snapshoty i runtime pozostają bez zmian. Nie rozpoznajemy
  systemowego działania na podstawie nazwy starego wpisu.
- Niedokończony formularz blokuje zwykłe zamknięcie i Cmd+Q, zachowuje tekst i wskazuje
  właściwy slot. Można go poprawić lub anulować. Szybkie akcje korzystają z kolejki zapisu.
- Dokumentacja, instrukcje Codex/Work i wersja aplikacji zostały uaktualnione.
  Brak nowych zależności. Stabilny identyfikator aplikacji i adres SQLite zachowane.

## Migracja 005

Nowa tabela `actor_statuses`: UUID, właściciel, typowany `status_json` i czas utworzenia;
indeks po aktorze i ochrona tożsamości/właściciela. Usunięcie aktora usuwa jego bieżące
statusy, ale zachowuje log. Rust i Zod walidują pełen kontrakt JSON.
Migracje 001–004 pozostają identyczne z bazą. Migracja 005 nie aktualizuje starych
rekordów, nie tworzy fikcyjnej historii i nie odtwarza bazy.

Dostarczenie plików nie otwiera bazy użytkownika. Migrację wykona pierwsze uruchomienie
aplikacji 0.6.0. Testy migracji i natywne testy UI używają osobnych baz testowych.

## Weryfikacja

- Pełne `pnpm check`: **95/95 testów w 18 plikach**, TypeScript, ESLint i Prettier.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **17/17**.
- `cargo fmt --check`, `git diff --check` i kontrola niezmienności migracji 001–004: poprawne.
- `pnpm build:macos`: poprawny produkcyjny build macOS arm64 0.6.0.
- `codesign --verify --deep --strict`: poprawny lokalny podpis ad hoc.
- Testy czasu pokrywają start, end, next_end, globalne rundy, jedną postać, brak
  inicjatywy, różne źródła, brak mutacji PW, stare opisy i reset liczników.
- Testy persistence sprawdzają zachowanie starych wierszy, snapshotów i logu,
  ponowne otwarcie pliku SQLite oraz kaskadę aktor/status bez usuwania historii.
- Błędy zapisu statusu i logu wycofują całą transakcję. Konflikt obcego ID statusu
  nie zapisuje nawet części nowej postaci. Retry zachowuje zdarzenia i kolejność.
- Natywny smoke test: osobny bundle `pl.neuroshima.combat-tracker.stage5-smoke`.
  BG „Żaneta Łącka”, inicjatywa 12, Podpalenie z opisem wielowierszowym i źródłem.
  Początek tury pokazał i zapisał 1k4 bez zmiany PW; kolejna tura wygasiła status
  i zachowała Wyczerpanie. Nie pojawiło się przypomnienie wygasłego Podpalenia.
- Wyczerpanie 1 → 2 → 3 pokazało kary −2/−4/−6 i −1,5/−3/−4,5 m. Jawne prepare
  na poziomie 2, zmiana do 3 i reset przywróciły poziom 2, rundę 1 i brak aktywnej tury.
- Cmd+Q poprawnie zakończyło zapisaną aplikację. Restart zachował status, log i dane BG.
  Cmd+Q z pustą nazwą własnego statusu zachowało okno, polski opis wielowierszowy
  i wyświetliło prośbę o dokończenie/anulowanie. Sprawdzono fokus nowego formularza.
- Obejrzano natywny widok 1100×760. Własne statusy i wszystkie warianty czasu mają
  testy domeny/store; nie klikano każdego wariantu w natywnym UI.

## Dostarczenie

Repozytorium docelowe: `/Users/dominik/Desktop/Combat Tracker`.
Aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzedni bundle zachowany jako `NeuroAltar 0.5.0.app` w tym samym katalogu.
Zastosowanie sprawdza czystość Git, bazowy commit, sumę patcha, zgodność drzewa
końcowego i podpis aplikacji. Baza MG nie jest częścią tej operacji.

## Ograniczenia przed Etapem 6

- Statusy pokazują reguły jako przypomnienia; nie zmieniają automatycznie wpisanych
  PW, TT, ruchu ani inicjatywy i nie podejmują decyzji MG. Pełne opisy zasad pozostają
  w podręczniku; aplikacja dostarcza krótkie przypomnienia.
- Edycja statusu uruchamia wybrany czas od nowa. Licznik rounds obejmuje bieżącą
  część rundy. Brak inicjatywy wstrzymuje zdarzenia początku/końca tury tej postaci.
- Stare statusy o nazwie np. „Podpalenie” nadal są opisowe. Systemową wersję należy
  dodać w nowym panelu; konwersja po nazwie mogłaby zmienić wcześniejsze ustalenia MG.
- Formularze i niezapisane akcje są w pamięci do zapisu. Wymuszone zabicie procesu
  może je utracić; zwykłe zamykanie chroni szkice i opróżnia kolejkę.
- Używaj wersji 0.6.0 do dalszej pracy z nowymi statusami. Starszy bundle nie zna
  nowego modelu i nie powinien służyć do edycji tych danych.
- Nie dodano Etapu 6 (Zranienia/Tchórzliwość), zasobów, broni, awarii, Ekwipunku,
  Wiedzy MG, importu Excel, rzutów ani liczenia amunicji.
- macOS 13.3+ Apple Silicon, lokalny podpis ad hoc bez notaryzacji. Intel/Windows
  i pełny przegląd wszystkich rozmiarów ekranu nie były częścią tej weryfikacji.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_5.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `manifest.json`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/005_actor_statuses.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/src/status.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/combatRepository.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/status.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/statuses/StatusForm.tsx`
- `src/features/statuses/StatusPanel.tsx`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/combatDatabase.test.ts`
- `tests/combatLogDatabase.test.ts`
- `tests/enemyDatabase.test.ts`
- `tests/status.test.ts`
- `tests/statusDatabase.test.ts`
- `tests/statusStore.test.ts`
