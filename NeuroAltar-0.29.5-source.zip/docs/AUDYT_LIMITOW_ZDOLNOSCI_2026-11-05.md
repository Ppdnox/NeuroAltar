# Limity użyć zdolności — sprawdzenie z podręcznikiem

Data: 2026-11-05. Dotyczy aktualnego 24E Roboczego oraz liczników przy zdolnościach.

## Źródło i zakres

Podstawą jest **Neuroshima: Ostatnia Era**, lokalny podręcznik
`reference/NOE_dla_dominadiinteriapl.pdf`. Wszystkie numery poniżej są numerami
**drukowanymi** (fizyczne strony PDF są o 2 większe). Przeczytano pełne rozdziały
pochodzeń (60–65), wszystkich sześciu klas i ich profesji (66–101), sztuczek
(102–108), Kolorów (201–203), a także zasady cech, rozwoju, wieloklasowości
oraz odpoczynków (13,45,58–59). Tabele i niejednoznaczne fragmenty sprawdzono
również na obrazach stron. Excel nie był źródłem limitów.

Zestawienie dotyczy pojemności pul, kosztu pojedynczego zastosowania i odnowienia.
Nie jest ponownym odbiorem wszystkich efektów zdolności, towarzyszy ani produkcji.

## Jak czytać wielkość puli

- `mod. Cecha` oznacza **modyfikator**, a nie wartość Cechy. W puli używamy
  `max(0, modyfikator)`. Źródło nie ustanawia minimum 1 dla tych zdolności.
- Zwykły BG ma Cechę najwyżej 20, czyli modyfikator +5 (s.13). Przy Cechach
  10/12/14/16/18/20 pula wynosi odpowiednio 0/1/2/3/4/5, jeśli jej podstawą
  jest ta Cecha. UI nie ma sztywnego ograniczenia do pięciu kropek: wyświetla
  rzeczywiście wyliczone maksimum, zachowując także historyczne nadpisania.
- PB wynika z **sumy poziomów postaci**, także przy wieloklasowości: 2 na
  poziomach 1–4, 3 na 5–8 i 4 na 9–12 (s.58–59).
- „Poziom Brutala” i podobne oznaczają poziom **konkretnej klasy**, nie sumę
  wszystkich poziomów.
- „Krótki lub długi” uwzględnia wcześniejszą decyzję użytkownika, że długi
  odpoczynek odnawia także wszystkie zasoby odnawiane krótkim.
- Podane maksima dotyczą standardowego rozwoju BG do poziomu 12, bez
  ręcznych nadpisań. Zmiany Cech, także uwzględniane skutki zdrowotne,
  przeliczają limit; zmiana maksimum sama nie zeruje wydanych użyć.

## Wszystkie 26 pul

| Zdolność            | Od kiedy / warunek posiadania           | Liczba kropek                                               | Potencjalne maksimum | Odnowienie                         | Strona                   |
| ------------------- | --------------------------------------- | ----------------------------------------------------------- | -------------------- | ---------------------------------- | ------------------------ |
| Berserk             | Brutal 1                                | 2 na poziomach Brutala 1–3, 3 na 4–6, 4 na 7–9, 5 na 10–12  | 5                    | Długi                              | 67–68                    |
| Wściekły cios       | Brutal 2                                | Tyle kości, ile poziomów Brutala                            | 12 kości             | Długi                              | 67–68                    |
| Motywacja           | Cwaniak 1                               | mod. CHA                                                    | 5                    | Krótki lub długi                   | 72                       |
| Szczęście           | Cwaniak 1                               | 1 na poziomach Cwaniaka 1–3, 2 na 4–6, 3 na 7–9, 4 na 10–12 | 4                    | Długi                              | 72–73                    |
| Spieprzysz to!      | Cwaniak 2                               | mod. CHA                                                    | 5                    | Krótki lub długi                   | 72                       |
| Obelga              | Cwaniak 5                               | PB                                                          | 4                    | Krótki lub długi                   | 73                       |
| Dobra rada          | Spec 1                                  | PB                                                          | 4                    | Krótki lub długi                   | 78                       |
| Inteligentna obrona | Spec 1                                  | mod. INT                                                    | 5                    | Krótki lub długi                   | 78                       |
| Łeb jak sklep       | Spec 2                                  | PB                                                          | 4 kości              | Długi                              | 78–79                    |
| Szybka produkcja    | Spec 3                                  | 1                                                           | 1                    | Krótki lub długi                   | 79                       |
| Szybkie ręce        | Spec 4                                  | mod. ZRC                                                    | 5                    | Krótki lub długi                   | 79                       |
| Trajektoria         | Spec 7                                  | PB                                                          | 4                    | Długi                              | 79                       |
| Kondycha            | Twardziel 1                             | mod. KON                                                    | 5                    | Długi                              | 86                       |
| Zryw                | Twardziel 2                             | 1                                                           | 1                    | Krótki lub długi                   | 87                       |
| Twardość            | Twardziel 3                             | mod. KON                                                    | 5 kości              | Długi                              | 87                       |
| Kocie kości         | Złodziej 2                              | mod. ZRC                                                    | 5 kości              | Długi                              | 91–92                    |
| Matrix              | Złodziej 7                              | PB                                                          | 4                    | Długi                              | 92                       |
| Saper               | Złodziej 11                             | 1, według wcześniejszego rozstrzygnięcia użytkownika        | 1                    | Krótki lub długi                   | 93 + decyzja użytkownika |
| Amen                | Wybrane w profesji Kaznodziei Nowej Ery | mod. CHA                                                    | 5 kości              | Długi                              | 75                       |
| Clint — Poprawka    | Wybrany Clint w profesji Kowboja        | 1                                                           | 1                    | Nowa walka                         | 88                       |
| Za garść gambli     | Wybrane w profesji Gwiazdy              | 1 koncert dziennie                                          | 1                    | Kolejny dzień; przywrócenie ręczne | 74                       |
| Czas patriotów      | Wybrana zdolność Nowego Jorku           | 1                                                           | 1                    | Długi                              | 63                       |
| Zawzięty sukinkot   | Wybrana zdolność Hegemonii              | 1                                                           | 1                    | Długi                              | 63                       |
| Wierzę              | Wybrana zdolność Salt Lake City         | 1                                                           | 1                    | Długi                              | 64                       |
| Fart                | Wybrana zdolność Vegas                  | 1                                                           | 1                    | Krótki lub długi                   | 65                       |
| Pieśń otuchy        | Sztuczka Muzyk                          | 1 wykonanie                                                 | 1                    | Długi                              | 105                      |

### Liczba kości a ich rozmiar i zastosowanie

Wściekły cios ma pulę równą poziomowi Brutala, lecz do jednego trafienia wolno
wydać najwyżej 3 kości k6, raz w rundzie. Jedna kropka oznacza jedną kość.

Twardość nadal ma tyle kości, ile mod. KON. Awans zmienia ich rozmiar:
Twardziel 3–5: k4, 6–8: k6, 9–11: k8, 12: k10.
Kocie kości mają liczebność mod. ZRC i rozmiar zależny od poziomu Złodzieja:
2–4: k4, 5–7: k6, 8–10: k8, 11–12: k10. Refleks, Koci odskok i Kocia
nieśmiertelność korzystają z **tej samej** puli Kocich kości. Nie dostają
kolejnego niezależnego zestawu kropek. Ciche, Cztery i Zgrabne łapy dopuszczają
wydanie jednej lub kilku kości; Refleks, Koci odskok i Kocia nieśmiertelność
wydają po jednej. Twardość pozwala wydać jedną kość po nieudanym RO.

Łeb jak sklep ma PB kości; wzrost Speca zwiększa ich rozmiar, nie mnoży
liczby użyć. Szybka produkcja na 11. poziomie nadal ma jedno użycie —
rośnie budżet przedmiotu z 25 do 50 gambli, nie liczba kropek. Amen ma mod. CHA kości k6; k6 nie oznacza sześciu użyć.

Muzyk wykonuje Pieśń otuchy raz na długi odpoczynek. `1 + mod. CHA`
określa liczbę sojuszników obdarowanych Fuksem, nie liczbę wykonań pieśni.
Odbiorcy muszą słyszeć muzyka, a wykonawca musi być biegły w używanym
instrumencie. Fuks jest ważny 24 godziny i jest osobnym zasobem odbiorcy.

## Wynik porównania i poprawki

25 wcześniej istniejących pul miało właściwe podstawy maksimum i odnowienia.
Nie potwierdziło się założenie, że liczba kropek ma zależeć tylko od poziomu.
Interfejs korzysta z `conditionView → deriveResources → deriveCharacter`,
obejmującego aktualne Cechy, PB, poziomy i wybrane reguły.

Dodano brakujący licznik **Za garść gambli**: 1 koncert dziennie. Nie odnawia
się od samego restartu, rozpoczęcia walki ani odpoczynku. Kolejny dzień gracz
oznacza przywróceniem kropki. Kliknięcie wyłącznie zapisuje użycie; nie dopisuje
zarobku ani Wyczerpania. Opis zachowuje czterogodzinny czas koncertu i jego
skutki. Uzupełniono opis Muzyka o odbiorców, warunki wykonania i ważność Fuksa.

Saper zachowuje przyjęte wcześniej rozstrzygnięcie: 1 użycie odnawiane krótkim
lub długim odpoczynkiem. Sam tekst na s.93 nie określa jednoznacznie wielkości
puli, dlatego nie przedstawiamy tej wartości jako bezspornej dosłownej reguły.

## Ograniczenia, które nie są pulą kropek

- „Raz na turę/rundę”, zwykły koszt Akcji Bonusowej lub Reakcji nie tworzą
  dodatkowego zasobu na odpoczynek. Dotyczy to m.in. Bolesnego ataku,
  Zwodu, Zabójcy mutantów i Słabego punktu.
- Ulubione bronie, biomy, kategorie wrogów, początkowe przedmioty i wybory
  sztuczek to limity wyborów, a nie zużywane użycia.
- **Truciciel (s.94):** jedna porcja 10 ml podczas długiego odpoczynku.
  Porcja pokrywa jedno ostrze albo do trzech grotów. To limit produkcji, nie pula kropek. Decyzja MG 2026-11-08: wystarcza opis;
  gracz sam rozlicza produkcję i wpisuje porcję. Nie dodajemy automatycznej
  kontroli konkretnego odpoczynku; nie jest to otwarte zadanie.
- **Pogromca (s.99):** do PB pocisków podczas długiego odpoczynku, po
  10 gambli za pocisk; potencjalnie 2–4 przy poziomach postaci 1–12.
  Decyzja MG 2026-11-08: wystarcza istniejący opis; gracz sam oblicza koszt
  i ilość, po czym wpisuje pociski. Automatyczna kontrola produkcji nie jest
  zadaniem. Nie odnawiamy zgromadzonej amunicji do wartości PB.
- **Emiter EMP (s.101):** akumulator na 6 strzałów ładowany prądem 230 V;
  to magazyn broni, nie sześć użyć zdolności na odpoczynek.
- Towarzysze pozostają wcześniej odłożonym modułem; ich PW i KW nie są
  zasobami postaci sterującej.

## Kolory

Kolory nie zmieniają bezpośrednio liczby użyć wymienionych pul. Zmieniają
czasy odpoczynku: Rdza 24/72 h, Chrom 1/8 h, pozostałe 4/24 h. Stal i Chrom
przyznają po jednym Fuksie na sesję; Rtęć wyłącza wszystkie Fuksy zgodnie
z decyzją użytkownika, także pochodzące z Pieśni otuchy. Nie jest to zakaz
każdego przerzutu: Fart, Szczęście lub Amen nie stają się przez to Fuksami.

## Sprawdzenie implementacji

Testy obejmują wszystkie podstawy limitów, progi klasowe i PB, wieloklasowość,
zmiany modyfikatora bez awansu, spadek maksimum bez kasowania zużyć oraz
oddzielną odnowę koncertu. Wyniki końcowe i build podaje raport
[zmian UI](UI_ZASOBY_I_ZAKLADKI_2026-11-05.md).
