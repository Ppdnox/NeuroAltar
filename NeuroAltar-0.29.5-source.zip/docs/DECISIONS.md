## Decyzja MG — produkcja ręczna i przygotowanie Windows, 2026-11-08

Truciciel i Pogromca pozostają opisami w zakresie produkcji. Gracz sam oblicza
ilości, koszty/czas i ręcznie wpisuje wytworzone przedmioty lub pociski.
Nie implementujemy dedykowanej kontroli produkcji na odpoczynek, automatycznego
pobierania kosztu ani dopisywania produktów. Nie jest to otwarty brak 24E.
Decyzja zastępuje wcześniejsze wskazanie tych dwóch automatyzacji jako zadań.

Zlecono porządek dokumentacji oraz przygotowanie buildu Windows na bazie
24E Roboczego. Przygotowanie można wykonać teraz; nie oznacza końcowego odbioru
24E, gotowego instalatora ani zaliczonego testu Windows. Nie podmieniamy aplikacji
macOS ani bazy użytkownika. Aktualny [status](STATUS.md), [plan](PLAN_DALSZYCH_PRAC.md)
i [procedura Windows](BUILD_WINDOWS.md) zastępują dawne listy następnych etapów.

Starsze wpisy poniżej są rejestrem decyzji; w razie zmiany obowiązuje nowsza decyzja.

## Kierunek interfejsu — decyzja MG, 2026-11-04

Użytkownik zaakceptował połączenie poziomego paska parametrów i lewej nawigacji
ze „Stołu gracza” z głównymi zakładkami „Trybu sesji”. Wdrażamy ten układ
na aktualnym 24E Roboczym, zachowując istniejącą papierową paletę i zasady.
Pozostałe funkcje karty (zdrowie, postój, rozwój, podsumowanie) pozostają dostępne.
Szczegóły: [UI_GUIDELINES.md](UI_GUIDELINES.md).

## Zdolności BG: mechanika a opis — decyzja MG, 2026-09-27

Mechanicznie obsługujemy tylko zdolności z mierzalnym skutkiem dla rzutów, przerzutów, zasobów, akcji lub innych reguł. Zdolności czysto fabularne pokazujemy graczowi w opisie karty; nie tworzą arbitralnych modyfikatorów przez panel walki. Brak gotowej obsługi zdolności mechanicznej pozostaje jawnym zadaniem, a nie powodem do uznania jej za narracyjną. [Zakres 24E](24E_BRAKI_ZDOLNOSCI.md).

## Aktualny zakres 24E — decyzja MG po przeglądzie braków

Teraz: obsługa zdolności i sztuczek w walce oraz wspólne obliczanie rzutów
z karty BG i potyczki. Gracz potwierdza warunki sytuacyjne, cel i efekt;
nie rozstrzygamy automatycznie trafienia ani nie odejmujemy PW po rzucie.

Towarzysze (BG-42) przechodzą do listy pomysłów na przyszłość, bez terminu
realizacji i bez blokowania 24E. Wykreślone z wymagań tego etapu:
automatyczne przerywanie Berserka przez stany, dalsza automatyzacja zacięć
oraz przegrzania, integracja leków z walką i tworzenie pełnej karty ze starego
uproszczonego BG. Przerwanie Berserka śledzi gracz. Zachowane już działające
ręczne funkcje nie są usuwane. Powiązanie z istniejącą kartą BG pozostaje.

Pełny odbiór testowy nastąpi po zakończeniu buildu i dalszych poprawkach,
zgodnie z ustalonym harmonogramem. Bieżące sprawdzenie kompilacji nie stanowi odbioru.
Ta decyzja ma pierwszeństwo przed starszą matrycą kompletności i historycznymi
wymaganiami testów dla każdego podetapu. Stan: [raport 24E](ETAP_24E.md).

## Etap 24E — rozstrzygnięcia MG, 2026-09-20

- Przegrzewanie po seriach obowiązuje również w Chromie.
- Jeden cios daje najwyżej jedno Zranienie, także przy jednoczesnym krytyku,
  spadku do 0 PW i przekroczeniu progu Kondycji w Rdzy.
- Krwawienie odejmuje łącznie 1 PW na turę, niezależnie od liczby Zranień.
- Rzut nie odejmuje PW automatycznie; rozliczenie zdrowia pozostaje jawne.

Stan wdrożenia i pozostały zakres: [ETAP_24E.md](ETAP_24E.md).
Etap pozostaje w toku; ten zapis nie oznacza odbioru ani wydania aplikacji.

# DECISIONS

## 0.29.3 — amunicja bez masy

Decyzja MG: amunicja nie ma parametru masy w interfejsie i nie obciąża BG,
zarówno w zapasie, jak i po załadowaniu. Dotyczy też wcześniejszych kopii.
Puste magazynki pozostają osobnymi przedmiotami. Zachowujemy liczbę naboi,
kaliber, ceny i wszystkie istniejące zapisy; bez migracji SQL.


## Aktualizacja 0.29.2 — obsługa karty BG

Usunięto pola powodu, uzasadnienia masy i zapłaconej ceny z formularza przedmiotu.
Masy kategorii broni „ok. X kg” liczymy jako stałe X kg. Przeładowanie jest przy
stanie magazynka. Cechy, umiejętności i RO BG wywołują rzuty z trwałym podpisem
postaci. Mutkornica: TT 12 (nowsza decyzja MG zastępuje TT 15).
Pełne połączenie BG z walką nadal należy do 24E.


## Aktualizacja 0.29.1 — czytelność, korekty 24D i Moloch City

Nowy podział karty BG na sekcje zachowuje dotychczasową kolorystykę.
Poprawiono dawki leków, ograniczenia Rtęci, RadOff, zegar odpoczynku/postoju
oraz uwzględnianie wyuczonych biegłości podczas zatwierdzania karty.
Dodano 11 przeciwników i Beamgun/BigBeamgun z Suplementu Moloch City.
Decyzje MG: Mutkornica TT 15; dostępność obu broni 0%.
Bez nowej migracji SQL. Raport i ograniczenia: [POPRAWKI_0.29.1.md](POPRAWKI_0.29.1.md).
Etap 24E jest w toku; Windows dopiero po ukończeniu i odbiorze karty BG.


## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.


Uzupełnienie MG: wybór **Koloru gry** w rogu karty (N/D, Rdza, Rtęć, Stal, Chrom),
odrębny od handlu, z wpływem na rozwój i odpoczynki. Kontrakt i testy:
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).

## 2026-09-13 — Etap24C i trzy rozstrzygnięcia MG

1. „Chrom: nieliczony zapas i pusta broń przy1”. Domyślny tryb wg Koloru;
   dokładny zapas i napełnienie magazynków nie są kasowane ani nadpisywane.
   Jawne przełączenie trybu jest możliwe po podglądzie. W24C oznaczenie1 jest
   przyciskiem, automatyczne powiązanie z testem ataku należy do24E.
2. „Tak, środki leczące w Chromie kosztują połowę”. Wyjątek z podręcznika s.203
   dotyczy obu kalkulatorów (MG/BG), kategorii Środki lecznicze, bez zmiany
   historycznej kwoty zapłaconej i bez zmiany cen innych kategorii.
3. „+5 punktów procentowych przed mnożnikiem Koloru” dla Gambling we krwi.
   Dostępność=(baza+lokalizacja+5pp)×Kolor, następnie ograniczenie0–100.
   Bez tej zdolności premia0; none/none/none zachowuje dokładne zakresy bazowe.

Podetap24C został zlecony. Inwentarz jest odrębny od szkicu awansu; jego
operacje zapisują się atomowo z rewizją i pełną historią. Masa w miligramach,
ilość w tysięcznych jednostki; naboje tylko całkowite. Nieznana masa jest jawna.
Masa pancerzy wspomaganych z n.d. nie jest odgadywana z liczby w nazwie.
Źródła: podręcznik s.53–54,67,72,78,86,91,96,107,113–125,203,257.

## 2026-09-13 — Etap24B i minimum PW

MG rozstrzygnął „Minimum 0 PW na awans”. Minimum dotyczy każdego późniejszego
przyrostu po dodaniu klasy, bieżącego modyfikatora KON i Koloru zapisanego przy
awansie. Pierwszy poziom ma własny wzór. Przeliczenie KON jest wsteczne;
zmiana Koloru domyślnie przyszła, a zmiana historii wymaga jawnego podglądu.
Żadna z tych operacji nie odnawia aktualnych PW.

Profesja daje na progu jedną wybraną, jeszcze nieposiadaną zdolność z całej listy;
jej pozycja w podręczniku nie wyznacza poziomu nabycia. Dotyczy wszystkich18profesji.
Gotowa karta i szkic są osobne. Korekta wcześniej zatwierdzonego rozwoju wymaga
uzasadnienia, zapisywanego razem z operacją. Zwykły kolejny poziom go nie wymaga.
Migracja011 jest addytywna; bez automatycznej adopcji starych BG i bez zmiany
pięciu slotów. 24C pozostaje osobnym zleceniem.

## 2026-09-13 — Etap 24A i ostateczne poziomy zdolności

- MG zlecił kolejny etap po23: realizacja24A zgodnie z PLAN_DALSZYCH_PRAC.
  Opracowano specyfikację i model, bez implementacji24B. Aplikacja nadal0.26.0.
- **Ostateczna korekta MG: Samouk poziom9; profesje Twardziela3/7/11.**
  Zastępuje wcześniejsze wskazanie opisów (7 i3/6/11) z tej samej rozmowy.
  Nie przenosić tamtej interpretacji do nowych definicji ani testów.
- Źródłem zasad jest lokalny Neuroshima: Ostatnia Era, strony drukowane;
  wzorzec czterostronicowej karty wyznacza strukturę. Arkusz nie zastępuje reguł.
- Kontrakt projektowy24A: Character trwały, Participation lokalny; wiele
  przygotowanych slotów, najwyżej jeden aktywny udział tej postaci. Powiązanie
  legacy wyłącznie jawne, reset/clear nie cofa trwałych PW/rozwoju/inwentarza.
- Szczegóły: [KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md),
  [KARTA_BG_KATALOG_REGUL.md](KARTA_BG_KATALOG_REGUL.md),
  [KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md),
  [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md). Otwarte interpretacje Q
  wymagają rozstrzygnięcia przed automatyzacją, nie domysłów z D&D.
- Bez nowych migracji, zmian DB i podmiany aplikacji. Raport ETAP_24A.md.
  Etap24B został następnie zlecony i wdrożony; patrz aktualna decyzja powyżej.

## 2026-09-13 — Kolory na karcie BG

- MG zlecił uwzględnienie pola wyboru Koloru gry przy karcie; Kolor może
  modyfikować rozwój, np. Rdza. N/D oraz Rdza/Rtęć/Stal/Chrom w rogu nagłówka.
- Reguły źródłowe: Neuroshima: Ostatnia Era, s.201–203. Pełna specyfikacja
  i testy COL w KARTA_BG_KOLORY.md; nie utożsamiać tego ustawienia z TradeContext.
- Projekt zachowuje historię Koloru przy każdym awansie; przełączenie istniejącej
  karty wymaga podglądu, bez cichego przeliczenia całego życia postaci.
- Samo uwzględnienie Kolorów nie kasuje wcześniejszego zlecenia dokładnej amunicji
  BG ani reguły cen Chromu×1. Wyjątki podręcznika opisano w COL-Q do rozstrzygnięcia.


## 2026-09-13 — rozstrzygnięcia MG dla mechaniki BG

- Q-01: Saper ma jedno użycie, odnawia się po krótkim lub długim.
- Q-05: długi odpoczynek odnawia również zasoby odnawiane po krótkim;
  nie stanowi to polecenia odnawiania amunicji, przedmiotów lub zasobów ręcznych.
- Q-06: modyfikatory procentowe sumują się względem bazy; dwa podwojenia→×3,
  dwa +50%→×2, zamiast kolejnego mnożenia. To przyjęta interpretacja „sumują się”.
- Q-07: zestaw startowyX ma jeden Item o masieY i opis zawartości;
  nie szacować niepodanych mas składników ani liczyć zawartości drugi raz.
- Q-08: zacięcie sprawdzane przy pierwszym wystrzale; akcja zmarnowana,
  cała amunicja zachowana. Sam rzut w rollerze nie jest deklaracją strzału.
- Q-10: wymagane zaokrąglenia mechaniczne zawsze w dół. Nie ucinać przez to
  ułamkowych mas/jednostek; prezentacja nadal do dwóch miejsc po przecinku.
- Q-04 ma dzięki temu rozstrzygnięty kierunek zaokrąglenia. Nadal brakuje
  podstawy połowy KW; w Q-10 nadal nie ustalono znaczenia tempa50% ani
  kolejności osobistej premii dostępności. Pozostałe Q/COL-Q zgodnie z rejestrem.

## Historia decyzji (obowiązują późniejsze korekty powyżej)

## 2026-08-28
- v1.0 tylko macOS; Windows później.
- dokładnie 5 aktywnych potyczek.
- biblioteka zapisanych encounterów dopiero po v1.0.
- każdy przeciwnik ma osobną inicjatywę; brak grupowania.
- BG: Imię, TT, PW, inicjatywa, statusy.
- brak dice rollera w v1.0.
- formuły kości wyraźnie oznaczone ikoną.
- brak liczenia amunicji i magazynków w v1.0.
- wariant amunicji może wpływać na profil broni.
- NPC zawsze biegły w przypisanej broni; PB doliczany.
- Krwawienie to efekt opisowy konkretnego statblocka.
- Podpalenie: systemowe przypomnienie 1k4 na początku tury.
- difficulty: ciągły pasek SP/SD.
- program ewidencjonuje i przypomina, nie decyduje za MG.
- template nigdy nie jest modyfikowany runtime zmianą instancji.
- Reset = prepared snapshot.
- stack: Tauri 2 + React TS + Vite + Tailwind + SQLite + Zod + Zustand + Vitest + Git.

## 2026-09-06 — nazwa i oprawa przed Etapem 1
- Na prośbę użytkownika nazwa produktu to **NeuroAltar**.
- Kierunek wizualny inspirowany lokalnym podręcznikiem Neuroshima 5e: papier kości słoniowej, grafitowy metal, ciemny turkus, rdza i ochra.
- Szczegóły i tokeny: `docs/VISUAL_IDENTITY.md`; wszystkie późniejsze ekrany mają stosować te same role kolorów i typografię.
- Własna oprawa CSS/SVG; ilustracje, logo i pliki fontów podręcznika nie są zasobami aplikacji.
- Stabilny identyfikator aplikacji i URL SQLite zachowują dane po zmianie nazwy. Zmiana nie wymaga migracji DB.
- Ten zakres obejmuje nazwę i wygląd istniejącego ekranu; nie uruchamia Etapu 1 ani funkcji Etapu 13.

## 2026-09-07 — Etap 1.5, architektura NeuroAltar

- Zachowujemy ukończone Etapy 0–1; checkpoint Etapu 1 to `148c4a9`, drzewo przed Etapem 1.5 było czyste. Nie zaczynamy Etapu 2.
- NeuroAltar jest warsztatem MG: Walka, Potyczki, Bestiariusz, Ekwipunek, Wiedza MG. Nazwa produktu była już wdrożona; ujednolicamy pozostałą dokumentację.
- v1.0: część bojowa. v1.1: Ekwipunek. v1.2: Wiedza MG. W v1.0 profile broni są oparte na Item; pełny katalog i handel czekają do v1.1.
- Zamiast przyszłego `weapons` przyjmujemy `items` / Item oraz opcjonalny weaponProfile. Typy: weapon, armor, ammunition, tool, electronics, food, fuel, other.
- Item przechowuje zakresy ceny i dostępności, kategorię ekonomiczną, wagę, opis i właściwości. Brak danych nie jest zerem. Szczegółowy kontrakt: `docs/DATA_MODEL.md`.
- TradeContext ma niezależne region, lokalizację i Kolor; każde ma `none` (N/D). Domyślne none/none/none oznacza dokładne wartości bazowe.
- Cena = baza × region × Kolor; dostępność = (baza + lokalizacja) × Kolor, ograniczona na końcu do 0–100%. Obie granice zakresu są obliczane osobno.
- Reguły N/D/Rdza/Rtęć/Stal/Chrom: tabela w `docs/DATA_MODEL.md`; Stal modyfikuje tylko weapon i ammunition.
- calculateMarketPrice, calculateMarketAvailability i calculateMarketValues pozostają projektem czystych funkcji domenowych. Nie dodajemy ich implementacji w Etapie 1.5.
- KnowledgeEntry / alias ReferenceEntry to przyszły model Wiedzy MG w v1.2.
- Excel posłuży jednorazowo jako źródło seed data w v1.1. Bez runtime sync, ponownego importu i skryptu importu w Etapie 1.5.
- Bez UI Ekwipunku, Wiedzy MG, k100, regionu/lokalizacji/Koloru, dice rollera i liczenia amunicji w tym etapie.
- Bez zmian zachowania pięciu slotów, autozapisu, testów, istniejącej migracji 001, identyfikatora aplikacji i adresu SQLite. Bez migracji w Etapie 1.5; przyszłe zmiany schematu muszą zachować istniejącą bazę.
- Historyczne raporty Etapu 0 i 1 opisują wcześniejsze wykonanie. Aktualne instrukcje startowe nie zlecają już bootstrapu.

## 2026-09-07 — Etap 2, BG i inicjatywa

- Użytkownik zlecił Etap 2 po commicie 241c0a6. Nie rozszerzamy go o Etap 3 ani Ekwipunek.
- BG: imię, TT, aktualne/maks. PW, ręcznie wpisana inicjatywa, ręczne statusy opisowe. Czas/automatyczne efekty statusów dopiero w Etapie 5, log w Etapie 4.
- Kolejka malejąca; pusta inicjatywa poza kolejką, 0 i wartości ujemne poprawne. Ręczne strzałki rozstrzygają remisy. Wstępny porządek remisów zachowuje kolejność dodania, bez losowania.
- Pierwszy start nie zwiększa rundy. Przejście za ostatniego aktora zwiększa rundę. 0 PW nie pomija tury. Zmiana kolejności zachowuje aktywne UUID.
- MG może wskazać bieżącą turę bez zwiększania rundy. Usunięcie aktywnego BG albo usunięcie jego inicjatywy odznacza turę i pozostawia rundę.
- BG są niezależni między slotami. Usunięcie wymaga potwierdzenia; nie usuwa slotu. Skróty PW ograniczają wynik do 0–maks., błędny ręczny wpis wymaga poprawy.
- Migracja 002 jest addytywna. Nie zmieniamy migracji 001, bazy, identyfikatora aplikacji ani nazw technicznych. Wersja aplikacji 0.3.0.
- Zapis BG i rundy/tury jest atomowy w transakcji Rust/SQLx na poolu istniejącego pluginu. combat_revision zapobiega nadpisaniu zmian drugiego okna; konflikt zachowuje szkic.
- Autozapis i zamykanie obejmują obie grupy danych: nazwę/notatki i BG. Niepełnych pól liczbowych nie zamieniamy na zero.
- Materiały prywatne reference pozostają poza Gitem i aplikacją.

## 2026-09-07 — Etap 3, przeciwnicy i reset

- Etap 2 zastosowano w repozytorium jako `358a865`; użytkownik potwierdził poprawne
  otwieranie i zamykanie aplikacji oraz zlecił Etap 3.
- Każdy przeciwnik to odrębna instancja podstawowego EnemyTemplate. Kategorie
  human/beast/machine/other są profilami prezentacji. Każda kopia ma własną inicjatywę.
- Szablon jest tworzony z danych MG i zachowywany w enemy_templates. Dodanie kolejnej
  kopii korzysta z szablonu, nie ze zranionej instancji. Bez seeda z prywatnych źródeł.
- Pełny CRUD, wyszukiwanie, filtry i Add ×N pozostają w Etapie 8. Etap 3 pozwala
  utworzyć podstawowy szablon i dodać pojedyncze kopie z jego karty.
- Ruch to lista nazw sposobów przemieszczania i nieujemnych metrów, także ułamkowych.
  Pole puste = brak danych, 0 = jawna zerowa szybkość. Bez automatycznych kar za zranienia.
- Explicit prepare: MG potwierdza zastąpienie punktu powrotu aktualnym stanem obecnych
  postaci. Zwykła edycja runtime nie zmienia szablonu ani punktu powrotu.
- Reset wymaga potwierdzenia. Przywraca nazwy instancji, PW/max PW, TT, inicjatywę,
  kolejność remisów, ręczne statusy i ruch obecnych członków. Runda 1, brak aktywnej tury.
  Skład, nazwa potyczki i notatki pozostają. Nie odtwarzamy usuniętych członków.
- Migracja 003 dodaje reset_snapshot_json jako aktywny punkt powrotu, zachowując
  niezmienny prepared_snapshot_json z 002. Stare BG korzystają z oryginalnego snapshotu
  do pierwszego jawnego przygotowania. Nie resetujemy danych podczas migracji.
- Wszystkie zapisy szablonów/aktorów/baseline/rundy/revision są jedną transakcją.
- Wersja 0.4.0. Bez Etapu 4, czasu statusów, mechanik maszyn, zasobów i Ekwipunku.

## 2026-09-07 — Etap 4, log walki

- Użytkownik zlecił Etap 4 po zastosowaniu Etapu 3 (`94044bf`). Wersja 0.5.0.
- Log jest niezależny dla pięciu slotów i trwały w SQLite. Migracja 004 nie zmienia
  istniejących danych i nie tworzy fikcyjnych wpisów dla wcześniejszej historii.
- Wpisy generuje czysta funkcja Rust porównująca poprzedni zapisany stan i następny
  stan. Dopisanie odbywa się w tej samej transakcji co zapis walki; każda porażka
  wycofuje również log. Revision chroni przed duplikacją przy konflikcie ponowienia.
- Akcje PW/tur zachowują kolejne checkpointy, nawet jeśli szybka seria wraca do
  początkowej wartości. Edycje tekstowe nadal debounce'ują; logujemy zapisane różnice.
- Zakres: skład, nazwa instancji, PW/max PW, TT, inicjatywa/remisy, ręczne statusy,
  ruch, tury/rundy, jawne prepare/reset. Wybór karty i nazwy/notatki slotów nie są
  zdarzeniami bojowymi. Mechaniki przyszłych etapów nie zostały dodane.
- Reset zachowuje log i dopisuje marker. Wyczyść log po potwierdzeniu usuwa całą
  historię jednego slotu, pozostawiając stan walki i snapshoty bez zmian.
- Log przechowuje historyczny opis, actor_id bez FK oraz strukturalny before/after.
  Usunięcie aktora nie usuwa jego historii. Nie ma automatycznej retencji.
- UI pokazuje najnowsze wpisy, rundę i lokalny czas. Paginacja po 100 z kursorem ID
  nie gubi remisów czasowych. Błąd odczytu jest jawny, dostępne ponowienie.
- Etap 5 i późniejsze funkcje wymagają nowego zlecenia.

## 2026-09-08 — Etap 5, statusy

- Użytkownik zlecił Etap 5 po ec3efb4. Wersja 0.6.0. Bez Etapu 6.
- Katalog 14 stanów ze specyfikacji i Podpalenie; własne nazwy, opisy, źródła.
  Systemowe wpisy mają krótkie przypomnienia, bez kopiowania podręcznika do aplikacji.
- Reguły Wyczerpania zweryfikowano w lokalnym podręczniku, drukowane s. 35–36:
  kumulacja 1–6, kara 2 × poziom do k20, spadek szybkości 1,5 m × poziom,
  śmierć na poziomie 6; Długi odpoczynek obniża o 1. W UI jeden ręczny licznik,
  kary jako przypomnienie, bez nadpisania PW/TT/ruchu/inicjatywy i usuwania postaci.
- Pozostałe powtórzone stany mają niezależne czasy, lecz nie wzmacniają efektu.
  Podpalenie: pojedyncze przypomnienie 1k4 na początku tury, niezależnie od liczby źródeł.
  Brak rzutu i automatycznej zmiany PW. Krwawienie pozostaje opisem konkretnego efektu.
- Przyjęta konwencja czasu: rounds zmniejsza się przy globalnej zmianie numeru rundy,
  w tym po bieżącej części rundy. Początek/koniec odnoszą się do właściciela statusu.
  until_end_of_next_turn pomija bieżący koniec, gdy właściciel jest aktywny w momencie
  dodania; w przeciwnym razie czeka na jeden koniec jego przyszłej tury.
- Next Turn wykonuje kolejno end/wrap/start. Wygasanie poprzedza przypomnienie
  Podpalenia. Start pierwszej tury nie zwiększa rundy. Jedna postać też ma end/start.
  Ręczna korekta aktywnego aktora i restart są neutralne, bez odliczania.
- Edycja statusu jawnie uruchamia wybrany czas ponownie. Wyczerpanie jest ręczne.
  Nie dodano źródłowego aktora jako zegara czasu; sourceText jest opisem.
- Migration 005 tworzy actor_statuses (UUID, actor FK, zwalidowany status_json,
  created_at, indeks, ochrona właściciela). Wszystkie pola statusu są w typowanym
  JSON zamiast równoległych kolumn i metadata_json; jeden kontrakt TS/Rust.
- Ręczne statusy Etapów 2–4 pozostają w manualStatuses i snapshotach bez zmiany.
  Nie promujemy ich po nazwie do statusów systemowych ani nie tworzymy fikcyjnego logu.
- Runtime effects, snapshoty i log zapisują się w jednej transakcji. Reset odtwarza
  również pozostałe liczniki ze stanu przygotowanego. Wyczyść log nie zmienia effects.
- Niedokończony formularz statusu jest szkicem w pamięci, blokuje zwykłe zamykanie
  oraz Cmd+Q i wskazuje właściwy slot. Wymuszone zabicie procesu może utracić szkic.

## 2026-09-09 — Etap 6, Zranienia i Tchórzliwość

- Użytkownik zlecił Etap 6 po 5c82f49. Wersja 0.7.0, bez Etapu 7.
- Zakres przeciwników zgodnie z kontraktem BG. Opcjonalny tor i próg w szablonie,
  niezależna konfiguracja runtime. Stare dane domyślnie bez toru i progu.
- Reguły sprawdzono w lokalnym podręczniku, drukowane s. 32 i 205. Konsekwencje
  stopni narastają; poziom zmienia ręcznie MG. PW/0 PW nie dodają Zranienia.
- Reprezentacja 0–4 plus deathWarning na 4 przy kolejnym Zranieniu. Ostrzeżenie
  nie usuwa aktora i nie pomija jego tury; −1 cofa je do 4.
- Przejście z poziomu <4 do 4 dodaje jeden poziom wspólnego Wyczerpania, maks. 6.
  InitialLevel=4 nalicza go raz dla nowej kopii przed prepare. Sam zapis, restart,
  tura, ponowny poziom 4, cofnięcie ostrzeżenia i reset nie naliczają go ponownie.
- Przyjęta konwencja korekty: obniżenie/wyłączenie Zranień nie leczy Wyczerpania,
  które MG obniża oddzielnie. Ponowne wejście z 3 na 4 to nowe +1. Wyłączenie
  jawnie zeruje tor i ostrzeżenie. Wszystko obejmuje przygotowanie/reset.
- Podgląd ruchu = max(0, wpisany ruch − 4,5 m za Zranienie ≥1 − 1,5 m × Wyczerpanie).
  Wpisany ruch pozostaje przed karami. Pozostałe statusy nie są silnikiem ruchu.
  Brak Reakcji i Akcji Bonusowych to informacja, bez liczników Etapu 7.
- Tchórzliwość: null/brak = wyłączona; całkowite 0–100%, próg liczony z aktualnego
  maks. PW. Dla całkowitych PW floor(max × % / 100), dokładna arytmetyka całkowita.
  Ostrzeżenie utrzymuje się przy PW ≤ próg, znika powyżej. Log ostrzega przy wejściu
  w ten stan, także po zmianie progu/maks. PW; nie dopisuje go przy każdym zapisie.
- Opcjonalne pola w już istniejących JSON szablonu/runtime/snapshotu. Bez nowej
  tabeli, kolumny, migracji SQL, przepisywania danych lub zmiany migracji 001–005.
  Zod i Rust walidują zgodny zakres. Template identity pozostaje niezmienna.
- Dane, Wyczerpanie, revision, snapshot i log zapisują się atomowo. Surowy błędny
  procent pozostaje edytowalny i blokuje normalne zamknięcie aplikacji.

## 2026-09-09 — Etap 7, zasoby i akcje

- Użytkownik zlecił Etap 7 po dddaa28. Pakiet 0.8.0. BG zachowują swój kontrakt.
- Uniwersalne liczniki 0–maks. (maks. 1–999), refresh round/encounter/day/manual.
  Round to globalna zmiana numeru rundy (również dla postaci bez inicjatywy).
  Encounter/day odnowienie tylko po poleceniu MG i potwierdzeniu, w jednym slocie;
  bez resetu HP, tury, statusów lub snapshotu. Nie używamy zegara kalendarzowego.
- Pula A/B/R po 1, odnawiana przy zwykłym starcie własnej tury (również pierwszym).
  Reakcja zgodnie z lokalnym podręcznikiem drukowana s. 23. Konwencja Legendarnych:
  pula 0–999, odnowienie przy globalnej nowej rundzie, zgodnie z liczeniem na rundę
  statblocków (drukowane s. 217, 231, 237); szczególny moment MG koryguje ręcznie.
  Nie kopiujemy tekstu zdolności podręcznika. MG wprowadza własne nazwy/opisy.
- Zdolność ma rodzaj action/bonus/reaction/legendary, opis, opcjonalny zasób i koszt.
  Jeden klik zużywa pulę (legendarny koszt 1–999) i zasób w tej samej transakcji.
  Akcja ataku wielokrotnego zużywa jedną akcję, nie każdy atak. Efekty tylko opisowe.
- Zranienie >=2 blokuje zwykłe Reakcje, >=3 Bonusowe; systemowe incapacitated,
  unconscious, stunned, paralyzed blokują zwykłe A/B/R/L. Stare statusy tekstowe
  pozostają opisowe. Death warning nie usuwa aktora ani nie wymusza jego losu.
- Jawny „Wyjątek MG” może zarejestrować użycie mimo blokady/zużytej puli, z osobnym
  potwierdzeniem i wpisem logu. Nadal musi wystarczyć zasobu, pula nigdy nie spada
  poniżej 0. „Przywróć” i edycja licznika są osobnymi ręcznymi korektami.
- Program nie wymusza momentu użycia (np. opóźniony zapis Reakcji). MG wybiera cele,
  rozstrzyga efekty i stosuje legendarne po turze innej postaci. Brak rzutów/obrażeń.
- Szablon: optional capabilities Setup; instancja: niezależny State. UUID zasobów
  i zdolności są unikatowe wewnątrz konfiguracji aktora; kopie mogą mieć te same
  klucze definicji, ale nigdy współdzielone obiekty ani liczniki.
- Physical storage: istniejące statblock_json/runtime_overrides_json/snapshoty.
  Nie dodajemy redundantnej actor_resources obok tych danych. Wcześniejsza tabela
  była modelem docelowym; Stage 7 wdraża typowany JSON bez DDL/migracji 001–005.
- LastUse + usageNumber odróżniają kolejne użycia także przy wyjątku z pustą pulą.
  Liczniki, koszt, zdarzenie i revision są atomowe. Reset odtwarza snapshot i nie
  emituje fikcyjnego action_used. Przygotowanie/restart/korekta tury nie odnawiają.
- Formularz całej konfiguracji w store chroni niepełne dane i usunięte wiersze
  przed przypadkowym zamknięciem; Anuluj zachowuje poprzedni zapis. Powiązany zasób
  można usunąć dopiero po zmianie/usunięciu odwołujących się do niego zdolności.

## 2026-09-09 — Etap 8, Bestiariusz

- Użytkownik zlecił Etap 8 po 5ecd53c; wersja 0.9.0. Bez Etapu 9.
- CRUD obejmuje pola wdrożone w Etapach 3, 6, 7. Kolejne profile/mechaniki nadal
  powstają w swoich etapach; brak importu i kopiowania prywatnego podręcznika.
- Migracja 006 rozszerza enemy_templates o revision i deleted, bez przebudowy
  tabel, zmian migracji 001–005 i przepisywania runtime/snapshotów/logów.
- Usunięcie z katalogu to deleted=1, także dla nieużywanych wzorców. Zachowuje
  tożsamość referencji i zapobiega odtworzeniu wpisu przez późniejszy autozapis.
  Nie ma automatycznej retencji ani UI kosza/przywracania w tym etapie.
- Template snapshot istniejącej postaci pozostaje niezmienny także po edycji
  katalogu. Nowa kopia może użyć aktualnej definicji katalogu lub definicji
  trzymanej przez zapisaną kartę przeciwnika. Nie aktualizujemy starych aktorów.
- Duplikat ma nowe ID katalogu i niezależną konfigurację. ID zasobów/zdolności
  mogą pozostać takie same, bo ich przestrzeń identyfikacji jest lokalna.
- Zapis katalogu ma kontrolę revision; identyczne ponowienie po niepewnym wyniku
  jest idempotentne. Inny wynik/wersja daje konflikt, bez zmiany danych.
  Niezapisana zmiana pozostaje w pamięci do ponowienia lub jawnego odrzucenia.
- Add ×N tworzy 1–100 kopii jednym checkpointem i transakcją walki. Każda ma
  osobne UUID, inicjatywę null, tie order, pełne liczniki i prepared snapshot.
  Zmiana katalogu sama w sobie nie jest zdarzeniem w logu potyczki.
- Wyszukiwanie nazwy/zdolności nie rozróżnia wielkości liter ani polskich znaków;
  filtry kategorii i rozmiaru działają łącznie, wyniki sortujemy po polskiej nazwie.
- Zamknięcie czeka na zapis katalogu, ujawnia niedokończony formularz Bestiariusza;
  wcześniejsze szkice walki i notatek nadal wymagają poprawnego zapisu.

## 2026-09-09 — Etap 9, profile bojowe Item

- Użytkownik zlecił Etap 9 po 38884fd. Pakiet 0.10.0, nie finalne v1.0.
- Item jest ogólnym modelem z ośmioma typami i opcjonalnym weaponProfile tylko
  dla weapon. Brak profilu nie tworzy ataku. Zachowujemy zakresy ceny/dostępności,
  wagę, kategorię ekonomiczną, opis, właściwości, źródło i timestamps.
- loadout jest opcjonalnym zestawem w EnemyTemplate i EnemyInstance; zawiera PB,
  modyfikatory SIŁ/ZRC i kopie Item z wybranymi wariantami. To dane osadzone w
  istniejących JSON, nie nowa biblioteka weapons ani UI Ekwipunku. Bez SQL DDL.
- PB jest wpisywane przez MG (nie wyliczamy poziomu/SP). Pola cech są wprost
  modyfikatorami. PB 0–99, modyfikatory −99…99; null/puste = brak danych, nie zero.
- Atak = PB + SIŁ/ZRC według abilityRule + jawne premie profilu/trybu/amunicji.
  Finezyjna wybiera większy z dwóch znanych modyfikatorów. Rodzaj wręcz/dystansowy
  jest etykietą profilu; abilityRule jawnie wybiera cechę (umożliwia np. rzucaną).
- Formuła obrażeń jest pełnym tekstem MG. Nie dodajemy do niej automatycznie cechy,
  nie parsujemy/wykonujemy kości ani nie wyliczamy średniej. Średnia jest opcjonalna.
- Wariant ma id, etykietę, modyfikator ataku, opcjonalne wskazanie damageMode,
  opcjonalny pełny zakres i efekt. Premie do ataku sumują się. Jawna amunicja
  nadpisuje tryb ognia, a tryb bazę dla formuły/zasięgu. N/D = null bez podmiany.
  Brak automatycznej interpretacji nazwy/opisu; brak liczników magazynków/nabojów.
- Podmiana w instancji tworzy nowe Item ID. Edycja lokalnej kopii profilu może
  zachować ID, bez propagacji do szablonu, innych kopii lub przygotowanego stanu.
  Reset odtwarza pełny zestaw i wybory, bez odczytu katalogu lub przeliczenia efektów.
- Zmiana loadout (również wariantu) zapisuje się atomowo z equipment_changed.
  Wybór wariantu nie używa budżetu akcji, nie zmienia HP/statusów i nie rzuca.
- Zachowujemy starsze JSON bez loadout i migracje 001–006. Edytor broni oraz edytor
  Bestiariusza chronią niepełne dane przy normalnym zamknięciu i ⌘Q.

## 2026-09-09 — Etap 10, awarie maszyn

- Zlecono po 01e51f4, wersja 0.11.0. Etap 11 pozostaje poza zakresem.
- Warunek zweryfikowano w lokalnym podręczniku, drukowana s. 214: obrażenia
  pojedynczego ataku przekraczają próg. Tabela maszyn różni się od tabeli pojazdów;
  nie używamy reguły >= z pojazdów. MG ocenia zastosowanie i niepasujący wynik.
- null/puste = brak progu; 0 = jawny próg. Próg nie odnosi się do aktualnych PW.
  Sam spadek PW niczego nie uruchamia; input obrażeń jest opcjonalnym podglądem.
- Każde Zastosuj tworzy osobną aktywną awarię z UUID. Liczbowe kary kumulują się;
  blokady pozostają, dopóki aktywne jest ich źródło. MG może zakończyć każdy wpis.
- Kary −2/−4 do ataku i −2 TT oraz mnożniki ruchu są wyliczane z awarii.
  Nie nadpisują bazowego TT/ruchu/profilu. TT efektywne minimum 0. Najpierw
  odejmujemy Zranienia/Wyczerpanie, potem mnożniki awarii. Wynik 19/20 daje ruch 0.
- 1 oznacza konkretną broń (Item UUID) jako zniszczoną, zachowując jej dane.
  Podmiana na nowy Item nie dziedziczy uszkodzenia starego. 4 wymaga decyzji MG:
  Bonusowe albo Legendarne. Akcje respektują blokady i wcześniejszy wyjątek MG.
- 6 odejmuje 50 PW, minimum 0, oraz przypomina o braku amunicji. Brak licznika.
  20 ustawia 0 PW i znacznik zniszczenia; autodestrukcję rozstrzyga MG. Nie ma
  automatycznych obrażeń innych postaci, wyboru celów, usuwania lub pomijania tury.
- 5/8/11/12 tworzą niezależne systemowe statusy ze źródłem awarii; ID statusu
  jest ID awarii. Naprawa usuwa tylko ten status. Powtórzone Podpalenie nadal
  daje jedno przypomnienie z istniejącego silnika statusów, nigdy automatyczne PW.
- 5/10/12 liczą pozostałe końce własnej tury: 2 jeśli zastosowano w jej trakcie,
  1 poza nią. Zwykłe Next Turn odlicza, korekta tury/prepare/restart nie odliczają.
  10 blokuje tylko Akcje i Bonusowe, bez dodatkowego statusu blokującego Reakcje.
- 7 i 15 są przypomnieniami o liczbie ataków i obrażeniach wręcz. 16 blokuje
  profil wręcz informacyjnie (brak wykonywania ataków). 17/18 są decyzjami MG.
- Naprawa znosi konkretną awarię, nie cofa obrażeń. Zmiana/usunięcie powiązanego
  statusu ręcznie pozostaje możliwą decyzją MG; osobny wpis awarii może zakończyć
  w panelu. Reset przywraca dokładny prepared, w tym aktywne awarie i czas.
- Istniejące JSON mieszczą failureThreshold i machineFailures. Brak nowej tabeli
  i migracji; migracje 001–006 bez zmian. Zod/Rust walidują zgodny kontrakt.
  Stare JSON bez pól pozostają czytelne; nie otwieramy bazy użytkownika w testach.


## Etap 11 — trudność i doprecyzowanie użytkownika

- SD jest sumą ręcznie wpisanych poziomów BG w slocie; lista nie jest związana
  z minimalnymi kartami BG. Dodanie/usunięcie BG nie zmienia poziomów automatycznie.
- SP jest opcjonalną nieujemną liczbą w szablonie i niezależnej instancji, bez
  wyprowadzania z PB/cech. Puste lub stare brakujące pole to brak danych, 0 ważne.
- Wszystkie obecne instancje przeciwników wnoszą SP, także 0 PW/zniszczone.
  To ocena składu spotkania, a nie pozostałej siły w trakcie walki.
- Przy choć jednym brakującym SP pokaż znaną sumę i liczbę braków; SP/ratio/pasek
  nie udają pełnych danych. Przy SD=0 ratio i marker są nieokreślone.
- Użytkownik dodał przedziały między punktami podręcznika: 101–125 Łatwa,
  126–149 Wyczerpująca, 151–175 Wyczerpująca, 176–199 Ryzykowna,
  201–250 Ryzykowna, 251–299 Zabójcza. Punkty 100/150/200/300 zachowują nazwy.
  Definicja ciągła: [0,126) Łatwa, [126,176) Wyczerpująca, [176,251) Ryzykowna,
  [251,+∞) Zabójcza. Dotyczy też ułamków; porównanie bez zaokrąglania procentu.
- Nazwa korzysta z przedziałów; pozycja wskaźnika i gradient pozostają ciągłe,
  bez dodatkowych szczebli widocznych na skali. Wskaźnik 0–300%, dokładny procent
  pokazany również powyżej 300%. Cztery kotwice są orientacyjne (~).
- Poziomy zapisuje dotychczasowy metadata autosave, bez wpisu do logu walki.
  SP instancji zapisuje transakcja walki z logiem sp_changed. Reset nie zmienia
  listy poziomów, ale odtwarza przygotowane SP. Bez zmiany schematu SQL.


## Poprawki Etapu 11 — 0.12.1

- Prezentacja wyników trudności: maksymalnie 2 miejsca po przecinku, bez zmiany
  surowych danych ani progów. Zapisane liczby zachowują pełną precyzję.
- Panel „Karta potyczki — trudność” zwijany; wybór rozwinięcia osobny dla slotów
  podczas sesji, błędne dane odsłaniają panel. Walka pozostaje dostępna.
- Mały pasek i procent/nazwa przy każdym z pięciu slotów, także nieaktywnych.
  Puste SD/brak SP to N/D, niepoprawny szkic „Popraw dane”.
- Aktualne SP korzysta z obramowania i odstępu etykiety jak pozostałe statystyki.
- Bestiariusz i formularz nowego przeciwnika pokazują konkretne pola, numery
  przedmiotów/formuł/akcji oraz przyczynę. Pierwszy błąd odsłania pole i ustawia
  kursor; kliknięcie błędu prowadzi do danej pozycji, także w zwiniętej sekcji.
- Walidacja zachowuje reguły: puste wymagane teksty, liczby, zakresy, koszty
  większe niż pule/zasoby i zasięgi. Błędy nie usuwają szkicu ani nie zapisują
  niepoprawnych danych. Brak migracji i zmian bazy, pięć slotów bez zmian.

## Etap 12 — bezpieczne przygotowanie, reset i czyszczenie (0.13.0)

- Zlecono następny etap po czystym 5bde995. Etap 13 pozostaje niezlecony.
- Clear usuwa obecny skład wraz ze snapshotami/statusami, cały log i notatki.
  Runda 1, brak tury. Zachowuje ID 1–5, nazwę slotu, listę poziomów BG,
  katalog Bestiariusza i inne sloty. Poziomy są niezależną konfiguracją drużyny.
- Clear nie jest odwracalne Resetem. Reset zachowuje skład, nazwę, poziomy,
  notatki i log oraz odtwarza dokładny przygotowany stan obecnych postaci.
- Potwierdzenie zawiera slot/nazwę/liczbę postaci i skutki; zmiana szkicu lub
  rewizji je unieważnia. Przed pełnym Clear opróżniamy obie kolejki autozapisu.
- Dedykowana transakcja Clear sprawdza revision oraz nazwę/notatki/poziomy.
  Ponowienie rozpoznaje już pusty stan przy dokładnie revision+1; nowszy stan
  powoduje konflikt. W czasie niepewnego wyniku edycja/zamykanie są wstrzymane,
  dostępne ponowienie lub odczyt slotu. Inne szkice pozostają nietknięte.
- Compare-and-save metadanych odrzuca nieaktualne okno, zamiast przywracać
  stare notatki. Identyczny retry metadanych rozpoznaje zapisany wynik.
- Rust odrzuca podmianę istniejącego prepared w zwykłym zapisie, częściowy
  reset, zmianę składu przy prepare/reset i niezgodny stan powrotu.
  Kolejność remisów po resecie: prepared rank, następnie UUID, ciągłe indeksy.
- Bez zmiany schematu, migracji 001–006, identyfikatora lub bazy użytkownika.


## Etap 13 — obsługa przy stole (0.14.0)

Skróty Alt/⌥+↑/↓ wybierają karty w kolejności inicjatywy, z postaciami bez wyniku
na końcu, bez zawijania na skraju. Nie zmieniają tury ani danych. Pola edycji,
kompozycja tekstu, dodatkowe modyfikatory, przytrzymanie i otwarty formularz
blokują skrót. „Pokaż bieżącą postać” ustawia fokus na jej karcie.
F1/przycisk otwierają pomoc modalną; Escape zamyka pomoc i nie anuluje formularza.
Spacja zachowuje ochronę kontrolek; także formularz przeciwnika blokuje turę.
Skróty slotów oraz walki nie działają pod modalem pomocy.
Log domyślnie zwinięty przy wejściu do slotu; podsumowanie pokazuje ostatni wpis.
Rozwinięcie nie usuwa/odświeża liczników, zapis logu trwa niezależnie od widoku.
Błąd odczytu odsłania historię i ponowienie. Stan rozwinięcia pozostaje lokalny.
Pasek rundy jest przyklejony podczas przewijania walki, lecz statyczny w oknie
niższym niż 581px. Lewa inicjatywa przyklejona tylko na szerokim/wysokim ekranie.
Nagłówek bardziej zwarty, oprawa papier/turkus/metal zachowana; fokus kontrolek
czytelny. Brak nowej mechaniki, migracji i skrótów usuwających dane.

## Etap 14 — końcowe QA (0.15.0)

Zlecony po czystym 2f38a29. Pełne testy, natywny smoke na odrębnej bazie,
restart i build macOS. Bez zmian mechanik, persistence i migracji 001–006.
Ujednolicone bieżące instrukcje odsyłają do raportu ETAP_14; dawne raporty
pozostają historią. Stopka pokazuje numer pakietu zamiast numeru etapu.

QA ujawniło brak osobnych pól pełnego statblocka wymienionych w PRODUCT_SPEC
(sześć cech, RO, umiejętności, zmysły, odporności, podtyp i Próg Obrażeń).
Dotychczasowy zakres etapów bojowych jest zaimplementowany, lecz ten punkt
pozostawał otwarty przed pełnym v1.0; został uzupełniony w Etapie 16. Pakiet 0.15.0 oznacza punkt kontrolny QA,
nie pełne v1.0. Braków nie przenosimy automatycznie do Ekwipunku v1.1.
Nie dodano nowych mechanik ani UI statblocka w końcowym QA.
v1.1 Ekwipunek i v1.2 Wiedza MG wymagają nowego zlecenia.

## Plan po Etapie 14 — historyczne ustalenia MG

Historyczny plan; kolejność karty/Windows zastąpiona decyzją z 2026-09-12 poniżej. Etapy 15–25 są planem do osobnych zleceń; bieżące zadanie zmienia tylko docs.

- Ekran główny wcześnie: Panel MG i zapowiedź karty BG. Wszystkie inne moduły w Panelu MG.
- Kolejność: ekran → statblocki → Bestiariusz maszyny/potwory/ludzie → Ekwipunek
  → Wiedza MG → roller → pełne QA macOS → port Windows → pełna karta BG.
- Bestiariusz z używanego podręcznika: trzy odrębne wdrożenia i odbiory danych.
- Wiedza MG obejmuje zawartość tabelarycznego Excela, ze strukturą tabel.
- Roller prosty, jawny, bez 3D i automatycznego odejmowania PW/rozliczania trafień.
  Ręczne sterowanie PW i dotychczasowe jawne awarie 6/20 pozostają. Nie zmieniamy
  ich przy okazji wykluczenia nowej automatyzacji obrażeń.
- Bibliotekę potyczek ponad pięć wykreślamy, także jako późniejszy backlog.
- Amunicja tylko karta BG: magazynek, zapas, przeładowanie, zużycie, masa,
  jawny alarm „Pusty magazynek — przeładuj”. Bez liczenia amunicji NPC.
- Karta odzwierciedla pełne reguły gry, przelicza cechy/wartości/wagę/amunicję.
  Krótki i długi odpoczynek odnawia zasoby klasowe według indywidualnych reguł.
  Jest ostatnim modułem i od początku podlega odbiorowi na macOS oraz Windows.
- Trwała karta nie jest własnością potyczki. Reset/clear nie może kasować karty
  lub cofać rozwoju/inwentarza. Kontrakt synchronizacji ustalić przed implementacją.
- Jednorazowe przygotowanie danych Ekwipunku/Wiedzy z Excela, bez runtime sync/reimportu.
  Reguły rynku, w tym N/D i Stal, pozostają zgodne z DATA_MODEL.
- Prywatne źródła pozostają poza Gitem/bundlem. Zlecony Bestiariusz pozwala opracować
  strukturalne dane statystyczne i potrzebne opisy; nie dołączać całego podręcznika.
- Backup GUI i import/eksport pozostają do decyzji przed zamknięciem zakresu macOS.

Szczegółowe briefy i kryteria: PLAN_DALSZYCH_PRAC.md; kolejność: ROADMAP.md.
Dla tej zmiany dokumentacyjnej: kontrola spójności, linków, formatowania i diff,
bez nowego numeru wersji, migracji, kompilacji i podmiany aplikacji.

## Etap 15 — ekran startowy (0.16.0)

MG zlecił Etapy 15 i 16 kolejno z raportem pomiędzy. Nawigacja home/gm/character jest sesyjna, niezależna od danych walki. Ukryty panel pozostaje zamontowany; jego skróty są blokowane. Globalna ochrona zamykania pokazuje problematyczny moduł i slot. Karta BG pozostaje zapowiedzią.

## Etap 16 — statblocki (0.17.0)

Zlecony bezpośrednio po raporcie 15. Pełne pola są przypomnieniem i danymi MG, nie automatycznym rozstrzyganiem. Wyliczony modyfikator cechy nie zmienia wpisanych końcowych RO/umiejętności ani jawnych danych ataku. Progi Obrażeń i Awarii odrębne. Null odróżniamy od zera i jawnej pustej listy. Bez DDL, importera i seeda. Pięć jawnych opcji wyboru potyczki usuwa zależność tej kontrolki od natywnego rozwijanego menu. Obserwacje QA menu nie dowiodły błędu zapisu do niewłaściwego slotu; finalny wybór i Add ×N wymagają testu natywnego i odczytu osobnej bazy.

## Etap 17 — ostateczne doprecyzowanie MG

Użytkownik zlecił Etap 17, następnie zażądał dokładnie 11 wpisów. Na przykładzie
Mobsprzętu doprecyzował: statblock jak w podręczniku, wszystkie losowane bronie
jako lista oraz adnotacja o losowaniu jednej przez 1k6. Przyjęto tę interpretację:
bez rozbijania katalogu i bez obowiązkowego wyboru konfiguracji w aplikacji.
Ogólne opisy pasywów i Items bez profilu Testu Ataku uzupełniają model tak,
aby zachować warunki/alternatywy pełnych statblocków. Dalsze partie sprawdzają
własne brakujące mechaniki przy odrębnym zleceniu; nie importowano ich w Etapie 17.

Źródło: prywatny PDF NOE_dla_dominadiinteriapl.pdf, Notatnik Łowcy s. 214–225,
pomocniczo s. 204–205. Statblock ma pierwszeństwo przed przykładem: Biodroid SP20
oraz inicjatywa +3 (12) zachowane. Podane średnie/formuły nie są przeliczane.
Pająk/Łowca/Kurczak nie mają podanego Progu Awarii: N/D. Rozbieżność ogólnego opisu
progu na s. 205 z regułą maszyn na s. 214 nie zmienia przyjętego Etapu 10:
obrażenia > próg, zastosowanie awarii wybiera MG. Pełny PDF i ilustracje prywatne.
Korekty seeda wyłącznie nietkniętych wpisów, edycje/usunięcia/kopie chronione.

## Etap 18 — korekta kategorii i dane potworów

MG doprecyzował pięć kategorii: Ludzie, Maszyny, Mutanci, Potwory, Zwierzęta.
Ta decyzja zastępuje wcześniejsze mapowanie potworów na beast/other. Dawne
wartości pozostają tylko dla zgodności, bez automatycznego przypisania własnych wpisów.
Etap 18: dział Potwory s.232–242, 12 statblocków i Zombie jako nakładka.
Techmorwy mają dwa osobne statblocki, więc dwa wpisy; losowane pod-ataki
Szczękowija pozostają w jednym wpisie. Mutanci i Zwierzęta: osobne planowane partie.
Zombie tworzy szkic nowego szablonu z wybranego człowieka/mutanta. Bez fikcyjnego
PW ani ujemnego bazowego TT, bez zmiany nosiciela. MG wybiera odziedziczone
zdolności wręcz, sprawdza RO/umiejętności po zmianie INT/CHA i zatwierdza formularz.
Brakujące PB/SIŁ/SP pozostają N/D; TT<0 po korekcie blokuje zapis, bez cichego clamp.
Legendarna odporność Megatora nie zużywa Reakcji: ręczny licznik 3/dzień.
Zionięcie 2/walkę ma osobny przycisk z kosztem; Owipozycja zużywa limit 10 jaj/dzień.

## Etap 18A — dane mutantów

Zlecenie kolejnego etapu po 0.19.3 realizuje 18A zgodnie z kolejnością planu.
Siedem statblocków z s. 226–231 (PDF 228–233); nowa partia noe-mutants v1.
Bez rozbijania generacji na dodatkowe warianty i bez automatycznego dodawania watahy.
Gadolud ma odporności wymienione w lewej kolumnie s. 227; Wilkolud ich nie dziedziczy.
Końcowe TT Techmutasa 16 i Mesmeryty 19 uwzględniają INT. Końcowe RO Mesmeryty:
CHA +10, ZRC +8. Zachowane źródłowe PW Szpiega 38 (6k8 + 14) i inicjatywa
Wilkoluda -3 (7), bez samodzielnej korekty podręcznika. Tylko Gadolud, Wilkolud,
Grubas i Mesmeryta mają tor Zranień wskazany w statblocku.
Łańcuch Grubasa: atak +9 i skutki opisowo, bez wymyślonej formuły obrażeń.
Dmuchawka Szpiega ma stałe 4 obrażenia; zapis „4” nie uruchamia rzutu.
Zdolności z RO i bez Testu Ataku nie dostają fikcyjnego weaponProfile.
Mesmeryta: Posiłki 2/dzień, osobna Reakcja i 3 akcje legendarne/rundę.
W Ataku wielokrotnym MG rozlicza pod-ataki i ręcznie odejmuje użyte Posiłki;
bez automatycznej zmiany składu, losowania czasu, PW i statusów.
Dotychczasowe partie v1, instancje i snapshoty pozostają niezmienione.

## Etap 18B — zwierzęta (0.21.0)

Zlecenie następnego etapu po 340edb5 (0.20.0) realizuje partię 18B zwierząt.
Źródło przejrzano tekstowo i wizualnie, także kolumny stron PDF 246, 247, 251.
Dokładnie 12 statblocków; bez mnożenia wariantów roju/skakuna. Zachowujemy
źródłowe średnie PW/obrażeń i inicjatywę mimo niespójności matematycznych.
Rój ma nielimitowane reakcje przez jawną właściwość modelu, nie przez wyjątek MG.
Źródło nie określa obrażeń przy 50% PW i jednocześnie podaje odporność na
Przerażenie oraz strach przed ogniem. Obie uwagi widoczne; rozstrzyga MG.
Obrony pajęczyny nie stają się obronami pająka. Akcje automatycznych obrażeń
pozostają opisowe, bez wymyślonego Testu Ataku. Ludzie i późniejsze etapy niezlecone.

## Poprawki czytelności — 0.21.1

Zlecono wyłącznie korekty tekstów i widoków, bez Etapu 19. „Chód” w interfejsie
zastępuje „Szybkość”; prezentacja ruchu zawiera m. SP podręcznikowej kopii z
podaną wartością jest nieedytowalne w karcie walki; ręczne tworzenie i własne
wpisy zachowują pole. Wartości, liczenie trudności i dane pozostają niezmienione.
Usunięto wskazane dopiski administracyjne i dekoracyjny licznik slotów,
skrócono nagłówki. Pancerz: TT z wartością i opisem w nawiasie.
Wspólna prezentacja działa także na starych snapshotach; seed i SQL nietknięte.
Raport/kryteria odbioru: CZYTELNOSC_0.21.1.md. Następny etap wymaga zlecenia.

## Etap 19 — ludzie (0.22.0)

Zlecony po poprawkach 0.21.1. Dziewięć statblocków z s. 207–213 (PDF 209–215):
Cyngiel, Cywil, Gangus żołnierz, Gangus kapo, Gangus boss, Konwojent (strażnik),
Kanibal, Szeryf i Żołnierz Posterunku. Katalog startowy: 51 szablonów + nakładka Zombie.
Wariant farmera pozostaje bronią Cywila. Ofiara jest Reakcją; dodatkowy nóż Cyngla
Akcją Bonusową. Trzy długie serie mają osobne limity 2/walkę i są opisane przez RO,
bez fikcyjnego Testu Ataku. Przedmioty noszone są opisem, bez liczenia amunicji.
Nie sumować ponownie premii Kuloodpornego i Brutalnego ciosu; wartości końcowe
pozostają źródłowe. Warunkowe premie, przywołania, rzuty i obrażenia nie są automatyczne.
Nowa partia noe-humans v1, bez zmiany kontraktów ani migracji 001–008. Starsze partie,
edycje/usunięcia MG, instancje i snapshoty zachowane. Obowiązują poprawki czytelności 0.21.1.
Historyczny raport: ETAP_19.md. Etap 20 wdrożono następnie w 0.23.0.

## Etap 20 — Ekwipunek (0.23.0)

Wdrożono katalog 299 pozycji z tabelarycznego Excela: wszystkie osiem typów Item,
wyszukiwanie nazw/opisów/właściwości, filtry typu i kategorii, waga oraz zakresy
ceny i dostępności. Panel MG → Ekwipunek. Jedenaście regionów, cztery lokalizacje
i pięć Kolorów; niezależne N/D, domyślnie none/none/none. Stal modyfikuje tylko
Item.type weapon/ammunition, także gdy brak weaponProfile.

Katalog w tym etapie służy do przeglądania i obliczeń handlu. Nie zmienia
przedmiotów osadzonych w Bestiariuszu, walce ani przygotowanych kopiach.
Warunki handlu i filtry zachowują się w sesji przy przełączaniu modułów;
nowe uruchomienie zaczyna od wartości bazowych. Brak edytora katalogu,
liczenia inwentarza/amunicji, rollera, importu/synchronizacji Excela i UI Wiedzy MG.
Wagi zakresowe/przybliżone pozostają tekstem, brak danych = N/D, nigdy zero.

Migracja 009 dodaje items i equipment_seed_batches; migracje 001–008 pozostają
niezmienione. Jednorazowy, transakcyjny seed po migracjach i przed udostępnieniem
repozytoriów. Ponowny start nie nadpisuje wpisów ani nie odtwarza usunięć.
Raport: ETAP_20.md. Następny etap: 21 — Wiedza MG; tylko po nowym zleceniu.

## Etap 21 — Wiedza MG (0.24.0)

Panel MG → Wiedza MG: 50 wpisów, działy, wyszukiwanie po treści, tabelach i
nagłówkach (także bez polskich znaków), pasujące wiersze z zachowaniem kontekstu.
47 tabel/opisów z 13 arkuszy oraz trzy tabele MODYFIKATORÓW wyprowadzane z
istniejących reguł Ekwipunku. Spis zakresów: WIEDZA_MG_ZRODLA.md.
Długie opisy mają rozwijane akapity; nagłówki, jednostki, uwagi oraz odsyłacze
do arkusza/komórek pozostają dostępne. Na węższym panelu wiersze przechodzą
w karty z etykietami kolumn. Link do Ekwipunku prowadzi do przeliczania cen.

KnowledgeEntry zawiera strukturalne blocks: table (columns/rows/cells) i text;
ReferenceEntry to alias tego modelu. Wpisy są zwalidowane przez Zod i dostarczane
z aplikacją jako niezmienny katalog tylko do odczytu, bez nowej tabeli SQL.
Stan wyszukiwania/działu/wyboru trwa w sesji; nie zmienia potyczek ani ich bazy.
Migracje 001–009, identyfikator aplikacji, Bestiariusz, Item i TradeContext bez zmian.
Kolory i mnożniki handlu mają jedno źródło prawdy współdzielone z Ekwipunkiem.

Nie dodano kalkulatora, rollera, automatycznych efektów, liczników amunicji,
edycji wiedzy ani importu/synchronizacji Excela. Opisy rzutów i „Rzuć dwa razy”
są treścią tabel źródłowych; niczego nie uruchamiają. Raport: ETAP_21.md.
Następny etap: 22 — prosty roller, wyłącznie po osobnym zleceniu.

## Etap 22 — roller i strony podręcznika (0.25.0)

Zlecony po Etapie 21 (`c41dece`). Rozwijany panel Kości w prawym dolnym rogu:
k4/k6/k8/k10/k12/k20/k100, 1–100 kości, modyfikator ±10000 i pełne formuły
NkS±N (także d). Pokazuje każdą kość, sumę i 100 ostatnich wyników po restarcie.
Kliknięcie ataku, obsługiwanej formuły obrażeń, cechy, RO lub umiejętności
z jawną premią rzuca z kontekstem postaci i zapisuje wynik w logu jej potyczki.
Atak korzysta z bieżącego profilu; cecha z jej modyfikatora, RO/skill z podanej
premii końcowej. Liczbowa kara Wyczerpania dotyczy testów, nie obrażeń/awarii.
Pozostałe warunki i ułatwienia/utrudnienia ocenia MG. Nieobsługiwane, złożone
lub opisowe formuły pozostają tekstem; brak częściowego zgadywania rzutu.
Rzuć awarię k20 wypełnia istniejący formularz. Ręczne wpisanie i zmiana wyniku
pozostają dostępne. Tylko osobne „Zastosuj awarię” zmienia stan maszyny.
Rzuty nie zmieniają PW, zasobów, amunicji, tur, statusów ani wyboru celów.
Ponowienie z historii jest nowym rzutem samej formuły bez starej postaci/rundy.

Migracja 010 dodaje wyłącznie tabelę dice_rolls. 001–009 pozostają nietknięte.
Historia i opcjonalny wpis dice_rolled powstają w jednej transakcji; stabilne
UUID umożliwia ponowienie zapisu bez losowania i duplikowania. Nie zmieniamy
rewizji ani snapshotów walki. Zamknięcie czeka na zapis; błąd ujawnia panel
z zachowanym wynikiem. Skróty walki są zablokowane przy otwartym panelu kości.

Wiedza MG pokazuje tytuł „Neuroshima: Ostatnia Era” i drukowane strony zamiast
arkusza/komórek. 50 przypisań udokumentowano w WIEDZA_MG_STRONY.md. Treść tabel
pozostaje adaptacją Excela; samo dodanie odsyłaczy nie koryguje różnic mechaniki.
Surowe źródła pozostają poza repo/bundle; brak synchronizacji/reimportu.
Raport: ETAP_22.md. Następny Etap 23 — odbiór Panelu MG na macOS — wymaga zlecenia.


## Poprawki kart walki — 0.25.1

Zlecone po Etapie 22 (2cd2926), dla wszystkich przeciwników, także istniejących
instancji i wpisów MG. Bieżące cechy/RO, obrona i zmysły są stale widoczne przed
„Parametry i notatki postaci”. Opisy zdolności, reguł i broni mają klikalne jawne
premie ataku i formuły kości, także mieszane np. 2k8+2k6+4. ST/RO celu pozostaje
opisem; nie przypisuj rzutu obronnego do atakującego. Rzut nie zużywa zdolności
ani nie zmienia PW/zasobów; log zachowuje nazwę zdolności i postaci. Tekstowa
premia ataku uwzględnia liczbowe kary awarii i Wyczerpania bez doliczania PB.
Własne opisy korzystają z tej samej obsługi jawnych zapisów. Nieznanych wartości
nie zgadujemy. W historii opcjonalne groups opisuje mieszane kości; stare wpisy
bez groups nadal działają. Bez migracji i bez zmian seedów/snapshotów.
Raport: POPRAWKI_0.25.1.md. Etap 23 nadal wymaga osobnego zlecenia.


## Kolory naturalnych rzutów k20 — 0.25.2

Naturalne 20 ma kolor zielony, naturalna 1 czerwony. Decyduje wartość kości,
nie suma z modyfikatorem: 20−19=1 pozostaje zielone, 1+19=20 czerwone.
Dotyczy wyniku rollera, historii i logu walki, również poprzednich zapisów.
Przy wielu kościach wyróżniane są poszczególne k20; wspólna suma pozostaje
neutralna. Inne rodzaje kości nie otrzymują wyróżnienia naturalnej 20/1.
To wyłącznie prezentacja, bez rozstrzygania trafień/efektów i bez migracji.
Raport: POPRAWKI_0.25.2.md. Etap 23 nadal wymaga osobnego zlecenia.


## Jednorazowy krytyk — uzupełnienie 0.25.2

Naturalne 20 w pojedynczym k20 ataku przygotowuje podwojenie kości kolejnego
rzutu obrażeń tej samej postaci i broni/zdolności. Np. 2k6+3 → 4k6+3, także
mieszane grupy; premie stałe pozostają bez zmian. Opis zdolności i profil tej
samej broni współdzielą powiązanie po ID przedmiotu. Cechy, RO, awarie i ogólny
roller nie przygotowują krytyka. Kolejny test ataku tej broni zastępuje poprzedni.
Inna postać/broń nie zużywa krytyka. Pierwszy zapisany rzut obrażeń zużywa go;
retry zapisuje identyczny wynik i nie zużywa go ponownie. Historia SQLite jest
źródłem stanu, więc wznowienie aplikacji zachowuje gotowy krytyk. Opcjonalne
purpose/sourceKey w kontekście i critical w zapisie rzutu; bez migracji SQL.
To nie rozstrzyga trafienia, celu ani PW. Raport POPRAWKI_0.25.2.md.

## Zmiana kolejności — karta BG przed Windows (2026-09-12)

Użytkownik zdecydował: najpierw pełna karta BG, następnie Windows, gdy całość
będzie opracowana. Ta decyzja zastępuje wcześniejszą kolejność Windows → karta BG.

- Etap 23: odbiór Panelu MG na macOS, bez zmiany zakresu.
- Etap 24, podetapy 24A–24E (dawne 25A–25E): pełna karta BG na macOS, wszystkie
  mechaniki i obliczenia, inwentarz/waga/amunicja, zasoby/odpoczynki, integracja
  z potyczkami i rollerem oraz odbiór macOS.
- Etap 25 (dawny 24): port kompletnej aplikacji, także karty BG, na Windows;
  odbiór rzeczywistego Windows i regresja macOS. Brak Windows nie blokuje Etapu 24.
- Przenośność kodu obowiązuje podczas tworzenia karty. Zakres mechanik, pięć
  slotów, brak automatycznego odejmowania PW i brak animacji 3D pozostają bez zmian.
- Zlecono zmianę planu; nie rozpoczęto implementacji Etapów 23–25.
  Wersja pozostaje 0.25.2, bez migracji, buildu i podmiany aplikacji.

## Zgłoszenie inicjatywy przeciwników (2026-09-12; wdrożone w 0.25.3)

MG zlecił dopisanie do listy prac: klikalna inicjatywa przeciwnika rzuca kośćmi
i zapisuje końcowy wynik jako inicjatywę tej instancji w danej potyczce,
z aktualizacją kolejności. Ręczne wpisywanie pozostaje. Do wykonania przed
odbiorem Panelu MG; szczegóły i kryteria w PLAN_DALSZYCH_PRAC.md.
Późniejsze zlecenie MG uruchomiło implementację; wykonano w 0.25.3, zgodnie z opisem poniżej.

## Wzorzec karty BG — decyzja MG 2026-09-12

Przy projektowaniu Etapu 24 zachować strukturę czterostronicowej karty
`reference/karta-postaci-Neuro-2025-NEW-8-Interactive (1).pdf`: grupy, nazwy
i hierarchię pól, z responsywnym układem i interaktywnymi obliczeniami.
Mapa stron, wymagania i ocena pomocniczego arkusza Google: [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md).
Oryginał PDF pozostaje tylko do odczytu i poza dystrybucją. Zlecono ustalenie
wzorca przyszłych prac, bez rozpoczynania implementacji karty.


## Wyszukiwarka przeciwników i rzut inicjatywy — 0.25.3

„Dodaj przeciwnika” otwiera wyszukiwarkę Bestiariusza w bieżącej potyczce.
Nazwa (także bez polskich znaków) i kategoria zawężają wyniki; „Dodaj” tworzy
jedną niezależną instancję i zamyka okno. „Dodaj własnego” otwiera dotychczasowy
formularz ręczny. Escape anuluje wybór, bez zmiany składu.

Przycisk inicjatywy przy statblocku i ręcznym polu wyniku rzuca 1k20 z jawną
premią „Inicjatywa: ±N” (również dawny zapis „z podręcznika”). Liczba w nawiasie
nie jest premią. Gdy brak tej pozycji, używany jest modyfikator Zręczności;
nieznana lub sprzeczna premia wymaga ręcznego wyniku. Odejmowana jest liczbowa
kara Wyczerpania. MG nadal ocenia pozostałe warunki testu.

Wynik, historia kości, log i rewizja potyczki zapisują się w jednej transakcji.
Kolejność inicjatywy aktualizuje się bez zmiany rundy, bieżącej tury, remisów,
PW, zasobów ani przygotowanych snapshotów. Inicjatywa nie przygotowuje krytyka.
Przed rzutem kończy się autozapis; podczas zapisu edycja i zamknięcie czekają.
Błąd zachowuje dokładny wynik do ponowienia, bez kolejnego losowania. Odczyt
aktualnego stanu pozwala rozstrzygnąć niepewny zapis lub porzucić niezapisany rzut.
Ręczny wpis pozostaje dostępny. Brak migracji; 001–010 pozostają niezmienione.
Raport: POPRAWKI_0.25.3.md. Etap 23 nadal wymaga osobnego zlecenia.


## Korekta miejsca inicjatywy i źródeł Ekwipunku — 0.25.4

Zlecenie MG po 0.25.3: interaktywny jest wyłącznie istniejący wpis
„Inicjatywa: …” w „Zdolnościach stałych i zasadach” karty przeciwnika.
Usunięto dodatkowe przyciski z pola wyniku i nagłówka statblocku. Pole wyniku
ma zwykłą etykietę i ręczną edycję; cztery pola oraz przyciski „Dodaj przeciwnika”
i „Dodaj własnego” są wyrównane. Atomowy zapis inicjatywy z 0.25.3 pozostaje.
Nie dodawaj drugiego wpisu inicjatywy ani nowego przycisku poza istniejącą zasadą.

Źródła wszystkich 299 pozycji Ekwipunku pokazują „Neuroshima: Ostatnia Era”,
drukowane strony oraz właściwą tabelę/sekcję. Granaty i miny wskazują swoje
opisy, gdy książka nie zawiera tabeli. Mapa: EKWIPUNEK_STRONY.md i
src/data/equipment/handbook-sources.v1.json. Powiązanie po ID i oryginalnym
źródle seedu działa także na istniejącej bazie. Własnych źródeł MG nie nadpisujemy.
Bez zmiany danych mechanicznych, seedu, migracji lub reimportu. Raport
POPRAWKI_0.25.4.md. Etap 23 nadal wymaga nowego zlecenia.

## Etap 23 — odbiór Panelu MG na macOS (0.26.0)

Etap 23 zlecony przez MG 2026-09-13, punkt wyjścia `c32c607` (0.25.4).
Raport odbioru: `docs/ETAP_23.md`. Zachowane wszystkie funkcje Etapów 0–22,
18A/18B i korekt 0.25.1–0.25.4. Poprawiono obsługę F1 i powrót fokusu z wyszukiwarki.
Na dodatkowe zlecenie MG poprawiono dwie reguły Wiedzy MG według podręcznika:
zniszczenie hełmu przy Krytycznej ochronie (s. 115) i Szybkość celu równa 0
we właściwości Długa (s. 118). Oryginalny zapis Excela pozostaje materiałem audytowym.
Bez nowych migracji i zmian bazy użytkownika. Następny Etap 24A — karta BG —
wymaga nowego zlecenia; Windows pozostaje na końcu (25).
Import/eksport kampanii i backup z GUI odroczone poza zakres tego odbioru.
Nie są warunkiem odbioru wcześniej zleconych funkcji Panelu MG.

## 2026-09-20 — doprecyzowania Etapu24D

- Pancerz: połowa maksymalnej, nie wydanej puli KW; każda wielkość kości osobno,
  zaokrąglenie w dół, odzysk ograniczony do wydanych kości.
- Przerwany długi: korzyści krótkiego po czasie właściwym dla bieżącego Koloru.
- Rtęć: zakaz obejmuje wszystkie źródła Fuksów, również start i Muzyka.
- Fabrykator: czas produkcji pomniejszony o50%, np.6h→3h. Nie interpretować
  jako tempa×1,5. Pozostałe wcześniejsze decyzje pozostają ważne.
- Zdrowie i postój wymagają jawnego podglądu/zatwierdzenia. Upływ czasu gry
  może wygaszać terminowe efekty, ale nie wykonuje odpoczynku ani nie zużywa
  sam leków, jedzenia lub amunicji.


## Doprecyzowanie MG — Etap 24D, 2026-09-20

Początkową chorobę wybiera się bezpośrednio z listy albo wybiera „Nie wybieram — −1 do cechy”. Bez formularza wyników k8; analogicznie wybór fobii. Jednorazowość premii/kary i dawek pozostaje. Leki bez masy w podręczniku mają 0 kg także na istniejących kartach; jawnej masy MG nie nadpisujemy. Fabrykator: czas −50% (6 h → 3 h).

## 2026-09-20 — układ UI 0.29.4

Makieta wyznacza strukturę, nie nową paletę: pozostają papier, rdzawy akcent i turkus. Boczne menu BG i sloty potyczek przechodzą nad treść na mniejszych oknach. Widoki i formularze zachowują stan oraz dotychczasową walidację. Bez zmian mechaniki i migracji.


## 2026-11-05 — zatwierdzanie rozwoju i bieżąca TT

Decyzja użytkownika: usunąć dialog „Korekta wcześniejszego rozwoju” wraz
z wymaganym powodem. Zwykłe „Zatwierdź kartę” obsługuje również korekty
wcześniejszych cech, pochodzenia i wyborów. Pozostają walidacja, zapis
pełnego szkicu, historia operacji, idempotencja i blokady aktywnej walki.
Opcjonalne pole powodu zachowujemy do odczytu starszych operacji; bez migracji.

Kafelek Obrona pokazuje jedną aktualną TT (np. 13 zamiast 11 / 13), z założonym
pancerzem i działającymi modyfikatorami. Korzysta z obliczeń udziału BG w walce.
Podsumowanie nadal wyjaśnia warianty i źródła obrony.


Uzupełnienie decyzji z 2026-11-05: PD i awans nie wymagają uzasadnienia;
usunięto pole powodu PD, zachowując dawne opisy w danych i historii.
Usunięto edytor „Korekty MG” z karty. Historyczne modyfikatory pozostają
zachowane i uwzględniane w obliczeniach. Kończenie choroby/fobii pozostaje
czynnością zdrowia, bez nazwy „korekta MG”. Nie usuwać dawnych zapisów z bazy.


## 2026-11-05 — szkic karty a aktywny udział w potyczce

Zapis szkicu jest dozwolony podczas walki. Zatwierdzenie rozwoju i archiwizacja
pozostają zablokowane do zakończenia aktywnego udziału. Odrzucenie tych operacji
z tego powodu nie może pozostawić operacji oczekującej ani zablokować zakończenia
udziału. Tylko dokładnie rozpoznane odrzucenie przed transakcją zwalnia kolejkę;
nieznane błędy i utrata odpowiedzi zachowują dotychczasową idempotencję/retry.
Z karty ze szkicem można przejść do właściwego slotu i uczestnika. Zakończenie
udziału dopuszcza szkic, wymaga wcześniejszego rozliczenia efektów i nie wymaga
usunięcia postaci z potyczki. Nie kończyć walki ani nie usuwać efektów automatycznie.
Bez migracji i zmiany reguł mechanicznych.

Reset i czyszczenie slotu również nie mogą blokować zakończenia udziału po
odrzuceniu przez ten sam warunek. Sprawdzaj go przed lokalnymi zmianami, a przy
nieaktualnym cache obsłuż dokładne odrzucenie backendu. Cofnięcie resetu musi
zachować późniejsze edycje i nie może przepuścić resetowanych wartości jako
zwykłego autosave. Nie zwalniaj blokad po nierozpoznanym błędzie sieci/zapisu.

## 2026-11-09 — osiem poprawek przed przekazaniem Windows

Budżet27 i zakres8–15 dotyczą zakupu Cech przed premiami (s.48–50);
wynik na starcie może osiągnąć18. Karta pokazuje ostrzeżenia i postęp PD.
Sprzęt startowy lub gamble są wyborem według pierwszej klasy, z obowiązkowym
plecakiem/narzędziami/instrumentem. Wydatki z gambli rozlicza gracz.
Magazynki nazywamy Magazynek(BPK/BPP/BPD/BPC), zachowując ID i własne nazwy.
Postój ma kafelki i trwały tracker treningu. Skutki Zranień i Wyczerpania
pokazujemy jawnie; Wyczerpanie można zwiększyć i zmniejszyć ręcznie.
Notatki, znajomi i pierwsze spotkania są edytowalne bez szkicu rozwoju,
także podczas udziału w walce. Oddzielny journal nie przyznaje PD.
Zakres i sprawdzenie: [raport](POPRAWKI_8_2026-11-09.md).
