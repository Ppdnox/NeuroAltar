# Numerowane miejsca ekwipunku — 2026-11-05

Zmiana aktualnego 24E Roboczego na bazie `e9c2469`, na zlecenie MG.

## Obsługa

W edytorze przedmiotu jeden wybór „Miejsce w ekwipunku” zastępuje osobne
pola miejsca i rąk. Dostępne są Plecak, Juki / przechowywane i sloty
odpowiednie do profilu przedmiotu:

- Broń biała 1–4.
- Broń dystansowa 1–3.
- Przedmiot podręczny 1–3.
- Dotychczasowe miejsca pancerza, hełmu i ochraniaczy; tarcza ma własną pozycję.

Zajęty slot pokazuje nazwę zajmującego go przedmiotu i nie może zostać
wybrany przez drugi. Broń biała pozostaje w swojej grupie również wtedy,
gdy ma właściwość rzucana. Broń miotana, łuki/kusze i broń palna mają
miejsca dystansowe. Granat i zapasowy magazynek mogą być podręczne.
Własna broń bez określonego typu wymaga uzupełnienia profilu przed wyborem slotu.

Lista rozdziela broń białą, dystansową, przedmioty podręczne, pancerze,
plecak i juki. Przy nazwie widać numer slotu. Zainstalowany magazynek
pozostaje przy swojej broni i nie zajmuje dodatkowego slotu podręcznego.
Wymiana magazynka ze slotu podręcznego przekazuje ten slot magazynkowi
wyjętemu; nie zmienia liczby naboi.

## Mechanika i zgodność

Podstawa: karta źródłowa, strona 1; Neuroshima: Ostatnia Era, drukowane
s. 53–54 (miejsca), s. 117–119 (chwyt i właściwości broni).

Slot określa przygotowanie i przechowywanie broni, nie jej jednoczesne
trzymanie w dłoniach. Z nowego slotu działają ataki, strzały i odejmowanie
amunicji; plecak i juki wymagają wcześniejszego przypisania broni do slotu.
Wariant obrażeń broni oburęcznej wybiera się przy broni. Przy strzale
można wybrać chwyt jedną lub dwiema rękami, z zachowaniem Utrudnienia,
Poręcznej i wyjątków zdolności. Broń wymagająca dwóch rąk korzysta z nich.

Samuraj/Siekierezada (TT) i Rzeźnik wymagają rzeczywistej sytuacji w dłoniach.
Nowe miejsca nie naliczają tych warunkowych premii z samego posiadania
kilku przygotowanych broni. Obowiązuje wcześniejsza decyzja MG: premie
sytuacyjne rozlicza gracz. Dawne snapshoty rąk zachowują swój odczyt
mechaniczny, dopóki gracz nie zapisze ich w nowym miejscu.

## Zapis i kompatybilność

Bez migracji SQL i bez przebudowy bazy. Schemat JSON przyjmuje nowe sloty
oraz opcjonalny chwyt; dawne sloty rąk nadal są odczytywane. Ich widoczny
numer wyznaczany jest bez zapisu do bazy. Dopiero zatwierdzona edycja
przedmiotu zapisuje nowe miejsce, zachowując ID, magazynek, naboje, masę
i wcześniejszy chwyt. Historyczne operacje i idempotencja pozostają.

Po zapisaniu nowych miejsc nie należy uruchamiać starszego buildu,
który nie zna tych wartości schematu JSON.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i **510/510 testów** (72 pliki) — PASS.
- `cargo test --release --lib`: **99/99 testów** — PASS.
- Regresje: stare snapshoty i historia, limity/typy/zajęte sloty, brak zapisu
  przy odczycie, chwyt broni dwuręcznej, strzały i atomowa wymiana magazynka.
- Native QA w oknie 760×850: zapis AR do Broń Dystansowa 2, dodanie maczety
  z katalogu do Broń Biała 4, przeniesienie przedmiotu do Przedmiot Podręczny 2,
  strzał zmieniający magazynek 1/30 → 0/30, zamknięcie i ponowne otwarcie
  z zachowanymi miejscami i amunicją — PASS. Wyłącznie osobna baza QA.
- `pnpm build` i finalny Tauri `.app` 24E Roboczy — PASS; podpis ad-hoc
  sprawdzony `codesign --verify --deep --strict` — PASS.
- Właściwy 24E Roboczy: Johny Test otwiera się z dawnym M14 widocznym
  jako Broń Dystansowa 1; magazynek pozostaje 18/20. Otworzenie i anulowanie
  edytora nie zmienia rewizji 53 ani danych.
- Porównanie całej bazy użytkownika przed/po: wszystkie **15 tabel bez zmian**,
  `PRAGMA integrity_check = ok`. Kopie bezpieczeństwa aplikacji i bazy zachowane
  lokalnie poza repozytorium.
- Bez nowej migracji SQL. Zmiana nie stanowi pełnego odbioru sesyjnego 24E.

Pozostały wcześniejsze ostrzeżenia Vite dotyczące mieszanych importów i rozmiaru
pakietu. Build nadal jest podpisany ad-hoc, bez notaryzacji Apple.
