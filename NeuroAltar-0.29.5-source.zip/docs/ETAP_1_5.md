# Etap 1.5 — architektura NeuroAltar

Data: 2026-09-07. Repozytorium: `/Users/dominik/Desktop/Combat Tracker`.

## Punkt wyjścia

Przed edycją gałąź `main` miała czyste drzewo robocze i commit `148c4a9`
(`Implement stage 1 persistent encounter tabs and autosave`). Etap 1 był już
zapisany, więc dodatkowy commit checkpoint nie był potrzebny. Zachowano całą historię.

## Wykonane zmiany

- Ujednolicono pozostałą dokumentację pod nazwą NeuroAltar i celem warsztatu MG.
  Tytuł okna, nazwa w UI, HTML i metadata Tauri były już poprawne. Opis Cargo
  zmieniono z combat tracker na GM workspace; bez zmiany nazw technicznych i wersji 0.2.0.
- Przyjęto moduły Walka, Potyczki, Bestiariusz, Ekwipunek i Wiedza MG.
  Usunięto pustą rezerwację weapons; dodano opisane katalogi equipment i reference.
- Zastąpiono przyszłą tabelę weapons wspólnym Item: osiem typów przedmiotów,
  opcjonalny weaponProfile, zakresy ceny/dostępności, kategoria ekonomiczna,
  waga, opis i właściwości. Zachowano granicę szablon / prepared snapshot / runtime.
- Zaprojektowano TradeContext z niezależnym none (N/D) dla regionu, lokalizacji
  i Koloru. Stan domyślny none/none/none zachowuje dokładne wartości bazowe.
- Zapisano reguły potwierdzone przez MG z Excela: N/D ×1/×1, Rdza ×2/×0,5,
  Rtęć ×1/×1, Stal ×0,5/×2 tylko weapon/ammunition, Chrom ×1/×2
  (kolejno cena/dostępność). Stal dla innych typów daje ×1/×1.
- Zaprojektowano calculateMarketPrice, calculateMarketAvailability i
  calculateMarketValues: obie granice zakresu osobno, dostępność po lokalizacji
  i Kolorze ograniczana do 0–100%, bez mutacji bazy i bez rzutów.
- Dodano projekt KnowledgeEntry i aliasu ReferenceEntry.
- Ustalono jednorazowe przygotowanie seed data z Excela w v1.1, bez zależności
  od arkusza w działającej aplikacji, synchronizacji i funkcji ponownego importu.
- Roadmapa: v1.0 walka, v1.1 Ekwipunek, v1.2 Wiedza MG. Instrukcje Work/Codex
  nie zlecają ponownie bootstrapu i nie uruchamiają Etapu 2.

Modele i funkcje rynkowe są **projektem w dokumentacji**, bez implementacji TypeScript,
SQLite lub UI. Rozszerzono kryteria przyszłych testów, w tym dokładną tożsamość
none/none/none. Nie dodano testów wykonujących funkcje rynkowe, ponieważ takie
funkcje nie zostały wprowadzone. Istniejące testy pozostają bez zmian.

## Pełna lista plików

| Plik                               | Zmiana                                                       |
| ---------------------------------- | ------------------------------------------------------------ |
| `AGENTS.md`                        | misja, moduły, granice etapu i zachowanie danych             |
| `README.md`                        | aktualny stan, moduły, model przedmiotów i wydania           |
| `README_FIRST.md`                  | NeuroAltar, istniejący checkpoint i aktualny start           |
| `START_PROMPT_CODEX.txt`           | aktualny punkt kontrolny zamiast zlecenia Etapu 0            |
| `START_PROMPT_WORK.txt`            | aktualny punkt kontrolny i granice planowania                |
| `docs/PRODUCT_SPEC.md`             | pięć modułów, Item, przyszłe wydania i wyłączenia            |
| `docs/TECH_SPEC.md`                | struktura modułów, kontrakty kalkulacji, seed i persistence  |
| `docs/DATA_MODEL.md`               | Item/WeaponProfile, zakresy, TradeContext, Kolory, wiedza    |
| `docs/DECISIONS.md`                | decyzje Etapu 1.5; historia wcześniejszych decyzji zachowana |
| `docs/ROADMAP.md`                  | Etap 1.5, profile Item w walce, v1.1 i v1.2                  |
| `docs/ACCEPTANCE_TESTS.md`         | regresja Etapu 1.5 i przyszłe testy rynku                    |
| `docs/CODEX_INSTRUCTIONS.md`       | aktualny zakres i wymagane kontrole                          |
| `docs/WORK_INSTRUCTIONS.md`        | aktualny zakres koordynacji                                  |
| `manifest.json`                    | lista modułów, plan wydań, odnośnik do raportu               |
| `src-tauri/Cargo.toml`             | wyłącznie opis produktu jako warsztatu MG                    |
| `src/features/weapons/.gitkeep`    | usunięta pusta rezerwacja osobnej biblioteki broni           |
| `src/features/equipment/README.md` | nowy opis przyszłego modułu                                  |
| `src/features/reference/README.md` | nowy opis przyszłej Wiedzy MG                                |
| `docs/ETAP_1_5.md`                 | nowy raport zakresu i weryfikacji                            |

## Dane i migracje

**Brak migracji.** Migracja 001 i jej rejestracja pozostają identyczne.
Zachowano identyfikator `pl.neuroshima.combat-tracker`, adres `sqlite:combat-tracker.db`,
pięć slotów, kolejki autozapisu, ochronę zamykania i istniejące testy.
Porównanie SHA-256 potwierdziło identyczną zawartość istniejącego pliku bazy
użytkownika i migracji 001 przed i po pracy. Nie uruchamiano aplikacji na bazie
użytkownika i nie wykonywano zapisów do niej.

Kod runtime React/TypeScript/Rust, testy, lockfile i konfiguracja Tauri pozostają
identyczne względem checkpointu Etapu 1. Nie dodano UI Ekwipunku, Wiedzy MG, k100,
regionu/lokalizacji/Koloru, importera, dice rollera, ammo tracking ani Etapu 2.
Prywatny główny `reference/` nadal jest ignorowany i nie trafia do commita/bundla.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier — poprawne; **43/43 testy, 6 plików Vitest**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: poprawne.
- `pnpm build:macos`: poprawny build frontendu i Tauri/Rust dla macOS arm64.
- `codesign --verify --deep --strict`: poprawny podpis bundla po końcowym buildzie.
- `git diff --check`: poprawny końcowy diff przed commitem.

Artefakt: `/var/folders/ln/4_bjvcz17bd0j85hls2n0ztc0000gn/T/neuroshima-combat-tracker/412aa42ea9cc/target/release/bundle/macos/NeuroAltar.app`.
Jest to katalog tymczasowy; system może go później usunąć.

Build korzystał z istniejących lokalnych zależności, w trybie offline. Początkowe
ostrzeżenie rust-objcopy o libLLVM usunięto przez uruchomienie toolchainu przez
rustup z poprawnymi CARGO_HOME/RUSTUP_HOME, bez zmian instalacji lub kodu projektu.
Po usunięciu wyłącznie wygenerowanych artefaktów pakietu z katalogu tymczasowego
końcowy build przeszedł bez ostrzeżenia Rust. Pozostał standardowy komunikat
o pominięciu notaryzacji, zgodny z obecną konfiguracją podpisu ad hoc.

## Ryzyka przed Etapem 2

- Nie wykryto nowego blokera funkcjonalnego Etapu 2. Aktualizacja jest przygotowaniem
  architektury; Etap 2 nie został rozpoczęty.
- Obliczenia rynkowe, katalog regionów/lokalizacji, walidacja modeli i seed wymagają
  implementacji oraz testów w przyszłych etapach. Mnożników regionu i poprawek
  lokalizacji nie wymyślano; przed v1.1 należy zweryfikować katalog źródłowy.
- Przed wprowadzeniem nowych tabel w kolejnych etapach potrzebne są migracje
  z testem zachowania istniejących danych. Nie wolno zastępować bazy świeżym seedem.
- Build obejmuje Apple Silicon i lokalny podpis ad hoc, bez notaryzacji Apple.
  Windows i Intel nie były budowane. Nie wykonywano nowego testu klikania UI;
  kod UI/runtime się nie zmienił, a regresję pokryto pełnym istniejącym zestawem testów.
