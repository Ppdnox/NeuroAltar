# Etap 24A — specyfikacja pełnej karty BG

Data: 2026-09-13. Punkt wyjścia: `8f8160c`, aplikacja 0.26.0, czyste drzewo Git.
Zlecenie „Rozpocznij kolejny etap” realizuje podetap 24A z przyjętego planu.
To etap dokumentacyjny. Nie uruchomiono 24B ani nie zadeklarowano gotowej karty.

## Wynik

- [KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md): źródło/fingerprint, 42 reguły
  z obliczeniami i wymaganymi testami, przypisania 18 umiejętności i 22 narzędzi,
  wymagania rozwoju i rejestr 10 interpretacji z rozstrzygnięciami MG.
- [KARTA_BG_KATALOG_REGUL.md](KARTA_BG_KATALOG_REGUL.md): sześć klas,
  rozwój 1–12, 18 profesji, 12 pochodzeń i 36 zdolności, katalog 53 sztuczek, pul,
  chorób, fobii, towarzyszy i zależności produkcji przedmiotów.
- [KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md): trwała postać niezależna od
  slotu, własność danych, jeden aktywny udział przy wielu przygotowanych,
  transakcje/retry, adopcja starego BG, reset/clear oraz 14 scenariuszy trwałości.
- [KARTA_BG_WZORZEC.md](KARTA_BG_WZORZEC.md): przypisanie grup pól czterech
  stron PDF do danych, widoków i etapów wdrożenia.
- Aktualizacja stanu, zakresu i odsyłaczy w README/README_FIRST, AGENTS,
  specyfikacjach produktu/techniki/danych, decyzjach, planie/roadmapie,
  kryteriach odbioru i instrukcjach Codex/Work wraz z promptami startowymi.

Ostateczne ustalenie MG: **Samouk Cwaniaka na 9; profesje Twardziela 3/7/11**.
Zastępuje wcześniejszą odpowiedź z tej samej rozmowy. Nie wprowadzamy ogólnej
zasady, że wszystkie opisy zawsze wygrywają z tabelami.

## Wybór Koloru gry — uzupełnienie zlecenia

[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md) dodaje selektor w rogu karty,
pełną listę nakładek ze stron 201–203, historię przyrostów PW oraz 12 testów.
N/D jest bazą, kontekst postaci jest niezależny od handlu. Rdza−2PW/awans
i odpoczynki24/72h; Rtęć−3PW, Stal+1PW, Chrom+2PW. Także warunkowe
krytyki, Fuksy, zdrowie i awaryjność. Konflikty Chromu z dokładną amunicją
i wcześniejszymi cenami pozostają jawnie opisane, bez samowolnej zmiany aplikacji.

## Weryfikacja źródeł i zakresu

Przeanalizowano lokalny podręcznik: zasady postaci i testów, tworzenie/awans,
pochodzenia, klasy/profesje, sztuczki, choroby/fobie, odpoczynki, obciążenie,
istotne zasady broni/amunicji/pancerzy i produkcji oraz Kolory s. 201–203. Numery w dokumentach są
drukowane, nie numerami pliku PDF. Konflikt Samouka sprawdzono także na obrazie
strony73. Ponownie obejrzano wszystkie cztery strony wzorcowej karty.
Oryginalne PDF-y, wyciągi tekstu i obrazy kontrolne nie są częścią repo ani aplikacji.

Ta specyfikacja określa pokrycie i kontrakt implementacji. Poszczególne definicje
reguł nadal wymagają wdrożenia i własnych testów w 24B–24E. Otwarte kombinacje
i braki źródłowe są jawne, więc nie jest to deklaracja pełnej automatyzacji mechanik.

## 2026-09-13 — rozstrzygnięcia MG dla mechaniki BG

- Q-01: Saper ma jedno użycie, odnawia się po krótkim lub długim.
- Q-05: długi odpoczynek odnawia również zasoby odnawiane po krótkim;
  nie stanowi to polecenia odnawiania amunicji, przedmiotów lub zasobów ręcznych.
- Q-06: modyfikatory procentowe sumują się względem bazy; dwa podwojenia→×3,
  dwa +50%→×2, zamiast kolejnego mnożenia. To przyjęta interpretacja „sumują się”.
- Q-07: zestaw startowyX ma jeden Item o masieY i opis zawartości;
  nie szacować niepodanych mas składników ani liczyć zawartości drugi raz.
- Q-08: zacięcie sprawdzane przy pierwszym wystrzale; akcja zmarnowana,
  cała amunicja zachowana. Sam rzut w rollerze nie jest deklaracją strzału.
- Q-10: wymagane zaokrąglenia mechaniczne zawsze w dół. Nie ucinać przez to
  ułamkowych mas/jednostek; prezentacja nadal do dwóch miejsc po przecinku.
- Q-04 ma dzięki temu rozstrzygnięty kierunek zaokrąglenia. Nadal brakuje
  podstawy połowy KW; w Q-10 nadal nie ustalono znaczenia tempa50% ani
  kolejności osobistej premii dostępności. Pozostałe Q/COL-Q zgodnie z rejestrem.

## Migracje, testy i build

Brak migracji, SQL, zmian bazy, kodu aplikacji i zależności. Migracje 001–010,
pięć slotów, autozapis, dane MG i istniejąca aplikacja pozostają bez zmian.
Nie wykonano pełnych testów TS/Rust ani nowego buildu macOS: zgodnie z AGENTS
sam etap dokumentacyjny wymaga kontroli spójności, odsyłaczy, formatu i diffu.
Przypadki BG/P opisują przyszłe testy; nie są uruchomionymi testami aplikacji.
Poprzedni odbiór binarny opisuje [ETAP_23.md](ETAP_23.md); nie przedstawiamy jego
wyników jako nowego uruchomienia.

Kontrole dokumentów zakończone powodzeniem:

- `pnpm format:check` — PASS (pliki objęte konfiguracją projektu).
- `git diff --check` — PASS.
- Sprawdzenie 49 lokalnych odsyłaczy — PASS.
- Spójność i unikalność 42 reguł BG, 14 scenariuszy P i 12 scenariuszy COL — PASS.
- Kontrola katalogu: 6 klas, 53 sztuczki oraz ostateczne poziomy Samouka/Twardziela — PASS.
- Porównanie zakresu 20 plików: wyłącznie dokumentacja/instrukcje; kod, migracje,
  zależności i numer wersji bez zmian. Fingerprint obu PDF-ów zgodny ze źródłami.

## Dokładna lista plików

Nowe: `docs/ETAP_24A.md`, `docs/KARTA_BG_MECHANIKA.md`,
`docs/KARTA_BG_KATALOG_REGUL.md`, `docs/KARTA_BG_KONTRAKT.md`,
`docs/KARTA_BG_KOLORY.md`.

Zmienione: `AGENTS.md`, `README.md`, `README_FIRST.md`,
`START_PROMPT_CODEX.txt`, `START_PROMPT_WORK.txt`, `docs/ACCEPTANCE_TESTS.md`,
`docs/CODEX_INSTRUCTIONS.md`, `docs/WORK_INSTRUCTIONS.md`, `docs/DATA_MODEL.md`,
`docs/DECISIONS.md`, `docs/KARTA_BG_WZORZEC.md`, `docs/PLAN_DALSZYCH_PRAC.md`,
`docs/PRODUCT_SPEC.md`, `docs/ROADMAP.md`, `docs/TECH_SPEC.md`.

Git: etap zapisany osobnym commitem dokumentacji po kontrolach. Poprzedni stan
Etapu23 był już zatwierdzony (`8f8160c`), więc dodatkowy checkpoint nie był potrzebny.

## Ryzyka przed 24B–24E

Dodatkowo pięć grup interpretacji COL-Q1…5 obejmuje skutki Kolorów,
zwłaszcza Chrom i zmianę czasu odpoczynku; szczegóły w KARTA_BG_KOLORY.md.

1. Niektóre reguły są niedookreślone (minimum użyć zależnych od cechy, podstawa
   połowy KW w pancerzu, tempo produkcji i premie dostępności). Lista Q
   wskazuje dokładne źródło i zachowanie do rozstrzygnięcia. Nie blokuje pozostałych
   pól 24B, lecz blokuje deklarację kompletności tych mechanik.
2. Wiele przedmiotów/amunicji nie ma pewnej masy ani pełnego profilu bojowego
   w obecnym katalogu. Brak pozostaje widoczny; nie zgadywać z nazwy.
3. Powiązanie trwałych PW/zasobów z dotychczasowym checkpointem walki wymaga
   testów atomowości i zgodności starych snapshotów w 24E. Nie wolno cofać
   postaci resetem potyczki.
4. Towarzysze, wyjątkowe krytyki i warunkowe premie są realnym zakresem pełnej
   karty, a nie opcjonalnym pomijanym dodatkiem. Wymagają kontroli źródła
   konkretnego efektu. Amunicja nadal wyłącznie BG.

Następny osobno zlecany podetap: **24B — trwałe dane postaci, obliczenia i ekran
karty BG**. Potem 24C, 24D, 24E, na końcu 25 — Windows.
