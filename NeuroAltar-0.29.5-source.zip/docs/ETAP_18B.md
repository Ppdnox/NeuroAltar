# Etap 18B — zwierzęta z podręcznika

Wersja 0.21.0, 2026-09-12. Zakres: kolejny zlecony etap po 18A.
Baza: czysty commit `340edb5` (0.20.0). Zmiany wprowadzono do
`/Users/dominik/Desktop/Combat Tracker`. Etap 19 nie został rozpoczęty.

## Wprowadzone zmiany

- 12 statblocków: Gigamut, Gigantyczny pająk, trzy konie (skażony, teksańczyk,
  zdrowy), Mrokoszczur, Myślący szczur, Neokot, Neogator, Neoniedźwiedź,
  Pies bojowy, Rój szczurów. Katalog startowy: 42 szablony + nakładka Zombie.
- Pełne cechy, źródłowe PW/TT/SP/PB, ruch, obrony, zasady, ataki i bonusy.
  Tor Zranień tylko tam, gdzie podano go w statblocku.
- Rój: dwa warianty ugryzienia w jednym wpisie oraz Reakcje bez limitu.
  Właściwość edytowalna w zasobach i akcjach, widoczna w kartach.
  Użycia nadal respektują stany, Zranienia i koszt zasobu; każde trafia do logu.
  Przełączenie właściwości nie odnawia zużytej zwykłej reakcji.
- Nowa niezależna partia `noe-animals` v2 wykorzystuje dotychczasowy ledger.
  Edycje MG, usunięcia, kolizje, katalog oraz kopie bojowe pozostają chronione.
- Aktualizacja planu, specyfikacji, instrukcji i wersji aplikacji.

## Źródło i decyzje

Lokalny PDF `reference/NOE_dla_dominadiinteriapl.pdf`, SHA256:
`714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
Sekcja zwierząt przejrzana do końca: PDF 245–253; statblocki PDF 246–253,
strony drukowane 244–251. Weryfikacja tekstu i renderów, w tym kolumn 246/247/251.
PDF i rendery nie są dołączane do aplikacji ani commita.

Zachowano źródłowe średnie i inicjatywę mimo niespójności rachunkowych,
m.in. Gigamut −3 (6), Myślący szczur PW 12 (4k6 + 4), łuk 5 (1k6 + 4),
sztylet 4 (1k4 + 4), Pies bojowy PW 20 (2k8 + 8).
Obrony pajęczyny nie są przypisane pająkowi. Miażdżenie/Rozszarpanie
pozostają opisowymi akcjami bez fikcyjnego Testu Ataku.

Rój: podręcznik nie podaje obrażeń przy dokładnie 50% PW. Wskazuje również
Niewrażliwość na Przerażenie i osobno strach przed ogniem. Obie niejasności
są widoczne w aplikacji; rozstrzyga je MG. Rozszarpanie niedźwiedzia nie ma
podanego typu obrażeń — nie dopisano własnego.

Wersja partii to v2: natywny test restartu wykrył zmianę dwóch opisów
w nieopublikowanym podglądzie v1 bez podniesienia wersji. Zachowano blokadę
chroniącą dane i użyto standardowej aktualizacji partii v1 → v2.

## Dane i migracje

Brak migracji SQL. Migracje 001–008 oraz trzy wcześniejsze pliki seed pozostały
identyczne bajtowo. Pięć stałych slotów, autosave, log i snapshoty zachowane.
Rozszerzenie JSON: opcjonalne `capabilities.unlimitedReactions`; brak pola
zachowuje zwykłe reakcje i nie zmienia serializacji wcześniejszych wpisów.
Budżet reakcji nadal ma zakres 0–1; przy true nie jest wydawany.
Baza użytkownika nie była kasowana, odtwarzana ani używana do testów.

## Weryfikacja

- `pnpm check`: 215/215 testów, 44 pliki; TypeScript, ESLint i formatowanie OK.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: 51/51, bez błędów.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`, `git diff --check`: OK.
- macOS: `pnpm build:macos` zakończony pomyślnie; macOS arm64, podpis ad hoc..
- Testy obejmują pełne statblocki/ataki, round-trip edycji, osobne kopie,
  przygotowanie/reset, reakcje bez limitu i ich ograniczenia, atomowy log,
  instalację/ponawianie/rollback oraz ochronę edycji i usunięć MG.

Natywny test używał wyłącznie identyfikatora
`pl.neuroshima.combat-tracker.readability-smoke`. W katalogu 43 pozycje,
filtr Zwierzęta 12. W slocie 4 dodano dwie kopie roju. Pierwsza otrzymała
nazwę „Rój szczurów — Żółć QA” i użyła reakcji 5 razy (3 bez limitu, 1 zwykła,
1 ponownie bez limitu). W bazie 5 wpisów action_used; usageNumber=5,
latentny budżet reaction=0, unlimitedReactions=true. Druga kopia ma usageNumber=0
i reaction=1, obie PW32. Otwarty formularz zatrzymał ⌘Q i wskazał niezapisane dane.
Polskie dwuwierszowe notatki zapisano automatycznie.

Po podniesieniu partii do v2 aktualizacja zakończyła się bez zmian postaci,
logów i metadanych potyczek. Wszystkie 30 wcześniejszych szablonów i ich wpisy
ledger pozostały identyczne. Ledger: machines 11/v1, monsters 12/v1,
mutants 7/v1, animals 12/v2. Kolejny restart i zwykłe zamknięcie okna nie zmieniły
żadnego wiersza w pięciu tabelach (katalog, ledger, postacie, log, potyczki).
Zweryfikowano stopkę 0.21.0, skrót ⌘4, polskie notatki, stan obu kopii,
zamknięcie przyciskiem okna i ⌘Q. SQLite integrity_check=ok, foreign_key_check pusty.
Lokalne dowody: work/stage18b-before-restart.db, stage18b-updated.db,
stage18b-after-restart.db w katalogu zadania; nie należą do repo ani buildu.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary_seed.rs`
- `src-tauri/src/capability.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/tauri.conf.json`
- `src/domain/capabilities.ts`
- `src/domain/capabilitySchema.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/resources/CapabilityFields.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `src/features/statblocks/CapabilitySummary.tsx`
- `src/data/bestiary/animals.v2.json`
- `tests/animalSeed.test.ts`
- `src/app/App.tsx`
- `docs/ETAP_18B.md`

## Dostarczenie i ograniczenia

Aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.21.0).
Przed podmianą starszy build zachowano jako `NeuroAltar 0.20.0.app`
w tym samym katalogu. Zweryfikowano identyfikator i podpis gotowego pliku.
Commit dostawy: `feat: add handbook animals and unlimited reactions`.
Pełny hash commita podaje raport końcowy zadania (nie wpisujemy go do własnej treści commita).

Build lokalny macOS arm64, podpis ad hoc; nie jest publiczną notaryzowaną
dystrybucją ani testem Windows/Intel. Zachowana starsza aplikacja nie stanowi
migracji bazy wstecz: 0.20.0 nie obsługuje nowego pola JSON, więc nie należy
uruchamiać jej na bazie zapisanej przez 0.21.0.
Bez automatycznych rzutów, obrażeń, statusów i przywołań. Bez Ekwipunku UI,
śledzenia amunicji i rozbudowy karty BG. Następny etap: 19 — ludzie,
wyłącznie po nowym zleceniu.
