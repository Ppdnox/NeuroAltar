# Zasoby przy zdolnościach i wspólne zakładki — 2026-11-05

Zmiana aktualnego 24E Roboczego na bazie `b059519`, na zlecenie MG.

## Zakres

Osiem sekcji Karty BG ma jeden wspólny pasek zakładek z ikonami i takim samym
wyróżnieniem aktywnej sekcji. Na szerokim ekranie układają się w dwie linie
po cztery, w wąskim oknie w dwie kolumny. Nawigacja klawiaturą pozostaje.

Zasoby klasowe i ze zdolności znajdują się przy odpowiadających im opisach
w Zdolnościach. Pełne kropki oznaczają dostępne użycia, puste — wydane.
Kliknięcie odlicza lub przywraca jedno użycie, bez formularza, powodu,
przycisków Użyj/Przywróć i dodatkowego potwierdzenia.

Liczba kropek pochodzi z bieżącego wyliczonego maksimum konkretnej zdolności,
nie ze stałego limitu ani samego poziomu. Wspólne `deriveResources` uwzględnia
m.in. poziom danej klasy, modyfikator właściwej Cechy, Premię z Biegłości
oraz posiadane zdolności pochodzenia, profesji i sztuczki. `conditionView`
uwzględnia też działające skutki zdrowotne zmieniające Cechy. Zmiana podstawy
limitu przelicza maksymalną liczbę kropek,
zachowując dotychczasowe zużycie. Przykład: maksimum 3 i jedno wydane użycie
po wzroście limitu do 5 daje pięć kropek, w tym cztery pełne. Odnowienie
krótkim/długim odpoczynkiem nadal wynika z reguły konkretnego zasobu.

Własne liczniki są dostępne w Zdolnościach. Duże pule używają ograniczonego
widoku kropek, aby nie tworzyć tysięcy przycisków jednocześnie.

Sekcja Zasoby postaci i stary formularz użycia/korekty znikają ze Zdrowia
oraz odpoczynku. Ustawianie PW/Zranień/KW nie wymaga powodu ani etykiety
„Korekta”. Opisy i mechaniczne funkcje zdolności w aktywnej walce pozostają
osobno dostępne. Kliknięcie kropki zmienia wyłącznie licznik; nie uruchamia
efektu Berserka ani nie zużywa akcji, nie leczy i nie wykonuje rzutu.

Dodatkowy audyt całego rozdziału zdolności i sztuczek potwierdził 25 istniejących
pul i wykrył brakujący limit koncertu Gwiazdy. Dodano jedną kropkę dla
Za garść gambli, przywracaną ręcznie przy kolejnym dniu. Uzupełniono opis Muzyka.
Pełne zestawienie 26 pul, wzory i potencjalne maksima wraz ze stronami:
[AUDYT_LIMITOW_ZDOLNOSCI_2026-11-05.md](AUDYT_LIMITOW_ZDOLNOSCI_2026-11-05.md).

## Zapis

Nowe polecenie `resourceStep` z kierunkiem `use`/`restore` zmienia jedno
zużycie w istniejącym `condition.spent`. Obie warstwy sprawdzają granice,
aktualne maksimum i istnienie zasobu. Trwałe operationId i rewizje chronią
przed podwójnym zapisem po ponowieniu, konfliktem i równoległymi kliknięciami.

Bez migracji SQL i bez modyfikacji istniejących kart przy odczycie. Zachowana
historia dawnych operacji. Szkic rozwoju nie zmienia zatwierdzonych zasobów;
kropki stają się aktywne po zatwierdzeniu karty.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i **527/527 testów** (75 plików) — PASS.
- `cargo test --release --lib`: **102/102 testów** — PASS.
- Regresje: granice puli, odnowienia odpoczynkiem, zmiana 3→5 przy publikacji
  awansu, zmiana KON bez awansu, zachowanie wydanych użyć, źródłowe limity
  wszystkich 26 pul, osiem pul zależnych od Cech, PB wieloklasowy,
  mapowanie każdej klasy na poziomach 1–12,
  kliknięcie tej samej kropki, duże własne liczniki, aktywna walka,
  odrzucenie całego błędnego zapisu i ponowienie operacji, walidacja koncertu
  w TS/Rust i brak odnowienia odpoczynkiem — PASS.
- `pnpm build` — PASS.
- Build macOS `NeuroAltar 24E Roboczy.app` — PASS.
- Kontrola natywnego UI: wszystkie osiem zakładek, kropki przy zamkniętych
  opisach, odstępy między zdolnościami i usunięcie zasobów ze Zdrowia — PASS.
- Osobna karta QA: wydanie i przywrócenie tego samego użycia bez dialogu;
  stan zachowany po zamknięciu i ponownym otwarciu aplikacji — PASS.
- Baza użytkownika: wszystkie 15 tabel identyczne z kopią sprzed zmiany,
  `integrity_check` = `ok`; testowe kliknięcia wyłącznie w osobnej bazie QA.
- Wcześniejsze ostrzeżenia bundlera nie blokują buildu. Pakiet pozostaje
  podpisany ad hoc, bez notaryzacji; pełny odbiór sesyjny 24E jest osobny.
