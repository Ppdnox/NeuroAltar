# Etap 23 — odbiór Panelu MG na macOS

Data: 2026-09-13. Wersja: **0.26.0**. Punkt wyjścia: `c32c607` (0.25.4),
czyste drzewo Git przed pracą. Odbiór zlecony przez MG, następnie rozszerzony
jego poleceniem o poprawienie dwóch reguł Wiedzy MG według podręcznika.

## Wynik

Panel MG przeszedł odbiór w zakresie dotychczas zleconych funkcji na tym Macu
(Apple Silicon). Zachowane etapy 0–22, 18A/18B i poprawki 0.25.1–0.25.4.
Brak nowych migracji. Nie otwierano produkcyjnej bazy do testów ani nie zmieniano
jej danych. Etap 24A nie został rozpoczęty.

## Wprowadzone poprawki

- F1 nie otwiera pomocy na wierzchu innego dialogu, w tym wyszukiwarki przeciwników.
- Escape i przycisk zamknięcia wyszukiwarki przywracają fokus do „Dodaj przeciwnika”.
  Enter ponownie otwiera wyszukiwarkę. Przycisk ma deklarację otwierania dialogu.
- Ogólne ostrzeżenie po zatrzymanym zamykaniu znika po zakończeniu/anulowaniu
  formularzy i poprawnym zapisaniu wszystkich pięciu slotów. Nie ukrywa błędów
  zapisu, niepełnych szkiców ani osobnego błędu zamknięcia aplikacji.
- **Hełmy:** użycie Krytycznej ochrony w Reakcji zamienia trafienie krytyczne na
  zwykłe obrażenia i niszczy hełm. Neuroshima: Ostatnia Era, s. 115 (PDF 117).
- **Długa:** utrudnienie ataku na cel do 3 m nie obowiązuje, gdy **Szybkość** celu
  wynosi 0. Poprzedni tekst Excela błędnie podawał Zręczność. Podręcznik s. 118
  (PDF 120). Oba fragmenty ponownie odczytano w lokalnym PDF.
- Aktualne instrukcje i plan wskazują odbiór 23, następnie kartę BG 24A–24E,
  a port całej aplikacji na Windows na końcu (25).

Dwie korekty treści są stosowane przy odczycie katalogu Wiedzy MG według stałych ID.
Oryginalne 47 wpisów Excela w `tables.v1.json` pozostaje niezmienionym materiałem
porównawczym. Poprawione bloki mają dokładne źródło podręcznikowe i datę korekty.
Pozostałe wpisy nie są zmieniane. Brak nowych funkcji automatycznie rozliczających
hełm, atak, PW lub amunicję.

## Dane i aktualizacja starszej wersji

Osobna aplikacja `NeuroAltar Stage 23 Test`, identyfikator
`pl.neuroshima.combat-tracker.stage23-smoke`. Do jej nowego katalogu skopiowano
przez SQLite backup historyczną bazę QA z Etapu 14 (migracje 001–006).
Aktualny build sam zastosował istniejące migracje 007–010 i katalogi.

| Kontrola                          | Wynik                                                                    |
| --------------------------------- | ------------------------------------------------------------------------ |
| Pięć slotów, ID 1–5               | Wszystkie stare kolumny i wartości identyczne po aktualizacji            |
| Pięć istniejących postaci         | Zachowane ID, statystyki, runtime i oba snapshoty                        |
| Własny szablon                    | Zachowany bez zmian; wraz z 51 oficjalnymi daje 52 rekordy               |
| Dotychczasowy log                 | Wszystkie 25 wpisów zachowane                                            |
| Nowe katalogi                     | 51 wpisów rejestru Bestiariusza, 299 przedmiotów, jedna partia Ekwipunku |
| Migracje                          | 001–010, bez modyfikacji plików migracji                                 |
| Integralność SQLite i klucze obce | `ok`, zero naruszeń                                                      |
| Restart po scenariuszu walki      | Wszystkie wiersze wszystkich tabel identyczne przed i po restarcie       |

Po próbach: 7 postaci (dodano wyłącznie w QA Gangusa i Mobsprzęt), 32 wpisy logu,
6 rzutów. Katalogi przedmiotów i szablonów identyczne z tymi po pierwszej migracji.
Oryginalne postacie, ich runtime, PW/TT i snapshoty nadal bez zmian.

## Sprawdzenie danych źródłowych

Ponownie odczytano oryginalny XLSX, SHA256
`829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22`.

- Wszystkie 299 wierszy Ekwipunku: zgodne nazwy, kategorie ekonomiczne, oba końce
  ceny i oba końce dostępności. Brak zaokrąglania danych wejściowych.
- 47 oryginalnych wpisów Wiedzy MG: porównano 1951 odwołań do komórek
  (nagłówki, puste i wypełnione komórki oraz opisy). Zero rozbieżności z Excelem.
- Trzy tabele handlu nadal pochodzą ze wspólnych danych rynku; razem 50 wpisów Wiedzy MG.
- Dwie opisane wyżej korekty podręcznikowe celowo zmieniają wynik prezentowany
  użytkownikowi względem oryginalnego Excela. Test potwierdza zachowanie reszty wpisów.
- Testy wszystkich partii Bestiariusza obejmują 11 maszyn, 7 mutantów, 12 potworów,
  12 zwierząt i 9 ludzi, szczególne statblocki, profile ataków, zasoby oraz nakładkę Zombie.
  Nie wykonywano ponownej ręcznej transkrypcji wszystkich 51 statblocków.
- Test źródeł obejmuje każdą z 299 pozycji Ekwipunku oraz każdy wpis Wiedzy MG.
  Mapy i wcześniejsze sprawdzenia tabel: EKWIPUNEK_STRONY.md, WIEDZA_MG_STRONY.md.

Pozostałe treści Ekwipunku/Wiedzy MG zachowują uzgodnione opracowanie Excela.
Odbiór nie oznacza nowego pełnego porównania każdej reguły podręcznika z Excelem.
Prywatne PDF/XLSX nie zostały dodane do Git ani do aplikacji.

## Próby natywne

| Obszar             | Dowód z aplikacji                                                                                           |
| ------------------ | ----------------------------------------------------------------------------------------------------------- |
| Start i nawigacja  | Ekran główny → Panel MG; Walka, Bestiariusz, Ekwipunek, Wiedza MG                                           |
| Wyszukiwarka       | Gangus: 3 wyniki; dodano jednego żołnierza. F1 pozostawia dialog, Escape go zamyka, Enter otwiera ponownie  |
| Starsza potyczka   | Zachowana runda 2, bieżąca Łucja, Konwojent i ich wcześniejsze wartości                                     |
| Inicjatywa         | Istniejący wpis zasad Gangusa: 1k20+2, naturalna 1 → 3; wpisane do jego inicjatywy, bieżąca tura bez zmiany |
| Kości podręczne    | 3k8 → [6, 8, 1] = 15, osobny wpis w historii                                                                |
| Atak z opisu       | Peacemaker Gangusa: naturalne 20 +4 = 24, rozpoznany krytyk                                                 |
| Jednorazowy krytyk | Następne obrażenia 1k8+2 → 2k8+2 = 15; kolejne ponownie 1k8+2 = 8                                           |
| Zachowanie PW      | Gangus 18/18, Mobsprzęt 48/48; rzuty nie zmieniły PW                                                        |
| Bestiariusz        | Mobsprzęt ma sześć alternatyw broni i instrukcję wyboru 1k6, jedna kopia dodana do slotu 2                  |
| Awaria             | Ręcznie wpisane 13 daje podgląd TT −2; rzut k20 dał 19. Sam podgląd nie zastosował awarii                   |
| Ochrona zamknięcia | ⌘Q z formularzem awarii zatrzymane i wskazany formularz; po anulowaniu ostrzeżenie znika                    |
| Skróty             | ⌘1/⌘2 przełączają slot; przy rozwiniętych kościach skrót nie zmienia potyczki                               |
| Rynek              | N/D/N/D/N/D: amunicja 2 gb i 50%; Stal: 1 gb i 100%; pancerz ze Stalą nadal 30 gb i 70%                     |
| Źródła             | Kurtka ćwiekowana: podręcznik s. 113; poprawione Hełmy i Długa widoczne w Wiedzy MG                         |
| Czytelność         | Okno domyślne 1100×760, powiększone 1332×768, tekst 115%; układ wypełnia okno                               |
| Zamykanie/restart  | ⌘Q i przycisk zamknięcia okna; proces zakończony, ponowne otwarcie i porównanie bazy                        |

Operacje usuwania, resetu, konflikty rewizji i błędy zapisu sprawdzano przez
istniejące testy automatyczne. Nie wykonywano destrukcyjnych prób w GUI na danych MG.

## Testy i build

- `pnpm check`: PASS — typecheck, lint bez ostrzeżeń, format oraz **291 testów / 54 pliki**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: PASS — **63 testy**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: PASS.
- `pnpm build:macos`: PASS, arm64, podpis ad hoc zweryfikowany przy dostarczeniu.
- Osobny build testowy i opisane próby natywne: PASS.
- `git diff --check`: PASS.

Dane kontrolne, logi i obrazy QA pozostają w lokalnym katalogu roboczym zadania.

## Granice odbioru i dalsza praca

Brak stwierdzonego błędu blokującego używanie odebranego Panelu MG na testowanym Macu.
Pozostają ograniczenia platformowe: brak sprawdzenia na Intel Mac i Windows,
podpis ad hoc bez notaryzacji Apple. Build nadal zgłasza ostrzeżenie o pakiecie JS
większym niż 500 kB; nie blokuje kompilacji ani przeprowadzonych prób uruchomienia.

Import/eksport kampanii i backup z GUI odroczone poza zakres tego odbioru.
Nie implementowano ich bez dodatkowego zlecenia. Brak dodatkowych zapisanych
potyczek, kont, chmury, 3D, automatycznego odejmowania PW i licznika amunicji NPC.
Pełna karta BG pozostaje Etapem 24A–24E. Windows po całej karcie BG, w Etapie 25.
Publiczna dystrybucja i notaryzacja wymagają osobnego ustalenia.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DECISIONS.md`
- `docs/ETAP_23.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/ROADMAP.md`
- `docs/WIEDZA_MG_STRONY.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/knowledge/README.md`
- `src/data/knowledge/catalog.ts`
- `src/data/knowledge/handbookCorrections.ts`
- `src/domain/shortcuts.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/features/help/ShortcutHelp.tsx`
- `tests/knowledge.test.ts`
- `tests/shortcuts.test.ts`
