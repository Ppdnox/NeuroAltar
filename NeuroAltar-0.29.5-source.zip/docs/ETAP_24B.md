# Etap 24B — trwała karta BG i obliczenia

Wersja: **0.27.0**. Data: 2026-09-13. Punkt wyjścia: czyste repo,
commit bcb18d9 (specyfikacja24A). Prace wykonano bezpośrednio w lokalnym
folderze Combat Tracker. Zakres: podetap B; nie rozpoczęto C–E ani Windows.

## Co działa

- Ekran główny → Karta postaci BG: wiele niezależnych kart, osobny szkic,
  autozapis, zatwierdzenie kompletnego zestawu wyborów, archiwizacja/przywrócenie.
- Tworzenie: trzy tablice cech,27punktów lub jawne wartości MG z powodem;
  6cech,12pochodzeń/36zdolności,6klas,18profesji i53sztuczki. Wymagania
  wyborów są sprawdzane podczas nabycia. Brak wartości pozostaje brakiem.
- Kolejne poziomy do12 i wieloklasowość: częściowe biegłości wejścia do nowej
  klasy, profesje, sztuczki, specjalizacje, ulubione modele broni i inne wybory.
  Samouk na9, profesje Twardziela3/7/11. Zdolność profesji można wybrać
  z całej listy jeszcze nieposiadanych, bez narzucania kolejności podręcznika.
- Przeliczenia z objaśnieniem składników: efektywne cechy, modyfikatory, PB,
  RO,18umiejętności,22narzędzia i instrumenty, PW, pule KW, inicjatywa,
  Pasywna Percepcja, alternatywne TT bez pancerza, ruch, skoki i udźwig.
  Umiejętność pozwala podejrzeć test z inną cechą, zachowując rangę biegłości.
- Warianty TT pozostają osobne. Obsługa pancerza nie zwiększa TT bez pancerza.
  Szczur może używać Zręczności do skoków; Szary dolicza wybrany modyfikator
  mentalny. Trwałe premie profesji i sztuczek mają jawne źródła.
- Kolor gry w nagłówku, osobny od warunków handlu: podgląd, domyślnie od teraz,
  opcjonalne przeliczenie historii. Każdy poziom zapisuje swój Kolor.
  Bieżąca KON przelicza wszystkie poziomy. Bieżące PW nie odnawiają się.
- **Decyzja MG: minimum0 PW na każdy późniejszy awans** po klasie, KON i Kolorze.
  Pierwszy poziom zachowuje własny wzór, bez kary/premii Koloru.
- Aktualne PW, dziennik PD albo kamienie milowe, notatki, znajomi, odkrycia,
  opis/portret/wiek/wzrost/masa ciała/wielkość i nazwane korekty MG.
  Zmiana wcześniej zatwierdzonych cech, pochodzenia lub rozwoju wymaga
  powodu korekty zapisywanego w historii operacji.
- Grupowanie zgodne z kartą PDF,3/2/1kolumny zależnie od okna, istniejąca
  regulacja czytelności. Walidacja prowadzi do problematycznej sekcji/pola.

## Trwałość i migracja

Migracja **011_characters.sql** dodaje wyłącznie characters i
character_operations. Migracje001–010 pozostają identyczne.
Zatwierdzona karta i szkic są osobne. Operacje zapisują postać, revision
i wynik w jednej transakcji; dokładne retry nie wykonuje operacji drugi raz.
Próba X, później Y, później retry X zwraca dawny wynik X bez cofania Y.
Konflikt zachowuje szkic i pozwala porównać obie wersje przed przeniesieniem
lokalnego szkicu do ponownej kontroli. Nie stosuje cichego nadpisania.

Sprawdzenie migracji na osobnej bazie QA zachowało dokładną zawartość:
5slotów,7aktorów wraz ze snapshotami,52szablonów (w tym własny),
32wpisów walki,51powiązań seedu,299przedmiotów,1partii ekwipunku,
6rzutów oraz pozostałych tabel. Kontrola integralności: OK.
Stare BG nie zostały powiązane z kartami. Bazy użytkownika nie kasowano,
nie odtwarzano ani nie używano do testów; migracja zastosuje się przy jego
pierwszym uruchomieniu nowej wersji.

## Weryfikacja

- Pełne pnpm check: **332testy w57plikach**, kontrola typów, lint i format PASS.
- Rust: **68testów PASS**, w tym atomowość, retry, konflikty, ochrona sheet/draft
  i powód korekty wcześniejszego rozwoju.
- Build macOS Apple Silicon: **PASS**, podpis ad-hoc i codesign --verify --deep --strict: **PASS**.
- Format Rust i git diff --check: **PASS**.
- Natywnie sprawdzono utworzenie, pełne wybory i zatwierdzenie Brutala1:
  Asgard,CON14,INT13,max18PW,Goła klata14,bazoweTT12,udźwig75/150kg.
  Następnie aktualne7PW i awans2wRdzy dały max22PW bez odnowienia tych7PW.
  Zapis potwierdzono w osobnej bazie.
- Ujemne PW blokuje ⌘Q i wskazuje pole. Po poprawieniu wartości wyjście
  zakończyło aplikację. Restart finalnej wersji0.27.0 zachował dane i ustawienie tekstu.
- Automatyczne testy obejmują wszystkie klasy do12, wszystkie profesje,
  minimalne przyrosty PW, historię Kolorów, wieloklasowość, wymagania sztuczek,
  brak dublowania PB, specjalizacje, MG overrides i ponowienia autozapisu.

- Natywny podgląd Rdza→Chrom: przyszłe przyrosty22→22PW, przeliczenie historii22→26PW,
  bieżące7PW bez zmian. Anulowanie zachowało Rdza/max22 i revision.
- Próba okna1100px i750px oraz tekst115%: sekcje przechodzą do jednej kolumny,
  pola pozostają czytelne. Wyśrodkowanie dialogów i wysokość selektorów poprawione
  po oględzinach; finalny dialog korekty obejrzany w0.27.0.
- Korekta wcześniej zatwierdzonej tablicy cech wymagała uzasadnienia. Po wpisaniu
  powodu zapisano całą kartę oraz ten powód w dzienniku; aktualne7PW zachowane.
- W finalnej aplikacji testowej sprawdzono kolejne ⌘Q i poprawne wyjście.

## Dostarczona aplikacja

Docelowy plik: src-tauri/target/release/bundle/macos/NeuroAltar.app (0.27.0).
Kopia poprzedniej wersji: src-tauri/target/release/bundle/macos/NeuroAltar 0.26.0.app.
Podmieniono zamkniętą aplikację, następnie sprawdzono podpis w miejscu docelowym.
Nie uruchamiano produkcyjnej bazy do QA. Ostrzeżenia buildu: brak notaryzacji
Apple oraz główny pakiet JavaScript powyżej500kB; oba nie blokują lokalnego buildu.

## Granice i dalsza praca

To fundament rzeczywistej karty, nie pełna automatyzacja całej mechaniki.
**24C**: posiadany inwentarz, waga wyposażenia, pancerze/bronie, magazynki
i amunicja BG. **24D**: zużycie KW/zasobów, odpoczynki, choroby/fobie, Fuksy
i szczegółowe zdrowie. **24E**: udział w walce, rzuty z karty, efekty warunkowe,
towarzysze i końcowy odbiór. Następnie25Windows.

W24B Kolory automatyzują PW i historię rozwoju. Pozostałe efekty nie są
przedstawiane jako działające. Zdolności czynnościowe mają zapisane wybory
i nazwy, lecz nie rozliczają jeszcze kosztów ani skutków; szczegółowe opisy
rozszerza odpowiedni podetap. Ulubiona broń to zapis modelu, bez zgadywania
profilu przedmiotu. Udźwig to limit, nie wyliczona masa noszonego wyposażenia.
Pule KW pokazują maksimum, nie zasób gotowy do odpoczynku.
Nie dodano automatycznego odejmowania PW z ataków, amunicji NPC ani synchronizacji
źródeł. Prywatne PDF/Excel pozostają poza Gitem i aplikacją.
Nierozstrzygnięte pytania Q/COL-Q pozostają przy właściwych przyszłych podetapach.

Notaryzacja Apple nadal nie jest skonfigurowana. Weryfikacja dotyczy macOS
Apple Silicon; Intel i Windows nie są potwierdzone. Dziennik zapisuje pełne
migawki operacji (również portret), więc rośnie wraz z liczbą edycji;
nie dodano automatycznego kasowania historii.

## Pliki zmienione i dodane

- AGENTS.md
- README.md
- README_FIRST.md
- START_PROMPT_CODEX.txt
- START_PROMPT_WORK.txt
- docs/ACCEPTANCE_TESTS.md
- docs/CODEX_INSTRUCTIONS.md
- docs/DATA_MODEL.md
- docs/DECISIONS.md
- docs/ETAP_24B.md
- docs/KARTA_BG_KATALOG_REGUL.md
- docs/KARTA_BG_KOLORY.md
- docs/KARTA_BG_KONTRAKT.md
- docs/KARTA_BG_MECHANIKA.md
- docs/KARTA_BG_WZORZEC.md
- docs/PLAN_DALSZYCH_PRAC.md
- docs/PRODUCT_SPEC.md
- docs/ROADMAP.md
- docs/TECH_SPEC.md
- docs/WORK_INSTRUCTIONS.md
- package.json
- src-tauri/Cargo.lock
- src-tauri/Cargo.toml
- src-tauri/migrations/011_characters.sql
- src-tauri/src/character.rs
- src-tauri/src/character_tests.rs
- src-tauri/src/lib.rs
- src-tauri/tauri.conf.json
- src/app/App.tsx
- src/db/characterRepository.ts
- src/domain/character/catalog.ts
- src/domain/character/derive.ts
- src/domain/character/feats.ts
- src/domain/character/model.ts
- src/domain/character/review.ts
- src/features/character/CharacterWorkspace.tsx
- src/features/character/character.css
- src/services/prepareAppClose.ts
- src/stores/characterStore.ts
- src/stores/navigationStore.ts
- tests/character.test.ts
- tests/characterReview.test.ts
- tests/characterStore.test.ts
- tests/fixtures/character.json
- tests/helpers/character.ts
