# Poprawki kart walki — NeuroAltar 0.25.1

## Zakres i wynik

Zlecone po Etapie 22, commit wyjściowy `2cd2926`, początkowo czyste repo.
Zmiany wykonano w `/Users/dominik/Desktop/Combat Tracker`. Obejmują wszystkich
przeciwników: ludzi, maszyny, mutantów, potwory, zwierzęta oraz własne wpisy MG
odczytywane przez wspólne komponenty. Istniejących kopii nie trzeba dodawać ponownie.
Etap 23 nie został rozpoczęty.

- Sekcja „Cechy, obrona i zmysły” jest stale widoczna przed „Parametry i notatki postaci”.
  Usunięto zewnętrzne rozwijanie statblocka instancji; dotychczasowe cechy, RO, obrona,
  zmysły i umiejętności pozostają. Dodatkowe źródła nadal można rozwinąć osobno.
- Premie ataku i kości w opisach zdolności, reguł stałych oraz broni są klikalne.
  Dotyczy to np. dodatkowego ataku nożem Cyngla, jego Bolesnego ataku i Zionięcia Megatora.
- Wspólny parser obsługuje jawne zapisy ataku, w tym „Atak wręcz +9”,
  „Jeden atak piłą: +16” i „Trzy ataki w jeden cel: +9”. Kości pozostają w miejscu opisu.
- Dodano mieszane grupy w jednej formule, np. `2k8+2k6+4`, również w głównym panelu.
  Wynik pokazuje osobne kości z ich rodzajami oraz jedną sumę. Limit 100 kości łącznie.
- Wyniki z karty trafiają do logu z nazwą postaci i zdolności. Sam rzut nie zmienia PW,
  tury, zasobów, amunicji ani budżetu zdolności. Użycie zdolności pozostaje osobne.
- Premia tekstowego ataku uwzględnia liczbowe kary awarii i Wyczerpania; nie dodaje ponownie PB.
  ST rzutu obronnego celu nie staje się rzutem atakującego. Stałe obrażenia nie są losowane.

## Dane

**Brak nowej migracji.** Migracje 001–010, dane seeda i prywatne źródła niezmienione.
Opcjonalne `groups` w JSON historii opisuje mieszane kości. Starsze rzuty bez `groups`
są nadal czytane i zapisywane; zapis Rust sprawdza osobno zakres każdej kości.
Transakcja historii/logu oraz zachowanie identycznego wyniku przy ponowieniu pozostają.
Nie usunięto ani nie odtworzono bazy użytkownika. Testy odbyły się na oddzielnej bazie QA.

## Testy i build

- `pnpm check`: PASS — TypeScript, ESLint, Prettier, **276 testów / 51 plików**.
- Dodatkowe poszerzenie testu na wszystkie partie: **4 testy ruleRolls PASS**;
  obejmuje **51 szablonów / 178 opisów zdolności**, także aktualną partię zwierząt v2.
- Rust release lib: **60 testów PASS**; `cargo fmt --check`: PASS.
- Osobna aplikacja testowa macOS: PASS. `pnpm build:macos`: PASS, arm64, podpis ad hoc.
- Testy sprawdzają kolejność i stałą widoczność sekcji, zwykły i dodatkowy atak Cyngla,
  mieszane kości, zakres każdej składowej, kompatybilność historii, brak losowania
  fragmentów błędnych wyrażeń i brak traktowania ST celu jako premii atakującego.

## Natywne sprawdzenie macOS

Aplikacja testowa 0.25.1, baza z poprzedniej wersji, okno 1100×760.

- Dodano jedną kopię Cyngla do slotu 5 wyłącznie w QA. Cechy były widoczne przed
  parametrami bez otwierania statblocka. Układ sprawdzono wizualnie.
- „Nóż taktyczny — dodatkowy atak”: kliknięcie +9 → 1k20+9 = 21;
  kliknięcie kości → 1k6+5 = 11. Oba wpisy w logu slotu 5.
- Bolesny atak: 4k6 = 11, z nazwą Cyngla i zdolności w logu.
- Mieszane kości: 2k8+2k6+4 → [4,8,2,5] +4 = 23, z opisanymi rodzajami kości.
- Istniejący Megator w slocie 1: Zionięcie 6k8 = 17. RO KON ST 19 pozostało opisem celu;
  rzut obrażeń nie zużył Zionięcia ani akcji i nie zmienił PW.
- ⌘Q zakończyło aplikację. Po restarcie zachowane zarówno sześć dawnych rzutów,
  jak i pięć nowych, w tym mieszana formuła i wynik 23. Sprawdzono też zamknięcie okna.

Porównanie bazy QA: migracje 10→10, pięć slotów, aktorzy 9→10 (jawnie dodany Cyngiel),
historia rzutów 6→11, log 48→53 (dodanie Cyngla i cztery rzuty z kart).
Wszystkie stare logi i rzuty zachowane. Katalog 51, seed 51, przedmioty 299 i statusy 2
bez zmian. Dane poprzednich aktorów, snapshoty i zasoby zachowane; przy dodaniu Cyngla
istniejący zapis slotu 5 zaktualizował tylko `updated_at` jego dwóch wcześniejszych aktorów.
Pozostałe sloty bez zmian. `integrity_check`: ok; `foreign_key_check`: bez błędów.

## Dostarczenie i ograniczenia

Aplikacja 0.25.1 dostarczona do `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzedni build zachowany obok jako `NeuroAltar 0.25.0.app`; baza nie jest podmieniana.

- Rzuty obronne wykonuje wybrany cel ze swoimi premiami; tekst ST w opisie ataku nie wskazuje celu.
- Nieznane/opisowe premie i wyrażenia spoza składni pozostają tekstem. Obsługa własnych wpisów
  wymaga jawnego zapisu premii/formuły; nie wylicza brakujących danych z opisu.
- Ułatwienie, Utrudnienie, trafienie, krytyk i efekty pozostają decyzją MG.
- Stary build 0.25.0 nie obsługuje nowych mieszanych wpisów historii; kopia aplikacji nie
  oznacza gwarantowanego cofnięcia wersji danych. Bieżąca wersja czyta wcześniejszą historię.
- Ostrzeżenie Vite o pakiecie JS ponad 500 kB (około 614 kB); build ukończony.
  Podpis ad hoc, bez notaryzacji; nie testowano Intel ani Windows.

## Pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/dice.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/domain/dice.ts`
- `src/domain/ruleRolls.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/dice/ActorRoll.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/features/dice/RollText.tsx`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `src/features/statblocks/RuleText.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `src/services/actorDice.ts`
- `tests/combatPresentation.test.ts`
- `tests/dice.test.ts`
- `tests/ruleRolls.test.ts`
- `docs/POPRAWKI_0.25.1.md` — ten raport.
