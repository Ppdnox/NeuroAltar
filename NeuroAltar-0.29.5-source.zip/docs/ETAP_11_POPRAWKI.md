# Poprawki Etapu 11 — 0.12.1

## Zakres

- Wyniki trudności i podsumowania slotów pokazują najwyżej dwa miejsca po przecinku.
  Dane i progi są liczone z pełną precyzją; format nie nadpisuje zapisanego SP.
- „Karta potyczki — trudność” może być zwinięta. Stan rozwinięcia jest osobny
  dla slotów podczas sesji. Walkę można obsługiwać również przy zwiniętym panelu.
- Każdy slot ma mały pasek, procent i nazwę trudności. Wynik pochodzi z jego
  bieżących wpisów, a brak danych i niepoprawne wpisy są jawnie oznaczone.
- Aktualne SP na karcie ma widoczne pole, obramowanie, odstęp etykiety i fokus.
  Problem ze zrzutu był błędem stylowania pola, bez zmiany jego liczbowej wartości.
- Bestiariusz i formularz dodawania przeciwnika zbierają błędy konkretnych pól.
  Komunikat podaje numer przedmiotu/formuły/akcji i przyczynę; nie zgaduje, które
  dane MG chciał wpisać. Wykrywa także koszt przewyższający pulę lub zasób.
- Po zatwierdzeniu pierwszy błąd odsłania sekcję i ustawia kursor. Lista błędów
  pozwala przejść do każdej pozycji; wskazane kontrolki mają oznaczenie błędu.
  Pisanie nie przenosi kursora do innych pól. Niepoprawny formularz pozostaje.

## Dane i zakres bezpieczeństwa

Nie ma nowej migracji. Migracje 001–006, pięć slotów, autozapis, statusy, snapshoty
oraz identyfikator i ścieżka bazy pozostają. Baza użytkownika nie jest używana do
testów ani odtwarzana przy instalacji. Zachowano dotychczasowe reguły walidacji.
To poprawki zlecone do Etapu 11; nie rozpoczęto Etapu 12.

## Weryfikacja

- pnpm check: TypeScript, ESLint, Prettier; 169 testów w 31 plikach, wszystkie OK.
- cargo test --manifest-path src-tauri/Cargo.toml --release --lib: 32/32.
- cargo fmt --manifest-path src-tauri/Cargo.toml --check: OK.
- pnpm build:macos: produkcyjny bundle arm64 0.12.1; podpis ad hoc zweryfikowany.
- git diff --check i niezmienione migracje 001–006: OK.
- Nowe testy sprawdzają format bez zmiany progów, niezależność podsumowań slotów,
  identyfikację błędnego SP/poziomu, pełne ścieżki broni/formuły/akcji, koszty
  przekraczające pule i brak zapisu niepoprawnego szablonu.

## Test natywny

Osobna aplikacja i baza stage11-smoke. SP 20,123456 zachowało surową wartość,
a panel i pasek slotu pokazały 225,77%, SP36,12 i ratio2,26. Wizualnie sprawdzono
obramowanie/etykietę SP oraz pięć małych pasków. Zwinięty panel pozostawił walkę
widoczną; przełączenie do slotu2 i powrót zachowało jego zwinięcie.

„Gangus testowy” z pustym PW i SP−1 wyświetlił dwa konkretne błędy. Automatyczny
fokus trafił do PW; kliknięcie błędu SP skierowało go do SP. Po ich poprawieniu
utworzono broń z niepełną formułą i zamknięto jej sekcję. Zatwierdzenie odsłoniło
broń, wskazało Formułę1 i Typ obrażeń, a kursor trafił do formuły kości.
⌘Q zachowało formularz. Po wpisaniu „1k8 + 3” i „kłute” szablon zapisano.
Po poprawieniu formularza ⌘Q zakończyło proces. Restart zachował SP20,123456,
poziomy i wynik225,77%; sprawdzono też przycisk zamknięcia okna.
Baza użytkownika i jego Gangus/Konwojent nie były modyfikowane w testach.

## Dostarczenie i ograniczenia

Repozytorium docelowe: /Users/dominik/Desktop/Combat Tracker.
Punkt wyjścia: czysty commit 6665618. Zmiany przygotowane i testowane w osobnej
kopii, następnie stosowane po sprawdzeniu HEAD, czystości i zgodności drzewa Git.
Aplikacja docelowa: src-tauri/target/release/bundle/macos/NeuroAltar.app (0.12.1).
Poprzedni bundle zostaje jako NeuroAltar 0.12.0.app. Kopia aplikacji nie cofa bazy.

Stan zwinięcia jest preferencją bieżącej sesji; po restarcie panel otwiera się.
Dwumiejscowy wynik może zaokrąglić wartość tuż poniżej progu, ale nazwa nadal
wynika z dokładnego procentu. Komunikaty błędów zapisu dysku/konfliktu rewizji
nadal wymagają ponowienia zapisu, a nie wskazania pola. Podpis ad hoc, bez notaryzacji.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DECISIONS.md`
- `docs/ETAP_11_POPRAWKI.md`
- `docs/PRODUCT_SPEC.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/styles.css`
- `src/components/TemplateValidation.tsx`
- `src/domain/capabilitySchema.ts`
- `src/domain/difficulty.ts`
- `src/domain/enemy.ts`
- `src/domain/item.ts`
- `src/domain/itemDraft.ts`
- `src/domain/validation.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/EnemyForm.tsx`
- `src/features/difficulty/DifficultyPanel.tsx`
- `src/features/difficulty/SlotDifficulty.tsx`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/features/equipment/LoadoutFields.tsx`
- `src/features/resources/CapabilityFields.tsx`
- `src/stores/bestiaryStore.ts`
- `src/stores/combatStore.ts`
- `tests/difficultyPresentation.test.ts`
- `tests/templateValidation.test.ts`
