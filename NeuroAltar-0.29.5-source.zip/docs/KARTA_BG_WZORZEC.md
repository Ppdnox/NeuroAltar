# Karta BG — wzorzec struktury i źródła do Etapu 24

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.

## Decyzja MG (2026-09-12)

Przyszła karta BG w aplikacji ma być jak najbardziej podobna w strukturze do
`reference/karta-postaci-Neuro-2025-NEW-8-Interactive (1).pdf`.
Przejrzano wizualnie wszystkie cztery strony. PDF ma 436 pól formularza;
liczba ta nie oznacza liczby odrębnych mechanik ani kompletności obliczeń.
SHA-256: `95ae2f8edbe9a6ce39a8b5eb15f191434c01694167ba4a7241ff51b8417e99a4`.
Oryginał jest prywatnym, niezmienianym materiałem referencyjnym, poza Gitem i bundlem.

## Wdrożone w24B

Ekran główny otwiera listę trwałych kart i szkiców. Układ zachowuje grupy
cech/RO/umiejętności, wartości obrony i ruchu, biegłości oraz zdolności.
Kolumny przechodzą z trzech do dwóch i jednej zależnie od szerokości. Dane
postaci, portret, dziennik i rozwój mają własne sekcje. Inwentarz, zasoby,
zdrowie szczegółowe i pomoc w walce pozostają do kolejnych podetapów.

## Mapa układu

| Strona wzorca              | Grupy do odwzorowania w aplikacji                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| -------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1 — karta główna           | Sześć cech z modyfikatorami, RO i przypisanymi umiejętnościami po lewej; obok Premia Biegłości, Fuksy, Szybkość, Inicjatywa, Pasywna Percepcja, PW, Kości Wytrzymałości, rzuty przeciw śmierci, Wyczerpanie, Zranienia i narzędzia. Górna część środkowa: tożsamość, klasa/profesja, pochodzenie, doświadczenie/poziom i miejsce na portret. Dalej pancerz/TT i wyszkolenie. Prawa część: podręczne przedmioty, biegłości broni, broń biała, broń dystansowa z magazynkiem oraz zdolności/sztuczki. |
| 2 — plecak i zdolności     | Plecak: przedmiot, gamble, waga; sumy wagi uzbrojenia i pancerzy, amunicja i obciążenie. Obok rozwinięta lista zdolności/sztuczek z nazwą/opisem, ilością aktualną/maksymalną i odnowieniem.                                                                                                                                                                                                                                                                                                        |
| 3 — pozostałe dane postaci | Choroba z trzema stanami, lekiem i dawkami; fobia z efektem i przełamaniem; notatki, pierwsze spotkanie, znajomi, nowy obszar, przedmioty w jukach, amunicja i opis postaci (wzrost, waga, wiek).                                                                                                                                                                                                                                                                                                   |
| 4 — pomoc w walce          | Ściąga z podziałem na Ruch, Akcję, Akcję Bonusową, Darmową Interakcję i Reakcję.                                                                                                                                                                                                                                                                                                                                                                                                                    |

Zachować nazwy, grupowanie, hierarchię i sąsiedztwo sekcji z PDF-a. Na dużym
oknie dążyć do układu zbliżonego do karty. Na mniejszych oknach sekcje mają
układać się responsywnie z czytelną czcionką. Pola mają być natywnymi,
interaktywnymi kontrolkami, listami i obliczeniami, a nie obrazem strony PDF.
Nie ograniczać liczby broni/przedmiotów/zdolności do liczby pustych wierszy
papierowego wzorca. Nie rozdzielać tych samych zasobów między dwa źródła danych.
Krótki/długi odpoczynek i alarm pustego magazynka integrować z odpowiednimi sekcjami.

## Arkusz Google — sprawdzony dostęp do podglądu

[Kreator Postaci - Neuroshima d20](https://docs.google.com/spreadsheets/u/0/d/137RLC2ZDwV0xkeSpJsDW0x2YzdmvEr8C3U0-pCQBdPM/htmlview#gid=2130375812).
W przeglądarce odczytano podgląd HTML. Wskazany gid prowadzi do Sztuczek.
Zakładki: Kalkulator Cech, Karta Postaci, Sztuczki, Choroby i Fobie,
Pochodzenie - zdolności, Klasy i Profesje.

Próbki odczytu: kalkulator cech i ich modyfikatorów, pola i wyniki karty,
tabela wymagań/korzyści sztuczek, opisy zdolności pochodzenia, rozwój sześciu klas
(Brutal, Cwaniak, Spec, Twardziel, Złodziej, Zwiadowca). To przydatny kandydat
na pomocnicze źródło tabel i przykład zależności danych dla Etapu 24A.

Bezpośredni eksport XLSX zwrócił HTTP 401, eksport przez przeglądarkę błąd
pobierania. Nie pozyskano formuł, walidacji ani skryptów i nie przetestowano
przeliczania po zmianie wejść. Widok karty zawiera #N/D! przy PW i części
biegłości, a klasa/profesja są niewybrane; nie ustalono przyczyny tych błędów.
Tytuł arkusza sam nie potwierdza zgodności z wersją podręcznika używaną w projekcie.

Arkusz ułatwi pozyskanie uporządkowanych tabel, ale nie dowodzi kompletności
mechaniki, obsługi wagi/amunicji/odpoczynków ani poprawności wyjątków. Przed
użyciem obliczeń sprawdzić formuły i zgodność z podręcznikiem. PDF karty określa
strukturę; arkusz jest źródłem pomocniczym; podręcznik służy do weryfikacji zasad.
Nie wprowadzać synchronizacji Google Sheets ani importera runtime przez samo
użycie tego źródła. Niniejsza notatka nie oznacza wdrożenia karty ani importu danych.

## Kryterium Etapu 24A

Przygotować mapę wszystkich sekcji/pól wzorca do modelu i widoków aplikacji,
z odsyłaczami do reguł, źródłami tabel, listą braków i testów. Uwzględnić
pełną mechanikę gry także tam, gdzie karta lub arkusz jej nie opisują.
Kolejność nadal: 23 odbiór Panelu MG, 24A–24E karta BG na macOS, 25 Windows.

## Uzupełnienie Etapu 24A — mapa pól do modelu i etapów

Ponowna kontrola wizualna wszystkich4stron:2026-09-13; fingerprint PDF bez zmiany.
Poniżej każda grupa pól wzorca ma właściciela, regułę i podetap. Powtórzone
wiersze broni/zdolności i sumy są widokami kolekcji, nie osobnymi niezależnymi
danymi.436pól technicznych AcroForm nie przenosimy jako436kolumn SQL.

| Strona / pola                                                          | Dane / obliczenie                                    | Etap i próba odbioru                                                                               |
| ---------------------------------------------------------------------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| 1: imię,portret,klasa/profesja,pochodzenie,poziom,PD                   | Character.identity/advancement                       | B; szkic,awans,wieloklasowość BG-02…08,41                                                          |
| 1: cechy,modyfikatory,B/S,RO,18umiejętności                            | baseScores,ProficiencyGrant,derivedChecks            | B; BG-01,09–11; modyfikatory niewpisywane drugi raz                                                |
| 1: PB,Fuksy                                                            | derivedPB,tokeny źródło/termin                       | B/D; BG-05,28; B/S mnożnik nie globalne podwojenie każdej PB                                       |
| 1: szybkość metry/kwadraty,inicjatywa,PP                               | derivedSpeed,m/1,5,initiativeBonus,perception        | B/E; BG-12,23; wynik inicjatywy tylko Participation                                                |
| 1: PW max/aktualne,KW max/użyte,rzuty przeciw śmierci                  | Character.vitals,KW oddzielne pule                   | B/D/E; BG-07,08,20,21; zmiana klasy nie leczy                                                      |
| 1: Wyczerpanie,Zranienia                                               | levels/causes,effects; statusy menu                  | D/E; BG-18,19; aktywna walka pokazuje nakładkę bez duplikowania                                    |
| 1: narzędzia i ich B/S                                                 | ProficiencyGrant+lista narzędzi                      | B; BG-10,22zestawy oraz instrumenty; lista dłuższa niż papierowe wiersze                           |
| 1: pancerz,nazwa,TT,maks.ZRC,Utrudnienie,wyszkolenie                   | InventoryEntry/rulesProfile,derivedArmor             | B/C; BG-13,14; suma nie jest niezależnym edytowalnym TT                                            |
| 1: podręczne3pola,biegłości broni,bronie białe                         | location/weaponCategory/weaponProfile                | C/E; BG-15,24; karta ma również kategorię specjalną z podręcznika mimo jej braku w checkboxach PDF |
| 1: dystansowa,nazwa,atak,obrażenia,zasięg,właściwości,pocisk,magazynek | profile/selectedGrip/fire/ammo,Magazine              | C/E; BG-15,16,26,27; klikalne testy i obrażenia                                                    |
| 1–2: zdolności/sztuczki,opis,max/aktualne,odnowienie                   | rule choices,resources,derived values                | B/D/E; pełny katalog nazw, nie tylko pięć wpisów; opis rozwijany, częste przyciski stale dostępne  |
| 2: plecak,przedmiot,gamble,waga                                        | InventoryEntry i location                            | C; BG-24,25; cena zakupu i bieżąca wycena odrębne                                                  |
| 2: sumy broni/pancerzy,amunicja,aktualne/użytkowe/maks.obciążenie      | derivedWeight/encumbrance i widokAmmoStock           | C; BG-22,25; brak podwójnego liczenia, brakujące masy wskazane                                     |
| 3: choroba,3stany,lek,dawki                                            | Disease/effects i powiązane zapasy leków             | D; BG-34,35,37; hemofilia nie dostaje fikcyjnych stanów ostrych                                    |
| 3: fobia,efekt,przełamanie                                             | Phobia/conditions/consecutiveSuccesses               | D; BG-36; wiele fobii możliwe, ta sama pula sukcesów na obu ekranach                               |
| 3: notatki,znajomi,pierwsze spotkanie,nowy obszar                      | journal,opcjonalne powiązanie z PD entry             | B/D; BG-41; zapis notatki nie przyznaje automatycznie PD                                           |
| 3: juki,przedmiot,gamble,waga,amunicja                                 | external location i te same InventoryEntry/AmmoStock | C; P-10; juki nie obciążają BG, dopóki ich nie niesie                                              |
| 3: wzrost,waga,wiek,opis                                               | identity; masa ciała oddzielnie od sprzętu           | B; jednostki i opcjonalne losowanie s.56; Q-02 dotyczy zdrowia/wieku                               |
| 4: Ruch,A,B,I,R i przykłady                                            | rules help + Participation budgets                   | E; aktualne wyjątki zdolności; opis pomocy nie zużywa akcji                                        |

Układ szeroki zachowuje sąsiedztwo grup z PDF. Przy zwężaniu kolumny przechodzą
w czytelne sekcje; powiększenie tekstu bez obcinania i bez zmniejszania pisma,
żeby zmieścić papierową stronę. Własna oprawa aplikacji, bez kopiowania logo,
ilustracji czy fontów źródła. Portret lokalny dobrowolny; brak kont i usług sieciowych.
Braki prowadzą do pola, listy stanów rozwijane, ważne statystyki widoczne od razu.
Mechaniczne limity rzeczy pod ręką pozostają rzeczywistymi limitami, natomiast
liczba pustych wierszy w PDF nie ogranicza całego posiadanego inwentarza.

Źródła obliczeń i wymagane testy: [KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md),
modele: [KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md).

### Dodatkowy element względem PDF — Kolor gry

Na życzenie MG (2026-09-13) w prawym górnym rogu przy tożsamości/poziomie
pojawia się selektor „Kolor gry”, z N/D i czterema Kolorami. Na wąskim oknie
przechodzi pod nagłówek. To świadome rozszerzenie wzorca PDF. Powiązanie:
Character.rulesContext, macierz COL-01…12; szczegóły
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md). Zmiana selektora najpierw pokazuje
wpływ na postać, nie nadpisuje wcześniejszych awansów ani danych bez podglądu.
