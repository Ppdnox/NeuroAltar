# Etap 8 — Bestiariusz (0.9.0)

## Rezultat

Osobny widok Bestiariusza: tworzenie szablonu bez aktora, podgląd, edycja,
duplikowanie, potwierdzane usunięcie z katalogu, wyszukiwanie nazwy i zdolności
oraz łączne filtry kategorii i rozmiaru. Wyszukiwanie rozpoznaje polskie znaki
również po wpisaniu ich odpowiedników bez znaków diakrytycznych.

Edytor obejmuje pola wdrożone w Etapach 3, 6, 7: nazwę, kategorię, rozmiar,
TT/PW, ruch, Zranienia, Tchórzliwość, zasoby i zdolności z opisami/kosztami.
Współdzieli pola ze wcześniejszym formularzem przeciwnika.

Dodaj ×N tworzy 1–100 niezależnych kopii w wybranym slocie, jednym checkpointem
oraz transakcją walki. Każda ma nowe UUID, pustą inicjatywę, własne pełne liczniki
zasobów i prepared snapshot. Edycja lub usunięcie katalogu nie zmienia istniejących
postaci, ich snapshotów ani logu. Karta walki może nadal kopiować własny stary wzorzec.

## Dostarczenie

Repozytorium docelowe: `/Users/dominik/Desktop/Combat Tracker`.
Przed zmianami czyste drzewo Etapu 7: `5ecd53c`.
Kod i testy przygotowano w izolowanej kopii tego commita, następnie zastosowanie
weryfikuje niezmieniony HEAD, czystość repo i zgodność końcowego drzewa Git.
Docelowa aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.9.0.
Poprzedni bundle pozostaje jako `NeuroAltar 0.8.0.app`.
Baza użytkownika nie była otwierana ani zmieniana w ramach testów i dostarczenia.

## Migracja i ochrona danych

Nowa migracja **006_bestiary.sql** dodaje do enemy_templates kolumny revision
i deleted oraz indeks katalogu. Nie zmienia migracji 001–005 ani rekordów aktorów,
statusów, logów, snapshotów i pięciu potyczek. Zostanie zastosowana automatycznie
przy pierwszym uruchomieniu nowej aplikacji. Nie kasuje ani nie odtwarza bazy.

Usunięcie z katalogu ustawia deleted=1. Fizyczny rekord zachowuje referencje;
ponowny autozapis aktora nie wskrzesza wpisu. Zapis szablonu ma kontrolę wersji,
walidację TS/Rust i idempotentne ponowienie po niepewnym wyniku IPC.
Istniejący aktor jest sprawdzany względem własnej historycznej kopii wzorca,
a jego tożsamość, template_id i slot pozostają niezmienne.

Formularz zachowuje niepełne dane. Błąd zapisu pozostawia dokładną mutację do
ponowienia lub jawnego odrzucenia. Zamykanie czeka na rozpoczęty zapis katalogu,
ujawnia niedokończony formularz i zachowuje dotychczasowe zabezpieczenia walki.

## Testy i build

- `pnpm check`: TypeScript, ESLint, Prettier, **115 testów / 23 pliki — zaliczone**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **24/24**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: zaliczone.
- `pnpm build:macos`: zbudowano **arm64 0.9.0**, podpis ad hoc.
- `codesign --verify --deep --strict`: kontrola bundle'a przed i po dostarczeniu.
- `git diff --check`; migracje 001–005 bez zmian.

Nowe testy obejmują wyszukiwanie/filtrowanie, kopię konfiguracji i kosztów,
identyfikatory duplikatu, grupowe dodawanie, niezależność PW/zasobów/snapshotów,
blokadę niepoprawnego slotu, błędy formularza, retry i zamknięcie.
Rust sprawdza konflikt rewizji, idempotencję, rollback, nienaruszalność kopii
aktorów, zapis po edycji/usunięciu katalogu i zachowanie danych migracji 006.
Usunięcie katalogu i reset po takim usunięciu zweryfikowano automatycznie.

## Test natywny

Osobna aplikacja/baza `pl.neuroshima.combat-tracker.stage8-smoke`:

- Pusty katalog i utworzenie „Żmija Łąkowa”, Bestia, Średni, TT 15, 88 PW,
  ruch „Chód: 9” oraz „Wspinaczka: 4,5” w osobnych wierszach.
- Dodaj ×3 do slotu 1: trzy karty 88/88 PW, bez inicjatywy, trzy wpisy składu.
- Edycja katalogu do „Żmija Łąkowa — weteran”, 99 PW, nie zmieniła trzech kart.
  Zmiana pierwszej karty do 78/88 PW oraz inicjatywy 13 zapisała się po tej edycji.
- Puste maksymalne PW odrzucone; ⌘Q nie zamknęło formularza. Po poprawie można
  było zatwierdzić dane i normalnie zakończyć proces przez ⌘Q.
- Wyszukanie „zmija lakowa” znalazło polską nazwę. Duplikat uzyskał własne 101 PW,
  oryginalny wzorzec zachował 99 PW. Filtr Człowiek dał 0/2, Bestia 2/2.
- Restart zachował oba szablony, trzy karty, 78/88 i 88/88 PW, inicjatywę 13,
  ruch i historię. Podgląd katalogu pokazał oddzielne 99 i 101 PW.
- Sprawdzono wygląd pól i przycisków. Otwarcie potwierdzenia usunięcia oraz
  „Zachowaj szablon” zachowały katalog. Przycisk zamknięcia okna zakończył proces.

## Ograniczenia przed Etapem 9

- Brak profili broni, awarii, trudności, importerów, kości i liczenia amunicji.
  Dalsze sekcje statblocka powstają zgodnie z etapami; brak seeda prywatnych danych.
- Limit jednego Dodaj ×N to 100; katalog jest lokalny, bez importu/eksportu.
  Usunięte wzorce są ukryte bez UI kosza; przechowują referencje istniejących kopii.
- Szkic formularza nie przetrwa wymuszonego zabicia procesu. Zwykłe zamykanie
  i ⌘Q są chronione. Konflikt wymaga odczytu aktualnego katalogu przed nową edycją.
- **Nie używać aplikacji 0.8.0 i starszych na bazie po edycjach Bestiariusza 0.9.0.**
  Starszy zapis walki porównuje instancje do katalogu; kopia bundle'a nie cofa bazy.
- Podpis ad hoc bez notaryzacji Apple. FinderInfo dopisane przez Pulpit może wymagać
  usunięcia wyłącznie tego atrybutu z wygenerowanego bundle'a przed kontrolą podpisu.
- Etap 9 wymaga nowego zlecenia.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_8.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/006_bestiary.sql`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/bestiaryRepository.ts`
- `src/domain/bestiary.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/EnemyForm.tsx`
- `src/services/prepareAppClose.ts`
- `src/stores/bestiaryStore.ts`
- `src/stores/combatStore.ts`
- `tests/bestiary.test.ts`
- `tests/prepareAppClose.test.ts`
