# NeuroAltar 0.29.4 — układ pulpitu

## Zakres

- Wspólna nawigacja Start / Panel MG / Karta BG korzysta z istniejącej kontroli zapisu przed zmianą obszaru.
- Karta BG: boczne menu, zwarty wybór i zarządzanie postacią, nazwa i Kolor nad paskiem wartości, dwie kolumny sekcji. Mniejsze okna: menu nad treścią, następnie jedna kolumna.
- Potyczki: kompaktowe sloty z istniejącymi paskami trudności, lewa kolumna od 1050 px. Działają strzałki poziome i pionowe oraz skróty ⌘1–5. Historia pozostaje rozwijana, a na bardzo szerokim ekranie znajduje się po prawej.
- Ekwipunek BG: wyraźne karty pozycji i ostrzeżenie pustego magazynka, zachowane przeładowanie przy magazynku.
- Zachowano aktualną kolorystykę papieru, rdzy i turkusu oraz regulację rozmiaru tekstu.

## Pliki i dane

App.tsx i styles.css; CharacterWorkspace.tsx, character.css i inventory.css; EncounterWorkspace.tsx; numery wersji package.json, Cargo.toml, Cargo.lock i tauri.conf.json; README, AGENTS i DECISIONS.

Bez migracji SQL, zmian schematów, mechaniki, seedów ani danych użytkownika. Istniejące formularze, rzuty i odnośniki walidacji pozostają w swoich sekcjach. Duża różnica tekstowa CharacterWorkspace wynika z wcięcia treści pod nowe kontenery układu. Etap 24E i port Windows pozostają poza zakresem.

## Weryfikacja

Pełne pnpm check: 407 testów, typy, lint i formatowanie OK. Rust: 82 testy OK; cargo fmt OK. Końcowy build i odbiór opisano poniżej.

Końcowy build macOS i weryfikacja podpisu lokalnego: OK. Native QA na osobnej bazie: karta BG i przejście do Ekwipunku, przeładowanie dostępne przy magazynku; okno około 747 px, standardowe 1100 px i powiększone; menu nad treścią / obok treści, boczne sloty, przełączenie strzałką w dół i End do slotu 5, zamknięcie i ponowne otwarcie. Ograniczono wysokość bocznej listy slotów, by ostatni był dostępny także w niskim oknie. Nie wykonywano operacji na produkcyjnej bazie.

Dostarczono `src-tauri/target/release/bundle/macos/NeuroAltar.app` 0.29.4; poprzednia 0.29.3 zachowana obok. SHA256 binarium: `b009e2a6ea328dca1918dc2b9d2d4cb88cba191dc6b17c8b5e9853221b9a5d3d`.

Ograniczenia: build nadal zgłasza duży pakiet JS; aplikacja podpisana lokalnie, bez notaryzacji Apple. Pełny zakres automatyzacji BG pozostaje zadaniem 24E. Test wizualny obejmował standardowe powiększenie tekstu; nie stanowi pełnego audytu dostępności.
