# Etap 24E — stan bieżący, 2026-11-08

Baza dalszych prac: **24E Roboczy / 0.29.4**, z poprawkami UI, zasobów i ikon
z 5 listopada. Aktualny [status](STATUS.md) rozdziela wdrożenie od odbioru.
Truciciel i Pogromca: zaakceptowane ręczne rozliczenie produkcji na podstawie
opisu; nie są brakami do implementacji. Przygotowanie Windows zostało zlecone
osobno; pełny odbiór sesyjny 24E nadal pozostaje otwarty.

## Archiwum raportów 24E

Poniższe datowane wyniki i uwagi o niedostarczeniu buildu dotyczą ówczesnych
stanów. Nie opisują obecnego miejsca dostarczenia ani aktualnej listy braków.
Nie przenoś historycznych zadań do backlogu bez sprawdzenia bieżącego STATUS.

## Aktualizacja 2026-10-21 — mechanika i opisy 24E Roboczego

Wdrożone uzupełnienia i weryfikacja: [POPRAWKI_24E_MECHANIKA_3.md](POPRAWKI_24E_MECHANIKA_3.md). Obowiązuje decyzja MG: premie sytuacyjne (np. Mój wróg) pozostają ręczne, a zdolności fabularne opisowe. Nie traktować ich jako braków automatyzacji wymagających dalszych presetów. Dodatkowe kości Twardości/Amen/Kota mają osobną obsługę wyniku i zasobu; nie są przerzutem k20. Pełny odbiór sesyjny 24E pozostaje oddzielnym krokiem.

Starsze wpisy poniżej opisują stan historyczny; aktualny zakres tej partii podaje powyższy raport.

# Etap 24E — stan prac, bez końcowego odbioru

Punkt wyjścia: 0.29.4, commit 6c95af9. Zmiany są w lokalnym checkoutcie.
Nie podmieniono aplikacji użytkowej i nie podniesiono wersji wydania.

## Zaimplementowane do weryfikacji

- Jawne podłączenie opublikowanej karty BG do aktora w potyczce, podgląd,
  jeden aktywny udział i wiele przygotowanych; trwałe zdrowie/inwentarz pozostają
  własnością karty. Reset nie odnawia zasobów karty.
- Budżety czynności, koszty wybranych zasobów i obsługi amunicji, efekty czasowe,
  zapis z kontrolą rewizji i trwałym identyfikatorem operacji.
- Rzuty kontekstowe, Ułatwienia/Utrudnienia, ręczne wyniki, inicjatywa zapisywana
  do potyczki, krytyki Stali i Brutala; naturalna 1 opróżnia broń w Chromie.
- Jawne rozliczenie obrażeń, leczenia, krwawienia i rzutów przeciw śmierci.
- Decyzje MG: Chrom nadal przegrzewa broń; jedno Zranienie na cios; łącznie
  1 PW krwawienia na turę. Aktywny udział blokuje powtórne rozliczenie krwawienia
  lub RO przeciw śmierci w tej samej turze, także po ponownym otwarciu.
- Naprawa formatu nowych wpisów logu wykryta podczas próby natywnej.

## Dane

Nowa migracja 014 dodaje character_participations i participation_operations.
Migracje 001–013 nie są zmieniane. Pięć slotów pozostaje zachowane.
Kopie baz wykonano przed testem; testy natywne korzystają z osobnego identyfikatora
aplikacji i bazy stage24d-smoke. Migracja nie została uruchomiona na bazie użytkowej.

## Potwierdzone sprawdzenia

- pnpm check: 412 testów w 62 plikach, typy, lint i formatowanie poprawne.
- Rust: 86 testów, w tym jednokrotne rozliczenie krwawienia i RO w turze.
- Natywna próba: podłączenie pełnej karty do slotu 4, rzut i trwała inicjatywa,
  rozpoczęcie udziału, zamknięcie i ponowne otwarcie aplikacji testowej.
- Budowa aplikacji testowej macOS wykonana; końcowy odbiór jeszcze niezamknięty.
- Próba zdrowia w natywnej aplikacji: krytyczne 22 obrażenia w Rdzy przy 22 PW
  dają 0 PW i dokładnie jedno Zranienie. Krwawienie przy 0 PW zapisuje jedną
  porażkę RO; druga próba w tej samej turze została odrzucona. Odczyt po błędzie
  zachował wersję 42 z jedną porażką, bez ponownego ubytku.
- Po ostatnim buildzie i ponownym uruchomieniu zachowano 0 PW, jedno Zranienie
  i jedną porażkę RO. Przycisk krwawienia pozostaje wyłączony dla rozliczonej
  tury. Podpis lokalny aplikacji testowej przeszedł codesign --verify --deep --strict.

## Zmiana zakresu na polecenie MG

Towarzysze przeniesieni do przyszłego backlogu w ROADMAP. Nie są już częścią 24E.
Wykreślono: automatyczne przerywanie Berserka przez stany, dalszą automatyzację
zacięć i przegrzania, integrację leków z walką oraz konwersję starego BG w nową
pełną kartę. Nie usunięto dotychczasowych ręcznych funkcji ani powiązania
z istniejącą kartą. Testy odbiorcze odłożono na czas po zakończeniu buildu.

## Bieżąca implementacja zdolności i spójności

Wspólny moduł characterRolls obsługuje cechy, RO, umiejętności i broń w karcie
oraz potyczce. Ustawienia Ułatwienia/Utrudnienia i ręcznej kości są wspólne dla
postaci. Oba widoki uwzględniają te same aktywne efekty, Wyczerpanie, pancerz
i obciążenie. Dodatkowe kości obrażeń uczestniczą w mnożniku krytyka.

Panel zdolności pokazuje posiadane zdolności, sztuczki i zasoby. Gracz wybiera
cel spośród aktywnych BG, potwierdza warunki sytuacyjne, koszt oraz efekt.
Dla zasobów o określonym koszcie wymagany rodzaj akcji nie może zostać usunięty.
Zużycie zasobu, budżetu i dodanie efektu zapisują się atomowo, także gdy cel
jest inną kartą BG. Dostępne są limity raz na turę/rundę, premia liczbowa,
Ułatwienie/Utrudnienie, dodatkowe kości obrażeń i wygaśnięcie ręczne/czasowe.
Jednorazowy efekt jest usuwany w transakcji zapisu pasującego rzutu.

To jawne rozliczanie zdolności, a nie automatyczna ocena zasięgu, trafienia,
wszystkich sytuacji w fikcji lub stanu celu. Gracz podaje sytuacyjne parametry
zgodnie z zasadą. Automatyczny wybór efektu wszystkich profesji nie jest
potwierdzony; lista posiadanych reguł nie jest dowodem automatyzacji każdej z nich.

## Sprawdzenia bieżącej zmiany

Wyniki 412/86 powyżej dotyczą poprzedniej wersji roboczej, przed bieżącymi
zmianami zdolności. Nie przedstawiać ich jako testów nowego panelu.
Bieżący zakres podlega kontroli kompilacji i formatowania. Pełne testy
mechaniki, regresji, interfejsu oraz odbiór macOS pozostają odłożone zgodnie
z decyzją MG. Nie podmieniono jeszcze użytkowej wersji 0.29.4.

## Bieżące sprawdzenie techniczne po zmianie zakresu

TypeScript, lint oraz kompilacja Rust (cargo check --release): poprawne.
Zbudowano interfejs (pnpm build). Nie uruchamiano pełnego zestawu testów
ani nowych prób natywnych po zmianie zakresu.

Gotowe ustawienia obejmują m.in. kości Wściekłego i Bolesnego ataku,
premię Dobrej rady, TT Inteligentnej obrony, jawne leczenie Kondychą,
wybór Akcji/Bonusowej dla Zrywu i przerzut ostatniego zwykłego testu
Szczęściem z zachowaniem Ułatwienia/Utrudnienia. Przerzut inicjatywy
pozostaje w jej osobnej, atomowej obsłudze; przycisk Szczęścia nie zmienia
inicjatywy. Efekty czasowe wskazują turę używającego zdolności.

Zmiany źródeł: characterRolls, CombatAbilities, CharacterCombatRolls,
CharacterWorkspace, combatAbility, participation, conditionModel/condition,
derive, dice/diceHistory oraz character_condition, character_participation,
dice po stronie Rust. Nie dodano kolejnej migracji ponad roboczą 014.

## Korekty czytelności Panelu MG — 2026-09-20

- Usunięto dopisek „0 PW — decyzja należy do MG.” oraz długi komentarz o limitach
  zdolności. Wspólna korekta prezentacji ukrywa ten komentarz także w zapisanych
  szablonach i instancjach, bez zmiany źródłowych danych.
- Karta potyczki pokazuje wyłącznie procent wyniku, zaokrąglony do pełnych procentów;
  usunięto SD/SP/iloraz, nazwy trudności i dużą skalę. Zachowano edycję poziomów BG,
  komunikaty brakujących danych i miniaturowy pasek slotu (również z pełnymi %).
  Obliczenia domenowe i progi trudności pozostają bez zmian.
- Bestiariusz: „Zranienia: możliwe” zamiast początkowego poziomu toru.
- Wiedza MG: wszystkie akapity zasad stale widoczne, bez zwijania zależnego od
  długości. Wyróżniono nazwy właściwości, rozdzielono wiersze i zachowano papierową
  kolorystykę. Osobno rozwijany pozostaje jedynie odsyłacz do źródła.
- Stopka zawiera podpis Made by Dominik "Polakko" Stanisławski, pseudonim kursywą.
- Pomoc opisuje aktualne skróty, wyszukiwarkę przeciwników, miejsce rzutu inicjatywy,
  roller, krytyki, ręczne awarie oraz rozliczanie zdolności BG.

Pliki: App.tsx, presentation.ts, BestiaryWorkspace.tsx, CombatWorkspace.tsx,
DifficultyPanel.tsx, SlotDifficulty.tsx, KnowledgeWorkspace.tsx, knowledge.css,
ShortcutHelp.tsx oraz niniejszy raport. Ta korekta nie dodaje migracji.
Typecheck, lint i build frontendu zaliczone. Pozostały ostrzeżenia bundlera
odnośnie rozmiaru paczki i współdzielonych importów. Pełne testy i odbiór wizualny
nadal odroczone zgodnie z decyzją MG. Wersja produkcyjna nie została podmieniona.
Build macOS „NeuroAltar 24E Roboczy.app” i weryfikacja podpisu lokalnego zaliczone.
Artefakt znajduje się w work/stage2-target/release/bundle/macos/ lokalnego projektu
ChatGPT Neuroshima 5e. Nie oznacza to pełnego odbioru 24E ani notaryzacji.

## Usunięcie panelu i poprawka powiązania — 2026-09-20

Na polecenie MG usunięto sekcję „Aktywna walka” z karty BG. Obsługa powiązanego
BG w samej potyczce pozostaje dostępna.

Wykryto błędną obsługę odświeżenia po zapisie powiązania: wcześniejsze wyzerowanie
pending przed odczytem kart mogło pozostawić blokady edycji bez możliwości ponowienia.
Operacja zachowuje teraz identyfikator aż do poprawnego odczytu wszystkich danych;
ponowienie używa tego samego ID, a backend zachowuje idempotencję. Błędy przygotowania
odblokowują edycję, błędy odczytu zachowują możliwość odzyskania. Odczyt udziałów nie
jest już połykany podczas zatwierdzania. Dodano widoczny komunikat trwającej operacji.

Cztery ukierunkowane testy obejmują poprawne powiązanie, błąd odczytu kart po zapisie,
błąd odczytu udziałów i wyjątek przygotowania. Zaliczone; pełny odbiór nadal odroczony.
Nie odtworzono jeszcze zgłoszonego zawieszenia w natywnym interfejsie użytkownika,
więc nie ma pewności, że znaleziony błąd był jedyną jego przyczyną. Bez nowej migracji
ani ingerencji w bazę użytkownika. Pliki: CharacterWorkspace.tsx, ParticipationPanel.tsx,
participationStore.ts, tests/participationStore.test.ts oraz ten raport.

## Potwierdzenie MG i audyt mechaniki — 2026-09-20

MG potwierdził działanie powiązania i wybrał build „24E Roboczy” jako podstawę dalszych prac. Nie wracamy do 0.29.4. Audyt źródłowy wykazał rozbieżności w premiach broni, budżecie serii i przeładowań oraz obsłudze części zdolności. Szczegóły: [AUDYT_24E_MECHANIKA.md](AUDYT_24E_MECHANIKA.md). Audyt nie oznacza jeszcze naprawienia wskazanych pozycji ani pełnego odbioru mechaniki. Bez nowych zmian kodu, migracji i buildu w tej turze.

## Aktualizacja 2026-09-24

Wdrożono pierwszą partię poprawek z audytu: [POPRAWKI_24E_MECHANIKA_1.md](POPRAWKI_24E_MECHANIKA_1.md). Raport rozróżnia naprawione obliczenia od pozostałych ograniczeń. Historyczna tabela audytu opisuje stan sprzed tej partii; 24E nie jest jeszcze ukończone.

## Druga partia uzupełnień — 2026-09-24

Ulubiona broń, wybór przerzutu Szczęścia, efekty wielocelowe, wybrane presety zdolności i efekty przeciwników zostały rozszerzone. Bieżący zakres, dowody i jawne ograniczenia: [POPRAWKI_24E_MECHANIKA_2.md](POPRAWKI_24E_MECHANIKA_2.md). Historyczna lista rozbieżności nie oznacza, że każda pozycja pozostaje nietknięta; raporty partii 1 i 2 określają aktualny stan. Pełny odbiór 24E nadal przed nami.

## Decyzja MG i poprawki czytelności — 2026-09-27

MG uznał obecne przerzuty za wystarczające oraz wykreślił automatyczne łączenie kilku efektów przeciwnika. Dokładny zakres pozostałego przeglądu zdolności: [24E_BRAKI_ZDOLNOSCI.md](24E_BRAKI_ZDOLNOSCI.md). Poprawiono podział Karty BG, wybór trwałego modelu Ulubionej broni, jawną klasyfikację własnej broni i zakończenie Neo po trafieniu. Zakres i weryfikacja bieżącej poprawki: [POPRAWKI_24E_KARTA_UI.md](POPRAWKI_24E_KARTA_UI.md). Pełny odbiór 24E pozostaje otwarty.

## Kryterium zdolności — 2026-09-27

MG rozdzielił zdolności o mierzalnym skutku mechanicznym od fabularnych, które pozostają opisem dla gracza. Panel walki nie pokazuje już dowolnej pozycji katalogu w ogólnym formularzu premii; wybór jest ograniczony do istniejących ścieżek bojowych. Dalsza lista zdolności mechanicznych i opisy narracyjne wymagają osobnej weryfikacji względem podręcznika. Zmiana i jej ograniczenia: [POPRAWKI_24E_ZDOLNOSCI.md](POPRAWKI_24E_ZDOLNOSCI.md).

## Cechy i rzuty broni na Karcie BG — 2026-09-27

Sześć cech wraz z ich Rzutami Obronnymi i umiejętnościami zajmuje dwie kolumny na szerokim ekranie. Symbol tarczy wyróżnia RO. W ekwipunku przy profilu broni są osobne przyciski ataku i obrażeń; bonus i formuła pozostają widoczne do rzutu ręcznego. Atak broni palnej korzysta z dotychczasowego zapisu strzału, odejmuje naboje zgodnie z trybem i w aktywnej potyczce rozlicza także koszt akcji. Przycisk „Zapisz strzał” usunięto. Serie obszarowe zachowują własne rozliczenie bez testu trafienia. Usunięto wskazane przez MG objaśnienia masy i maksymalnych PW. Nie dodano migracji SQL. Pełny odbiór 24E pozostaje otwarty.

Sprawdzenia: `pnpm check` — 434 testy JS/TS, typy, lint i formatowanie zaliczone; `cargo test` — 88 testów zaliczonych; build macOS „NeuroAltar 24E Roboczy.app” oraz lokalny podpis `codesign --verify --deep --strict` zaliczone. Nie przeprowadzono w tej partii ręcznego odbioru natywnego interfejsu ani notaryzacji. Produkcyjnej aplikacji nie podmieniono.
