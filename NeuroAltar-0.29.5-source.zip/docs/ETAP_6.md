# Etap 6 — Zranienia i Tchórzliwość (0.7.0)

## Rezultat

Etap 6 obejmuje przeciwników: ręczne Zranienia 0–4, narastające konsekwencje,
ostrzeżenie po kolejnym Zranieniu i próg Tchórzliwości. Nowe pola szablonu i
niezależne pola instancji obejmują autozapis, log oraz przygotowanie/reset.
Krytyczny dodaje 1 Wyczerpania przy wejściu; zapis/reset/restart nie dodają go ponownie.
Ruch po karach jest podglądem, wpisane metry zachowane. BG mają dotychczasowy zakres.
Brak rzutów, zmiany PW, automatycznej śmierci/wycofania lub pomijania tur.
Nie wdrożono Etapu 7 ani dalszych modułów.

## Stan wyjściowy i dostarczenie

Docelowe repozytorium: `/Users/dominik/Desktop/Combat Tracker`.
Przed zmianami zweryfikowano czyste drzewo i checkpoint Etapu 5 `5c82f49`.
Implementacja i build powstały w izolowanej kopii tego commita. Zastosowanie
zmian do folderu docelowego sprawdza brak nowych zmian użytkownika i zgodność
końcowego drzewa Git z przetestowaną kopią. Commit Etapu 6 opisuje ten raport.
Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.7.0).
Poprzedni bundle pozostaje obok jako `NeuroAltar 0.6.0.app`.
Bazy użytkownika nie otwierano ani nie modyfikowano podczas testów/dostarczenia.

## Migracje i zgodność

Bez nowej migracji SQL: nowe opcjonalne pola mieszczą się w istniejących JSON
szablonu, runtime i snapshotów. Migracje 001–005 są niezmienione. Stare dane bez
pól oznaczają wyłączone Zranienia i brak progu. Ręczne statusy nie są migrowane.
Nadal dokładnie pięć slotów, ten sam identyfikator aplikacji/adres SQLite i
atomowy zapis statusów, runtime, baseline, revision oraz logu.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier oraz **100 testów / 20 plików**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **19/19**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: poprawne formatowanie.
- `pnpm build:macos`: build macOS arm64, bundle 0.7.0, podpis ad hoc.
- Domenowe: stopnie, 4→5→4 bez dodatkowego Wyczerpania, ponowne 3→4, limit 6,
  wyłączenie toru, minimum ruchu, initial critical, niezależne kopie/snapshoty,
  reset, stare dane, niepoprawne pola i dokładny próg nawet dla dużych PW.
- Persistence: reopen SQLite, legacy templates, błąd logu wycofuje również
  Zranienia i Wyczerpanie, retry, brak duplikacji warning, izolacja pięciu slotów.
- Store: kolejność szybkich akcji, błąd zapisu/ponowienie, blokada zamknięcia
  przy 101%, korekta, restart i reset do przygotowanego Krytycznego/Wyczerpania.
- Natywnie w osobnej aplikacji `pl.neuroshima.combat-tracker.stage6-smoke`:
  „Żółw spod mostu”, 88 PW, TT 15, próg 50%, wielowierszowy ruch z przecinkiem.
  Poziomy 0→4 dały jedno Wyczerpanie, ruch 9→3 i 4,5→0, blokady Reakcji/Bonusowych.
  45 PW bez warning, 44 PW z warning na karcie i w kolejce oraz jednym wpisem logu.
  Kolejne Zranienie dało ostrzeżenie o śmierci, a aktor mógł rozpocząć turę.
  Cofnięcie ostrzeżenia pozostawiło jedno Wyczerpanie. Przygotowany stan przetrwał
  Cmd+Q i restart: 44/88 PW, inicjatywa 12, aktywna tura, Zranienia 4, Wyczerpanie 1,
  próg 50%, log i oryginalny ruch. Błędne 101% zatrzymało Cmd+Q i pozostało edytowalne.
  Po korekcie normalne Cmd+Q i przycisk zamknięcia zakończyły proces.
- Testy resetu wykonano automatycznie; natywnie sprawdzono zapis/odczyt prepared.
  Po smoke poprawiono wyłącznie numer etapu i opisy walidacji/potwierdzeń; finalny
  build zawiera te poprawki. Prywatne reference pozostaje ignorowane.

## Ograniczenia przed Etapem 7

- Reakcje/Akcje Bonusowe są teraz przypomnieniami. Przyszłe liczniki muszą korzystać
  z wyliczonych ograniczeń bez zmiany bazowych statystyk.
- Wpisuj ruch przed karami Zranienia i Wyczerpania; pozostałe stany rozstrzyga MG.
- Obniżenie/wyłączenie Zranień nie usuwa uzyskanego Wyczerpania. Korekta jest osobna.
- Stara aplikacja 0.6.0 nie rozumie nowych pól zapisanych w 0.7.0. Kopia bundle
  służy zachowaniu poprzedniej wersji, nie jest mechanizmem cofania bazy.
- Podpis ad hoc, bez notaryzacji Apple (jak wcześniej). Nieprawidłowe szkice są
  chronione przy zwykłym zamknięciu, ale nie przy wymuszonym zabiciu procesu.
- Użytkownik musi osobno zlecić Etap 7.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_6.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/enemy.ts`
- `src/domain/injury.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/EnemyForm.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/injuries/InjuryPanel.tsx`
- `src/stores/combatStore.ts`
- `tests/enemyDatabase.test.ts`
- `tests/injury.test.ts`
- `tests/injuryStore.test.ts`
