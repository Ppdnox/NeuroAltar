# Etap 24C — inwentarz, masa i amunicja BG

Data: 2026-09-13. Wersja: **0.28.0**. Punkt wyjścia: `3a4e677`
(ukończony24B, czysty Git przed rozpoczęciem prac). Zmiany wprowadzono
bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`.

## Funkcje

- Własny inwentarz każdej karty, niezależny od szkicu rozwoju. Kopie z katalogu
  299 przedmiotów i własne pozycje; ilość/jednostka, cena zapłacona, opis,
  źródło, masa i jej uzasadnienie, pojemniki, wyposażenie, plecak i juki.
- Zagnieżdżanie pojemników bez cykli; masa pustego pojemnika plus składniki
  albo masa agregatu. Zestaw startowy zgodny z pierwszą klasą, przyznawany raz
  jako plecak z pełnym opisem i masą. Broń, pancerz i narzędzia klasy dodaje
  się osobno według wybranej alternatywy — przycisk nie przyznaje ich w ciemno.
- Masa w całkowitych miligramach, ilość w tysięcznych jednostki. Naboje tylko
  całkowite; magazynek/broni egzemplarz ma ilość1. Masa luźnych i załadowanych
  naboi naliczana raz, juki poza obciążeniem. Nieznane masy prowadzą do edytora
  konkretnego przedmiotu; brak pełnej masy oznacza niepełny wynik obciążenia.
- Udźwig użytkowy/maksymalny i obniżenie Szybkości; limit3 przedmiotów pod ręką,
  4 przygotowanych broni białych,3 dystansowych. Więcej broni mieści się w plecaku.
- Jawne profile62 broni i17 pancerzy/akcesoriów z podręcznika, przypisane po ID
  do kopii BG. Katalog MG i bronie przeciwników pozostają niezależne.
  Własne profile można uzupełnić w edytorze; niekompletnych reguł nie zgadujemy
  z nazwy. Wagi przybliżone/n.d. wymagają decyzji MG, także pancerze wspomagane.
- TT z jednej dozwolonej podstawy i dodatków, limit Zręczności, wymagania Siły,
  wyszkolenie, kary pancerza, Trening w zbroi i Obsługa pancerza. Hełm/tarcza
  wyłączają odpowiednie formuły bez pancerza; tarcza nie daje stałego +5TT.
- Podstawowe profile ataku/obrażeń z biegłością, wyborem cechy finezyjnej,
  wariantem obrażeń i trybem ognia. P1/dublet2/KS3 i jawne progi DS/MS.
  Serie nie dodają modyfikatorów obrażeń. Pełne efekty sytuacyjne walki należą24E.
- Oddzielne ładowanie naboi, rozładowanie do wskazanego zapasu, wymiana
  kompatybilnego magazynka i przeładowanie mechanizmu. Szybkie palce pozwalają
  pominąć mechanizm; pokazane są koszty czynności. Pusta broń blokuje strzał.
- Podgląd i zatwierdzenie każdej operacji; nabycie/korekta wymagają powodu.
  Edytor zachowuje niepoprawny tekst, blokuje zamknięcie i wskazuje pole.
  Trwała historia operationId zabezpiecza przed podwójnym zużyciem przy retry.
  Po błędzie można odczytać aktualny zapis i przygotować nową operację.

## Decyzje MG wdrożone w tym etapie

1. Chrom domyślnie używa nieliczonego zapasu. Naturalna1 oznacza pustą broń;
   przeładowanie przywraca gotowość. Dokładny stan naboi i magazynków pozostaje
   zachowany. W24C jest to jawny przycisk, powiązanie z testem ataku nastąpi24E.
2. Środki lecznicze w Chromie kosztują połowę — w kalkulatorze MG i BG.
   Pozostałe ceny Chromu bez zmian. Historyczna kwota zapłacona nie zmienia się.
3. Gambling we krwi dodaje5 punktów procentowych **przed mnożnikiem Koloru**:
   `(baza + lokalizacja + premia) × Kolor`, następnie ograniczenie0–100.
   Bez premii none/none/none zwraca dokładne przedziały bazowe.

## Dane i migracja

Opcjonalne `Character.inventory` jest poza `sheet` i `draft`. Stare karty bez
inwentarza odczytują się jako puste bez automatycznego zapisu. Autozapis szkicu,
zatwierdzenie rozwoju, jego odrzucenie i archiwizacja nie mogą zmienić inwentarza.
Mutacja inventory wymaga gotowej karty bez szkicu rozwoju. TS/Zod i Rust
niezależnie sprawdzają dane, a Rust przelicza komendę i porównuje wynik z podglądem.

**Migracja012** rozszerza dozwolony rodzaj polecenia o inventory. Kopiuje wszystkie
kolumny dotychczasowej historii do tabeli z nowym ograniczeniem CHECK w ramach
migracji; nie usuwa wpisów historii, kart ani danych potyczek. Migracje001–011
pozostają niezmienione. Baza użytkownika nie była używana do testów ani odtwarzana.

W natywnym QA wykryto odrzucenie równoważnych liczb JSON `40.0` i `40`, obecnych
w przygotowanej kopii testowej. Poprawiono porównanie wartości liczbowych bez
rozluźnienia kontroli struktury/ID/tekstów, dodano regresję i ponowiono test.
Odrzucona operacja nie zmieniła stanu amunicji. Przestarzały proces QA zatrzymano
po odrzuceniu transakcji; finalny build zamknięto następnie normalnie.

## Weryfikacja

| Kontrola                                                          | Wynik                                                          |
| ----------------------------------------------------------------- | -------------------------------------------------------------- |
| `pnpm check`                                                      | PASS: TypeScript, ESLint, Prettier, **351 testów / 58 plików** |
| `cargo test --manifest-path src-tauri/Cargo.toml --release --lib` | PASS: **73 testy**                                             |
| `cargo fmt --manifest-path src-tauri/Cargo.toml --check`          | PASS                                                           |
| `pnpm build:macos`                                                | PASS, pakiet `.app` 0.28.0, podpis ad hoc                      |
| Git diff i migracje001–011                                        | Bez błędów diff; stare migracje nietknięte                     |
| Migracja24B→24C w izolowanej kopii SQLite                         | PASS, wersje1–12, integrity_check=ok, foreign_key_check puste  |

Nowe próby obejmują wszystkie299 kopii katalogowych, nieznane masy, dokładne
progi70/70,01/139,99/140kg, agregat i cykle, jednorazowość zestawu, konflikt
wyposażenia, kompatybilność/pojemność magazynka, transfery i utratę masy po strzale,
Chrom i zachowanie starego zapasu, puste strzały, DS12, przeładowanie mechanizmu,
ujemny modyfikator Zręczności, brak premii obrażeń w seriach, zakresy cen,
Gambling przed Kolorem, retry, konflikty i rollback wraz z historią.

Natywna aplikacja QA używała własnego identyfikatora `stage24c-smoke` i kopii
bazy24B. Potwierdzono przez interfejs: odczyt istniejącej karty, plecak22kg,
własny przedmiot1,5kg z polskim przecinkiem, błędną masę z zachowaniem wpisu,
blokadę Cmd+Q przy formularzu, podgląd i zapis, ładowanie1 naboju bez zmiany
masy, strzał1→0 i blokadę kolejnego, przełączenie na nieliczony zapas,
przeładowanie/strzał/naturalną1 bez zmiany29 zapisanych naboi, normalne Cmd+Q
oraz ponowne otwarcie z tym samym stanem. Skontrolowano końcowy układ w oknie1100×760.
Do próby amunicji dodano jawny fixture w zamkniętej, izolowanej bazie QA.

Porównanie wszystkich kolumn tabel Panelu MG z bazą24B: bez zmian5 potyczek,
7 aktorów,52 szablony,32 wpisy walki,51 wpisów seeda Bestiariusza,299 przedmiotów,
1 wpis partii Ekwipunku,6 rzutów i tabela statusów. Kontrola po zamknięciu:
5 pozycji inwentarza QA,29 naboi luźnych, cinematicLoaded=false.

## Dostarczenie i dalszy zakres

Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzednia0.27.0 zostaje obok jako `NeuroAltar 0.27.0.app`.
Nowy pakiet przechodzi kontrolę podpisu przed podmianą i po niej.
Nie uruchamiano produkcyjnej bazy użytkownika; migracja nastąpi przy otwarciu.

- Następny, osobno zlecany: **24D — zasoby i odpoczynki**.
- **24E:** połączenie BG z potyczką i rollerem, budżet akcji, jam bez utraty
  amunicji, ograniczenia rundy, pełne efekty sytuacyjne i odbiór całej karty.
  Nie trzeba odejmować amunicji za zacięcie: należy anulować zapis strzału.
  Przegrzewanie Chromu pozostaje pytaniem do integracji24E.
- Produkcja, zużywanie leków, odpoczynki i zasoby nie zostały uruchomione tym etapem.
- Windows nadal na końcu (25). Brak notaryzacji Apple, jak w poprzednim wydaniu.
  Nie dodano amunicji przeciwników, automatycznych obrażeń ani nowych slotów.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/KARTA_BG_KOLORY.md`
- `docs/KARTA_BG_KONTRAKT.md`
- `docs/KARTA_BG_MECHANIKA.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/character.rs`
- `src-tauri/src/character_tests.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/item.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/domain/character/catalog.ts`
- `src/domain/character/model.ts`
- `src/domain/market.ts`
- `src/features/character/CharacterWorkspace.tsx`
- `src/stores/characterStore.ts`
- `tests/characterStore.test.ts`
- `tests/market.test.ts`
- `docs/ETAP_24C.md`
- `src-tauri/migrations/012_character_inventory.sql`
- `src-tauri/src/character_inventory.rs`
- `src/data/character/equipment-profiles.v1.json`
- `src/domain/character/equipped.ts`
- `src/domain/character/inventory.ts`
- `src/domain/character/inventoryCatalog.ts`
- `src/domain/character/inventoryModel.ts`
- `src/features/character/InventoryPanel.tsx`
- `src/features/character/inventory.css`
- `tests/fixtures/character-inventory.json`
- `tests/inventory.test.ts`
