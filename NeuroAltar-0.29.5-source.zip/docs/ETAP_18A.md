# Etap 18A — mutanci, NeuroAltar 0.20.0

Etap zrealizowany po zleceniu kolejnego punktu planu, po poprawce 0.19.3.
Stan wyjściowy rzeczywistego repo: czysty `3e1e8d2`. Repozytorium:
`/Users/dominik/Desktop/Combat Tracker`. Następny punkt: **18B — zwierzęta**,
wymaga osobnego zlecenia; Etap 19 to nadal ludzie.

## Co dodano

Siedem wpisów kategorii Mutanci, po jednym na źródłowy statblock.
Wpisy obejmują sześć cech, końcowe RO, umiejętności, zmysły, odporności,
Próg Obrażeń, ruch, Zranienia/Tchórzliwość tam, gdzie podano, zdolności stałe,
wykaz przedmiotów i wszystkie 31 zdolności z podziałem na rodzaje akcji.
Dane korzystają z obecnego, rozwijanego układu kart i formularzy.

| Wpis                                     | Strona drukowana / PDF | TT  | PW  | SP  | PB  |
| ---------------------------------------- | ---------------------- | --- | --- | --- | --- |
| Generacja I — Nocny ghul                 | 226 / 228              | 9   | 36  | 3   | +2  |
| Generacja II — Genotyp gadzi (Gadolud)   | 227 / 229              | 13  | 30  | 12  | +3  |
| Generacja II — Genotyp wilczy (Wilkolud) | 227 / 229              | 16  | 64  | 17  | +3  |
| Generacja III — Grubas                   | 228 / 230              | 16  | 72  | 16  | +3  |
| Generacja III — Techmutas                | 229 / 231              | 16  | 30  | 10  | +3  |
| Generacja III — Szpieg                   | 230 / 232              | 13  | 38  | 8   | +3  |
| Generacja IV — Mesmeryta                 | 231 / 233              | 19  | 112 | 75  | +5  |

Na pustej bazie: **30 szablonów** (11 maszyn, 12 potworów, 7 mutantów).
Interfejs pokazuje 31 pozycji z uwzględnieniem osobnej nakładki Zombie.
Filtr Mutanci pokazuje siedem wpisów. Własne szablony MG mogą zwiększać liczbę.

## Źródła i decyzje o odwzorowaniu

Prywatny `reference/NOE_dla_dominadiinteriapl.pdf`, Notatnik Łowcy,
strony drukowane 226–231 (PDF 228–233). Sprawdzono tekst i wyrenderowane strony,
zwłaszcza oddzielne kolumny Gadoluda i Wilkoluda. SHA256 pliku źródłowego:
`714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
Prywatny PDF, obrazy stron i ilustracje nie trafiły do repo ani aplikacji.

- Gadolud ma odporności na kłute, cięte, obuchowe i truciznę. Nie przypisano ich Wilkoludowi z sąsiedniej kolumny.
- Zachowano nietypowe wartości źródłowe: inicjatywa Wilkoluda −3 (7), Szpieg PW 38 (6k8 + 14), średnie i formuły obrażeń. Aplikacja nie poprawia podręcznika przez własne przeliczenie.
- TT Techmutasa 16 i Mesmeryty 19 już uwzględniają premię INT. RO Mesmeryty CHA +10 i ZRC +8 są wartościami końcowymi. Nie dodano premii ponownie.
- Nocny ghul, Techmutas i Szpieg nie mają wskazanego toru Zranień; w ich danych startowych pozostaje wyłączony. Brakujące RO, odporności i progi są N/D, nie zerem.
- Obrażenia radioaktywne Ugryzienia i trucizna Jadowitych zębów pozostają dodatkowymi składnikami opisów, a nie alternatywnymi trybami zastępującymi główne obrażenia.
- Łańcuch Grubasa ma opis ataku +9, zasięgu 3 m, RO SIŁ ST 17, wyzwolenia ST 20 oraz TT 19/PW 10 łańcucha. Źródło nie podaje obrażeń: Item nie otrzymał fikcyjnej formuły ani profilu wymagającego obrażeń. Pełne reguły są dostępne pod Akcją i w zestawie broni.
- Oszczep ma osobne profile wręcz i dystansowy 60/180 m; oba +9 z SIŁ. Opis wskazuje, że to sposoby użycia tej samej broni, nie dodatkowe sztuki. Nie dodano licznika amunicji.
- Dmuchawka Szpiega zachowuje stałe 4 obrażenia, bez wymyślonej kości. Zdolności psychiczne oparte na RO są opisowymi Itemami bez fikcyjnego Testu Ataku.
- Mesmeryta: Posiłki 2/dzień, Reakcja „Iluzoryczny cel” i trzy akcje legendarne na rundę, każda z kosztem 1. Budżety/zasoby korzystają z dotychczasowych reguł.
- Przy Ataku wielokrotnym jedna Akcja obejmuje pod-ataki rozliczane przez MG; użyte w nim Posiłki trzeba ręcznie odjąć z licznika. W osobnej akcji przycisk Posiłki odejmuje zasób i budżet razem. Przybycie 16 pająków / 2 łowców / 1 grubasa po 1k4 rundach oraz wataha 2k4 psów Wilkoluda są rozstrzygane ręcznie.

## Zapis i bezpieczeństwo danych

**Brak nowych migracji.** Pliki migracji 001–008 pozostają niezmienione.
Nowa partia `noe-mutants`, wersja danych 1, używa istniejących tabel katalogu
i rejestru danych startowych. Każdy wpis ma stabilne ID, stronę i SHA256 źródła.
Backend dodaje tę partię po maszynach i potworach, w osobnej transakcji.

Pierwsze uruchomienie dopisuje brakujące tożsamości. Ponowne uruchomienie nie
powiela wpisów. Nadal chronione są edycje MG, usunięcia, kolizje tożsamości,
wersje danych nowsze od aplikacji oraz instancje i snapshoty w potyczkach.
Korekta nową wersją danych może objąć tylko nietknięty wpis zgodny z wcześniejszą
wersją. Awaria trzeciej partii cofa jej transakcję i pozwala ponowić start,
bez utraty dwóch wcześniejszych partii.

Pliki `machines.v1.json` i `monsters.v1.json` są identyczne bajtowo z 0.19.3.
Nie zmieniono mechaniki, układu UI, pakietów zależności, identyfikatora aplikacji
ani ścieżki bazy. Testy korzystały wyłącznie z odrębnych baz. Baza użytkownika
nie została otwarta przez testy ani zastąpiona.

## Wyniki kontroli

| Kontrola                          | Wynik                                                     |
| --------------------------------- | --------------------------------------------------------- |
| `pnpm check`                      | PASS: TypeScript, ESLint, Prettier; 210 testów / 43 pliki |
| Rust `cargo test --release --lib` | PASS: 47 testów                                           |
| `cargo fmt --check`               | PASS                                                      |
| `pnpm build:macos`                | PASS: 0.20.0, macOS arm64, podpis lokalny ad hoc          |
| Istniejące partie i migracje      | Bez zmian                                                 |
| SQLite QA                         | integralność `ok`, brak naruszeń kluczy obcych            |
| `git diff --check`                | PASS                                                      |

Pięć nowych testów aplikacji sprawdza komplet danych i edycję przez formularze,
wyjątki źródłowe, wyliczenie premii ataków, niezależność zasobów/kopii i reset,
oraz nakładkę Death Breath z nowego mutanta. Dwa nowe testy Rust sprawdzają
transakcję trzeciej partii, błąd i retry, ochronę zmian/usunięć/kolizji,
bezpieczne korekty i brak cofania wersji, zachowanie pięciu slotów oraz
wcześniejszych wpisów, instancji, snapshotów i logów.

## Rzeczywisty test macOS

Aplikacja QA z osobnym identyfikatorem `pl.neuroshima.combat-tracker.readability-smoke`
i istniejącą bazą testową po 0.19.3:

1. Start 0.20.0, Panel MG, Bestiariusz: 31 pozycji z nakładką; filtr Mutanci — dokładnie 7. Przegląd pełnego statblocka Mesmeryty, końcowych RO, limitów i sekcji akcji.
2. Dodaj ×2 do slotu 3: dwie niezależne kopie, SP 150, inicjatywa początkowo pusta. Pierwsza otrzymała nazwę „Mesmeryta — próba Łódź” i inicjatywę 18.
3. Na pierwszej kopii użyto Posiłków, Iluzorycznego celu i Pokłoń się!: Posiłki 1/2, Akcja 0/1, Reakcja 0/1, Legendarne 2/3. PW nadal 112/112 i brak dodanych statusów. Druga kopia zachowała komplet budżetów i Posiłki 2/2. Skrót ⌥↓ zmienił tylko wybraną kartę.
4. Zapis polskiej notatki w dwóch wierszach. Edycja nazwy katalogowej Mesmeryty: próba `⌘Q` z formularzem wróciła do niezapisanego pola. Zatwierdzono nazwę „Mesmeryta — wersja MG QA”; istniejące kopie zachowały wcześniejszy szablon.
5. Oględziny karty walki i profili Grubasa: łańcuch bez fikcyjnych obrażeń, oba zasięgi oszczepu i poprawne +9.
6. Wyjście przez `⌘Q`, potwierdzenie zakończenia procesu, ponowne uruchomienie i wejście do slotu 3 przez `⌘3`: zachowane nazwy, inicjatywa, zużyte zasoby, notatki i edycja katalogu. Zamknięcie przyciskiem okna również zakończyło aplikację.
7. Porównanie kopii zamkniętej bazy ze stanem 0.19.3: zachowane wszystkie 23 wcześniejsze szablony, 3 wcześniejsze postacie wraz ze snapshotami, 15 wcześniejszych wpisów logu i pozostałe sloty. Jedynie slot 3 zmieniły celowe działania QA.
8. Porównanie bazy przed i po ponownym otwarciu: identyczne tabele katalogu, rejestru partii, postaci, logów i potyczek. Trzy partie liczą 11/12/7 wpisów; brak duplikatów i nadpisania edycji MG.

## Zmienione pliki

- `src/data/bestiary/mutants.v1.json` — nowa partia danych.
- `src-tauri/src/bestiary_seed.rs` — instalacja i walidacja kategorii partii; testy zapisu.
- `tests/mutantSeed.test.ts` — testy danych i użycia mutantów.
- `package.json`, `src-tauri/Cargo.toml`, `src-tauri/Cargo.lock`, `src-tauri/tauri.conf.json`, `src/app/App.tsx` — wersja 0.20.0, bez aktualizacji zależności.
- `README.md`, `README_FIRST.md`, `AGENTS.md`, `START_PROMPT_CODEX.txt`, `START_PROMPT_WORK.txt` — bieżący stan i granice dalszych zleceń.
- `docs/ACCEPTANCE_TESTS.md`, `docs/CODEX_INSTRUCTIONS.md`, `docs/WORK_INSTRUCTIONS.md`, `docs/DATA_MODEL.md`, `docs/DECISIONS.md`, `docs/PLAN_DALSZYCH_PRAC.md`, `docs/PRODUCT_SPEC.md`, `docs/ROADMAP.md`, `docs/TECH_SPEC.md` oraz ten raport — zakres, kontrakty, odbiór i następny etap.

## Dostarczenie i ograniczenia

Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app` (0.20.0).
Poprzednia wersja jest zachowana obok jako `NeuroAltar 0.19.3.app`.
Podpis jest sprawdzany przed podmianą i po niej. Commit:
`feat: add handbook mutants to bestiary`.

Build lokalny Apple Silicon, bez notaryzacji Apple; Intel i Windows nie były
budowane ani testowane. Wyniki testów baz dotyczą QA, nie uruchomienia nowej
wersji na prywatnej bazie MG. Nowi mutanci zostaną dopisani przy uruchomieniu
nowej aplikacji. Zachowane ograniczenia: bez rollera, auto-PW, auto-statusów,
licznika amunicji NPC i automatycznego przywoływania istot. Dalsze partie nie
zostały rozpoczęte. Następna: **Etap 18B — zwierzęta**.
