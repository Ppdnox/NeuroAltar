# Etap 1 — NeuroAltar 0.2.0

Wdrożono pięć stałych zakładek potyczek, niezależne nazwy i wielowierszowe notatki, autozapis SQLite oraz odczyt danych po restarcie. Zachowano styl papieru, turkusu, rdzy i metalu. Etap 2 nie został rozpoczęty.

## Obsługa

- Kliknięcie lub ⌘1–⌘5 przełącza slot; na zakładkach działają strzałki, Home i End.
- Autozapis następuje po 400 ms przerwy, opuszczeniu pola, przełączeniu slotu i przy zamykaniu aplikacji.
- Każdy slot ma własny szkic i kolejkę zapisu. Opóźniona odpowiedź nie nadpisuje nowszego tekstu.
- Pusta nazwa jest niepoprawna. Notatki oczekują na jej uzupełnienie. Błąd zapisu zachowuje tekst i udostępnia ponowienie.
- Zamykanie okna i ⌘Q czekają na zapis wszystkich slotów. Błąd zatrzymuje zamknięcie. Menu zakończenia aplikacji ma własną obsługę, ponieważ domyślne menu macOS omijało ochronę w teście natywnym.
- Restart przywraca zapisane dane i otwiera slot 1.

## Zmienione pliki

- `src/features/encounters/EncounterWorkspace.tsx`: zakładki, edytor, skróty, komunikaty zapisu i walidacji.
- `src/stores/encounterStore.ts`: ładowanie, szkice per slot, debounce, kolejki zapisu, ponowienia i zapis przy zamykaniu. Zastępuje usunięty `bootstrapStore.ts`.
- `src/domain/encounterDetails.ts`, `src/domain/encounter.ts`: typy i walidacja szczegółów; zachowanie wpisanej nazwy bez cichego obcinania spacji.
- `src/db/connection.ts`, `src/db/encounterRepository.ts`: parametryzowany zapis wyłącznie nazwy, notatek i daty aktualizacji, kontrola liczby zmienionych rekordów.
- `src/services/encounters.ts`, `src/services/closeGuard.ts`: serwis zapisu i integracja ochrony zamykania z Tauri.
- `src/app/App.tsx`, `src/app/styles.css`: podłączenie edytora, aktywna zakładka, niższy nagłówek i czytelny formularz.
- `src-tauri/src/lib.rs`: komendy i zdarzenia zamykania, menu zakończenia po zapisie.
- `src-tauri/capabilities/default.json`: uprawnienie do wykonywania zapytań SQLite.
- `package.json`, `src-tauri/Cargo.toml`, `src-tauri/Cargo.lock`, `src-tauri/tauri.conf.json`: wersja 0.2.0.
- `tests/encounterStore.test.ts`, `tests/encounterDetails.test.ts`, `tests/closeGuard.test.ts`: testy autozapisu, trwałości, błędów, kolejek i zamykania. Usunięto testy starego bootstrap store; ich przypadki ładowania obejmuje nowy zestaw.
- `tests/connection.test.ts`, `tests/helpers/database.ts`, `tests/validation.test.ts`: dostosowanie adapterów testowych.
- `README.md`, `docs/VISUAL_IDENTITY.md`, `docs/ETAP_1.md`: obsługa, architektura, wygląd i raport.

Schemat danych nie uległ zmianie. Wykorzystano pola migracji 001; identyfikator aplikacji, adres bazy i pięć istniejących slotów zachowano. Prywatny `reference/` pozostaje ignorowany przez Git i nie jest częścią paczki.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i **43 testy Vitest — poprawne**.
- Testy obejmują szybkie wpisywanie, niezależność slotów, opóźnione zapisy, błąd i ponowienie, pustą nazwę, zamykanie podczas zapisu, walidację oraz ponowne otwarcie rzeczywistego pliku SQLite.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: poprawne.
- `pnpm build:macos`: poprawny build Tauri dla Apple Silicon.
- `codesign --verify --deep --strict`: poprawny podpis ad hoc.
- Natywny test macOS: nazwy i polskie notatki wielowierszowe dwóch slotów, przełączenia ⌘1–⌘5, strzałka 5→1, restart, blokowanie ⌘Q i przycisku zamknięcia przy pustej nazwie, zapis po jej poprawieniu — poprawne.
- Dane użytkownika przywrócono po teście; zmieniły się jedynie daty aktualizacji dwóch testowanych slotów. `PRAGMA integrity_check`: `ok`.
- Archiwum ZIP sprawdzone przez `unzip -t`.

## Ograniczenia i ryzyka

- Paczka jest dla macOS 13.3+ na Apple Silicon, podpisana lokalnie ad hoc, bez notaryzacji Apple. Windows i Intel nie były budowane.
- Wymuszone zakończenie procesu lub utrata zasilania mogą utracić jeszcze niezapisany tekst. Zwykłe zamknięcie okna i ⌘Q są chronione i przetestowane.
- Pusta nazwa blokuje zapis całego szkicu danego slotu, również notatek; komunikat wyjaśnia sposób poprawy.
- Nie dodano aktorów ani mechaniki walki — to zakres kolejnych etapów, wymagających osobnej zgody.
