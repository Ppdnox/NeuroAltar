# UI GUIDELINES

## Zaakceptowany układ „Stół gracza + Tryb sesji” — 2026-11-04

Ten kierunek zastępuje układ z 21 października. Jasny papier, turkus, rdza,
ochra i grafit pozostają bez zmian.

- Jedna lewa nawigacja aplikacji: Start, Karta postaci, Panel MG i biblioteki.
  Bez drugiego pionowego menu sekcji karty.
- Karta BG: tożsamość, poziomy pasek PW / TT / Inicjatywa / Szybkość,
  główne zakładki Broń / Testy / Zdolności / Ekwipunek.
- Zdrowie i odpoczynek, postój, podsumowanie i rozwój są dostępne w nawigacji
  dodatkowej. Szkic i błędy walidacji mają pierwszeństwo przed domyślnym widokiem.
- Najnowszy rzut postaci pojawia się pod zakładkami. Historia pozostaje
  w rollerze, a naturalne 1/20 zachowują dotychczasowe wyróżnienie.
- Broń: wyraźne przyciski ataku i obrażeń oraz magazynek obok przeładowania.
  Broń i Ekwipunek współdzielą jedną instancję formularzy i operacji.
- Panel MG: nagłówek potyczki, pięć poziomych slotów, pasek rundy i tury,
  kolejka inicjatywy obok karty uczestnika. Sloty nie tworzą drugiego menu bocznego.
- Cechy z testami mają dwie kolumny przy odpowiedniej szerokości; RO zachowują
  tarczę. Małe okno i powiększony tekst mogą przełączyć układ na jedną kolumnę.
- Nawigacja nie zmienia stanu gry. Polecenia, autozapis i ochrona niezapisanych
  formularzy pozostają aktywne. Zmiana UI nie wymaga migracji ani nowych zasad.

Raport: [UI_STOL_SESJI_2026-11-04.md](UI_STOL_SESJI_2026-11-04.md).

## Poprzedni układ roboczego 24E — 2026-10-21

Historyczne reguły tego wdrożenia; nowsze ustalenia powyżej mają pierwszeństwo:

- Zachowujemy papierową kolorystykę, turkus, rdzę i skalowanie tekstu.
- W zatwierdzonej Karcie BG tożsamość jest zwięzłym nagłówkiem, a pola edycyjne pozostają w szkicu. Siedem sekcji zachowuje swój zakres. Zmiana sekcji prowadzi do początku jej widoku.
- Cechy wraz z podległymi testami mają dwie kolumny, jeśli rzeczywista szerokość karty na to pozwala. Klikalny wynik jest oddzielony od rozwijanych składników i wyboru cechy; RO oznacza tarcza.
- Stan magazynka i przeładowanie są obok siebie. Szczegóły zapasu, wymiany oraz konserwacji broni rozwija się na żądanie; aktywny problem broni pozostaje widoczny.
- PW, Zranienia, Wyczerpanie i KW mają osobne kafle. Rozliczanie zdrowia, zasoby i odpoczynek tworzą odrębne grupy.
- Sloty potyczek są zwarte i poziome w standardowym oknie; boczna lista pojawia się dopiero na szerokim ekranie. Na wąskim ekranie sloty przewija się poziomo.
- Inicjatywa i karta stoją obok siebie od 46rem dostępnej szerokości panelu. Węższy panel ma ograniczoną wysokość kolejki, aby nie wypychać całej karty poniżej składu.
- Trudność domyślnie pokazuje pełny procent; rozwinięcie odsłania poziomy BG, błąd zawsze otwiera panel. Statblock przeciwnika nadal jest widoczny przed parametrami i notatkami.
- Karta uczestnika ma skróty PW i TT / Cechy / Akcje / Statusy / Awarie stosownie do typu. Skróty tylko przewijają i ustawiają fokus, bez zmiany tury ani stanu gry.
- W szerokim i wysokim oknie karta ma własne przewijanie. Małe okno korzysta z przewijania strony. Log pozostaje rozwijany pod kolejką i kartą.
- Zmiany wyglądu nie zmieniają reguł, handlerów poleceń, autozapisu, migracji ani zapisanych postaci.

Raport tej poprawki: [POPRAWKI_UI_24E_2026-10-21.md](POPRAWKI_UI_24E_2026-10-21.md).

## Cel
Obsługa przy stole ma być szybsza niż papier.

## Klimat
NeuroAltar: papier kości słoniowej i grafitowy metal, turkusowe nagłówki, rdzawe akcenty i krótkie pasy ochra/grafit. Szczegóły: `docs/VISUAL_IDENTITY.md`. Tekst i dane na spokojnym, jasnym tle. Faktura wyłącznie dekoracyjna, o niskiej intensywności. Własne CSS i SVG inspirowane podręcznikiem; bez kopiowania oprawy 1:1.

## WALKA
Góra: 5 slotów + runda + Next Turn.
Lewa: inicjatywa.
Środek/prawa: aktywny aktor.
Log: zwijany panel dolny lub prawa dolna sekcja.

## Priorytet aktora
Zawsze widoczne: nazwa, HP, TT, inicjatywa, ruch, statusy, injury, resources, główne akcje.
Rozwijane: cechy, RO, skills, senses, resistances, traits, items.

## Akcja
Nazwa + premia + zasięg + ikona kości + formuła + typ obrażeń + krótki efekt.
Pełny opis po rozwinięciu.
Ikona kości nie uruchamia rzutu.

## HP
Duże cyfry. Najczęstsze akcje bez menu `...`.

## Alarmy
Tchórzliwość, Awaria, 0 PW, krytyczny Injury: widoczne, ale nie blokujące.

## Difficulty
Ciągły kolorowy pasek + zawsze tekst SD/SP/%/etykieta.

## Dostępność
Focus states, sterowanie klawiaturą, dobry kontrast, nie polegać wyłącznie na kolorze.


## Etap 13 — obsługa przy stole (0.14.0)

Skróty Alt/⌥+↑/↓ wybierają karty w kolejności inicjatywy, z postaciami bez wyniku
na końcu, bez zawijania na skraju. Nie zmieniają tury ani danych. Pola edycji,
kompozycja tekstu, dodatkowe modyfikatory, przytrzymanie i otwarty formularz
blokują skrót. „Pokaż bieżącą postać” ustawia fokus na jej karcie.
F1/przycisk otwierają pomoc modalną; Escape zamyka pomoc i nie anuluje formularza.
Spacja zachowuje ochronę kontrolek; także formularz przeciwnika blokuje turę.
Skróty slotów oraz walki nie działają pod modalem pomocy.
Log domyślnie zwinięty przy wejściu do slotu; podsumowanie pokazuje ostatni wpis.
Rozwinięcie nie usuwa/odświeża liczników, zapis logu trwa niezależnie od widoku.
Błąd odczytu odsłania historię i ponowienie. Stan rozwinięcia pozostaje lokalny.
Pasek rundy jest przyklejony podczas przewijania walki, lecz statyczny w oknie
niższym niż 581px. Lewa inicjatywa przyklejona tylko na szerokim/wysokim ekranie.
Nagłówek bardziej zwarty, oprawa papier/turkus/metal zachowana; fokus kontrolek
czytelny. Brak nowej mechaniki, migracji i skrótów usuwających dane.

## Zaplanowane interfejsy po Etapie 14

Etap 15: ekran główny z wejściem do Panelu MG i zapowiedzią karty BG. Jasny powrót
na ekran główny; dotychczasowe moduły wewnątrz Panelu MG. Zapowiedź mówi wprost,
że karta nie jest jeszcze dostępna. Zachować fokus, szkice i globalny close guard.

Roller: wynik tekstowy, składowe i suma, historia, bez 3D. Jawny przycisk Rzuć;
wyświetlenie statblocka lub zmiana karty nie wykonuje rzutu. Brak auto-odejmowania PW.
Wiedza MG: prawdziwe tabele z nagłówkami/jednostkami/przypisami i wyszukiwaniem.

Pełna karta BG po porcie Windows: wartości pochodne pokazują składniki, ręczna
korekta odróżniona od obliczenia. Ilości i masa czytelne; brak wagi daje informację
o niepełnej sumie. Przy magazynku 0 tekst „Pusty magazynek — przeładuj”, również
po restarcie, bez polegania wyłącznie na kolorze. Krótki/długi odpoczynek pokazuje
zasoby, które zmieni. Oba systemy zachowują dostępne skróty i polskie etykiety.

## Etap 16 — statblock i docelowy slot

Statblock w zwijanej sekcji karty i wspólnym podglądzie Bestiariusza. Tabela sześciu cech, modyfikatorów i końcowych RO; na wąskim ekranie może przewijać się poziomo. Opisy zachowują nowe wiersze i warunki. Formularz pokazuje jednoznaczne nazwy pól i linki do błędów. Pięć radio opcji docelowej potyczki jest stale widocznych, z nazwami i wyraźnie zaznaczonym wyborem.

## Czytelność 0.19.1

Treść wykorzystuje dostępną szerokość okna. Bazowy rozmiar tekstu rośnie płynnie
od 16 do 20 px; przyciski Tekst zwiększają go dodatkowo do 115/130/150% wartości
Auto. Preferencja pozostaje lokalna i nie zmienia bazy ani zapisów potyczek.
Przy węższym obszarze kolumny układają się pionowo. Kafle cech pokazują osobno
wartość, modyfikator i końcowy RO. Reguły i zdolności są pełne, w osobnych kartach;
sekcje akcji można zwinąć. Źródła i pochodzenie premii są rozwijane. W Bestiariuszu
broń i warianty mają osobną rozwijaną sekcję; w Walce profile pozostają dostępne.
Nie skracaj warunków mechanicznych ani nie traktuj źródeł jako nowych zasad.

## Karta walki 0.19.2

Pula i przyciski każdej akcji nad jej zdolnościami; pełne opisy rozwijane osobno.
Wspólne profile broni są w grupie Akcja, bez automatycznego przypisania kosztu
broni. Zwięzły podgląd ruchu/statusów i alarmy przed akcjami. Dodatkowe pola
edytowalne po rozwinięciu. Karta ma własny scroll przy oknie od 950×650 px;
w mniejszych oknach przewijana jest strona. Formularz awarii przy wyzwalaczu,
z aktywnym polem k20; nie może dziedziczyć disabled z karty instancji.

## Statusy BG w panelu walki — 0.19.3

Wybór statusu bezpośrednio z menu na karcie aktora. Ustawienia czasu, poziomu,
opisu i źródła w formularzu pod menu; stan pojawia się po zatwierdzeniu.
Aktywne wpisy pokazują nazwę, poziom i czas; opisy są rozwijane. Własne statusy
i dawne notatki pozostają dostępne. Wspólny panel obsługuje też przeciwników.
