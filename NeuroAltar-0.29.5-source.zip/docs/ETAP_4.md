# Etap 4 — NeuroAltar 0.5.0

Etap 4 dodaje trwały log walki dla każdej z pięciu potyczek. Bazą jest czysty
commit Etapu 3 `94044bf`. Prace i testy wykonano w kopii roboczej; sprawdzony
commit oraz aplikacja są dostarczane bezpośrednio do
`/Users/dominik/Desktop/Combat Tracker`. Etap 5 wymaga osobnego zlecenia.

## Co zmieniono

- Log zapisanych zmian: PW i maks. PW, TT, nazwa, inicjatywa i remisy, ręczne
  statusy, ruch, dodawanie/usuwanie postaci, tury, rundy, przygotowanie i reset.
- Każdy wpis zawiera czas, rundę, identyfikator postaci (jeśli dotyczy), typ,
  czytelny opis oraz strukturalne wartości przed/po. Historia zachowuje nazwę
  usuniętej postaci. Zmiana nazwy lub usunięcie postaci nie przepisuje historii.
- Wpisy powstają w Rust w tej samej transakcji co stan walki. Błąd wpisu wycofuje
  również zmianę postaci, szablonu, punktu resetu, rundy/tury i rewizji.
- Kolejka autozapisu zachowuje pośrednie stany szybkich akcji, także obrażenia
  i leczenie kończące się wyjściową liczbą PW. Edycje tekstu nadal mają debounce;
  niepoprawne lub niezapisane szkice nie są rejestrowane jako zdarzenia.
- Widok pokazuje najnowsze wpisy i umożliwia odczyt starszych po 100. Kolejność
  wyznacza stabilne ID, również gdy wpisy mają identyczny czas. Błąd odczytu
  pokazuje komunikat i możliwość ponowienia, a stara odpowiedź nie nadpisuje nowej.
- Wyczyść log wymaga potwierdzenia i zapisanych danych walki. Czyści wyłącznie
  historię wskazanego slotu; zachowuje statystyki, skład, notatki, rundę/turę
  i snapshoty. Reset zachowuje historię i dopisuje zdarzenie resetu.
- Zaktualizowano dokumentację, instrukcje Codex/Work i wersję do 0.5.0.
  Brak nowych zależności. Dotychczasowe identyfikatory aplikacji i SQLite zachowane.

## Migracja 004

`004_combat_log.sql` tworzy wyłącznie tabelę `combat_log` i indeks kolejności
w obrębie potyczki. Migracje 001–003 pozostają bez zmian. Nie kasuje, nie odtwarza
ani nie resetuje istniejących danych i nie dopisuje wymyślonych zdarzeń historycznych.
ID aktora w logu celowo nie ma klucza obcego do instancji: wpis musi przetrwać
jej usunięcie. Potyczki nadal mają stałe ID 1–5.

Dostarczenie plików nie otwiera bazy użytkownika. Migracja wykona się przy pierwszym
uruchomieniu wersji 0.5.0. Testy migracji pracują na oddzielnych bazach testowych.

## Weryfikacja

- `pnpm check`: 85/85 testów Vitest w 15 plikach; TypeScript, ESLint i Prettier poprawne.
- Rust: 14/14 testów (`cargo test --manifest-path src-tauri/Cargo.toml --release --lib`).
- Sprawdzono wycofanie transakcji przy błędzie INSERT/DELETE logu, brak duplikatów
  przy konflikcie rewizji, izolację czyszczenia, zachowanie snapshotów i dalsze wpisy
  po wyczyszczeniu. Test migracji porównuje stare dane i sprawdza ponowny odczyt pliku.
- Testy kolejek obejmują szybkie akcje, retry po błędzie i zachowanie ich kolejności.
  Testy odczytu obejmują paginację i odrzucanie nieaktualnych odpowiedzi.
- `cargo fmt --check` i `git diff --check`: poprawne.
- Natywny test w osobnej aplikacji `pl.neuroshima.combat-tracker.stage4-smoke`:
  BG „Żaneta Łącka”, polskie i wielowierszowe statusy „Osłona / Przerażenie”,
  zapis zmian inicjatywy oraz PW 20 → 10 → 11 jako oddzielnych wpisów.
- Dwa szybkie przejścia tury zachowały rundy 2 i 3 oraz oba zdarzenia tury
  przy jednej postaci. Slot 2 pozostał pusty, a powrót do slotu 1 zachował log.
- Sprawdzono wyświetlenie potwierdzenia czyszczenia i Anuluj w UI. Faktyczne
  usunięcie wpisów i jego atomowość sprawdzono testami Rust/SQLite.
- ⌘Q zakończyło proces. Ponowne uruchomienie zachowało wszystkie wpisy,
  PW 11/20, inicjatywę 12, statusy, rundę 3 i aktywną postać. Zamknięcie
  przyciskiem okna również zakończyło proces. Obejrzano natywne okno 1100×760.
- `pnpm build:macos`: poprawny build produkcyjny macOS arm64 0.5.0.
- `codesign --verify --deep --strict`: poprawny lokalny podpis aplikacji.
- Aplikacja docelowa: `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
  Poprzedni bundle zachowany jako `NeuroAltar 0.4.0.app` w tym samym katalogu.
  Dostarczenie sprawdza czyste drzewo bazowe, zgodność patcha i drzewa końcowego.

## Ograniczenia przed Etapem 5

- Historia obejmuje zapisy dokonane przez wersję 0.5.0 i nowszą. Starsza aplikacja
  nie tworzy logu; do dalszej pracy należy używać aktualnego bundla.
- Ręczne edycje tekstu są scalane przez autozapis; log nie jest rejestrem każdego
  naciśnięcia klawisza. Wymuszone zabicie procesu może utracić szkice lub akcje,
  których zapis jeszcze się nie zakończył. Zwykłe zamykanie czeka na zapis.
- Po niejednoznacznym błędzie odpowiedzi IPC ochrona rewizji zapobiega powtórnemu
  zapisowi; szkic pozostaje do wyjaśnienia konfliktu. Nie dodano automatycznego merge.
- Czyszczenia historii nie można cofnąć w UI. Nie dodano eksportu ani backup GUI.
- Mechaniki czasu/efektów statusów, zranienia, zasoby, awarie i broń pozostają
  w kolejnych etapach; log tych pól będzie rozszerzany wraz z ich implementacją.
- Ekwipunek, Wiedza MG, Excel, rzuty i liczenie amunicji nie są częścią Etapu 4.
- Build macOS 13.3+ Apple Silicon ma lokalny podpis ad hoc, bez notaryzacji.
  Nie budowano Intel ani Windows. Nie przeprowadzano testów UI na bazie użytkownika
  ani pełnej kontroli wszystkich rozmiarów okna (osobny Etap UX).

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_3.md`
- `docs/ETAP_4.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `manifest.json`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/004_combat_log.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/combatLogRepository.ts`
- `src/domain/combatLog.ts`
- `src/features/combat/CombatLog.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/services/combat.ts`
- `src/services/combatLog.ts`
- `src/stores/combatLogStore.ts`
- `src/stores/combatStore.ts`
- `tests/combatLogDatabase.test.ts`
- `tests/combatLogStore.test.ts`
- `tests/combatStore.test.ts`
