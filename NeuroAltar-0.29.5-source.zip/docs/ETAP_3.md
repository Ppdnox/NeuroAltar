# Etap 3 — NeuroAltar 0.4.0

## Aktualizacja po dostarczeniu

Etap 3 zastosowano bezpośrednio w repozytorium na Pulpicie jako `94044bf`.
Drzewo było czyste; gotowy bundle 0.4.0 umieszczono w src-tauri/target/release/bundle/macos.
Poniżej zachowano raport tego wydania.

## Rezultat i dostarczenie

Etap 3 rozszerza działający Etap 2 (`358a865`) o przeciwników, ruch, jawne
przygotowanie punktu powrotu i reset potyczki. Nie rozpoczyna Etapu 4.
Przed pracą i końcowym zastosowaniem kontrolowane jest czyste drzewo bazowe.
Praca i testy odbyły się w kopii roboczej; sprawdzony commit jest przeznaczony
bezpośrednio do `/Users/dominik/Desktop/Combat Tracker`. Zastosowanie commita
nie otwiera ani nie zmienia bazy użytkownika. Migrację uruchamia aplikacja 0.4.0.

## Co zmieniono

- Wspólne Actor/ActorDraft zastępują model ograniczony do BG. Zachowane dotychczasowe
  pola, autozapis, remisy, rundy/tury, pięć slotów i wspólna ochrona zamykania.
- Podstawowy EnemyTemplate: nazwa, kategoria, rozmiar, bazowe TT/maks. PW i ruch.
  Formularz wymaga wpisania statystyk; nie dostarcza wymyślonych statblocków.
- Niezależne instancje z własnymi UUID, PW/TT, nazwą, inicjatywą, statusami i ruchem.
  Przycisk w karcie szablonu dodaje kolejną kopię jego danych bazowych.
- Ruch: nazwa sposobu i nieujemne metry, obsługa przecinka/kropki i wielu wierszy.
  Brak danych jest pustą listą, a 0 jawnie oznacza zerową szybkość.
- Potwierdzany zapis przygotowania kopiuje aktualny stan obecnych postaci, także
  częściowe PW, inicjatywy, ręczne remisy i statusy. Edycja runtime go nie nadpisuje.
- Potwierdzany reset odtwarza przygotowanie obecnego składu, rundę 1 i brak aktywnej
  tury. Zachowuje nazwę/notatki slotu, szablony i oryginalne snapshoty.
- Niedokończony formularz przeciwnika i błędny ruch blokują zamknięcie z możliwością
  poprawy. Formularz przed dodaniem jest szkicem w pamięci; wymuszone zabicie procesu
  może go utracić, podobnie jak ostatnie niezapisane edycje autozapisu.
- Ujednolicona dokumentacja i instrukcje Codex/Work, raport użytkownika o poprawnym
  otwieraniu/zamykaniu Etapu 2. Stabilny identyfikator aplikacji i URL SQLite.
- Brak nowych zależności. Wersja 0.4.0; przyszłe Item/Equipment/TradeContext bez zmian.

## Migracja 003

`003_enemy_instances.sql` dodaje tabelę `enemy_templates`, aktywny punkt resetu
`encounter_actors.reset_snapshot_json` i kontrolę odwołań do szablonu. Migracje 001/002
są identyczne z bazą. Dotychczasowy `prepared_snapshot_json` pozostaje niezmienny.
Przy braku nowego punktu resetu odczyt korzysta z oryginalnego snapshotu Etapu 2.
Żadne dotychczasowe statystyki, tury, nazwy/notatki ani snapshoty nie są resetowane
przy migracji. Nie kasowano i nie odtwarzano bazy użytkownika.

Jedna transakcja Rust/SQLx zapisuje nowe szablony, instancje, aktywne baseline,
rundę/turę i combat_revision. Każdy błąd wycofuje całość. Zapis nie aktualizuje
istniejącego szablonu i odrzuca kolizję danych jego ID. Usunięcie instancji nie usuwa
szablonu, a tożsamość aktora i pierwotny snapshot są chronione.

## Weryfikacja

- Pełne `pnpm check`: **79 testów Vitest w 13 plikach**, TypeScript, ESLint, Prettier.
- Rust `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **7/7**.
- Ochrona oryginalnych danych podczas migracji, odczyt po ponownym otwarciu pliku SQLite,
  niezależność trzech kopii, reset, częściowe PW, statusy/ruch, błędne pola, retry,
  konflikt wersji, obce ID/baseline i wycofanie transakcji obejmującej szablony.
- `pnpm build:macos`: poprawny build produkcyjny macOS arm64.
- `codesign --verify --deep --strict`: poprawny lokalny podpis ad hoc.
- `cargo fmt --check` i `git diff --check`: poprawne.
- Natywny smoke test w osobnym bundlu `pl.neuroshima.combat-tracker.stage3-smoke`
  z osobną bazą. Przeciwnik „Żmija pustkowi”, ruch wielowierszowy i ułamki z przecinkiem,
  statusy „Zatrucie / Przerażenie”, jawne prepare, kopia z bazowymi PW/ruchem,
  oddzielne inicjatywy 12 i 7, utrata PW i ruchu tylko pierwszej kopii.
- Natywny reset przywrócił przygotowane 19/28 PW, ruch 7,5/4,5 m i statusy pierwszej
  kopii, pozostawiając 28/28 PW i pustą przygotowaną inicjatywę drugiej.
- ⌘Q z wpisem `Chód:` pozostawiło okno otwarte, pokazało błąd i pozwoliło go poprawić.
  Po poprawie ⌘Q zakończyło aplikację. Ponowne uruchomienie zachowało obie instancje,
  PW, inicjatywę, statusy, ruch i stan tury. Zamknięcie przyciskiem okna również zakończyło proces.
- Sprawdzono wygląd natywnego okna 1100×760. Nie przeprowadzano pełnego przeglądu
  wszystkich rozmiarów ekranu; ten zakres pozostaje w Etapie UX.

## Ograniczenia przed Etapem 4

- Stare BG mogą mieć oryginalny punkt powrotu z domyślnymi PW 1/1. W karcie można
  go podejrzeć. Po sprawdzeniu bieżących statystyk należy jawnie zapisać przygotowanie
  przed pierwszym resetem. Nie zmieniamy automatycznie historycznego punktu powrotu.
- Reset zachowuje obecny skład: usunięte postacie nie są odtwarzane, a dodane później
  mają własny punkt przygotowania. Skład/log/wyczyszczenie potyczki i dalsze utwardzanie
  resetu pozostają zgodne z Etapem 12; log dopiero w Etapie 4.
- Bestiariusz ma na razie podstawowy szablon i dodawanie pojedynczych kopii z karty.
  Pełny CRUD, wyszukiwanie, filtry i Add ×N to Etap 8. Szablon bez obecnej instancji
  pozostaje w bazie, lecz jego katalog nie jest jeszcze dostępny w UI.
- Przyszły edytor szablonów musi zachować snapshoty istniejących instancji; aktualna
  komenda odrzuca próbę nadpisania szablonu. Kolejne pola statblocka wymagają rozbudowy
  typów i wersjonowanych danych zgodnie z roadmapą.
- Bez czasu/efektów statusów, zranień, zasobów, mechanik maszyn, broni, Ekwipunku,
  wiedzy, importu Excel, rzutów i liczenia amunicji.
- Build macOS 13.3+ Apple Silicon, lokalny podpis ad hoc bez notaryzacji. Intel i Windows
  nie były budowane. Nie uruchamiano wersji produkcyjnej na danych użytkownika.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_2.md`
- `docs/ETAP_3.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `manifest.json`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/003_enemy_instances.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/combatRepository.ts`
- `src/domain/combat.ts`
- `src/domain/enemy.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/EnemyForm.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/combat/saveLabels.ts`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/combat.test.ts`
- `tests/combatDatabase.test.ts`
- `tests/combatStore.test.ts`
- `tests/enemy.test.ts`
- `tests/enemyDatabase.test.ts`
- `tests/prepareAppClose.test.ts`
