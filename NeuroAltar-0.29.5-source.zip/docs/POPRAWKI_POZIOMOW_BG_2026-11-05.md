# Usuwanie ostatniego poziomu BG — 2026-11-05

Przycisk „Usuń ostatni poziom” przeniesiono z wnętrza ostatniej rozwijanej
sekcji poziomu obok „Dodaj kolejny poziom do szkicu”. Jest widoczny także,
gdy wszystkie wyższe poziomy są zwinięte. Przycisk działa w edytowanym szkicu;
przy jednym poziomie oraz podczas blokady zapisu pozostaje nieaktywny.
Zatwierdzoną kartę najpierw otwiera się przez „Edytuj kartę / awansuj”.

Zachowano istniejącą operację usuwania ostatniego elementu `levels`,
autozapis i przeliczanie pochodnych wartości. Nie dodano potwierdzenia ani
uzasadnienia. Brak zmian w regułach, aktualnych PW, zasobach, wyposażeniu,
backendzie oraz schemacie bazy. Nie wykonano migracji.

Weryfikacja: `pnpm check` — typy, lint, formatowanie i 488 testów OK;
`cargo test --release --lib` — 93 testy OK; frontend i oba natywne buildy
macOS (QA oraz 24E Roboczy) — OK. Zachowane znane ostrzeżenia bundlera
o mieszanych importach. Podpis aplikacji ad hoc; bez nowej notaryzacji.

Test natywny w osobnej bazie: na poziomie 1 przycisk jest widoczny i nieaktywny;
dodanie poziomu 2 pozostawia go zwiniętego, a przycisk usuwania jest aktywny.
Kliknięcie bez rozwijania poziomu usuwa poziom 2 i przywraca blokadę minimum 1.
Zamknięcie zapisuje szkic z jednym poziomem — potwierdzone odczytem bazy QA.

Pliki: `src/features/character/CharacterWorkspace.tsx` oraz ten raport.
Kopia aplikacji i bazy użytkownika: `work/level-removal-2026-11-05` w środowisku
roboczym. Przed podmianą użytkownik potwierdził zamknięcie uruchomionej wersji.
