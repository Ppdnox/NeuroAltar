# 24E — aktualny zakres zdolności, 2026-11-08

Uzupełnienie zamówione przez MG: [raport mechaniki i opisów](POPRAWKI_24E_MECHANIKA_3.md).

| Obszar                                                                      | Stan                                                                                                                      |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Opisy klas i profesji                                                       | Konkretne warunki i wartości dla całego katalogu; skalowanie na poziomach 1–12.                                           |
| Stałe premie, rozwój, wyposażenie                                           | Wspólne obliczenia karty i walki; dodatkowo wrodzone Ułatwienia i zapisane efekty zdrowia.                                |
| Twardość, Amen, Kocie kości                                                 | Wybrany pierwotny test, dodatkowa kość, walidacja puli i jednoczesny trwały zapis.                                        |
| Trajektoria, Koci odskok, Podstępny atak, Matrix, Odskok, Śmiertelna obelga | Indywidualne rozliczenia, koszt, wynik/efekt i termin; trafienie oraz PW nadal jawnie.                                    |
| Medyk, Pan Plaster, Immunitet, Szybka produkcja                             | Uzupełnione zdrowie, narzędzia, leki i postój; koszty zapisywane z wynikiem.                                              |
| Premie sytuacyjne                                                           | Ręcznie przez gracza zgodnie z ostatnim poleceniem, np. Mój wróg, biom, rodzaj celu i okoliczności.                       |
| Zdolności fabularne                                                         | Opisy dla gracza; bez sztucznych pól do automatyzacji.                                                                    |
| Przerzuty i łączenie efektów                                                | Dotychczasowy zakres zaakceptowany przez MG; nie rozszerzamy.                                                             |
| Towarzysze                                                                  | Przyszły backlog.                                                                                                         |
| Odbiór końcowy                                                              | Nadal potrzebny test sesyjny kart i walki przez użytkownika; brak deklaracji całkowicie automatycznego rozstrzygania gry. |

## Produkcja — decyzja MG 2026-11-08

Truciciel i Pogromca mają wystarczające opisy. Produkcję, koszty/czas i wpisanie
wytworzonych przedmiotów/pocisków rozlicza ręcznie gracz. Nie dodajemy dedykowanej
automatyzacji i nie traktujemy jej braku jako warunku zamknięcia 24E lub buildu Windows.

Aktualny [status](STATUS.md) i [procedura Windows](BUILD_WINDOWS.md).
Archiwalna lista braków sprzed uzupełnienia mechaniki została usunięta z bieżącej
listy zadań; pozostaje dostępna przez `git show 1aeab92:docs/24E_BRAKI_ZDOLNOSCI.md`.
