# Ekwipunek: wyszukiwarka, grupy i piktogramy — 2026-11-05

Poprawka interfejsu aktualnego 24E Roboczego, na bazie `06d7484`.

## Zakres

- Przycisk „Dodaj z katalogu” po otwarciu zmienia się w „Schowaj wyszukiwarkę”.
  Dodatkowy przycisk schowania znajduje się w samym panelu wyszukiwania.
  Zwijanie nie jest blokowane przez szkic karty ani oczekujący zapis.
- Schowanie oddaje fokus przyciskowi otwierającemu. Fraza i filtr typu
  pozostają po ponownym otwarciu. Dodawanie przedmiotów nadal respektuje
  dotychczasowe blokady edycji.
- „Przy sobie”, „Pod ręką”, „Plecak” i „Juki / przechowywane” mają większy,
  wyraźniejszy nagłówek z ikoną, tłem, turkusowym akcentem i licznikiem.
- Wspólne piktogramy towarzyszą nazwom przedmiotów na Karcie BG, w wynikach
  dodawania z katalogu oraz na liście i w szczegółach biblioteki Ekwipunku.
- Grafiki są lekkimi SVG w obecnej palecie aplikacji. Podobne przedmioty
  korzystają ze wspólnego wzoru; nazwa nadal identyfikuje konkretny model.
  Ikony są dekoracyjne i nie zastępują tekstowych nazw ani reguł gry.

Nie zmieniono mechaniki, danych katalogu, migracji SQL ani zapisanych
przedmiotów. Dobór grafiki korzysta tylko z danych do prezentacji; nie
wyznacza typu amunicji, kategorii biegłości ani właściwości mechanicznych.
Broń i Ekwipunek pozostają jedną instancją panelu inwentarza.

## Pliki

- `src/features/character/InventoryPanel.tsx`
- `src/features/character/inventory.css`
- `src/features/equipment/EquipmentWorkspace.tsx`
- `src/features/equipment/equipment.css`
- `src/features/equipment/ItemIllustration.tsx`
- `src/features/equipment/itemPictogram.ts`
- `src/features/equipment/itemIllustration.css`
- Ten raport.

## Weryfikacja

- Audyt całego katalogu: 301 pozycji, 115 używanych wzorów piktogramów.
  Własne nierozpoznane wpisy mają neutralny symbol przedmiotu.
- `pnpm check`: TypeScript, ESLint, Prettier i 499 testów w 71 plikach — PASS.
- Backend Rust: 93 testy — PASS.
- Frontend i aplikacja macOS — build PASS; podpis lokalny sprawdzony
  przez `codesign --verify --deep --strict`.
- Zaktualizowany i uruchomiony dotychczasowy `NeuroAltar 24E Roboczy.app`,
  z tym samym identyfikatorem aplikacji i bazą danych.
- Natywny test w oknie 760 × 850: nagłówki lokalizacji, nazwy, przyciski
  i grafiki mieszczą się w układzie; sprawdzono broń, plecak, amunicję,
  własny przedmiot, linę i noktowizor.
- Chowanie katalogu działa również w szkicu karty, przywraca fokus
  przyciskowi otwierającemu i zachowuje frazę wyszukiwania.
- W docelowym oknie 1100 × 760 sprawdzono istniejącą kartę: M14,
  magazynek, plecak, amunicję i akordeon; w wyszukiwarce baterie i inne
  pozycje elektroniki. Po zwinięciu i ponownym otwarciu zachowały się
  fraza `bateri` oraz filtr Elektronika.
- Stare kopie leków bez aktualnej kategorii otrzymują grafikę po nazwie;
  sprawdzono 22 nazwy w 3 wariantach kategorii (66 przypadków).
- Porównanie bazy przed aktualizacją i po kontroli: wszystkie 15 tabel
  i ich wiersze bez zmian. Bez nowych migracji i zależności.

Bieżąca kontrola UI nie zastępuje końcowego odbioru całego Etapu 24E.
