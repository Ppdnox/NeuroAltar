# 24E — zakres mechanizacji zdolności, 2026-09-27

Decyzja MG: obsługa mechaniczna dotyczy zdolności wpływających na rzuty, przerzuty, zasoby, budżet akcji i inne mierzalne zasady. Zdolności fabularne mają być opisem dla gracza. Nie dodajemy im premii przez ogólny formularz.

## Zmiana w roboczym buildzie

- Panel zdolności w potyczce wybiera tylko zdolności z istniejącą ścieżką rozliczenia. Nie oferuje już każdego wybranego wpisu katalogu jako potencjalnego modyfikatora rzutów. Narracyjne i jeszcze nieobsługiwane wpisy nadal są widoczne w sekcji **Zdolności** Karty BG, z podaniem strony źródłowej.
- Usunięto bezwarunkową sugestię z opisu zdolności profesji, że każdą należy rozliczyć w panelu walki.
- Nie zmieniono dotychczas zapisanych efektów, zużytych zasobów, historii rzutów ani trwałych kart. Nie dodano migracji SQL.

## Co pozostało

Panel rozróżnia **gotową ścieżkę bojową** od reszty katalogu. Nie jest to jeszcze ukończona klasyfikacja wszystkich zdolności. Każdą pozostałą pozycję należy sprawdzić z podręcznikiem: aktywne reguły mechaniczne wymagają właściwego kosztu i wyniku, pasywne pozostają w istniejących obliczeniach, a czysto fabularne potrzebują zwięzłego opisu na karcie. Obecne opisy wielu zdolności klas i profesji są ogólne; należy je uzupełnić przed końcowym odbiorem 24E. Szczegóły: [24E_BRAKI_ZDOLNOSCI.md](24E_BRAKI_ZDOLNOSCI.md).

Pliki funkcjonalne: `src/domain/character/combatAbility.ts`, `src/features/character/CombatAbilities.tsx`, `src/domain/character/derive.ts`, `tests/combatAbilityRules.test.ts`. Decyzja została dopisana do instrukcji i dokumentacji projektu. Pełny odbiór 24E pozostaje otwarty.

Weryfikacja: `pnpm check` przeszedł (typy, lint, format, 434 testy w 65 plikach). Roboczy build macOS po zmianie został zbudowany i podpisany lokalnie. Nie zastępowano aplikacji produkcyjnej ani nie modyfikowano danych postaci. Natywnego przebiegu nowego selektora nie przeprowadzono w tej partii; działającego okna roboczego nie zamykano podczas pracy MG.
