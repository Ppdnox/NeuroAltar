# Etap 7 — zasoby i akcje (0.8.0)

## Rezultat

Wdrożono zasoby runda/potyczka/dzień/ręcznie, pule Akcji/Bonusowej/Reakcji/Legendarnych,
konfigurację nazwanych zdolności z opisami i kosztami. Definicje szablonu tworzą
niezależne pełne liczniki kopii; edytor instancji zachowuje stan szablonu i prepared.
Zapis kosztu puli i zasobu jest atomowy z logiem. MG rozstrzyga moment, cel i efekt;
aplikacja nie rzuca, nie zmienia PW i nie nadaje automatycznych efektów zdolności.
Zranienia/Obezwładnienie blokują zwykłe użycie; jawny wyjątek jest potwierdzany i logowany.

## Dostarczenie

Docelowe repozytorium: `/Users/dominik/Desktop/Combat Tracker`.
Przed zmianami sprawdzono czyste drzewo przy checkpoint Etapu 6 `dddaa28`.
Prace i walidacja odbyły się w izolowanej kopii tego commita. Zastosowanie zmian
sprawdza oczekiwany HEAD, brak zmian użytkownika i zgodność drzewa Git z testowaną
kopią. Commit Etapu 7 zawiera ten raport.
Bundle docelowy: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, wersja 0.8.0.
Poprzednia aplikacja pozostaje obok jako `NeuroAltar 0.7.0.app`.
Bazy MG nie otwierano ani nie modyfikowano podczas testowania i podmiany bundle'a.

## Migracje i model danych

Bez nowej migracji SQL i bez zmiany migracji 001–005. Nowe opcjonalne capabilities
Setup/State mieszczą się w statblock_json/runtime_overrides_json i snapshotach.
Wcześniej planowana actor_resources nie jest drugim źródłem tych samych danych.
Oba kontrakty mają walidację Zod i Rust (UUID, zakresy, koszty, odwołania, unikatowość).
Stare dane są poprawne bez nowych pól. Zachowano pięć slotów, revision, autozapis,
legacy statusy, timery, Zranienia/Wyczerpanie, prepare/reset i ochronę przy zamykaniu.

## Reguły

- A/B/R po 1: zwykły początek własnej tury. Ręczna korekta current jest neutralna.
- Legendarne 0–999 i zasoby round: tylko globalny wrap do kolejnej rundy.
- Encounter/day: jawne odnowienie do maksimum w wybranym slocie, z potwierdzeniem.
  Bez odnowienia przez datę komputera lub restart. Manual pozostaje do ręcznej korekty.
- Reset odtwarza dokładne prepared counts, w tym częściowo zużyte; nie napełnia pul.
- Brak zasobu blokuje nawet wyjątek MG. Wyjątek nie tworzy ujemnego licznika.
- Użycie całej akcji ataku wielokrotnego zużywa jedną Akcję. Wykonywanie pojedynczych
  ataków ani obliczanie profilu broni nie jest dodane w tym etapie.

## Testy i build

- `pnpm check`: TypeScript, ESLint, Prettier, **107 testów w 22 plikach** — poprawne.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **21/21**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: poprawne.
- `pnpm build:macos`: gotowy bundle arm64 0.8.0 z podpisem ad hoc.
- `codesign --verify --deep --strict`: kontrola bundle'a przed i po dostarczeniu.
- Domena: koszty obu pul, odnowienie własnej tury i globalnej rundy, 3/rundę vs
  2/potyczkę, brak inicjatywy/queue, pierwszy start, jawne day/encounter, reset,
  stare dane, blokady/wyjątki, odwołania i niepoprawne liczniki.
- Rust: awaria action_used wycofuje pulę, zasób i revision; retry bez duplikacji;
  reset nie tworzy fikcyjnego użycia. Kontrola immutable template i błędnych danych.
- Store/repository: szkic przy Cmd+Q, ujawnienie slotu, poprawa, szybkie akcje,
  zapis/ponowienie, odczyt po restarcie i SQLite reopen, prepared ze zużytym licznikiem.

## Natywna weryfikacja

Osobna aplikacja i baza: `pl.neuroshima.combat-tracker.stage7-smoke`.

- Nowy szablon „Żmija z kanionu”, TT 15, 88 PW, tor Zranień, pula Legendarnych 3,
  zasób Impuls 3/rundę, akcja „Żądło” o koszcie 2 Impulsu i polskim wielowierszowym opisie.
- Użycie Żądła zmieniło A 1→0 i Impuls 3→1. Brak wystarczającego zasobu zablokował
  kolejne użycie. Log zapisał użycie, koszt i pulę, PW pozostały 88.
- Pierwszy start odnowił A, zachował Impuls 1/3. Przejście do rundy 2 odnowiło
  Impuls 3/3 i Reakcję. Zranienie 3 zablokowało Bonusową/Reakcję; potwierdzony
  wyjątek MG zmniejszył Reakcję i pojawił się jawnie w logu.
- Użycie Legendarnej zmniejszyło pulę 3→2. Błędne puste maksimum zasobu zachowało
  formularz i zatrzymało Cmd+Q. Korekta do 3 i pozostałe 2 pozwoliły zatwierdzić.
- Zapis prepared, Cmd+Q i restart zachowały Impuls 2/3, Reakcję 0/1, Legendarne 2/3,
  Zranienie 3, inicjatywę 12, rundę 2, aktywną turę, log i opis. Snapshot pokazał te
  same częściowo zużyte liczniki, bez odnowienia przy restarcie.
- Nowa kopia tego szablonu dostała Impuls 3/3, Reakcję 1/1, Legendarne 3/3,
  Zranienie 0 i pustą inicjatywę. Pierwsza instancja zachowała stan runtime.
- Zamknięcie przyciskiem okna również zakończyło proces. Testy resetu i jawnego
  odnowienia day/encounter wykonano automatycznie; natywnie sprawdzono prepared/restart.

## Ograniczenia przed Etapem 8

- MG nadal wybiera właściwy moment/cele użycia. Nie wdrożono okien reakcji, celowania,
  efektów zdolności, kości, profili broni, ammo trackingu ani pełnego CRUD Bestiariusza.
- Legendarne odnawiają się globalnie co rundę. Szczególne reguły statblocka MG
  rozstrzyga korektą puli; nie ma automatycznej interpretacji tekstu zdolności.
- Formularz zatwierdza także usuwanie wierszy. Niedokończony szkic jest chroniony
  przy zwykłym zamknięciu, ale nie przetrwa wymuszonego zabicia procesu.
- Nowe dane wymagają aplikacji 0.8.0. Kopia bundle'a 0.7.0 nie jest mechanizmem
  cofania bazy; starsza wersja nie rozumie nowych pól.
- Podpis ad hoc, bez notaryzacji Apple jak dotychczas. Folder Pulpitu może dopisać
  FinderInfo do bundle'a; kontrola dostarczenia usuwa wyłącznie taki atrybut,
  jeśli zaburza ścisłą kontrolę podpisu.
- Etap 8 wymaga osobnego zlecenia użytkownika.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_7.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/capability.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/domain/capabilities.ts`
- `src/domain/capabilitySchema.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/enemy.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/EnemyForm.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/resources/CapabilityFields.tsx`
- `src/features/resources/CapabilityForm.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `src/features/resources/ResourceRefresh.tsx`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/capabilities.test.ts`
- `tests/capabilityStore.test.ts`
- `tests/enemyDatabase.test.ts`
