# Uzupełnienie tabel podręcznika — 2026-09-27

Źródło: lokalny PDF `reference/NOE_dla_dominadiinteriapl.pdf`,
_Neuroshima: Ostatnia Era_, SHA256
`714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34`.
Numery stron w UI są numerami drukowanymi (strona PDF = numer drukowany + 2).
Wydobyte dane są statycznym plikiem `src/data/knowledge/handbook-tables.v1.json`;
aplikacja nie odczytuje PDF podczas działania.

Do dotychczasowych 50 wpisów Wiedzy MG dodano 29 tabel (288 wierszy, w tym
adnotacja do brakującego wyniku 85 w Tabeli Fantów):

| Dział                | Tabele i strony drukowane                                                         |
| -------------------- | --------------------------------------------------------------------------------- |
| Zdrowie i zagrożenia | Zranienia 32; choroby 109; fobie 112; upojenie 256; jedzenie, woda i skażenie 258 |
| Walka                | Miażdżąca seria 120                                                               |
| Sprzęt               | Broń specjalna i ciężka 124; ulepszenia broni białej 128 i dystansowej 129        |
| Łupy i surowce       | Fanty 133; surowce 144; czas i trudność produkcji 145                             |
| Zasady szczegółowe   | TT i PW obiektów 253; osłony 255; typy obrażeń 256                                |
| Pojazdy              | Statystyki 262; awarie 265; trudność i komplikacje pościgu 266–267                |
| Szabrowanie          | Bebeszenie bestii i maszyn 269; komplikacje 270; losowe przedmioty i ruiny 271    |

Z działu postaci w Wiedzy MG dodano tylko żądane Zranienia, choroby i fobie;
nie kopiowano tabel rozwoju klas. Dane uproszczonych tabel dwułamowych zostały
ułożone w jednym ciągu kolejnych wyników. **Podręcznik pomija wynik 85 w Tabeli
Fantów**; wiersz aplikacji oznacza brak źródła, bez wymyślonego przedmiotu.

Ekwipunek ma teraz zakładki „Przedmioty”, „Ulepszenia broni” i „Fanty”. Dwie
ostatnie czytają te same statyczne tabele co Wiedza MG. Nie są nowymi rekordami
Item w bazie i nie zmieniają 299 istniejących pozycji katalogu ani dwóch z
Moloch City. Pojazdy są osobnym widokiem obok Ekwipunku: 14 wierszy tabeli ze
strony 262, bez indywidualnych statblocków. Nie dodano ich jako Item.

Zmiana nie wymaga migracji SQL, nie modyfikuje istniejących potyczek ani danych
użytkownika. Transkrypcja PDF zachowuje liczby i treść komórek; ozdobne znaki
nieodczytywane przez warstwę tekstową zastąpiono pauzą. Przed ewentualnym użyciem
tych tabel jako automatycznych reguł potrzebny byłby osobny audyt mechaniczny.

## Build roboczy 24E

Zmiany są w pakiecie `NeuroAltar 24E Roboczy.app` w katalogu
`work/stage2-target/release/bundle/macos/` projektu ChatGPT „Neuroshima 5e”.
Przed podmianą zapisano kopię w katalogu `work/backups/` pod nazwą
`NeuroAltar 24E Roboczy przed tabelami 2026-09-27.app`. Zachowano identyfikator
`pl.neuroshima.combat-tracker.stage24d-smoke` i jego osobną bazę roboczą.
Pełny zestaw testów JS/TS: 437/437. Build macOS, lokalny podpis
`codesign --verify --deep --strict` i natywne sprawdzenie widoków karty
potyczki, Ekwipunku, Pojazdów oraz Wiedzy MG zakończone powodzeniem.
Build zgłosił ostrzeżenie o niedostępnej bibliotece `libLLVM.dylib` dla
`rust-objcopy`; nie przerwało ono kompilacji ani podpisywania pakietu.
