# NeuroAltar 0.25.4 — poprawki interfejsu i źródeł

Zlecone po `a307836`. Wdrożono bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`.

## Co zmieniono

- **Inicjatywa:** interaktywny jest dokładnie istniejący wpis „Inicjatywa: …”
  w „Zdolnościach stałych i zasadach”. Usunięto przyciski z pola wyniku i z góry
  statblocku. Ręczna etykieta i edycja wyniku wróciły do poprzedniego układu.
  Nie dodaje się nowej pozycji, gdy statblock nie zawiera inicjatywy.
- **Wyrównanie:** cztery pola PW / maks. PW / TT / inicjatywa mają jednakową
  wysokość i wspólną dolną krawędź. „Dodaj przeciwnika” i „Dodaj własnego” mają
  jednakową wysokość i są wyrównane w jednym rzędzie; na małych oknach mogą się zawijać.
- **Źródła Ekwipunku:** wszystkie 299 pozycji wskazują „Neuroshima: Ostatnia Era”,
  drukowane strony oraz właściwą tabelę/sekcję. Przykładowo amunicja: s. 125,
  elektronika: s. 130, narzędzia: s. 134. Granaty i miny wskazują strony opisów,
  ponieważ książka nie ma dla nich wspólnej tabeli. Koktajl Mołotowa: s. 127 i 139.
  Pełna mapa i zakres weryfikacji: [EKWIPUNEK_STRONY.md](EKWIPUNEK_STRONY.md).

## Dane i zgodność

Bez migracji, zmian seedów, synchronizacji lub reimportu. Odsyłacze wyświetlają
się od razu także na istniejącej bazie. Powiązanie sprawdza ID oraz oryginalne
źródło seedu; własne źródło MG pozostaje zachowane. Nie zmieniano cen,
dostępności, wagi, opisów ani zasad handlu. Nie twierdzimy, że dotychczasowe
opracowanie Excela zostało w całości porównane pod kątem wartości z książką.

Zachowane atomowy zapis rzutu, log, korekta ręczna i odporność na ponowienie
z wersji 0.25.3. Pięć slotów, tury, rundy, zasoby i snapshoty bez zmian.
Bazy użytkownika nie używano do testów ani nie zastępowano.

## Sprawdzenie

- `pnpm check`: **289 testów / 54 pliki**, typy, lint, format — PASS.
- Rust: **63 testy** — PASS. `cargo fmt --check` i `git diff --check` — PASS.
- Build macOS oraz osobny build QA — PASS, arm64, podpis ad hoc.
- Test miejsca przycisku obejmuje wszystkie 51 szablonów przeciwników:
  jeden przycisk wewnątrz zasad, statyczny podgląd katalogu, brak dopisywania pozycji.
- Testy źródeł: 299/299 ID bez duplikatów, strony tabel, rozdzielenie granatów,
  brak zmiany danych i zachowanie własnych źródeł MG.
- Natywnie sprawdzono wyrównanie obu przycisków i wszystkich czterech pól.
  Kliknięcie istniejącego wpisu Megatora w zasadach dało **6−6=0**; wynik trafił
  do pola inicjatywy i logu. Bieżąca tura nadal należała do Megatora.
- Natywnie sprawdzono źródła amunicji (.12 Ga), Agregatu i Koktajlu Mołotowa.
  Po ⌘Q i ponownym uruchomieniu zachowany wynik 0; zwykłe zamknięcie też działa.
- Porównanie oddzielnej bazy QA: katalog Ekwipunku i Bestiariusza identyczny
  przed i po teście; 11 instancji zachowanych, zmieniona tylko inicjatywa
  rzuconego aktora i metadane zapisu, rundy/tury/snapshoty/statystyki bez zmian.

## Dostarczenie i ograniczenia

Aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app` — **0.25.4**.
Poprzedni build zachowany obok jako `NeuroAltar 0.25.3.app`.
Nie rozpoczynano Etapu 23 ani późniejszych etapów.
Build pozostawia ostrzeżenie o rozmiarze pakietu JS (639,49 kB) i brak notaryzacji;
weryfikacja natywna dotyczy lokalnego macOS arm64.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/EKWIPUNEK_STRONY.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/data/equipment/README.md`
- `src/data/equipment/handbook-sources.v1.json`
- `src/domain/equipmentSource.ts`
- `src/features/bestiary/enemyPicker.css`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/InitiativeRoll.tsx`
- `src/features/equipment/EquipmentWorkspace.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `tests/equipmentSources.test.ts`
- `tests/initiativePlacement.test.ts`
- `docs/POPRAWKI_0.25.4.md` — ten raport.
