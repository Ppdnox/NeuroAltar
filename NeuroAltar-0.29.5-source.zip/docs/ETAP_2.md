# Etap 2 — NeuroAltar 0.3.0

## Aktualizacja po dostarczeniu

Użytkownik zastosował zmiany w repozytorium na Pulpicie jako `358a865` (czyste drzewo,
identyczne z przetestowanym wydaniem) i potwierdził poprawne otwieranie/zamykanie oraz
działanie aplikacji w swoich sprawdzeniach. Poniższy raport opisuje pierwotne dostarczenie.

## Stan dostarczenia

Implementacja jest gotowa w roboczej kopii repozytorium utworzonej z `241c0a6`.
Docelowe `/Users/dominik/Desktop/Combat Tracker` pozostaje niezmienione: kontrola
uprawnień tej rozmowy odrzuciła zapis poza projektem. Gotowy commit i plik patch
można zastosować w tym folderze bez ponownej implementacji. Skrypt dostarczenia
sprawdza czyste drzewo i właściwy commit bazowy przed zastosowaniem zmian.
Etap 3 nie został rozpoczęty.

## Funkcje

- Pięć niezależnych slotów i dotychczasowy autozapis nazw/notatek.
- Dodawanie, edycja i usuwanie BG z potwierdzeniem. Dane: imię, TT, aktualne/maks. PW,
  wpisana inicjatywa i ręczne statusy po jednym w wierszu.
- Skróty PW −1/−5/−10/+1 oraz własne obrażenia/leczenie; wynik mieści się w 0–maks. PW.
- Kolejka malejąca, ręczne przestawianie remisów strzałkami, bez losowania.
  Brak wyniku pozostaje poza kolejką, a 0 i wyniki ujemne są poprawne.
- Rozpoczęcie tury, następna tura, zwiększenie rundy po ostatnim aktorze.
  MG może wskazać bieżącą turę bez zmiany rundy. Wybór karty nie zmienia tury.
- Spacja przechodzi do następnej tury poza polami, przyciskami i innymi kontrolkami.
  0 PW nie pomija automatycznie postaci.
- Autozapis BG po 400 ms, opuszczeniu pola i przełączeniu slotu; akcje tury zapisują
  się od razu. Niepełny tekst liczbowy pozostaje w szkicu, bez zamiany na zero.
- Zachowanie najnowszego szkicu przy błędzie, ponowienie zapisu i wspólna ochrona
  zamykania dla nazw/notatek oraz BG. Błędny slot jest wskazywany użytkownikowi.

## Architektura i migracja

Nowa migracja `002_pc_initiative.sql` dodaje `encounter_actors`, indeks slotu
oraz `encounters.combat_revision`. Migracja 001 jest identyczna z bazową.
Istniejące rekordy pięciu potyczek, nazwy, notatki i identyfikator aplikacji
pozostają zachowane. Nie kasowano ani nie odtwarzano bazy użytkownika.
Porównanie jej SHA-256 potwierdziło brak zmian podczas pracy.

Modele/Zod i logika tur są poza React. Odczyt jednego SELECT pobiera spójny stan
aktorów i tury. Komenda Rust save_combat korzysta z poolu istniejącego pluginu SQL;
jedna transakcja aktualizuje BG, rundę i aktywną postać. Każdy błąd wycofuje całość.
Wersja zapisu wykrywa konflikt drugiego okna i zachowuje lokalny szkic.
Przy aktualizacji runtime nie nadpisujemy prepared_snapshot_json.

Dodano bezpośrednie zależności serde, serde_json, sqlx i uuid, już obecne wcześniej
pośrednio w Cargo.lock. Nie zmieniono stacku, wersji zależności frontendowych,
identyfikatora `pl.neuroshima.combat-tracker` ani URL `sqlite:combat-tracker.db`.
Wersja aplikacji wzrosła z 0.2.0 do 0.3.0.

## Weryfikacja

- Pełny `pnpm check`: **69 testów Vitest w 11 plikach**, TypeScript, ESLint i formatowanie.
- `cargo test --manifest-path src-tauri/Cargo.toml --lib`: **4 testy Rust**;
  końcowo również 4/4 w profilu `--release`.
- Testy obejmują migrację danych pięciu slotów, trwałość po ponownym otwarciu pliku,
  błędne pola, remisy, zerową/ujemną/brakującą inicjatywę, przejścia rund, atomowe
  wycofanie zapisu, konflikt wersji, ochronę snapshotu i wspólne zamykanie.
- `pnpm build:macos`: poprawny build frontendu i Tauri/Rust dla macOS arm64.
- `codesign --verify --deep --strict`: poprawny podpis gotowego bundla.
- `cargo fmt --check` i `git diff --check`: poprawne.
- Natywny test wykonano w osobnym bundlu z identyfikatorem
  `pl.neuroshima.combat-tracker.stage2-smoke`, z oddzielną bazą, bez otwierania bazy użytkownika.
- Potwierdzono w natywnym UI: dodanie dwóch BG, polskie imiona, TT/PW, statusy
  wielowierszowe, autozapis, ręczne przestawienie remisu, rozpoczęcie tury,
  spację do następnej tury, brak przejścia po spacji w statusach i przejście do rundy 2.
- Po wznowieniu pracy odczyt kopii bazy testowej potwierdził zapis dwóch BG,
  rundy 2 i poprawną integralność SQLite. To potwierdzenie trwałości pliku;
  ponownego otwarcia UI oraz zamykania okna/⌘Q nie udało się dokończyć po utracie
  narzędzia sterowania komputerem. Zachowanie zamykania pokrywają testy automatyczne.
- Końcowy build zapisano w trwałym folderze wyników po usunięciu wcześniejszych
  katalogów tymczasowych podczas przerwy w sesji.

## Ograniczenia i następny etap

- Statusy w Etapie 2 są ręczne; ich czas/efekty należą do Etapu 5, log do Etapu 4.
  Nie dodano przeciwników, resetu, Ekwipunku, rzutów ani liczenia amunicji.
- Nowy BG ma edytowalne wartości początkowe: Nowy BG, TT 10, PW 1/1, brak inicjatywy.
  Prepared snapshot zachowuje pierwszy zapis; sposób jawnego przygotowywania
  późniejszych snapshotów należy dopracować przy Etapie 3/reset, przed udostępnieniem resetu.
- Usunięcie aktywnej postaci albo wyczyszczenie jej inicjatywy odznacza turę,
  pozostawiając rundę. MG wybiera nową postać lub zaczyna kolejkę od pierwszej.
- Niepełne dane jednego BG wstrzymują zapis całego szkicu BG tego slotu;
  niezależne nazwy/notatki nadal mogą się zapisać. Wymuszone zakończenie procesu
  może utracić ostatnie niezapisane zmiany, jak w dotychczasowym autozapisie.
- Build przeznaczony dla macOS 13.3+ na Apple Silicon, podpisany lokalnie ad hoc,
  bez notaryzacji Apple. Windows i Intel nie były budowane.
- Przed dalszą pracą należy zastosować commit w docelowym repozytorium. Skrypt nie
  modyfikuje bazy ani nie uruchamia aplikacji; migracja wykona się przy uruchomieniu 0.3.0.

## Pełna lista zmienionych i nowych plików

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_2.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `manifest.json`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/002_pc_initiative.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/combatRepository.ts`
- `src/domain/combat.ts`
- `src/domain/initiative.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/saveLabels.ts`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/services/closeGuard.ts`
- `src/services/combat.ts`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/combat.test.ts`
- `tests/combatDatabase.test.ts`
- `tests/combatStore.test.ts`
- `tests/initiative.test.ts`
- `tests/prepareAppClose.test.ts`
