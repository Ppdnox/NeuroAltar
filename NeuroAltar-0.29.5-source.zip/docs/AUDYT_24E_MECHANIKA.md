# Audyt mechaniki roboczego 24E — 2026-09-20

## Wniosek i zakres

Kontynuujemy zaakceptowany przez MG build „NeuroAltar 24E Roboczy”. MG potwierdził, że powiązanie BG z potyczką działa. Nie wracamy do produkcyjnego 0.29.4.

**Nie można jeszcze uznać 24E za w pełni zgodne mechanicznie.** Istnieją poprawnie odwzorowane zasoby i podstawowe obliczenia, ale część zdolności jest tylko wpisem w katalogu lub wymaga ręcznego efektu. Są też konkretne rozbieżności w obliczeniach i kosztach akcji.

Audyt obejmuje statyczne porównanie rozwoju, zasobów, zdolności klas i profesji, sztuczek oraz ich połączenia z bronią, rzutami i budżetem potyczki. Źródło: `reference/NOE_dla_dominadiinteriapl.pdf`, w szczególności drukowane strony 67–108. Numer strony PDF jest o 2 większy od drukowanego. Odczytano tekst źródłowy, a tabelę sztuczek ze s. 107 sprawdzono również wizualnie.

Nie jest to pełny ponowny audyt wszystkich statblocków Bestiariusza, całego Ekwipunku, Wiedzy MG i wszystkich czynności postoju. Nie przeprowadzono w tej turze pełnego zestawu testów ani nowego buildu. Poniższe ustalenia wynikają z kodu i źródła; nie przedstawiamy ich jako wyników testów interfejsu.

## Potwierdzone rozbieżności do poprawienia

P1 oznacza błędny wynik albo rozliczenie zasobu/akcji. P2 oznacza brak wygodnej obsługi lub niewystarczającą informację; nie musi oznaczać błędu samej reguły podstawowej.

| Priorytet | Reguła i źródło                                                           | Stan roboczego 24E                                                                                                                                                                              | Oczekiwana korekta                                                                                                                                                   |
| --------- | ------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| P1        | Szturmowiec, s. 107                                                       | `equipped.ts:211` nadaje Utrudnienie każdej krótkiej serii, bez sprawdzenia sztuczki.                                                                                                           | W normalnym zasięgu uwzględnić wyjątek Szturmowca; dalszy zasięg rozliczać osobno.                                                                                   |
| P1        | Grad ołowiu, s. 103                                                       | `character_participation.rs:607–650` pozwala zużywać kolejne ataki na krótkie serie bez sprawdzenia sztuczki; zapis `short-series` nie blokuje następnej KS.                                    | Powiązać możliwość używania KS w ramach wielokrotnego Atakowania z Gradem ołowiu.                                                                                    |
| P1        | Ruchome gniazdo CKM, s. 107                                               | `equipped.ts:178–193` mnoży kości wyłącznie według trybu i liczby nabojów.                                                                                                                      | Dodatkowe podwojenie kości długiej serii wynikające ze sztuczki.                                                                                                     |
| P1        | Rzeźnik, s. 86; Spec 11, s. 79; Clint, s. 88; Mistrz broni białej, s. 104 | `deriveInventoryWeapon` uwzględnia Samuraja i Sokole oko, ale nie wymienione premie obrażeń.                                                                                                    | Dodać odpowiednio premię Rzeźnika z warunkiem drugiej ręki, INT Speca, kość rewolweru Clinta i kość wybranej broni białej. Nie stosować ich bez wymaganych warunków. |
| P1        | Miotacz, s. 104; Snajper, s. 107                                          | Zasięg zwracany jest bez zmian (`equipped.ts:216`); brak premii +2 do testu Miotacza.                                                                                                           | Obliczać premię i odpowiednie zwiększenie zasięgu; oddzielić informację o zasięgu od sytuacyjnego Utrudnienia.                                                       |
| P1        | Pulp Fiction, s. 106; Stalowy nadgarstek, s. 86; Rewolwerowiec, s. 88     | Warunek Utrudnienia za trzymanie broni jedną ręką w `equipped.ts:211–215` nie uwzględnia tych wyjątków.                                                                                         | Uwzględnić konkretną kategorię broni i nabyte zdolności.                                                                                                             |
| P1        | Samuraj i Siekierezada, s. 107                                            | `deriveEquipment` nie dodaje warunkowego +1 TT za właściwy układ trzymanych broni. Samuraj ma wdrożone +1 do ataku i obrażeń, co nie oznacza kompletnej sztuczki.                               | Obliczać TT także z aktualnie trzymanych broni.                                                                                                                      |
| P1        | Robin Hood, s. 106                                                        | Katalog używa ID `robin`, przeładowanie sprawdza `robinhood` (`character_participation.rs:581`).                                                                                                | Ujednolicić ID; właściwy załadunek powinien móc zużyć Interakcję.                                                                                                    |
| P1        | Szybkie ręce, s. 79                                                       | Zdolność dodaje budżet `use`, lecz operacje przeładowania wybierają wyłącznie akcję, bonus lub interakcję (`character_participation.rs:546,565–596`).                                           | Pozwolić wykorzystać dodatkowe Użycie w odpowiedniej czynności, bez ponownego pobierania standardowej akcji.                                                         |
| P1        | Ulubiona broń, s. 86                                                      | Operacja strzału obsługuje pulę ataków i Akcję; nie ma ścieżki dodatkowego strzału z Akcji Bonusowej przez tę zdolność.                                                                         | Po spełnieniu warunków pobrać Bonus i amunicję dla dodatkowego ataku.                                                                                                |
| P1        | Wyczulone zmysły, s. 98                                                   | Ułatwienie trafia do opisowych `conditions` testu w `derive.ts`, ale `characterRolls.ts` nie pobiera tych warunków do trybu rzutu.                                                              | Przekazać pewne, aktywne Ułatwienia do rollera; warunkowe pozostawić do potwierdzenia.                                                                               |
| P1        | Szczęście, s. 72                                                          | `CombatAbilities.tsx:268` wybiera poprzedni k20 po aktorze, bez ograniczenia do bieżącej potyczki i wyklucza inicjatywę. Efekt `all/nextRoll` może też zostać zużyty przez zwykły kolejny test. | Wskazać konkretny kwalifikujący się rzut do przerzutu i zużywać zasób przy przerzucie, z właściwym kontekstem potyczki.                                              |
| P2        | Cichy krok, s. 98                                                         | Ostrzeżenie o utrudnieniu skradania przez pancerz w `deriveEquipment` uwzględnia Trening w zbroi, ale nie Cichy krok.                                                                           | Usunąć nieaktualną karę/ostrzeżenie po nabyciu zdolności.                                                                                                            |
| P2        | Zdolności klas i profesji, s. 67–101                                      | `derive.ts:527,700` zastępuje wiele właściwych reguł ogólnym tekstem. Zdanie „Stałe premie są uwzględnione” nie jest prawdziwe dla wszystkich pozycji.                                          | Każda pozycja powinna mieć rzeczywisty opis kosztu, warunków, działania i czasu, a komunikat o automatyzacji odpowiadać implementacji.                               |

## Obsługa ręczna — ograniczenia, a nie zakaz ręcznego rozstrzygania

Ogólny formularz „Zdolności i sztuczki” pozwala wybrać koszt, cel, modyfikator, kości i czas. Jest użyteczny jako ręczne narzędzie MG, ale nie dowodzi wdrożenia konkretnej reguły.

- Motywacja i Mózg mają przycisk rzutu kością premii; nie należy raportować całkowitego braku kości tych zdolności. Formularz pozwala jednak zatwierdzić efekt z domyślną premią 0 bez wykonania tego rzutu. Potrzebne są bezpieczne ustawienia konkretnej zdolności.
- Dobra rada i Motywacja domyślnie wskazują używającego, choć wymagają właściwego sojusznika. Ręcznie można wybrać innego BG; domyślny wybór powinien odpowiadać regule.
- Cele efektów są ograniczone do aktywnych BG. Obelga lub Spieprzysz to nie mają pełnej ścieżki na przeciwnika. Efekt należy obecnie rozliczyć ręcznie poza tym formularzem.
- Let’s rock i Łaska Boża wymagają obsługi wielu celów przy jednym koszcie użycia. Pojedynczy cel w formularzu nie odwzorowuje całej zdolności.
- Bolesny cios, Mój wróg, osłony, odległość, obecność sojusznika i warunki sytuacyjne mogą nadal wymagać potwierdzenia gracza. Nie proponujemy automatycznego rozstrzygania trafień ani automatycznego odejmowania PW.
- Efekty mają ogólne zakresy (np. wszystkie obrażenia, cecha, umiejętności), bez pełnego przypisania do konkretnej broni/umiejętności. Przed dodaniem gotowych ustawień trzeba zapobiec przechodzeniu premii na nieuprawniony rzut.

## Obszary zgodne w sprawdzonym kodzie

Poniższe stwierdzenia dotyczą wskazanych obliczeń, nie kompletności wszystkich zdolności danej klasy.

- Pule Berserka, Wściekłego ciosu, Motywacji, Szczęścia, Mózgu, Kondychy, Twardości i Kociego wdzięku mają przewidziane progi rozwoju oraz odpowiednie podstawy liczby użyć/kości w `resources.ts` i `character_condition.rs`.
- Wściekły cios ma ograniczenie liczby wydawanych kości; Berserk ma dodatkowe kości obrażeń oparte na Sile oraz czas trwania.
- Rdzeń ataku uwzględnia modyfikator odpowiedniej cechy, wyszkolenie i PB. Serie mają osobne mnożniki kości. Braki dotyczą wskazanych wyjątków klas i sztuczek.
- Sokole oko daje +3 do ataku dystansowego, a Samuraj +1 do ataku i obrażeń ciętych; brakujący składnik TT opisano powyżej.
- Podstawowe alternatywy TT bez pancerza oraz Kuloodporność są rozdzielone. Nie stwierdzono podwójnego naliczania PB Kuloodporności w sprawdzonej ścieżce.
- Inicjatywa uwzględnia Instynkt i Być jak Bill; podstawowa Szybkość i jej klasowe przyrosty są wyliczane.
- Katalog sztuczek zawiera wymagania, rozwój cech i odsyłacze. Obecność wpisu nie jest równoznaczna z działaniem wszystkich jego efektów w walce.

## Decyzje MG zachowane jako nadrzędne

Nie uznajemy za błędy uzgodnionych odstępstw: Samouk na poziomie 9; profesje Twardziela 3/7/11; Saper jednorazowy z odnowieniem po krótkim lub długim odpoczynku; minimum 0 PW przy awansie; jedno Zranienie na cios; krwawienie łącznie 1 PW na turę; ręczne rozliczanie PW; nieliczony zapas Chromu i pusta broń przy naturalnej 1; pozostałe zapisane rozstrzygnięcia Kolorów i odpoczynku.

Nie przywracamy wycofanych wymagań: automatycznego przerywania Berserka przez stany, dalszej automatyzacji zacięć/przegrzania, leków podczas walki, konwersji starego uproszczonego BG ani panelu „Aktywna walka” w karcie. Towarzysze pozostają pomysłem na przyszłość.

## Kolejność korekt i odbioru

1. Wspólne obliczenia broni, TT i wyjątków pasywnych; poprawne dane muszą trafiać zarówno do karty, jak i do potyczki.
2. Budżet krótkich serii, dodatkowych ataków oraz przeładowań.
3. Ułatwienia i bezpieczny przerzut Szczęścia.
4. Rzeczywiste opisy i ustawienia zdolności: właściwy koszt, cel, zakres i czas; osobno efekty wielocelowe.
5. Po zakończeniu poprawek — pełny zestaw testów i build macOS oraz odbiór użytkowy, zgodnie z decyzją MG.

W tej turze nie zmieniono mechaniki, schematu bazy ani danych użytkownika. Zapisano ustalenia audytu i potwierdzenie przyjęcia working24E jako podstawy dalszych prac. Nie wydano nowej aplikacji i nie utworzono commita zamykającego 24E.

## Aktualizacja 2026-09-24

Wdrożono pierwszą partię poprawek z audytu: [POPRAWKI_24E_MECHANIKA_1.md](POPRAWKI_24E_MECHANIKA_1.md). Raport rozróżnia naprawione obliczenia od pozostałych ograniczeń. Historyczna tabela audytu opisuje stan sprzed tej partii; 24E nie jest jeszcze ukończone.

## Druga partia uzupełnień — 2026-09-24

Ulubiona broń, wybór przerzutu Szczęścia, efekty wielocelowe, wybrane presety zdolności i efekty przeciwników zostały rozszerzone. Bieżący zakres, dowody i jawne ograniczenia: [POPRAWKI_24E_MECHANIKA_2.md](POPRAWKI_24E_MECHANIKA_2.md). Historyczna lista rozbieżności nie oznacza, że każda pozycja pozostaje nietknięta; raporty partii 1 i 2 określają aktualny stan. Pełny odbiór 24E nadal przed nami.
