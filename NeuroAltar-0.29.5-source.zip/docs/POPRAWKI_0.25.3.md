# NeuroAltar 0.25.3 — wyszukiwarka przeciwników i inicjatywa

Zlecone poprawki po `3a48045`, bez rozpoczęcia Etapu 23. Zmiany bezpośrednio
w `/Users/dominik/Desktop/Combat Tracker`.

## Zachowanie aplikacji

- **Dodaj przeciwnika** otwiera okno Bestiariusza dla aktualnego slotu. Kursor
  trafia od razu w nazwę, wyszukiwanie obsługuje brak polskich znaków. Filtr
  kategorii obejmuje Ludzi, Maszyny, Mutantów, Potwory i Zwierzęta; istniejące
  kategorie historyczne pozostają czytelne. Przy wyniku widać TT, PW i SP.
- **Dodaj** tworzy jedną niezależną instancję, wybiera jej kartę, zamyka okno
  i korzysta z dotychczasowego autozapisu. **Dodaj własnego** uruchamia
  dotychczasowy ręczny formularz. Escape zamyka wyszukiwarkę bez dodawania.
- **Inicjatywa** jest klikalna przy polu wyniku oraz w stale widocznym statblocku.
  Rzut k20 korzysta z podanej premii inicjatywy; wartość w nawiasie nie jest
  dodawana. Brak pozycji inicjatywy pozwala użyć modyfikatora Zręczności.
  Nieznany lub sprzeczny zapis wymaga ręcznego wyniku. Wyczerpanie odejmuje
  właściwą liczbową karę; pozostałe warunki nadal ocenia MG.
- Wynik trafia do inicjatywy danej instancji, historii kości i logu potyczki.
  Kolejka zmienia porządek, zachowując rundę, bieżącego aktora i reguły remisów.
  Ręczne wpisanie oraz poprawienie inicjatywy pozostają dostępne.

## Bezpieczeństwo zapisu i migracje

Przed losowaniem kończy się autozapis. Polecenie `save_initiative_roll`
transakcyjnie zapisuje wynik, inicjatywę, log i rewizję. Odrzuca złą rewizję,
slot, rundę i aktora BG. Ponowienie z tym samym UUID nie losuje ponownie ani
nie nadpisuje późniejszej ręcznej korekty. Błąd zachowuje wynik i blokuje
zamknięcie do ponowienia lub odczytu aktualnego stanu.

**Brak migracji.** Migracje 001–010, seedy, pięć slotów, przygotowane/oryginalne
snapshoty, PW, zasoby i pozostałe kopie pozostają zachowane. Inicjatywa nie
przygotowuje krytyka obrażeń. Bazy użytkownika nie używano do testów ani nie
zastępowano; QA wykonano w osobnej aplikacji i bazie readability-smoke.

## Weryfikacja

- `pnpm check`: **284 testy / 52 pliki**, typy, lint i format — PASS.
- Rust `cargo test --release --lib`: **63 testy** — PASS.
- `cargo fmt --check`, `git diff --check` — PASS.
- `pnpm build:macos` oraz osobny build QA — PASS, arm64, podpis ad hoc.
- Testy inicjatywy obejmują wszystkie 51 szablonów, premię jawną i zastępczą,
  nieznane dane, Wyczerpanie, autozapis przed rzutem, blokowanie formularzy,
  kolejkę, izolację kopii, zachowanie tury/rundy/snapshotów, błąd zapisu,
  dokładne ponowienie, niepewny wynik transakcji i ponowny odczyt.
- Natywnie: „gangus zolnierz” → 1 wynik, dodanie Gangusa do slotu 1,
  rzut **15+2=17** i wpis w logu, potem ręczna korekta **7**.
  Bieżącą turę zachował Megator. Po ⌘Q i ponownym otwarciu wartość 7
  oraz kolejka były zachowane. Dotychczasowy formularz działa pod nową nazwą.
- Finalne okno wyszukiwania sprawdzono wizualnie: centrowanie, czytelne pole,
  automatyczny fokus. „mobsprzet” → Mobsprzęt; filtr Ludzie → brak wyników;
  Escape anuluje. Rzut istniejącego Mobsprzętu **9+2=11** zapisał się
  w jego karcie i logu, zachowując turę Megatora.
- Porównanie oddzielnej bazy po pierwszej próbie: wszystkie 10 poprzednich
  instancji bez zmian wartości i snapshotów; jedna nowa instancja Gangusa;
  wszystkie rundy i bieżące tury zachowane. Końcowe zwykłe zamknięcie okna
  także działa; w bazie pozostają Megator 13, Mobsprzęt 11 i Gangus 7.
  Po tej próbie nadal zachowane wszystkie pozostałe statystyki i snapshoty.

## Dostarczenie i ograniczenia

Gotowa aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzedni build zachowany jako `NeuroAltar 0.25.2.app` obok. Wersja 0.25.3.
Pełny zakres Etapu 23 nadal wymaga osobnego zlecenia. Nie wdrażano karty BG
ani portu Windows. Build nadal zgłasza znane ostrzeżenie o pakiecie JS >500 kB
(625,31 kB) i brak notaryzacji. Testy natywne dotyczą lokalnego macOS arm64.

## Pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/dice.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/domain/dice.ts`
- `src/domain/enemyInitiative.ts`
- `src/features/bestiary/EnemyPicker.tsx`
- `src/features/bestiary/enemyPicker.css`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/InitiativeRoll.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/services/initiativeRoll.ts`
- `src/services/prepareAppClose.ts`
- `src/stores/initiativeStore.ts`
- `tests/initiativeRoll.test.ts`
- `docs/POPRAWKI_0.25.3.md` — ten raport.
