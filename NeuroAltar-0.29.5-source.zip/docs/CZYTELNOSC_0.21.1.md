# Poprawki czytelności 0.21.1

Zlecenie: lista korekt interfejsu po Etapie 18B; Etap 19 nie został rozpoczęty.
Baza Git: czysty f4da82c (0.21.0). Docelowy folder: /Users/dominik/Desktop/Combat Tracker.

## Zmiany

- Chód w widokach i formularzach pokazuje się jako Szybkość. Wszystkie rodzaje
  ruchu mają jednostkę m w podglądzie: Szybkość 18m, Wspinanie 4,5m.
  Formularze nadal pokazują liczby w metrach; akceptują również jawne m.
- Podręcznikowe kopie z podanym SP pokazują tę wartość jako tekst.
  Pole Aktualne SP zniknęło z ich karty walki. Ręczne tworzenie, własne
  niepodręcznikowe wpisy oraz brak bazowego SP zachowują możliwość wpisania SP.
- Umiejętności mają krótki nagłówek; Inicjatywa bez „z podręcznika”.
- Opis pancerza uzupełnia liczbę TT, np. TT: 19 (naturalny pancerz).
  Szablon pokazuje bazową TT, statblock instancji jej aktualną TT.
- Z prezentacji zasad, zdolności i profili broni usunięto wskazane dopiski
  o źródłowych niespójnościach, ręcznym wpisywaniu inicjatywy, rozliczaniu przez
  MG, jednej Akcji/pod-atakach i braku Testu Ataku. Warunki, liczby, rzuty
  obronne, decyzje o wariantach oraz wyjątki mechaniczne pozostają.
- Usunięto ozdobne 05 STAŁYCH SLOTÓW, dopisek o nakładce Zombie przy wynikach
  oraz zdanie „Niezależne kopie do każdej potyczki.” pod Bestiariuszem.
- Zaktualizowano dokumentację i wersję aplikacji. Pięć rzeczywistych slotów bez zmian.

## Dane i migracje

Brak migracji SQL. Wszystkie cztery partie Bestiariusza i migracje 001–008
pozostały identyczne bajtowo. Wspólna prezentacja obejmuje także stare kopie
w potyczkach, bez przepisywania ich danych. Edytory zachowują źródłowe teksty
jako materiał do ręcznej edycji; usunięcie dopisków dotyczy widoków kart i akcji.
Nie nadpisano wcześniejszych SP ani nie zmieniono obliczeń trudności. Ręczne
nazwy ruchu nadal są zachowywane, a starszy zapis Chód pozostaje obsługiwany.

## Weryfikacja

- pnpm check: 219 testów / 45 plików; TypeScript, lint i formatowanie OK.
- Rust: 51/51 testów. cargo fmt --check oraz git diff --check OK.
- pnpm build:macos: OK, NeuroAltar 0.21.1 arm64. Osobny build QA również OK.
- Natywny test na osobnej bazie: statyczne SP Megatora i pole SP ręcznego formularza; Neogator — Szybkość 6m, Pływanie 21m, TT: 19 (naturalny pancerz), krótkie nagłówki i oczyszczone akcje; usunięte podpisy Bestiariusza. Ponowne otwarcie 0.21.1, skrót ⌘4, polskie nazwy, ⌘Q i przycisk zamknięcia OK. Po zamknięciu wszystkie osiem tabel identyczne względem bazy przed poprawkami: 5 slotów, 7 postaci, 42 szablony, 37 wpisów logu, 2 statusy, 42 wpisy rejestru seed; integrity_check/FK OK. Baza użytkownika nie była używana do testów.

## Pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/domain/enemy.ts`
- `src/domain/statblock.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/DeathBreathPanel.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/injuries/InjuryPanel.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `src/features/statblocks/RuleText.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `src/stores/combatStore.ts`
- `tests/statblockPresentation.test.ts`
- `src/domain/presentation.ts`
- `tests/presentationCopy.test.ts`
- `docs/CZYTELNOSC_0.21.1.md`

## Dostarczenie

Aplikacja: src-tauri/target/release/bundle/macos/NeuroAltar.app, wersja 0.21.1.
Poprzedni build: NeuroAltar 0.21.0.app obok. Podpis gotowego pliku sprawdzony.
Commit: fix: simplify statblock labels and annotations; hash w raporcie końcowym zadania.
Lokalny build macOS arm64, podpis ad hoc; bez notaryzacji i testu Windows/Intel.
Nie rozpoczęto żadnego kolejnego etapu.
