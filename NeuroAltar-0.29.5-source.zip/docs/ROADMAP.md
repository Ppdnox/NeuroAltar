# NeuroAltar — mapa etapów

Stan: **2026-11-09**. Aktualny zakres: [STATUS](STATUS.md).
Numer etapu nie jest numerem wersji; obecna wersja techniczna to **0.29.5**.

| Etapy           | Zakres                                                                                              | Stan                                                                                                                        |
| --------------- | --------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| 0–14, w tym 1.5 | Fundament aplikacji, pięć potyczek, walka, Bestiariusz, profile broni, awarie, trudność, zapis i UX | Wdrożone; raporty ETAP_*.md zachowano.                                                                                      |
| 15–19, 18A/18B  | Ekran startowy, pełne statblocki i podręcznikowe partie Bestiariusza                                | Wdrożone.                                                                                                                   |
| 20–22           | Ekwipunek, Wiedza MG i roller                                                                       | Wdrożone; później uzupełnione o tabele, pojazdy i Moloch City.                                                              |
| 23              | Odbiór Panelu MG na macOS                                                                           | Wykonany; [raport](ETAP_23.md).                                                                                             |
| 24A–24D         | Projekt, rozwój, inwentarz/amunicja, zdrowie, odpoczynki i postój BG                                | Wdrożone; [24B](ETAP_24B.md), [24C](ETAP_24C.md), [24D](ETAP_24D.md).                                                       |
| 24E             | Powiązanie BG z walką i rollerem, mechanika zdolności, przebudowa UI i poprawki                     | Wdrożenia są w 24E Roboczym; pełny odbiór sesyjny nadal otwarty. [Stan zdolności](24E_BRAKI_ZDOLNOSCI.md).                  |
| 25              | Windows: cały Panel MG i Karta BG                                                                   | Przygotowanie buildu zlecone 2026-11-08. Instalator i odbiór na Windows jeszcze niezweryfikowane. [Plan](BUILD_WINDOWS.md). |

## Bieżąca kolejność

1. Wdrożono osiem poprawek karty BG w 0.29.5: [raport](POPRAWKI_8_2026-11-09.md).
2. Przekazać przygotowane źródła i instrukcje do pracy na komputerze Windows.
3. Zbudować i sprawdzić instalator Windows oraz dokończyć odbiór sesyjny 24E.
   Przygotowanie Windows nie jest deklaracją wcześniejszego odbioru macOS.
4. Po wynikach prób poprawić potwierdzone błędy i oznaczyć rzeczywiście odebrane wydanie.

Truciciel/Pogromca: produkcja ręczna, zgodnie z decyzją 2026-11-08; nie są zadaniem
implementacyjnym. Premie sytuacyjne, zdolności narracyjne, przerzuty i łączenie
efektów pozostają w zaakceptowanym zakresie. Dalsze pomysły opisuje
[plan prac](PLAN_DALSZYCH_PRAC.md).

Szczegółowa historyczna roadmapa: `git show 1aeab92:docs/ROADMAP.md`.
Raporty etapów są źródłem historii, nie instrukcją cofania implementacji.
