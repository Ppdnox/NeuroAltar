## Etap 24E — rozstrzygnięcia MG, 2026-09-20

- Przegrzewanie po seriach obowiązuje również w Chromie.
- Jeden cios daje najwyżej jedno Zranienie, także przy jednoczesnym krytyku,
  spadku do 0 PW i przekroczeniu progu Kondycji w Rdzy.
- Krwawienie odejmuje łącznie 1 PW na turę, niezależnie od liczby Zranień.
- Rzut nie odejmuje PW automatycznie; rozliczenie zdrowia pozostaje jawne.

Stan wdrożenia i pozostały zakres: [ETAP_24E.md](ETAP_24E.md).
Etap pozostaje w toku; ten zapis nie oznacza odbioru ani wydania aplikacji.

# Karta BG — Kolor gry i rozwój postaci

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.

Uzupełnienie Etapu24A na zlecenie MG, 2026-09-13. To specyfikacja przyszłej
funkcji, bez zmiany obecnej aplikacji. Źródło: **Neuroshima: Ostatnia Era,
s.201–203**, dodatkowo s.54,109–112,126. Fingerprint podręcznika podany
w [KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md).

## Status24C

Rozwój PW wdrożono w24B, inwentarz/amunicję/wycenę w24C.
Odpoczynki wdrożono w 24D. Integracja walki pozostaje w 24E. Starsze pytania poniżej
rozstrzygają najnowsze decyzje w DECISIONS (2026-09-13).

## Wybór na karcie

W prawym górnym rogu karty, obok tożsamości/poziomu, kompaktowe pole
**„Kolor gry: N/D / Rdza / Rtęć / Stal / Chrom”**. N/D oznacza podstawowe reguły
bez nakładki i jest domyślnym wyborem. Na wąskim ekranie pole przechodzi pod
nagłówek. Etykieta tekstowa i dostęp klawiaturą, nie sam kolor tła.
Pod wyborem dostępne krótkie objaśnienie aktywnych zmian oraz odsyłacz
„Neuroshima: Ostatnia Era, s.201–203”.

Kolory są opcjonalnymi zestawami zasad; wybór ma wpływ mechaniczny, nie tylko
wizualny. Pełny zestaw jest punktem wyjścia, pojedyncze odstępstwo MG zapisujemy
jawnie z powodem. Nie mieszać kilku Kolorów przez samo zaznaczenie wielu nazw.
Łączenie wybranych zasad może być późniejszą jawną korektą, nie domyślnym trybem.

`Character.rulesContext.gameColor` jest ustawieniem karty/kampanii tej postaci.
`TradeContext.color` pozostaje istniejącym kontekstem transakcji/rynku. Mogą
używać tego samego słownika nazw, lecz nie są tym samym stanem.
Zmiana kalkulatora cen **nie zmienia** poziomu, PW, choroby, odpoczynku ani Koloru
gry. Karta może jawnie przekazać swój Kolor do otwieranego kalkulatora rynku;
nie synchronizuje go w tle z wszystkimi kartami i potyczkami.

## Reguły nakładek

W tabeli zapisano różnice wobec podstawowych zasad. „Bez zmiany” oznacza bazę,
a nie wyłączenie reguły. Premia/kara PW dotyczy **awansu na kolejny poziom**,
nie początkowych12/16PW. Pełne tabele klas i PB pozostają takie same.

| Kolor / strona | Przyrost PW i odpoczynek                     | Pozostałe skutki karty                                                                                                                                                                                                                                     |
| -------------- | -------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| N/D            | Przyrost klasy+modKON; krótki4h/długi24h     | Zasady bazowe                                                                                                                                                                                                                                              |
| Rdza / 201     | Przy każdym awansie PW−2; krótki24h/długi72h | Choroba i leki na3dni; do usunięcia Zranienia konieczna opieka medyczna; nowe Zranienie powoduje krwawienie1PW na początku tury; Medycyna INT ST10 w Pomaganiu zatrzymuje je. Jednorazowy cios≥wartośćKON daje Zranienie. Szabrowanie daje połowę surowców |
| Rtęć / 201–202 | Przy każdym awansie PW−3; czasy bazowe       | Fobia; opieka medyczna do usunięcia Zranienia; krwawienie jak Rdza; brak natychmiastowych środków leczących, np.medpak/AR-23; brak Fuksów                                                                                                                  |
| Stal / 202     | Przy każdym awansie PW+1; czasy bazowe       | Krwawienie jak Rdza;1Fuks na sesję, niewykorzystany przepada; Ułatwienie RO przeciw Przerażeniu; krytyk przy naturalnym19–20 w Teście Ataku                                                                                                                |
| Chrom / 203    | Przy każdym awansie PW+2; krótki1h/długi8h   | 1Fuks na sesję; Ułatwienie rzutów przeciw śmierci; broń nie zacina się/nie uszkadza, pancerz nie uszkadza się; domyślnie nieliczony zapas i pusta broń przy naturalnej1 (decyzja MG24C)                                                                    |

Awaryjność Rdzy: automatyczne pistolety/karabiny1–4, pozostała palna1–3,
biała uszkodzona1–2. Rtęć: automatyczne1–3, pozostała palna1–2. Rodzaj
automatyczny musi wynikać ze zweryfikowanego profilu broni, nie wyszukania słowa
w nazwie. Specjalne zdolności zapobiegające zacięciu są odrębnymi regułami.
Decyzja MG Q-08: zacięcie na pierwszym wystrzale zużywa akcję, ale nie naboje.
To **zacięcie broni**, nie tabela20awarii maszyny z aktualnego Panelu MG.

Handel: Rdza cena×2/dostępność×0,5; Rtęć baza; Stal cena×0,5/dostępność×2
tylko weapon/ammunition; Chrom cena×1/dostępność×2. Istniejące funkcje rynku
zachowują bazowe mnożniki, z zatwierdzonym przez MG wyjątkiem24C:
środki leczące w Chromie kosztują połowę (s.203), zarówno dla MG, jak i BG.
Gambling we krwi dodaje5pp przed mnożnikiem Koloru; zakres0–100 na końcu.

## Historia rozwoju i zmiana Koloru

Każdy wpis awansu zapisuje `rulesContextRevision`, `gameColor`, przyrost PW
klasy oraz zastosowaną korektę Koloru. Późniejsze przeliczenie KON używa historii
awansów, a nie mnoży aktualną karę Koloru przez wszystkie wcześniejsze poziomy.

Przykład: Twardziel z KON16 ma na1poziomie19PW. Przy stałym Kolorze na5poziomie:
N/D47PW, Rdza39PW, Rtęć35PW, Stal51PW, Chrom55PW. Przyrost jest naliczany
cztery razy. Przy KON18 każdy z tych wyników rośnie o5PW, nie o4PW.

Wybranie innego Koloru istniejącej postaci najpierw otwiera podgląd zmian:
rozwój, odpoczynki, Fuksy, choroby/fobie, krytyki, zacięcia i tryb amunicji.
Domyślny zakres to **od teraz**: przyszłe awanse i czynności, bez ponownego
rozdawania dawek, chorób, Fuksów lub przepisywania historii. Opcja **przelicz
historię rozwoju** wymaga osobnego jawnego wyboru MG i pokazania nowych PW
maksymalnych, skutków dla aktualnych PW i braków. Sama zmiana selektora nie leczy.
Zmiana Koloru nie usuwa nabytej choroby/fobii ani obrażeń; takie skutki mają
własną jawną operację. Rozpoczęty odpoczynek zachowuje kontekst z chwili startu;
zmiana zasad w jego trakcie wymaga ponownego podglądu, nie darmowego ukończenia.

Decyzja MG z 2026-09-13: **minimum 0 PW na awans**. Każdy późniejszy
przyrost to max(0, przyrost klasy + bieżący modyfikator KON + Kolor tego awansu).
Nie odejmować PW za ujemny wynik i nie dodawać minimum1. Pierwszy poziom
zachowuje wzór startowy, bez premii/kary Koloru. Wdrożone i przetestowane w24B.

## Amunicja Chromu a wcześniejsze wymagania MG

Wcześniej MG zlecił dokładne liczenie magazynków i zapasu **wyłącznie dla BG**.
Nowa prośba o Kolory nie kasuje tego wymagania. Projekt przewiduje
`ammoMode: tracked | cinematic` jako jawne odstępstwo/profil, a nie samoistne
wyczyszczenie pól po wyborze Chromu. Decyzja MG24C: domyślnie nieliczony zapas
z pustą bronią przy naturalnej1; jawny wybór dokładnego liczenia pozostaje
możliwy. W24C służą do tego przyciski, podłączenie do testu ataku nastąpi24E.

Tryb nieliczony musi nadal przechowywać stan załadowania i komunikat pustego
magazynka, a także zachować dawny dokładny zapas do porównania/przywrócenia.
Nie wpisywać fikcyjnego nieskończonego zapasu ani masy0. Naturalna1 daje
propozycję oznaczenia pustego magazynka, z jawnym zastosowaniem; nie psuje broni.
Reguła s.126 proponuje k6 po DS/MS:5–6 pozwala na kolejną serię w następnej
turze,1–4 daje przegrzanie i ryzyko trwałego uszkodzenia. To sprzeczne
z niezniszczalnością Chromu na s.203; do decyzji MG, nie automatycznej kumulacji.
Nie przenosić tego sposobu liczenia na przeciwników.

## Macierz uzupełniająca

| ID / etap    | Reguła → źródło                      | Obliczenie / wymagany test                                                                                                                                |
| ------------ | ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| COL-01 / B   | N/D, wybór Koloru → decyzja MG       | N/D dokładnie daje wyniki BG-01…42 bazowe; przełączenie rynku nie zmienia karty                                                                           |
| COL-02 / B   | Przyrosty PW → s.201–203             | Przykład19→47/39/35/51/55 na5poziomie; kara nie dotyczy pierwszego poziomu i nie nalicza się dwukrotnie                                                   |
| COL-03 / B   | Historia zmiany → kontrakt aplikacji | StartN/D, awans2wRdzy i3wStali, KON3:19+5+8=32; wybór Chromu na3poziomie nie zmienia32 bez jawnego przeliczenia                                           |
| COL-04 / D   | Czasy → s.201,203                    | N/D4/24,Rdza24/72,Rtęć4/24,Stal4/24,Chrom1/8 godzin; restart nie kończy odpoczynku                                                                        |
| COL-05 / D   | Choroba/fobia → s.54,109–112,201–202 | Rdza żąda wyboru choroby, Rtęć fobii; raz na tworzenie odpowiednia nagroda i zapas; zmiana selektora nie farmi leków ani +1cechy                          |
| COL-06 / D,E | Krwawienie/gojenie → s.201–202       | Zranienie generuje źródło krwawienia i przypomnienie, nie auto-PW; sama regeneracja bez medyka nie usuwa rany Rdzy/Rtęci                                  |
| COL-07 / D,E | Fuksy → s.202–203                    | Rtęć nie przyznaje zwykłych Fuksów; Stal/Chrom token na sesję dokładnie raz, koniec sesji usuwa tylko ten token; konflikt zdolności patrz pytania         |
| COL-08 / E   | Krytyki i RO → s.202–203             | Stal naturalne19 daje krytyk, suma19 przy kości18 nie; normalny tryb kość19 bez krytyka. Chrom przewaga rzutu przeciw śmierci jako jawny wyjątek od BG-20 |
| COL-09 / E   | Awaryjność → s.201–203               | Każdy próg i próg+1 dla automatycznej/pozostałej/białej; brak mylenia z awarią maszyny; Chrom1 oznacza pusty magazynek, nie uszkodzenie                   |
| COL-10 / C,D | Leczenie/surowce → s.201–203         | Rtęć blokuje użycie zakazanego natychmiastowego środka, nie usuwa Item; Rdza połowa uzyskanych surowców, nie dowolnego posiadanego stosu                  |
| COL-11 / C,E | Amunicja Chromu → s.126,203          | Domyślnie nieliczony zapas; zmiana trybu zachowuje dawny stan, nie tworzy naboi; alarm pustego magazynka w obu trybach                                    |
| COL-12 / B–E | Zmiana kontekstu → kontrakt          | Podgląd+revision+operationId; anulowanie neutralne; powtórzenie nie zmienia ponownie przyrostu/zasobów; istniejące NPC bez zmian                          |

Kolorowanie naturalnego20 na zielono i1 na czerwono pozostaje. Krytyk Stali
z19 otrzymuje opis/oznaczenie krytyka; nie udawać naturalnego20. Brutal11
potraja kości również przy kwalifikującym się krytyku Stali; modyfikator raz.

## Dodatkowe interpretacje do rozstrzygnięcia

- **COL-Q1 — częściowo rozstrzygnięte24C:** Chrom ma nieliczony zapas i pustą broń przy1. Przegrzanie s.126 kontra niezawodność s.203 pozostaje do24E.
- **COL-Q2 — rozstrzygnięte24C:** środki leczące w Chromie cena×0,5 dla MG i BG. Pozostałe ceny Chromu×1.
- **COL-Q3 — częściowo rozstrzygnięte:** minimum0 PW na awans ustalone przez MG.
  Nadal otwarte: liczba Zranień przy
  jednoczesnym krytyku, spadku do0 i progu KON; czy kilka ran kumuluje krwawienie.
- **COL-Q4 — rozstrzygnięte24D:** Rtęć blokuje każdy Fuks, w tym startowy,
  Muzyka i inne źródła. Zachowane wcześniej tokeny pozostają zapisane, ale nie
  można ich użyć podczas gry na Rtęci; terminowe nadal wygasają w czasie gry.
- **COL-Q5 — rozstrzygnięte24D:** korzyści krótkiego po przerwaniu długiego
  wymagają progu Koloru: Rdza24h, Chrom1h, N/D/Rtęć/Stal4h.

Wszystkie nakładki są przewidziane do pełnego odbioru24E. W24B wdrożono wybór
Koloru, historię i przeliczenie PW; w24C tryb amunicji i powiązanie z inwentarzem;
w24D odpowiednie odpoczynki/zdrowie/Fuksy; w24E testy, krytyki i awaryjność.
Wybór nie może być przedstawiony jako w pełni działający, gdy wdrożono tylko PW.
