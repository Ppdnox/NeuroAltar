# Etap 11 — Trudność potyczki (0.12.0)

## Rezultat

Panel nad walką zapisuje poziomy BG osobno w każdym z pięciu slotów. Nie zmienia
minimalnych kart BG i nie synchronizuje listy automatycznie ze składem bohaterów.
SP szablonu w Bestiariuszu i Aktualne SP instancji są niezależne; liczby dziesiętne
z przecinkiem są obsługiwane. Puste pole oznacza brak danych, jawne 0 jest wartością.

SD jest sumą poziomów, SP sumą wszystkich obecnych przeciwników. Także postać przy
0 PW lub zniszczona wnosi SP — kalkulator ocenia skład spotkania. Przy brakującym
SP pokazuje znaną sumę i liczbę braków; całkowite SP, ratio i wskaźnik są N/D.
Przy SD=0 nie ma dzielenia przez zero, NaN ani Infinity.

Pasek jest ciągły, z gradientem zielony/żółty/pomarańczowy/czerwony i punktami
~100% Łatwa, ~150% Wyczerpująca, ~200% Ryzykowna, ~300% Zabójcza. Wskaźnik kończy
się na 300%, ale wynik liczbowy jest nadal pokazywany powyżej skali.

Doprecyzowanie użytkownika: przedziały pośrednie zmieniają nazwę przy dokładnie
126%, 176% i 251%. [0,126) Łatwa, [126,176) Wyczerpująca, [176,251) Ryzykowna,
od 251 Zabójcza. Wartości ułamkowe porównuje domena bez zaokrąglania; format
liczbowy PL w UI pokazuje do czterech miejsc po przecinku. Brak dodatkowych kresek.

## Persistence i migracje

Brak nowej migracji SQL. Migracje 001–006 pozostają niezmienione. Poziomy używają
istniejącego party_levels_json; SP istniejących JSON katalogu/runtime/prepared.
Stare dane bez SP są poprawne. Zod i Rust walidują nieujemne, skończone SP.
Sumy są kontrolowane względem Number.MAX_SAFE_INTEGER.

Surowe wpisy pozostają w formularzu przy błędzie walidacji lub zapisu. Poziomy
korzystają z kolejki autozapisu metadanych (nazwa/notatki), z ochroną nowszych zmian.
Dotychczasowi wywołujący updateDetails bez partyLevels zachowują kolumnę.
SP zapisuje się atomowo z rewizją, snapshotem i logiem sp_changed. Zapis walki
nie nadpisuje poziomów. Reset przywraca przygotowane SP, bez zmiany listy poziomów.
Zmiana katalogu wpływa wyłącznie na nowe kopie; BG nie dostają SP.

## Weryfikacja

- pnpm check: TypeScript, ESLint, Prettier; 164/164 testów w 29 plikach.
- cargo test --manifest-path src-tauri/Cargo.toml --release --lib: 32/32.
- cargo fmt --manifest-path src-tauri/Cargo.toml --check: OK.
- pnpm build:macos: produkcyjny bundle arm64 0.12.0 z podpisem ad hoc.
- git diff --check, niezmienione migracje 001–006, kontrola podpisu codesign.
- Testy nowych zachowań: punkty podręcznika i granice pośrednie, ciągłość wskaźnika,
  wartości ponad 300%, SD0/SP0/brak SP, polski zapis i błędne/niebezpieczne liczby,
  niezależność template/runtime/prepared, 0 PW, reset, pięć list poziomów,
  in-flight autosave, retry, zamykanie i ponowny odczyt. Rust sprawdza też rollback
  SP razem z logiem, pojedyncze retry i zachowanie poziomów przez reset walki.

## Test natywny macOS

Oddzielny bundle i baza pl.neuroshima.combat-tracker.stage11-smoke.
Cztery poziomy 4 w osobnych wierszach dały SD16. Szablon „Żółw z Pustkowi”,
TT16/PW88/SP8, z polskim wielowierszowym ruchem został dodany ×3: SP24, 150%
Wyczerpująca. Aktualne SP jednej kopii 4,16 dało SP20,16, 126% Wyczerpująca.
Zmiana na16 dała SP32 i200% Ryzykowna, z osobnymi wpisami SP w logu; prepared
pozostało SP8. Wizualnie sprawdzono gradient, wskaźnik i czytelne kotwice.

Drugi slot pozostał pusty i miał SD0/N/D. Błędny wpis poziomów 6/0 po przełączeniu
slotu zatrzymał ⌘Q i ujawnił drugi slot, zachowując surowe dane. Po korekcie na6/7
oraz zapisaniu notatki „Żółta brama” w dwóch wierszach ⌘Q zakończyło proces.
Restart końcowej aplikacji testowej zachował poziomy4/4/4/4, aktualne SP16 i wynik
200% w pierwszym slocie, a poziomy6/7 (SD13) oraz dokładną polską notatkę w drugim.
Stopka wskazuje Etap11. Sprawdzono także zamknięcie przyciskiem okna.
Testy nie korzystały z bazy użytkownika.

## Dostarczenie

Docelowe repozytorium: /Users/dominik/Desktop/Combat Tracker.
Punkt wyjścia: czysty checkpoint Etapu 10 bb14b3d. Testy prowadzone w izolowanej
kopii; zastosowanie wymaga zgodnego HEAD, czystego drzewa, kontroli patcha SHA256
i końcowego drzewa Git. Docelowy bundle: src-tauri/target/release/bundle/macos/NeuroAltar.app.
Poprzedni bundle zostaje jako NeuroAltar 0.11.0.app. Baza użytkownika nie jest
otwierana podczas testów ani kopiowana, kasowana lub odtwarzana przy dostarczeniu.

## Ograniczenia przed Etapem 12

- Poziomy i SP wpisuje MG; nie ma prywatnego seeda, automatycznego poziomu z PB
  ani odgadywania SP. Należy aktualizować listę poziomów po zmianie składu BG.
- Panel jest podglądem bieżących wpisów; stan zapisu nadal pokazują kontrolki
  metadanych i walki. Błędny wpis w innym polu aktora może wstrzymać jego autozapis.
- Surowy szkic nie przetrwa wymuszonego zabicia procesu; normalne zamknięcie i ⌘Q
  chronią zmiany. Zatwierdzone liczby są trwałe w SQLite.
- Wersje 0.11.0 i starsze nie znają SP. Nie zapisuj nimi danych po tej aktualizacji.
  Kopia starego bundle'a nie przywraca poprzedniej bazy.
- Podpis lokalny ad hoc, bez notaryzacji Apple. Bez nowego silnika rzutów,
  ammo trackingu, importera, pełnego Ekwipunku ani zmian Etapu 12.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_11.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/difficulty_tests.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/db/encounterRepository.ts`
- `src/domain/bestiary.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/difficulty.ts`
- `src/domain/encounterDetails.ts`
- `src/domain/enemy.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/difficulty/DifficultyPanel.tsx`
- `src/features/encounters/EncounterWorkspace.tsx`
- `src/stores/bestiaryStore.ts`
- `src/stores/combatStore.ts`
- `src/stores/encounterStore.ts`
- `tests/difficulty.test.ts`
- `tests/difficultyStore.test.ts`
- `tests/encounterStore.test.ts`
