# Poprawki mechaniki 24E — partia 2, 2026-09-24

Kontynuacja roboczego 24E, bez cofania zaakceptowanego układu. Podstawa: Neuroshima: Ostatnia Era, rozdziały klas, profesji i sztuczek (drukowane s. 72–79, 86–89, 98, 104–107) oraz decyzje MG. To raport wdrożenia, nie pełny odbiór 24E.

## Wprowadzone

- Ulubiona broń: jawne rozliczenie bonusowego ataku po Atakowaniu tym modelem w bieżącej turze. Dla broni palnej wspólny zapis amunicji i Akcji Bonusowej; odrzucona operacja nie zużywa części zasobów. Obsługa ataków wręcz ma oddzielne rozliczenie budżetu. Nie rozstrzygamy trafienia i nie odejmujemy PW.
- Szczęście: wybór pierwotnego testu z bieżącej rundy, zachowanie Ułatwienia/Utrudnienia, przerzut inicjatywy zapisujący nową inicjatywę. Powiązanie z pierwotnym rzutem i zużycie przygotowanego efektu zapisują się razem. Zwykły test nie zużywa Szczęścia.
- Zdolności wielocelowe: jeden koszt dla wskazanych aktywnych BG, kontrola aktualności każdego celu i wycofanie całej operacji przy konflikcie. Łaska Boża ma limit celów względem poziomu Cwaniaka; nowa kość k4 trafia do każdego pasującego ataku/RO.
- Gotowe ustawienia i objaśnienia wybranych zdolności: Motywacja, Mózg, Porada, Obrona, Łaska Boża, Let’s Rock, Mój Bóg kule nosi, Neo, Stabilne ręce, Obelga oraz Spieprzysz to. Warunki sytuacyjne nadal potwierdza gracz.
- Let’s Rock: premia według wyniku Występów/instrumentu, wybór ataków albo RO, termin zakończenia oraz przerwanie przez odpowiednie stany wykonawcy.
- Efekty przeciwników: widoczne w potyczce; jawny wybór efektu do rzutu pozwala potwierdzić warunek Obelgi. Spieprzysz to powtarza kwalifikujący się atak/RO przeciwnika i zachowuje gorszy wynik.
- Zakresy efektów ograniczają premię do właściwych rzutów i broni. Rutyna daje bojowe Ułatwienie RO ZRC/MDR. Narzędzia i instrumenty w karcie mają klikalne testy.

## Zmienione pliki tej partii

- Modele: src/domain/character/combatAbility.ts, participation.ts, inventoryModel.ts; src/domain/dice.ts.
- Obliczenia i zapis: src/services/characterRolls.ts, actorDice.ts; src/stores/diceStore.ts, initiativeStore.ts, npcAbilityRollStore.ts.
- Interfejs: src/features/character/CombatAbilities.tsx, CharacterCombatRolls.tsx, CharacterWorkspace.tsx, InventoryPanel.tsx, NpcAbilityEffects.tsx; src/features/combat/CombatWorkspace.tsx.
- Backend: src-tauri/src/character_participation.rs, character_inventory.rs, dice.rs.
- Testy: tests/combatAbilityRules.test.ts oraz test transakcyjny w character_participation.rs.
- Dokumentacja: niniejszy raport, ETAP_24E.md, AUDYT_24E_MECHANIKA.md.

## Weryfikacja i dane

Zaliczone: kontrola typów, lint, 46 testów TypeScript w sześciu wybranych zestawach oraz pięć testów Rust udziału w potyczce. Nowy test potwierdza jednokrotne pobranie kosztu dla wielu celów i pełne wycofanie operacji przy nieaktualnym celu. Testy przerzutów sprawdzają gorszy wynik, pojedyncze doliczenie modyfikatora i zachowanie wyniku przy ponowieniu zapisu.

Bez nowej migracji SQL w tej partii. Rozszerzenia zapisów JSON są opcjonalne; zachowano wcześniej dodaną migrację 014 i pozostałe robocze zmiany. Nie ingerowano w bazę użytkownika ani produkcyjną aplikację. Pełna regresja i ręczny odbiór macOS pozostają odroczone zgodnie z decyzją MG.

## Pozostałe ograniczenia

- Nie wszystkie zdolności katalogu mają indywidualny preset. Pozostałe warunkowe premie nadal wymagają jawnego ustawienia i potwierdzenia; nie deklarujemy pełnej automatyzacji wszystkich klas i pochodzeń.
- Szczęście wybiera z dostępnej historii 100 rzutów. Powtórny przerzut już przerzuconego testu jest blokowany; łączenie kilku różnych źródeł przerzutu wymaga dalszej obsługi.
- Spieprzysz to obsługuje obecnie przeciwnika z potyczki, nie wymuszony przerzut innego BG. Sukces pierwotnego testu i zasięg potwierdza gracz. Wybierany jest ostatni kwalifikujący się test.
- Panel przeciwnika pozwala wybrać jeden dodatkowy efekt do rzutu; łączenie kilku efektów wymaga rozszerzenia. Wielocelowe premie sojusznicze obejmują aktywne powiązane BG.
- Neo wymaga zakończenia efektu po rozliczeniu danego trafienia. Rzuty nie rozstrzygają trafień ani obrażeń zdrowia.
- Model własnej broni musi odpowiadać wyborowi Ulubionej broni. Nie dodano automatycznej klasyfikacji dowolnych nazw.

24E pozostaje w toku. Wyłączenia MG (towarzysze na przyszłość, automatyczne przerwanie Berserka, dalsza automatyzacja zacięć/przegrzania, leki w walce, konwersja starego BG) nadal obowiązują.

Build macOS zakończony powodzeniem: `NeuroAltar 24E Roboczy.app` w `work/stage2-target/release/bundle/macos/` projektu ChatGPT Neuroshima 5e. Podpis lokalny; bez notaryzacji. Ostrzeżenia bundlera dotyczą wielkości paczki i współdzielonych importów. Nie przeprowadzono nowego ręcznego testu natywnego UI.
