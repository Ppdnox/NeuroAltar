# Etap 10 — Awarie maszyn (0.11.0)

## Rezultat

Próg awarii w szablonie Bestiariusza i osobno w instancji. Ręczny wynik k20,
podgląd tabeli 1–20, jawne Zastosuj i indywidualne naprawy. Próg dotyczy obrażeń
pojedynczego ataku większych od wpisanego progu, nie pozostałych PW. Puste pole
jest brakiem danych. Opcjonalne obrażenia w formularzu nie odejmują PW.

Wszystkie 20 wyników ma obsługę zgodną z PRODUCT_SPEC i opisanymi konwencjami:

- 1 wskazuje konkretną broń; przedmiot pozostaje, oznaczony jako zniszczony.
- 2 mnoży ruch ×0,5; 3/14 dają −2/−4 do ataku; 13 daje −2 do efektywnego TT.
- 4 wymaga wybrania Bonusowych albo Legendarnych; 9 blokuje Reakcje.
- 5/8/11/12 dodają odpowiednie statusy; 5/10/12 kończą się po następnej własnej
  turze. 10 blokuje Akcje i Bonusowe. Obecny koniec pomijany, gdy efekt zastosowano
  podczas własnej tury. Korekta tury, restart i przygotowanie nie odliczają.
- 6 odejmuje 50 PW z ograniczeniem do 0 i oznacza brak amunicji. Brak licznika.
- 7 przypomina o jednym ataku mniej, 15 o połowie obrażeń wręcz; 16 oznacza brak
  ataków wręcz. 17/18 pozostawiają zachowanie i wybór celu MG.
- 19 oznacza wyłączenie; 20 ustawia 0 PW i zniszczenie z przypomnieniem o
  autodestrukcji. Bez usuwania, pomijania tury i obrażeń innych postaci.

Kary TT/ruchu/ataku są pochodną aktywnych awarii. Wpisane wartości bazowe pozostają,
więc naprawa zdejmuje tylko wybraną karę. Ataki wylicza domena, ruch uwzględnia
wcześniejsze Zranienia/Wyczerpanie. Blokady akcji zachowują jawny wyjątek MG.
Każde Zastosuj jest osobnym wpisem; kary liczbowe kumulują się. Naprawa usuwa
wybraną awarię i jej własny status, ale nie leczy utraconych PW.

## Dostarczenie

Repozytorium docelowe: `/Users/dominik/Desktop/Combat Tracker`.
Punkt wyjścia: czysty commit Etapu 9 `01e51f4`. Przygotowanie i testy w izolowanej
kopii, następnie zastosowanie z kontrolą bazowego HEAD, czystości, hasha patcha
i zgodności końcowego drzewa Git. Aplikacja docelowa:
`src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.11.0.
Poprzedni bundle zachowany jako `NeuroAltar 0.10.0.app`.

## Migracje i ochrona danych

**Brak nowej migracji SQL.** Migracje 001–006 pozostają bez zmian.
Opcjonalne failureThreshold/machineFailures mieszczą się w istniejących JSON
szablonu, runtime i prepared. Statusy używają istniejącej tabeli actor_statuses.
Stare dane bez pól są nadal poprawne. Próg i awarie mają walidację Zod/Rust.

Awarie, zmiany PW, statusy, snapshot, rewizja i log zapisują się w jednej transakcji.
Nieudany zapis zachowuje dokładny checkpoint do ponowienia. Formularz zachowuje
surowe wpisy i blokuje zamknięcie, ujawniając właściwy slot. Reset przywraca
prepared bez ponownego stosowania uszkodzeń. Inne instancje i szablon są niezależne.
Baza użytkownika nie była otwierana ani odtwarzana podczas testów i dostarczenia.

## Testy i build

- `pnpm check`: TypeScript, ESLint, Prettier, **156/156 testów w 27 plikach**.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: **30/30**.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: arm64 0.11.0, podpis ad hoc.
- `git diff --check`; kontrola niezmienionych migracji i końcowego drzewa Git.
- `codesign --verify --deep --strict` dla dostarczonej aplikacji.

Nowe testy: każdy wynik 1–20, złe liczby/cele/czas, TT/ruch/atak, kumulacja i
naprawy, wyjątek MG, granice PW, niezależność danych, pełny reset i czas własnej
tury. Store testuje błędny formularz, close guard, awarię zapisu, pojedyncze retry
i ponowny odczyt. Rust testuje wycofanie HP razem z awarią/logiem, odczyt danych,
próg katalogu, aktywny timer w prepared i zachowanie pięciu slotów.

## Test natywny macOS

Oddzielna aplikacja i baza `pl.neuroshima.combat-tracker.stage10-smoke`.
Maszyna „Żółw Naprawczy”, TT 16, PW 88, inicjatywa 12, próg 20,
ruch „Chód: 9” oraz „Lot: 4,5” w osobnych wierszach.

- Wynik 21 odrzucony; ⌘Q zachowało formularz i polską wielowierszową notatkę.
- Podgląd progu: 20 nie przekracza 20, 21 przekracza 20. Sam podgląd nie zmienia PW.
- Wynik 13: kolejka i podsumowanie TT 14, pole bazowe 16 z właściwą etykietą.
- Wynik 2: podgląd 4,5 / 2,25 m, bazowe wartości 9 / 4,5 m zachowane.
- Wynik 6: PW 88 → 38, osobne wpisy HP i awarii w logu tej samej zmiany.
- Wynik 10 podczas tury: blokada Akcji i Bonusowych, Reakcja dostępna; pierwszy
  koniec zmniejszył licznik 2 → 1. ⌘Q zakończyło proces po zapisie.

- Restart na końcowym buildzie zachował 38/88 PW, TT 14, bazowy ruch, trzy
  trwałe awarie, notatkę i licznik czasowy 1. Następne Next Turn usunęło blokadę
  10 i przywróciło dostępność Akcji/Bonusowych. Nowy log podał pozostałe końce tur.
- Prepared nadal miał 88 PW, TT 16 i ruch 9/4,5. Bestiariusz zachował te bazowe
  wartości oraz próg 20. Skontrolowano wygląd poprawionych przycisków formularza.
- Zamknięcie przyciskiem okna zakończyło proces. Naprawy, reset i pozostałe
  wyniki sprawdzono automatycznie; testy nie korzystały z bazy użytkownika.

## Ograniczenia przed Etapem 11

- Zastosowanie wymaga oceny MG: program nie sprawdza odporności statblocka,
  nie wybiera automatycznie kolejnego pasującego wyniku i nie wykonuje k20.
- Uszkodzenia broni, liczba ataków i połowa obrażeń są informacją na profilu,
  nie silnikiem wykonywania ataków. MG może oznaczyć naprawę/koniec efektu.
- Ręczna edycja powiązanego statusu jest nadal dostępna. Wpis awarii można
  zakończyć osobno; naprawa usuwa tylko status z ID tej awarii.
- Maksimum 1000 aktywnych awarii jednej instancji. Bez katalogu pojazdów, seeda,
  licznika amunicji, rzutów, trudności Etapu 11 i pełnego Ekwipunku v1.1.
- Szkic formularza nie przetrwa wymuszonego zabicia procesu. Zwykłe zamykanie i ⌘Q
  są chronione; zatwierdzony stan jest trwały w SQLite.
- Wersje 0.10.0 i starsze nie znają nowych pól; nie używać ich do zapisywania
  danych z awariami. Kopia starego bundle'a nie cofa bazy.
- Podpis ad hoc bez notaryzacji Apple. Przy dostarczeniu sprawdzany jest atrybut
  FinderInfo dopisywany przez Pulpit; usuwany tylko z wygenerowanego bundle'a.
- Etap 11 wymaga osobnego zlecenia.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_10.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/bestiary.rs`
- `src-tauri/src/combat.rs`
- `src-tauri/src/combat_log.rs`
- `src-tauri/src/machine_failure.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/domain/bestiary.ts`
- `src/domain/capabilities.ts`
- `src/domain/combat.ts`
- `src/domain/combatLog.ts`
- `src/domain/enemy.ts`
- `src/domain/injury.ts`
- `src/domain/item.ts`
- `src/domain/machineFailureSchema.ts`
- `src/domain/machineFailureView.ts`
- `src/domain/machineFailures.ts`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/TemplateFields.tsx`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/combat/PreparationControls.tsx`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/equipment/LoadoutPanel.tsx`
- `src/features/injuries/InjuryPanel.tsx`
- `src/features/machine-failures/FailurePanel.tsx`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `tests/failureStore.test.ts`
- `tests/machineFailures.test.ts`
