# ACCEPTANCE TESTS

Uzupełnienie MG: wybór **Koloru gry** w rogu karty (N/D, Rdza, Rtęć, Stal, Chrom),
odrębny od handlu, z wpływem na rozwój i odpoczynki. Kontrakt i testy:
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).

## Etap 24B — dane, obliczenia i ekran BG (0.27.0)

Wdrożono trwałe karty BG i szkice z autozapisem, tworzenie postaci, historię
poziomów, wybory sześciu klas, profesji, pochodzeń i sztuczek, obliczenia
cech/biegłości/PW/obrony/ruchu/udźwigu oraz dziennik PD. Układ opiera się na
karcie PDF i dopasowuje kolumny do okna. Raport: docs/ETAP_24B.md.

Kolor gry jest osobny od handlu. W tym podetapie działa jego wpływ na rozwój PW,
z podglądem zmiany i historią Koloru każdego awansu. Decyzja MG z 2026-09-13:
**minimum 0 PW za każdy awans**, po KON i karze Koloru. Pierwszy poziom
zachowuje własny wzór. Samouk9; profesje Twardziela3/7/11.
Zmiana zatwierdzonego rozwoju wymaga powodu korekty MG; nie leczy bieżących PW.

Migracja011 dodaje tylko karty i historię operacji;001–010 oraz dane Panelu MG
pozostają zachowane. Stare BG nie są łączone automatycznie z nowymi kartami.
Następny osobno zlecany podetap: **24C — inwentarz, masa i amunicja BG**;
dalej24D zasoby/odpoczynki,24E integracja z walką i odbiór,25Windows.
Nie deklarować pełnej karty ani wszystkich efektów Kolorów przed odbiorem24E.
Reguły i kontrakt: docs/KARTA_BG_MECHANIKA.md, docs/KARTA_BG_KATALOG_REGUL.md,
docs/KARTA_BG_KONTRAKT.md, docs/KARTA_BG_KOLORY.md, docs/KARTA_BG_WZORZEC.md.

## Poprzedni etap: 23 — odbiór Panelu MG na macOS (0.26.0)

Etap 23 zlecony przez MG 2026-09-13, punkt wyjścia `c32c607` (0.25.4).
Raport odbioru: `docs/ETAP_23.md`. Zachowane wszystkie funkcje Etapów 0–22,
18A/18B i korekt 0.25.1–0.25.4. Poprawiono obsługę F1 i powrót fokusu z wyszukiwarki.
Na dodatkowe zlecenie MG poprawiono dwie reguły Wiedzy MG według podręcznika:
zniszczenie hełmu przy Krytycznej ochronie (s. 115) i Szybkość celu równa 0
we właściwości Długa (s. 118). Oryginalny zapis Excela pozostaje materiałem audytowym.
Etap 23 nie dodał migracji. Etap 24A został następnie zlecony i opracowany;
aktualny zakres opisuje sekcja powyżej. Windows pozostaje na końcu (25).
Import/eksport kampanii i backup z GUI odroczone poza zakres tego odbioru.
Nie są warunkiem odbioru wcześniej zleconych funkcji Panelu MG.


## Persistence
Zmień nazwę, dodaj aktorów, HP, status. Restart aplikacji. Stan identyczny.

## 5 slots
Każdy slot ma inne dane. Przełączenie nie miesza stanu. `⌘1–⌘5`.

## Initiative
3 identycznych przeciwników = 3 niezależne inicjatywy. Sort malejąco. Remisy ręcznie.

## Round
Po ostatnim aktorze nowa runda. Log zawiera zmianę.

## PCs
Tylko Imię/TT/PW/Inicjatywa/Statusy.

## HP
-1/-5/-10/+1, dowolne obrażenia, leczenie, ręczne ustawienie. Brak ujemnego HP.

## Statuses
Systemowy, własny, usunięcie, duration. Podpalenie przypomina 1k4.

## Injury
1: -4,5 m; 2: brak Reakcji; 3: brak Bonusowych; 4: +1 Wyczerpania; kolejny: death warning.

## Cowardice
88 HP i 50% => warning przy <=44. Bez automatycznego usunięcia.

## Resources
3/rundę odświeża się na nową rundę. 2/walkę nie. Reset przywraca prepared state.

## Weapon
PB +4 + ZRC +5 => +9 dla broni dystansowej. Runtime zmiana nie rusza template. Reset cofa runtime zmianę.

## Machines
13 => TT -2; 2 => speed x0,5; 6 => -50 PW. Reset przywraca prepared state.

## Difficulty
SD/SP/ratio poprawne. SD 0 bez NaN/Infinity.

## Reset
Skład i prepared wyposażenie zostają; runtime wraca do początku.

## Clear
Usuwa skład/log/notatki/runtime i wymaga potwierdzenia.

## Negative scope test
Nie ma dice rollera, ammo countera, chmury, kont, mapy.

## Etap 1.5 — architektura i regresja

- Etap 1 zapisany w Git przed zmianami. Zachowane pięć slotów, autozapis i migracja 001.
- Nazwa NeuroAltar spójna w bieżącej dokumentacji i aplikacji; stabilny identyfikator i URL SQLite.
- Brak UI Ekwipunku, Wiedzy MG, k100, wyboru regionu/lokalizacji/Koloru, importera Excel i funkcji Etapu 2.
- Pełne `pnpm check` i build macOS przechodzą. Nowa architektura nie wymaga migracji ani uruchamiania aplikacji na bazie użytkownika.

## Przyszłe funkcje rynkowe — przy ich implementacji

- Dla none/none/none cena bazowa {min: 10.5, max: 25} i dostępność {min: 20, max: 40} wracają dokładnie bez zmian.
- Sprawdź również pojedynczą wartość (min=max), 0%, 100%, brak danych null i brak mutacji Item.
- Każdy wymiar none działa niezależnie; region wpływa na cenę, lokalizacja na dostępność.
- Dostępność: dodawanie lokalizacji, mnożenie Koloru, dopiero clamp; oba końce zakresu.
- Każdy Kolor zgodny z tabelą DATA_MODEL. Stal zmienia weapon/ammunition; armor/tool/electronics/food/fuel/other zachowują mnożniki Koloru ×1.
- Wynik calculateMarketValues odpowiada parze wyników calculateMarketPrice i calculateMarketAvailability.
- Nieznane reguły i nieprawidłowe zakresy są odrzucane zamiast po cichu zmieniać wartości.

## Etap 2 — obowiązująca regresja

- Zachowane pięć slotów, nazwy/notatki, migracja 001 i ich trwałość po migracji 002.
- BG: dodawanie/edycja/usuwanie za potwierdzeniem, TT, aktualne/maks. PW, niezależna inicjatywa i ręczne statusy.
- Remisy można przestawić ręcznie; aktywne UUID nie zmienia się od sortowania. Null nie jest 0.
- Pierwsza tura zachowuje rundę; przejście przez koniec zwiększa ją. 0 PW pozostaje w kolejce.
- Brak aktorów lub inicjatyw blokuje przejście. Spacja w polach, przyciskach i z modyfikatorami nie przewija kolejki.
- Puste/nieprawidłowe wartości pozostają w szkicu; zamknięcie pokazuje błędny slot i umożliwia poprawę.
- Błąd zapisu wycofuje aktorów i turę; ponowienie zachowuje najnowsze dane. Konflikt wersji nie nadpisuje innego okna.
- Ręczne statusy zachowują polskie znaki i wiele wierszy; nie mają jeszcze czasu ani automatycznych efektów.
- Po restarcie wracają aktorzy, PW, TT, statusy, kolejność remisu, runda i aktywny aktor osobno w każdym slocie.
- Pełne pnpm check, testy transakcji Rust, build macOS i natywna weryfikacja, gdy komputer jest dostępny.

## Etap 3 — przeciwnicy, przygotowanie, reset

- Migracja 003 zachowuje wszystkie wcześniejsze kolumny pięciu slotów i aktorów,
  oryginalne snapshoty, nazwy/notatki, rundy, tury i revisions.
- 3 kopie szablonu mają 3 UUID i niezależne PW, inicjatywy, statusy i ruch.
- Zmiana runtime kopii nie zmienia szablonu, baseline ani pozostałych instancji.
- Ułamkowy ruch z przecinkiem, brak ruchu i jawne 0 działają; ujemne, nieskończone,
  powtórzone i niepełne wpisy są odrzucane i pozostają w edytowalnym szkicu.
- Jawne prepare jest potwierdzane; reset wraca do jego danych również po restarcie DB.
- Reset obecnego składu nie przywraca usuniętych członków, nie dotyka innych slotów,
  nazwy/notatek, oryginalnego snapshotu ani szablonu. Runda 1, brak aktywnej tury.
- Awaria zapisu wycofuje nowe szablony, actor runtime, baseline, rundę i revision.
- Kolizje ID/szablonu i obce snapshoty są odrzucane bez nadpisania danych.
- Niedokończony formularz przeciwnika blokuje zamknięcie, ujawnia swój slot i daje
  możliwość dokończenia lub jawnego anulowania. Błędny ruch również blokuje zamknięcie.
- Pełne pnpm check, transakcje Rust, build macOS i natywne smoke testy w osobnej bazie.

## Etap 4 — log walki

- Migracja 004 nie zmienia danych 001–003 i rozpoczyna pustą historię.
- Każdy slot ma niezależne wpisy, trwałe po restarcie pliku i aplikacji.
- Wpisy mają rzeczywiste before/after dla PW/max PW, TT, statusów, ruchu i inicjatywy;
  rundy/tury są rejestrowane również przy jednym aktorze i kolejnym obiegu.
- Szybkie −10/+10 PW i kilka tur zachowują kolejne zdarzenia; nie tylko końcowy bilans.
- Niepoprawny szkic i bezskuteczna zmiana (np. leczenie przy pełnych PW) nie tworzą wpisu.
- Błąd dopisania logu wycofuje zapis walki i revision. Retry i konflikt nie duplikują wpisów.
- Usunięcie/zmiana nazwy aktora nie zmienia wcześniejszych opisów historii.
- Prepare/reset mają markery; reset zachowuje historię i dopisuje przywrócone różnice.
- Czyszczenie wymaga potwierdzenia, obejmuje też niewczytane starsze strony, zachowuje
  pozostałe sloty, statystyki, snapshoty, nazwę/notatki i turę. Błąd zachowuje całość.
- Paginacja po ID działa także przy jednakowych timestampach; spóźniony odczyt nie
  przywraca wyczyszczonego logu. Błąd odczytu pokazuje komunikat i pozwala ponowić.
- Pełne pnpm check, testy Rust, build macOS i natywna weryfikacja w osobnej bazie.

## Etap 5 — statusy

- Migracja 005 zachowuje stare runtime, baseline, snapshoty, log i pięć slotów.
- 15 kluczy katalogu, własny status z polską/multiliniową treścią, źródło, edycja,
  potwierdzone usunięcie; brak pustych nazw i błędnych zakresów czasu/poziomów.
- Manual, rounds, start, end i next_end na granicach tur, przy pojedynczym aktorze,
  pierwszym starcie, braku inicjatywy i zmianie rundy. Neutralna ręczna korekta.
- Różne źródła tego samego stanu nie potęgują reguł; Podpalenie przypomina raz,
  bez zmiany PW. Wygasły przed startem ogień nie przypomina.
- Wyczerpanie: kumulacja 0–6, jawna redukcja, kara 2/poziom i 1,5 m/poziom,
  death warning bez usuwania postaci; niedozwolone poziomy i duplikaty odrzucone.
- Trwałość stanu i liczników po restarcie, prepare/reset, niezależność slotów.
- Atomowość przy błędzie statusu lub logu: brak częściowej zmiany PW/tury/revision.
  Próba przeniesienia ID statusu między aktorami jest odrzucona.
- Zamknięcie z niepełnym formularzem wskazuje slot, pozwala poprawić/anulować;
  po zapisaniu Cmd+Q i przycisk zamknięcia działają normalnie.
- pnpm check, cargo test/format, build macOS oraz osobny natywny test bez bazy MG.

## Etap 6 — Zranienia i Tchórzliwość

- Nowy przeciwnik z torem/progiem, stare BG i przeciwnicy bez nowych pól.
- Kary poziomów 1–4 narastają, Krytyczny daje dokładnie +1 wspólnego Wyczerpania
  (limit 6), dalsze Zranienie tylko death warning. Brak mutacji PW/TT/ruchu/kolejki.
- Powtórny zapis, 4→5→4, tura i restart nie dodają Wyczerpania. 4→3 zachowuje je;
  nowe 3→4 dodaje jeden. Wyłączenie toru zeruje Zranienia, pozostawia Wyczerpanie.
- InitialLevel=4 tworzy osobny status każdej kopii; prepare/reset odtwarza oba
  liczniki i próg. Runtime nie modyfikuje template ani innych aktorów/slotów.
- Próg 50% z 88 PW: 45 bez warning, 44 z warning. Uwzględnij zmianę maks. PW,
  puste/0/100%, nieparzyste maksimum i bardzo duże liczby bez błędów zaokrąglenia.
- Błędny procent nie zapisuje się i pozostaje w szkicu po odmowie zamknięcia.
- Atomowość Zranienia, Wyczerpania i logu przy awarii; retry bez duplikowania.
  Warning w logu tylko przy wejściu pod próg; powrót nad próg umożliwia nowy wpis.
- SQLite reopen zachowuje runtime/snapshot. Brak nowej migracji i niezmienione 001–005.
- Pełne check, Rust tests/format, macOS build oraz natywny test w osobnej bazie.

## Etap 7 — zasoby i akcje

- Nowy szablon z zasobami i zdolnościami, niezależne kopie z pełnymi licznikami;
  edycja runtime nie zmienia szablonu, innych aktorów ani przygotowanego stanu.
- 3/rundę odnawia się dopiero na wrap; 2/potyczkę nie. First start/zmiana karty/
  korekta current/restart nie odświeżają zasobów rundowych.
- A/B/R odnowione tylko przy zwykłym własnym starcie, również pojedynczy aktor;
  zasoby round odnawiają się także postaciom bez inicjatywy. Brak queue = brak hooka.
- Day/encounter jawnie odnowione tylko w wybranym slocie; manual zachowany.
- Akcja kosztująca zasób zmienia obie pule atomowo. Brak zasobu blokuje nawet wyjątek;
  Zranienia/Obezwładnienie blokują zwykłe użycie, jawny wyjątek ma osobny wpis.
- Koszt Legendarnych sprawdzany względem aktualnej puli; nigdy poniżej 0.
- Reset odtwarza częściowo zużyte liczniki, nie generuje fikcyjnego użycia akcji.
- Błędne nazwy/liczniki/koszty/odwołania pozostają szkicem. Cmd+Q ujawnia slot,
  pozwala poprawić/anulować; po zapisie aplikacja normalnie się zamyka.
- Błąd logu wycofuje zasób, pulę i revision; retry zachowuje kolejność i brak duplikacji.
  Odczyt po SQLite reopen i restarcie aplikacji zachowuje liczniki oraz prepared.
- Pełny check, Rust test/format, build macOS i natywny smoke w osobnej bazie.

## Etap 8 — Bestiariusz

- Nowy szablon bez tworzenia aktora; podgląd, edycja pełnego dotychczasowego setup,
  duplikat z nowym UUID, potwierdzone usunięcie z katalogu.
- Wyszukiwanie nazwy i opisów zdolności, polskie znaki i ich brak, łączne filtry
  kategorii/rozmiaru, pusty katalog i brak wyników; czytelny opis wielowierszowy.
- Dodaj ×3 do wskazanego slotu: osobne UUID/init/tie order/PW/resources/prepared;
  jeden zapis i atomowy log. Niepełny szkic slotu blokuje dodanie całej grupy.
- Edycja/usunięcie katalogu nie zmienia runtime, snapshotów ani logów aktorów;
  zapis, reset i kopie ze starej karty nadal działają, bez wskrzeszenia katalogu.
- Migrowana baza 001–005 zachowuje bajtowo runtime i snapshoty, log i pięć slotów.
  Odczyt po ponownym otwarciu i restarcie aplikacji zachowuje katalog i instancje.
- Złe pola pozostają szkicem. Konflikt/awaria nie nadpisuje katalogu, ponowienie
  identycznej mutacji jest bez duplikacji. Zamknięcie czeka na zapis i ujawnia form.
- Pełne check, testy Rust/format, build macOS i osobny natywny smoke bez bazy MG.

## Etap 9 — profile Item

- PB 4 + ZRC 5 = +9; SIŁ/ujemne modyfikatory/Finezyjna poprawne; brak PB/cechy nie
  jest zerem. Brak weaponProfile nie tworzy fikcyjnego profilu ataku.
- Ikona kości obok pełnej formuły i typu obrażeń. Brak rzutu, liczenia nabojów,
  modyfikacji HP, zużycia akcji i automatycznej interpretacji efektu.
- N/D trybu/amunicji zachowuje bazę. Premie sumowane, jawna formuła/zasięg amunicji
  ma pierwszeństwo nad trybem. Zmiana wariantu zapisywana i logowana.
- Walidacja zakresów, linków wariantów i ID; błędne dane pozostają w formularzu.
  Edycja profilu nie gubi zakresów cen/dostępności i metadanych Item.
- Podmiana runtime nie zmienia szablonu ani rodzeństwa. Prepare i reset obejmują
  pełne Item oraz wybory. Ponowny odczyt po restarcie zachowuje zestawy i log.
- Nieudany log wycofuje zapis broni/revision; powtórzenie nie duplikuje zmiany.
  Stare JSON i migracje 001–006 pozostają poprawne, pięć slotów nienaruszone.
- Normalne zamknięcie i ⌘Q chronią formularz broni i Bestiariusza.
- Pełny pnpm check, Rust test/format, macOS build i natywny test w osobnej bazie.

## Etap 10 — awarie maszyn

- Puste/0 próg, błędne liczby, wynik 0/21 i brak wymaganych wyborów dla 1/4.
- Podgląd i wpis obrażeń nie odejmują PW. Zastosuj 6: 88 → 38, minimum 0.
- 13: TT efektywne 16 → 14; 2: 9 m → 4,5 m, wszystkie rodzaje ruchu.
- 3/14: kary ataku sumują się; naprawa usuwa tylko jedną karę. Baza pozostaje.
- 1: konkretny Item, podmiana na nowy UUID nie przejmuje uszkodzenia.
- 4/9/10/19: blokady i jawny wyjątek MG. 10 nie blokuje Reakcji.
- 5/10/12: koniec następnej własnej tury, pominięcie obecnej; prepare/restart neutralne.
- 7/15/17/18: przypomnienia bez automatycznych ataków/celów. 20: zero PW bez usunięcia.
- Niezależne szablon/instancje/prepared, naprawa bez leczenia PW, reset odtwarza listę.
- Walidacja wszystkich 20 wyników TS/Rust. Błąd logu wycofuje awarię i HP razem.
- Szkic przy zamknięciu/⌘Q, retry pojedynczej aplikacji, restart i pięć slotów.
- Brak nowej migracji, dice rollera, licznika amunicji, obrażeń innych aktorów.


## Etap 11 — implementacja 0.12.0

- SD16: SP16/24/32/48 daje 100/150/200/300%; SP64 daje400% z markerem na końcu.
- Granice 125/126,175/176,250/251 oraz ułamki klasyfikowane bez zaokrąglania.
- Pusty skład SP0; brak pola SP/null nie jest zerem; SD0 bez ratio/NaN/Infinity.
- Polskie liczby dziesiętne SP; błędne/ujemne/nieskończone/niebezpieczne odrzucone.
- Niezależne poziomy pięciu slotów, autozapis po restarcie, retry i nowszy szkic
  podczas zapisu; niepoprawny poziom/SP chroniony przy zamknięciu i ⌘Q.
- Szablon/instancja/prepared/sąsiednia kopia niezależne. Przy 0PW nadal licz SP.
- Błąd zapisu logu wycofuje SP i rewizję. Retry dodaje pojedynczy wpis.
- Reset przywraca przygotowane SP, zachowując poziomy i pięć slotów.


## Poprawki Etapu 11 — 0.12.1

- Prezentacja wyników trudności: maksymalnie 2 miejsca po przecinku, bez zmiany
  surowych danych ani progów. Zapisane liczby zachowują pełną precyzję.
- Panel „Karta potyczki — trudność” zwijany; wybór rozwinięcia osobny dla slotów
  podczas sesji, błędne dane odsłaniają panel. Walka pozostaje dostępna.
- Mały pasek i procent/nazwa przy każdym z pięciu slotów, także nieaktywnych.
  Puste SD/brak SP to N/D, niepoprawny szkic „Popraw dane”.
- Aktualne SP korzysta z obramowania i odstępu etykiety jak pozostałe statystyki.
- Bestiariusz i formularz nowego przeciwnika pokazują konkretne pola, numery
  przedmiotów/formuł/akcji oraz przyczynę. Pierwszy błąd odsłania pole i ustawia
  kursor; kliknięcie błędu prowadzi do danej pozycji, także w zwiniętej sekcji.
- Walidacja zachowuje reguły: puste wymagane teksty, liczby, zakresy, koszty
  większe niż pule/zasoby i zasięgi. Błędy nie usuwają szkicu ani nie zapisują
  niepoprawnych danych. Brak migracji i zmian bazy, pięć slotów bez zmian.

## Etap 12 — Reset / Clear

- Potwierdzenie pokazuje slot/nazwę/liczbę i zakres. Anuluj jest neutralne;
  zmiana danych/revision blokuje stare potwierdzenie. Brak akcji przy formularzach.
- Clear z pustym/pełnym składem usuwa również log i notatki; zachowuje nazwę,
  poziomy, inne sloty i Bestiariusz. Pięć trwałych wierszy nadal istnieje.
- Oczekujący zapis notatek i walki kończy się przed Clear. Żaden późniejszy timer
  nie wskrzesza postaci/notatek. Błędny szkic blokuje operację i nie znika.
- Błąd w połowie transakcji cofa wszystkie usunięcia, metadane i revision.
  Retry nie duplikuje, konflikt nowszych danych nie wykonuje Clear. W trakcie
  niepewnego wyniku edycja i close zablokowane; odczyt rozstrzyga wynik z bazy.
- Zwykły zapis nie podmienia prepared. Reset obejmuje cały obecny skład i pełne
  liczniki/statusy/SP/broń/awarie, runda1, brak tury; log pozostaje z markerem.
- Osobna baza natywna, normalne zamknięcie/⌘Q i restart; brak testów na bazie MG.


## Etap 13 — UX

- Alt+strzałki wybierają kartę według kolejki, także bez inicjatywy; tura, runda,
  PW i statusy pozostają. Skraje nie zawijają; pola tekstowe zachowują skróty OS.
- Powrót do właściciela tury nie zmienia aktualnej tury. Wyraźny fokus karty.
- F1/przycisk, Tab/Shift+Tab i Escape w pomocy; brak zmiany slotu/tury pod modalem.
- Spacja nie przewija tury w polu, przycisku, summary ani otwartym formularzu.
- Log zwija się bez utraty historii/paginacji; nowe wpisy w podsumowaniu.
- Małe i standardowe okno: brak zasłonięcia pól, scroll i kontrolki dostępne.
- Polska nazwa i wielowierszowy tekst, przełączanie slotów, restart, zwykłe
  zamknięcie i Cmd+Q. Brak zmiany bazy użytkownika i migracji.

## Etap 14 — końcowa kontrola

- Pełne pnpm check, Rust release tests i cargo fmt, produkcyjny build macOS.
- Osobna baza native smoke: polskie/wielowierszowe dane, niezależne sloty,
  PW, status i czas, akcje, trudność, katalog i Dodaj ×3.
- Restart zachowuje stan i nie odlicza czasu; kontrola integralności kopii
  zamkniętej bazy. Nie używaj bazy użytkownika.
- Oba sposoby zamknięcia, ochrona niepełnego formularza, fokus błędu, pomoc,
  skróty i małe okno. Operacje reset/clear sprawdzane w automatyce; natywnie
  treść potwierdzeń i Anuluj, bez niszczenia danych MG.
- Raportuj osobno potwierdzone testy, próby niejednoznaczne i braki produktu.
- Przed pełnym v1.0 uzupełnij i zweryfikuj pełne pola statblocka z PRODUCT_SPEC.
  Zielone testy istniejących mechanik nie pokrywają niezaimplementowanych pól.

## Kryteria przyszłego planu 15–25

- Ekran główny: oba wejścia i powrót, BG jako jawna zapowiedź; niewidoczny formularz
  nadal chroniony przed zamknięciem. Nawigacja nie zmienia tury, danych ani statusów.
- Pełny statblock: czytelne pola, zgodność wejścia/odczytu, legacy null, zachowanie
  snapshotów i katalogu. Rozróżnienie Progu Obrażeń i Progu Awarii.
- Każda partia Bestiariusza: komplet wpisów i weryfikacja względem stron źródłowych;
  ponowienie seeda bez duplikatów, brak nadpisania edycji/usunięć MG i instancji.
- Ekwipunek: zakresy/null, dokładne none/none/none, każdy Kolor i zakres Stali,
  kolejność modyfikatorów oraz brak zmiany bazowego Item. Seed Excel tylko raz.
- Wiedza MG: zgodność liczby tabel/wierszy, nagłówków, wartości, jednostek i przypisów
  z inwentaryzacją Excela. Wyszukiwanie polskie, brak zależności runtime od arkusza.
- Roller: granice kości/ilości/formuły, wadliwa składnia, kontrolowane losowanie
  w testach, składowe/suma/historia. Rzut/retry/odczyt historii nie zmienia PW,
  nabojów, zasobów, tury ani statusów. Brak 3D i automatycznego rozliczania ataków.
- Port Windows po odbiorze macOS: realna instalacja, aktualizacja, stare dane,
  restart, Unicode, Ctrl-skróty, skalowanie i zamykanie. Brak regresji macOS.
- Karta BG po Windows: macierz wszystkich reguł, jawne korekty, obliczenia cech,
  wagi i udźwigu, nieznana masa, zgodność zachowania obu platform.
- Amunicja tylko BG: zużycie, przeładowanie ograniczone zapasem, brak wartości
  ujemnych/kreowania nabojów, retry bez drugiego zużycia, alarm przy 0 także po
  restarcie. Masa magazynka/zapasu nie liczona podwójnie. Roller nie zużywa nabojów.
- Krótki/długi odpoczynek: indywidualne reguły klas/zasobów i warunki, brak
  bezwarunkowego odnowienia zasobów ręcznych; powtórzenia i restart bez nadużyć.
- Reset/clear potyczki nie usuwa trwałej karty, rozwoju ani inwentarza. Jawne
  powiązanie dawnych BG i kontrola konfliktów. Wciąż dokładnie pięć slotów.

Każdy punkt należy do własnego etapu, nie deklaruje wykonania w 0.15.0.
Szczegółowe briefy: PLAN_DALSZYCH_PRAC.md. Raporty ETAP_0–14 zachowują historię.

## Etap 15 — odbiór

Sprawdź start na ekranie głównym, wejście i powrót MG/BG; zachowanie szkicu, slotu i tury. Spacja/Alt/⌘1–5 poza GM nie zmieniają walki. Niepełny formularz schowany przez ekran główny blokuje zwykłe zamknięcie i ⌘Q oraz ujawnia problem. Po poprawieniu zapis i restart zachowują dane, start ponownie na ekranie głównym.

## Etap 16 — odbiór

Sprawdź wszystkie sześć cech i RO, warunkowe opisy, N/D/zero/Brak, osobne progi. Błędna cecha wskazuje dokładnie jej pole i ujawnia zamkniętą sekcję. Szkic runtime i katalogu przetrwa powrót do home, blokuje zamknięcie i konfliktujące akcje. Zapis/ponowny odczyt, edycja katalogu bez wpływu na runtime, reset do prepared, awaria logu i ponowienie bez podwójnego wpisu. W Bestiariuszu wybierz inny slot, dodaj ×N i sprawdź instancje wyłącznie tam. Testy starego JSON oraz fixture nowych danych TS/Rust; restart, zwykłe zamknięcie i ⌘Q na osobnej bazie.

## Etap 17 — odbiór

- Czysta baza: 11 wpisów, ponowne otwarcie nie dubluje katalogu.
- Mobsprzęt: sześć ponumerowanych broni i 1k6, tabela podwozi; Spawacz: lot tylko SMART.
- Pasywy, polskie wielowierszowe opisy, precyzyjne błędy, formularze i ochrona zamykania.
- Wybór slotu i Add ×N zachowują niezależne kopie, zasoby i przygotowane stany.
- Jednorazowy transakcyjny seed/upgrade nie zmienia starych aktorów, logów ani slotów.
- Korekty chronią edycje/usunięcia/kolizje/brak wiersza; retry, rollback, brak downgrade.
- Broń oparta na RO ma opis bez premii do ataku; awaria może wskazać jej Item.
- Full pnpm check, cargo test release lib/fmt, macOS build i natywna osobna baza QA.

## Etap 18

- Inwentaryzacja 12 kompletnych potworów + nakładka Zombie, s.232–242.
- Wszystkie testy TS/Rust; źródłowe wartości, końcowe ataki i formularze roundtrip.
- Rozdzielne limity zionięcia/odporności/jaj, brak zmiany PW, kopie i reset.
- Pięć kategorii, starsze wpisy bez przymusowej konwersji; migration008 bez utraty danych.
- Druga partia: retry, rollback, brak zmian maszyn/edycji/usunięć/aktorów/logów.
- Zombie: nosiciel, N/D, nowa tożsamość, ręczny przegląd i brak nadpisania nosiciela.
- Natywny start/upgrade na osobnej bazie, filtrowanie, Add×N, zapis/restart, close/⌘Q.

## Etap 18A — mutanci

- 7 mutantów zgodnych ze stronami 226–231; pełne cechy, RO, ataki i pasywy.
- Filtr Mutanci, edycja/duplikacja i Add ×N, niezależny runtime i snapshoty.
- Łańcuch bez fikcyjnych obrażeń, psychiczne RO bez fikcyjnej premii ataku.
- Posiłki Mesmeryty 2/dzień; reakcja i trzy Legendarne zużywają oddzielne pule.
- Restart nie duplikuje wpisów, nie nadpisuje zmian i nie przywraca usunięć.
- Błąd trzeciej partii cofa tylko jej wpisy; retry zachowuje wcześniejsze partie.
- Pięć slotów, istniejące dane/logi, integralność SQL, pełne testy i macOS smoke.

## Etap 18B — zwierzęta (0.21.0)

- Na pustej bazie 12 zwierząt, 42 szablony łącznie + nakładka Zombie.
- Pełne statblocki i ataki zgodne ze źródłem, zapis/edycja/snapshot bez utraty pól.
- Powtórny startup bez duplikatów; błąd partii cofa tylko zwierzęta; retry działa.
- Edycje MG, usunięcia, kolizje UUID i starsze partie chronione, pięć slotów zachowane.
- Reakcja roju działa wielokrotnie, każda trafia do logu, PW i inne kopie bez zmian.
- Zwykła reakcja wyczerpuje się; przełączanie limitu nie odnawia jej budżetu.
- Blokady Zranień/stanów i brak zasobu blokują również reakcję bez limitu.
- Edytor, zapis, restart, prepared/reset zachowują flagę; legacy bez nowego pola.
- Pełne TS/Rust, macOS build i natywny smoke na osobnej bazie. Dowody ETAP_18B.md.

## Poprawki czytelności — 0.21.1

Zlecono wyłącznie korekty tekstów i widoków, bez Etapu 19. „Chód” w interfejsie
zastępuje „Szybkość”; prezentacja ruchu zawiera m. SP podręcznikowej kopii z
podaną wartością jest nieedytowalne w karcie walki; ręczne tworzenie i własne
wpisy zachowują pole. Wartości, liczenie trudności i dane pozostają niezmienione.
Usunięto wskazane dopiski administracyjne i dekoracyjny licznik slotów,
skrócono nagłówki. Pancerz: TT z wartością i opisem w nawiasie.
Wspólna prezentacja działa także na starych snapshotach; seed i SQL nietknięte.
Raport/kryteria odbioru: CZYTELNOSC_0.21.1.md. Następny etap wymaga zlecenia.

## Etap 19 — ludzie (0.22.0)

Zlecony po poprawkach 0.21.1. Dziewięć statblocków z s. 207–213 (PDF 209–215):
Cyngiel, Cywil, Gangus żołnierz, Gangus kapo, Gangus boss, Konwojent (strażnik),
Kanibal, Szeryf i Żołnierz Posterunku. Katalog startowy: 51 szablonów + nakładka Zombie.
Wariant farmera pozostaje bronią Cywila. Ofiara jest Reakcją; dodatkowy nóż Cyngla
Akcją Bonusową. Trzy długie serie mają osobne limity 2/walkę i są opisane przez RO,
bez fikcyjnego Testu Ataku. Przedmioty noszone są opisem, bez liczenia amunicji.
Nie sumować ponownie premii Kuloodpornego i Brutalnego ciosu; wartości końcowe
pozostają źródłowe. Warunkowe premie, przywołania, rzuty i obrażenia nie są automatyczne.
Nowa partia noe-humans v1, bez zmiany kontraktów ani migracji 001–008. Starsze partie,
edycje/usunięcia MG, instancje i snapshoty zachowane. Obowiązują poprawki czytelności 0.21.1.
Historyczny raport: ETAP_19.md. Etap 20 wdrożono następnie w 0.23.0.

## Etap 20 — Ekwipunek (0.23.0)

Wdrożono katalog 299 pozycji z tabelarycznego Excela: wszystkie osiem typów Item,
wyszukiwanie nazw/opisów/właściwości, filtry typu i kategorii, waga oraz zakresy
ceny i dostępności. Panel MG → Ekwipunek. Jedenaście regionów, cztery lokalizacje
i pięć Kolorów; niezależne N/D, domyślnie none/none/none. Stal modyfikuje tylko
Item.type weapon/ammunition, także gdy brak weaponProfile.

Katalog w tym etapie służy do przeglądania i obliczeń handlu. Nie zmienia
przedmiotów osadzonych w Bestiariuszu, walce ani przygotowanych kopiach.
Warunki handlu i filtry zachowują się w sesji przy przełączaniu modułów;
nowe uruchomienie zaczyna od wartości bazowych. Brak edytora katalogu,
liczenia inwentarza/amunicji, rollera, importu/synchronizacji Excela i UI Wiedzy MG.
Wagi zakresowe/przybliżone pozostają tekstem, brak danych = N/D, nigdy zero.

Migracja 009 dodaje items i equipment_seed_batches; migracje 001–008 pozostają
niezmienione. Jednorazowy, transakcyjny seed po migracjach i przed udostępnieniem
repozytoriów. Ponowny start nie nadpisuje wpisów ani nie odtwarza usunięć.
Raport: ETAP_20.md. Następny etap: 21 — Wiedza MG; tylko po nowym zleceniu.

## Etap 21 — Wiedza MG (0.24.0)

Panel MG → Wiedza MG: 50 wpisów, działy, wyszukiwanie po treści, tabelach i
nagłówkach (także bez polskich znaków), pasujące wiersze z zachowaniem kontekstu.
47 tabel/opisów z 13 arkuszy oraz trzy tabele MODYFIKATORÓW wyprowadzane z
istniejących reguł Ekwipunku. Spis zakresów: WIEDZA_MG_ZRODLA.md.
Długie opisy mają rozwijane akapity; nagłówki, jednostki, uwagi oraz odsyłacze
do arkusza/komórek pozostają dostępne. Na węższym panelu wiersze przechodzą
w karty z etykietami kolumn. Link do Ekwipunku prowadzi do przeliczania cen.

KnowledgeEntry zawiera strukturalne blocks: table (columns/rows/cells) i text;
ReferenceEntry to alias tego modelu. Wpisy są zwalidowane przez Zod i dostarczane
z aplikacją jako niezmienny katalog tylko do odczytu, bez nowej tabeli SQL.
Stan wyszukiwania/działu/wyboru trwa w sesji; nie zmienia potyczek ani ich bazy.
Migracje 001–009, identyfikator aplikacji, Bestiariusz, Item i TradeContext bez zmian.
Kolory i mnożniki handlu mają jedno źródło prawdy współdzielone z Ekwipunkiem.

Nie dodano kalkulatora, rollera, automatycznych efektów, liczników amunicji,
edycji wiedzy ani importu/synchronizacji Excela. Opisy rzutów i „Rzuć dwa razy”
są treścią tabel źródłowych; niczego nie uruchamiają. Raport: ETAP_21.md.
Następny etap: 22 — prosty roller, wyłącznie po osobnym zleceniu.

## Etap 22 — roller i strony podręcznika (0.25.0)

Zlecony po Etapie 21 (`c41dece`). Rozwijany panel Kości w prawym dolnym rogu:
k4/k6/k8/k10/k12/k20/k100, 1–100 kości, modyfikator ±10000 i pełne formuły
NkS±N (także d). Pokazuje każdą kość, sumę i 100 ostatnich wyników po restarcie.
Kliknięcie ataku, obsługiwanej formuły obrażeń, cechy, RO lub umiejętności
z jawną premią rzuca z kontekstem postaci i zapisuje wynik w logu jej potyczki.
Atak korzysta z bieżącego profilu; cecha z jej modyfikatora, RO/skill z podanej
premii końcowej. Liczbowa kara Wyczerpania dotyczy testów, nie obrażeń/awarii.
Pozostałe warunki i ułatwienia/utrudnienia ocenia MG. Nieobsługiwane, złożone
lub opisowe formuły pozostają tekstem; brak częściowego zgadywania rzutu.
Rzuć awarię k20 wypełnia istniejący formularz. Ręczne wpisanie i zmiana wyniku
pozostają dostępne. Tylko osobne „Zastosuj awarię” zmienia stan maszyny.
Rzuty nie zmieniają PW, zasobów, amunicji, tur, statusów ani wyboru celów.
Ponowienie z historii jest nowym rzutem samej formuły bez starej postaci/rundy.

Migracja 010 dodaje wyłącznie tabelę dice_rolls. 001–009 pozostają nietknięte.
Historia i opcjonalny wpis dice_rolled powstają w jednej transakcji; stabilne
UUID umożliwia ponowienie zapisu bez losowania i duplikowania. Nie zmieniamy
rewizji ani snapshotów walki. Zamknięcie czeka na zapis; błąd ujawnia panel
z zachowanym wynikiem. Skróty walki są zablokowane przy otwartym panelu kości.

Wiedza MG pokazuje tytuł „Neuroshima: Ostatnia Era” i drukowane strony zamiast
arkusza/komórek. 50 przypisań udokumentowano w WIEDZA_MG_STRONY.md. Treść tabel
pozostaje adaptacją Excela; samo dodanie odsyłaczy nie koryguje różnic mechaniki.
Surowe źródła pozostają poza repo/bundle; brak synchronizacji/reimportu.
Raport: ETAP_22.md. Odbiór Etapu 23: ETAP_23.md.

### Odbiór rollera

- 3k8±N pokazuje trzy składowe i jednokrotny modyfikator; błędna formuła nie losuje.
- Atak i obrażenia mają osobne kliknięcia, nazwy postaci/broni i właściwy slot w logu.
- Cechy używają modyfikatora, RO/skill końcowej premii; N/D pozostaje nieaktywne.
- Rzut awarii 20 nie zmienia PW; ręczne nadpisanie działa, efekt dopiero po Apply.
- Błąd zapisu zachowuje wynik; retry nie losuje i nie powiela historii/logu.
- Historia wraca po restarcie; Space przy panelu nie przesuwa tury, Escape zwija.
- Aktualizacja bazy zachowuje pięć slotów, dane, seedy i stare logi; dodaje tylko 010.
- Wiedza MG: wszystkie wpisy wskazują podręcznik i strony, bez arkusza/komórek w UI.


## Poprawki kart walki — 0.25.1

Zlecone po Etapie 22 (2cd2926), dla wszystkich przeciwników, także istniejących
instancji i wpisów MG. Bieżące cechy/RO, obrona i zmysły są stale widoczne przed
„Parametry i notatki postaci”. Opisy zdolności, reguł i broni mają klikalne jawne
premie ataku i formuły kości, także mieszane np. 2k8+2k6+4. ST/RO celu pozostaje
opisem; nie przypisuj rzutu obronnego do atakującego. Rzut nie zużywa zdolności
ani nie zmienia PW/zasobów; log zachowuje nazwę zdolności i postaci. Tekstowa
premia ataku uwzględnia liczbowe kary awarii i Wyczerpania bez doliczania PB.
Własne opisy korzystają z tej samej obsługi jawnych zapisów. Nieznanych wartości
nie zgadujemy. W historii opcjonalne groups opisuje mieszane kości; stare wpisy
bez groups nadal działają. Bez migracji i bez zmian seedów/snapshotów.
Raport: POPRAWKI_0.25.1.md. Etap 23 został następnie zlecony; patrz ETAP_23.md.

## Macierz odbioru 23

- Migracja rzeczywistej kopii bazy z 001–006 do 001–010: porównać wszystkie stare kolumny
  slotów, aktorów, szablonów i logu; osobny bundle ID, nigdy baza MG.
- Sprawdzić komplet 51 szablonów, 299 przedmiotów i 50 wpisów Wiedzy MG. Restart nie
  nadpisuje własnego szablonu i nie dubluje seedu. Pola oryginalne/przygotowane bez zmian.
- F1 nie zasłania otwartego dialogu; Escape z wyszukiwarki oddaje fokus do jej przycisku.
  Enter ponownie otwiera wyszukiwarkę. Skróty slotów nie działają w modalach.
- Inicjatywa w istniejącym wpisie zasad zapisuje tylko wynik tej instancji; tura nie przeskakuje.
- Roller 3k8, rzut z ataku/obrażeń, historia i manualne pole awarii pozostają działające.
- N/D trzech wymiarów zwraca bazę, Stal zmienia tylko broń/amunicję. Źródła w szczegółach.
- Hełmy zawierają zniszczenie przy ochronie, Długa używa Szybkości celu równej 0.
- Niepełny formularz blokuje ⌘Q; poprawny zapis, zamknięcie okna i restart zachowują dane.
- Zwykłe i powiększone okno, powiększenie tekstu, powrót z modułów do ekranu głównego.
- Pełne pnpm check, Rust release lib, cargo fmt i build macOS. Rozdzielić dowody natywne
  i automatyczne w ETAP_23.md; nie deklarować nieprzeprowadzonych prób.

## Etap 24 — nowa macierz odbioru (plan testów)

[KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md): BG-01…BG-42;
[KARTA_BG_KATALOG_REGUL.md](KARTA_BG_KATALOG_REGUL.md): każda klasa/profesja,
pochodzenie, sztuczka i wyjątek z testem swojej definicji;
[KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md): P-01…P-14.
To testy do implementacji, nie wykonane w24A. Finalna korekta MG wymaga testów:
Cwaniak8 bez Samouka,9 z jednym grantem; Twardziel6 bez drugiej zdolności
profesji,7 z nią,11 z trzecią. Powtórny zapis/awans nie duplikuje grantów.
Odbiór24E wymaga zamknięcia braków macierzy, regresji starych BG/NPC,
pełnych testów i natywnego buildu macOS; Windows25.

Testy Kolorów: COL-01…COL-12 w [KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).
Pełny odbiór obejmuje każdy Kolor oraz bazowy none, historię zmiany,
brak wpływu kalkulatora handlu na rozwój i warunkowe odpoczynki.

Rozstrzygnięcia MG wymagają dodatkowo: Saper0/1 i oba odnowienia; wszystkie
pule krótkiego po długim; Pakowanie+Górnik×3; zacięcie zużywa akcję,0naboi;
zestaw startowy liczony raz; wymagane zaokrąglenia produkcji zawsze w dół.


## Odbiór24B

- Minimum0 na każdym późniejszym przyroście PW, bez kary Koloru na1poziomie.
- Każda z6klas do12,18profesji,12pochodzeń/36wyborów,53sztuczki i wymagania.
- Wieloklasowość nie powtarza startowych PW ani wszystkich biegłości.
- KON przelicza dawne poziomy; Kolor zachowuje kontekst poziomu i nie leczy.
- Wcześniejszy rozwój tylko jako korekta z powodem; zwykły awans bez tej blokady.
- Szkic/autozapis/restart, utracona odpowiedź i dokładne retry, konflikt/rebase,
  odrzucenie szkicu, archiwizacja i błąd pola odsyłający do sekcji.
- Rust: granice sheet/draft, konflikty, atomowość i historyczne retry X po Y.
- Osobna baza QA po migracji011: wszystkie wcześniejsze rekordy bez zmian.
- Próby natywne oraz szczegółowe wyniki zapisane w ETAP_24B.md.
