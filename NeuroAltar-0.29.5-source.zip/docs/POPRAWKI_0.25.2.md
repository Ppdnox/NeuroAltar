# Poprawki 0.25.2 — naturalne wyniki i jednorazowy krytyk

Punkt wyjścia: 0.25.1, commit `bc1486b`. Zakres zlecony przez użytkownika po Etapie 22; nie rozpoczyna Etapu 23.

## Zmiany

- Naturalne 20 na k20 ma kolor zielony, naturalna 1 czerwony, niezależnie od końcowej sumy. Przykłady: 20−19=1 pozostaje zielone, 1+19=20 czerwone. Wynik zawiera również etykietę słowną.
- Wyróżnienia obejmują panel kości, historię i log walki, także starsze wyniki. Przy wielu kościach oznaczane są poszczególne k20; wspólna suma pozostaje neutralna. Pozostałe rodzaje kości nie otrzymują tych oznaczeń.
- Naturalna 20 w pojedynczym k20 testu ataku przygotowuje krytyk dla następnego rzutu obrażeń tej samej postaci i broni lub zdolności. Podwajana jest liczba kości, także w mieszanych formułach, np. 2k6+3 → 4k6+3; stały modyfikator pozostaje bez zmian.
- Opis ataku i profil tej samej broni współdzielą powiązanie przez ID przedmiotu. Inna postać lub broń nie zużywa krytyka. Kolejny atak tej samej broni zastępuje poprzedni; pierwszy zapisany rzut obrażeń zużywa krytyk. Zwykłe testy cech/RO, awarie i ogólny roller nie przygotowują krytyka.
- Krytyk przetrwa ponowne uruchomienie, ponieważ stan wynika z historii SQLite. Historia i log opisują podwojone kości. Ponowienie nieudanego zapisu zachowuje identyczny wynik i UUID; nie losuje drugi raz.
- Backend sprawdza jednorazowe wykorzystanie w transakcji, odrzuca brakujące lub niezgodne powiązanie oraz próbę ponownego zużycia przez inny rzut. Liczbowe kary Wyczerpania i awarii pozostają uwzględniane w atakach.

## Dane i migracje

Brak migracji SQL. Migracje 001–010 bez zmian. Rozszerzono opcjonalnie JSON rzutu o purpose/sourceKey i critical (ID ataku, pierwotna formuła). Starsze rekordy pozostają zgodne; stare ataki bez oznaczenia purpose nie tworzą krytyka wstecznie.

Nie zmieniono danych użytkownika, identyfikatora aplikacji, pięciu slotów, snapshotów, seedów, PW, zasobów ani amunicji. Rzut nie rozstrzyga trafienia ani celu. Ogólny przycisk powtórzenia formuły w historii pozostaje rzutem bez kontekstu postaci.

## Weryfikacja

- Pełne `pnpm check`: 279 testów w 51 plikach — PASS, razem ze sprawdzeniem TypeScript, lint i formatowania.
- Rust: 61 testów release/lib — PASS; `cargo fmt --check` — PASS.
- Testy obejmują naturalne 20/1 mimo przeciwnych modyfikatorów, neutralne sumy i inne kości, mieszane obrażenia, niezmienione premie, ponowienie zapisu, jednokrotne zużycie oraz odrzucenie niewłaściwej broni/powiązania.
- Produkcyjny `pnpm build:macos` oraz oddzielny build aplikacji QA — PASS.
- Natywny test macOS 0.25.2 w osobnej aplikacji i bazie QA: atak Cyngla z opisu Szabli dał 20+9=29 (zielone). Zamknięcie przez ⌘Q potwierdzone zakończeniem procesu. Po ponownym uruchomieniu kliknięto obrażenia z profilu Szabli: 2k8+5, kości [7,2], suma 14, oznaczenie krytyka w panelu i logu. Następny rzut: 1k8+5, [5], suma 10, bez krytyka. Końcowy proces QA zamknięty.
- Historia QA zawiera również naturalną 1 przy sumie 10. Oznaczenia sprawdzono dodatkowo testami renderowania.
- Kopie bazy QA przed/po: 11 → 76 rzutów, 53 → 118 wpisów logu; poprzednie rekordy zachowane. Wszystkie pozostałe dane identyczne: 10 migracji, 5 slotów, 10 aktorów, 51 szablonów, 2 statusy, 51 wpisów rejestru Bestiariusza, 299 przedmiotów, 1 partia Ekwipunku. Zmieniły się tylko historia/log i ich liczniki. Integralność SQLite OK, brak naruszeń kluczy obcych.

## Dostarczenie

Wersja 0.25.2 zostaje umieszczona w dotychczasowym miejscu:
`src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Poprzedni build zachowany obok jako `NeuroAltar 0.25.1.app`. Pliki projektu aktualizowane bezpośrednio, bez paczki do ręcznego instalowania.

Build macOS arm64 jest podpisany ad-hoc, bez notaryzacji. Pozostaje ostrzeżenie Vite o głównym pakiecie JS przekraczającym 500 kB (616,89 kB, gzip 175,36 kB). Brak blokującego błędu testów/builda. Nieznane formuły nadal pozostają tekstem, a krytyk wymaga rzutu ataku i obrażeń z kontekstem tej samej postaci/broni; nie jest odgadywany z fizycznych kości.

## Pliki zmienione

- `AGENTS.md`
- `README.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/dice.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/domain/dice.ts`
- `src/domain/dicePresentation.ts`
- `src/features/combat/CombatLog.tsx`
- `src/features/dice/ActorRoll.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/features/dice/RollLogMessage.tsx`
- `src/features/dice/dice.css`
- `src/features/equipment/AttackProfiles.tsx`
- `src/services/actorDice.ts`
- `src/services/diceHistory.ts`
- `src/stores/diceStore.ts`
- `tests/dice.test.ts`
- `docs/POPRAWKI_0.25.2.md`
