# 24E — czytelność Karty BG i własna broń (2026-09-27)

To jest poprawka roboczego builda 24E, nie końcowy odbiór etapu. Zachowano obecną jasną kolorystykę aplikacji i zapisy postaci.

## Zakres

- Kartę BG podzielono na osobne widoki **Podsumowanie**, **Cechy i testy** oraz **Zdolności**. Podsumowanie zawiera wartości do szybkiego odczytu, a pasek PW, szybkości, masy i poziomu jest widoczny na każdej stronie karty. Testy cech, RO, umiejętności i narzędzi pozostają klikalne w swoim widoku.
- Dla broni dodawanej ręcznie można wskazać rodzaj modelu wykorzystywany przez zdolności: rewolwer, pistolet maszynowy albo topór. Nazwa własna egzemplarza może być dowolna. Wybranie Ulubionej broni z ekwipunku zapisuje identyfikator modelu, nie etykietę, więc zmiana nazwy egzemplarza nie zrywa powiązania. Starsze egzemplarze bez pola rodzaju pozostają poprawne.
- Lista efektów aktywnego BG pokazuje efekty w oddzielnych kartach i czytelniej podaje termin zakończenia. Neo ma jawny przycisk zakończenia premii TT po rozliczeniu jednego trafienia; aplikacja nadal nie orzeka sama, czy atak trafił.
- Decyzją MG dalsze rozszerzanie przerzutów i automatyczne łączenie kilku efektów przeciwnika nie są zadaniami 24E. [Dokładny zakres pozostałego przeglądu zdolności](24E_BRAKI_ZDOLNOSCI.md) odróżnia brak ustawienia w panelu od działającej premii pasywnej i od efektu zależnego od sytuacji.

## Pliki zmienione w tej poprawce

- UI: `src/features/character/CharacterWorkspace.tsx`, `character.css`, `InventoryPanel.tsx`, `ParticipationPanel.tsx`.
- Model i walidacja: `src/domain/character/inventoryModel.ts`, `weaponTraits.ts`, `src-tauri/src/character_inventory.rs`.
- Test: `tests/characterWeaponRules.test.ts`.
- Dokumentacja: `AGENTS.md`, `docs/ETAP_24E.md`, `docs/ROADMAP.md`, `docs/PLAN_DALSZYCH_PRAC.md`, `docs/24E_BRAKI_ZDOLNOSCI.md` i ten raport.

Nowej migracji SQL nie ma: rodzaj modelu jest opcjonalnym polem istniejącego JSON, a istniejących danych nie zmieniono. Dotychczasowa migracja 014 i inne robocze zmiany 24E pozostają w drzewie roboczym. Produkcyjnej aplikacji nie zastępowano.

## Weryfikacja

Zaliczone: kontrola typów i lint TypeScript, 11 testów reguł broni oraz 88/88 testów Rust. Pierwszy pełny przebieg Rust wykrył odrzucanie starszych profili broni bez nowego opcjonalnego pola `family`; po poprawce wszystkie testy przeszły. Końcowy build aplikacji macOS po tej poprawce zakończył się pomyślnie; `codesign --verify --deep --strict` potwierdził podpis lokalny. W natywnym roboczym buildzie sprawdzono otwarcie istniejącej Karty BG i przełączanie trzech nowych widoków; nie zmieniono danych postaci.

Pełna regresja i ręczny odbiór 24E pozostają do zakończenia etapu, zgodnie z decyzją MG. Build jest podpisany lokalnie, bez notaryzacji.
