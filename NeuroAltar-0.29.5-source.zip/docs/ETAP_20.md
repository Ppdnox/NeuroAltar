# Etap 20 — Ekwipunek, 0.23.0

Wdrożenie bezpośrednio w `/Users/dominik/Desktop/Combat Tracker`.
Punkt wyjścia: czysty Git, `edee0ee` (Etap 19, 0.22.0); dodatkowy checkpoint
nie był potrzebny. Zlecenie „Rozpocznij kolejny etap” dotyczy Etapu 20.

## Wynik

Panel MG ma moduł Ekwipunek: 299 przedmiotów z Excela, osiem typów,
wyszukiwarkę (także bez polskich znaków), filtry typu/kategorii, strony po
40 wyników i osobną kartę szczegółów. Karta pokazuje cenę oraz dostępność
bazową i po modyfikacjach, wagę, parametry, opis i źródłowy wiersz.
Szczegóły mają lokalne przewijanie, układ składa się do jednej kolumny na
węższych ekranach. Zachowano istniejące skalowanie tekstu.

Handel: jedenaście regionów, cztery lokalizacje, N/D/Rdza/Rtęć/Stal/Chrom.
Każdy wymiar ma niezależne N/D, domyślnie none/none/none. Przycisk przywraca
wartości bazowe. Cena = baza × region według kategorii ekonomicznej × Kolor.
Dostępność = (baza + lokalizacja w p.p.) × Kolor, ograniczona na końcu do 0–100%.
Każda granica zakresu jest liczona osobno, bez zaokrąglania w domenie;
prezentacja ma najwyżej dwa miejsca po przecinku. Null i zero pozostają odrębne.
Stal ×0,5/×2 dotyczy tylko typu weapon/ammunition, nie pancerza z kategorią BROŃ.
Nieznany region/lokalizacja/brak mnożnika zgłasza konkretny błąd, nie domyślne ×1.

Stan filtrów i handlu utrzymuje się podczas nawigacji w sesji. Po ponownym
uruchomieniu wracają wartości bazowe. Skróty walki nie działają w Ekwipunku;
ochrona zamykania nadal ujawnia niedokończone formularze wcześniejszych modułów.

## Dane i migracja

Źródło: `Neuroshima_Suplement_Tabelaryczny_ulepszony (1).xlsx`, arkusze KATALOG
(wiersze 5–303) oraz MODYFIKATORY. SHA256:
`829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22`.
Porównano 299/299 nazw, kategorii, opisów, cen, dostępności i odsyłaczy.
Szczegóły mapowania: `src/data/equipment/README.md`.

75 broni, 17 pancerzy, 26 amunicji, 34 narzędzia (w tym instrumenty),
29 elektroniki, 23 żywności, 4 paliwa, 91 innych. Dokładne wagi zapisano
liczbowo w kg; zakresy i wartości „ok.” pozostawiono opisowo, bez zgadywania.
Brak pewnej wagi = null. Broń zachowuje parametry źródłowe w opisie;
nie wymyślono brakujących pól opcjonalnego weaponProfile.

**Migracja 009_equipment.sql** tworzy `items` (id, item_json, revision, deleted)
i `equipment_seed_batches` (batch_id, source_sha256, entry_count).
Migracje 001–008 i wcześniejsze partie Bestiariusza pozostały niezmienione.
Seed oraz jego znacznik są jedną transakcją. Awaria wycofuje całą partię;
ponowienie nie duplikuje danych. Kolizje ID, przyszłe edycje, tombstones i
brakujące wiersze nie są nadpisywane ani przywracane. Brak runtime importu,
synchronizacji, obserwowania pliku lub przycisku ponownego importu.
Nie usuwano i nie odtwarzano bazy użytkownika.

## Weryfikacja

- Pełne `pnpm check`: typecheck, lint, format oraz **249 testów / 48 plików — PASS**.
- Rust: **57 testów — PASS**, w tym migracja, kompletność seeda, rollback,
  ponowienie, kolizje/edycje/usunięcia i niezależność potyczek.
- `cargo fmt --check` — PASS.
- `pnpm build:macos` — PASS, macOS arm64, podpis ad hoc.
- Osobny build natywny i osobna baza `readability-smoke`, bez używania bazy MG.
- Natywnie: 299 wyników, stronicowanie, filtr Paliwo (4 wpisy), wyszukiwanie
  „ćwiekowana”, karta Namiotu (20–60 gb i 5–50 kg), nawigacja z zachowaniem filtra,
  domyślne i pełne okno. Sprawdzono amunicję pod Stalą (2→1 gb, 50→100%).
- Kurtka ćwiekowana pod Stalą pozostaje 30 gb / 70%; Detroit daje 45 gb,
  Miasto 80%; Rdza z tym regionem/lokalizacją daje 90 gb / 40%.
  Przywrócenie N/D odtwarza 30 gb / 70%.
- Restart, ⌘Q i zwykłe zamknięcie — PASS. Po restarcie nadal 299 wpisów i N/D.
- Porównano wszystkie wcześniejsze tabele bazy QA przed/po migracji i seedzie:
  bez zmian (5 slotów, 9 aktorów, 51 szablonów, 43 logi, statusy i snapshoty).
  Po kolejnym restarcie także wszystkie nowe tabele identyczne. Integralność OK,
  brak naruszeń kluczy obcych. Kopie dowodowe pozostają poza repo w katalogu work.

## Granice i dalsze prace

Katalog tego etapu służy do przeglądania i handlu; nie zawiera CRUD ani dodawania
przedmiotów do inwentarza BG. Dotychczasowy edytor broni przeciwnika pozostaje
niezależny. Amunicja/liczenie wagi całego inwentarza należą do pełnej karty BG.
Nie dodano rollera, automatycznych zmian PW ani Wiedzy MG. Etap 21 wymaga
nowego zlecenia; źródłowy Excel jest dostępny do spisu tabel.

Wagi przybliżone/zakresowe i brakujące nie pozwalają dziś obliczać pewnej sumy
obciążenia. Przed etapem karty BG trzeba obsłużyć te przypadki jawnie.
Dostarczony build jest lokalny arm64, bez notaryzacji; nie stanowi odbioru
Windows ani Intel. Nie wykryto blokera dla rozpoczęcia osobno zleconego Etapu 21.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/009_equipment.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/equipment.rs`
- `src-tauri/src/item.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/equipment/README.md`
- `src/data/equipment/catalog.v1.json`
- `src/data/equipment/market-rules.v1.json`
- `src/db/connection.ts`
- `src/db/equipmentRepository.ts`
- `src/domain/equipment.ts`
- `src/domain/market.ts`
- `src/features/equipment/EquipmentWorkspace.tsx`
- `src/features/equipment/README.md`
- `src/features/equipment/equipment.css`
- `src/stores/bestiaryStore.ts`
- `src/stores/equipmentStore.ts`
- `tests/connection.test.ts`
- `tests/equipment.test.ts`
- `tests/market.test.ts`
- `tests/navigation.test.ts`
- `tests/prepareAppClose.test.ts`
- `docs/ETAP_20.md` (ten raport)
