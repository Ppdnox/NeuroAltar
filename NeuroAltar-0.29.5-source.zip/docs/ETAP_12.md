# Etap 12 — Reset / Clear hardening (0.13.0)

## Zakres

Etap zlecony po czystym commicie 5bde995. Nie rozpoczęto Etapu 13.

- Dodano „Wyczyść potyczkę”: jedna transakcja usuwa obecny skład wraz ze stanami
  przygotowanymi i bieżącymi, statusy, cały log i notatki. Runda 1, brak tury.
  Nazwa slotu, poziomy BG, katalog Bestiariusza i pozostałe sloty pozostają.
- Przygotowanie, Reset i Clear mają osobne potwierdzenia z numerem/nazwą slotu,
  liczbą postaci i skutkami. Zmiana szkicu lub rewizji blokuje stare potwierdzenie.
- Clear opróżnia kolejki walki i metadanych oraz wstrzymuje edycję/zamykanie.
  Niepewna odpowiedź zachowuje żądanie do dokładnego ponowienia; można także
  odczytać zapisany stan slotu. Nowsze dane powodują konflikt zamiast usunięcia.
- Compare-and-save metadanych blokuje spóźnione przywrócenie notatek z innego
  okna. Identyczny retry rozpoznaje zapisany już wynik.
- Rust sprawdza niezmienność istniejącego prepared przy zwykłym zapisie,
  kompletność przygotowania i resetu oraz zgodność runtime z punktem powrotu.
  Reset zachowuje obecny skład, nazwę, poziomy, notatki i log. Odtwarza wszystkie
  zapisane liczniki, SP, statusy, broń i awarie; nie uzupełnia ich do maksimum.
  Remisy normalizuje deterministycznie według przygotowanej kolejności i UUID.
- Uaktualniono dokumentację, instrukcje Codex/Work, wersję i oznaczenie etapu.

## Dane i migracje

Brak nowej migracji SQL. Migracje 001–006, pięć stałych wierszy encounter,
identyfikator aplikacji i adres bazy pozostają. Clear używa UPDATE wiersza slotu,
nie DELETE/REPLACE. Katalog szablonów nie jest usuwany. Nie odtwarzamy bazy MG
ani nie otwieramy jej na potrzeby testów. Oryginalny snapshot istniejących postaci
pozostaje niezmienny przy prepare/reset; pełne Clear usuwa go razem z postacią.

## Weryfikacja

- `pnpm check`: TypeScript, ESLint, Prettier i 174 testy w 32 plikach — OK.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`: 35/35 — OK.
- `cargo fmt --manifest-path src-tauri/Cargo.toml --check`: OK.
- `pnpm build:macos`: produkcyjny bundle arm64 0.13.0, podpis ad hoc — OK.
- `git diff --check`: OK; migracje 001–006 bez zmian.

Testy obejmują opróżnienie obu kolejek przed Clear, zachowanie szkiców i blokadę
edycji po niepewnej odpowiedzi, dokładne retry i rozstrzygnięcie przez odczyt,
blokadę operacji przy formularzach/błędnych danych oraz niezależność slotów.
Prawdziwe SQLite sprawdza rollback wszystkich kolumn po błędzie kasowania logu,
statusy usuwane przez FK, zachowanie drugiego slotu i katalogu, pięć ID, odrzucenie
starego autozapisu i niezgodnych metadanych. Testy odrzucają podmieniony prepared,
częściowy reset i reset zmieniający skład. Wcześniejsze scenariusze zasobów,
SP, broni, awarii i statusów używają teraz pełnego resetu wszystkich postaci.

## Test natywny

Osobna aplikacja i baza `pl.neuroshima.combat-tracker.stage12-smoke`.
Sprawdzono potwierdzenie Clear przy pustym slocie; dodanie BG unieważniło je
oraz zablokowało przycisk zatwierdzenia. Reset poprawnie wskazał slot „Most —
Etap 12”, zakres i zachowywane dane; Anuluj zachowało stan.

Sprawdzono polskie imię „Żaneta — test resetu”, wielowierszowe statusy i notatki,
przełączenie ⌘2, poziomy 6/7 w drugim slocie i zamknięcie ⌘Q. Proces zakończył
się, a restart odtworzył nazwę, postać, statusy, notatki, log i wynik drugiego
slotu. Przycisk zamknięcia okna również zakończył proces. Potwierdzenie obejrzano
na zrzucie w oknie 1100×760. Destrukcyjne wykonanie Clear/Reset sprawdzono
w testach automatycznych; natywny smoke obejmował ich potwierdzenia i anulowanie.
Baza użytkownika nie była używana.

## Dostarczenie i ograniczenia

Repozytorium docelowe: `/Users/dominik/Desktop/Combat Tracker`. Zmiany przygotowano,
przetestowano i zbudowano w osobnej kopii. Zastosowanie do repozytorium sprawdza
bazowy HEAD, czystość, sumę patcha i końcowe drzewo Git. Docelowy bundle:
`src-tauri/target/release/bundle/macos/NeuroAltar.app`, wersja 0.13.0.
Poprzedni bundle pozostaje jako `NeuroAltar 0.12.1.app`.

Clear jest nieodwracalne Resetem. Kopia aplikacji nie jest kopią bazy.
Przy konflikcie zapisu nie nadpisujemy danych innego okna; szkic należy zachować
przed ponownym otwarciem. Clear ma własny odczyt rozstrzygający niepewny wynik.
Wymuszone zakończenie procesu nadal może utracić niezapisane szkice.
Bundle jest podpisany lokalnie ad hoc, bez notaryzacji dystrybucyjnej.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/ETAP_12.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/src/combat.rs`
- `src-tauri/src/difficulty_tests.rs`
- `src-tauri/src/encounter_clear.rs`
- `src-tauri/src/item.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/src/machine_failure.rs`
- `src-tauri/src/prepared_state.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/db/encounterRepository.ts`
- `src/domain/combat.ts`
- `src/features/combat/PreparationControls.tsx`
- `src/services/clearEncounter.ts`
- `src/services/encounters.ts`
- `src/services/prepareAppClose.ts`
- `src/stores/combatStore.ts`
- `src/stores/encounterMaintenanceStore.ts`
- `src/stores/encounterStore.ts`
- `tests/encounterMaintenance.test.ts`
- `tests/encounterStore.test.ts`
