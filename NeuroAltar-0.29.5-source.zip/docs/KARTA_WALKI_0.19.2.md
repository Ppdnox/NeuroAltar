# Karta walki — NeuroAltar 0.19.2

12 września 2026. Punkt wyjścia: czyste repo `48a0047`, wersja 0.19.1.
Korekta przed kolejnym etapem, zgodnie z doprecyzowaniem MG: pole awarii działało,
ale formularz otwierał się wysoko nad kartą; nie była to usterka wpisywania k20.

## Zmienione zachowanie

- Każda pula Akcji / Bonusowej / Reakcji / Legendarnych ma bezpośrednio pod
  przyciskiem swoje zdolności. Zdolności zachowują istniejące przypisanie rodzaju,
  koszty, ograniczenia, ostrzeżenia i Wyjątek MG. Pełny opis rozwijany osobno.
- Wspólny zestaw broni jest dostępny w grupie Akcja, w „Profile broni i warianty”.
  Brak automatycznego przypisywania broni do rodzaju lub kosztu akcji na podstawie
  jej nazwy. Rodzaj/cenę użycia określa istniejący opis zdolności.
- Liczniki zasobów nad grupami akcji. Najważniejsze PW/TT/inicjatywa pozostają
  na początku karty. Ruch bazowy, statusy opisowe, aktywne statusy, zranienia,
  Tchórzliwość i awarie mają zwięzłe przypomnienia; szczegółowe panele zachowane.
- Edytory SP, ruchu i notatek opisowych są w „Parametry i notatki postaci”.
  Niepoprawne dane odsłaniają tę sekcję; szkice zachowują treść.
- Przy oknie co najmniej 950×650 px karta przeciwnika ma własne przewijanie.
  Lista inicjatywy i sterowanie turą pozostają obok. W mniejszym oknie stosowany
  jest pionowy układ i przewijanie całej strony. Przyciski Akcje/Awarie przenoszą
  do odpowiedniej sekcji karty.
- Formularz awarii pojawia się pod przyciskiem w panelu awarii. Fokus i przewinięcie
  kierują do pola wyniku. Formularz jest poza blokadą pozostałych pól instancji;
  próba zamknięcia z otwartym formularzem nadal ujawnia właściwy slot i wynik.
- Pole progu awarii ma wyraźną ramkę i etykietę, oddzieloną od wartości.

## Dane i zakres

Brak migracji, zmian reguł gry, danych seeda lub schematów domenowych.
Zachowane migracje 001–008, stałe sloty 1–5, logi, autosave, niezależne kopie
przeciwników i stan przygotowany. Baza użytkownika nie była używana w testach
ani podmieniana. Nie rozpoczęto Etapu 19 ani partii 18A/18B.
Kliknięcie opisu/profilu nie zużywa akcji. Zmianę awarii nadal wywołuje wyłącznie
jawne „Zastosuj awarię”; bez automatycznego rzutu k20.

## Wyniki weryfikacji

- `pnpm check` w rzeczywistym repo — PASS: TypeScript, ESLint, Prettier,
  **203 testy w 42 plikach**.
- Dwa nowe testy prezentacji: właściwa grupa dla Zionięcia/Połknięcia i pełne opisy;
  pojedynczy formularz awarii po przycisku, poza disabled fieldset, zachowany
  wynik 21 oraz polska notatka dwuwierszowa, blokada zamknięcia bez utraty szkicu.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib` —
  **45 testów PASS**. `cargo fmt --check` i `git diff --check` — PASS.
- `pnpm build:macos` — PASS; lokalna aplikacja arm64 z podpisem ad hoc.

Natywna aplikacja QA: `pl.neuroshima.combat-tracker.readability-smoke`, osobna baza
z testu 0.19.1. Sprawdzono okno 1100×760, 760×580 i maksymalizację:

- Przewijanie karty zostawia listę inicjatywy i położenie logu na miejscu.
- Zionięcie pod Akcją, Połknięcie pod Bonusową. Rozwijanie opisu Spacją nie przesuwa
  tury. Użycie Połknięcia zużywa Bonusową 1→0. Zachowane Zionięcie 1/2 i inicjatywa 13.
- Przycisk Awarie prowadzi do sekcji. Wpisz wynik otwiera formularz pod przyciskiem
  i ustawia fokus na k20. Wynik 21 odrzucony, tekst zachowany. Próba ⌘Q utrzymuje
  aplikację otwartą i fokus na wyniku. Poprawienie na 2 pozwala zatwierdzić awarię.
- Mobsprzęt: wynik 2 daje uszkodzony napęd; wynik 1 pozwala wskazać 1. Karabin.
  Lista wyboru zawiera wszystkie sześć broni. Obydwie awarie zachowane po restarcie,
  PW nadal 48/48, TT 12. Profil karabinu pokazuje ostrzeżenie o zniszczeniu.
- Zmniejszenie okna zachowuje rozpoczęty wynik 1 i dostęp do formularza.
  Finalny build QA potwierdza oddzielną etykietę i ramkę progu awarii.
- Zwykłe zamknięcie i ⌘Q po zatwierdzeniu kończą proces.
- Kopia zamkniętej bazy QA: `integrity_check=ok`, brak błędów kluczy obcych,
  pięć slotów, 23 wpisy katalogu i zachowane polskie notatki dwuwierszowe.

## Dostarczenie i ograniczenia

Gotowy build: `src-tauri/target/release/bundle/macos/NeuroAltar.app`, 0.19.2.
Poprzednia aplikacja zachowana obok jako `NeuroAltar 0.19.1.app`.
Identyfikator produkcyjny bez zmian: `pl.neuroshima.combat-tracker`.
Podpis sprawdzany przed i po podmianie; zmiany zapisane w Git po sprawdzeniach.

Pełne opisy wymagają rozwinięcia; stan rozwinięcia jest lokalnym stanem widoku.
Profile broni są wspólne — model nie zawiera jawnego powiązania Item↔zdolność,
więc nie zgadywano go ani nie zmieniano mechaniki użycia.
Na małym ekranie pozostaje przewijanie strony. Build lokalny arm64, bez
notaryzacji; nie przeprowadzano testów Intel/Windows.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `docs/UI_GUIDELINES.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/machine-failures/FailurePanel.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `tests/combatPresentation.test.ts`
- `docs/KARTA_WALKI_0.19.2.md`
