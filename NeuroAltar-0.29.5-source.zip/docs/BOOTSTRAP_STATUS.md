# Etap 0 — stan weryfikacji

6 września 2026. Zaimplementowano wyłącznie bootstrap z roadmapy.

- Tauri 2, React, TypeScript, Vite, Tailwind, Lucide, SQLite, Zod, Zustand, Vitest.
- Migracja `001_initial.sql`: pięć stałych slotów 1–5, wartości początkowe i ochrona integralności.
- Warstwy domeny, repozytorium i inicjalizacji; ekran odczytu stanu bazy.
- Git, lockfile pnpm/Cargo, lint, formatowanie i dokumentacja uruchomienia.
- `reference/` pozostaje poza Gitem i bundlem.

## Wyniki

| Kontrola                                                    | Wynik                                                                                      |
| ----------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| Vitest                                                      | 31 testów w 4 plikach — PASS                                                               |
| TypeScript, ESLint, Prettier                                | PASS                                                                                       |
| Formatowanie Rust                                           | PASS                                                                                       |
| Build frontendu                                             | PASS                                                                                       |
| Build macOS Apple Silicon, release                          | PASS                                                                                       |
| Podpis lokalny ad hoc, `codesign --verify --deep --strict`  | PASS                                                                                       |
| Test migracji i trwałości SQLite po ponownym otwarciu pliku | PASS                                                                                       |
| Pierwsze uruchomienie i restart natywnej aplikacji          | PASS — natywne okno pokazuje pięć slotów; baza identyczna po Cmd+Q i ponownym uruchomieniu |

Testy SQLite używają prawdziwego silnika `node:sqlite` i produkcyjnego pliku SQL. Testy jednostkowe adaptera Tauri używają mocka API. Dodatkowo sprawdzono gotową aplikację macOS: ekran z połączonym SQLite, pięć slotów, restart i odczyt prawdziwej bazy SQLx. Migracja 1 ma status sukcesu, a `PRAGMA integrity_check` zwraca `ok`.

## Build macOS

Uruchom `pnpm build:macos`. Skrypt drukuje katalog wyniku i domyślnie buduje poza synchronizowanym Biurkiem/Dokumentami, w systemowym katalogu tymczasowym. Eliminuje to błąd podpisu powodowany przez metadane FinderInfo dodawane do pakietu `.app`. Można ustawić własne `CARGO_TARGET_DIR` wskazujące lokalny katalog. Wynik trzeba zachować poza katalogiem tymczasowym.

Bundle ma podpis ad hoc. Nie ma certyfikatu dystrybucyjnego ani notaryzacji. Minimalny system to macOS 13.3; Intel i Windows nie były testowane.

## Ręczna kontrola uruchomienia

Otwórz gotową aplikację. Oczekiwany ekran: komunikat o połączonym SQLite i pięć kart „Potyczka 1”–„Potyczka 5”. Zamknij aplikację przez Cmd+Q i uruchom ponownie; nadal powinno być pięć kart, bez błędu migracji. W tym etapie karty służą wyłącznie do odczytu.

Etap 1 (edycja, przełączanie slotów, autozapis) nie został rozpoczęty i wymaga zgody użytkownika.
