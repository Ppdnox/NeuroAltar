# Spis źródeł Wiedzy MG — Etap 21

Uzupełnienie po Etapie 21: 29 tabel bezpośrednio z podręcznika dodano osobno,
bez zmiany opisanej niżej transkrypcji Excela. Aktualna Wiedza MG liczy
79 wpisów. Zestawienie nowych tabel i stron: [TABELE_PODRECZNIKA.md](TABELE_PODRECZNIKA.md).

Spis ustalony przed implementacją modułu. Źródło: Neuroshima_Suplement_Tabelaryczny_ulepszony (1).xlsx,
SHA256 `829ab98ddb856742c101ef3235a0c755bc8f70f868e18f2bb1790ce21e05ad22`.
16 arkuszy: PANEL MG i KATALOG już obsługuje Ekwipunek; 13 arkuszy zasad i tabel
sprzętu poniżej oraz MODYFIKATORY tworzą Wiedzę MG. Nie wprowadzamy kalkulatora,
rzutów ani żadnych automatycznych zmian stanu gry. Zachowujemy strukturę tabel,
opisy i jednostki, także wiersze „Rzuć dwa razy” jako treść źródłową.

47 wpisów źródłowych, 362 wiersze tabel, 1868 niepustych komórek objętych
mapowaniem (bez tytułów arkuszy i redakcyjnych opisów układu w wierszu 2).
Pełne opisy pozostają przy tabelach; sekcje pancerzy i broni są osobnymi wpisami.
Puste komórki pozostają brakiem danych; nie dopisujemy zakresów losowania,
średnich cen ani wag. Format procentowy Excela jest zachowany, cena w gb.
Brak komentarzy komórkowych i formuł w tych 14 arkuszach; nie kopiujemy ilustracji
kontrolnych ani technicznych notatek o przepisywaniu arkusza.

| Arkusz                  | Wpis                                                                            | Komórki źródłowe          |
| ----------------------- | ------------------------------------------------------------------------------- | ------------------------- |
| AKCJE I NARZĘDZIA       | Tabela typowych akcji                                                           | E4;E6:F28                 |
| AKCJE I NARZĘDZIA       | Tabela zestawów narzędzi                                                        | A4;A6:C28                 |
| STANY I PODRÓŻ          | Tabela stanów                                                                   | A4;A6:B20                 |
| STANY I PODRÓŻ          | Tempo podróży                                                                   | D4;D6:G10;D12;D14;D16;D18 |
| ZASADY SPRZĘTU          | Hełmy                                                                           | A4;A5                     |
| ZASADY SPRZĘTU          | Tarcze                                                                          | A7;A8                     |
| ZASADY SPRZĘTU          | Właściwości broni białej                                                        | A10;A11                   |
| ZASADY SPRZĘTU          | Właściwości broni dystansowej                                                   | A13;A14                   |
| ZASADY SPRZĘTU          | Serie i ogień zaporowy                                                          | A16;A17                   |
| ZASADY SPRZĘTU          | Tabela obrażeń długiej serii                                                    | A19;A20:B25               |
| ZASADY SPRZĘTU          | Ogień zaporowy                                                                  | D19;D20:E24               |
| PANCERZE                | LEKKIE PANCERZE (1 akcja na założenie/ściągnięcie)                              | A7;A6:G12                 |
| PANCERZE                | ŚREDNIE PANCERZE (2 akcje na założenie/ściągnięcie)                             | A13;A6:G17                |
| PANCERZE                | CIĘŻKIE PANCERZE (4 akcje na założenie/ściągnięcie)                             | A18;A6:G22                |
| PANCERZE                | AKCESORIA (1 akcja na założenie/ściągnięcie)                                    | A23;A6:G27                |
| BROŃ BIAŁA I MIOTANA    | Tabela broni białej                                                             | A4;A6:G26                 |
| BROŃ BIAŁA I MIOTANA    | Tabela broni miotanej                                                           | A30;A32:G42               |
| BROŃ PALNA              | Broń Palna Krótka (BPK) — Pistolety (waga ok. 1 kg)                             | C7;B6:H14                 |
| BROŃ PALNA              | Broń Palna Krótka (BPK) — Rewolwery (waga ok. 1 kg)                             | C15;B6:H19                |
| BROŃ PALNA              | Broń Palna Krótka (BPK) — Broń kombinowana (waga ok. 2 kg)                      | C20;B6:H22                |
| BROŃ PALNA              | Broń Palna Pośrednia (BPP) — Pistolety maszynowe (waga ok. 3 kg)                | C28;B27:H32               |
| BROŃ PALNA              | Broń Palna Pośrednia (BPP) — karabinki automatyczne (waga ok. 3 kg)             | C33;B27:H37               |
| BROŃ PALNA              | Broń Palna Długa (BPD) — Karabiny powtarzalne (waga ok. 4kg)                    | C43;B42:H47               |
| BROŃ PALNA              | Broń Palna Długa (BPD) — Karabiny automatyczne i samopowtarzalne (waga ok. 4kg) | C48;B42:H52               |
| BROŃ PALNA              | Broń Palna Długa (BPD) — Strzelby (waga ok. 4kg)                                | C53;B42:H57               |
| AMUNICJA                | Amunicja do broni krótkiej                                                      | A4;A5:E10                 |
| AMUNICJA                | Amunicja do broni długiej                                                       | A13;A14:E21               |
| AMUNICJA                | Amunicja do granatników i broni ppanc                                           | A24;A25:E28               |
| AMUNICJA                | Amunicja do broni miotanej                                                      | A31;A32:E37               |
| AMUNICJA                | Ceny magazynków wymiennych                                                      | A43;A45:C50;A41           |
| EKSPLOZYWY              | GRANATY I IM PODOBNE                                                            | A4;A5                     |
| EKSPLOZYWY              | MINY I ŁADUNKI WYBUCHOWE                                                        | A7;A8                     |
| EKSPLOZYWY              | OBSZAR EKSPLOZJI (NA PRZYKŁADZIE SZEŚCIANU)                                     | A10;A11                   |
| EKSPLOZYWY              | Tabela granatów, min i ładunków                                                 | A13;A15:E27               |
| ELEKTRONIKA I NARZĘDZIA | ELEKTRONIKA                                                                     | A4;A6:F33                 |
| ELEKTRONIKA I NARZĘDZIA | TABELA ZESTAWÓW NARZĘDZI                                                        | A39;A41:D63;A37           |
| PROCHY I LEKARSTWA      | Materiały pirotechniczne                                                        | A7;A9:D12                 |
| PROCHY I LEKARSTWA      | Narkotyki                                                                       | A15;A17:D21               |
| PROCHY I LEKARSTWA      | Używki                                                                          | A24;A26:D31               |
| PROCHY I LEKARSTWA      | Środki lecznicze                                                                | A34;A36:D50               |
| PROCHY I LEKARSTWA      | LEKARSTWA                                                                       | A53;A55:D63               |
| PROCHY I LEKARSTWA      | PROCHY I UŻYWKI                                                                 | A4;A5                     |
| RÓŻNOŚCI                | TABELA RÓŻNOŚCI                                                                 | A4;A6:E62                 |
| INSTRUMENTY             | INSTRUMENTY MUZYCZNE                                                            | A4;A5;A8                  |
| INSTRUMENTY             | PRZYKŁADOWE INSTRUMENTY                                                         | A10;A12:E24               |
| ŻYWNOŚĆ I ISTOTY        | ŻYWNOŚĆ                                                                         | A4;A6:D27                 |
| ŻYWNOŚĆ I ISTOTY        | ŻYWE ISTOTY                                                                     | A30;A32:D44               |

## Wspólne reguły handlu — 3 dodatkowe tabele

- Regiony: MODYFIKATORY A4:H17, mnożniki kategorii z istniejącego market-rules.v1.json.
- Lokalizacje: J4:L10, poprawki z tego samego pliku; przykłady handlarzy z L7:L10.
- Kolory: N4:Q11, wartości z TRADE_COLORS w domain/market.ts; Stal tylko broń/amunicja.
- Zasada łączenia modyfikatorów: J13, przy tabelach handlu. Każdy wymiar ma także N/D.

Nie powielamy liczb handlowych w drugiej bazie reguł. Katalogi bazowego sprzętu
są widokiem tabel źródłowych, natomiast bieżące przeliczenie zapewnia Ekwipunek.
W razie przyszłych zmian źródła trzeba aktualizować także zgodność tych widoków;
nie dodajemy funkcji importu ani synchronizacji.
