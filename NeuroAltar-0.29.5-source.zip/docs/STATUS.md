# NeuroAltar — bieżący status

Aktualizacja: **2026-11-10**. **24E Roboczy / 0.29.5**.
Ten plik jest punktem wejścia do aktualnego zakresu. Dawne raporty opisują
historyczne wydania; najnowsze decyzje użytkownika mają pierwszeństwo.
Commit przekazanej paczki wskazuje jej `MANIFEST.json`; w repozytorium sprawdza go
`git rev-parse HEAD`.

## Wdrożone

- Panel MG: pięć trwałych potyczek, inicjatywa, tury, statusy, zasoby, log,
  awarie maszyn, przygotowanie/reset oraz trudność spotkania.
- Bestiariusz z pełnymi statblockami i pięcioma kategoriami; partie podręcznika
  oraz zatwierdzony suplement Moloch City.
- Ekwipunek i handel, Pojazdy jako tabela bez statblocków, Wiedza MG i roller.
- Karty BG: sześć klas, osiemnaście profesji, rozwój na poziomach 1–12,
  wieloklasowość, obliczenia, inwentarz, amunicja, zdrowie, zasoby, odpoczynki,
  postój oraz powiązanie z potyczką. Szczegóły: [zakres zdolności](24E_BRAKI_ZDOLNOSCI.md).
- Układ Stół gracza + Tryb sesji, osiem jednolitych zakładek BG, aktualna TT,
  numerowane sloty ekwipunku, klikalne kropki zasobów zależne od właściwych reguł,
  rozwijana wyszukiwarka i zielone dedykowane ikony.
- Osiem poprawek zgłoszonych 9 listopada: ostrzeżenia zakupu Cech za 27 punktów
  i zakresu bazowego 8–15; pełny sprzęt startowy lub gamble; nazwy magazynków;
  kafelki Postoju i trwały postęp treningu; widoczne skutki Zranień; dodawanie
  i zmniejszanie Wyczerpania; pasek PD; niezależny autozapis notatek, znajomych
  i pierwszych spotkań. [Raport zmian i prób](POPRAWKI_8_2026-11-09.md).
- Przygotowanie Windows: konfiguracja NSIS x64, ikona ICO, polecenie buildu,
  ręczny workflow oraz instrukcja pracy na Windows. Paczka źródłowa zawiera
  katalog projektu, historię Git w bundle i manifest wersji.

## Przyjęte granice automatyzacji

- **Truciciel i Pogromca:** opisy produkcji wystarczają. Gracz sam oblicza ilości,
  koszty i czas oraz ręcznie wpisuje wyprodukowane przedmioty/amunicję. Nie są
  otwartym brakiem mechaniki ani warunkiem buildu Windows (decyzja 2026-11-08).
- Premie sytuacyjne, np. Mój wróg, rozlicza gracz; zdolności narracyjne są opisami.
- Obecny zakres przerzutów jest zaakceptowany. Nie rozszerzamy łączenia efektów.
- Nie dodajemy automatycznego trafienia/odejmowania PW, przerywania Berserka,
  dalszej automatyzacji zacięć/przegrzania, leków w walce ani konwersji starego BG.
- Zachowujemy już działające funkcje ręczne. Dokładnie pięć potyczek; bez 3D kości.

## Pozostaje

| Zakres                                                                                         | Status                                                                                                                                                                              |
| ---------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Końcowy odbiór sesyjny 24E                                                                     | Otwarty: reprezentatywne karty, rozwój, wieloklasowość, zasoby, odpoczynki, Kolory, ekwipunek/amunicja i udział w walce. Udane próby ośmiu poprawek nie zastępują całego odbioru.   |
| Build i odbiór Windows                                                                         | Do wykonania na Windows: instalator, instalacja, aktualizacja i próba aplikacji. [Instrukcja przekazania](PRZEKAZANIE_WINDOWS_2026-11-09.md), [procedura buildu](BUILD_WINDOWS.md). |
| Towarzysze                                                                                     | Przyszły backlog, nie blokuje 24E.                                                                                                                                                  |
| Web / konta / synchronizacja, backup GUI / import-eksport, publiczna dystrybucja / notaryzacja | Osobne decyzje; nie rozpoczęto realizacji.                                                                                                                                          |
| 45 przedmiotów bez dedykowanej grafiki                                                         | Mają dotychczasowe piktogramy; opcjonalne uzupełnienie wyglądu.                                                                                                                     |

## Weryfikacja 10 listopada 2026

- **569 testów TypeScript i 107 testów Rust — PASS.**
- Typy, lint, formatowanie i frontend build — **PASS**.
- Natywny build QA i docelowy build macOS — **PASS**. Build zakończony kodem 0;
  podpis zweryfikowany, `Info.plist` potwierdza wersję 0.29.5 i zachowany
  identyfikator wariantu 24E Roboczego.
- Natywne próby na osobnej bazie QA — **PASS**: walidacja Cech, pasek PD,
  Zranienia i Wyczerpanie, komplet startowy bez ponownego przyznania, notatki
  bez szkicu rozwoju, trening oraz zamknięcie i ponowne otwarcie. Notatki
  i postęp treningu zachowano po restarcie.
- Niezależny przegląd zmian nie wykazał istotnych regresji w autozapisie,
  ochronie przed powielaniem zestawu startowego i skutkach stanów.

Nie zmieniono migracji **001–014** ani identyfikatora aplikacji. Nowe notatki
korzystają z opcjonalnego `Character.journal` w istniejącym JSON; stare dane są
odczytywane przez fallback. Zmiany akcji inwentarza i zdrowia nie wymagają migracji SQL.
Próby wykonano na odrębnej bazie. **Porównanie skrótów bazy użytkownika — PASS**:
skrót przed pracą i po weryfikacji jest identyczny, baza nie została zmieniona.

Instalatora Windows i prób Windows nie wykonano. Pierwsza wersja Windows będzie
lokalną aplikacją z własną bazą, bez synchronizacji z Maciem. Podpis ad hoc macOS
nie jest notaryzacją. Historyczny raport przygotowania Windows:
[2026-11-08](PRZYGOTOWANIE_WINDOWS_2026-11-08.md).
