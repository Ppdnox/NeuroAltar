# Etap 22 — roller i odsyłacze do podręcznika (0.25.0)

## Wynik

Wprowadzono zmiany w rzeczywistym repozytorium `/Users/dominik/Desktop/Combat Tracker`.
Stan początkowy był czysty, Etap 21 zapisany w `c41dece`; dodatkowy checkpoint nie był potrzebny.
Zakres obejmuje Etap 22 i doprecyzowania MG dotyczące rollera oraz źródeł Wiedzy MG.
Etap 23 nie został rozpoczęty.

- Rozwijany panel Kości w prawym dolnym rogu Panelu MG: k4, k6, k8, k10, k12, k20, k100.
- Liczba 1–100 kości, modyfikator od −10000 do 10000; formuły np. 3k8+2, k20-1, 1k100.
- Wynik zawiera wszystkie składowe, sumę i modyfikator dodany raz. Panel pokazuje 100 ostatnich rzutów po restarcie.
- Klikane premie ataku i obsługiwane formuły obrażeń w profilu broni, cechy, RO i wymienione umiejętności z jawną premią.
- Rzuty z karty mają nazwę postaci, etykietę broni/testu, slot i rundę; trafiają do jej logu walki oraz historii kości.
- Awaria: przycisk k20 uzupełnia istniejący formularz. **Ręczne wpisanie oraz nadpisanie wyniku pozostają.** Dopiero „Zastosuj awarię” zmienia stan maszyny.
- Brak automatycznego trafienia, zmian PW z rzutu, zużycia akcji/zasobów/amunicji, zmiany tury, wyboru celu czy animacji 3D.
- Ponowienie z historii wykonuje samą formułę bez przypisania do dawnej postaci/rundy. Kolejny rzut z karty pobiera jej bieżący kontekst.

## Dane i bezpieczeństwo zapisu

**Jedna nowa migracja: `010_dice_history.sql`**, wyłącznie dodatkowa tabela `dice_rolls`.
Migracje 001–009 niezmienione; bez usuwania, odtwarzania ani podmieniania bazy użytkownika.
Każdy rzut ma stabilne UUID; zapis historii i opcjonalnego `dice_rolled` jest atomowy.
Ponowienie błędu zapisuje ten sam wynik, bez losowania lub podwójnego wpisu.
Kontekst jest opisem postaci w chwili rzutu; nie tworzy zależności usuwających historię wraz z aktorem.
Historia prezentuje 100 najnowszych rekordów; starsze rekordy pozostają w bazie dla spójności retry.
Zamknięcie czeka na rozpoczęty zapis, a błąd ujawnia panel z wynikiem do ponowienia.
Otwarty panel kości blokuje skróty walki, Escape zwija panel.

## Wiedza MG

Wszystkie 50 wpisów wskazuje **Neuroshima: Ostatnia Era** i drukowane strony.
W UI usunięto źródła w postaci „Suplement tabelaryczny · arkusz · komórki”.
Mapa i podstawa weryfikacji: [WIEDZA_MG_STRONY.md](WIEDZA_MG_STRONY.md).
Arkuszowe metadane pozostają w danych technicznych dla audytu. Surowy PDF i Excel
pozostają niezmienione, ignorowane przez Git i nie są pakowane do aplikacji.

## Testy i build

- `pnpm check`: **PASS**, TypeScript, ESLint, Prettier, **270 testów / 50 plików**.
- Rust release lib: **59 testów PASS**; `cargo fmt --check`: PASS.
- `pnpm build:macos`: **PASS**, aplikacja 0.25.0 dla macOS arm64, podpis ad hoc.
- Osobny build testowy: PASS, bundle ID `pl.neuroshima.combat-tracker.readability-smoke`.
- Testy obejmują granice kości i modyfikatorów, brak częściowej interpretacji błędnych formuł,
  równomierne losowanie, wyścig zamknięcia, błąd zapisu/odczytu, dokładny retry,
  atomowość historii/logu, zachowanie walki oraz ręczne nadpisanie awarii i jawny Apply.

## Natywny test macOS

Przeprowadzono w osobnej aplikacji i jej istniejącej bazie testowej, bez testowania na bazie MG.

- 3k8+2: składowe 1, 7, 7 → 17. Nie dodał wpisu do logu żadnej potyczki.
- Gangus kapo — Żółć QA, slot 5: UZI atak 1k20+6 → 8; obrażenia 1k6+3 → 6.
- SIŁ 1k20+2 → 14; Atletyka +6, 1k20+6 → 13. Każdy wynik pojawił się w logu slotu 5.
- Mobsprzęt, slot 1: awaria k20 → 7. Ręcznie wpisano 20; podgląd „Zniszczenie”, PW nadal 48.
  ⌘Q ujawnił niezakończony formularz; anulowanie pozostawiło maszynę bez nowej awarii.
- Błędne `2k6+` pokazało komunikat, nie utworzyło rzutu; Space z otwartym panelem nie przesunęło tury.
- Źródło Hełmów: „Neuroshima: Ostatnia Era · s. 114–115”.
- ⌘Q zakończyło proces po anulowaniu formularza. Po restarcie wszystkie sześć rzutów i ich wyniki były zachowane.
- Przycisk zamknięcia okna również zakończył proces. Panel sprawdzono wizualnie przy 1100×760.

Porównanie bazy przed/po: migracje 9→10; historia 0→6; log 43→48 (pięć jawnych rzutów z kart).
Wszystkie poprzednie wiersze logu i migracji zachowane. Bez zmian: 5 slotów, 9 aktorów,
2 statusy, 51 szablonów i 51 wpisów ich seeda, 299 przedmiotów oraz partia Ekwipunku.
Porównano pełne wiersze, w tym rewizje, przygotowane snapshoty i runtime.
`integrity_check`: ok; `foreign_key_check`: bez błędów.

## Ograniczenia przed Etapem 23

- Roller podstawowy obsługuje jedną grupę kości i stały modyfikator. Złożone/opisowe obrażenia,
  w tym ataki zapisane wyłącznie w opisie bez weaponProfile, pozostają do ręcznego ustawienia w panelu.
- Rzuty nie rozstrzygają trafienia, krytyków, ST, ułatwień ani utrudnień. Liczbowa kara Wyczerpania
  jest uwzględniona w testach z karty; pozostałe warunki ocenia MG.
- Cytowania wskazują odpowiednie fragmenty książki, ale tabele pozostają adaptacją Excela.
  Wykryte różnice (skrócony opis Hełmów, warunek właściwości Długa) opisano w mapie źródeł;
  ta zmiana nie jest audytem ani korektą całej mechaniki tabel.
- Build zgłasza ostrzeżenie o pakiecie JS ponad 500 kB (około 612 kB). Brak błędu kompilacji.
- Podpis ad hoc, bez notaryzacji; nie potwierdza publicznej dystrybucji, Intel ani Windows.
- Testowano aktualizację istniejącej bazy QA; bazy użytkownika celowo nie otwierano dla testów.

## Dostarczenie

Docelowo podmieniono `src-tauri/target/release/bundle/macos/NeuroAltar.app` na 0.25.0.
Poprzedni build zachowano obok jako `NeuroAltar 0.24.0.app`. To kopia aplikacji, nie bazy.
Kod i instrukcje zmieniono bezpośrednio w repo; bez paczek wymagających ręcznej instalacji.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `START_PROMPT_CODEX.txt`
- `START_PROMPT_WORK.txt`
- `docs/ACCEPTANCE_TESTS.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/DATA_MODEL.md`
- `docs/DECISIONS.md`
- `docs/PLAN_DALSZYCH_PRAC.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/WIEDZA_MG_STRONY.md`
- `docs/WORK_INSTRUCTIONS.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/migrations/010_dice_history.sql`
- `src-tauri/src/combat.rs`
- `src-tauri/src/dice.rs`
- `src-tauri/src/lib.rs`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/data/knowledge/catalog.ts`
- `src/data/knowledge/handbook-pages.v1.json`
- `src/domain/combatLog.ts`
- `src/domain/dice.ts`
- `src/domain/knowledge.ts`
- `src/features/combat/CombatWorkspace.tsx`
- `src/features/dice/ActorRoll.tsx`
- `src/features/dice/DiceDock.tsx`
- `src/features/dice/DiceWorkspace.tsx`
- `src/features/dice/dice.css`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/equipment/LoadoutPanel.tsx`
- `src/features/machine-failures/FailurePanel.tsx`
- `src/features/reference/KnowledgeWorkspace.tsx`
- `src/features/statblocks/StatblockPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `src/services/actorDice.ts`
- `src/services/diceHistory.ts`
- `src/services/failureDice.ts`
- `src/services/prepareAppClose.ts`
- `src/services/workspaceShortcuts.ts`
- `src/stores/diceStore.ts`
- `tests/dice.test.ts`
- `tests/knowledge.test.ts`
- `tests/navigation.test.ts`
- `docs/ETAP_22.md` — ten raport.
