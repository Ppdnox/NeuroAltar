# Instrukcje implementacyjne NeuroAltar

Aktualizacja: 2026-11-09. Obowiązujące reguły pracy są w [AGENTS.md](../AGENTS.md).
Ten plik opisuje przebieg zadania; nie powiela historii etapów.

1. Pracuj w rzeczywistym `/Users/dominik/Desktop/Combat Tracker` na aktualnym
   24E Roboczym. Sprawdź Git, wariant buildu i niezapisane zmiany użytkownika.
2. Czytaj [decyzje](DECISIONS.md), [plan](PLAN_DALSZYCH_PRAC.md),
   [roadmapę](ROADMAP.md), kontrakty danego modułu i jego najnowszy raport.
   Źródłem mechaniki jest podręcznik, z jawnymi rozstrzygnięciami MG.
3. Truciciel i Pogromca mają tylko opisy; produkcję, koszty i dopisanie
   przedmiotów rozlicza gracz. Nie dopisuj ich do braków automatyzacji.
   Premie sytuacyjne są ręczne, zdolności fabularne opisowe; dotychczasowe
   przerzuty wystarczają. Pozostałe granice określa AGENTS.
4. Osiem poprawek karty BG jest w 0.29.5. Kontynuacja na Windows:
   [instrukcja przekazania](PRZEKAZANIE_WINDOWS_2026-11-09.md).
   Nie ogłaszaj pełnego odbioru 24E ani Windows na podstawie samej kompilacji.
   Nie wracaj do dawnych „następnych etapów” 24B/24C/24D z archiwum.
5. Zachowaj pięć slotów, bazę, migracje 001–014, kompatybilność zapisów,
   prepared/runtime/katalog, rewizje, operationId, kolejki i ochronę formularzy.
   Testy wyłącznie na oddzielnych bazach. Nie dołączaj prywatnych źródeł/danych
   do repozytorium zdalnego ani instalatora. Nie zmieniaj tożsamości istniejącej
   aplikacji ani lokalizacji danych przy porządkowaniu dokumentacji.
6. Mechanikę utrzymuj poza komponentami UI, wspólną dla karty i potyczki.
   Warstwy zapisu i walidacja TypeScript/Zod/Rust pozostają zgodne.
   Zachowaj zaakceptowany układ, zieleń i wszystkie poprawki obsługi karty.
7. Dla dokumentacji sprawdź spójność, linki, format i diff. Dla kodu/konfiguracji
   wykonaj odpowiednie kontrole z AGENTS. Build Windows i natywny test wymagają
   osobnego wyniku; brak środowiska nie jest zaliczeniem. Zachowaj regresję macOS.
8. Dostarcz zmiany do tego samego repo, a gotowy build do potwierdzonego miejsca.
   Nie zamykaj siłowo aplikacji z możliwymi niezapisanymi danymi. Po weryfikacji
   commit obejmuje własne pliki, bez cudzych zmian i duplikatów.
9. Raportuj: wykonane zmiany, pliki, migracje/dane, konkretne wyniki kontroli,
   miejsce artefaktu i brakujące testy. Przygotowany workflow nie jest jeszcze
   działającym instalatorem; lokalny build nie jest publicznym wydaniem.

Towarzysze, web/konta/synchronizacja, import/eksport, backup z GUI i publiczna
dystrybucja pozostają osobnymi decyzjami, nie warunkami przygotowania Windows.

Poprzednia wersja instrukcji jest zachowana w historii Git (commit 1aeab92).
