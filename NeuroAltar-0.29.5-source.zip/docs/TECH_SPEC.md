# TECH SPEC — NeuroAltar

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.


Uzupełnienie MG: wybór **Koloru gry** w rogu karty (N/D, Rdza, Rtęć, Stal, Chrom),
odrębny od handlu, z wpływem na rozwój i odpoczynki. Kontrakt i testy:
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md).

## Etap 24C — inwentarz, masa i amunicja BG (0.28.0)

Karty BG mają niezależny inwentarz: kopie przedmiotów z katalogu i własne wpisy,
ilości, masę, cenę zapłaconą, miejsca przechowywania, pojemniki i wyposażenie.
Przyznanie plecaka startowego jest jednorazowe; masę jego opisanej zawartości
liczymy łącznie. Dodatkową broń, pancerz i narzędzia klasy dodaje się osobno.
Zweryfikowane profile 79 pozycji (62 bronie, 17 pancerzy/akcesoriów) dotyczą kopii BG.
Przeciążenie, pancerz i wyszkolenie wpływają na widoczne TT/Szybkość/ataki.
Nieznana masa wskazuje pozycję do uzupełnienia i nie udaje pełnego obciążenia.

Dokładny zapas i magazynki są rozłączne. Ładowanie, rozładowanie, wymiana,
przeładowanie mechanizmu i jawny zapis strzału mają podgląd i trwałe operationId.
Chrom domyślnie używa nieliczonego zapasu; ręczne oznaczenie naturalnej1 ustawia
pustą broń, przeładowanie przywraca gotowość. Dokładne ilości pozostają zachowane.
Decyzje MG: środki leczące w Chromie cena×0,5 (MG i BG); Gambling we krwi
+5 punktów procentowych **przed** mnożnikiem Koloru, ograniczenie0–100 na końcu.
Kolor gry i warunki handlu pozostają niezależne.

`Character.inventory` jest osobne od `sheet` i `draft`: odrzucenie rozwoju nie
cofa amunicji. Migracja012 rozszerza rodzaje poleceń, zachowując pełną historię;
001–011 i dane Panelu MG pozostają bez zmian. Raport: docs/ETAP_24C.md.
Minimum0PW na awans, Samouk9, Twardziel3/7/11 i cały Etap24B są zachowane.
Następny osobno zlecany podetap: **24D — zasoby i odpoczynki**;
potem24E integracja walki i odbiór macOS,25Windows. Zasady zacięcia/kosztów akcji,
krytyków i ograniczeń rundy zostaną połączone z udziałem BG w24E.
Nie deklarować pełnej karty ani wszystkich efektów Kolorów przed odbiorem24E.

## Stack
- Tauri 2
- React
- TypeScript
- Vite
- Tailwind CSS
- Lucide Icons
- SQLite
- Zod
- Zustand
- Vitest
- Git

Nie zmieniać stacku bez zatwierdzenia.

## Architektura
1. UI nie zawiera logiki systemowej.
2. Logika domenowa w `domain/` i `services/`.
3. Persistence przez repository layer.
4. Template ≠ encounter instance.
5. Prepared state ≠ runtime state.
6. Zmiana schematu DB zawsze przez migrację.
7. SQLite jest źródłem trwałych danych; Zustand = UI/cache.
8. Brak `any` w modelach domenowych.
9. Kod specyficzny dla OS izolować.

## Foldery
```text
src/
  app/
  components/
  domain/
  db/
  features/
    combat/
    encounters/
    initiative/
    bestiary/
    equipment/
    reference/
    statuses/
    injuries/
    machine-failures/
  services/
  stores/
  types/
  utils/
src-tauri/
  migrations/
tests/
docs/
```

## Kluczowe funkcje domenowe
- `advanceTurn`
- `calculateEncounterDifficulty`
- `applyInjuryLevel`
- `applyMachineFailure`
- `applyStatus`
- `resetEncounter`
- `clearEncounter`
- `calculateWeaponAttackProfile`

## DB
- SQLite lokalnie.
- numerowane migracje od `001_initial.sql`.
- nie kasować bazy, żeby "naprawić" migrację.

## Autozapis
Po każdej udanej zmianie runtime zapis do DB. Brak przycisku Zapisz.
Przy błędzie zapisu UI nie może udawać sukcesu.

## Testy
Vitest. Obowiązkowe:
- inicjatywa i remisy,
- przejście rund,
- odnowienie zasobów,
- injury,
- cowardice,
- SP/SD,
- reset/clear,
- machine failures,
- weapon attack profile,
- persistence.

## Git
Repo od pierwszego dnia. Commit po działającym etapie. Główna gałąź zawsze buildable.

## Cross-platform
v1.0 macOS. Logika domenowa bez zależności od macOS; późniejszy Windows ma być buildem tego samego projektu.

## Granice modułów — Etap 1.5

| Moduł | Katalog | Zakres / wydanie |
| --- | --- | --- |
| Walka | `combat` | v1.0: stan i prowadzenie walki |
| Potyczki | `encounters` | v1.0: pięć stałych slotów i przygotowanie |
| Bestiariusz | `bestiary` | v1.0: szablony przeciwników |
| Ekwipunek | `equipment` | wspólny model Item; v1.0 profile bojowe, v1.1 katalog i handel |
| Wiedza MG | `reference` | v1.2: lokalne wpisy wiedzy |

`initiative`, `statuses`, `injuries` i `machine-failures` są częściami funkcji
bojowych, nie dodatkowymi modułami głównej nawigacji. Rezerwacja katalogu nie
oznacza dodania ekranu lub przycisku do istniejącego UI.

Docelowe modele w `src/domain/`: Item/WeaponProfile, TradeContext/MarketValues
i KnowledgeEntry (ReferenceEntry jako alias). W Etapie 1.5 ich kontrakty istnieją
w dokumentacji; nie tworzymy nieużywanych tabel i nie przebudowujemy persistence.
Broń i amunicja są typami Item. Nie tworzymy równoległego repozytorium/tabeli weapons.
Przyszły kalkulator ataku przyjmuje weaponProfile; odrzuca brak profilu zamiast
nadawać przedmiotowi fikcyjny atak. Snapshot instancji jest niezależny od katalogu Item.

## Funkcje rynkowe (wdrożone w Etapie 20)

```ts
declare function calculateMarketPrice(item: Item, context: TradeContext, rules: MarketRules): PriceRange | null;
declare function calculateMarketAvailability(item: Item, context: TradeContext, rules: MarketRules): AvailabilityRange | null;
declare function calculateMarketValues(item: Item, context: TradeContext, rules: MarketRules): MarketValues;
```

Czyste, deterministyczne funkcje w domenie, bez React, SQLite, Excela, zegara i rzutów.
MarketRules dostarcza zweryfikowany katalog modyfikatorów regionu (według kategorii
ekonomicznej) i lokalizacji. Reguły Kolorów to jedna wspólna tabela domenowa zgodna
z `docs/DATA_MODEL.md`. `none` zawsze działa bez wpisu w katalogu.
Nieznany identyfikator/modyfikator inny niż `none` daje błąd walidacji; nie stosuj
cichego fallbacku do wartości bazowej. Region nie zmienia dostępności, lokalizacja
nie zmienia ceny. Nie utrwalaj wyników jako nowych wartości bazowych.

Najpierw walidacja Zod na granicy wejścia; potem obliczenia osobno dla min/max,
z ograniczeniem dostępności dopiero na końcu. W domenie brak zaokrąglania;
formatowanie wyniku nie zmienia danych. Zakres i brak wartości nie są pojedynczą
liczbą ani zerem. `calculateMarketValues` składa wyniki dwóch funkcji i zachowuje
niezależne braki ceny/dostępności.

Przy implementacji wymagane testy: none/none/none dokładnie równe bazie (także
zakresy, ułamki, 0%, 100%, null), niezależność wymiarów, kolejność dodawania/mnożenia,
każdy Kolor, Stal dla wszystkich typów Item, clamp 0–100%, brak mutacji bazy,
nieprawidłowe zakresy i nieznane identyfikatory. Etap 1.5 nie wprowadza tych funkcji.

## Excel i persistence w przyszłych wydaniach

Jednorazowe przetworzenie arkusza do zwalidowanych seed data w v1.1, jako praca
przygotowawcza. Brak skryptu importu w Etapie 1.5 i brak runtime sync/reimport UI/API.
W v1.1 seed trafi do aplikacji jako dane startowe, ze stabilnymi identyfikatorami
i jednorazowym, wersjonowanym zastosowaniem; nie nadpisuje edycji użytkownika ani
snapshotów przy każdym starcie. Nowe tabele dodaj dopiero w etapie ich użycia,
nową migracją i testem zachowania danych istniejącej bazy.

## Stabilna tożsamość aplikacji

Produkt i tytuł: NeuroAltar. Zachowaj folder Combat Tracker, istniejące techniczne
nazwy, `pl.neuroshima.combat-tracker`, `sqlite:combat-tracker.db` i katalog buildu.
Etap 1.5 nie zmienia migracji 001, konfiguracji Tauri, technicznych nazw pakietów
ani wersji aplikacji. Opis produktu w Cargo wskazuje warsztat MG.

## Zrealizowany Etap 2

- `src/domain/initiative.ts`: sortowanie, ręczne remisy, następna tura.
- `src/domain/combat.ts`: typy/Zod oraz oddzielenie surowego tekstu formularza od wartości liczbowych.
- `src/db/combatRepository.ts`: jeden SELECT odczytuje atomowo aktorów i rundę/turę wszystkich slotów.
- `src/stores/combatStore.ts`: osobne szkice BG w każdym slocie, debounce, kolejki, retry, blokowanie zamknięcia.
- `src/services/prepareAppClose.ts`: koordynacja zamykania szkiców potyczek i BG; błąd odblokowuje oba edytory.
- `src-tauri/src/combat.rs`: komenda save_combat na poolu DbInstances pluginu SQL, transakcja jednego połączenia i kontrola combat_revision.
- `002_pc_initiative.sql`: dodatkowa tabela aktorów, indeks slotu, wersja zapisu i kontrola tożsamości/tury, bez zmiany migracji 001.
- Bez nowego silnika bazy: serde/serde_json/sqlx/uuid to bezpośrednie zależności już obecne w dotychczasowym lockfile.

Testy Rust: `cargo test --manifest-path src-tauri/Cargo.toml --lib` obok pełnego
`pnpm check`. Testy obejmują wycofanie transakcji, konflikt wersji, izolację slotów,
zachowanie prepared snapshot, odczyt po restarcie i koordynację zamykania.

## Zrealizowany Etap 3

- `domain/enemy.ts`: EnemyTemplate, EnemyInstance, Speed, surowy formularz i walidacja.
- `domain/combat.ts`: uogólniony Actor/ActorDraft, instantiateEnemy, prepareActor,
  prepareCombat i resetEncounter. Snapshot jest głęboką kopią bez rekurencji.
- `combatRepository`: jeden SELECT obejmuje runtime i aktywny baseline. Nieprawidłowy
  reset_snapshot_json blokuje odczyt; nieprawidłowy stary snapshot nie blokuje runtime,
  ale uniemożliwia reset do czasu jawnego przygotowania.
- `combatStore`: wspólne kolejki BG/przeciwników; jawne prepare/reset korzystają z tych
  samych wersjonowanych zapisów. Niedokończony formularz przeciwnika blokuje zamknięcie
  i jest ujawniany we właściwym slocie przez prepareAppClose.
- `combat.rs`: zapis podstawowego template tylko jeśli nowy, kontrola kolizji danych
  istniejącego ID, zapis instancji/baseline/rundy i usunięć w jednej transakcji.
  Template ID/kind/slot nie mogą zmienić tożsamości istniejącej instancji.
- `003_enemy_instances.sql`: minimalna używana część enemy_templates, osobny aktywny
  reset snapshot i ograniczenia odwołań. Nie zmienia kodu migracji 001/002.

Historycznie podstawowy szablon nie miał pełnych sekcji statblocka (uzupełniono w Etapie 16); planowano je zgodnie
z roadmapą. Etap 8 musi wprowadzić edycję szablonów bez zmiany kopii zapisanych
w istniejących instancjach; obecna komenda nie aktualizuje szablonu i odrzuca kolizje.

## Zrealizowany Etap 4

- `src-tauri/src/combat_log.rs`: czysta funkcja changes(before, after, reason),
  odczyt poprzedniego stanu w transakcji i parametryzowane dopisywanie wpisów.
- `combat.rs`: save_with_reason obejmuje atomowo log i istniejący zapis walki.
  clear_log weryfikuje zgodność snapshotu, usuwa wpisy tylko danego slotu i zwiększa
  combat_revision bez aktualizowania aktorów, nazw/notatek, tury ani snapshotów.
- `combatStore`: kolejka niezmiennych snapshotów dla kolejnych akcji. Checkpoint
  pozostaje na czele do sukcesu; po błędzie ponowienie zachowuje kolejność.
  Zmiana tekstu bez akcji nadal korzysta z debounce. Closing opróżnia kolejki.
- `domain/combatLog.ts`: typy/Zod wpisów i SaveReason edit/prepare/reset/clear_log.
- `combatLogRepository` i service: strona 100 wpisów + informacja o kolejnej;
  stabilny kursor ID, porządek malejący, walidacja JSON i zgodności slotu.
- `combatLogStore`: osobne stany pięciu slotów; tokeny żądań odrzucają spóźniony
  odczyt po odświeżeniu lub czyszczeniu. UI aktualizuje log po udanym zapisie walki.
- `features/combat/CombatLog.tsx`: opis, czas/runda, starsze strony, retry i
  potwierdzenie czyszczenia. Treść renderowana jako tekst, bez HTML z danych.

Log dotyczy zatwierdzonych zmian. Po niepewnym wyniku IPC, który faktycznie zdążył
się zapisać, stara revision jest odrzucana zamiast dopisać duplikaty; szkic pozostaje
z komunikatem konfliktu jak wcześniej. Log nie jest mechanizmem undo ani pełnym
event-sourcingiem aplikacji. Nie zmieniono zależności ani stacku.

## Zrealizowany Etap 5

- domain/status.ts: katalog przypomnień, typy/Zod, walidacja formularza, funkcje czasu
  oraz wyliczenie kar Wyczerpania. Bez React, bazy, losowania i zegara systemowego.
- nextCombatTurn stosuje end/wrap/start do effects; korekta currentTurnActorId nie
  wywołuje hooków. PreparedActor zawiera niezależne effects i liczniki.
- StatusPanel/StatusForm: katalog/własny wpis, źródło/opis/czas, edycja/usunięcie,
  licznik Wyczerpania. Formularz jest w store, utrzymuje dane przy zmianie kart/slotów.
- combatStore: form guard i wspólna kolejka zapisu dla statusów/tur. prepareAppClose
  ujawnia slot niedokończonego formularza. Szybkie akcje pozostają checkpointami.
- status.rs: walidacja zgodna z Zod, odczyt i zapis status_json w transakcji walki.
  Błąd INSERT/UPDATE/DELETE/status log wycofuje całość. ID nie może przejść do innego aktora.
- combat_log.rs: różnice statusów, wygaśnięcia przy advance i pojedyncze przypomnienie
  Podpalenia po wygaśnięciach. HP jest tylko wartością wpisaną przez MG.
- actor_statuses w 005 nie migruje nazw z manualStatuses i nie zmienia snapshotów.
  Nowe UI i pole effects współistnieją z historycznymi opisowymi statusami.

Brak zmian zależności. Podpis/adres DB/stałe sloty i migracje 001–004 zachowane.

## Zrealizowany Etap 6

- domain/enemy.ts waliduje opcjonalne injuryTrack/cowardicePercent szablonu oraz
  injury/cowardicePercent instancji. Surowy procent nie jest zamieniany na 0.
- domain/injury.ts: applyInjuryLevel, setInjuryEnabled, changeExhaustion,
  injuryConsequences, cowardiceWarning. Bez React i persistence; UUID nowego statusu
  może dostarczyć caller. Tylko utworzenie statusu wymaga nowego ID.
- instantiateEnemy nalicza initialLevel przed prepare. Reset kopiuje stan, nie
  powtarza transition hooka. Przyciski Zranień korzystają z kolejki checkpointów.
- InjuryPanel i InjuryBadges pokazują stopień, konsekwencje i próg, bazując na
  zwalidowanym szkicu. Błędny szkic nie pokazuje fikcyjnych wyników.
- Rust waliduje nowe opcjonalne dane również w snapshotach. Statblock pomija
  nieobecne pola, więc istniejące template ID zachowują zgodność zapisu.
- Log: injury_changed, cowardice_changed i cowardice_warning przy wejściu pod próg.
  Próg TS BigInt / Rust i128 jest dokładny także dla MAX_SAFE_INTEGER PW.
- Nie zmieniono SQL schema; dotychczasowe kolumny JSON mieszczą nowe pola.
  Zgodność starych danych, transakcje, retry, close guard i reopen mają testy.

## Zrealizowany Etap 7

- capabilitySchema.ts: Zod Setup/State/Resource/Ability, raw CapabilityDraft,
  sprawdzanie zakresów, unikatowych ID, kosztów i referencji. Brak input→0 fallback.
- capabilities.ts: consumeCapability, adjustResource, restoreBudget,
  refreshCapabilities i actionRestriction; bez React, SQL, losowania i zegara.
- nextCombatTurn: globalny wrap odnawia round/legendary, owner start A/B/R; neutralna
  korekta tury i restart nie wywołują hooków. Statusy zachowują kolejność end/wrap/start.
- CapabilityFields współdzielone między tworzeniem szablonu i formularzem instancji.
  CapabilityForm w store, zamykanie ujawnia slot; panel pokazuje pule/koszty/blokady.
- Existing enemy JSON holds typed capabilities. Rust capability.rs sprawdza ten sam
  kontrakt, także w snapshotach. Statblock serializuje capabilities tylko gdy obecne.
- combat_log.rs: konfiguracja, wartości zasobów, pule, każde użycie (w tym wyjątek),
  jawne odnowienia. Wszystko w tej samej transakcji co aktorzy/efekty/revision.
- usageNumber nie jest zegarem: zwiększa się przy rejestracji użycia. Reset przywraca
  go jak resztę snapshotu; powód reset wyłącza generowanie action_used.
- Bez SQL DDL i nowych zależności. Zachowano istniejące migracje oraz tożsamość aplikacji.

## Zrealizowany Etap 8

- BestiaryWorkspace i TemplateFields: katalog oraz współdzielony edytor wzorca.
  Domena bestiary.ts: typy, tworzenie szkicu, filtrowanie/sortowanie bez React.
- bestiaryRepository: walidowany odczyt aktywnych rekordów; save_bestiary zapisuje
  przez Rust na tym samym poolu co walka. Jedna transakcja, kontrola wersji,
  walidacja zgodna z EnemyTemplate i idempotentne ponowienie identycznego zapisu.
- bestiaryStore zachowuje formularz i dokładną nieudaną mutację; blokuje równoległe
  zapisy, czeka na zapis przy zamykaniu i pokazuje błąd bez udawania sukcesu.
- combat::bestiary::ensure_instance_template sprawdza własną historyczną kopię
  istniejącego aktora. Nowi aktorzy mogą użyć katalogu lub zapisanej kopii; nadal
  nie można zmienić template_id, kind ani slotu istniejącego aktora.
- combatStore.addEnemies tworzy grupę w jednym checkpoint. Nie ma pętli osobnych
  zapisów ani częściowego sukcesu. Zachowuje istniejący mechanizm retry i logu.
- Migracja 006 dodaje dwa pola i indeks katalogu, bez zmiany wcześniejszych SQL.
  Brak nowych zależności i zmian adresu bazy/identyfikatora aplikacji.

## Zrealizowany Etap 9

- domain/item.ts: Item/WeaponProfile/CombatLoadout, walidacja Zod, czyste
  calculateWeaponAttackProfile, selectWeaponVariant i formatowanie zasięgu.
- domain/itemDraft.ts: surowe liczby/tekst, edycja bez utraty metadanych Item.
  Puste liczby opcjonalne to null; niepoprawny tekst pozostaje do poprawy.
- LoadoutFields współdzielone w Bestiariuszu i instancji; AttackProfiles tylko
  prezentuje wartości i wybory. Lucide Dice5 to ikona, nie kontrolka rzutu.
- combatStore.loadoutForm chroni formularz i ujawnia aktora/slot przy zamykaniu.
  Wybór wariantu i zatwierdzenie zestawu korzystają z kolejki zapisów walki.
- Rust item.rs: zgodny kontrakt serde i walidacja wariantów, zakresów, identyfikacji.
  bestiary zapisuje loadout przez dotychczasowy serializer statblock JSON.
  combat_log dodaje equipment_changed z pełnym before/after, w tej samej transakcji.
- Bez nowych zależności, migracji i tabel. Opcjonalne pola loadout w istniejących
  template/runtime/prepared JSON. Testy wspólnego fixture TS/Rust, rollback i reset.

## Zrealizowany Etap 10

- machineFailureSchema.ts: opcjonalny próg, typowane aktywne wpisy i surowy szkic.
- machineFailures.ts: apply/repair/tick, tabela, kary i blokady. Bez rzutów i DB.
- calculateWeaponAttackProfile przyjmuje opcjonalną listę awarii. TT w kolejce
  i podsumowaniu pochodzi z effectiveMachineTT; ruch z injuryConsequences.
- FailureForm/Panel: podgląd, jawne zastosowanie, indywidualna naprawa. Store
  zachowuje szkic, ujawnia slot przy close guard i używa kolejki checkpointów.
- Rust machine_failure.rs waliduje cele, czas i numery; combat_log porównuje próg
  i listę. Dane, PW, statusy, baseline, revision i log są jedną transakcją.
- Bez migracji i nowych zależności. Opcjonalne pola JSON zachowują stare dane.


## Etap 11 — implementacja 0.12.0

src/domain/difficulty.ts: parsePartyLevels, parseSP, calculateEncounterDifficulty,
difficultyLabel. Czysta domena, bez zależności UI. Waliduj skończone wartości i sumy
≤ Number.MAX_SAFE_INTEGER; ratio przy SD>0 i kompletnym SP, inaczej null.
Zwracaj sd/sp/knownSP/missingSP/ratio/percent/markerPercent/label. Marker to min(percent/3,100).
Nie zaokrąglaj przed klasyfikacją progów 126/176/251. Format PL tylko w prezentacji.
EncounterDetailsDraft przechowuje surowy partyLevelsText; parser tworzy tablicę.
Kolejka zapisuje najnowszą zwalidowaną kopię metadanych. Legacy updateDetails bez
partyLevels zachowuje kolumnę. SP używa istniejących JSON i transakcji Rust/logu.
Równoległy zapis walki nie nadpisuje metadanych poziomów. Bez migracji SQL.


## Poprawki Etapu 11 — 0.12.1

- Prezentacja wyników trudności: maksymalnie 2 miejsca po przecinku, bez zmiany
  surowych danych ani progów. Zapisane liczby zachowują pełną precyzję.
- Panel „Karta potyczki — trudność” zwijany; wybór rozwinięcia osobny dla slotów
  podczas sesji, błędne dane odsłaniają panel. Walka pozostaje dostępna.
- Mały pasek i procent/nazwa przy każdym z pięciu slotów, także nieaktywnych.
  Puste SD/brak SP to N/D, niepoprawny szkic „Popraw dane”.
- Aktualne SP korzysta z obramowania i odstępu etykiety jak pozostałe statystyki.
- Bestiariusz i formularz nowego przeciwnika pokazują konkretne pola, numery
  przedmiotów/formuł/akcji oraz przyczynę. Pierwszy błąd odsłania pole i ustawia
  kursor; kliknięcie błędu prowadzi do danej pozycji, także w zwiniętej sekcji.
- Walidacja zachowuje reguły: puste wymagane teksty, liczby, zakresy, koszty
  większe niż pule/zasoby i zasięgi. Błędy nie usuwają szkicu ani nie zapisują
  niepoprawnych danych. Brak migracji i zmian bazy, pięć slotów bez zmian.

## Etap 12 — transakcja Clear i integralność snapshotów

`encounterMaintenanceStore` blokuje oba edytory flagami closing, opróżnia kolejki
metadanych i walki, następnie wywołuje `clear_encounter` z revision i zapisanymi
name/notes/partyLevels. Nie zmienia lokalnych szkiców przed odpowiedzią. Close
koordynator respektuje blokadę; błąd pozostawia request do dokładnego retry albo
odczytu wyłącznie wskazanego slotu. Timer/queue sprzed Clear nie odtwarza danych.
Rust uzyskuje blokadę zapisu, sprawdza warunki, aktualizuje istniejący encounter,
usuwa jego aktorów (FK usuwa statusy) i cały log, commit. Awaria = pełny rollback.
Retry przy revision+1 jest uznawany tylko dla zgodnego pustego stanu i metadanych.
Metadane używają compare-and-save względem poprzednich wartości, niezależnie od
updated_at (ten znacznik zmienia także walka); identyczne ponowienie jest neutralne.
`prepared_state` waliduje przejście przed zapisem aktorów i logu. Nowa postać ma
własny snapshot; istniejący może zastąpić tylko Prepare obejmujące cały skład.
Reset odtwarza pełen baseline wszystkich obecnych aktorów, rundę 1 i pustą turę;
normalizacja remisów odpowiada TS (rank, UUID). Legacy bez prepared nie nadpisuje
istniejącego reset_snapshot_json; oryginalny prepared_snapshot_json jest niezmienny.


## Etap 13 — interakcje klawiatury

Czyste `combatShortcut` i `adjacentCard` rozpoznają zamiar i są testowane poza UI.
Komponent sprawdza kontekst DOM/otwarte formularze i wywołuje wyłącznie istniejące
selectActor lub nextTurn. Modal pomocy to HTML dialog z obsługą fokusu i Escape;
nie zmienia danych Zustand. Log używa details i nie odmontowuje historii przy
zwijaniu. CSS sticky ma warianty dla małej szerokości/wysokości. Bez SQL DDL.

## Etap 14 — weryfikacja i pakiet 0.15.0

Bez zmian domeny, transakcji, schematu, identyfikatora i URL SQLite.
Końcowe kontrole TS/Rust i natywne scenariusze: `docs/ETAP_14.md`.
Wersja w package.json/Cargo/Tauri i stopce jest spójna. Aktualny bundle arm64
ma podpis ad hoc; notaryzacja, Intel i Windows nie zostały zweryfikowane.
Niepełne pola statblocka to otwarty punkt zakresu v1.0 opisany w raporcie QA.

## Kontrakty przyszłych etapów 15–25

AppShell zarządza trasami home/gm/character, wspólnymi store i globalną ochroną
zamknięcia. Ukrycie widoku nie usuwa szkicu. Skróty ograniczone do aktywnego
modułu. W Etapie 15 character jest zapowiedzią, bez modelu DB pełnej postaci.
Przenośność utrzymywać od teraz; karta BG i jej odbiór na macOS w Etapie 24,
port oraz odbiór całej aplikacji na Windows w Etapie 25.

Seed Bestiariusza: trzy manifesty partii, stabilne ID, źródło/wersja, walidacja
TS/Rust i jednokrotne transakcyjne zastosowanie. Test ponownego startu, aktualizacji,
usunięcia/edycji przez MG i niezmienności instancji. Nie importować całego PDF
ani zakładać zależności Bestiariusza od UI Ekwipunku: istnieją osadzone Item/loadout.
Tabele Wiedzy mają strukturę danych z Excela, bez bibliotek Excel w runtime.

Roller: oddzielna domena, bez zależności od zapisu Combat. Dozwolona gramatyka
formuł, limity i bezpieczna walidacja, bez eval. Źródło losowości podmienialne
w testach, wynik zawiera rzuty i składowe sumy. Historia oddzielona od zdarzeń
zmieniających walkę. Nie tworzyć auto-apply damage ani silnika 3D.

Pełna postać: oddzielny model trwały i projekcja bojowa z jawnie określonym
kierunkiem synchronizacji, wersjonowaniem i polityką konfliktów. Reset snapshotu
potyczki nie zapisuje starego stanu do trwałej postaci. Obliczenia cech, udźwigu,
zasobów i odpoczynków jako testowalne funkcje; macierz reguł pokrywa klasy/wyjątki.
Amunicja tylko Character: operacje zużycia/przeładowania atomowe i bez podwójnego
naliczenia po retry. Zera/ujemne wartości i brak masy sprawdzać jawnie.
Zasoby short/long/manual rozliczane według reguły, nie globalnym napełnieniem.

Nowe tabele tworzyć dopiero w etapie użycia z addytywną migracją i testem starej
bazy. Etapy 15–25 opisują przyszłą implementację; ta aktualizacja nie dodaje DDL.
Pełne kryteria i kontrole dokumentacji/implementacji: PLAN_DALSZYCH_PRAC.md.

## Etap 15 — nawigacja

navigationStore przechowuje stronę i sygnał ujawnienia błędu zamykania. App uruchamia inicjalizację i close guard niezależnie od strony. GM ma hidden, a nie demontaż. workspaceShortcuts sprawdza widoczność przed każdą akcją klawiatury. Nie zmieniamy schematu SQLite.

## Etap 16 — implementacja i zgodność

Statblock ma wspólny kontrakt TS/Zod i Rust oraz współdzielony fixture testowy. Edycja runtime ma statblockForm w combatStore, ochronę zamknięcia, wyłączenie konfliktujących poleceń i zapis przez istniejący checkpoint/retry. FieldValidation obsługuje dokładne ścieżki zarówno template, jak i runtime. Rozwijana prezentacja instancji jest niezależna od podglądu jej starego szablonu. Repozytoria czytają dodatkowe pole w istniejącym JSON, bez nowych tabel. Zmiana wpisu i logu jest atomowa; reset odtwarza pełne prepared. Radio wyboru pięciu slotów zastępuje natywne menu, a operacja Add ×N nadal zapisuje jeden checkpoint wyłącznie wybranego slotu.

## Etap 17 — maszyny z podręcznika (0.18.0)

**11 wpisów, tyle co typów maszyn w podręczniku.** Mobsprzęt ma jeden statblock,
pełną listę sześciu ponumerowanych broni oraz adnotację „rzuć 1k6 i wybierz jedną”.
W opisie ruchu zachowano tabelę trzech podwozi i warunki. Spawacz ma jeden wpis
z lotem opisanym „tylko SMART”. Aplikacja nie wymusza selektora wariantu i nie losuje.
MG rozstrzyga wybór i może usunąć niewylosowane pozycje w edytorze uzbrojenia kopii.
Dane katalogu oraz inne kopie pozostają niezależne.

Statblock otrzymuje opcjonalne, edytowalne „Zdolności stałe i uwagi źródłowe”.
Tu zachowano pasywy, warunki, inicjatywę, formułę PW i strony podręcznika. Lista
jest widoczna w katalogu/karcie i objęta wyszukiwaniem oraz precyzyjną walidacją.
Broń oparta na RO celu to Item bez fikcyjnego weaponProfile/premii do Testu Ataku;
wyświetla opis, ST, obszar i skutki oraz może być wskazana w awarii niszczącej broń.
Nie dodano automatycznych rzutów, obrażeń, leczenia ani amunicji. Limity zdolności
na walkę/dzień pozostają zasobami; przy ataku wielokrotnym MG ręcznie odejmuje
zużycia pod-ataków, wykorzystując jeden budżet Akcji.

Seed inicjuje się po migracjach, przed odczytem potyczek. Migracja 007 dodaje tylko
rejestr danych startowych. Edycje i usunięcia MG, pięć potyczek, snapshoty oraz
logi są zachowane. Pełna polityka korekt i odbiór: ETAP_17.md (w katalogu docs).
Etap 18 nadal wymaga odrębnego zlecenia.

## Etap 18 — bezpieczna taksonomia i druga partia danych

Migracja 008 wyłącznie ALTER TABLE ADD COLUMN official_category z CHECK.
Migracje 001–007 pozostają bajtowo bez zmian. Rust i TS znają pięć nowych kategorii
oraz dwie historyczne. Rust/SQL zapisują kategorię jawną i kompatybilną, frontend
czyta COALESCE; ten sam kontrakt obowiązuje seed, CRUD i nową instancję z formularza.
Start kolejno stosuje maszyny v1 i potwory v1; osobna transakcja każdej partii.
Błąd potworów nie cofa ukończonych maszyn; retry bez duplikacji. Pakiet maszyn
nie zmienia wersji ani treści. Potwory: 12 stabilnych ID, źródło/strony/SHA-256.
Zombie: źródłowe reguły + czysta funkcja przygotowania szkicu, wybór nosiciela i
jego ataków wręcz, potem istniejący formularz/ochrona zamykania/repository/CAS.
Brak ogólnego silnika nakładek, automatycznej infekcji czy modyfikacji postaci w walce.

## Prezentacja i rozmiar tekstu (0.19.1)

Root font-size: clamp(16px, 12px + 0.4vw, 20px), mnożony przez preferencję
100/115/130/150%. Typografia w rem; siatki odpowiadają szerokości kontenera.
ReadingControls zapisuje wyłącznie preferencję neuroaltar:reading-scale:v1
w localStorage. Nieprawidłowa/niedostępna wartość wraca do Auto; niedostępny
zapis preferencji nie blokuje aplikacji. Brak zmiany SQLite/JSON domenowych.
StatblockSummary/CapabilitySummary/RuleText zachowują pełną treść reguł.

## Etap 18A — trzecia partia Bestiariusza

`src/data/bestiary/mutants.v1.json` jest walidowana przez istniejące kontrakty
TS/Zod i Rust. `bestiary_seed.rs` instaluje kolejno machines, monsters, mutants.
Nowy batchId noe-mutants dopuszcza tylko kategorię mutant. Każda partia zachowuje
własną transakcję i retry; awaria trzeciej nie cofa dwóch pierwszych. Dotychczasowe
JSON-y v1 są niezmienione. Obowiązują stabilne ID, wersja, SHA256 i strony źródła.
Bez zmian UI, mechaniki, zależności, schematu czy sposobu przechowywania danych.

## Etap 18B — zwierzęta (0.21.0)

Czwarta partia `animals.v2.json`, batchId `noe-animals`, version 2.
Startup: machines → monsters → mutants → animals; osobne atomowe transakcje.
`unlimitedReactions?: boolean` jest walidowane przez Zod i Rust, kopiowane do
runtime/prepared/reset i edytowalne. Brak pola zachowuje starszy zapis.
consumeCapability nie odejmuje reaction budget przy true, lecz respektuje
restrykcje i resourceCost. usageNumber zwiększa się przy każdym użyciu, więc
atomowy log rejestruje także użycia bez zmiany licznika. Wyłączenie właściwości
nie odnawia wcześniej zużytej zwykłej reakcji. Migrations 001–008 bez zmian.

## Poprawki czytelności — 0.21.1

Zlecono wyłącznie korekty tekstów i widoków, bez Etapu 19. „Chód” w interfejsie
zastępuje „Szybkość”; prezentacja ruchu zawiera m. SP podręcznikowej kopii z
podaną wartością jest nieedytowalne w karcie walki; ręczne tworzenie i własne
wpisy zachowują pole. Wartości, liczenie trudności i dane pozostają niezmienione.
Usunięto wskazane dopiski administracyjne i dekoracyjny licznik slotów,
skrócono nagłówki. Pancerz: TT z wartością i opisem w nawiasie.
Wspólna prezentacja działa także na starych snapshotach; seed i SQL nietknięte.
Raport/kryteria odbioru: CZYTELNOSC_0.21.1.md. Następny etap wymaga zlecenia.

## Etap 19 — ludzie (0.22.0)

Zlecony po poprawkach 0.21.1. Dziewięć statblocków z s. 207–213 (PDF 209–215):
Cyngiel, Cywil, Gangus żołnierz, Gangus kapo, Gangus boss, Konwojent (strażnik),
Kanibal, Szeryf i Żołnierz Posterunku. Katalog startowy: 51 szablonów + nakładka Zombie.
Wariant farmera pozostaje bronią Cywila. Ofiara jest Reakcją; dodatkowy nóż Cyngla
Akcją Bonusową. Trzy długie serie mają osobne limity 2/walkę i są opisane przez RO,
bez fikcyjnego Testu Ataku. Przedmioty noszone są opisem, bez liczenia amunicji.
Nie sumować ponownie premii Kuloodpornego i Brutalnego ciosu; wartości końcowe
pozostają źródłowe. Warunkowe premie, przywołania, rzuty i obrażenia nie są automatyczne.
Nowa partia noe-humans v1, bez zmiany kontraktów ani migracji 001–008. Starsze partie,
edycje/usunięcia MG, instancje i snapshoty zachowane. Obowiązują poprawki czytelności 0.21.1.
Historyczny raport: ETAP_19.md. Etap 20 wdrożono następnie w 0.23.0.

## Etap 20 — Ekwipunek (0.23.0)

Wdrożono katalog 299 pozycji z tabelarycznego Excela: wszystkie osiem typów Item,
wyszukiwanie nazw/opisów/właściwości, filtry typu i kategorii, waga oraz zakresy
ceny i dostępności. Panel MG → Ekwipunek. Jedenaście regionów, cztery lokalizacje
i pięć Kolorów; niezależne N/D, domyślnie none/none/none. Stal modyfikuje tylko
Item.type weapon/ammunition, także gdy brak weaponProfile.

Katalog w tym etapie służy do przeglądania i obliczeń handlu. Nie zmienia
przedmiotów osadzonych w Bestiariuszu, walce ani przygotowanych kopiach.
Warunki handlu i filtry zachowują się w sesji przy przełączaniu modułów;
nowe uruchomienie zaczyna od wartości bazowych. Brak edytora katalogu,
liczenia inwentarza/amunicji, rollera, importu/synchronizacji Excela i UI Wiedzy MG.
Wagi zakresowe/przybliżone pozostają tekstem, brak danych = N/D, nigdy zero.

Migracja 009 dodaje items i equipment_seed_batches; migracje 001–008 pozostają
niezmienione. Jednorazowy, transakcyjny seed po migracjach i przed udostępnieniem
repozytoriów. Ponowny start nie nadpisuje wpisów ani nie odtwarza usunięć.
Raport: ETAP_20.md. Następny etap: 21 — Wiedza MG; tylko po nowym zleceniu.

## Etap 21 — Wiedza MG (0.24.0)

Panel MG → Wiedza MG: 50 wpisów, działy, wyszukiwanie po treści, tabelach i
nagłówkach (także bez polskich znaków), pasujące wiersze z zachowaniem kontekstu.
47 tabel/opisów z 13 arkuszy oraz trzy tabele MODYFIKATORÓW wyprowadzane z
istniejących reguł Ekwipunku. Spis zakresów: WIEDZA_MG_ZRODLA.md.
Długie opisy mają rozwijane akapity; nagłówki, jednostki, uwagi oraz odsyłacze
do arkusza/komórek pozostają dostępne. Na węższym panelu wiersze przechodzą
w karty z etykietami kolumn. Link do Ekwipunku prowadzi do przeliczania cen.

KnowledgeEntry zawiera strukturalne blocks: table (columns/rows/cells) i text;
ReferenceEntry to alias tego modelu. Wpisy są zwalidowane przez Zod i dostarczane
z aplikacją jako niezmienny katalog tylko do odczytu, bez nowej tabeli SQL.
Stan wyszukiwania/działu/wyboru trwa w sesji; nie zmienia potyczek ani ich bazy.
Migracje 001–009, identyfikator aplikacji, Bestiariusz, Item i TradeContext bez zmian.
Kolory i mnożniki handlu mają jedno źródło prawdy współdzielone z Ekwipunkiem.

Nie dodano kalkulatora, rollera, automatycznych efektów, liczników amunicji,
edycji wiedzy ani importu/synchronizacji Excela. Opisy rzutów i „Rzuć dwa razy”
są treścią tabel źródłowych; niczego nie uruchamiają. Raport: ETAP_21.md.
Następny etap: 22 — prosty roller, wyłącznie po osobnym zleceniu.

## Etap 22 — roller i strony podręcznika (0.25.0)

Zlecony po Etapie 21 (`c41dece`). Rozwijany panel Kości w prawym dolnym rogu:
k4/k6/k8/k10/k12/k20/k100, 1–100 kości, modyfikator ±10000 i pełne formuły
NkS±N (także d). Pokazuje każdą kość, sumę i 100 ostatnich wyników po restarcie.
Kliknięcie ataku, obsługiwanej formuły obrażeń, cechy, RO lub umiejętności
z jawną premią rzuca z kontekstem postaci i zapisuje wynik w logu jej potyczki.
Atak korzysta z bieżącego profilu; cecha z jej modyfikatora, RO/skill z podanej
premii końcowej. Liczbowa kara Wyczerpania dotyczy testów, nie obrażeń/awarii.
Pozostałe warunki i ułatwienia/utrudnienia ocenia MG. Nieobsługiwane, złożone
lub opisowe formuły pozostają tekstem; brak częściowego zgadywania rzutu.
Rzuć awarię k20 wypełnia istniejący formularz. Ręczne wpisanie i zmiana wyniku
pozostają dostępne. Tylko osobne „Zastosuj awarię” zmienia stan maszyny.
Rzuty nie zmieniają PW, zasobów, amunicji, tur, statusów ani wyboru celów.
Ponowienie z historii jest nowym rzutem samej formuły bez starej postaci/rundy.

Migracja 010 dodaje wyłącznie tabelę dice_rolls. 001–009 pozostają nietknięte.
Historia i opcjonalny wpis dice_rolled powstają w jednej transakcji; stabilne
UUID umożliwia ponowienie zapisu bez losowania i duplikowania. Nie zmieniamy
rewizji ani snapshotów walki. Zamknięcie czeka na zapis; błąd ujawnia panel
z zachowanym wynikiem. Skróty walki są zablokowane przy otwartym panelu kości.

Wiedza MG pokazuje tytuł „Neuroshima: Ostatnia Era” i drukowane strony zamiast
arkusza/komórek. 50 przypisań udokumentowano w WIEDZA_MG_STRONY.md. Treść tabel
pozostaje adaptacją Excela; samo dodanie odsyłaczy nie koryguje różnic mechaniki.
Surowe źródła pozostają poza repo/bundle; brak synchronizacji/reimportu.
Raport: ETAP_22.md. Następny Etap 23 — odbiór Panelu MG na macOS — wymaga zlecenia.


## Poprawki kart walki — 0.25.1

Zlecone po Etapie 22 (2cd2926), dla wszystkich przeciwników, także istniejących
instancji i wpisów MG. Bieżące cechy/RO, obrona i zmysły są stale widoczne przed
„Parametry i notatki postaci”. Opisy zdolności, reguł i broni mają klikalne jawne
premie ataku i formuły kości, także mieszane np. 2k8+2k6+4. ST/RO celu pozostaje
opisem; nie przypisuj rzutu obronnego do atakującego. Rzut nie zużywa zdolności
ani nie zmienia PW/zasobów; log zachowuje nazwę zdolności i postaci. Tekstowa
premia ataku uwzględnia liczbowe kary awarii i Wyczerpania bez doliczania PB.
Własne opisy korzystają z tej samej obsługi jawnych zapisów. Nieznanych wartości
nie zgadujemy. W historii opcjonalne groups opisuje mieszane kości; stare wpisy
bez groups nadal działają. Bez migracji i bez zmian seedów/snapshotów.
Raport: POPRAWKI_0.25.1.md. Etap 23 nadal wymaga osobnego zlecenia.


## Wyszukiwarka przeciwników i rzut inicjatywy — 0.25.3

„Dodaj przeciwnika” otwiera wyszukiwarkę Bestiariusza w bieżącej potyczce.
Nazwa (także bez polskich znaków) i kategoria zawężają wyniki; „Dodaj” tworzy
jedną niezależną instancję i zamyka okno. „Dodaj własnego” otwiera dotychczasowy
formularz ręczny. Escape anuluje wybór, bez zmiany składu.

Przycisk inicjatywy przy statblocku i ręcznym polu wyniku rzuca 1k20 z jawną
premią „Inicjatywa: ±N” (również dawny zapis „z podręcznika”). Liczba w nawiasie
nie jest premią. Gdy brak tej pozycji, używany jest modyfikator Zręczności;
nieznana lub sprzeczna premia wymaga ręcznego wyniku. Odejmowana jest liczbowa
kara Wyczerpania. MG nadal ocenia pozostałe warunki testu.

Wynik, historia kości, log i rewizja potyczki zapisują się w jednej transakcji.
Kolejność inicjatywy aktualizuje się bez zmiany rundy, bieżącej tury, remisów,
PW, zasobów ani przygotowanych snapshotów. Inicjatywa nie przygotowuje krytyka.
Przed rzutem kończy się autozapis; podczas zapisu edycja i zamknięcie czekają.
Błąd zachowuje dokładny wynik do ponowienia, bez kolejnego losowania. Odczyt
aktualnego stanu pozwala rozstrzygnąć niepewny zapis lub porzucić niezapisany rzut.
Ręczny wpis pozostaje dostępny. Brak migracji; 001–010 pozostają niezmienione.
Raport: POPRAWKI_0.25.3.md. Etap 23 nadal wymaga osobnego zlecenia.


## Korekta miejsca inicjatywy i źródeł Ekwipunku — 0.25.4

Zlecenie MG po 0.25.3: interaktywny jest wyłącznie istniejący wpis
„Inicjatywa: …” w „Zdolnościach stałych i zasadach” karty przeciwnika.
Usunięto dodatkowe przyciski z pola wyniku i nagłówka statblocku. Pole wyniku
ma zwykłą etykietę i ręczną edycję; cztery pola oraz przyciski „Dodaj przeciwnika”
i „Dodaj własnego” są wyrównane. Atomowy zapis inicjatywy z 0.25.3 pozostaje.
Nie dodawaj drugiego wpisu inicjatywy ani nowego przycisku poza istniejącą zasadą.

Źródła wszystkich 299 pozycji Ekwipunku pokazują „Neuroshima: Ostatnia Era”,
drukowane strony oraz właściwą tabelę/sekcję. Granaty i miny wskazują swoje
opisy, gdy książka nie zawiera tabeli. Mapa: EKWIPUNEK_STRONY.md i
src/data/equipment/handbook-sources.v1.json. Powiązanie po ID i oryginalnym
źródle seedu działa także na istniejącej bazie. Własnych źródeł MG nie nadpisujemy.
Bez zmiany danych mechanicznych, seedu, migracji lub reimportu. Raport
POPRAWKI_0.25.4.md. Etap 23 nadal wymaga nowego zlecenia.

## Etap 24A — granica domeny karty

[KARTA_BG_KONTRAKT.md](KARTA_BG_KONTRAKT.md) określa czyste derive/preview,
transakcje wieloagregatowe i kontrolę rewizji, bez drugiego źródła prawdy w UI.
Przyszłe katalogi reguł muszą używać stabilnych ID oraz referencji podręcznik/strona;
nie parsować etykiet UI ani tekstu PDF przy obliczeniach. Przenośny kod bez API
macOS w domenie. Żaden nowy moduł kodu nie powstał w24A.


## Implementacja24B

Czyste funkcje w src/domain/character: ścisły model Zod, jawny katalog wyborów,
deriveCharacter/deriveWeapon, kontrola wcześniejszego rozwoju i opis porównania.
Zustand characterStore zarządza szkicami, kolejkowanym autozapisem, retry i
konfliktami. Repozytorium wywołuje save_character. Rust sprawdza strukturę,
granice zapisu, revision i operationId; semantyczne wybory podręcznikowe waliduje
silnik domenowy przed publikacją. Nie parsować opisów reguł ani PDF w runtime.

prepareAppClose obejmuje kartę. Niekompletny, poprawnie zapisany szkic może
przetrwać zamknięcie; błędny surowy wpis liczby lub nieudany zapis blokuje wyjście
i ujawnia kartę. Nie gubić nowszych edycji podczas ponowienia niepewnego zapisu.
Lokalne portrety tylko PNG/JPEG/WebP w limitowanym data URL, bez zdalnych obrazów.

## Implementacja24C

inventoryModel/inventory: Zod, integralność, czyste polecenia i masa;
equipped: pancerz, obciążenie, profile broni; inventoryCatalog: kopie
zweryfikowanych profili oraz zestawy startowe. InventoryPanel: lokalna
wyszukiwarka katalogu, edytor, podgląd, potwierdzenie, komunikaty i close guard.
Dane edytora są zachowywane w pamięci po zmianie widoku; niedokończony
formularz blokuje zamknięcie i wskazuje kartę. Nie zapisuje roboczych cyfr
jako gotowej transakcji. Polecenia wymagają zatwierdzonej karty bez szkicu.
Rust character_inventory niezależnie oblicza wynik komendy i porównuje go
z podglądem. Jedna transakcja: inventory+revision+operationId/request/result.
Ponowienie zwraca historyczny wynik; nie wykonuje kolejnej mutacji.
Draft/publish/discard/archive nie mogą zmienić inventory. Konflikt inwentarza
wymaga odczytu nowego stanu i przygotowania nowej operacji, bez rebase amunicji.
