# Czytelność przed Etapem 19 — NeuroAltar 0.19.1

Data: 12 września 2026. Punkt wyjścia: czysty commit `365e6a9` (0.19.0).
Zakres: korekta prezentacji istniejących funkcji, przed kolejną partią Bestiariusza.

## Zmiany widoczne dla MG

- Bestiariusz: nazwa i typ przeciwnika, wyróżnione TT/PW/SP/Próg Awarii,
  osobne kafle sześciu cech z modyfikatorem i końcowym RO.
- Umiejętności, zmysły i obrony w grupach; reguły pasywne w kartach,
  zdolności pogrupowane według rodzaju akcji. Sekcje można zwijać.
- Źródła, informacje pomocnicze i wyjaśnienie premii do ataku rozwijane.
  Lista broni w Bestiariuszu ma osobną sekcję, dzięki czemu nie powtarza
  od razu całej treści zdolności. Pełne reguły i warunki pozostają dostępne.
- Mobsprzęt zachowuje sześć broni oraz zasadę ręcznego wyboru jednej przez 1k6.
  Nakładka Death Breath i akcje instancji korzystają z czytelniejszego podziału.
- Treść wykorzystuje szerokość okna. Siatki przechodzą do jednej kolumny przy
  małym obszarze; cechy pokazują sześć lub trzy kafle w rzędzie.
- Typografia w rem. Auto skaluje bazę płynnie od 16 do 20 px wraz z szerokością
  okna. Przyciski Tekst: A−/A+ i Auto pozwalają wybrać dodatkowe 115/130/150%.
  To procent aktualnej wartości Auto. Ustawienie przetrwa ponowne otwarcie.
- Puste listy trybów broni i pojedyncza formuła nie zajmują miejsca jako
  zbędne wybory. Istniejące warianty, efekty oraz ostrzeżenia pozostają.

## Dane i zakres

Brak nowych migracji. Migracje 001–008, seed maszyn i potworów, model domenowy,
repozytoria, kolejki zapisu, snapshoty, logi i ochrona zamykania niezmienione.
Nie zmieniano bazy użytkownika. Pięć stałych slotów zachowane.
Jedyny nowy zapis to lokalna preferencja wyświetlania
`neuroaltar:reading-scale:v1` w localStorage; brak zapisu nie blokuje pracy.
Nie rozpoczęto Etapu 19 ani partii 18A/18B.

## Sprawdzenia

- `pnpm check` w docelowym repo: TypeScript, ESLint, Prettier oraz
  **201 testów w 41 plikach — PASS**.
- Cztery nowe testy prezentacji sprawdzają pełne reguły i akcje wszystkich
  23 wpisów podręcznikowych, sześć broni Mobsprzętu, polski/wielowierszowy tekst,
  bezpieczne wyświetlanie znaków HTML oraz rozróżnienie zero/Brak/N/D.
- `cargo test --manifest-path src-tauri/Cargo.toml --release --lib`:
  **45 testów — PASS**. `cargo fmt --check` i `git diff --check` — PASS.
- `pnpm build:macos` w rzeczywistym repo — PASS, arm64, podpis ad hoc.
- Natywny smoke test osobnej aplikacji i bazy
  `pl.neuroshima.combat-tracker.readability-smoke` — PASS:
  okno 1100×760, 760×580, maksymalizacja i pełny ekran;
  Auto/115/130/150%, reset Auto i restart z zapamiętanym 150% oraz Auto;
  karty Mobsprzętu i Megatora, pełna lista sześciu broni, zwijanie sekcji.
- W testowej potyczce: inicjatywa Megatora 13, rozpoczęcie tury,
  Zionięcie zmniejsza limit 2→1 oraz Akcję 1→0; wartości przetrwały restart.
  Spacja na nagłówku sekcji rozwija ją bez przejścia do następnej tury.
- Polska notatka dwuwierszowa przetrwała zmianę wielkości okna i restart.
  Zwykłe zamknięcie okna i ⌘Q kończą proces.
- Kopia zamkniętej bazy QA: `integrity_check=ok`, bez naruszeń kluczy obcych,
  sloty 1–5, 23 szablony, zachowane notatki. Odczyt wykonywano na kopii pliku;
  bezpośrednie otwarcie QA przez SQLite zatrzymało się na dostępie do pliku.

## Dostarczenie

Docelowa aplikacja: `src-tauri/target/release/bundle/macos/NeuroAltar.app`.
Wersja 0.19.1, identyfikator produkcyjny `pl.neuroshima.combat-tracker`.
Poprzedni build zachowany obok jako `NeuroAltar 0.19.0.app`.
Podpis sprawdzany przed i po podmianie. Zmiany zapisane w Git po weryfikacji.

## Ograniczenia przed kolejnym etapem

Auto zmienia typografię w ograniczonym zakresie, aby ogromny ekran nie dawał
przesadnie dużych liter. Większy tekst w małym oknie wymaga przewijania pionowego.
Ustawienie rozwinięcia sekcji jest stanem widoku; po zmianie przeciwnika/ponownym
uruchomieniu wraca do domyślnego. Zapamiętywany jest rozmiar tekstu.
Nie zmieniono treści podręcznikowych ani rozstrzygania zasad.
Build jest lokalny arm64, bez notaryzacji; Intel/Windows nie były testowane.

## Zmienione pliki

- `AGENTS.md`
- `README.md`
- `README_FIRST.md`
- `docs/CODEX_INSTRUCTIONS.md`
- `docs/ROADMAP.md`
- `docs/TECH_SPEC.md`
- `docs/UI_GUIDELINES.md`
- `package.json`
- `src-tauri/Cargo.lock`
- `src-tauri/Cargo.toml`
- `src-tauri/tauri.conf.json`
- `src/app/App.tsx`
- `src/app/styles.css`
- `src/features/bestiary/BestiaryWorkspace.tsx`
- `src/features/bestiary/DeathBreathPanel.tsx`
- `src/features/equipment/AttackProfiles.tsx`
- `src/features/resources/CapabilityPanel.tsx`
- `src/features/statblocks/StatblockSummary.tsx`
- `src/components/ReadingControls.tsx`
- `src/features/statblocks/CapabilitySummary.tsx`
- `src/features/statblocks/RuleText.tsx`
- `tests/statblockPresentation.test.ts`
- `docs/CZYTELNOSC_0.19.1.md`
