# NeuroAltar — identyfikacja wizualna

Kierunek przyjęty na prośbę użytkownika 6 września 2026, przed Etapem 1. Nazwa produktu: **NeuroAltar**, zapis z wielkimi literami N i A. Określenie pomocnicze: „Warsztat Mistrza Gry”.

## Inspiracja

Lokalny podręcznik Neuroshima 5e: papierowe strony, turkusowe nagłówki, grafitowe metalowe zakładki, rdzawe wyróżnienia oraz krótkie pasy ostrzegawcze. Przejrzano m.in. strony PDF 2, 21, 81 i 240: mapę, reguły, tabelę i statblock. To odniesienie do języka wizualnego; interfejs, monogram i faktura są własnymi elementami CSS/SVG. Nie importujemy ilustracji, logo, fontów ani zrzutów stron z podręcznika.

## Paleta

Tokeny źródłowe są w `src/app/styles.css`, w bloku `@theme`.

| Token       | Kolor     | Rola                                              |
| ----------- | --------- | ------------------------------------------------- |
| paper       | `#EEE7D6` | Główna powierzchnia robocza, ciepły papier        |
| paper-light | `#F7F1E3` | Karty, jasny tekst na metalu                      |
| ink         | `#292D28` | Tekst i ważne dane na jasnym tle                  |
| muted       | `#606052` | Podpisy i treści pomocnicze                       |
| metal       | `#242925` | Nagłówek, rama, przyciski                         |
| teal        | `#006B65` | Nagłówki, aktywne elementy, potwierdzenia i fokus |
| rust        | `#9A4D2C` | Drugorzędne wyróżnienia, etykiety sekcji          |
| ochre       | `#C69A4A` | Dekoracja metalowej ramy i pasy ostrzegawcze      |
| danger      | `#A5362C` | Błędy i alarmy, zawsze z tekstem/ikoną            |

Ochra i jasne numery kart mają rolę dekoracyjną; nie przekazują samodzielnie informacji. Nazwy potyczek i komunikaty pozostają ciemne i czytelne. Drobny tekst na grafitowym tle jest jasny, nie ciemnoturkusowy.

## Typografia

- Nagłówki: systemowy `Avenir Next Condensed`, awaryjnie `Arial Narrow`, Impact i sans-serif. Zwarta forma, mocna grubość; uppercase tylko w krótkich etykietach/nagłówkach.
- Tekst użytkowy: systemowy sans-serif, normalna wielkość liter; dłuższe komunikaty nigdy nie korzystają ze stylu szablonowego.
- Numery techniczne i krótkie etykiety: `SFMono-Regular`, Consolas, monospace.
- Brak pobierania fontów z sieci i brak fontów wyciągniętych z podręcznika. Kolejne platformy mogą wymagać dopasowania kroju zastępczego.

## Kompozycja

- Ciemny nagłówek i wąska metalowa rama otaczają jasny obszar danych.
- Subtelna faktura papieru powstaje z własnego filtra SVG; nie jest zdjęciem ani skanem.
- Proste prostokątne karty, cienkie obramowania, niewielkie dekoracyjne nity; bez szklistych efektów i silnych cieni.
- Pasy ochra/grafit wyłącznie jako wąskie separatory. Nie pod tekstem i nie wokół każdego pola.
- Jeden dominujący nagłówek na ekranie. Liczby istotne dla prowadzenia gry mają wysoki kontrast i spokojne tło.
- Puste miejsca i stan inicjalizacji są pełnoprawną częścią projektu. W Etapie 0 karty są tylko do odczytu: brak imitacji przycisków lub aktywnej potyczki.

## Dostępność i przyszłe ekrany

- Tekst użytkowy: docelowo co najmniej 4,5:1; duży tekst i obramowanie fokusu co najmniej 3:1.
- Stanów nie rozróżniamy wyłącznie kolorem. Błędy mają etykietę i ikonę, fokus jest wyraźnie obrysowany.
- Faktura nie może utrudniać odczytu statystyk, tabel, PW ani inicjatywy.
- Obecny ekran adaptuje siatkę do małej szerokości. Późniejsze widoki walki muszą zachować hierarchię danych z `UI_GUIDELINES.md`.
- Te zasady są wspólnym punktem wyjścia dla Etapu 1 i kolejnych. Nie stanowią wdrożenia mechanik ani funkcji tych etapów.

## Spójność produktu i danych

Nazwa okna, aplikacji `.app`, tytuł HTML, pakiet frontendowy, crate Rust i ikona używają NeuroAltar. Techniczny identyfikator `pl.neuroshima.combat-tracker` oraz `sqlite:combat-tracker.db` pozostają stabilne, żeby zmiana marki nie utworzyła użytkownikowi osobnej bazy. Nie zmieniono schematu ani migracji.

## Weryfikacja wersji 0.1.1

- TypeScript, ESLint, Prettier i 31 testów Vitest: poprawne.
- Build macOS Apple Silicon oraz weryfikacja podpisu ad hoc: poprawne.
- Natywne okno NeuroAltar: nazwa, ikona, nowa oprawa i pięć slotów potwierdzone.
- Porównanie rzeczywistej bazy przed i po uruchomieniu nowej wersji: identyczne rekordy i historia migracji; integralność SQLite poprawna.
- Główne kolory tekstu na bazowym papierze spełniają kontrast 4,5:1; numeracja dekoracyjna kart ma oddzielne etykiety z wysokim kontrastem.

## Etap 1 — edytor potyczki

Zachowano papier, turkus, rdzę i ciemny metal. Wybrana zakładka ma turkusowe obramowanie i wypełnienie. Stały numer slotu pozostaje widoczny przy zmianie nazwy. Nazwa i wielowierszowe notatki znajdują się na wspólnej jasnej karcie; stan zapisu ma ikonę i tekst, nie tylko kolor. Nagłówek i zakładki są niższe, aby udostępnić miejsce na edytor.
