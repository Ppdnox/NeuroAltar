## Aktualny zakres 24E — decyzja MG po przeglądzie braków

Teraz: obsługa zdolności i sztuczek w walce oraz wspólne obliczanie rzutów
z karty BG i potyczki. Gracz potwierdza warunki sytuacyjne, cel i efekt;
nie rozstrzygamy automatycznie trafienia ani nie odejmujemy PW po rzucie.

Towarzysze (BG-42) przechodzą do listy pomysłów na przyszłość, bez terminu
realizacji i bez blokowania 24E. Wykreślone z wymagań tego etapu:
automatyczne przerywanie Berserka przez stany, dalsza automatyzacja zacięć
oraz przegrzania, integracja leków z walką i tworzenie pełnej karty ze starego
uproszczonego BG. Przerwanie Berserka śledzi gracz. Zachowane już działające
ręczne funkcje nie są usuwane. Powiązanie z istniejącą kartą BG pozostaje.

Pełny odbiór testowy nastąpi po zakończeniu buildu i dalszych poprawkach,
zgodnie z ustalonym harmonogramem. Bieżące sprawdzenie kompilacji nie stanowi odbioru.
Ta decyzja ma pierwszeństwo przed starszą matrycą kompletności i historycznymi
wymaganiami testów dla każdego podetapu. Stan: [raport 24E](ETAP_24E.md).

# Karta BG — kontrakt trwałości i walki

## Etap 24D — zdrowie, zasoby i postój (0.29.0)

Etap 24D wdrożył niezależny od rozwoju stan zdrowia, zasoby klasowe,
krótkie/długie odpoczynki z podglądem, KW, Zranienia, przyczyny Wyczerpania,
Fuksy, choroby/fobie, leki, żywienie, produkcję, naprawy i czynności postoju.
Raport zakresu i odbioru: [ETAP_24D.md](ETAP_24D.md). Opisy starszych etapów
poniżej pozostają historią; nie wyznaczają aktualnego „następnego etapu”.

Rozstrzygnięcia MG: w pancerzu `min(wydane, floor(maksimum / 2))` osobno dla
k6/k8 (maks6, wydane2 → odzysk2); przerwany długi wymaga czasu krótkiego
właściwego dla Koloru; Rtęć wyłącza wszystkie Fuksy, także początkowe i ze
zdolności. Fabrykator skraca czas produkcji o50%: 6h →3h. Przydasie zmienia
koszt surowców, nie czas. Nie odnawiać zasobów zegarem komputera ani restartem.

`Character.condition` jest poza `sheet` i `draft`; stare karty przyjmują stan
z dotychczasowych PW przy pierwszej jawnej operacji. Od tego momentu bieżące
PW zmienia wyłącznie polecenie zdrowia. Leczenie/produkcja i odpowiadające im
zmiany inwentarza zapisują się wspólnie z historią i trwałym `operationId`.
Migracja013 rozszerza rodzaje poleceń, zachowując karty i istniejącą historię;
migracje001–012 oraz pięć potyczek pozostają nienaruszone.

Etap24E (udział BG w walce, roller, budżet akcji, timery i kontekstowe
Ułatwienia/Utrudnienia) jest w trakcie implementacji i odbioru. Windows pozostaje25. Nie
ogłaszać pełnej automatyzacji karty przed odbiorem24E. Szczególne receptury
wymagają jawnych parametrów i źródła; nie zgadywać ich z nazwy produktu.

Specyfikacja24A, aktualizacja24B, 2026-09-13. **Kontrakt całej karty; 24B–24D wdrożone, integracja walki w 24E nadal planowana.**
W24B migracja011 wdraża Character(sheet/draft) oraz dziennik poleceń, bez udziałów,
inwentarza, efektów i zasobów. Dokładny zapis: DATA_MODEL i ETAP_24B.
Źródła reguł: [KARTA_BG_MECHANIKA.md](KARTA_BG_MECHANIKA.md).
Model zachowuje SQLite jako trwałe źródło danych i Item jako wspólny typ przedmiotu.

## Kontekst zasad postaci

`rulesContext` zawiera `gameColor: none | rust | mercury | steel | chrome`,
revision, sourceFingerprint i jawne odstępstwa MG. Każdy awans zapisuje kontekst
i korektę PW. `changeRulesContext` wymaga podglądu, revision i operationId;
domyślnie wpływa na przyszłe awanse, bez cofania historii lub leczenia.
`ammoMode: tracked | cinematic` wymaga jawnego wyboru; konflikt Chromu opisuje
[KARTA_BG_KOLORY.md](KARTA_BG_KOLORY.md). Pole `TradeContext.color` jest
odrębne. Rozpoczęty odpoczynek zapisuje kontekst i jego wymagany czas.

## Podział odpowiedzialności

`Character` oznacza trwałą postać gracza, niezależną od pięciu slotów.
`CharacterParticipation` oznacza jej udział w konkretnej potyczce.
`EncounterActor` pozostaje istniejącą instancją uczestnika; nie zmieniamy wszystkich
aktorów w Character. Niepowiązany stary BG, własny przeciwnik i kopia Bestiariusza
zachowują obecną semantykę, w tym prepared/runtime i niezależną inicjatywę.

| Dane                                                                          | Właściciel                   | Zasada odczytu/zapisu                                                       |
| ----------------------------------------------------------------------------- | ---------------------------- | --------------------------------------------------------------------------- |
| Tożsamość, poziomy, wybory, cechy bazowe, biegłości                           | Character                    | Obliczenia w obu widokach z tej samej wersji postaci                        |
| Inwentarz, magazynki, amunicja, leki, zasoby klasowe, Fuksy                   | Character                    | Nigdy kopia, którą odtwarza reset potyczki                                  |
| PW, redukcje maksimum, Zranienia, Wyczerpanie, rzuty przeciw śmierci, choroby | Character.vitals/effects     | Jedno źródło prawdy; jawna zmiana z walki zapisuje agregat postaci          |
| Stany długotrwałe i upośledzenia                                              | Character.effects            | Powód i warunek usunięcia, nie anonimowa liczba w slocie                    |
| Inicjatywa, pozycja w kolejce, budżet akcji, wyniki „raz w tej walce”         | Participation                | Niezależne od innych slotów; rzut nie zmienia bazowej premii inicjatywy     |
| Efekty czasowe konkretnej walki                                               | Participation.effects        | Własne ID, źródło i termin; karta pokazuje je jako nakładkę aktywnej walki  |
| Notatka o przygotowaniu, lokalna etykieta, prepared                           | EncounterActor               | Nie jest migawką do cofania trwałej postaci                                 |
| Historia operacji Character, rzutów i walki                                   | Dzienniki z identyfikatorami | Ta sama operacja ma jedno ID i powiązane wpisy, bez podwójnego zastosowania |

Nie kopiować PW/zasobów do dwóch edytowalnych pól. Jeżeli etap przejściowy
potrzebuje cache w istniejącym JSON aktora, oznaczyć go pochodnym, z revision
źródła; nie wolno nim nadpisać Character podczas zapisu starego checkpointa walki.

## Ta sama postać w kilku slotach

Postać można **przypisać do kilku przygotowanych potyczek**, najwyżej raz do
jednego slotu. Wszystkie pokazują jej aktualne trwałe dane. W danej chwili
Character może mieć najwyżej **jeden aktywny udział w prowadzonej walce**.
To ograniczenie projektu zapobiega dwóm niezależnym zegarom tur zużywającym
te same zasoby; nie jest zasadą podręcznika ani zakazem przygotowania kolejnej walki.

Rozpoczęcie innego slotu z tą samą postacią wymaga jawnego zakończenia/przeniesienia
aktywnego udziału i pokazania efektów czasowych do rozliczenia. Samo kliknięcie
zakładki, podgląd karty lub korekta zaznaczenia nie przenosi udziału i nie odnawia
zasobów. Pozostali aktorzy i inne potyczki nie są blokowani globalnie.

Przy zakończeniu/przeniesieniu udziału: efekty wyraźnie „do końca potyczki”
mogą wygasnąć po zatwierdzeniu; te „do opatrzenia/naprawy/odpoczynku” przechodzą
do trwałych efektów; nierozliczone terminy tur wymagają podglądu decyzji,
nie znikają po cichu. Archiwizacja karty również wymaga zamknięcia udziału.

## Kontrakt logiczny agregatu

Każdy obiekt ma UUID; numery poziomów i sztuk są liczbami całkowitymi.
Kwoty/masy/dawki mogą mieć ułamki, z jawną jednostką i kontrolą precyzji.
Poniższa struktura jest kontraktem znaczenia pól; nazwy tabel/kolumn i numer
migracji ustala implementacja dopiero gdy dane są faktycznie używane.

| Grupa            | Minimalne pola i wymagania                                                                                                                                                                                    |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Character        | id, schemaVersion, revision, createdAt, updatedAt, archivedAt; reguły/sourceFingerprint; identity; advancement; vitals; effects; inventory; resources; journal; overrides                                     |
| Identity         | name, opis, lokalny portret, pochodzenie, wielkość, wzrostCm, masaCiałaKg, wiekLat; płeć/opis fabularny jako dobrowolny tekst                                                                                 |
| Advancement      | wyjściowe6cech, metoda tworzenia, historia kolejnych classLevel/wyborów, profesje, zdolności pochodzenia, sztuczki i parametry, PD ledger lub milestones; requirements sprawdzane w chwili wyboru             |
| ProficiencyGrant | rodzaj(skill/save/tool/weapon/armor), targetId, rank, sourceRuleId, levelAcquired; zsumowany odczyt nie niszczy listy źródeł                                                                                  |
| Vitals           | hpCurrent, hpMaxReductionEffects, hitDicePools[{sides,max,spent}], injuryLevel, exhaustionEntries[{cause,level,removal}], deathState/successes/failures; nie odtwarzać tych pól z poziomu ani prepared        |
| Effect           | id, sourceRuleId/sourceInstanceId, operation(add/multiply/replace/limit/advantage/block), target, value/formula, predicate, stackingGroup, duration/removal, active; wartości trwałe oddzielne od warunkowych |
| Resource         | id, sourceRuleId, label, maxFormula, spent, refreshTriggers, costs, turn/round/encounter limit, lastAppliedOperationId; zmiana max nie jest odnowieniem                                                       |
| Disease/Phobia   | id, ruleId, stage, linkedMedicineEntries, dawka/zdarzenia, ostatni rozliczony dzień, kolejne sukcesy, bodziec, przełamanie/termin                                                                             |
| InventoryEntry   | id, itemSnapshot, catalogId/revision opcjonalne, quantity/unit, locationId, equippedSlot, valuation, weightBasis, condition, modifications, createdByCharacterId opcjonalne                                   |
| Location         | id, kind(body/handy/backpack/external), label, parentId opcjonalny, carriedBy; zakaz cyklu i dwojga rodziców; juki domyślnie external                                                                         |
| WeaponInstance   | InventoryEntry z weaponProfile i zweryfikowanym rulesProfile; selectedGrip/fireMode/ammoType, installedMagazineId, loadingState, condition; nie druga biblioteka weapons                                      |
| Magazine         | id, capacity, compatibleAmmoIds, loadedLots[{ammoId,count}], weightEmpty, location/weaponId; suma naboi≤capacity; jeden magazynek nie jest w dwóch broniach                                                   |
| AmmoStock        | liczba sztuk/ładunków związana z InventoryEntry; zapas luźny i załadowany rozłączne; ilość widoczna w wielu sekcjach jest projekcją jednego stanu                                                             |
| Journal          | notatki, znajomi, pierwsze spotkania, obszary, PD entries z ID zdarzenia, receptury/projekty/postęp, historia odpoczynków; dane fabularne nie uruchamiają automatycznych nagród                               |
| Override         | id, pole/reguła, replace/add, wartość, powód MG, zakres/czas, poprzedni wynik do objaśnienia; walidacja nie pomija ograniczeń integralności                                                                   |
| Participation    | id, characterId, encounterId, actorId, revision, state(prepared/active/ended), initiativeResult, actionBudget, encounterUsage, effects; unikalność characterId+encounterId                                    |
| Companion        | id, ownerCharacterId, ruleId, typ, name, profile, vitals, commandPolicy, initiativePolicy; odrębny zapis, nie kolejne poziomy właściciela ani amunicja NPC                                                    |

`derived` (cechy efektywne, modyfikatory, PB, RO, umiejętności, TT, ruch, udźwig,
profile ataków, dostępne zasoby) jest wynikiem czystych funkcji. Kwota zakupu,
bazowa cena katalogowa i bieżąca wycena handlowa są odrębne; zmiana TradeContext
nie przelicza wstecz zapłaconej ceny ani surowców produkcji.

Waga: przechowywać ustaloną jednostkę masy i precyzję, np. całkowite miligramy
lub równoważny typ dziesiętny po obu stronach granicy TS/Rust. Nie sumować
zaokrąglonego do0,01kg naboju kilkaset razy. Paczka z podaną masą całości używa
trybu `aggregate`; decyzja MG Q-07: zestaw startowy to jeden przedmiot
z masą całości i opisem zawartości. Tryb `components` dotyczy tylko innych
pojemników, których zawartość ma wiarygodne masy. Tryby wykluczają się.
Masa paczki dotyczy tylko jej wymienionej zawartości; broń/pancerz przyznane
osobno przez alternatywę sprzętową są odrębnymi przedmiotami. Wyjęcie składnika
z zestawu do osobnej ewidencji wymaga oznaczenia, czy nadal jest objęty masą
zestawu; przy nieznanej masie nie deklarować precyzyjnego ubytku. Pozwala to
używać rzeczy opisanych w zestawie bez podwójnego liczenia ich ciężaru.
Nieznana masa nie blokuje posiadania przedmiotu, ale uniemożliwia deklarowanie
pełnego obciążenia; w wyniku lista brakujących pozycji. Ostrzeżenie prowadzi
bezpośrednio do danego przedmiotu i pola.

Brak kompletnego profilu bojowego w istniejącym Item nie jest zachętą do
zgadywania z nazwy. Dodać jawny, zweryfikowany profil do kopii przedmiotu BG;
zachować źródło podręcznik/strona. Katalog299pozycji i osadzone bronie NPC
pozostają niezależne. Zmiana katalogu nie zmienia samoczynnie posiadanego egzemplarza.

## Polecenia i integralność

Planowane funkcje bez zależności od UI/systemu:
`validateCharacterChoices`, `deriveCharacter`, `deriveCheck`, `deriveArmor`,
`deriveWeapon`, `calculateCarriedWeight`, `calculateEncumbrance`,
`previewResourceUse`, `previewRest`, `previewReload`, `previewLegacyAdoption`.
Losowość jest wejściem lub wstrzykiwanym źródłem; obliczenia deterministyczne.

Zmian dokonują serwisy/repozytoria, walidowane w TS/Zod i Rust. Każde polecenie
otrzymuje `operationId` oraz oczekiwane revision wszystkich zmienianych agregatów.
Jedna transakcja obejmuje nowe wartości, rewizje i wpisy historii.
Ponowienie tego samego operationId zwraca poprzedni wynik; ten sam ID z innym
payloadem jest błędem. Nie wystarczy ostatnie ID na obiekcie — potrzebna trwała
ewidencja obsłużonych poleceń, także przy retry po nowszej operacji.

- `createCharacter` / `advanceCharacter`: atomowy komplet wyborów. Szkic zapisuje
  się osobno jako niekompletny; nie uczestniczy jako gotowa karta w obliczeniach.
- `useResource`: zasób+koszt akcji+efekt+log jednocześnie. Niepowodzenie nie
  zabiera samej akcji ani samego zasobu. Użycie zdolności nie jest jeszcze rzutem.
- `recordShot`: jawne zużycie amunicji; sam rzut i przerzut nie wywołują tego
  polecenia. Pusty magazynek blokuje strzał i pokazuje „Pusty magazynek — przeładuj”.
- `confirmJam`: po zadeklarowanym strzale test zacięcia dotyczy pierwszego
  wystrzału; porażka zużywa akcję, zachowując całą amunicję (decyzja MG Q-08).
  Stan broni, budżet i log zapisują się atomowo; retry nie zabiera kolejnej akcji.
- `reload` / `unload` / `swapMagazine`: transfer kompatybilnych sztuk, nie tworzenie
  amunicji. Oddzielnie napełnienie magazynka, przeładowanie mechanizmu i jego wymiana.
  Koszt A/B/I wynika z broni i konkretnej zdolności.
- `applyRest`: zatwierdzony podgląd z revision, wybrane KW/wyniki, czas w świecie,
  warunki snu, pancerza, chorób i przyczyn Wyczerpania, kwalifikacja pomocy.
  Długi zawiera wszystkie odnowienia krótkiego (Q-05), poza jawną blokadą
  korzyści przez regułę choroby; nie dotyczy nieskończonej amunicji/leków.
  Zmiana danych po podglądzie wymaga ponownego obliczenia. Anulowanie jest neutralne.
- `recordDamage` / `recordHealing` / `applyDeathSave`: istniejąca jawna kontrola MG,
  podgląd skutków i transakcja. Brak automatycznego odejmowania PW po trafieniu.
- `advanceTurn`: tylko normalne przejście tury odnawia budżety i przesuwa terminy
  aktywnego udziału. Odczyt/zaznaczenie aktora/korekta kolejki/restart neutralne.

Konflikt rewizji nie robi „last write wins”: zachować szkic użytkownika, pokazać
różnice, dać ponowienie na aktualnym stanie. Nie rezerwować zasobów na czas
otwartego formularza. Kolejki autozapisu i blokada zamykania obejmują nowe szkice
i błędne zapisy tak jak istniejące formularze; błąd odsyła do konkretnej sekcji/pola.

## Reset, czyszczenie, stary BG

Reset niepowiązanego aktora działa nadal z prepared. Reset **powiązanego** aktora
odtwarza wyłącznie przygotowanie potyczki (kolejność, inicjatywa, lokalne pola).
Nie leczy, nie odnawia KW/zdolności długiego odpoczynku, nie oddaje pocisków.
Zasoby „na walkę” odnawia dopiero jawne rozpoczęcie nowej walki, nie podgląd resetu.
Aktywny udział przed resetem/clear jest rozliczany według powyższej polityki.

Clear nadal wykonuje UPDATE slotu1–5 i usuwa jego lokalną zawartość według
obecnej ścieżki; nie usuwa Character, Companion, jego inwentarza ani historii.
Nie używać DELETE/REPLACE dla pięciu rekordów encounters. Nie zmieniać znaczenia
historycznych prepared snapshotów bez wersji i ścieżki zgodności.

Adopcja starego uproszczonego BG dopiero24E:

1. Na nowej migracji stare rekordy pozostają niepowiązane, działają jak wcześniej.
   Nie dopasowywać po nazwie; „Jan” w dwóch slotach nie dowodzi tej samej osoby.
2. Jawne „Utwórz kartę z BG” albo „Powiąż z istniejącą kartą”. Podgląd: nazwa,
   TT/PW, statusy, przygotowanie i wszystkie rozbieżności ze wskazaną kartą.
3. Nieznane cechy/klasy pozostają brakami. Ręczne TT/PW mogą zostać oznaczonym
   override; nie odtwarzać cech czy poziomu z liczby PW.
4. MG wskazuje, które bieżące dane przyjąć. Dopiero pełna walidacja zapisuje
   Character/link/rewizję/log atomowo. Snapshot starego BG zachowany jako dowód
   konwersji, nie źródło późniejszego automatycznego resetu Character.
5. Odłączenie tworzy jawny niezależny snapshot aktora; nie niszczy karty.
   Błędna adopcja/odłączenie ma bezpieczną ścieżkę odtworzenia poprzedniego linku
   z kontrolą konfliktów, nigdy cofnięcie całej bazy.

## Plan migracji i odbioru

24A: **zero SQL, zero migracji i zero zmian bazy**. W24B wdrożono addytywny schemat011
dla używanych kart/historii poleceń. Kolejne struktury dopiero w podetapie,
który z nich korzysta; nie rezerwować pustych tabel na zapas.
Migracje001–010 pozostają niezmienione, kolejne numery sprawdzać w aktualnym repo.
Przed zmianą zabezpieczyć dane; testy wyłącznie na osobnych bazach.
Nie kasować/reinicjalizować produkcyjnej bazy i nie zmieniać identyfikatora aplikacji.

| ID   | Próba przyszłego odbioru                                | Oczekiwany wynik                                                                               |
| ---- | ------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| P-01 | Stara baza przed nową migracją i ponowny start          | Te same sloty1–5, aktorzy, snapshoty, logi, własny Bestiariusz; brak automatycznej adopcji     |
| P-02 | Dwa widoki edytują tę samą revision                     | Jeden sukces, drugi czytelny konflikt z zachowaniem szkicu; bez cichej utraty danych           |
| P-03 | Awaria zapisu po wyliczeniu kosztu, restart i retry     | Wszystko albo nic; jeden wpis i jedno zużycie                                                  |
| P-04 | operationId X, potem Y, potem retry X                   | Wynik X zwrócony bez nowej mutacji; nie polegać tylko na lastOperationId                       |
| P-05 | Karta w slotach1 i2; reset/clear1                       | Karta, poziom, PW, przedmioty i amunicja zachowane;2 nadal widzi tę samą kartę                 |
| P-06 | Próba drugiego aktywnego udziału                        | Jawny konflikt/przeniesienie; brak podwójnego odnowienia tur i efektów                         |
| P-07 | Niezależny stary BG i przeciwnik po resecie             | Dotychczasowe zachowanie prepared/runtime zachowane                                            |
| P-08 | Rzut, przerzut, obrażenia krytyczne, ręczny wynik       | Same rzuty nie zużywają amunicji/PW; krytyk związany z właściwym aktorem i profilem, użyty raz |
| P-09 | Zamknięcie, ⌘Q, niekompletny formularz, błąd zapisu     | Zapis lub blokada z przejściem do problemu; po poprawce brak martwej blokady                   |
| P-10 | Przeładowanie 10naboi, zapas7, wolne3                   | Można przenieść3: załadowane+3,zapas−3; masa niesiona ta sama; brak ujemnych wartości          |
| P-11 | 24h odpoczynku systemowego komputera                    | Żadne automatyczne odnowienie, zużycie leków ani zmiana dnia kampanii                          |
| P-12 | Adopcja/odłączenie przerwane w połowie                  | Link, karta i aktor albo kompletne, albo bez zmian; stare dane możliwe do porównania           |
| P-13 | Zmiana KON/profesji/przedmiotu po podglądzie odpoczynku | Stary podgląd odrzucony; nowe wyniki i koszty do ponownego zatwierdzenia                       |
| P-14 | Długi tekst, polskie znaki, wąskie okno, powiększenie   | Sekcje zgodne z PDF, czytelne, klawiatura i etykiety; brak poziomego obcinania pól             |

Każdy etap implementacyjny: pełne `pnpm check`, testy Rust, format Rust,
`pnpm build:macos` i natywne próby odpowiednie do zmiany. Dla samej specyfikacji:
spójność, odsyłacze, format i `git diff --check`; bez sztucznego nowego buildu.

## Realizacja24C

Wdrożony inventory jest osobnym polem korzenia Character, poza sheet/draft.
Szczegóły: DATA_MODEL „Schemat wdrożony w24C”, raport ETAP_24C.
Wyposażenie startowe: jednorazowy przycisk plecaka z masą agregatu. Broń,
pancerz i narzędzia z wybranej alternatywy klasy dodaje MG oddzielnie.
RecordShot w24C jawnie zużywa naboje; połączenie z Participation/actionBudget,
jam i efektami rundy pozostaje24E. Na zacięciu należy anulować zapis strzału.
Chrom: nieliczony zapas i jawny stan loaded; naturalna1/powrót loaded nie
modyfikują zachowanych dokładnych ilości. Automatyczne powiązanie z rollerem24E.

## Doprecyzowanie MG — Etap 24D, 2026-09-20

Początkową chorobę wybiera się bezpośrednio z listy albo wybiera „Nie wybieram — −1 do cechy”. Bez formularza wyników k8; analogicznie wybór fobii. Jednorazowość premii/kary i dawek pozostaje. Leki bez masy w podręczniku mają 0 kg także na istniejących kartach; jawnej masy MG nie nadpisujemy. Fabrykator: czas −50% (6 h → 3 h).
