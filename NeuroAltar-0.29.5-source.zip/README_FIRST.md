# NeuroAltar — od tego zacznij

Aktualna baza to **24E Roboczy / 0.29.5**. Kontynuujemy ten build i jego
zaakceptowany interfejs; nie wracamy do dawnych paczek ani Etapu 24D.

1. [STATUS](docs/STATUS.md) — co działa, co pozostaje ręczne i czego jeszcze nie odebrano.
2. [Plan](docs/PLAN_DALSZYCH_PRAC.md) — najbliższa praca i odłożone pomysły.
3. [Przekazanie na Windows](docs/PRZEKAZANIE_WINDOWS_2026-11-09.md) — paczka, instrukcje dla Codexa, build i odbiór.
4. [README](README.md) — uruchamianie, kontrole i raporty.
5. [AGENTS](AGENTS.md) — zasady zmian w repozytorium i ochrony danych.

Decyzja 2026-11-08: Truciciel i Pogromca mają opisy; produkcję oblicza i zapisuje
gracz. Nie dodajemy automatów produkcji ani osobnych liczników tych receptur.

Przygotowanie Windows nie oznacza końcowego odbioru 24E ani gotowego instalatora.
Dotychczasowe wyniki macOS nie potwierdzają działania na Windows.
Raporty historyczne zachowano. Poprzednią wersję tego pliku można odczytać przez
`git show 1aeab92:README_FIRST.md`.
