import { createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

if (process.platform !== 'darwin') {
  throw new Error('Build macOS wymaga komputera Mac.');
}

const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const projectId = createHash('sha256')
  .update(project)
  .digest('hex')
  .slice(0, 12);
// File providers can attach FinderInfo to .app bundles on Desktop/Documents,
// preventing codesign. Keep generated macOS bundles in a local temporary folder.
const target = process.env.CARGO_TARGET_DIR
  ? resolve(project, process.env.CARGO_TARGET_DIR)
  : join(tmpdir(), 'neuroshima-combat-tracker', projectId, 'target');

console.log(`Katalog buildu macOS: ${target}`);
const result = spawnSync(
  'pnpm',
  ['exec', 'tauri', 'build', '--bundles', 'app'],
  {
    cwd: project,
    env: { ...process.env, CARGO_TARGET_DIR: target },
    stdio: 'inherit',
  },
);
if (result.error) throw result.error;
process.exitCode = result.status ?? 1;
