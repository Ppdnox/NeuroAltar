import { expect, it } from 'vitest';
import {
  newEnemyTemplateDraft,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { emptyLoadoutDraft, newWeaponDraft } from '../src/domain/itemDraft';
import { emptyCapabilityDraft } from '../src/domain/capabilitySchema';
import { validationIssues } from '../src/domain/validation';
import { createBestiaryStore } from '../src/stores/bestiaryStore';
const id = '00000000-0000-4000-8000-000000000001';
it('reports all invalid top-level fields instead of a generic checklist', () => {
  const d = {
    ...newEnemyTemplateDraft(),
    name: 'Gangus',
    tt: '12',
    hpMax: '',
    sp: '2,',
    speedsText: 'Chód dziewięć',
    cowardicePercent: '101',
  };
  try {
    parseEnemyTemplateDraft(d, id);
    throw new Error('Expected invalid draft');
  } catch (e) {
    const issues = validationIssues(e);
    expect(issues.map((i) => i.path)).toEqual(
      expect.arrayContaining(['hpMax', 'sp', 'speeds', 'cowardicePercent']),
    );
    expect(issues.some((i) => i.path === 'name')).toBe(false);
    expect(issues.find((i) => i.path === 'cowardicePercent')!.message).toBe(
      'Maksimum: 100.',
    );
  }
});
it('retains exact weapon, formula and ability indices including cross-field costs', () => {
  const d = {
    ...newEnemyTemplateDraft(),
    name: 'Gangus',
    tt: '12',
    hpMax: '20',
    loadout: emptyLoadoutDraft(),
    capabilities: emptyCapabilityDraft(),
  };
  d.loadout.items = [newWeaponDraft(), newWeaponDraft()];
  d.capabilities.abilities = [
    {
      id: crypto.randomUUID(),
      name: 'Seria',
      description: '',
      kind: 'legendary',
      legendaryCost: '2',
      resourceId: '',
      resourceCost: '1',
    },
  ];
  try {
    parseEnemyTemplateDraft(d, id);
    throw new Error('Expected invalid draft');
  } catch (e) {
    const issues = validationIssues(e);
    expect(issues.map((i) => i.path)).toEqual(
      expect.arrayContaining([
        'loadout.items.0.item.name',
        'loadout.items.1.item.weaponProfile.damageModes.0.dice',
        'capabilities.abilities.0.legendaryCost',
      ]),
    );
    expect(
      issues.find((i) => i.path.endsWith('legendaryCost'))!.message,
    ).toContain('przekracza pulę Legendarnych 0');
    expect(
      issues.find(
        (i) =>
          i.path === 'loadout.items.1.item.weaponProfile.damageModes.0.dice',
      )!.label,
    ).toContain('Przedmiot → 2');
  }
});
it('keeps an invalid catalog draft, identifies its field and saves only the corrected template', async () => {
  const saved: unknown[] = [];
  const store = createBestiaryStore(
    async () => [],
    async (m) => {
      saved.push(m);
      return 1;
    },
  );
  store.getState().open();
  store.getState().edit({
    ...newEnemyTemplateDraft(),
    name: 'Gangus',
    tt: '12',
    hpMax: '20',
    sp: '-1',
  });
  await store.getState().submit();
  expect(saved).toHaveLength(0);
  expect(store.getState().error).toContain('SP:');
  expect(store.getState().form!.fields.sp).toBe('-1');
  store.getState().edit({ sp: '2,5' });
  await store.getState().submit();
  expect(saved).toHaveLength(1);
  expect(store.getState().form).toBeNull();
});
