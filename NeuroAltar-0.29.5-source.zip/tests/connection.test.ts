import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  isTauri: vi.fn(),
  load: vi.fn(),
  invoke: vi.fn(),
}));
vi.mock('@tauri-apps/api/core', () => ({
  isTauri: mocks.isTauri,
  invoke: mocks.invoke,
}));
vi.mock('@tauri-apps/plugin-sql', () => ({ default: { load: mocks.load } }));

beforeEach(() => {
  vi.resetModules();
  vi.resetAllMocks();
});

describe('desktop database adapter', () => {
  it('reports browser mode without fabricating a database', async () => {
    mocks.isTauri.mockReturnValue(false);
    const { openDatabase } = await import('../src/db/connection');
    await expect(openDatabase()).rejects.toThrow('desktopowej');
    expect(mocks.load).not.toHaveBeenCalled();
  });
  it('shares one connection and forwards queries', async () => {
    mocks.isTauri.mockReturnValue(true);
    const select = vi.fn().mockResolvedValue([]);
    mocks.load.mockResolvedValue({ select });
    const { openDatabase, DATABASE_URL } = await import('../src/db/connection');
    const [first, second] = await Promise.all([openDatabase(), openDatabase()]);
    expect(first).toBe(second);
    expect(mocks.load).toHaveBeenCalledExactlyOnceWith(DATABASE_URL);
    await first.selectRows('SELECT id FROM encounters');
    expect(select).toHaveBeenCalledWith('SELECT id FROM encounters', undefined);
  });
  it('can reopen after a failed load', async () => {
    mocks.isTauri.mockReturnValue(true);
    mocks.load
      .mockRejectedValueOnce(new Error('Cannot migrate'))
      .mockResolvedValueOnce({ select: vi.fn() });
    const { openDatabase } = await import('../src/db/connection');
    await expect(openDatabase()).rejects.toThrow('Cannot migrate');
    await expect(openDatabase()).resolves.toBeDefined();
    expect(mocks.load).toHaveBeenCalledTimes(2);
  });
});

it('blocks repository exposure until seed succeeds and permits an exact retry after failure', async () => {
  mocks.isTauri.mockReturnValue(true);
  mocks.load.mockResolvedValue({ select: vi.fn() });
  mocks.invoke
    .mockRejectedValueOnce(new Error('seed disk failure'))
    .mockResolvedValueOnce(undefined);
  const { openDatabase } = await import('../src/db/connection');
  await expect(openDatabase()).rejects.toThrow('seed disk failure');
  await expect(openDatabase()).resolves.toBeDefined();
  expect(mocks.invoke).toHaveBeenCalledTimes(3);
  expect(mocks.invoke).toHaveBeenCalledWith('seed_bestiary');
});

it('waits for equipment seed and retries startup without exposing a half-ready database', async () => {
  mocks.isTauri.mockReturnValue(true);
  mocks.load.mockResolvedValue({ select: vi.fn() });
  let fail = true;
  mocks.invoke.mockImplementation(async (name: string) => {
    if (name === 'seed_equipment' && fail) {
      fail = false;
      throw new Error('equipment seed failure');
    }
  });
  const { openDatabase } = await import('../src/db/connection');
  await expect(openDatabase()).rejects.toThrow('equipment seed failure');
  await expect(openDatabase()).resolves.toBeDefined();
  expect(mocks.invoke.mock.calls.map((call) => call[0])).toEqual([
    'seed_bestiary',
    'seed_equipment',
    'seed_bestiary',
    'seed_equipment',
  ]);
});
