import { expect, it } from 'vitest';
import {
  calculateEncounterDifficulty as calculate,
  difficultyLabel,
  parsePartyLevels,
  parseSP,
} from '../src/domain/difficulty';
import {
  instantiateEnemy,
  parseActorDraft,
  toActorDraft,
  prepareCombat,
  resetEncounter,
  type Combat,
} from '../src/domain/combat';
import {
  parseEnemyTemplateDraft,
  type EnemyTemplate,
} from '../src/domain/enemy';
import { templateDraft } from '../src/domain/bestiary';
const template: EnemyTemplate = {
  id: crypto.randomUUID(),
  name: 'Żmija',
  category: 'beast',
  size: 'Mały',
  tt: 12,
  hpMax: 20,
  speeds: [],
  sp: 8,
};
it('calculates exact reference points and a continuous marker beyond and between them', () => {
  for (const [sp, ratio, percent, label] of [
    [16, 1, 100, 'Łatwa'],
    [24, 1.5, 150, 'Wyczerpująca'],
    [32, 2, 200, 'Ryzykowna'],
    [48, 3, 300, 'Zabójcza'],
    [64, 4, 400, 'Zabójcza'],
  ] as const) {
    expect(calculate([4, 4, 4, 4], [{ sp }])).toMatchObject({
      sd: 16,
      sp,
      ratio,
      percent,
      label,
      markerPercent: Math.min(percent / 3, 100),
    });
  }
  expect(calculate([4, 4, 4, 4], [{ sp: 20.1 }]).percent).toBeCloseTo(125.625);
  expect(calculate([4, 4, 4, 4], [{ sp: 20.1 }]).markerPercent).toBeCloseTo(
    41.875,
  );
});
it('uses the requested intermediate ranges with exact starts at 126, 176 and 251 percent', () => {
  for (const n of [0, 99, 100, 101, 125, 125.999])
    expect(difficultyLabel(n)).toBe('Łatwa');
  for (const n of [126, 149, 150, 151, 175, 175.999])
    expect(difficultyLabel(n)).toBe('Wyczerpująca');
  for (const n of [176, 199, 200, 201, 250, 250.999])
    expect(difficultyLabel(n)).toBe('Ryzykowna');
  for (const n of [251, 299, 300, 999])
    expect(difficultyLabel(n)).toBe('Zabójcza');
});
it('distinguishes unknown SP from zero, and handles an empty party/roster without NaN or Infinity', () => {
  expect(calculate([], [])).toMatchObject({
    sd: 0,
    sp: 0,
    ratio: null,
    percent: null,
    markerPercent: null,
    label: null,
  });
  expect(calculate([4], [])).toMatchObject({ sp: 0, ratio: 0, percent: 0 });
  expect(calculate([4], [{ sp: 0 }])).toMatchObject({ sp: 0, missingSP: 0 });
  expect(calculate([4], [{ sp: 8 }, {}, { sp: null }])).toMatchObject({
    sp: null,
    knownSP: 8,
    missingSP: 2,
    ratio: null,
    markerPercent: null,
  });
});
it('accepts Polish input and rejects malformed, negative, infinite and unsafe numbers', () => {
  expect(parsePartyLevels('4\n 5;6, 7')).toEqual([4, 5, 6, 7]);
  expect(parsePartyLevels('  ')).toEqual([]);
  expect(parseSP('2,5')).toBe(2.5);
  expect(parseSP('')).toBeNull();
  expect(parseSP('0')).toBe(0);
  for (const s of [
    '-1',
    'NaN',
    'Infinity',
    '1e2',
    '1/2',
    '2,',
    '9007199254740992',
  ])
    expect(() => parseSP(s)).toThrow();
  for (const s of ['0', '-1', '1.5', 'dwa', '9007199254740992'])
    expect(() => parsePartyLevels(s)).toThrow();
  expect(() => calculate([Number.MAX_SAFE_INTEGER, 1], [])).toThrow();
  expect(() =>
    calculate([1], [{ sp: Number.MAX_SAFE_INTEGER }, { sp: 1 }]),
  ).toThrow();
});
it('keeps catalog, prepared, siblings and runtime SP independent including zero HP', () => {
  const a = instantiateEnemy(template, 0),
    b = instantiateEnemy(template, 1);
  const raw = toActorDraft(a);
  raw.spText = '16';
  raw.hpCurrent = '0';
  const changed = parseActorDraft(raw);
  const c: Combat = {
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [changed, b],
  };
  expect(
    calculate(
      [4, 4, 4, 4],
      c.actors.map((a) => a.enemy!),
    ).sp,
  ).toBe(24);
  expect(a.enemy!.sp).toBe(8);
  expect(changed.prepared!.enemy!.sp).toBe(8);
  expect(template.sp).toBe(8);
  expect(resetEncounter(c).actors[0]!.enemy!.sp).toBe(8);
  expect(resetEncounter(prepareCombat(c)).actors[0]!.enemy!.sp).toBe(16);
  expect(parseEnemyTemplateDraft(templateDraft(template), template.id).sp).toBe(
    8,
  );
  const legacy = { ...template };
  delete legacy.sp;
  expect(
    parseActorDraft(toActorDraft(instantiateEnemy(legacy, 0))).enemy,
  ).not.toHaveProperty('sp');
  raw.spText = '';
  expect(parseActorDraft(raw).enemy!.sp).toBeNull();
});
