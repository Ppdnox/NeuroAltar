import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { migrate, repositoryFor } from './helpers/database';

describe('initial SQLite migration', () => {
  let database: DatabaseSync;
  beforeEach(() => {
    database = new DatabaseSync(':memory:');
    migrate(database);
  });
  afterEach(() => database.close());

  it('creates exactly five valid, empty slots numbered 1–5', async () => {
    const slots = await repositoryFor(database).listSlots();
    expect(slots.map(({ id }) => id)).toEqual([1, 2, 3, 4, 5]);
    for (const slot of slots) {
      expect(slot.name).toBe(`Potyczka ${slot.id}`);
      expect(slot).toMatchObject({
        notes: '',
        roundNumber: 1,
        currentTurnActorId: null,
        partyLevels: [],
      });
    }
  });

  it.each([0, 6, -1, 1.5])('rejects an invalid slot ID: %s', (id) => {
    expect(() =>
      database
        .prepare('INSERT INTO encounters (id, name) VALUES (?, ?)')
        .run(id, 'Extra'),
    ).toThrow();
    expect(
      database.prepare('SELECT count(*) AS count FROM encounters').get()?.count,
    ).toBe(5);
  });

  it.each([
    'DELETE FROM encounters WHERE id = 1',
    'DELETE FROM encounters',
    'UPDATE encounters SET id = 6 WHERE id = 1',
    "INSERT INTO encounters (id, name) VALUES (1, 'Duplicate')",
    "INSERT OR REPLACE INTO encounters (id, name) VALUES (1, 'Replacement')",
    'UPDATE OR REPLACE encounters SET id = 2 WHERE id = 1',
  ])('preserves the fixed slots against %s', (sql) => {
    expect(() => database.exec(sql)).toThrow();
    expect(
      database
        .prepare('SELECT id FROM encounters ORDER BY id')
        .all()
        .map((row) => row.id),
    ).toEqual([1, 2, 3, 4, 5]);
    expect(
      database.prepare('SELECT name FROM encounters WHERE id = 1').get()?.name,
    ).toBe('Potyczka 1');
  });

  it.each([
    "UPDATE encounters SET name = '   ' WHERE id = 1",
    'UPDATE encounters SET round_number = 0 WHERE id = 1',
    'UPDATE encounters SET round_number = 1.5 WHERE id = 1',
    `UPDATE encounters SET party_levels_json = '{}' WHERE id = 1`,
    "UPDATE encounters SET party_levels_json = 'invalid' WHERE id = 1",
  ])('rejects invalid stored fields: %s', (sql) => {
    expect(() => database.exec(sql)).toThrow();
  });

  it('does not duplicate or reset existing data when SQL is reapplied', async () => {
    database.exec(
      "UPDATE encounters SET name = 'Zasadzka', notes = 'Zachowaj', round_number = 3 WHERE id = 2",
    );
    migrate(database);
    const slots = await repositoryFor(database).listSlots();
    expect(slots).toHaveLength(5);
    expect(slots[1]).toMatchObject({
      name: 'Zasadzka',
      notes: 'Zachowaj',
      roundNumber: 3,
    });
  });

  it('keeps data independent and durable across closing and reopening a file', async () => {
    const directory = mkdtempSync(join(tmpdir(), 'combat-tracker-'));
    const file = join(directory, 'test.db');
    let disk: DatabaseSync | undefined;
    try {
      disk = new DatabaseSync(file);
      migrate(disk);
      for (let id = 1; id <= 5; id++) {
        disk
          .prepare(
            'UPDATE encounters SET notes = ?, party_levels_json = ? WHERE id = ?',
          )
          .run(`Slot ${id}`, JSON.stringify([id]), id);
      }
      const before = await repositoryFor(disk).listSlots();
      disk.close();
      disk = undefined;
      disk = new DatabaseSync(file);
      migrate(disk);
      expect(await repositoryFor(disk).listSlots()).toEqual(before);
      expect(before.map((slot) => slot.notes)).toEqual([
        'Slot 1',
        'Slot 2',
        'Slot 3',
        'Slot 4',
        'Slot 5',
      ]);
    } finally {
      disk?.close();
      rmSync(directory, { recursive: true, force: true });
    }
  });
});
