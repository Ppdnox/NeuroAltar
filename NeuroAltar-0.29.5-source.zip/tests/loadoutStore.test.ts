import { expect, it } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import { instantiateEnemy, parseCombatDraft } from '../src/domain/combat';
import { newWeaponDraft, parseLoadoutDraft } from '../src/domain/itemDraft';
function fixture() {
  const e = newWeaponDraft();
  e.name = 'Karabin';
  e.profile!.damageModes[0]!.dice = '2k8';
  e.profile!.damageModes[0]!.damageType = 'kłute';
  return parseLoadoutDraft({
    pb: '4',
    strModifier: '2',
    dexModifier: '5',
    items: [e],
  });
}
it('retains invalid weapon input, reveals its actor on close, then autosaves and resets an independent loadout', async () => {
  const template = {
    id: crypto.randomUUID(),
    name: 'Strzelec',
    category: 'human' as const,
    size: 'Średni',
    tt: 15,
    hpMax: 88,
    speeds: [],
    loadout: fixture(),
  };
  const a = instantiateEnemy(template, 0);
  let saved: unknown;
  const store = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 1,
        currentTurnActorId: null,
        actors: encounterId === 4 ? [a] : [],
      })),
    async (c) => {
      saved = structuredClone(c);
      return c.revision + 1;
    },
  );
  await store.getState().initialize();
  store.getState().openLoadoutForm(4, a.id);
  const fields = structuredClone(store.getState().loadoutForm!.fields);
  fields.items[0]!.profile!.damageModes[0]!.dice = '';
  store.getState().editLoadoutForm(fields);
  store.getState().submitLoadoutForm();
  expect(await store.getState().prepareClose()).toBe(false);
  expect(
    store.getState().loadoutForm?.fields.items[0]?.profile?.damageModes[0]
      ?.dice,
  ).toBe('');
  fields.items[0]!.profile!.damageModes[0]!.dice = '3k8';
  fields.items[0]!.name = 'Podmieniona';
  store.getState().editLoadoutForm(fields);
  store.getState().submitLoadoutForm();
  await store.getState().flush(4);
  expect(saved).toBeDefined();
  expect(store.getState().loadoutForm).toBeNull();
  const c = parseCombatDraft(
    store.getState().drafts[4]!.value,
    store.getState().slots.find((c) => c.encounterId === 4)!,
  );
  expect(c.actors[0]?.enemy?.loadout?.items[0]?.item.name).toBe('Podmieniona');
  expect(c.actors[0]?.enemy?.template.loadout?.items[0]?.item.name).toBe(
    'Karabin',
  );
  store.getState().resetEncounter(4);
  await store.getState().flush(4);
  expect(
    store.getState().slots.find((c) => c.encounterId === 4)?.actors[0]?.enemy
      ?.loadout?.items[0]?.item.name,
  ).toBe('Karabin');
  expect(await store.getState().prepareClose()).toBe(true);
});
