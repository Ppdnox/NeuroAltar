import { describe, expect, it } from 'vitest';
import { classes, professions } from '../src/domain/character/catalog';
import { deriveCharacter } from '../src/domain/character/derive';
import { CLASSES, type ClassId } from '../src/domain/character/model';
import {
  classRuleDescriptions,
  describeCharacterRule,
  professionRuleDescriptions,
} from '../src/domain/character/ruleDescriptions';
import { complete, fixture } from './helpers/character';

const placeholder =
  /Zdolność (klasy|profesji z podręcznika)|pozostałe warunki sprawdź|zgodnie z opisem w podręczniku|Dostępne pule użyć/;

describe('handbook class and profession descriptions', () => {
  it('covers every catalog rule ID, including every profession option', () => {
    const classIds = CLASSES.flatMap((id) =>
      Object.entries(classes[id].progression).flatMap(([level, labels]) =>
        labels.map((_, index) => `class.${id}.${level}.${index}`),
      ),
    );
    const professionIds = Object.entries(professions).flatMap(([id, p]) =>
      p.abilities.map((_, index) => `profession.${id}.${index}`),
    );
    expect(Object.keys(classRuleDescriptions).sort()).toEqual(classIds.sort());
    expect(Object.keys(professionRuleDescriptions).sort()).toEqual(
      professionIds.sort(),
    );
  });

  it.each(CLASSES)(
    'renders meaningful descriptions at all levels of %s',
    (id) => {
      for (let level = 1; level <= 12; level++) {
        const d = deriveCharacter(complete(fixture(id, level)));
        expect(d.issues).toEqual([]);
        for (const rule of d.rules.filter((r) =>
          /^(class|profession)\./.test(r.id),
        )) {
          expect(rule.summary, rule.id).not.toMatch(placeholder);
          expect(rule.summary.length, rule.id).toBeGreaterThan(50);
          expect(rule.summary, rule.id).not.toMatch(/undefined|NaN/);
          expect(rule.page, rule.id).toBeGreaterThanOrEqual(67);
          expect(rule.page, rule.id).toBeLessThanOrEqual(101);
        }
      }
    },
  );

  it('renders every acquired profession ability, not only the default first option', () => {
    for (const classId of CLASSES) {
      for (const profession of classes[classId].professions) {
        for (const index of professions[profession]!.abilities.keys()) {
          const s = fixture(classId, 3);
          s.levels[2]!.choices.profession = [profession];
          s.levels[2]!.choices['profession-ability'] = [
            `${profession}.${index}`,
          ];
          const d = deriveCharacter(complete(s));
          expect(d.issues).toEqual([]);
          const rule = d.rules.find(
            (r) => r.id === `profession.${profession}.${index}`,
          );
          expect(rule?.summary.length).toBeGreaterThan(50);
          expect(rule?.summary).not.toMatch(placeholder);
        }
      }
    }
  });

  it.each([
    ['brutal', 1, 'class.brutal.1.0', '+1k6', '2 użyć'],
    ['brutal', 4, 'class.brutal.1.0', '+1k8', '3 użyć'],
    ['brutal', 7, 'class.brutal.1.0', '+1k10', '4 użyć'],
    ['brutal', 12, 'class.brutal.1.0', '+1k12', '5 użyć'],
    ['cwaniak', 5, 'class.cwaniak.1.0', '1k8', '18 m'],
    ['cwaniak', 9, 'class.cwaniak.2.0', '1k8', 'każdą wydaną'],
    ['spec', 2, 'class.spec.2.0', '1k4', 'PB'],
    ['spec', 8, 'class.spec.2.0', '1k10', 'PB'],
    ['spec', 11, 'class.spec.3.0', 'do 50 G', '1 minutę'],
    ['twardziel', 12, 'class.twardziel.3.0', 'k10', 'Przeciw Śmierci'],
    ['zlodziej', 11, 'class.zlodziej.1.1', '6k6', 'Raz na turę'],
    ['zlodziej', 11, 'class.zlodziej.2.1', 'k10', 'modyfikatorowi Zręczności'],
    ['zwiadowca', 9, 'class.zwiadowca.1.0', '+3 do Testu Ataku', '+3k6'],
  ] as const)(
    'uses current %s level %i in %s',
    (id, level, ruleId, expected, other) => {
      const d = deriveCharacter(complete(fixture(id, level)));
      const summary = d.rules.find((r) => r.id === ruleId)?.summary;
      expect(summary).toContain(expected);
      expect(summary).toContain(other);
    },
  );

  it('scales a learned ability by its class level, not total level or acquisition level', () => {
    const s = fixture('brutal', 7);
    s.levels.slice(3).forEach((entry) => (entry.classId = 'spec'));
    const d = deriveCharacter(complete(s));
    expect(d.classLevels).toMatchObject({ brutal: 3, spec: 4 });
    expect(d.rules.find((r) => r.id === 'class.brutal.1.0')?.summary).toContain(
      '+1k6',
    );
    expect(d.rules.find((r) => r.id === 'class.spec.2.0')?.summary).toContain(
      '1k6',
    );
  });

  it('keeps rulings, conditional bonuses and healing upgrades explicit', () => {
    const levels = Object.fromEntries(CLASSES.map((id) => [id, 12])) as Record<
      ClassId,
      number
    >;
    expect(describeCharacterRule('class.cwaniak.9.0', levels)).toContain(
      '9. poziomie',
    );
    expect(describeCharacterRule('class.zlodziej.11.0', levels)).toContain(
      'Jedno użycie',
    );
    expect(describeCharacterRule('class.cwaniak.11.0', levels)).toContain(
      'wynikowi jednej kości k6 pomnożonemu',
    );
    expect(describeCharacterRule('profession.medic.1', levels)).toContain(
      'kością k12',
    );
    expect(describeCharacterRule('class.zwiadowca.1.0', levels)).toContain(
      'tylko po rozpoznaniu właściwego typu celu',
    );
    expect(describeCharacterRule('class.zwiadowca.1.1', levels)).toContain(
      'wymagają właściwego biomu',
    );
    expect(describeCharacterRule('origin.asgard.new', levels)).toBeUndefined();
  });
});

describe('Wyjadacz multiclass identity', () => {
  it.each([
    ['twardziel', 'zwiadowca', 'zwiadowca'],
    ['zwiadowca', 'zwiadowca', 'twardziel'],
  ] as const)(
    'does not offer or accept the same style twice in %s/%s/%s',
    (...order) => {
      const s = fixture(order[0], 3);
      s.levels.forEach((entry, i) => (entry.classId = order[i]!));
      complete(s);
      const firstStyleLevel = order[0] === 'twardziel' ? 0 : 1;
      expect(s.levels[firstStyleLevel]!.choices.veteran).toEqual(['armor']);
      expect(deriveCharacter(s).issues).toEqual([]);
      s.levels[2]!.choices.veteran = ['armor'];
      const d = deriveCharacter(s);
      expect(d.issues.some((issue) => issue.path === 'level-2-veteran')).toBe(
        true,
      );
      expect(
        d.choices
          .find((choice) => choice.level === 2 && choice.key === 'veteran')
          ?.options.some((option) => option.id === 'armor'),
      ).toBe(false);
      // Existing saved choices remain untouched and can be corrected explicitly.
      expect(s.levels[2]!.choices.veteran).toEqual(['armor']);
      s.levels[2]!.choices.veteran = ['eye'];
      expect(deriveCharacter(s).issues).toEqual([]);
    },
  );
});
