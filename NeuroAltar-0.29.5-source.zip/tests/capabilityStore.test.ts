import { expect, it, vi } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { createEncounterStore } from '../src/stores/encounterStore';
import { prepareAppClose } from '../src/services/prepareAppClose';
import { SLOT_IDS } from '../src/domain/encounter';
import type { Combat } from '../src/domain/combat';
import { capabilities } from '../src/domain/capabilities';
it('retains form across slots and Cmd+Q, queues spend/restore despite failure, and reloads/reset without refreshing counters', async () => {
  let data: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [],
  }));
  const load = async () => structuredClone(data);
  const save = vi.fn(async (c: Combat) => {
    data = data.map((v) =>
      v.encounterId === c.encounterId
        ? structuredClone({ ...c, revision: c.revision + 1 })
        : v,
    );
    return c.revision + 1;
  });
  const store = createCombatStore(load, save);
  await store.getState().initialize();
  store.getState().addEnemy(4, {
    id: '00000000-0000-4000-8000-000000000099',
    name: 'Żuk',
    category: 'machine',
    size: 'Duży',
    tt: 15,
    hpMax: 20,
    speeds: [],
  });
  await store.getState().flush(4);
  const id = store.getState().slots[3]!.actors[0]!.id;
  store.getState().editActor(4, id, { initiativeValue: '12' });
  await store.getState().flush(4);
  store.getState().openCapabilityForm(4, id);
  const d = structuredClone(store.getState().capabilityForm!.fields);
  d.resources.push({
    id: '00000000-0000-4000-8000-000000000001',
    name: 'Impuls',
    maxValue: '',
    currentValue: '2',
    refreshRule: 'round',
  });
  store.getState().editCapabilityForm(d);
  store.getState().submitCapabilityForm();
  expect(store.getState().capabilityForm!.error).toBeTruthy();
  const encounters = createEncounterStore();
  encounters.getState().prepareClose = vi.fn(async () => true);
  expect(await prepareAppClose(encounters, store)).toBe(false);
  expect(encounters.getState().activeId).toBe(4);
  d.resources[0]!.maxValue = '3';
  store.getState().editCapabilityForm(d);
  store.getState().submitCapabilityForm();
  await store.getState().flush(4);
  expect(store.getState().capabilityForm).toBeNull();
  store.getState().prepareEncounter(4);
  await store.getState().flush(4);
  save.mockRejectedValueOnce(new Error('disk'));
  store.getState().useCapability(4, id, 'reaction');
  await store.getState().flush(4);
  expect(store.getState().drafts[4]!.status).toBe('error');
  await store.getState().flush(4);
  store.getState().restoreBudget(4, id, 'reaction');
  store.getState().useCapability(4, id, 'reaction');
  await store.getState().flush(4);
  expect(
    capabilities(store.getState().slots[3]!.actors[0]!).budget.reaction,
  ).toBe(0);
  const restarted = createCombatStore(load, save);
  await restarted.getState().initialize();
  expect(
    capabilities(restarted.getState().slots[3]!.actors[0]!).budget.reaction,
  ).toBe(0);
  restarted.getState().setCurrent(4, id);
  await restarted.getState().flush(4);
  expect(
    capabilities(restarted.getState().slots[3]!.actors[0]!).budget.reaction,
  ).toBe(0);
  restarted.getState().resetEncounter(4);
  await restarted.getState().flush(4);
  expect(
    capabilities(restarted.getState().slots[3]!.actors[0]!).resources[0]!
      .currentValue,
  ).toBe(2);
  expect(
    capabilities(restarted.getState().slots[3]!.actors[0]!).budget.reaction,
  ).toBe(1);
  expect(restarted.getState().slots[0]!.actors).toEqual([]);
  expect(await restarted.getState().prepareClose()).toBe(true);
});
