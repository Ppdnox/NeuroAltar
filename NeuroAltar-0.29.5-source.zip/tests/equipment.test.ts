import { describe, expect, it, vi } from 'vitest';
import { itemSchema } from '../src/domain/item';
import { filterEquipment, equipmentWeight } from '../src/domain/equipment';
import {
  BASE_TRADE_CONTEXT,
  calculateMarketValues,
  marketRulesSchema,
} from '../src/domain/market';
import { createEquipmentRepository } from '../src/db/equipmentRepository';
import { createEquipmentStore } from '../src/stores/equipmentStore';
import catalog from '../src/data/equipment/catalog.v1.json';
import rawRules from '../src/data/equipment/market-rules.v1.json';
const items = catalog.entries.map((i) => itemSchema.parse(i));
const rules = marketRulesSchema.parse(rawRules);
describe('equipment source catalog', () => {
  it('covers 299 unique source rows and all eight types with valid Item metadata', () => {
    expect(items).toHaveLength(299);
    expect(new Set(items.map((i) => i.id)).size).toBe(299);
    expect(new Set(items.map((i) => i.type)).size).toBe(8);
    for (const [index, i] of items.entries()) {
      expect(i.source).toContain(`wiersz ${index + 5}`);
      expect(calculateMarketValues(i, BASE_TRADE_CONTEXT, rules)).toEqual({
        price: i.basePrice,
        availability: i.baseAvailability,
      });
    }
  });
  it('has the verified 11 regions and four locations; every item economic category is covered', () => {
    expect(Object.keys(rules.regions)).toHaveLength(11);
    expect(Object.keys(rules.locations)).toHaveLength(4);
    expect(rules.regions.texas?.priceMultipliers).toEqual({
      PALIWO: 0.25,
      ELEKTRONIKA: 0.5,
      MECHANIKA: 1,
      PROCHY: 0.25,
      BROŃ: 1,
      ŻYWNOŚĆ: 0.25,
      'USŁUGI SPECÓW': 2,
    });
    for (const r of Object.values(rules.regions))
      for (const i of items)
        expect(r.priceMultipliers[i.economicCategory]).toBeTypeOf('number');
  });
  it('retains source ranges, real zero and approximate/unknown weights', () => {
    const find = (name: string) => items.find((i) => i.name === name)!;
    expect(find('Tornado').basePrice).toEqual({ min: 30, max: 100 });
    expect(find('Namiot').basePrice).toEqual({ min: 20, max: 60 });
    expect(find('Ryby (1 kg)').baseAvailability).toEqual({ min: 0, max: 80 });
    expect(equipmentWeight(find('Kurtka ćwiekowana'))).toBe('3 kg');
    expect(equipmentWeight(find('B 92'))).toBe('1 kg');
    expect(find('B 92').weight).toBeNull();
    expect(equipmentWeight(find('Owca'))).toBe('N/D');
    expect(items.some((i) => equipmentWeight(i).includes('5 - 50'))).toBe(true);
    expect(find('Kurtka ćwiekowana').properties).toContain('TT: 11 + mod. ZRC');
    expect(find('Dynamit (laska)').description).toContain('5k6');
    expect(find('Dynamit (laska)').weaponProfile).toBeUndefined();
    expect(find('Szybkoładowarka').type).toBe('other');
  });
  it('searches Polish names and properties without accents, combines filters and does not mutate the input', () => {
    const before = structuredClone(items);
    expect(
      filterEquipment(items, 'cwiekowana', 'armor', '').map((i) => i.name),
    ).toContain('Kurtka ćwiekowana');
    expect(
      filterEquipment(items, 'szybkoladowarka', '', '').map((i) => i.name),
    ).toContain('Szybkoładowarka');
    expect(
      filterEquipment(items, 'finezyjna', 'weapon', '').length,
    ).toBeGreaterThan(0);
    expect(filterEquipment(items, 'cwiekowana', 'food', '')).toEqual([]);
    expect(
      filterEquipment(items, '', '', items[0]!.category).every(
        (i) => i.category === items[0]!.category,
      ),
    ).toBe(true);
    expect(items).toEqual(before);
  });
});
describe('equipment reads and view state', () => {
  it('validates row identity and identifies corrupted source data instead of hiding it', async () => {
    const selectRows = vi
      .fn()
      .mockResolvedValue([
        { id: items[0]!.id, item_json: JSON.stringify(items[0]) },
      ]);
    const repo = createEquipmentRepository({ selectRows, execute: vi.fn() });
    await expect(repo.list()).resolves.toEqual([items[0]]);
    expect(selectRows).toHaveBeenCalledWith(
      expect.stringContaining('WHERE deleted=0'),
    );
    selectRows.mockResolvedValue([
      { id: items[1]!.id, item_json: JSON.stringify(items[0]) },
    ]);
    await expect(repo.list()).rejects.toThrow(items[1]!.id);
  });
  it('retains context/filter/selection across loads and permits retry, without touching Items', async () => {
    const load = vi
      .fn()
      .mockRejectedValueOnce(new Error('disk'))
      .mockResolvedValue(items);
    const store = createEquipmentStore(load);
    expect(store.getState().context).toEqual(BASE_TRADE_CONTEXT);
    await store.getState().load();
    expect(store.getState().error).toContain('disk');
    expect(store.getState().loaded).toBe(false);
    await store.getState().load();
    store.getState().setContext({ ...BASE_TRADE_CONTEXT, color: 'steel' });
    store.getState().setFilters({ query: 'Żółć', type: 'weapon' });
    store.getState().select(items[0]!.id);
    await store.getState().load();
    expect(store.getState().context.color).toBe('steel');
    expect(store.getState().query).toBe('Żółć');
    expect(store.getState().selectedId).toBe(items[0]!.id);
    expect(store.getState().items).toEqual(items);
    expect(createEquipmentStore(load).getState().context).toEqual(
      BASE_TRADE_CONTEXT,
    );
  });
});
