import { expect, it } from 'vitest';
import {
  instantiateEnemy,
  prepareCombat,
  resetEncounter,
  nextCombatTurn,
  parseActorDraft,
  toActorDraft,
  type Combat,
} from '../src/domain/combat';
import {
  enemyInstanceSchema,
  parseCowardice,
  type EnemyTemplate,
} from '../src/domain/enemy';
import {
  applyInjuryLevel,
  changeExhaustion,
  cowardiceWarning,
  injuryConsequences,
  setInjuryEnabled,
} from '../src/domain/injury';
const template: EnemyTemplate = {
  id: '00000000-0000-4000-8000-000000000099',
  name: 'Żółw',
  category: 'beast',
  size: 'Duży',
  tt: 15,
  hpMax: 88,
  speeds: [
    { mode: 'Chód', meters: 9 },
    { mode: 'Lot', meters: 3 },
  ],
  injuryTrack: { enabled: true, initialLevel: 0 },
  cowardicePercent: 50,
};
it('accumulates all four consequences, adds exhaustion only on entering critical and keeps base, template and other copies intact', () => {
  const original = instantiateEnemy(template, 0);
  const other = instantiateEnemy(template, 1);
  let actor = original;
  for (let level = 1; level <= 4; level++) {
    actor = applyInjuryLevel(actor, level);
    expect(injuryConsequences(actor)).toMatchObject({
      level,
      reactionsBlocked: level >= 2,
      bonusActionsBlocked: level >= 3,
      speedPenalty: level < 4 ? 4.5 : 6,
    });
  }
  expect(actor.effects).toHaveLength(1);
  expect(actor.effects![0]!.level).toBe(1);
  expect(applyInjuryLevel(actor, 4).effects).toEqual(actor.effects);
  expect(injuryConsequences(actor).speeds.map((s) => s.meters)).toEqual([3, 0]);
  expect(actor.enemy!.speeds).toEqual(template.speeds);
  expect(actor.enemy!.template).toEqual(template);
  expect(actor.prepared).toEqual(original.prepared);
  expect(other.enemy!.injury!.level).toBe(0);
  const dead = applyInjuryLevel(actor, 5);
  expect(injuryConsequences(dead).deathWarning).toBe(true);
  expect(dead.hpCurrent).toBe(88);
  expect(dead.effects).toEqual(actor.effects);
  actor = applyInjuryLevel(dead, 4);
  expect(actor.effects).toEqual(dead.effects);
  actor = applyInjuryLevel(actor, 3);
  expect(actor.effects![0]!.level).toBe(1);
  expect(applyInjuryLevel(actor, 4).effects![0]!.level).toBe(2);
  expect(setInjuryEnabled(dead, false).effects).toEqual(dead.effects);
  expect(injuryConsequences(setInjuryEnabled(dead, false)).deathWarning).toBe(
    false,
  );
});
it('initial critical creates one independent exhaustion counter; reset/restart/turn never grant it again or infer injuries from HP', () => {
  const t = { ...template, injuryTrack: { enabled: true, initialLevel: 4 } };
  let actor = instantiateEnemy(t, 0);
  expect(actor.effects![0]!.id).not.toBe(
    instantiateEnemy(t, 1).effects![0]!.id,
  );
  const combat: Combat = {
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [{ ...actor, initiativeValue: 12 }],
  };
  const prepared = prepareCombat(combat);
  actor = {
    ...applyInjuryLevel(actor, 5),
    hpCurrent: 0,
    effects: changeExhaustion(actor.effects!, 1),
  };
  const reset = resetEncounter({
    ...prepared,
    actors: [{ ...actor, prepared: prepared.actors[0]!.prepared }],
  });
  expect(reset.actors[0]!.effects![0]!.level).toBe(1);
  expect(reset.actors[0]!.enemy!.injury!.deathWarning).toBe(false);
  expect(nextCombatTurn(reset).actors[0]!.effects![0]!.level).toBe(1);
  expect(parseActorDraft(toActorDraft(actor)).effects![0]!.level).toBe(2);
  expect(
    nextCombatTurn({
      ...combat,
      actors: [{ ...instantiateEnemy(template, 0), hpCurrent: 0 }],
    }).actors[0]!.enemy!.injury!.level,
  ).toBe(0);
  for (let i = 0; i < 10; i++)
    actor = { ...actor, effects: changeExhaustion(actor.effects!, 1) };
  expect(
    applyInjuryLevel(applyInjuryLevel(actor, 3), 4).effects![0]!.level,
  ).toBe(6);
});
it('warns at exactly 44/88, uses current max HP, handles null, zero, 100, fractions and exact large integers', () => {
  let actor = instantiateEnemy(template, 0);
  expect(cowardiceWarning({ ...actor, hpCurrent: 45 })!.active).toBe(false);
  expect(cowardiceWarning({ ...actor, hpCurrent: 44 })).toEqual({
    percent: 50,
    threshold: 44,
    active: true,
  });
  expect(
    cowardiceWarning({ ...actor, hpCurrent: 44, hpMaxCurrent: 80 })!.active,
  ).toBe(false);
  actor = {
    ...actor,
    enemy: { ...actor.enemy!, cowardicePercent: 0 },
    hpCurrent: 0,
  };
  expect(cowardiceWarning(actor)!.active).toBe(true);
  expect(cowardiceWarning({ ...actor, hpCurrent: 1 })!.active).toBe(false);
  expect(
    cowardiceWarning({
      ...actor,
      enemy: { ...actor.enemy!, cowardicePercent: null },
    }),
  ).toBeNull();
  expect(
    cowardiceWarning({
      ...actor,
      enemy: { ...actor.enemy!, cowardicePercent: 100 },
      hpCurrent: 88,
    })!.active,
  ).toBe(true);
  expect(
    cowardiceWarning({
      ...actor,
      enemy: { ...actor.enemy!, cowardicePercent: 50 },
      hpMaxCurrent: 89,
    })!.threshold,
  ).toBe(44);
  expect(
    cowardiceWarning({
      ...actor,
      enemy: { ...actor.enemy!, cowardicePercent: 99 },
      hpMaxCurrent: Number.MAX_SAFE_INTEGER,
    })!.threshold,
  ).toBe(Number((BigInt(Number.MAX_SAFE_INTEGER) * 99n) / 100n));
});
it('accepts legacy enemies unchanged and rejects malformed injury/threshold values without converting blank data into zero', () => {
  const old = { template: { ...template }, speeds: [] };
  delete old.template.injuryTrack;
  delete old.template.cowardicePercent;
  expect(enemyInstanceSchema.parse(old)).toEqual(old);
  const legacy = instantiateEnemy(old.template, 0);
  expect(applyInjuryLevel(legacy, 4)).toEqual(legacy);
  expect(parseActorDraft(toActorDraft(legacy)).enemy).toEqual(legacy.enemy);
  expect(parseCowardice('')).toBeNull();
  for (const text of ['-1', '101', '50.5', 'abc', 'Infinity'])
    expect(() => parseCowardice(text)).toThrow();
  for (const injury of [
    { enabled: true, level: 5, deathWarning: true },
    { enabled: true, level: 3, deathWarning: true },
    { enabled: false, level: 1, deathWarning: false },
  ])
    expect(enemyInstanceSchema.safeParse({ ...old, injury }).success).toBe(
      false,
    );
});
