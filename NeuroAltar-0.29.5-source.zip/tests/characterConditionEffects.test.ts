import { expect, it } from 'vitest';
import { complete, fixture } from './helpers/character';
import { newCharacter } from '../src/domain/character/model';
import {
  initialCondition,
  previewCondition,
  conditionView,
} from '../src/domain/character/condition';
import { characterConditionEffects } from '../src/domain/character/conditionEffects';
import { characterCombatValues } from '../src/domain/character/participation';
import { deriveEquipment } from '../src/domain/character/equipped';
import { emptyInventory } from '../src/domain/character/inventoryModel';
function character() {
  const c = newCharacter();
  c.sheet = complete(fixture('brutal', 1));
  c.sheet.hpCurrent = 10;
  c.draft = null;
  c.condition = initialCondition(c);
  return { ...c, sheet: c.sheet!, condition: c.condition! };
}
it('applies cumulative injury consequences and the same movement on the card and in combat', () => {
  const c = character();
  const base = characterCombatValues(c)!.speed!;
  for (let injury = 0; injury <= 5; injury++) {
    c.condition.injury = injury;
    const effects = characterConditionEffects(c.condition);
    const card = deriveEquipment(c.sheet, emptyInventory(), c.condition);
    const fight = characterCombatValues(c)!;
    expect(effects.injurySpeedPenalty).toBe(injury ? 4.5 : 0);
    expect(effects.reactionBlocked).toBe(injury >= 2);
    expect(effects.bonusBlocked).toBe(injury >= 3);
    expect(effects.fatal).toBe(injury === 5);
    expect(card.encumbrance.speed).toBe(
      injury === 5 ? 0 : Math.max(0, base - (injury ? 4.5 : 0)),
    );
    expect(fight.speed).toBe(injury === 5 ? 0 : card.encumbrance.speed);
  }
});
it('stacks exhaustion with injuries, clamps speed and reports fatal sixth exhaustion level', () => {
  const c = character();
  c.condition.injury = 1;
  for (let level = 1; level <= 6; level++) {
    c.condition.exhaustion = [
      { id: crypto.randomUUID(), cause: 'ordinary', source: 'Marsz', level },
    ];
    const effects = conditionView(c).consequences;
    expect(effects.testPenalty).toBe(2 * level);
    expect(effects.speedPenalty).toBe(4.5 + 1.5 * level);
    expect(effects.fatal).toBe(level === 6);
    expect(characterCombatValues(c)!.speed).toBe(
      Math.max(0, 9 - 4.5 - 1.5 * level),
    );
  }
});
it('adds fourth-injury exhaustion once, keeps its cause after wound healing and never mutates while deriving', () => {
  let c = character();
  const set = (injury: number) => {
    c = {
      ...c,
      condition: previewCondition(
        c,
        {
          type: 'correct',
          hp: 10,
          injury,
          hitDiceSpent: { 6: 0, 8: 0 },
          reason: 'Zmiana stopnia',
        },
        crypto.randomUUID(),
      ).state,
    };
  };
  set(3);
  set(4);
  set(4);
  expect(c.condition.exhaustion).toHaveLength(1);
  expect(c.condition.exhaustion[0]!.source).toBe('Czwarte Zranienie');
  expect(characterCombatValues(c)!.speed).toBe(3);
  const before = structuredClone(c);
  conditionView(c);
  characterCombatValues(c);
  expect(c).toEqual(before);
  set(3);
  expect(c.condition.exhaustion).toEqual(before.condition.exhaustion);
});
it('manual exhaustion decrement preserves other causes and unrelated state, removes only the final level and rejects stale ids', () => {
  const c = character(),
    first = crypto.randomUUID(),
    second = crypto.randomUUID();
  c.condition.exhaustion = [
    { id: first, cause: 'hunger', source: 'Brak jedzenia', level: 2 },
    { id: second, cause: 'radiation', source: 'Skażenie', level: 1 },
  ];
  c.condition.combatHealth = {
    bleeding: true,
    successes: 1,
    failures: 1,
    stable: false,
    dead: false,
  };
  const original = structuredClone(c),
    op = crypto.randomUUID();
  const one = previewCondition(c, { type: 'exhaustionReduce', id: first }, op);
  expect(one.state.exhaustion).toEqual([
    { ...c.condition.exhaustion[0], level: 1 },
    c.condition.exhaustion[1],
  ]);
  expect(one.state.hp).toBe(c.condition.hp);
  expect(one.state.combatHealth).toEqual(c.condition.combatHealth);
  expect(one.state.journal.at(-1)?.id).toBe(op);
  expect(c).toEqual(original);
  const two = previewCondition(
    { ...c, condition: one.state },
    { type: 'exhaustionReduce', id: first },
    crypto.randomUUID(),
  );
  expect(two.state.exhaustion).toEqual([c.condition.exhaustion[1]]);
  expect(() =>
    previewCondition(
      { ...c, condition: two.state },
      { type: 'exhaustionReduce', id: first },
      crypto.randomUUID(),
    ),
  ).toThrow('przyczynę');
});
