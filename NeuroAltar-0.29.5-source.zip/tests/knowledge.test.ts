import { expect, it, vi } from 'vitest';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import {
  knowledgeEntriesSchema,
  knowledgeEntrySchema,
  filterKnowledge,
  matchingRows,
  knowledgeParagraphs,
  type KnowledgeTable,
} from '../src/domain/knowledge';
import { listKnowledge } from '../src/data/knowledge/catalog';
import { createKnowledgeStore } from '../src/stores/knowledgeStore';
import { KnowledgeReader } from '../src/features/reference/KnowledgeWorkspace';
import raw from '../src/data/knowledge/tables.v1.json';
import handbookTables from '../src/data/knowledge/handbook-tables.v1.json';
import { TRADE_COLORS } from '../src/domain/market';
import rules from '../src/data/equipment/market-rules.v1.json';
const entries = listKnowledge();
const entry = (name: string) => entries.find((e) => e.title === name)!;
const table = (name: string) =>
  entry(name).blocks.find((b) => b.kind === 'table') as KnowledgeTable;
it('covers the original 47 source entries, three trade tables and the added handbook tables', () => {
  expect(raw.entries).toHaveLength(47);
  expect(entries).toHaveLength(50 + handbookTables.entries.length);
  expect(new Set(raw.entries.map((e) => e.source.sheet)).size).toBe(13);
  expect(
    raw.entries.flatMap((e) =>
      e.blocks.flatMap((b) => ('rows' in b ? b.rows : [])),
    ).length,
  ).toBe(362);
  expect(knowledgeEntriesSchema.parse(entries)).toEqual(entries);
});
it('preserves source headers, percentages, units, blanks and price/weight ranges', () => {
  const armor = table('LEKKIE PANCERZE (1 akcja na założenie/ściągnięcie)');
  expect(armor.columns.map((c) => c.label)).toEqual([
    'NAZWA',
    'TT (TRUDNOŚĆ TRAFIENIA)',
    'SIŁA',
    'SKRADANIE/PŁYWANIE',
    'WAGA',
    'CENA',
    'DOSTĘPNOŚĆ',
  ]);
  expect(armor.columns[5]?.unit).toBe('gb');
  expect(armor.rows[0]?.cells.map((c) => c.text)).toEqual([
    'Kurtka ćwiekowana',
    '11 + mod. ZRC',
    '-',
    '-',
    '3 kg',
    '30',
    '70%',
  ]);
  const tent = table('TABELA RÓŻNOŚCI').rows.find((r) =>
    r.cells.some((c) => c.text === 'Namiot'),
  )!;
  expect(tent.cells.map((c) => c.text)).toContain('20 - 60');
  expect(tent.cells.map((c) => c.text)).toContain('5 - 50 kg');
  expect(table('Tabela broni białej').rows[0]?.cells[0]?.text).toBe('');
  expect(table('Tabela broni białej').columns[0]?.label).toBe('k20');
});
it('retains travel notes, tool usages, burst tables and descriptive dice instructions', () => {
  expect(table('Tempo podróży').rows[0]?.cells.map((c) => c.text)).toEqual([
    'Bardzo szybkie',
    '500 m',
    '30 km',
    '240 km',
  ]);
  expect(
    entry('Tempo podróży').blocks.filter((b) => b.kind === 'text'),
  ).toHaveLength(4);
  expect(table('Tabela zestawów narzędzi').rows).toHaveLength(22);
  expect(
    table('Tabela obrażeń długiej serii').rows.map((r) => r.cells[0]?.text),
  ).toEqual(['10', '15', '20', '25', '30']);
  expect(
    table('Ogień zaporowy')
      .rows.at(-1)
      ?.cells.map((c) => c.text),
  ).toEqual(['k20', '20']);
  expect(table('ELEKTRONIKA').rows.at(-1)?.cells[1]?.text).toBe(
    'Rzuć dwa razy',
  );
  expect(knowledgeParagraphs('  A\n\nB\nC  ')).toEqual(['A', 'B', 'C']);
});
it('derives trade tables from the same regional rules and colors as Equipment', () => {
  const regional = table('Modyfikatory cen regionalnych');
  expect(regional.rows).toHaveLength(12);
  const columns = Object.keys(rules.regions.detroit.priceMultipliers);
  for (const region of Object.values(rules.regions)) {
    const row = regional.rows.find((r) => r.cells[0]?.text === region.label)!;
    expect(row.cells.slice(1).map((c) => c.text)).toEqual(
      columns.map(
        (key) =>
          `×${region.priceMultipliers[key as keyof typeof region.priceMultipliers].toLocaleString('pl')}`,
      ),
    );
  }
  expect(table('Modyfikatory dostępności').rows).toHaveLength(5);
  const colors = table('Kolory Neuroshimy');
  expect(colors.rows.map((r) => r.cells[0]?.text)).toEqual(
    Object.values(TRADE_COLORS).map((c) => c.label),
  );
  expect(
    colors.rows
      .find((r) => r.cells[0]?.text === 'Stal')
      ?.cells.map((c) => c.text),
  ).toEqual(['Stal', '×0,5', '×2', 'Tylko broń i amunicja']);
});
it('rejects inconsistent table shape and duplicate row or entry identities', () => {
  const broken = structuredClone(entry('Tempo podróży'));
  const block = broken.blocks[0] as KnowledgeTable;
  block.rows[0]!.cells.pop();
  expect(() => knowledgeEntrySchema.parse(broken)).toThrow('nagłówkom');
  block.rows[0]!.cells.push({ text: 'x', source: 'G7' });
  block.rows.push(block.rows[0]!);
  expect(() => knowledgeEntrySchema.parse(broken)).toThrow('Powtórzone');
  expect(() =>
    knowledgeEntriesSchema.parse([entries[0], entries[0]]),
  ).toThrow();
});
it('searches Polish text without diacritics and narrows rows with their heading context', () => {
  const before = structuredClone(entries);
  const result = filterKnowledge(entries, 'niewidocznosc', 'Stany i podróż');
  expect(result.map((e) => e.title)).toEqual(['Tabela stanów']);
  expect(
    matchingRows(result[0]!, table('Tabela stanów'), 'niewidocznosc').map(
      (r) => r.cells[0]?.text,
    ),
  ).toContain('Niewidoczność');
  expect(
    matchingRows(
      entry('Tabela zestawów narzędzi'),
      table('Tabela zestawów narzędzi'),
      'narzedzi aptekarza',
    ),
  ).toHaveLength(1);
  expect(
    matchingRows(entry('Tempo podróży'), table('Tempo podróży'), '30 km/h'),
  ).toHaveLength(4);
  expect(filterKnowledge(entries, 'nieistniejacehaslo', '')).toEqual([]);
  expect(entries).toEqual(before);
});
it('retains query, category and selection across loads, retries errors and isolates source copies', () => {
  const load = vi
    .fn()
    .mockImplementationOnce(() => {
      throw Error('bad data');
    })
    .mockImplementation(listKnowledge);
  const s = createKnowledgeStore(load);
  s.getState().load();
  expect(s.getState().error).toContain('bad data');
  s.getState().load();
  expect(s.getState().entries).toHaveLength(50 + handbookTables.entries.length);
  s.getState().search('Żółć');
  s.getState().filter('Handel');
  s.getState().select(entries[0]!.id);
  s.getState().load();
  expect(s.getState().query).toBe('Żółć');
  expect(s.getState().category).toBe('Handel');
  expect(s.getState().selectedId).toBe(entries[0]!.id);
  const a = listKnowledge();
  a[0]!.title = 'Changed';
  expect(listKnowledge()[0]!.title).not.toBe('Changed');
});
it('renders table headers and source and escapes content as plain text', () => {
  const markup = renderToStaticMarkup(
    createElement(KnowledgeReader, {
      entry: entry('Tabela stanów'),
      query: 'niewidocznosc',
    }),
  );
  expect(markup).toContain('NAZWA STANU');
  expect(markup).toContain('EFEKT');
  expect(markup).toContain('Niewidoczność');
  expect(markup).toContain('Neuroshima: Ostatnia Era');
  expect(markup).toContain('35–36');
  expect(markup).not.toContain('STANY I PODRÓŻ');
  expect(markup).not.toContain('Suplement tabelaryczny');
  const escaped = renderToStaticMarkup(
    createElement(KnowledgeReader, {
      entry: { ...entries[0]!, title: '<script>alert(1)</script>' },
      query: '',
    }),
  );
  expect(escaped).not.toContain('<script>');
  expect(escaped).toContain('&lt;script&gt;');
});

it('provides a named handbook and verified printed pages for every knowledge entry', () => {
  expect(entry('Hełmy').handbook).toEqual({
    title: 'Neuroshima: Ostatnia Era',
    pages: [114, 115],
  });
  expect(entry('Modyfikatory cen regionalnych').handbook.pages).toEqual([44]);
  expect(entry('Kolory Neuroshimy').handbook.pages).toEqual([201, 202, 203]);
  for (const e of entries) {
    expect(e.handbook.title).toBe('Neuroshima: Ostatnia Era');
    expect(e.handbook.pages.length).toBeGreaterThan(0);
    const markup = renderToStaticMarkup(
      createElement(KnowledgeReader, { entry: e, query: '' }),
    );
    expect(markup).not.toContain(e.source.range);
  }
});

it('uses the approved handbook corrections for helmet destruction and a stationary target', () => {
  const helmet = entry('Hełmy');
  const weapons = entry('Właściwości broni dystansowej');
  const text = (e: typeof helmet) =>
    e.blocks.flatMap((b) => (b.kind === 'text' ? [b.text] : [])).join(' ');
  expect(text(helmet)).toContain('Hełm ulega wtedy zniszczeniu.');
  expect(text(weapons)).toContain('chyba że Szybkość tej istoty wynosi 0.');
  expect(text(weapons)).not.toContain(
    'chyba że Zręczność tej istoty wynosi 0.',
  );
  expect(helmet.blocks.find((b) => b.kind === 'text')?.source).toContain(
    's. 115',
  );
  expect(weapons.blocks.find((b) => b.kind === 'text')?.source).toContain(
    's. 118',
  );
  for (const e of entries.filter(
    (e) => e.id !== helmet.id && e.id !== weapons.id,
  )) {
    const original = raw.entries.find((x) => x.id === e.id);
    if (original) expect(e.blocks).toEqual(original.blocks);
  }
  expect(listKnowledge()).toEqual(entries);
  const originalHelmet = raw.entries.find((e) => e.id === helmet.id)!;
  expect(JSON.stringify(originalHelmet)).not.toContain(
    'Hełm ulega wtedy zniszczeniu.',
  );
  const html = renderToStaticMarkup(
    createElement(KnowledgeReader, { entry: helmet, query: '' }),
  );
  expect(html).toContain('Hełm ulega wtedy zniszczeniu.');
});
