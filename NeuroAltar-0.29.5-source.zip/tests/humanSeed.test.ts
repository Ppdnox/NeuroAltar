import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/humans.v1.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { templateDraft } from '../src/domain/bestiary';
import { calculateWeaponAttackProfile } from '../src/domain/item';
import {
  instantiateEnemy,
  prepareCombat,
  resetEncounter,
  parseActorDraft,
  toActorDraft,
} from '../src/domain/combat';
import { consumeCapability } from '../src/domain/capabilities';
import { fixedHandbookSp, presentRule } from '../src/domain/presentation';
const entries = batch.entries.map((e) => ({
  ...e,
  template: enemyTemplateSchema.parse(e.template),
}));
const get = (key: string) => entries.find((e) => e.key === key)!.template;
it('inventories the nine source statblocks with printed values and preserves editor round trips', () => {
  expect(
    entries.map(({ source, template: t }) => [
      t.name,
      source.pdfPage,
      t.tt,
      t.hpMax,
      t.sp,
      t.loadout!.pb,
      t.cowardicePercent,
      t.injuryTrack!.enabled,
    ]),
  ).toEqual([
    ['Cyngiel', 209, 19, 88, 26, 4, 25, true],
    ['Cywil', 210, 11, 9, 1, 2, 75, false],
    ['Gangus żołnierz', 210, 13, 18, 3, 2, 25, false],
    ['Gangus kapo', 211, 15, 60, 14, 3, 25, true],
    ['Gangus boss', 212, 20, 108, 25, 4, 10, true],
    ['Konwojent (strażnik)', 212, 15, 24, 3, 2, 50, false],
    ['Kanibal', 213, 13, 26, 3, 2, 25, false],
    ['Szeryf', 214, 16, 93, 19, 4, 25, true],
    ['Żołnierz Posterunku', 215, 18, 52, 15, 3, 25, true],
  ]);
  for (const { source, template: t } of entries) {
    expect(t.category).toBe('human');
    expect(source.pdfPage - source.printedPage).toBe(2);
    expect(t.speeds).toEqual([{ mode: 'Chód', meters: 9 }]);
    expect(fixedHandbookSp(t)).toBe(true);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toEqual(t);
    expect(instantiateEnemy(t, 0).initiativeValue).toBeNull();
    expect(t.statblock!.traits!.map((v) => presentRule(v, t.tt))).toEqual(
      t.statblock!.traits,
    );
  }
  expect(new Set(entries.map((e) => e.template.id)).size).toBe(9);
});
it('matches printed attacks without double-counting conditional bonuses or inventing damage types', () => {
  const expected = [
    [9, 9, 9],
    [2, 2, 2],
    [3, 4],
    [5, 6],
    [8, 8],
    [3, 4],
    [4, 4, 3, 4],
    [5, 8, 8],
    [5, 6],
  ];
  entries.forEach(({ template: t }, i) =>
    expect(
      t
        .loadout!.items.filter((e) => e.item.weaponProfile)
        .map((e) => calculateWeaponAttackProfile(e, t.loadout!).attack),
    ).toEqual(expected[i]),
  );
  expect(
    get('gangus-boss').loadout!.items[1]!.item.weaponProfile!.damageModes[0],
  ).toMatchObject({ dice: '2k8 + 2k6 + 4', average: 18, damageType: 'N/D' });
  expect(
    get('cywil').loadout!.items[1]!.item.weaponProfile!.damageModes[0],
  ).toMatchObject({
    dice: '3k4',
    average: 6,
    damageType: 'N/D',
    condition: 'Tylko farmer.',
  });
  expect(get('szeryf').statblock!.senses).toContain('Pasywna Percepcja 11');
  expect(get('gangus-kapo').statblock!.skills).toContain('Atletyka +6');
  expect(get('kanibal').loadout!.items[2]!.item.description).toContain(
    'porażka o co najmniej 5',
  );
  expect(get('kanibal').loadout!.items[2]!.item.description).toContain(
    '3 (1k6) od trucizny',
  );
  expect(
    get('cyngiel').capabilities!.abilities.find(
      (a) => a.name === 'Nóż taktyczny — dodatkowy atak',
    )!.kind,
  ).toBe('bonus');
  expect(
    get('gangus-kapo').capabilities!.abilities.find((a) => a.name === 'Ofiara')!
      .kind,
  ).toBe('reaction');
});
it('limited bursts have separate per-encounter resources and never resolve saves, HP, ammunition or other copies', () => {
  for (const key of ['gangus-kapo', 'konwojent', 'zolnierz-posterunku']) {
    const t = get(key),
      b = instantiateEnemy(t, 1),
      id = t.capabilities!.abilities.find((a) => a.resourceId)!.id;
    const saveOnly = t.loadout!.items.find((e) =>
      e.item.name.includes('długa seria'),
    )!;
    expect(saveOnly.item.weaponProfile).toBeUndefined();
    const a = consumeCapability(instantiateEnemy(t, 0), id);
    expect(a.enemy!.capabilities!.resources[0]!.currentValue).toBe(1);
    expect(a.enemy!.capabilities!.budget.action).toBe(0);
    expect(() => consumeCapability(a, id)).toThrow();
    const twice = consumeCapability(a, id, true);
    expect(twice.enemy!.capabilities!.resources[0]!.currentValue).toBe(0);
    expect(() => consumeCapability(twice, id, true)).toThrow('Za mało');
    expect(twice.hpCurrent).toBe(t.hpMax);
    expect(twice.effects).toEqual(b.effects);
    expect(twice.enemy!.loadout).toEqual(a.enemy!.loadout);
    expect(b.enemy!.capabilities!.resources[0]!.currentValue).toBe(2);
    expect(t.capabilities!.resources[0]!.maxValue).toBe(2);
    expect(parseActorDraft(toActorDraft(twice))).toEqual(twice);
    const c = prepareCombat({
      encounterId: 1,
      revision: 0,
      roundNumber: 1,
      currentTurnActorId: null,
      actors: [a, b],
    });
    expect(
      resetEncounter({
        ...c,
        actors: [consumeCapability(c.actors[0]!, id, true), c.actors[1]!],
      }).actors[0]!.enemy!.capabilities!.resources[0]!.currentValue,
    ).toBe(1);
  }
});
