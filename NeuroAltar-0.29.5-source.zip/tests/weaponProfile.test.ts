import { describe, expect, it } from 'vitest';
import {
  combatLoadoutSchema,
  itemSchema,
  calculateWeaponAttackProfile,
  selectWeaponVariant,
  type CombatLoadout,
} from '../src/domain/item';
import {
  newWeaponDraft,
  parseLoadoutDraft,
  toLoadoutDraft,
} from '../src/domain/itemDraft';
import {
  instantiateEnemy,
  resetEncounter,
  prepareCombat,
  type Combat,
} from '../src/domain/combat';
import { templateDraft } from '../src/domain/bestiary';
import { parseEnemyTemplateDraft } from '../src/domain/enemy';
export function loadoutFixture(): CombatLoadout {
  const draft = {
    pb: '4',
    strModifier: '2',
    dexModifier: '5',
    items: [newWeaponDraft()],
  };
  const e = draft.items[0]!;
  e.name = 'Karabin Żółw';
  e.description = 'Efekt MG\nZażółć gęślą jaźń.';
  e.profile!.damageModes[0]!.dice = '2k8 + 3';
  e.profile!.damageModes[0]!.damageType = 'kłute';
  e.profile!.range = { normal: '30', long: '90' };
  return parseLoadoutDraft(draft, '2026-09-09T12:00:00.000Z');
}
describe('weapon profiles', () => {
  it('adds PB 4 to DEX 5 for +9, preserves final dice and never mutates the item', () => {
    const l = loadoutFixture(),
      copy = structuredClone(l);
    const p = calculateWeaponAttackProfile(l.items[0]!, l);
    expect(p.attack).toBe(9);
    expect(p.damage.dice).toBe('2k8 + 3');
    expect(l).toEqual(copy);
    expect(p.range).toEqual({ normal: 30, long: 90, unit: 'm' });
  });
  it('uses STR and finesse, supports negative modifiers and distinguishes unknown from zero', () => {
    const l = loadoutFixture();
    l.items[0]!.item.weaponProfile!.abilityRule = 'str';
    l.strModifier = -2;
    expect(calculateWeaponAttackProfile(l.items[0]!, l).attack).toBe(2);
    l.items[0]!.item.weaponProfile!.abilityRule = 'finesse';
    expect(calculateWeaponAttackProfile(l.items[0]!, l).attack).toBe(9);
    l.dexModifier = null;
    expect(() => calculateWeaponAttackProfile(l.items[0]!, l)).toThrow(
      'Uzupełnij',
    );
    l.items[0]!.item.weaponProfile!.abilityRule = 'str';
    l.pb = 0;
    l.strModifier = 0;
    expect(calculateWeaponAttackProfile(l.items[0]!, l).attack).toBe(0);
  });
  it('applies independent additive variants with explicit ammo damage/range priority and reversible N/D', () => {
    const l = loadoutFixture(),
      e = l.items[0]!,
      p = e.item.weaponProfile!;
    p.damageModes.push(
      { ...p.damageModes[0]!, id: 'fire', label: 'Seria', dice: '3k8' },
      { ...p.damageModes[0]!, id: 'ammo', label: 'Specjalna', dice: '4k8' },
    );
    p.fireModes.push({
      id: 'burst',
      label: 'Seria',
      attackModifier: -2,
      damageModeId: 'fire',
      range: { normal: 20, long: 60, unit: 'm' },
      effect: 'Krótka seria',
    });
    p.ammoVariants.push({
      id: 'special',
      label: 'Specjalna',
      attackModifier: 1,
      damageModeId: 'ammo',
      range: { normal: 10, long: 40, unit: 'm' },
      effect: 'Specjalny efekt',
    });
    const changed = selectWeaponVariant(l, e.item.id, {
      fireModeId: 'burst',
      ammoVariantId: 'special',
    });
    const result = calculateWeaponAttackProfile(changed.items[0]!, changed);
    expect(result.attack).toBe(8);
    expect(result.damage.dice).toBe('4k8');
    expect(result.range.normal).toBe(10);
    expect(
      calculateWeaponAttackProfile(
        selectWeaponVariant(changed, e.item.id, { ammoVariantId: null })
          .items[0]!,
        l,
      ).damage.dice,
    ).toBe('3k8');
    expect(
      calculateWeaponAttackProfile(
        selectWeaponVariant(changed, e.item.id, {
          fireModeId: null,
          ammoVariantId: null,
        }).items[0]!,
        l,
      ).attack,
    ).toBe(9);
    expect(e.fireModeId).toBeNull();
    expect(() =>
      selectWeaponVariant(l, e.item.id, { ammoVariantId: 'missing' }),
    ).toThrow();
  });
  it('validates ranges, variant links and ID uniqueness; an item without a profile is not a zero attack', () => {
    const l = loadoutFixture();
    const e = l.items[0]!;
    e.item.weaponProfile!.range.long = 1;
    expect(() => combatLoadoutSchema.parse(l)).toThrow();
    e.item.weaponProfile!.range.long = 90;
    l.items.push(structuredClone(e));
    expect(() => combatLoadoutSchema.parse(l)).toThrow();
    l.items.pop();
    delete e.item.weaponProfile;
    e.damageModeId = null;
    expect(() => calculateWeaponAttackProfile(e, l)).toThrow('nie ma profilu');
    e.item.type = 'tool';
    expect(itemSchema.parse(e.item).type).toBe('tool');
  });
  it('keeps base price/availability ranges and metadata during editor roundtrip without touching unchanged timestamps', () => {
    const l = loadoutFixture(),
      item = l.items[0]!.item;
    item.basePrice = { min: 10.5, max: 25 };
    item.baseAvailability = { min: 20, max: 40 };
    item.weight = 0;
    item.economicCategory = 'local';
    item.source = 'Notatki MG';
    const canonical = combatLoadoutSchema.parse(l);
    expect(
      parseLoadoutDraft(toLoadoutDraft(canonical), '2030-01-01T00:00:00.000Z'),
    ).toEqual(canonical);
    const d = toLoadoutDraft(canonical);
    d.items[0]!.name = 'Nowa nazwa';
    const next = parseLoadoutDraft(d);
    expect(next.items[0]!.item.basePrice).toEqual(item.basePrice);
    expect(next.items[0]!.item.baseAvailability).toEqual(item.baseAvailability);
    expect(next.items[0]!.item.source).toBe('Notatki MG');
  });
  it('copies setup independently and reset restores the complete prepared weapon rather than the catalog', () => {
    const template = {
      id: crypto.randomUUID(),
      name: 'Strzelec',
      category: 'human' as const,
      size: 'Średni',
      tt: 15,
      hpMax: 88,
      speeds: [],
      loadout: loadoutFixture(),
    };
    const parsed = parseEnemyTemplateDraft(
      templateDraft(template),
      template.id,
    );
    expect(parsed.loadout).toEqual(template.loadout);
    const a = instantiateEnemy(template, 0),
      b = instantiateEnemy(template, 1);
    const c: Combat = {
      encounterId: 1,
      revision: 0,
      roundNumber: 1,
      currentTurnActorId: null,
      actors: [a, b],
    };
    a.enemy!.loadout!.items[0]!.item.name = 'Inna broń';
    a.enemy!.loadout!.pb = 2;
    expect(b.enemy!.loadout!.items[0]!.item.name).toBe('Karabin Żółw');
    expect(template.loadout.pb).toBe(4);
    expect(resetEncounter(c).actors[0]!.enemy!.loadout).toEqual(
      template.loadout,
    );
    const prepared = prepareCombat(c);
    prepared.actors[0]!.enemy!.loadout!.pb = 9;
    expect(resetEncounter(prepared).actors[0]!.enemy!.loadout!.pb).toBe(2);
  });
});

it('accepts the shared Rust/TypeScript fixture and returns the baseline attack', async () => {
  const { readFileSync } = await import('node:fs');
  const l = combatLoadoutSchema.parse(
    JSON.parse(
      readFileSync(new URL('./fixtures/loadout.json', import.meta.url), 'utf8'),
    ),
  );
  expect(calculateWeaponAttackProfile(l.items[0]!, l).attack).toBe(9);
  expect(parseLoadoutDraft(toLoadoutDraft(l))).toEqual(l);
});
