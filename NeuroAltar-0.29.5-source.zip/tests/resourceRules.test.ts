import { expect, it } from 'vitest';
import { CLASSES } from '../src/domain/character/model';
import { deriveCharacter } from '../src/domain/character/derive';
import {
  deriveResources,
  type ResourceDefinition,
} from '../src/domain/character/resources';
import {
  resourceDotPage,
  resourceDotAvailable,
  resourcesForRule,
  toggleResourceDot,
  unassignedResources,
} from '../src/domain/character/resourceRules';
import { fixture } from './helpers/character';

it('attaches every class pool exactly once at every supported level, including upgraded abilities', () => {
  for (const classId of CLASSES) {
    for (let level = 1; level <= 12; level++) {
      const sheet = fixture(classId, level);
      const rules = deriveCharacter(sheet).rules;
      const resources = deriveResources(sheet);
      const attached = rules.flatMap((rule) =>
        resourcesForRule(resources, rule.id),
      );
      expect(
        attached.map((resource) => resource.id).sort(),
        `${classId} ${level}`,
      ).toEqual(resources.map((resource) => resource.id).sort());
      expect(unassignedResources(resources, rules)).toEqual([]);
    }
  }
});

it('uses stable IDs for renamed profession, origin and feat resources and preserves unknown/custom pools', () => {
  const make = (id: string): ResourceDefinition => ({
    id,
    label: 'Niepowiązana nazwa',
    max: 1,
    refresh: 'long',
    page: 75,
    costMax: 1,
    note: '',
    unresolved: false,
  });
  const resources = [
    'amen',
    'concert',
    'clint',
    'patriot',
    'stubborn',
    'believe',
    'fart',
    'song',
    'custom',
    'future',
  ].map(make);
  const rules = [
    'profession.preacher.0',
    'profession.star.3',
    'profession.cowboy.0',
    'origin.newyork.patriot',
    'origin.hegemony.stubborn',
    'origin.saltlake.believe',
    'origin.vegas.luck',
    'feat.musician',
  ].map((id) => ({ id }));
  expect(
    rules
      .flatMap((rule) => resourcesForRule(resources, rule.id))
      .map((resource) => resource.id),
  ).toEqual(resources.slice(0, 8).map((resource) => resource.id));
  expect(
    unassignedResources(resources, rules).map((resource) => resource.id),
  ).toEqual(['custom', 'future']);
  expect(unassignedResources([make('berserk')], [])).toHaveLength(1);
});

it('recomputes the displayed dot count after advancement without restoring spent uses', () => {
  const before = deriveResources(fixture('brutal', 6)).find(
    (r) => r.id === 'berserk',
  )!;
  const after = deriveResources(fixture('brutal', 10)).find(
    (r) => r.id === 'berserk',
  )!;
  expect(resourceDotPage(before.max, 2, null)).toMatchObject({
    start: 0,
    end: 3,
    remaining: 1,
  });
  expect(resourceDotPage(after.max, 2, null)).toMatchObject({
    start: 0,
    end: 5,
    remaining: 3,
  });
});

it('bounds huge custom pools and clamps stale page selection when their maximum shrinks', () => {
  const page = resourceDotPage(100000, 0, null);
  expect(page.end - page.start).toBeLessThanOrEqual(24);
  expect(page.end).toBe(100000);
  expect(resourceDotPage(3, 5, page.page)).toEqual({
    remaining: 0,
    page: 0,
    lastPage: 0,
    start: 0,
    end: 3,
  });
  expect(resourceDotPage(0, 0, 20)).toEqual({
    remaining: 0,
    page: 0,
    lastPage: 0,
    start: 0,
    end: 0,
  });
});

it('toggles the exact chosen dot and restores it on a second click without changing the other uses', () => {
  const used = toggleResourceDot(null, 5, 0, 0);
  expect(used?.spent).toBe(1);
  expect(resourceDotAvailable(used, 5, 1, 0)).toBe(false);
  expect(resourceDotAvailable(used, 5, 1, 4)).toBe(true);
  const twice = toggleResourceDot(used, 5, 1, 3);
  expect(twice?.spent).toBe(2);
  expect(resourceDotAvailable(twice, 5, 2, 0)).toBe(false);
  expect(resourceDotAvailable(twice, 5, 2, 3)).toBe(false);
  const restored = toggleResourceDot(twice, 5, 2, 0);
  expect(restored?.spent).toBe(1);
  expect(resourceDotAvailable(restored, 5, 1, 0)).toBe(true);
  expect(resourceDotAvailable(restored, 5, 1, 3)).toBe(false);
  expect(
    Array.from({ length: 5 }, (_, i) =>
      resourceDotAvailable(restored, 5, 1, i),
    ).filter(Boolean),
  ).toHaveLength(4);
  // Rest/advancement changes use the new persisted totals, never stale local positions.
  expect(resourceDotAvailable(restored, 5, 0, 3)).toBe(true);
  expect(resourceDotAvailable(restored, 3, 1, 3)).toBe(false);
  expect(toggleResourceDot(restored, 3, 5, 1)).toBeNull();
});
