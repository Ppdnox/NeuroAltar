import { expect, it } from 'vitest';
import {
  instantiateEnemy,
  prepareCombat,
  resetEncounter,
  toActorDraft,
  parseActorDraft,
  combatSchema,
  type Combat,
} from '../src/domain/combat';
import {
  parseSpeeds,
  parseEnemyTemplateDraft,
  type EnemyTemplate,
} from '../src/domain/enemy';
import { initiativeOrder } from '../src/domain/initiative';

export const template: EnemyTemplate = {
  id: '00000000-0000-4000-8000-000000000099',
  name: 'Żmija pustkowi',
  category: 'beast',
  size: 'Mały',
  tt: 14,
  hpMax: 28,
  speeds: [
    { mode: 'Chód', meters: 9 },
    { mode: 'Wspinaczka', meters: 4.5 },
  ],
};
const sample = (): Combat => ({
  encounterId: 1,
  revision: 0,
  roundNumber: 3,
  currentTurnActorId: null,
  actors: [
    instantiateEnemy(template, 0),
    instantiateEnemy(template, 1),
    instantiateEnemy(template, 2),
  ],
});
it('creates independent UUIDs, snapshots, movement and initiative for three copies of a template', () => {
  const combat = sample();
  const before = structuredClone(template);
  combat.actors[0]!.hpCurrent = 0;
  combat.actors[0]!.enemy!.speeds[0]!.meters = 0;
  combat.actors[0]!.statuses.push('Powalenie');
  [17, -1, 0].forEach((value, index) => {
    combat.actors[index]!.initiativeValue = value;
  });
  expect(new Set(combat.actors.map((a) => a.id)).size).toBe(3);
  expect(initiativeOrder(combat.actors).map((a) => a.initiativeValue)).toEqual([
    17, 0, -1,
  ]);
  expect(combat.actors[1]!.hpCurrent).toBe(28);
  expect(combat.actors[1]!.enemy!.speeds[0]!.meters).toBe(9);
  expect(combat.actors[0]!.prepared!.hpCurrent).toBe(28);
  expect(combat.actors[0]!.prepared!.enemy!.speeds[0]!.meters).toBe(9);
  expect(template).toEqual(before);
});
it('resets current members to their explicit baseline including partial HP, statuses, name and movement', () => {
  const combat = sample();
  Object.assign(combat.actors[0]!, {
    displayName: 'Żmija przy bramie',
    hpCurrent: 19,
    ttCurrent: 16,
    initiativeValue: 12,
    statuses: ['Zatrucie'],
  });
  combat.actors[0]!.enemy!.speeds[0]!.meters = 7.5;
  const prepared = prepareCombat(combat);
  const baseline = structuredClone(prepared.actors[0]!.prepared);
  prepared.actors[0]!.hpCurrent = 0;
  prepared.actors[0]!.hpMaxCurrent = 40;
  prepared.actors[0]!.enemy!.speeds = [];
  prepared.actors[0]!.statuses = [];
  prepared.actors[0]!.displayName = 'Ranna';
  prepared.currentTurnActorId = prepared.actors[0]!.id;
  prepared.actors.splice(1, 1);
  const beforeReset = structuredClone(prepared);
  const reset = resetEncounter(prepared);
  expect(reset.actors).toHaveLength(2);
  expect(reset.actors[0]).toMatchObject(baseline!);
  expect(reset.roundNumber).toBe(1);
  expect(reset.currentTurnActorId).toBeNull();
  expect(prepared).toEqual(beforeReset);
  expect(reset.actors[0]!.enemy!.template).toEqual(template);
});
it('normalizes tie ranks when old prepared ranks collide with a new member and rejects foreign snapshots', () => {
  const combat = sample();
  combat.actors.splice(1, 1);
  combat.actors.push(instantiateEnemy(template, 2));
  expect(
    new Set(resetEncounter(combat).actors.map((a) => a.initiativeTieOrder))
      .size,
  ).toBe(3);
  combat.actors[0]!.prepared!.id = combat.actors[1]!.id;
  expect(combatSchema.safeParse(combat).success).toBe(false);
});
it('keeps raw movement edits, supports Polish decimals and rejects missing, repeated, negative or infinite distances', () => {
  const draft = toActorDraft(instantiateEnemy(template, 0));
  expect(
    parseActorDraft({ ...draft, speedsText: 'Chód: 4,5\nLot: 0' }).enemy!
      .speeds,
  ).toEqual([
    { mode: 'Chód', meters: 4.5 },
    { mode: 'Lot', meters: 0 },
  ]);
  expect(parseSpeeds('')).toEqual([]);
  for (const text of [
    'Chód:',
    'Chód: -1',
    'Chód: Infinity',
    'Chód: 4\nchód: 5',
    'Chód: 1e3',
    'Chód: 9007199254740992',
  ])
    expect(() => parseActorDraft({ ...draft, speedsText: text })).toThrow();
  expect(draft.prepared!.enemy!.speeds).toEqual(template.speeds);
});
it('never interprets blank template HP/TT as zero or invents movement and requires a baseline for legacy actors', () => {
  expect(() =>
    parseEnemyTemplateDraft(
      {
        name: 'Test',
        category: 'other',
        size: 'Mały',
        tt: '',
        hpMax: '10',
        speedsText: '',
      },
      template.id,
    ),
  ).toThrow();
  const combat = sample();
  delete combat.actors[0]!.prepared;
  expect(() => resetEncounter(combat)).toThrow('Najpierw');
});
