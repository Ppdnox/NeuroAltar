import { expect, it } from 'vitest';
import {
  helpShortcut,
  adjacentCard,
  combatShortcut,
  type ShortcutInput,
} from '../src/domain/shortcuts';
const key: ShortcutInput = {
  key: ' ',
  code: 'Space',
  altKey: false,
  ctrlKey: false,
  metaKey: false,
  shiftKey: false,
  repeat: false,
  isComposing: false,
  defaultPrevented: false,
};
const outside = { editing: false, interactive: false, dialog: false };
it('space advances only outside controls and dialogs, without repeats or modifiers', () => {
  expect(combatShortcut(key, outside)).toBe('next-turn');
  for (const flag of ['editing', 'interactive', 'dialog'] as const)
    expect(combatShortcut(key, { ...outside, [flag]: true })).toBeNull();
  for (const flag of [
    'altKey',
    'ctrlKey',
    'metaKey',
    'shiftKey',
    'repeat',
    'isComposing',
    'defaultPrevented',
  ] as const)
    expect(combatShortcut({ ...key, [flag]: true }, outside)).toBeNull();
});
it('Alt arrows select cards, never a turn, and respect text editing/composition/dialogs', () => {
  const arrow = { ...key, key: 'ArrowDown', code: 'ArrowDown', altKey: true };
  expect(combatShortcut(arrow, outside)).toBe('next-card');
  expect(combatShortcut({ ...arrow, key: 'ArrowUp' }, outside)).toBe(
    'previous-card',
  );
  expect(combatShortcut(arrow, { ...outside, interactive: true })).toBe(
    'next-card',
  );
  for (const flag of ['editing', 'dialog'] as const)
    expect(combatShortcut(arrow, { ...outside, [flag]: true })).toBeNull();
  for (const flag of [
    'ctrlKey',
    'metaKey',
    'shiftKey',
    'repeat',
    'isComposing',
    'defaultPrevented',
  ] as const)
    expect(combatShortcut({ ...arrow, [flag]: true }, outside)).toBeNull();
  expect(combatShortcut({ ...arrow, altKey: false }, outside)).toBeNull();
});
it('card navigation follows supplied initiative order, includes unrolled actors, and stops at boundaries', () => {
  const ids = ['high', 'tie-first', 'tie-second', 'no-initiative'];
  expect(adjacentCard(ids, 'tie-first', 1)).toBe('tie-second');
  expect(adjacentCard(ids, 'high', -1)).toBe('high');
  expect(adjacentCard(ids, 'no-initiative', 1)).toBe('no-initiative');
  expect(adjacentCard(ids, 'missing', 1)).toBe('high');
  expect(adjacentCard([], null, 1)).toBeNull();
  expect(ids).toEqual(['high', 'tie-first', 'tie-second', 'no-initiative']);
});

it('F1 opens help only without another modal and ignores modified/repeated keys', () => {
  const help = { ...key, key: 'F1', code: 'F1' };
  expect(helpShortcut(help, false)).toBe(true);
  expect(helpShortcut(help, true)).toBe(false);
  expect(helpShortcut(key, false)).toBe(false);
  for (const flag of [
    'altKey',
    'ctrlKey',
    'metaKey',
    'shiftKey',
    'repeat',
    'isComposing',
    'defaultPrevented',
  ] as const)
    expect(helpShortcut({ ...help, [flag]: true }, false)).toBe(false);
});
