import { writeFileSync } from 'node:fs';
import { expect, it } from 'vitest';
import { deriveResources } from '../src/domain/character/resources';
import {
  conditionView,
  initialCondition,
  previewCondition,
  restDuration,
} from '../src/domain/character/condition';
import {
  newCharacter,
  type Ability,
  type Character,
  type CharacterSheet,
  type ClassId,
} from '../src/domain/character/model';
import type {
  ConditionAction,
  RestInput,
} from '../src/domain/character/conditionModel';
import { complete, fixture } from './helpers/character';

// Independent expectations transcribed from Neuroshima: Ostatnia Era, printed
// pp. 67–68, 72–75, 78–79, 86–88, 92–93. null means not yet acquired.
// The arrays deliberately do not reuse production formulas.
const classPools: [ClassId, string, string, number, (number | null)[]][] = [
  ['brutal', 'berserk', 'long', 67, [2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5]],
  ['brutal', 'rage', 'long', 67, [null, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]],
  ['cwaniak', 'motivation', 'short', 72, [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  ['cwaniak', 'luck', 'long', 72, [1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4]],
  ['cwaniak', 'heckle', 'short', 72, [null, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  [
    'cwaniak',
    'insult',
    'short',
    73,
    [null, null, null, null, 3, 3, 3, 3, 4, 4, 4, 4],
  ],
  ['spec', 'advice', 'short', 78, [2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4]],
  ['spec', 'defense', 'short', 78, [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  ['spec', 'brain', 'long', 78, [null, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4]],
  [
    'spec',
    'production',
    'short',
    79,
    [null, null, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  ],
  ['spec', 'hands', 'short', 79, [null, null, null, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  [
    'spec',
    'trajectory',
    'long',
    79,
    [null, null, null, null, null, null, 3, 3, 4, 4, 4, 4],
  ],
  ['twardziel', 'stamina', 'long', 86, [4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  ['twardziel', 'surge', 'short', 87, [null, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]],
  [
    'twardziel',
    'toughness',
    'long',
    87,
    [null, null, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
  ],
  ['zlodziej', 'cat', 'long', 92, [null, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4]],
  [
    'zlodziej',
    'matrix',
    'long',
    92,
    [null, null, null, null, null, null, 3, 3, 4, 4, 4, 4],
  ],
  [
    'zlodziej',
    'sapper',
    'short',
    93,
    [null, null, null, null, null, null, null, null, null, null, 1, 1],
  ],
];
function score(sheet: CharacterSheet, ability: Ability, value: number) {
  return {
    ...sheet,
    overrides: [
      {
        id: crypto.randomUUID(),
        target: `score:${ability}`,
        mode: 'replace' as const,
        value,
        reason: 'Test bieżącej cechy',
      },
    ],
  };
}
function profession(cls: ClassId, id: string, index: number) {
  const sheet = fixture(cls, 3);
  sheet.levels[2]!.choices = {
    profession: [id],
    'profession-ability': [`${id}.${index}`],
  };
  return sheet;
}
const specialPools: [CharacterSheet, string, number, string, number][] = [
  [profession('cwaniak', 'preacher', 0), 'amen', 4, 'long', 75],
  [profession('cwaniak', 'star', 3), 'concert', 1, 'day', 74],
  [profession('twardziel', 'cowboy', 0), 'clint', 1, 'encounter', 88],
  ...(
    [
      ['newyork', 'patriot', 'patriot', 'long', 63],
      ['hegemony', 'stubborn', 'stubborn', 'long', 63],
      ['saltlake', 'believe', 'believe', 'long', 64],
      ['vegas', 'luck', 'fart', 'short', 65],
    ] as const
  ).map(
    ([origin, choice, id, refresh, page]): [
      CharacterSheet,
      string,
      number,
      string,
      number,
    ] => {
      const sheet = fixture();
      sheet.originId = origin;
      sheet.levels[0]!.choices.origin = [choice];
      return [sheet, id, 1, refresh, page];
    },
  ),
];
const music = fixture();
music.levels[0]!.choices.start = ['musician'];
specialPools.push([music, 'song', 1, 'long', 105]);

it('matches the printed class tables and acquisition levels at every level 1–12', () => {
  for (const [cls, id, refresh, page, byLevel] of classPools) {
    for (const [index, max] of byLevel.entries()) {
      const actual = deriveResources(fixture(cls, index + 1)).find(
        (r) => r.id === id,
      );
      if (max === null)
        expect(actual, `${id} level ${index + 1}`).toBeUndefined();
      else
        expect(actual, `${id} level ${index + 1}`).toMatchObject({
          max,
          refresh,
          page,
        });
    }
  }
});

it('covers every profession, origin and feat pool without mistaking recipients or effects for uses', () => {
  for (const [sheet, id, max, refresh, page] of specialPools)
    expect(
      deriveResources(sheet).find((r) => r.id === id),
      id,
    ).toMatchObject({ max, refresh, page });
  expect(
    new Set([...classPools.map((x) => x[1]), ...specialPools.map((x) => x[1])])
      .size,
  ).toBe(26);
  // Muzyk (p.105): 1+CHA is recipient count; the performance pool stays one.
  for (const cha of [10, 14, 20])
    expect(
      deriveResources(score(music, 'cha', cha)).find((r) => r.id === 'song')
        ?.max,
    ).toBe(1);
});

it('uses current modifiers for all eight ability-based pools, with no invented minimum-one rule', () => {
  const pools: [CharacterSheet, string, Ability][] = [
    [fixture('cwaniak', 2), 'motivation', 'cha'],
    [fixture('cwaniak', 2), 'heckle', 'cha'],
    [fixture('spec', 4), 'defense', 'int'],
    [fixture('spec', 4), 'hands', 'dex'],
    [fixture('twardziel', 3), 'stamina', 'con'],
    [fixture('twardziel', 3), 'toughness', 'con'],
    [fixture('zlodziej', 2), 'cat', 'dex'],
    [profession('cwaniak', 'preacher', 0), 'amen', 'cha'],
  ];
  // Modifier table: scores <=10 give no uses; normal BG maximum20 gives5.
  // A supported manual override30 must remain representable rather than hard-capped5.
  const examples = [
    [1, 0],
    [8, 0],
    [10, 0],
    [12, 1],
    [14, 2],
    [16, 3],
    [18, 4],
    [20, 5],
    [30, 10],
  ] as const;
  for (const [sheet, id, ability] of pools)
    for (const [value, max] of examples)
      expect(
        deriveResources(score(sheet, ability, value)).find((r) => r.id === id)
          ?.max,
        `${id} score ${value}`,
      ).toBe(max);
});

it('uses total multiclass level for PB pools but only the relevant class level for class-sized pools', () => {
  // Printed p.59: PB follows total character level, not a single class level.
  // Spec2 / Brutal3 is PB3; Spec2 / Brutal7 is PB4. Berserk/rage use Brutal levels.
  for (const [brutal, advice, brain, berserk, rage] of [
    [3, 3, 3, 2, 3],
    [7, 4, 4, 4, 7],
  ]) {
    const sheet = fixture('spec', 2);
    sheet.levels.push(...fixture('brutal', brutal!).levels);
    const actual = Object.fromEntries(
      deriveResources(sheet).map((r) => [r.id, r.max]),
    );
    expect(actual).toMatchObject({ advice, brain, berserk, rage });
    expect(actual).not.toHaveProperty('production');
  }
});

function character(sheet: CharacterSheet): Character {
  const c = newCharacter();
  c.sheet = complete(sheet);
  c.sheet.hpCurrent = 1;
  c.draft = null;
  c.condition = initialCondition(c);
  return c;
}

it('keeps the daily concert separate from short/long rest and restores it only explicitly', () => {
  // Printed p.74: one four-hour concert per day. No income/time is applied by a dot click.
  const cases: unknown[] = [];
  const run = (c: Character, action: ConditionAction): Character => {
    const operationId = crypto.randomUUID();
    const result = previewCondition(c, action, operationId);
    const after = { ...c, condition: result.state };
    cases.push({
      before: c,
      action,
      context: result.context,
      operationId,
      after,
    });
    return after;
  };
  const fresh = character(profession('cwaniak', 'star', 3));
  const used = run(fresh, {
    type: 'resourceStep',
    id: 'concert',
    direction: 'use',
  });
  expect(used.condition!.worldMinutes).toBe(0);
  expect(used.inventory).toEqual(fresh.inventory);
  expect(used.condition!.spent.concert).toBe(1);
  expect(() =>
    run(used, { type: 'resourceStep', id: 'concert', direction: 'use' }),
  ).toThrow('Brak pozostałych');
  for (const kind of ['short', 'long'] as const) {
    const started = run(used, {
      type: 'restStart',
      id: crypto.randomUUID(),
      kind,
    });
    const rest: RestInput = {
      type: 'restApply',
      sessionId: started.condition!.rest!.id,
      outcome: 'complete',
      elapsed: restDuration('none')[kind],
      sleep: kind === 'long' ? 360 : 0,
      armored: false,
      consecutive: true,
      food: false,
      water: false,
      warm: false,
      exhaustionId: null,
      medicProficient: false,
      medicTools: false,
      healingSave: null,
      rolls6: [],
      rolls8: [],
      kolejkaLevel: 0,
      kolejkaRolls: [],
    };
    expect(run(started, rest).condition!.spent.concert).toBe(1);
  }
  const later = run(used, { type: 'worldTime', minutes: 1440 });
  expect(later.condition!.spent.concert).toBe(1);
  expect(
    run(later, { type: 'resourceStep', id: 'concert', direction: 'restore' })
      .condition!.spent.concert,
  ).toBe(0);
  expect(
    conditionView(fresh).resources.find((r) => r.id === 'concert')?.refresh,
  ).toBe('day');
  if (process.env.GENERATE_RESOURCE_HANDBOOK_FIXTURE)
    writeFileSync(
      'tests/fixtures/character-concert.json',
      JSON.stringify(cases, null, 2) + '\n',
    );
});
