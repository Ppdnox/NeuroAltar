import { expect, it } from 'vitest';
import {
  instantiateEnemy,
  nextCombatTurn,
  prepareCombat,
  resetEncounter,
  parseActorDraft,
  toActorDraft,
  type Combat,
} from '../src/domain/combat';
import {
  capabilities,
  consumeCapability,
  adjustResource,
  restoreBudget,
  refreshCapabilities,
  actionRestriction,
} from '../src/domain/capabilities';
import {
  capabilityStateSchema,
  instantiateCapabilities,
  parseCapabilityDraft,
  toCapabilityDraft,
  type CapabilitySetup,
} from '../src/domain/capabilitySchema';
import { applyInjuryLevel, setInjuryEnabled } from '../src/domain/injury';
import { newStatusDraft, parseStatusDraft } from '../src/domain/status';
const uuid = (n: number) =>
  `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
export const setup: CapabilitySetup = {
  legendaryMax: 3,
  resources: ['round', 'encounter', 'day', 'manual'].map((refreshRule, i) => ({
    id: uuid(i + 1),
    name: ['Impuls', 'Szarża', 'Regeneracja', 'Osłona'][i]!,
    maxValue: 3,
    refreshRule: refreshRule as 'round' | 'encounter' | 'day' | 'manual',
  })),
  abilities: [
    {
      id: uuid(10),
      name: 'Żądło',
      description: 'Zażółć\nMG wpisuje wynik.',
      kind: 'bonus',
      legendaryCost: 1,
      resourceId: uuid(1),
      resourceCost: 2,
    },
    {
      id: uuid(11),
      name: 'Ryk',
      description: 'Efekt opisowy',
      kind: 'legendary',
      legendaryCost: 2,
      resourceId: null,
      resourceCost: 1,
    },
  ],
};
export const enemy = () =>
  instantiateEnemy(
    {
      id: uuid(99),
      name: 'Żółw',
      category: 'beast',
      size: 'Duży',
      tt: 15,
      hpMax: 88,
      speeds: [],
      capabilities: setup,
    },
    0,
  );
const combat = (actors = [enemy()]): Combat => ({
  encounterId: 1,
  revision: 0,
  roundNumber: 1,
  currentTurnActorId: null,
  actors: actors.map((a, i) => ({
    ...a,
    initiativeValue: 12 - i,
    initiativeTieOrder: i,
  })),
});
it('uses both the correct budget and linked resource once, rejects exhausted costs, leaves base and other copies untouched', () => {
  const a = enemy();
  const b = enemy();
  const used = consumeCapability(a, uuid(10));
  expect(capabilities(used).budget.bonus).toBe(0);
  expect(capabilities(used).resources[0]!.currentValue).toBe(1);
  expect(capabilities(used).lastUse).toEqual({
    name: 'Żądło',
    kind: 'bonus',
    override: false,
  });
  expect(() => consumeCapability(used, uuid(10))).toThrow();
  expect(() => consumeCapability(used, uuid(10), true)).toThrow('Za mało');
  expect(used.hpCurrent).toBe(88);
  expect(used.enemy!.template).toEqual(a.enemy!.template);
  expect(used.prepared).toEqual(a.prepared);
  expect(capabilities(b).resources[0]!.currentValue).toBe(3);
  const legend = consumeCapability(a, uuid(11));
  expect(capabilities(legend).budget.legendary).toBe(1);
  expect(() => consumeCapability(legend, uuid(11))).toThrow();
});
it('blocks injury and incapacitating statuses but allows an explicit recorded GM exception without negative counters', () => {
  let a = applyInjuryLevel(setInjuryEnabled(enemy(), true), 3);
  expect(actionRestriction(a, 'reaction')).toContain('Zranienie');
  expect(actionRestriction(a, 'bonus')).toContain('Zranienie');
  expect(actionRestriction(a, 'action')).toBeNull();
  expect(() => consumeCapability(a, 'reaction')).toThrow();
  a = consumeCapability(a, 'reaction', true);
  a = consumeCapability(a, 'reaction', true);
  expect(capabilities(a).budget.reaction).toBe(0);
  expect(capabilities(a).usageNumber).toBe(2);
  expect(capabilities(a).lastUse!.override).toBe(true);
  expect(
    actionRestriction(restoreBudget(a, 'reaction'), 'reaction'),
  ).toBeTruthy();
  a = {
    ...enemy(),
    effects: [
      parseStatusDraft({ ...newStatusDraft(), systemKey: 'stunned' }, false),
    ],
  };
  for (const k of ['action', 'bonus', 'reaction', 'legendary'] as const)
    expect(actionRestriction(a, k)).toBeTruthy();
});
it('refreshes round resources and legendary pool only on wrap, and action/bonus/reaction only on the owners next ordinary start', () => {
  let a = consumeCapability(consumeCapability(enemy(), 'action'), 'reaction');
  a = consumeCapability(a, uuid(11));
  a = adjustResource(a, uuid(1), -1);
  a = adjustResource(a, uuid(2), -1);
  const b = enemy();
  const c = combat([a, b]);
  c.currentTurnActorId = a.id;
  const step = nextCombatTurn(c);
  expect(step.roundNumber).toBe(1);
  expect(capabilities(step.actors[0]!).budget).toEqual({
    action: 0,
    bonus: 1,
    reaction: 0,
    legendary: 1,
  });
  expect(capabilities(step.actors[0]!).resources[0]!.currentValue).toBe(2);
  const wrap = nextCombatTurn(step);
  expect(wrap.roundNumber).toBe(2);
  expect(capabilities(wrap.actors[0]!).budget).toEqual({
    action: 1,
    bonus: 1,
    reaction: 1,
    legendary: 3,
  });
  expect(
    capabilities(wrap.actors[0]!).resources.map((r) => r.currentValue),
  ).toEqual([3, 2, 3, 3]);
  expect(c.actors[0]!.enemy!.capabilities!.budget.action).toBe(0);
  const noInitiative = {
    ...adjustResource(b, uuid(1), -1),
    initiativeValue: null,
  };
  const single = nextCombatTurn({ ...c, actors: [c.actors[0]!, noInitiative] });
  expect(capabilities(single.actors[1]!).resources[0]!.currentValue).toBe(3);
});
it('first start and manual corrections do not refill round resources; day/encounter are explicit and reset restores depleted prepared values', () => {
  let a = enemy();
  for (const r of setup.resources) a = adjustResource(a, r.id, -1);
  a = consumeCapability(a, 'action');
  const c = combat([a]);
  const started = nextCombatTurn(c);
  expect(
    capabilities(started.actors[0]!).resources.map((r) => r.currentValue),
  ).toEqual([2, 2, 2, 2]);
  expect(capabilities(started.actors[0]!).budget.action).toBe(1);
  expect(
    capabilities(refreshCapabilities(a, 'day')).resources.map(
      (r) => r.currentValue,
    ),
  ).toEqual([2, 2, 3, 2]);
  expect(
    capabilities(refreshCapabilities(a, 'encounter')).resources.map(
      (r) => r.currentValue,
    ),
  ).toEqual([2, 3, 2, 2]);
  const prepared = prepareCombat(c);
  const full = nextCombatTurn({ ...prepared, currentTurnActorId: a.id });
  const reset = resetEncounter(full);
  expect(reset.actors[0]!.enemy!.capabilities).toEqual(a.enemy!.capabilities);
  expect(parseActorDraft(toActorDraft(a)).enemy!.capabilities).toEqual(
    a.enemy!.capabilities,
  );
});
it('validates config, costs, references and raw incomplete values; only explicit edits change maxima and counts', () => {
  const c = instantiateCapabilities(setup);
  const draft = toCapabilityDraft(c);
  draft.resources[0]!.maxValue = '';
  expect(() => parseCapabilityDraft(draft, c)).toThrow();
  draft.resources[0]!.maxValue = '1';
  expect(() => parseCapabilityDraft(draft, c)).toThrow();
  const d = toCapabilityDraft(c);
  d.abilities[0]!.resourceId = uuid(77);
  expect(() => parseCapabilityDraft(d, c)).toThrow();
  expect(
    capabilityStateSchema.safeParse({
      ...c,
      budget: { ...c.budget, action: 2 },
    }).success,
  ).toBe(false);
  expect(
    capabilityStateSchema.safeParse({ ...c, usageNumber: 1 }).success,
  ).toBe(false);
  expect(
    capabilityStateSchema.safeParse({
      ...c,
      resources: [...c.resources, c.resources[0]],
    }).success,
  ).toBe(false);
  const noLegend = {
    ...enemy(),
    enemy: {
      ...enemy().enemy!,
      capabilities: {
        ...instantiateCapabilities({
          ...setup,
          abilities: [],
          legendaryMax: 0,
        }),
      },
    },
  };
  expect(() => consumeCapability(noLegend, 'legendary', true)).toThrow(
    'Brak puli',
  );
});
it('refreshes exactly 3 per round while preserving 2 per encounter and an empty queue', () => {
  let a = enemy();
  a.enemy!.capabilities!.resources[1]!.maxValue = 2;
  a.enemy!.capabilities!.resources[1]!.currentValue = 2;
  for (let i = 0; i < 3; i++) a = adjustResource(a, uuid(1), -1);
  for (let i = 0; i < 2; i++) a = adjustResource(a, uuid(2), -1);
  const c = combat([a]);
  const first = nextCombatTurn(c);
  expect(
    capabilities(first.actors[0]!)
      .resources.slice(0, 2)
      .map((r) => r.currentValue),
  ).toEqual([0, 0]);
  const next = nextCombatTurn(first);
  expect(
    capabilities(next.actors[0]!)
      .resources.slice(0, 2)
      .map((r) => r.currentValue),
  ).toEqual([3, 0]);
  const noQueue = {
    ...c,
    currentTurnActorId: null,
    actors: [{ ...a, initiativeValue: null }],
  };
  expect(nextCombatTurn(noQueue)).toEqual(noQueue);
});
