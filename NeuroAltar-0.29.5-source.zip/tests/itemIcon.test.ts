import { describe, expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import moloch from '../src/data/equipment/moloch-city.v1.json';
import { itemSchema } from '../src/domain/item';
import {
  catalogEntry,
  starterPack,
} from '../src/domain/character/inventoryCatalog';
import { dedicatedItemIcon } from '../src/features/equipment/itemIcon';
import { itemIllustration } from '../src/features/equipment/itemPictogram';

const entries = [...catalog.entries, ...moloch.entries].map((entry) =>
  itemSchema.parse(entry),
);

describe('dedicated equipment art', () => {
  it('matches 256 source subjects and retains a pictogram for every other catalogue item', () => {
    expect(entries.filter((entry) => dedicatedItemIcon(entry))).toHaveLength(
      256,
    );
    for (const entry of entries) {
      expect(
        dedicatedItemIcon(entry) ?? itemIllustration(entry),
        entry.name,
      ).not.toBe('package');
    }
  });

  it('keeps weapon and ammunition names distinct and handles source spelling aliases', () => {
    expect(dedicatedItemIcon({ name: '.44 Magnum' })).toBe(
      'weapons/magnum_44.svg',
    );
    expect(dedicatedItemIcon({ name: '.44 Mag' })).toBe('ammo/ammo_44_mag.svg');
    expect(dedicatedItemIcon({ name: '7,62 x 39 mm AK' })).toBe(
      'ammo/ammo_7_62x39_mm.svg',
    );
    expect(dedicatedItemIcon({ name: 'PIŁOMIEC' })).toBe(
      'weapons/machine_sword.svg',
    );
    expect(dedicatedItemIcon({ name: 'Noktowizor' })).toBe(
      'items/loot/noktowizor_gogle.svg',
    );
  });

  it('covers inventory-specific dose, starter-pack and magazine labels without changing data', () => {
    const antibiotic = catalogEntry(
      entries.find((i) => i.name === 'Antybiotyk (10 dawek)')!,
    );
    const pack = starterPack('brutal');
    const snapshot = structuredClone({ antibiotic, pack });
    expect(dedicatedItemIcon(antibiotic.item)).toBe(
      'items/drugs/antybiotyk.svg',
    );
    expect(dedicatedItemIcon(pack.item)).toBe('items/loot/plecak_turysty.svg');
    expect(dedicatedItemIcon({ name: 'Magazynek — M14' })).toBe(
      'magazines/mag_assault_rifle.svg',
    );
    expect(dedicatedItemIcon({ name: 'Magazynek — B 92' })).toBe(
      'magazines/mag_handgun.svg',
    );
    for (const name of ['AK (Kałach)', 'Scar', 'AR', 'XM-8', 'Light Fifty']) {
      expect(dedicatedItemIcon({ name: `Magazynek — ${name}` })).toBe(
        'magazines/mag_assault_rifle.svg',
      );
    }
    expect({ antibiotic, pack }).toEqual(snapshot);
  });

  it('does not guess a dedicated asset for missing or custom subjects', () => {
    expect(dedicatedItemIcon({ name: 'Lina (15 m)' })).toBeUndefined();
    expect(dedicatedItemIcon({ name: 'Beamgun' })).toBeUndefined();
    expect(dedicatedItemIcon({ name: 'M14 z własną nazwą' })).toBeUndefined();
    expect(dedicatedItemIcon({ name: 'Własny wynalazek' })).toBeUndefined();
  });
});
