import { expect, it } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import { instantiateEnemy, type Combat } from '../src/domain/combat';
it('protects invalid SP on close, retains failed writes, retries and reloads independent runtime/prepared values', async () => {
  const actor = instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Żmija',
      category: 'beast',
      size: 'Mały',
      tt: 12,
      hpMax: 20,
      speeds: [],
      sp: 8,
    },
    0,
  );
  let disk: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: encounterId === 4 ? [actor] : [],
  }));
  let fail = false;
  const load = async () => structuredClone(disk);
  const save = async (c: Combat) => {
    if (fail) throw new Error('Disk full');
    const saved = { ...structuredClone(c), revision: c.revision + 1 };
    disk = disk.map((s) => (s.encounterId === c.encounterId ? saved : s));
    return saved.revision;
  };
  const store = createCombatStore(load, save);
  await store.getState().initialize();
  store.getState().editActor(4, actor.id, { spText: '2,' });
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().drafts[4]!.value.actors[0]!.spText).toBe('2,');
  store.getState().editActor(4, actor.id, { spText: '2,5' });
  fail = true;
  expect(await store.getState().flush(4)).toBe(false);
  expect(disk[3]!.actors[0]!.enemy!.sp).toBe(8);
  fail = false;
  expect(await store.getState().flush(4)).toBe(true);
  const reopen = createCombatStore(load, save);
  await reopen.getState().initialize();
  expect(reopen.getState().slots[3]!.actors[0]!.enemy!.sp).toBe(2.5);
  expect(reopen.getState().slots[3]!.actors[0]!.prepared!.enemy!.sp).toBe(8);
  expect(await reopen.getState().prepareClose()).toBe(true);
});
