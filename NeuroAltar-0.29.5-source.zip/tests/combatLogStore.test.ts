import { expect, it, vi } from 'vitest';
import { createCombatLogStore } from '../src/stores/combatLogStore';
import type { CombatLogEntry } from '../src/domain/combatLog';
const entry = (id: number, encounterId: 1 | 2 = 1): CombatLogEntry => ({
  id,
  encounterId,
  roundNumber: 1,
  actorId: null,
  eventType: 'reset',
  message: 'Reset potyczki.',
  payload: { before: null, after: null },
  createdAt: '2026-09-07T10:00:00.000Z',
});
it('ignores stale reads after refresh/clear and keeps other slots independent', async () => {
  let release!: (value: {
    entries: CombatLogEntry[];
    hasMore: boolean;
  }) => void;
  const load = vi.fn(async () => ({ entries: [entry(2)], hasMore: false }));
  load.mockImplementationOnce(
    () =>
      new Promise((resolve) => {
        release = resolve;
      }),
  );
  const store = createCombatLogStore(load);
  const old = store.getState().refresh(1);
  load.mockResolvedValueOnce({ entries: [], hasMore: false });
  await store.getState().refresh(1);
  release({ entries: [entry(1)], hasMore: false });
  await old;
  expect(store.getState().slots[1]!.entries).toEqual([]);
  load.mockResolvedValueOnce({ entries: [entry(3, 2)], hasMore: false });
  await store.getState().refresh(2);
  expect(store.getState().slots[1]!.entries).toEqual([]);
  expect(store.getState().slots[2]!.entries[0]!.id).toBe(3);
});
it('paginates with a cursor, preserves history on failure and allows retry', async () => {
  const load = vi.fn<
    (
      id: number,
      cursor?: number,
    ) => Promise<{ entries: CombatLogEntry[]; hasMore: boolean }>
  >(async () => ({
    entries: [entry(2)],
    hasMore: true,
  }));
  const store = createCombatLogStore(load);
  await store.getState().refresh(1);
  load.mockRejectedValueOnce('Błąd dysku');
  await store.getState().older(1);
  expect(store.getState().slots[1]).toMatchObject({
    status: 'error',
    error: 'Błąd dysku',
    entries: [entry(2)],
  });
  load.mockResolvedValueOnce({ entries: [entry(1)], hasMore: false });
  await store.getState().older(1);
  expect(load).toHaveBeenLastCalledWith(1, 2);
  expect(store.getState().slots[1]!.entries.map((e) => e.id)).toEqual([2, 1]);
});
