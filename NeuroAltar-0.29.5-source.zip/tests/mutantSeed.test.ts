import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/mutants.v1.json';
import machines from '../src/data/bestiary/machines.v1.json';
import monsters from '../src/data/bestiary/monsters.v1.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { templateDraft, filterCatalog } from '../src/domain/bestiary';
import { calculateWeaponAttackProfile } from '../src/domain/item';
import { instantiateEnemy, resetEncounter } from '../src/domain/combat';
import {
  consumeCapability,
  refreshCapabilities,
} from '../src/domain/capabilities';
import { prepareDeathBreath } from '../src/domain/deathBreath';

const entries = batch.entries.map((e) => ({
  ...e,
  template: enemyTemplateSchema.parse(e.template),
}));
const get = (key: string) => entries.find((e) => e.key === key)!.template;

it('inventories all seven handbook mutants with source values and round-trip editable statblocks', () => {
  expect(
    entries.map(({ key, source, template: t }) => [
      key,
      source.pdfPage,
      t.tt,
      t.hpMax,
      t.sp,
      t.loadout!.pb,
      t.injuryTrack!.enabled,
      t.cowardicePercent,
    ]),
  ).toEqual([
    ['nocny-ghul', 228, 9, 36, 3, 2, false, null],
    ['gadolud', 229, 13, 30, 12, 3, true, null],
    ['wilkolud', 229, 16, 64, 17, 3, true, null],
    ['grubas', 230, 16, 72, 16, 3, true, 25],
    ['techmutas', 231, 16, 30, 10, 3, false, 25],
    ['szpieg', 232, 13, 38, 8, 3, false, 50],
    ['mesmeryta', 233, 19, 112, 75, 5, true, 50],
  ]);
  expect(
    new Set(
      [...entries, ...machines.entries, ...monsters.entries].map(
        (e) => e.template.id,
      ),
    ).size,
  ).toBe(30);
  expect(batch.sourceSha256).toBe(machines.sourceSha256);
  for (const { template: t, source } of entries) {
    expect(t.category).toBe('mutant');
    expect(source.pdfPage).toBe(source.printedPage + 2);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toEqual(t);
    expect(Object.values(t.statblock!.abilityScores)).not.toContain(null);
    expect(t.failureThreshold).toBeNull();
    expect(instantiateEnemy(t, 0).initiativeValue).toBeNull();
  }
  const catalog = [...entries, ...machines.entries, ...monsters.entries].map(
    (e) => ({ template: enemyTemplateSchema.parse(e.template), revision: 0 }),
  );
  expect(filterCatalog(catalog, '', 'mutant', '')).toHaveLength(7);
  expect(filterCatalog(catalog, 'Mesmeryta', 'mutant', '')).toHaveLength(1);
});

it('preserves final defenses, unusual printed initiative/HP, conditional rules and save-only actions without guessed bonuses', () => {
  expect(get('mesmeryta').statblock!.savingThrows).toEqual({
    str: null,
    dex: 8,
    con: null,
    int: null,
    wis: null,
    cha: 10,
  });
  expect(get('techmutas').tt).toBe(16);
  expect(get('mesmeryta').tt).toBe(19);
  expect(get('grubas').statblock!.damageThreshold).toBe(10);
  expect(get('gadolud').statblock!.resistances).toEqual([
    'kłute',
    'cięte',
    'obuchowe',
    'od trucizny',
  ]);
  expect(get('wilkolud').statblock!.resistances).toBeNull();
  expect(get('wilkolud').statblock!.traits!.join('\n')).toContain('-3 (7)');
  expect(get('szpieg').statblock!.traits!.join('\n')).toContain(
    '38 (6k8 + 14)',
  );
  expect(get('techmutas').statblock!.skills).toContain(
    'Narzędzia małego elektronika +8 lub narzędzia małego mechanika +8',
  );
  expect(get('gadolud').speeds).toEqual([
    { mode: 'Chód', meters: 12 },
    { mode: 'Pływanie', meters: 12 },
    { mode: 'Wspinanie', meters: 12 },
  ]);
  expect(get('nocny-ghul').loadout!.items[0]!.item.description).toContain(
    '3 (1k6) radioaktywne',
  );
  expect(get('gadolud').loadout!.items[1]!.item.description).toContain(
    '5 (1k10) od trucizny',
  );
  const chain = get('grubas').loadout!.items[0]!.item;
  expect(chain.weaponProfile).toBeUndefined();
  expect(chain.description).toContain('Atak wręcz +9');
  expect(chain.description).toContain('TT 19, PW 10');
  for (const key of ['techmutas', 'mesmeryta'])
    expect(get(key).loadout!.items.every((e) => !e.item.weaponProfile)).toBe(
      true,
    );
  expect(
    get('mesmeryta').capabilities!.abilities.find(
      (a) => a.name === 'Ściana żaru',
    )!.description,
  ).toContain('12 (3k8)');
});

it('matches printed attack bonuses and damage formulas without changing dual damage or fixed damage to extra dice', () => {
  const expected = [[5], [6, 6], [7, 7], [9, 9, 9], [], [6, 4], []];
  for (const [i, { template: t }] of entries.entries()) {
    expect(
      t
        .loadout!.items.filter((e) => e.item.weaponProfile)
        .map((e) => calculateWeaponAttackProfile(e, t.loadout!).attack),
    ).toEqual(expected[i]);
  }
  expect(
    get('szpieg').loadout!.items[0]!.item.weaponProfile!.damageModes[0],
  ).toMatchObject({ dice: '4', average: 4, damageType: 'kłute' });
  expect(get('grubas').loadout!.items[3]!.item.weaponProfile).toMatchObject({
    abilityRule: 'str',
    attackKind: 'ranged',
    range: { normal: 60, long: 180 },
  });
});

it('keeps Mesmeryta daily reinforcements separate from reaction/legendary budgets and leaves copies, HP and prepared state unchanged', () => {
  const t = get('mesmeryta'),
    before = structuredClone(t),
    b = instantiateEnemy(t, 1);
  let a = instantiateEnemy(t, 0);
  const id = (name: string) =>
    t.capabilities!.abilities.find((v) => v.name === name)!.id;
  a = consumeCapability(a, id('Posiłki'));
  a = refreshCapabilities(a, 'turn');
  a = consumeCapability(a, id('Posiłki'));
  a = refreshCapabilities(a, 'turn');
  expect(() => consumeCapability(a, id('Posiłki'))).toThrow();
  expect(
    refreshCapabilities(a, 'encounter').enemy!.capabilities!.resources[0]!
      .currentValue,
  ).toBe(0);
  a = consumeCapability(a, id('Iluzoryczny cel'));
  expect(() => consumeCapability(a, id('Iluzoryczny cel'))).toThrow();
  for (const name of ['Pokłoń się!', 'Stój!', 'Iluzoryczna niewidzialność'])
    a = consumeCapability(a, id(name));
  expect(() => consumeCapability(a, id('Stój!'))).toThrow();
  a = refreshCapabilities(a, 'round');
  expect(a.enemy!.capabilities!.budget.legendary).toBe(3);
  expect(a.enemy!.capabilities!.resources[0]!.currentValue).toBe(0);
  expect(
    refreshCapabilities(a, 'day').enemy!.capabilities!.resources[0]!
      .currentValue,
  ).toBe(2);
  expect(a.hpCurrent).toBe(112);
  expect(a.effects).toEqual(b.effects);
  expect(b.enemy!.capabilities!.resources[0]!.currentValue).toBe(2);
  expect(t).toEqual(before);
  const reset = resetEncounter({
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [a, b],
  });
  expect(reset.actors[0]!.enemy!.capabilities!.resources[0]!.currentValue).toBe(
    2,
  );
  expect(reset.actors[0]!.enemy!.capabilities!.budget.legendary).toBe(3);
});

it('allows a reviewed Death Breath copy of the new mutant host without mutating its catalog or combat copy', () => {
  const host = get('szpieg'),
    before = structuredClone(host),
    actor = instantiateEnemy(host, 0);
  const melee = host.capabilities!.abilities.find(
    (a) => a.name === 'Stalowe pięści',
  )!.id;
  const zombie = parseEnemyTemplateDraft(
    prepareDeathBreath(host, [melee]),
    crypto.randomUUID(),
  );
  expect(zombie).toMatchObject({
    category: 'monster',
    hpMax: 38,
    tt: 11,
    sp: 10,
  });
  expect(zombie.capabilities!.abilities.map((a) => a.name)).toContain(
    'Stalowe pięści',
  );
  expect(host).toEqual(before);
  expect(actor.enemy!.template).toEqual(before);
});
