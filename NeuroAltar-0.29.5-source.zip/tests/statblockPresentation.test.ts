import { presentRule } from '../src/domain/presentation';
import { readFileSync } from 'node:fs';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { expect, it } from 'vitest';
import { enemyTemplateSchema } from '../src/domain/enemy';
import { StatblockSummary } from '../src/features/statblocks/StatblockSummary';
import { CapabilitySummary } from '../src/features/statblocks/CapabilitySummary';
import { AttackProfiles } from '../src/features/equipment/AttackProfiles';
import { RuleText } from '../src/features/statblocks/RuleText';
const templates = ['machines', 'monsters'].flatMap((batch) => {
  const data = JSON.parse(
    readFileSync(
      new URL(`../src/data/bestiary/${batch}.v1.json`, import.meta.url),
      'utf8',
    ),
  );
  return data.entries.map((entry: { template: unknown }) =>
    enemyTemplateSchema.parse(entry.template),
  );
});
const plain = (html: string) =>
  html
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'");
it('retains every handbook rule and action condition while separating presentation', () => {
  for (const t of templates) {
    const before = JSON.stringify(t);
    const html = renderToStaticMarkup(
      createElement(StatblockSummary, { value: t.statblock }),
    );
    for (const rule of t.statblock?.traits ?? [])
      expect(plain(html)).toContain(presentRule(rule));
    if (t.capabilities) {
      const actions = plain(
        renderToStaticMarkup(
          createElement(CapabilitySummary, { value: t.capabilities }),
        ),
      );
      for (const a of t.capabilities.abilities) {
        expect(actions).toContain(a.name);
        expect(actions).toContain(presentRule(a.description));
      }
    }
    expect(JSON.stringify(t)).toBe(before);
  }
});
it('keeps all six Mobsprzęt weapons and its manual selection rule', () => {
  const t = templates.find((t) => t.name === 'Mobsprzęt')!;
  expect(t.loadout!.items).toHaveLength(6);
  const weapons = plain(
    renderToStaticMarkup(
      createElement(AttackProfiles, { loadout: t.loadout! }),
    ),
  );
  for (const item of t.loadout!.items)
    expect(weapons).toContain(item.item.name);
  const block = plain(
    renderToStaticMarkup(
      createElement(StatblockSummary, { value: t.statblock }),
    ),
  );
  expect(block).toContain('k6');
});
it('preserves multiline user text, punctuation and escapes markup', () => {
  const text =
    'Warunek: 1,5 m; tylko w nocy.\nDrugi wiersz <script> & wyjątek.';
  const html = renderToStaticMarkup(createElement(RuleText, { text }));
  expect(plain(html)).toBe(text);
  expect(html).not.toContain('<script>');
});
it('distinguishes an explicit zero threshold, no defenses and unknown data', () => {
  const t = templates[0]!;
  const html = plain(
    renderToStaticMarkup(
      createElement(StatblockSummary, {
        value: {
          ...t.statblock!,
          damageThreshold: 0,
          vulnerabilities: [],
          resistances: null,
        },
      }),
    ),
  );
  expect(html).toContain('Próg Obrażeń 0');
  expect(html).toContain('Brak');
  expect(html).toContain('N/D');
  expect(renderToStaticMarkup(createElement(StatblockSummary, {}))).toContain(
    'N/D',
  );
});
