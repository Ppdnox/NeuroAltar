import { describe, expect, it } from 'vitest';
import {
  ABILITIES,
  CLASSES,
  COLORS,
  newSheet,
  withGameColor,
  type GameColor,
} from '../src/domain/character/model';
import {
  deriveCharacter,
  deriveWeapon,
  modifier,
  proficiencyBonus,
} from '../src/domain/character/derive';
import {
  classes,
  origins,
  professions,
  skills,
  tools,
} from '../src/domain/character/catalog';
import { feats } from '../src/domain/character/feats';

import { fixture, complete } from './helpers/character';
describe('character mechanics, handbook BG and color matrices', () => {
  it.each([
    [8, -1],
    [9, -1],
    [10, 0],
    [17, 3],
    [20, 5],
    [null, null],
  ])('floors modifier %s to %s', (score, result) =>
    expect(modifier(score)).toBe(result),
  );
  it('keeps unknown values unknown, validates arrays, point buy and the original favorite', () => {
    const s = newSheet();
    expect(deriveCharacter(s).hpMax.value).toBeNull();
    s.baseScores = { str: 15, dex: 15, con: 15, int: 8, wis: 8, cha: 8 };
    s.method = 'points';
    expect(deriveCharacter(s).pointTotal).toBe(27);
    s.baseScores.int = 9;
    expect(
      deriveCharacter(s).issues.some((i) => i.path === 'creation-method'),
    ).toBe(true);
    s.method = 'array-b';
    s.baseScores.int = 8;
    expect(
      deriveCharacter(s).issues.some((i) => i.path === 'creation-method'),
    ).toBe(false);
    s.baseScores.str = 14;
    s.originId = 'appalachia';
    expect(
      deriveCharacter(s).issues.some((i) => i.path === 'ability-str'),
    ).toBe(true);
  });
  it.each(CLASSES)(
    'offers a complete start and 12 class levels for %s',
    (id) => {
      const s = complete(fixture(id, 12)),
        d = deriveCharacter(s);
      expect(d.issues).toEqual([]);
      expect(d.classLevels[id]).toBe(12);
      expect(d.pb).toBe(4);
      expect(
        d.grants.some((g) => g.target === 'save:' + classes[id].saves[0]),
      ).toBe(true);
      expect(d.hitDice[classes[id].hitDie]).toBe(12);
    },
  );
  it('covers the full names catalog and corrected profession choices', () => {
    expect(origins).toHaveLength(12);
    expect(origins.flatMap((o) => o.choices)).toHaveLength(36);
    expect(Object.keys(professions)).toHaveLength(18);
    expect(feats).toHaveLength(53);
    expect(skills).toHaveLength(18);
    expect(tools).toHaveLength(22);
    expect(tools.find((t) => t.id === 'electronics')?.ability).toBe('dex');
    for (const classId of CLASSES)
      for (const profession of classes[classId].professions) {
        const s = fixture(classId, 3);
        s.levels[2]!.choices.profession = [profession];
        const d = deriveCharacter(complete(s));
        expect(d.issues).toEqual([]);
        const abilities = d.choices.find(
          (c) => c.key === 'profession-ability',
        )!;
        expect(abilities.options).toHaveLength(
          professions[profession]!.abilities.length,
        );
      }
  });
  it('uses Samouk 9 and profession selections at Twardziel 3/7/11', () => {
    expect(
      deriveCharacter(complete(fixture('cwaniak', 8))).rules.some(
        (r) => r.label === 'Samouk',
      ),
    ).toBe(false);
    expect(
      deriveCharacter(complete(fixture('cwaniak', 9))).rules.some(
        (r) => r.label === 'Samouk',
      ),
    ).toBe(true);
    const d = deriveCharacter(complete(fixture('twardziel', 12)));
    expect(
      d.choices
        .filter((c) => c.key === 'profession-ability')
        .map((c) => c.level + 1),
    ).toEqual([3, 7, 11]);
    expect(
      d.choices.filter((c) => c.key === 'feat').map((c) => c.level + 1),
    ).toEqual([4, 6, 8, 10, 12]);
  });
  it('multiclasses with ordered hit dice, no repeated initial HP, no new saves', () => {
    const s = fixture('brutal', 5);
    s.originId = 'miami';
    s.baseScores.con = 14;
    s.levels[3]!.classId = 'zlodziej';
    s.levels[4]!.classId = 'zlodziej';
    const d = deriveCharacter(s);
    expect(d.hpMax.value).toBe(40);
    expect(d.hitDice).toEqual({ 6: 2, 8: 3 });
    expect(d.pb).toBe(3);
    expect(d.grants.some((g) => g.target === 'save:int')).toBe(false);
    s.hpCurrent = 9;
    s.baseScores.con = 16;
    expect(deriveCharacter(s).hpMax.value).toBe(45);
    expect(s.hpCurrent).toBe(9);
  });
  it.each([
    ['none', 47],
    ['rust', 39],
    ['mercury', 35],
    ['steel', 51],
    ['chrome', 55],
  ] as [GameColor, number][])(
    'computes fixed %s color with no first-level penalty',
    (color, hp) => {
      const s = fixture('twardziel', 5);
      s.originId = 'miami';
      s.baseScores.con = 16;
      s.levels = s.levels.map((l) => ({ ...l, color }));
      expect(deriveCharacter(s).hpMax.value).toBe(hp);
      s.baseScores.con = 18;
      expect(deriveCharacter(s).hpMax.value).toBe(hp + 5);
    },
  );
  it('preserves mixed color history and current HP, with explicit retrospective preview', () => {
    const s = fixture('twardziel', 3);
    s.originId = 'miami';
    s.baseScores.con = 16;
    s.hpCurrent = 11;
    s.levels[1]!.color = 'rust';
    s.levels[2]!.color = 'steel';
    expect(deriveCharacter(s).hpMax.value).toBe(32);
    const prospective = withGameColor(s, 'chrome', false);
    expect(deriveCharacter(prospective).hpMax.value).toBe(32);
    expect(prospective.hpCurrent).toBe(11);
    const retrospective = withGameColor(s, 'chrome', true);
    expect(deriveCharacter(retrospective).hpMax.value).toBe(37);
    expect(s.levels[1]!.color).toBe('rust');
  });
  it('applies the user ruling minimum zero separately on each later level', () => {
    for (const color of COLORS) {
      const s = fixture('spec', 3);
      s.originId = 'miami';
      s.baseScores.con = 6;
      s.levels = s.levels.map((l) => ({ ...l, color }));
      const h = deriveCharacter(s).hpHistory;
      expect(h[0]!.value).toBe(10);
      expect(h[1]!.value).toBeGreaterThanOrEqual(0);
    }
    const s = fixture('spec', 3);
    s.originId = 'miami';
    s.baseScores.con = 6;
    s.levels[1]!.color = 'mercury';
    s.levels[2]!.color = 'steel';
    expect(deriveCharacter(s).hpMax.value).toBe(12);
  });
  it('adds two doubling bonuses and retains precise jump distances', () => {
    const s = fixture();
    s.originId = 'appalachia';
    s.baseScores.str = 13;
    s.levels[0]!.choices = {
      origin: ['miner'],
      start: ['packing'],
      'start-ability': ['int'],
    };
    const d = deriveCharacter(s);
    expect(d.carry.value).toBe(210);
    expect(d.maxCarry.value).toBe(420);
    expect(d.longJump.value).toBeCloseTo(4.2);
    expect(d.highJump.value).toBeCloseTo(1.2);
  });
  it('never stacks repeated PB and preserves expertise when changing test ability', () => {
    const s = fixture('spec', 7);
    s.originId = 'miami';
    s.baseScores.int = 16;
    s.baseScores.str = 14;
    s.levels[0]!.choices['class-skills'] = ['medicine', 'history'].map(
      (x) => 'skill:' + x,
    );
    s.levels[6]!.choices.expertise = ['skill:medicine', 'skill:history'];
    const d = deriveCharacter(s);
    expect(d.check('skill:medicine', 'int').value).toBe(9);
    expect(d.check('skill:medicine', 'str').value).toBe(8);
  });
  it('validates feats before their own increase and disallows duplicate tricks', () => {
    const s = fixture();
    s.originId = 'miami';
    s.baseScores.dex = 15;
    s.levels[0]!.choices.start = ['gunfight'];
    const d = deriveCharacter(s);
    expect(d.issues.some((i) => i.path === 'level-0-start')).toBe(true);
    expect(d.scores.dex.value).toBe(16);
    s.levels = Array.from({ length: 4 }, () => ({
      classId: 'brutal',
      color: 'none',
      contextRevision: 0,
      choices: {},
    }));
    s.levels[0]!.choices = { start: ['grenadier'] };
    s.levels[3]!.choices = { feat: ['grenadier'] };
    expect(
      deriveCharacter(s).issues.some((i) => i.path === 'level-3-feat'),
    ).toBe(true);
  });
  it('derives separate armor bases and initiative/PP bonuses without automatic checks', () => {
    const s = fixture('brutal', 1);
    s.originId = 'miami';
    s.baseScores = { str: 15, dex: 15, con: 14, int: 10, wis: 15, cha: 16 };
    s.levels[0]!.choices = {
      start: ['instinct'],
      'class-skills': ['skill:perception', 'skill:athletics'],
    };
    const d = deriveCharacter(s);
    expect(d.armor.find((a) => a.id === 'bare')?.result.value).toBe(15);
    expect(d.initiative.value).toBe(8);
    expect(d.perception.value).toBe(19);
    expect(deriveWeapon(3, 2, true)).toEqual({ attack: 5, damageModifier: 3 });
    expect(deriveWeapon(3, 2, false)).toEqual({ attack: 3, damageModifier: 3 });
    expect(deriveWeapon(3, 2, true, true).damageModifier).toBe(0);
  });
  it('applies named MG corrections once and rejects missing reasons', () => {
    const s = fixture();
    s.overrides = [
      {
        id: crypto.randomUUID(),
        target: 'hpMax',
        mode: 'add',
        value: 5,
        reason: 'Nagroda MG',
      },
    ];
    const d = deriveCharacter(s);
    expect(d.hpMax.components.at(-1)?.source).toContain('Nagroda MG');
    expect(deriveCharacter(structuredClone(s)).hpMax.value).toBe(d.hpMax.value);
    s.overrides[0]!.reason = '';
    expect(deriveCharacter(s).issues.some((i) => i.path === 'overrides')).toBe(
      true,
    );
  });
  it('validates XP thresholds, duplicates and snapshots without an implicit level-up', () => {
    expect([4, 5, 8, 9].map(proficiencyBonus)).toEqual([2, 3, 3, 4]);
    const s = fixture();
    s.advancementMode = 'xp';
    const id = crypto.randomUUID();
    s.xp = [{ id, amount: 49, reason: 'Sesja' }];
    expect(deriveCharacter(s).xpLevel).toBe(1);
    s.xp[0]!.amount = 50;
    expect(deriveCharacter(s).xpLevel).toBe(2);
    expect(s.levels).toHaveLength(1);
    s.xp.push({ ...s.xp[0]! });
    expect(deriveCharacter(s).issues.some((i) => i.path === 'xp')).toBe(true);
    expect(ABILITIES).toHaveLength(6);
  });
});

it('does not apply armor training to unarmored TT', () => {
  const s = fixture('twardziel');
  s.levels[0]!.choices.wyjadacz = ['armor'];
  const d = deriveCharacter(complete(s));
  expect(d.armor[0]!.result.value).toBe(14);
});
it('allows a later-listed profession ability at level three and uses Dexterity for rat jumps', () => {
  const s = fixture('zlodziej', 3);
  s.baseScores.str = 10;
  s.baseScores.dex = 16;
  s.levels[2]!.choices.profession = ['rat'];
  s.levels[2]!.choices['profession-ability'] = ['rat.3'];
  const d = deriveCharacter(complete(s));
  expect(d.issues).toEqual([]);
  expect(d.longJump.value).toBeCloseTo(4.8);
  expect(d.highJump.value).toBeCloseTo(1.5);
  expect(d.climb).toBe(d.speed.value);
  s.baseScores.dex = null;
  expect(deriveCharacter(s).longJump.value).toBeNull();
});
it('applies Szary as an extra chosen mental modifier and records the correct handbook page', () => {
  const s = fixture('zlodziej', 3);
  s.levels[2]!.choices.profession = ['rat'];
  s.levels[2]!.choices['profession-ability'] = ['rat.1'];
  s.levels[2]!.choices['profession-ability-grey'] = ['wis'];
  const d = deriveCharacter(complete(s));
  const result = d.check('skill:stealth', 'dex');
  expect(result.components.find((p) => p.source === 'Szary')?.value).toBe(
    d.modifiers.wis,
  );
  expect(d.rules.find((r) => r.id === 'profession.rat.1')?.page).toBe(94);
});

it('accepts XP and level advancement without a reason while enforcing XP thresholds', () => {
  const s = complete(fixture('brutal', 2));
  s.advancementMode = 'xp';
  s.xp = [{ id: crypto.randomUUID(), amount: 50, reason: '' }];
  expect(deriveCharacter(s).issues).toEqual([]);
  expect(deriveCharacter(s).xpLevel).toBe(2);
  s.xp[0]!.amount = 49;
  expect(deriveCharacter(s).issues.some((i) => i.path === 'xp')).toBe(true);
});
