import { describe, expect, it } from 'vitest';
import { classes, origins, professions } from '../src/domain/character/catalog';
import { feats } from '../src/domain/character/feats';
import { ruleIllustration } from '../src/features/character/ruleIconMapping';

describe('dedicated character rule art', () => {
  it('covers every current rule except the generic origin-choice prompt', () => {
    const ids = [
      ...Object.entries(classes).flatMap(([id, definition]) =>
        Object.entries(definition.progression).flatMap(([level, labels]) =>
          labels.map((_, index) => `class.${id}.${level}.${index}`),
        ),
      ),
      ...Object.entries(professions).flatMap(([id, definition]) =>
        definition.abilities.map((_, index) => `profession.${id}.${index}`),
      ),
      ...origins.flatMap((origin) =>
        origin.choices.map((choice) => `origin.${origin.id}.${choice.id}`),
      ),
      ...feats.map((feat) => `feat.${feat.id}`),
    ];
    expect(ids.filter((id) => !ruleIllustration(id))).toEqual([
      'class.spec.5.1',
    ]);
  });

  it('keeps class-specific versions of the same feature distinct', () => {
    expect(ruleIllustration('class.spec.7.0')).toBe(
      'abilities/specjalizacja-spec.svg',
    );
    expect(ruleIllustration('class.zlodziej.1.0')).toBe(
      'abilities/specjalizacja-zlodziej.svg',
    );
    expect(ruleIllustration('class.zwiadowca.2.1')).toBe(
      'abilities/wyjadacz-zwiadowca.svg',
    );
    expect(ruleIllustration('class.twardziel.1.0')).toBe(
      'abilities/wyjadacz.svg',
    );
    expect(ruleIllustration('class.twardziel.1.2')).toBe(
      'abilities/ulubiona-bron-twardziel.svg',
    );
    expect(ruleIllustration('class.zlodziej.2.0')).toBe(
      'abilities/ulubiona-bron-zlodziej.svg',
    );
    expect(ruleIllustration('class.zwiadowca.1.2')).toBe(
      'abilities/ulubiona-bron-zwiadowca.svg',
    );
  });

  it('uses explicit aliases and falls back safely for an unknown rule', () => {
    expect(ruleIllustration('origin.hegemony.dog')).toBe(
      'abilities/zjadlem-wlasnego-psa.svg',
    );
    expect(ruleIllustration('feat.plug')).toBe('abilities/plug-and-play.svg');
    expect(ruleIllustration('custom.unknown')).toBeUndefined();
    expect(ruleIllustration('../weapons/any.svg')).toBeUndefined();
  });
});
