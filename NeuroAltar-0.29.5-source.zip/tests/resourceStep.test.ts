import { expect, it } from 'vitest';
import {
  conditionContext,
  conditionView,
  initialCondition,
  previewCondition,
  restDuration,
} from '../src/domain/character/condition';
import {
  conditionActionSchema,
  type ConditionAction,
  type RestInput,
} from '../src/domain/character/conditionModel';
import {
  newCharacter,
  type Character,
  type CharacterMutation,
  type ClassId,
} from '../src/domain/character/model';
import { complete, fixture } from './helpers/character';
import { createCharacterStore } from '../src/stores/characterStore';

function character(cls: ClassId = 'brutal', level = 4): Character {
  const c = newCharacter();
  c.sheet = complete(fixture(cls, level));
  c.sheet.hpCurrent = 3;
  c.draft = null;
  c.condition = initialCondition(c);
  return c;
}
function apply(c: Character, action: ConditionAction): Character {
  return {
    ...c,
    condition: previewCondition(c, action, crypto.randomUUID()).state,
  };
}
const step = (c: Character, id: string, direction: 'use' | 'restore') =>
  apply(c, { type: 'resourceStep', id, direction });
const left = (c: Character, id: string) => {
  const view = conditionView(c);
  return Math.max(
    0,
    view.resources.find((r) => r.id === id)!.max - (view.state.spent[id] ?? 0),
  );
};

it('one click changes only the named pool and appends history without healing or normalizing other state', () => {
  const c = character('twardziel', 3);
  c.condition!.combatHealth = {
    bleeding: true,
    successes: 1,
    failures: 1,
    stable: false,
    dead: false,
  };
  c.condition!.fuks.push({
    id: crypto.randomUUID(),
    source: 'Dawny Fuks',
    kind: 'manual',
    expiresAt: 0,
    session: null,
  });
  c.condition!.spent.toughness = 2;
  const before = structuredClone(c);
  const used = step(c, 'stamina', 'use');
  expect(c).toEqual(before);
  expect(used.condition).toEqual({
    ...before.condition,
    spent: { ...before.condition!.spent, stamina: 1 },
    journal: [expect.objectContaining({ text: 'Kondycha: użyto 1' })],
  });
  const restored = step(used, 'stamina', 'restore');
  expect(restored.condition).toEqual({
    ...used.condition,
    spent: { ...used.condition!.spent, stamina: 0 },
    journal: [
      ...used.condition!.journal,
      expect.objectContaining({ text: 'Kondycha: przywrócono 1' }),
    ],
  });
});

it('rejects empty pools, extra restores, unknown resources and malformed direction without a reason field', () => {
  let c = character();
  expect(() => step(c, 'berserk', 'restore')).toThrow('Wszystkie użycia');
  for (let i = 0; i < 3; i++) c = step(c, 'berserk', 'use');
  expect(left(c, 'berserk')).toBe(0);
  expect(() => step(c, 'berserk', 'use')).toThrow('Brak pozostałych');
  for (const direction of ['use', 'restore'] as const)
    expect(() => step(c, 'unknown', direction)).toThrow('nie jest dostępna');
  const zero = character('cwaniak');
  zero.sheet!.baseScores.cha = 8;
  expect(() => step(zero, 'motivation', 'use')).toThrow('Brak pozostałych');
  expect(
    conditionActionSchema.safeParse({
      type: 'resourceStep',
      id: 'berserk',
      direction: 'reset',
    }).success,
  ).toBe(false);
  expect(
    conditionActionSchema.safeParse({
      type: 'resourceStep',
      id: 'berserk',
      direction: 'use',
      amount: 20,
    }).success,
  ).toBe(false);
});

it('scales 3 to 5 uses on advancement without refilling spent uses and preserves debt when the maximum falls', () => {
  let c = step(character('brutal', 4), 'berserk', 'use');
  expect(left(c, 'berserk')).toBe(2);
  const spent = structuredClone(c.condition!.spent);
  c.sheet = complete(fixture('brutal', 10));
  expect(conditionView(c).resources.find((r) => r.id === 'berserk')!.max).toBe(
    5,
  );
  expect(left(c, 'berserk')).toBe(4);
  expect(c.condition!.spent).toEqual(spent);
  for (let i = 0; i < 3; i++) c = step(c, 'berserk', 'use');
  c.sheet = complete(fixture('brutal', 1));
  expect(left(c, 'berserk')).toBe(0);
  expect(c.condition!.spent.berserk).toBe(4);
  expect(() => step(c, 'berserk', 'use')).toThrow();
  c = step(c, 'berserk', 'restore');
  expect(c.condition!.spent.berserk).toBe(3);
  expect(left(c, 'berserk')).toBe(0);
  c = step(step(c, 'berserk', 'restore'), 'berserk', 'restore');
  expect(left(c, 'berserk')).toBe(1);
});

it('supports existing custom counters and refuses draft or archived cards', () => {
  const c = character();
  const id = crypto.randomUUID();
  c.condition!.manual.push({ id, label: 'Baterie testowe', max: 2 });
  const used = step(c, id, 'use');
  expect(used.condition!.spent[id]).toBe(1);
  expect(step(used, id, 'restore').condition!.spent[id]).toBe(0);
  expect(() => step({ ...c, draft: c.sheet }, id, 'use')).toThrow();
  expect(() => step({ ...c, archived: true }, id, 'use')).toThrow();
});

it('keeps short and long rest regeneration rules for the same counters', () => {
  function rest(c: Character, kind: 'short' | 'long') {
    const started = apply(c, {
      type: 'restStart',
      id: crypto.randomUUID(),
      kind,
    });
    const action: RestInput = {
      type: 'restApply',
      sessionId: started.condition!.rest!.id,
      outcome: 'complete',
      elapsed: restDuration(c.sheet!.rulesContext.gameColor)[kind],
      sleep: kind === 'long' ? 360 : 0,
      armored: false,
      consecutive: true,
      food: false,
      water: false,
      warm: false,
      exhaustionId: null,
      medicProficient: false,
      medicTools: false,
      healingSave: null,
      rolls6: [],
      rolls8: [],
      kolejkaLevel: 0,
      kolejkaRolls: [],
    };
    return apply(started, action);
  }
  const c = step(
    step(character('twardziel', 3), 'stamina', 'use'),
    'surge',
    'use',
  );
  const short = rest(c, 'short');
  expect(short.condition!.spent).toMatchObject({ stamina: 1, surge: 0 });
  expect(rest(c, 'long').condition!.spent).toMatchObject({
    stamina: 0,
    surge: 0,
  });
});

it('publishes the new level through the store while preserving every spent use and the prior journal', async () => {
  let persisted = step(character('brutal', 4), 'berserk', 'use');
  const before = structuredClone(persisted.condition);
  const store = createCharacterStore({
    list: async () => [structuredClone(persisted)],
    save: async (mutation: CharacterMutation) => {
      expect(mutation.expectedRevision).toBe(persisted.revision);
      persisted = {
        ...structuredClone(mutation.character),
        revision: persisted.revision + 1,
      };
      return structuredClone(persisted);
    },
  });
  await store.getState().initialize();
  store.getState().select(persisted.id);
  store.getState().edit();
  store.getState().update({
    ...complete(fixture('brutal', 10)),
    hpCurrent: persisted.sheet!.hpCurrent,
  });
  expect(await store.getState().publish()).toBe(true);
  expect(persisted.condition).toEqual(before);
  expect(persisted.draft).toBeNull();
  expect(
    conditionView(persisted).resources.find((r) => r.id === 'berserk')!.max,
  ).toBe(5);
  expect(left(persisted, 'berserk')).toBe(4);
});

it('recalculates modifier-based capacity after publishing a score edit and from live condition effects', async () => {
  const c = character('twardziel', 1);
  c.sheet!.baseScores.con = 14;
  let persisted = step(c, 'stamina', 'use');
  const capacity = (record: Character) =>
    conditionView(record).resources.find((r) => r.id === 'stamina')!.max;
  expect(conditionView(persisted).derived.modifiers.con).toBe(2);
  expect(capacity(persisted)).toBe(2);
  expect(left(persisted, 'stamina')).toBe(1);
  const before = structuredClone(persisted.condition);
  const store = createCharacterStore({
    list: async () => [structuredClone(persisted)],
    save: async (mutation: CharacterMutation) => {
      expect(mutation.expectedRevision).toBe(persisted.revision);
      persisted = {
        ...structuredClone(mutation.character),
        revision: persisted.revision + 1,
      };
      return structuredClone(persisted);
    },
  });
  await store.getState().initialize();
  store.getState().select(persisted.id);
  store.getState().edit();
  store.getState().update({
    ...persisted.sheet!,
    baseScores: { ...persisted.sheet!.baseScores, con: 18 },
  });
  expect(await store.getState().publish()).toBe(true);
  expect(persisted.condition).toEqual(before);
  expect(persisted.sheet!.levels).toEqual(c.sheet!.levels);
  expect(conditionView(persisted).derived.modifiers.con).toBe(4);
  expect(capacity(persisted)).toBe(4);
  expect(left(persisted, 'stamina')).toBe(3);

  persisted = step(step(persisted, 'stamina', 'use'), 'stamina', 'use');
  persisted.condition!.effects.push({
    id: crypto.randomUUID(),
    target: 'con',
    amount: 4,
    source: 'Czasowe osłabienie Kondycji',
    refresh: 'long',
  });
  expect(capacity(persisted)).toBe(2);
  expect(persisted.condition!.spent.stamina).toBe(3);
  expect(left(persisted, 'stamina')).toBe(0);
  expect(() => step(persisted, 'stamina', 'use')).toThrow('Brak pozostałych');
  persisted = step(persisted, 'stamina', 'restore');
  expect(persisted.condition!.spent.stamina).toBe(2);
  expect(left(persisted, 'stamina')).toBe(0);
  persisted = step(persisted, 'stamina', 'restore');
  expect(left(persisted, 'stamina')).toBe(1);

  persisted.condition!.effects[0]!.amount = 20;
  expect(capacity(persisted)).toBe(0);
  expect(persisted.condition!.spent.stamina).toBe(1);
  expect(() => step(persisted, 'stamina', 'use')).toThrow('Brak pozostałych');
  expect(
    conditionContext(persisted).longResources.find((r) => r.id === 'stamina')!
      .max,
  ).toBe(4);
  const restored = step(persisted, 'stamina', 'restore');
  expect(restored.condition!.spent.stamina).toBe(0);
  expect(() => step(restored, 'stamina', 'restore')).toThrow(
    'Wszystkie użycia',
  );
});
