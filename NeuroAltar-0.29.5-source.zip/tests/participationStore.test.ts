import { beforeEach, expect, it, vi } from 'vitest';
const mocks = vi.hoisted(() => ({
  invoke: vi.fn(),
  rows: vi.fn(),
  characters: vi.fn(),
  slots: vi.fn(),
  character: {
    locked: false,
    invalid: {},
    flush: vi.fn(),
    records: [] as { id: string; revision: number }[],
  },
  combat: {
    closing: false,
    flush: vi.fn(),
    slots: [] as { encounterId: number; revision: number }[],
    drafts: {},
  },
  encounter: { closing: false, flush: vi.fn() },
}));
vi.mock('@tauri-apps/api/core', () => ({ invoke: mocks.invoke }));
vi.mock('../src/db/connection', () => ({
  openDatabase: async () => ({ selectRows: mocks.rows }),
}));
vi.mock('../src/db/characterRepository', () => ({
  loadCharacters: mocks.characters,
}));
vi.mock('../src/db/combatRepository', () => ({
  createCombatRepository: () => ({ listSlots: mocks.slots }),
}));
vi.mock('../src/domain/combat', () => ({ toCombatDraft: (v: unknown) => v }));
vi.mock('../src/stores/characterStore', () => ({
  useCharacterStore: {
    getState: () => mocks.character,
    setState: (v: object) => Object.assign(mocks.character, v),
  },
}));
vi.mock('../src/stores/combatStore', () => ({
  useCombatStore: {
    getState: () => mocks.combat,
    setState: (v: object | ((s: typeof mocks.combat) => object)) =>
      Object.assign(
        mocks.combat,
        typeof v === 'function' ? v(mocks.combat) : v,
      ),
  },
}));
vi.mock('../src/stores/encounterStore', () => ({
  useEncounterStore: {
    getState: () => mocks.encounter,
    setState: (v: object) => Object.assign(mocks.encounter, v),
  },
}));
vi.mock('../src/stores/combatLogStore', () => ({
  useCombatLogStore: { getState: () => ({ refresh: vi.fn() }) },
}));
vi.mock('../src/stores/navigationStore', () => ({
  useNavigationStore: { getState: () => ({ revealCloseIssue: vi.fn() }) },
}));
import { useParticipationStore as store } from '../src/stores/participationStore';
beforeEach(() => {
  vi.resetAllMocks();
  Object.assign(mocks.character, {
    locked: false,
    invalid: {},
    records: [{ id: 'bg', revision: 1 }],
  });
  Object.assign(mocks.combat, {
    closing: false,
    slots: [{ encounterId: 1, revision: 2 }],
    drafts: {},
  });
  mocks.encounter.closing = false;
  mocks.character.flush.mockResolvedValue(true);
  mocks.combat.flush.mockResolvedValue(true);
  mocks.encounter.flush.mockResolvedValue(true);
  mocks.slots.mockResolvedValue([{ encounterId: 1, revision: 3 }]);
  mocks.rows.mockResolvedValue([]);
  mocks.characters.mockResolvedValue(mocks.character.records);
  mocks.invoke.mockResolvedValue({});
  store.setState({ entries: [], busy: false, error: null, pending: null });
});
it('retains the same operation after a committed link cannot refresh characters, then unlocks after retry', async () => {
  mocks.characters.mockRejectedValueOnce(new Error('read failed'));
  expect(await store.getState().send('actor', 1, 'bg', { kind: 'link' })).toBe(
    false,
  );
  const pending = store.getState().pending;
  expect(pending).not.toBeNull();
  expect(mocks.character.locked).toBe(true);
  expect(store.getState().busy).toBe(false);
  expect(await store.getState().retry()).toBe(true);
  expect(mocks.invoke.mock.calls[0]).toEqual(mocks.invoke.mock.calls[1]);
  expect(store.getState().pending).toBeNull();
  expect(mocks.character.locked).toBe(false);
  expect(mocks.combat.closing).toBe(false);
  expect(mocks.encounter.closing).toBe(false);
});
it('does not discard recovery information when participation data cannot be read', async () => {
  mocks.rows.mockRejectedValueOnce(new Error('database unavailable'));
  expect(await store.getState().send('actor', 1, 'bg', { kind: 'link' })).toBe(
    false,
  );
  expect(store.getState().pending).not.toBeNull();
  expect(store.getState().error).toContain('database unavailable');
  expect(await store.getState().retry()).toBe(true);
  expect(mocks.character.locked).toBe(false);
});
it('unlocks all editors when preparation throws before invoking the command', async () => {
  mocks.combat.flush.mockRejectedValueOnce(new Error('save failed'));
  expect(await store.getState().send('actor', 1, 'bg', { kind: 'link' })).toBe(
    false,
  );
  expect(mocks.invoke).not.toHaveBeenCalled();
  expect(store.getState().pending).toBeNull();
  expect(store.getState().busy).toBe(false);
  expect(store.getState().error).toContain('save failed');
  expect(
    mocks.character.locked || mocks.combat.closing || mocks.encounter.closing,
  ).toBe(false);
});
it('successfully links and releases editing locks', async () => {
  expect(await store.getState().send('actor', 1, 'bg', { kind: 'link' })).toBe(
    true,
  );
  expect(store.getState().pending).toBeNull();
  expect(store.getState().busy).toBe(false);
  expect(mocks.combat.slots[0]?.revision).toBe(3);
  expect(
    mocks.character.locked || mocks.combat.closing || mocks.encounter.closing,
  ).toBe(false);
});
