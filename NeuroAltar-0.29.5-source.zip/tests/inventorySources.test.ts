import { expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import supplement from '../src/data/equipment/moloch-city.v1.json';
import { itemSchema } from '../src/domain/item';
import {
  catalogEntry,
  customItem,
} from '../src/domain/character/inventoryCatalog';
import { newInventoryEntry } from '../src/domain/character/inventoryModel';
import { inventorySources } from '../src/features/character/inventorySources';

function entry(name: string) {
  const item = [...catalog.entries, ...supplement.entries].find(
    (item) => item.name === name,
  );
  if (!item) throw new Error(`Missing fixture: ${name}`);
  return catalogEntry(itemSchema.parse(item));
}

it('shows the resolved M14 handbook citation once while retaining its table name', () => {
  const m14 = entry('M14');
  const before = structuredClone(m14);
  expect(inventorySources(m14)).toEqual([
    'Neuroshima: Ostatnia Era — s. 123; Broń palna długa (BPD)',
  ]);
  expect(m14).toEqual(before);
});

it('removes the exact duplicate supplement citation for Beamgun', () => {
  expect(inventorySources(entry('Beamgun'))).toEqual([
    'Suplement Moloch City — tabela „Broń laserowa Asgardu”',
  ]);
});

it('retains the wider armor rules reference beside its catalog table reference', () => {
  expect(
    inventorySources(entry('Pancerz wspomagany Stalowej Policji (200 kg)')),
  ).toEqual([
    'Neuroshima: Ostatnia Era — s. 113; Tabela pancerzy',
    'Neuroshima: Ostatnia Era, s. 113–115',
  ]);
});

it('preserves custom item sources and distinct custom profile annotations', () => {
  const m14 = entry('M14');
  m14.item.source = 'Notatki gracza — zmodyfikowany karabin';
  m14.weapon!.source = 'Własny profil MG';
  expect(inventorySources(m14)).toEqual([
    'Notatki gracza — zmodyfikowany karabin',
    'Własny profil MG',
  ]);
  m14.weapon!.source = m14.item.source;
  expect(inventorySources(m14)).toEqual([m14.item.source]);
});

it('never hides additional profile conditions even when handbook pages match', () => {
  const m14 = entry('M14');
  for (const note of [
    '; zmieniony magazynek 30',
    ' — zasady MG',
    ' (wariant specjalny)',
  ]) {
    m14.weapon!.source = 'Neuroshima: Ostatnia Era, s. 123' + note;
    expect(inventorySources(m14)).toHaveLength(2);
    expect(inventorySources(m14)[1]).toBe(m14.weapon!.source);
  }
});

it('compares full page ranges rather than a shared page number or book title', () => {
  const m14 = entry('M14');
  for (const source of [
    'Neuroshima: Ostatnia Era, s. 123–124',
    'Neuroshima: Ostatnia Era, s. 12',
    'Neuroshima: Ostatnia Era, s. 123, 125',
    'Inny podręcznik, s. 123',
  ]) {
    m14.weapon!.source = source;
    expect(inventorySources(m14)).toHaveLength(2);
  }
  m14.item.source = 'Neuroshima: Ostatnia Era — s. 113–115; Tabela pancerzy';
  m14.weapon!.source = 'Neuroshima: Ostatnia Era, s. 113 - 115';
  expect(inventorySources(m14)).toEqual([m14.item.source]);
});

it('omits empty sources and still shows a profile when the item has no source', () => {
  const own = newInventoryEntry(customItem('Własny przedmiot'));
  expect(inventorySources(own)).toEqual([]);
  const m14 = entry('M14');
  delete m14.item.source;
  expect(inventorySources(m14)).toEqual([m14.weapon!.source]);
});
