import { beforeEach, expect, it, vi } from 'vitest';
const mocks = vi.hoisted(() => ({
  invoke: vi.fn(),
  listen: vi.fn(),
  prepareClose: vi.fn(),
  setState: vi.fn(),
}));
vi.mock('@tauri-apps/api/core', () => ({
  isTauri: () => true,
  invoke: mocks.invoke,
}));
vi.mock('@tauri-apps/api/event', () => ({ listen: mocks.listen }));
vi.mock('../src/stores/encounterStore', () => ({
  useEncounterStore: {
    getState: () => ({ prepareClose: mocks.prepareClose }),
    setState: mocks.setState,
  },
}));
beforeEach(() => {
  vi.resetModules();
  vi.resetAllMocks();
  mocks.listen.mockResolvedValue(vi.fn());
});
it('registers one listener before enabling the native guard and awaits saving', async () => {
  const { installCloseGuard } = await import('../src/services/closeGuard');
  await Promise.all([installCloseGuard(), installCloseGuard()]);
  expect(mocks.listen).toHaveBeenCalledTimes(1);
  expect(mocks.listen.mock.invocationCallOrder[0]).toBeLessThan(
    mocks.invoke.mock.invocationCallOrder[0]!,
  );
  let finish!: (value: boolean) => void;
  mocks.prepareClose.mockReturnValue(
    new Promise<boolean>((resolve) => {
      finish = resolve;
    }),
  );
  const handler = mocks.listen.mock.calls[0]![1] as () => Promise<void>;
  const closing = handler();
  await handler();
  expect(mocks.prepareClose).toHaveBeenCalledTimes(1);
  expect(mocks.invoke).not.toHaveBeenCalledWith('finish_exit');
  finish(true);
  await closing;
  expect(mocks.invoke).toHaveBeenCalledWith('finish_exit');
});
it('does not exit when saving fails', async () => {
  const { installCloseGuard } = await import('../src/services/closeGuard');
  await installCloseGuard();
  mocks.prepareClose.mockResolvedValue(false);
  await (mocks.listen.mock.calls[0]![1] as () => Promise<void>)();
  expect(mocks.invoke).not.toHaveBeenCalledWith('finish_exit');
});
it('cleans up and permits retry when guard installation fails', async () => {
  const unlisten = vi.fn();
  mocks.listen.mockResolvedValue(unlisten);
  mocks.invoke.mockRejectedValueOnce(new Error('IPC unavailable'));
  const { installCloseGuard } = await import('../src/services/closeGuard');
  await expect(installCloseGuard()).rejects.toThrow('IPC unavailable');
  expect(unlisten).toHaveBeenCalledTimes(1);
  await installCloseGuard();
  expect(mocks.listen).toHaveBeenCalledTimes(2);
});
