import { expect, it } from 'vitest';
import {
  presentRule,
  displaySpeeds,
  fixedHandbookSp,
  speedDraftLabel,
} from '../src/domain/presentation';
import { parseSpeeds, enemyTemplateSchema } from '../src/domain/enemy';
import animals from '../src/data/bestiary/animals.v2.json';
it('removes administrative notes while keeping attack conditions and values', () => {
  expect(
    presentRule(
      'Ogon: RO SIŁ ST 17; porażka — Powalenie. Jedna Akcja; pod-ataki rozstrzyga MG.',
    ),
  ).toBe('Ogon: RO SIŁ ST 17; porażka — Powalenie.');
  expect(
    presentRule(
      'Ściana: 12 (3k8) od ognia. Bez Testu Ataku; obszar i obrażenia rozlicza MG.',
    ),
  ).toBe('Ściana: 12 (3k8) od ognia.');
  expect(
    presentRule('Pochwycenie, ST 13. Bez Testu Ataku i bez podanych obrażeń.'),
  ).toBe('Pochwycenie, ST 13.');
  expect(presentRule('PW: 192 (16k12 + 96); zachowano zapis źródłowy.')).toBe(
    'PW: 192 (16k12 + 96).',
  );
  expect(
    presentRule(
      'Inicjatywa z podręcznika: -3 (6). Wynik każdej kopii wpisuje MG.',
    ),
  ).toBe('Inicjatywa: -3 (6).');
  expect(
    presentRule(
      'Źródłowy statblock nie podaje toru Zranień ani Tchórzliwości.',
    ),
  ).toBe('');
});
it('formats armor using the displayed statblock TT without rewriting numeric or conditional armor rules', () => {
  expect(presentRule('TT: naturalny pancerz.', 19)).toBe(
    'TT: 19 (naturalny pancerz).',
  );
  expect(presentRule('TT: 12 bez tarczy, 14 z tarczą.', 19)).toBe(
    'TT: 12 bez tarczy, 14 z tarczą.',
  );
  const rule =
    'Przy dokładnie 50% PW wariant wybiera MG. Cel: RO KON ST 10; porażka — Zatrucie na 1 minutę.';
  expect(presentRule(rule)).toBe(rule);
});
it('shows movement units and accepts both new and legacy editor notation without rewriting existing custom walking modes', () => {
  const speeds = [
    { mode: 'Chód', meters: 18 },
    { mode: 'Wspinanie', meters: 4.5 },
  ];
  expect(displaySpeeds(speeds)).toBe('Szybkość 18m\nWspinanie 4,5m');
  expect(parseSpeeds('Szybkość: 18m\nWspinanie: 4,5 m')).toEqual([
    { mode: 'Szybkość', meters: 18 },
    speeds[1],
  ]);
  expect(parseSpeeds('Chód: 18')).toEqual([speeds[0]]);
  expect(speedDraftLabel('Chód: 18\nWspinanie:')).toBe(
    'Szybkość: 18\nWspinanie:',
  );
  expect(speeds[0]!.mode).toBe('Chód');
});
it('hides runtime SP editing only for known handbook values and preserves manual and unknown SP input', () => {
  const t = enemyTemplateSchema.parse(animals.entries[0]!.template);
  expect(fixedHandbookSp(t)).toBe(true);
  expect(fixedHandbookSp({ ...t, sp: null })).toBe(false);
  expect(fixedHandbookSp({ ...t, statblock: undefined })).toBe(false);
  expect(fixedHandbookSp({ ...t, sp: 0 })).toBe(true);
});
