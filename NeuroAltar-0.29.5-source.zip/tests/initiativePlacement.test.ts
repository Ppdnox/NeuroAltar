import { expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { StatblockPanel } from '../src/features/statblocks/StatblockPanel';
import { StatblockSummary } from '../src/features/statblocks/StatblockSummary';
import { toActorDraft, instantiateEnemy } from '../src/domain/combat';
import { enemyTemplateSchema } from '../src/domain/enemy';
import machines from '../src/data/bestiary/machines.v1.json';
import humans from '../src/data/bestiary/humans.v1.json';
import monsters from '../src/data/bestiary/monsters.v1.json';
import mutants from '../src/data/bestiary/mutants.v1.json';
import animals from '../src/data/bestiary/animals.v2.json';
it('makes the existing initiative rule interactive once, inside abilities and rules for every opponent', () => {
  for (const entry of [
    ...machines.entries,
    ...humans.entries,
    ...monsters.entries,
    ...mutants.entries,
    ...animals.entries,
  ]) {
    const actor = toActorDraft(
      instantiateEnemy(enemyTemplateSchema.parse(entry.template), 0),
    );
    const html = renderToStaticMarkup(
      createElement(StatblockPanel, { actor, slotId: 1 }),
    );
    expect(
      html.match(/aria-label="Rzuć inicjatywę/g),
      entry.template.name,
    ).toHaveLength(1);
    const start = html.indexOf('Zdolności stałe i zasady');
    const end = html.indexOf('</details>', start);
    const button = html.indexOf('aria-label="Rzuć inicjatywę');
    expect(button).toBeGreaterThan(start);
    expect(button).toBeLessThan(end);
    expect(html).toContain('<strong>Inicjatywa:</strong>');
  }
});
it('keeps catalog previews read-only and does not invent another initiative row when absent', () => {
  const actor = toActorDraft(
    instantiateEnemy(enemyTemplateSchema.parse(humans.entries[0]!.template), 0),
  );
  const preview = renderToStaticMarkup(
    createElement(StatblockSummary, { value: actor.enemy!.statblock }),
  );
  expect(preview).not.toContain('aria-label="Rzuć inicjatywę');
  actor.enemy!.statblock!.traits = [];
  const html = renderToStaticMarkup(
    createElement(StatblockPanel, { actor, slotId: 1 }),
  );
  expect(html).not.toContain('aria-label="Rzuć inicjatywę');
});
