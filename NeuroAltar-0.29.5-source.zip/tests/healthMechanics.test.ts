import { expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { newCharacter, type Character } from '../src/domain/character/model';
import { complete, fixture } from './helpers/character';
import {
  conditionView,
  previewCondition,
} from '../src/domain/character/condition';
import type { ConditionAction } from '../src/domain/character/conditionModel';
import { deriveCharacter } from '../src/domain/character/derive';
import {
  emptyInventory,
  newInventoryEntry,
} from '../src/domain/character/inventoryModel';
import { customItem } from '../src/domain/character/inventoryCatalog';
import {
  medicalAidProfile,
  resuscitationDC,
} from '../src/domain/character/downtime';
const cases: unknown[] = [];
function character(level = 3, feat?: string, ability = 'medic.1'): Character {
  const c = newCharacter(),
    sheet = fixture('spec', level);
  sheet.levels[0]!.choices['class-tools'] = ['tool:medic', 'tool:smith'];
  if (feat) sheet.levels[0]!.choices.start = [feat];
  if (level >= 3) {
    sheet.levels[2]!.choices.profession = ['medic'];
    sheet.levels[2]!.choices['profession-ability'] = [ability];
  }
  c.sheet = complete(sheet);
  c.sheet.hpCurrent = 1;
  c.draft = null;
  c.inventory = emptyInventory();
  expect(deriveCharacter(c.sheet).issues).toEqual([]);
  return c;
}
function add(c: Character, name: string, quantity = 1) {
  const e = newInventoryEntry(customItem(name));
  e.quantityMilli = quantity * 1000;
  e.unit = 'szt.';
  e.weightMg = 0;
  e.weightReason = 'Wpis testowy';
  c.inventory!.entries.push(e);
  return e;
}
function apply(c: Character, action: ConditionAction) {
  const operationId = crypto.randomUUID(),
    p = previewCondition(c, action, operationId);
  cases.push(
    structuredClone({
      before: c,
      action,
      operationId,
      context: p.context,
      after: p.state,
      inventory: p.inventory ?? c.inventory ?? null,
    }),
  );
  return {
    ...c,
    condition: p.state,
    ...(p.inventory ? { inventory: p.inventory } : {}),
  };
}
it('Pan Plaster adds a healing die and consumes half a daily disease dose without changing acute RadOff', () => {
  let c = character(3, 'plaster');
  const medpak = add(c, 'Medpak', 2);
  const heal: ConditionAction = {
    type: 'downtime',
    command: {
      kind: 'healingItem',
      entryId: medpak.id,
      formula: 'medpak',
      rolls: [2, 3, 4],
      wisSave: null,
    },
  };
  expect(() =>
    apply(c, {
      ...heal,
      command: {
        kind: 'healingItem',
        entryId: medpak.id,
        formula: 'medpak',
        rolls: [2, 3],
        wisSave: null,
      },
    }),
  ).toThrow();
  c = apply(c, heal);
  expect(c.condition!.hp).toBe(12);
  expect(
    c.inventory!.entries.find((e) => e.id === medpak.id)!.quantityMilli,
  ).toBe(1000);
  const id = crypto.randomUUID(),
    drug = add(c, 'Aspiryna K', 1);
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'disease',
      id,
      disease: 'circulation',
      details: 'Istniejąca choroba',
      onsetMinutes: 0,
    },
  });
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'medicine',
      id,
      entryId: drug.id,
      doses: 1,
      treatment: 'daily',
      sideSave: null,
    },
  });
  expect(
    c.inventory!.entries.find((e) => e.id === drug.id)!.quantityMilli,
  ).toBe(500);
  expect(c.condition!.care!.diseases[0]!.treatedDay).toBe(0);
  const rad = add(c, 'RadOff');
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'medicine',
      id: crypto.randomUUID(),
      entryId: rad.id,
      doses: 1,
      treatment: 'exposure',
      sideSave: 20,
    },
  });
  expect(c.inventory!.entries.find((e) => e.id === rad.id)!.quantityMilli).toBe(
    0,
  );
});
it('Mercury still blocks healing items with Pan Plaster', () => {
  const c = character(3, 'plaster');
  c.sheet!.rulesContext.gameColor = 'mercury';
  const e = add(c, 'Medpak');
  expect(() =>
    apply(c, {
      type: 'downtime',
      command: {
        kind: 'healingItem',
        entryId: e.id,
        formula: 'medpak',
        rolls: [1, 1, 1],
        wisSave: null,
      },
    }),
  ).toThrow(/Rtęć/);
  expect(e.quantityMilli).toBe(1000);
});
it('Immunitet blocks new diseases while preserving initial disease and radiation exhaustion', () => {
  let c = character(3, 'immunity');
  const initial = newInventoryEntry(customItem('Aspiryna K'));
  initial.quantityMilli = 3000;
  initial.unit = 'dawka';
  initial.weightMg = 0;
  initial.weightReason = 'Wpis testowy';
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'start',
      group: 'disease',
      choice: 1,
      ability: 'cha',
      id: crypto.randomUUID(),
      medicine: initial,
    },
  });
  expect(c.condition!.care!.diseases).toHaveLength(1);
  expect(() =>
    apply(c, {
      type: 'care',
      command: {
        kind: 'disease',
        id: crypto.randomUUID(),
        disease: 'rat',
        details: 'Nowa',
        onsetMinutes: 0,
      },
    }),
  ).toThrow(/Immunitet/);
  for (let i = 0; i < 3; i++)
    c = apply(c, {
      type: 'care',
      command: {
        kind: 'environment',
        id: 'Promieniowanie ' + i,
        hazard: 'radiation',
        total: 1,
        dc: 10,
        diseaseId: crypto.randomUUID(),
      },
    });
  expect(c.condition!.care!.diseases).toHaveLength(1);
  expect(c.condition!.exhaustion).toHaveLength(3);
});
it('quick production atomically validates level, summed value, materials and one-use pool', () => {
  let c = character();
  const material = add(c, 'Surowce', 4);
  const output = newInventoryEntry(customItem('Nóż'));
  const action: ConditionAction = {
    type: 'downtime',
    command: {
      kind: 'quickProduction',
      products: [
        { output, price: 10 },
        { output: { ...output, id: crypto.randomUUID() }, price: 10 },
      ],
      tools: 'Mały kowal',
      proficient: true,
      schematic: true,
      materials: [{ id: material.id, quantity: 1000, valueGb: 10 }],
    },
  };
  c = apply(c, action);
  expect(c.condition!.worldMinutes).toBe(20);
  expect(c.condition!.spent.production).toBe(1);
  expect(c.inventory!.entries).toHaveLength(3);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(3000);
  expect(() => apply(c, action)).toThrow();
  const low = character(2);
  add(low, 'Surowce');
  expect(() => apply(low, action)).toThrow(/3. poziomu/);
  const over = character();
  over.inventory = c.inventory;
  expect(() =>
    apply(over, {
      type: 'downtime',
      command: {
        kind: 'quickProduction',
        products: [
          { output: { ...output, id: crypto.randomUUID() }, price: 26 },
        ],
        tools: 'Mały kowal',
        proficient: true,
        schematic: true,
        materials: [{ id: material.id, quantity: 1000, valueGb: 30 }],
      },
    }),
  ).toThrow(/limit/);
});
it('quick production raises its price cap at Spec 11 and rejects an absent schematic without mutation', () => {
  const c = character(11),
    material = add(c, 'Surowce');
  const command = {
    kind: 'quickProduction' as const,
    products: [{ output: newInventoryEntry(customItem('Produkt')), price: 50 }],
    tools: 'Mały kowal',
    proficient: true,
    schematic: true,
    materials: [{ id: material.id, quantity: 1000, valueGb: 25 }],
  };
  const before = structuredClone(c);
  expect(() =>
    apply(c, { type: 'downtime', command: { ...command, schematic: false } }),
  ).toThrow();
  expect(c).toEqual(before);
  const result = apply(c, { type: 'downtime', command });
  expect(result.condition!.worldMinutes).toBe(50);
  expect(result.inventory!.entries[0]!.quantityMilli).toBe(0);
});
it('medical dice scale with Spec level and kit treatment consumes one of five uses without modifying patient HP', () => {
  for (const [level, sides] of [
    [3, 6],
    [6, 8],
    [9, 10],
    [12, 12],
  ]) {
    let c = character(level!);
    const kit = add(c, 'Narzędzia małego medyka');
    expect(medicalAidProfile(conditionView(c).sheet, 15).sides).toBe(sides);
    const action: ConditionAction = {
      type: 'downtime',
      command: {
        kind: 'medicalAid',
        patient: 'Pacjent testowy',
        kitId: kit.id,
        inReach: true,
        handsFree: true,
        total: 15,
        rolls: [sides!, sides!],
      },
    };
    for (let i = 0; i < 5; i++) c = apply(c, action);
    expect(c.condition!.hp).toBe(1);
    expect(c.condition!.downtime!.medicKitUses![kit.id]).toBe(5);
    expect(() => apply(c, action)).toThrow(/uzupełnienia/);
    const refill = add(c, 'Uzupełnienie narzędzi małego medyka');
    c = apply(c, {
      type: 'downtime',
      command: { kind: 'refillMedicKit', kitId: kit.id, entryId: refill.id },
    });
    expect(c.condition!.downtime!.medicKitUses![kit.id]).toBe(4);
    expect(
      c.inventory!.entries.find((e) => e.id === refill.id)!.quantityMilli,
    ).toBe(0);
  }
});
it('Łapiduch calculates time bands, rejects massive damage and spends one minute without reviving automatically', () => {
  let c = character(3, undefined, 'medic.2');
  for (const [minutes, dc] of [
    [1, 15],
    [2, 20],
    [4, 25],
    [8, 30],
  ]) {
    expect(resuscitationDC(minutes!)).toBe(dc);
    c = apply(c, {
      type: 'downtime',
      command: {
        kind: 'resuscitate',
        patient: 'Pacjent testowy',
        minutesSincePulse: minutes!,
        massiveDamage: false,
        total: dc!,
      },
    });
  }
  expect(c.condition!.worldMinutes).toBe(4);
  expect(c.condition!.hp).toBe(1);
  expect(() =>
    apply(c, {
      type: 'downtime',
      command: {
        kind: 'resuscitate',
        patient: 'Pacjent',
        minutesSincePulse: 1,
        massiveDamage: true,
        total: 30,
      },
    }),
  ).toThrow(/Olbrzymich/);
});
it('exports native parity cases for the new health operations', () => {
  expect(cases.length).toBeGreaterThan(30);
  if (process.env.GENERATE_HEALTH_MECHANICS_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-health-mechanics.json',
      JSON.stringify(cases) + '\n',
    );
});
