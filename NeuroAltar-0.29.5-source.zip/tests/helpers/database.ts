import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { createEncounterRepository } from '../../src/db/encounterRepository';

export const migration = readFileSync(
  new URL('../../src-tauri/migrations/001_initial.sql', import.meta.url),
  'utf8',
);
export function migrate(database: DatabaseSync) {
  database.exec('BEGIN');
  try {
    database.exec(migration);
    database.exec('COMMIT');
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
}
export function repositoryFor(database: DatabaseSync) {
  return createEncounterRepository({
    selectRows: async (query, values = []) =>
      database.prepare(query).all(...values),
    execute: async (query, values) => ({
      rowsAffected: Number(database.prepare(query).run(...values).changes),
    }),
  });
}
