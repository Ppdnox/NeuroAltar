import {
  catalogEntry,
  customItem,
} from '../../src/domain/character/inventoryCatalog';
import {
  emptyInventory,
  newInventoryEntry,
} from '../../src/domain/character/inventoryModel';
import { itemSchema } from '../../src/domain/item';
import catalog from '../../src/data/equipment/catalog.v1.json';
const get = (name: string) =>
  catalogEntry(itemSchema.parse(catalog.entries.find((e) => e.name === name)));
export function inventoryFixture() {
  const w = get('AR');
  w.slot = 'bothHands';
  w.location = 'body';
  w.weightMg = 3000000;
  w.weightReason = 'Masa testowa';
  const m = newInventoryEntry(customItem('Magazynek AR'));
  m.magazine = {
    capacity: 30,
    caliber: w.weapon!.caliber,
    model: w.weapon!.model,
    rounds: [],
  };
  m.item.type = 'ammunition';
  m.weightMg = 200000;
  m.weightReason = 'Masa testowa';
  const a = get('5,56 mm');
  a.quantityMilli = 30000;
  a.weightMg = 12000;
  a.weightReason = 'Masa testowa';
  const i = { ...emptyInventory(), entries: [w, m, a] };
  return { i, w, m, a };
}
