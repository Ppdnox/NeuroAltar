import {
  newSheet,
  type CharacterSheet,
  type ClassId,
} from '../../src/domain/character/model';
import { deriveCharacter } from '../../src/domain/character/derive';
export function fixture(
  classId: ClassId = 'brutal',
  level = 1,
): CharacterSheet {
  const s = newSheet();
  s.identity.name = 'Postać testowa';
  s.method = 'gm';
  s.methodReason = 'Próba pełnego rozwoju';
  s.baseScores = { str: 18, dex: 18, con: 18, int: 18, wis: 18, cha: 18 };
  s.originId = 'asgard';
  s.levels = Array.from({ length: level }, () => ({
    classId,
    color: 'none' as const,
    contextRevision: 0,
    choices: {},
  }));
  return s;
}
// Select all actual required choices, recalculating prerequisites after each selection.
// The fixture never bypasses validation or fills a second schema by hand.
export function complete(s: CharacterSheet): CharacterSheet {
  for (let pass = 0; pass < 300; pass++) {
    const d = deriveCharacter(s);
    const c = d.choices.find(
      (c) => (s.levels[c.level]!.choices[c.key]?.length ?? 0) !== c.count,
    );
    if (!c) return s;
    const values = c.freeText
      ? Array.from({ length: c.count }, (_, i) => `Model / instrument ${i + 1}`)
      : c.options.slice(0, c.count).map((o) => o.id);
    if (values.length !== c.count)
      throw Error(`No options: ${c.key} ${JSON.stringify(d.issues)}`);
    s.levels[c.level]!.choices[c.key] = values;
  }
  throw Error('Choice loop did not converge');
}
