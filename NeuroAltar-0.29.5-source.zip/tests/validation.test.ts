import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { encounterSlotsSchema } from '../src/domain/encounter';
import { createEncounterRepository } from '../src/db/encounterRepository';
import { migrate, repositoryFor } from './helpers/database';

describe('repository boundary validation', () => {
  let database: DatabaseSync;
  beforeEach(() => {
    database = new DatabaseSync(':memory:');
    migrate(database);
  });
  afterEach(() => database.close());

  it('rejects incomplete and duplicated slot sets', async () => {
    const slots = await repositoryFor(database).listSlots();
    expect(() => encounterSlotsSchema.parse(slots.slice(0, 4))).toThrow();
    expect(() =>
      encounterSlotsSchema.parse([slots[0], slots[0], ...slots.slice(2)]),
    ).toThrow();
  });
  it.each(['[0]', '[-1]', '[1.5]', '["3"]'])(
    'rejects invalid party levels: %s',
    async (json) => {
      database
        .prepare('UPDATE encounters SET party_levels_json = ? WHERE id = 1')
        .run(json);
      await expect(repositoryFor(database).listSlots()).rejects.toThrow();
    },
  );
  it('rejects invalid timestamps instead of presenting invalid data', async () => {
    database.exec(
      "UPDATE encounters SET updated_at = 'yesterday' WHERE id = 1",
    );
    await expect(repositoryFor(database).listSlots()).rejects.toThrow();
  });
  it('propagates database errors', async () => {
    const repository = createEncounterRepository({
      execute: async () => {
        throw new Error('Disk unavailable');
      },
      selectRows: async () => {
        throw new Error('Disk unavailable');
      },
    });
    await expect(repository.listSlots()).rejects.toThrow('Disk unavailable');
  });
});
