import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { readFileSync } from 'node:fs';
import { expect, it, vi } from 'vitest';
import { enemyTemplateSchema } from '../src/domain/enemy';
import { instantiateEnemy, toActorDraft } from '../src/domain/combat';
import { SLOT_IDS } from '../src/domain/encounter';
import { createCombatStore } from '../src/stores/combatStore';
import { CapabilityPanel } from '../src/features/resources/CapabilityPanel';
import { CombatWorkspace } from '../src/features/combat/CombatWorkspace';
const mock = vi.hoisted(() => ({
  state: {} as ReturnType<
    typeof import('../src/stores/combatStore').useCombatStore.getState
  >,
}));
vi.mock('../src/stores/combatStore', async (original) => {
  const actual = await original<typeof import('../src/stores/combatStore')>();
  return {
    ...actual,
    useCombatStore: Object.assign(
      (selector?: (state: typeof mock.state) => unknown) =>
        selector ? selector(mock.state) : mock.state,
      { getState: () => mock.state },
    ),
  };
});
function template(batch: string, name: string) {
  const data = JSON.parse(
    readFileSync(
      new URL(`../src/data/bestiary/${batch}.v1.json`, import.meta.url),
      'utf8',
    ),
  );
  return enemyTemplateSchema.parse(
    data.entries.find(
      (e: { template: { name: string } }) => e.template.name === name,
    ).template,
  );
}
it('renders each ability under its own budget and preserves shared weapon profiles', () => {
  const actor = toActorDraft(
    instantiateEnemy(template('monsters', 'Megator'), 0),
  );
  mock.state = createCombatStore().getState();
  const html = renderToStaticMarkup(
    createElement(CapabilityPanel, { slotId: 1, actor }),
  );
  const action = html.indexOf('aria-label="Akcja — pula i zdolności"');
  const bonus = html.indexOf('aria-label="Akcja Bonusowa — pula i zdolności"');
  const reaction = html.indexOf('aria-label="Reakcja — pula i zdolności"');
  expect(html.slice(action, bonus)).toContain('Użyj: Zionięcie');
  expect(html.slice(action, bonus)).toContain('Profile broni i warianty');
  expect(html.slice(bonus, reaction)).toContain('Użyj: Połknięcie');
  expect(html.slice(action, bonus)).not.toContain('Użyj: Połknięcie');
  expect(html).toContain('RO KON ST 19');
  expect(html).toContain('<details class="ability-description">');
});
it('places the failure form next to its trigger, outside disabled actor controls, and retains invalid input', async () => {
  const actor = instantiateEnemy(template('machines', 'Mobsprzęt'), 0);
  const slots = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: encounterId === 1 ? [actor] : [],
  }));
  const store = createCombatStore(
    async () => slots,
    async () => 1,
  );
  await store.getState().initialize();
  store.getState().openFailureForm(1, actor.id);
  store
    .getState()
    .editFailureForm({ result: '21', note: 'Żółć\nDrugi wiersz' });
  store.getState().submitFailureForm();
  mock.state = store.getState();
  const html = renderToStaticMarkup(
    createElement(CombatWorkspace, { slotId: 1 }),
  );
  expect(html.match(/aria-label="Wynik awarii k20"/g)).toHaveLength(1);
  expect(html.indexOf('aria-label="Zastosowanie awarii"')).toBeGreaterThan(
    html.indexOf('Wpisz wynik awarii k20'),
  );
  const prefix = html.slice(0, html.indexOf('aria-label="Wynik awarii k20"'));
  const stack: boolean[] = [];
  for (const tag of prefix.match(/<\/?fieldset\b[^>]*>/g) ?? []) {
    if (tag.startsWith('</')) stack.pop();
    else stack.push(tag.includes('disabled'));
  }
  expect(stack).not.toContain(true);
  expect(html).toContain('value="21"');
  expect(html).toContain('Żółć\nDrugi wiersz');
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().failureForm?.fields.result).toBe('21');
});

it('offers every system status and custom status on the BG card without adding an effect until confirmation', async () => {
  const { systemStatuses } = await import('../src/domain/status');
  const store = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 1,
        currentTurnActorId: null,
        actors: [],
      })),
    async (c) => c.revision + 1,
  );
  await store.getState().initialize();
  store.getState().addActor(2);
  await store.getState().flush(2);
  const id = store.getState().slots[1]!.actors[0]!.id;
  mock.state = store.getState();
  const html = renderToStaticMarkup(
    createElement(CombatWorkspace, { slotId: 2 }),
  );
  expect(html).toContain('aria-label="Dodaj status z listy"');
  for (const [key, [label]] of Object.entries(systemStatuses)) {
    expect(html).toContain(`<option value="${key}">${label}</option>`);
  }
  expect(html).toContain('Własny status…');
  store.getState().openStatusForm(2, id);
  store.getState().editStatusForm({
    systemKey: 'poisoned',
    durationType: 'rounds',
    rounds: '2',
  });
  expect(
    store.getState().drafts[2]!.value.actors[0]!.effects ?? [],
  ).toHaveLength(0);
  store.getState().submitStatusForm();
  await store.getState().flush(2);
  expect(
    store.getState().drafts[2]!.value.actors[0]!.effects?.[0]?.systemKey,
  ).toBe('poisoned');
});

it('keeps an invalid BG status draft inline and editable while locking the rest of the card', async () => {
  const store = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 1,
        currentTurnActorId: null,
        actors: [],
      })),
    async (c) => c.revision + 1,
  );
  await store.getState().initialize();
  store.getState().addActor(2);
  await store.getState().flush(2);
  const id = store.getState().slots[1]!.actors[0]!.id;
  store.getState().openStatusForm(2, id);
  store.getState().editStatusForm({
    systemKey: null,
    name: '',
    description: 'Żółty dym\nDrugi wiersz',
    durationType: 'rounds',
    rounds: '0',
  });
  store.getState().submitStatusForm();
  mock.state = store.getState();
  const html = renderToStaticMarkup(
    createElement(CombatWorkspace, { slotId: 2 }),
  );
  const formIndex = html.indexOf('aria-label="Formularz statusu"');
  expect(formIndex).toBeGreaterThan(
    html.indexOf('aria-label="Dodaj status z listy"'),
  );
  expect(html.match(/aria-label="Formularz statusu"/g)).toHaveLength(1);
  const prefix = html.slice(0, html.indexOf('aria-label="Rodzaj statusu"'));
  const stack: boolean[] = [];
  for (const tag of prefix.match(/<\/?fieldset\b[^>]*>/g) ?? []) {
    if (tag.startsWith('</')) stack.pop();
    else stack.push(tag.includes('disabled'));
  }
  expect(stack).not.toContain(true);
  expect(html).toContain('Żółty dym\nDrugi wiersz');
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().statusForm?.fields.rounds).toBe('0');
});

it('keeps current statblock visible before optional fields and rolls Cyngiel ability descriptions', async () => {
  const actor = instantiateEnemy(template('humans', 'Cyngiel'), 0);
  const store = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 1,
        currentTurnActorId: null,
        actors: encounterId === 1 ? [actor] : [],
      })),
    async () => 1,
  );
  await store.getState().initialize();
  mock.state = store.getState();
  const html = renderToStaticMarkup(
    createElement(CombatWorkspace, { slotId: 1 }),
  );
  expect(html).toContain(
    '<section class="template-summary" aria-label="Statblock tej instancji">',
  );
  expect(html.indexOf('aria-label="Statblock tej instancji"')).toBeLessThan(
    html.indexOf('Parametry i notatki postaci'),
  );
  expect(html).not.toContain('<summary>Statblock tej instancji');
  const description = html.slice(
    html.indexOf('<summary>Opis: Nóż taktyczny — dodatkowy atak'),
    html.indexOf(
      '</details>',
      html.indexOf('<summary>Opis: Nóż taktyczny — dodatkowy atak'),
    ),
  );
  expect(description).toContain(
    'Rzuć: Atak — Nóż taktyczny — dodatkowy atak (1k20+9)',
  );
  expect(description).toContain(
    'Rzuć: Rzut — Nóż taktyczny — dodatkowy atak (1k6+5)',
  );
  expect(html).toContain('Rzuć: Rzut — Bolesny atak (4k6)');
});
