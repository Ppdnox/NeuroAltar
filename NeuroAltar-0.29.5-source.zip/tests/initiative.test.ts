import { describe, expect, it } from 'vitest';
import {
  advanceTurn,
  initiativeOrder,
  moveWithinTie,
} from '../src/domain/initiative';

const actors = [
  { id: 'a', initiativeValue: 12, initiativeTieOrder: 0 },
  { id: 'b', initiativeValue: 18, initiativeTieOrder: 1 },
  { id: 'c', initiativeValue: 12, initiativeTieOrder: 2 },
  { id: 'd', initiativeValue: null, initiativeTieOrder: 3 },
  { id: 'e', initiativeValue: 0, initiativeTieOrder: 4 },
  { id: 'f', initiativeValue: -2, initiativeTieOrder: 5 },
];
describe('manual initiative and turn order', () => {
  it('sorts descending, includes zero/negative initiative and excludes missing results', () => {
    expect(initiativeOrder(actors).map((a) => a.id)).toEqual([
      'b',
      'a',
      'c',
      'e',
      'f',
    ]);
    expect(actors.map((a) => a.id)).toEqual(['a', 'b', 'c', 'd', 'e', 'f']);
  });
  it('moves only within a tie, keeps actor identity and never mutates inputs', () => {
    const reordered = moveWithinTie(actors, 'c', -1);
    expect(initiativeOrder(reordered).map((a) => a.id)).toEqual([
      'b',
      'c',
      'a',
      'e',
      'f',
    ]);
    expect(actors[0]!.initiativeTieOrder).toBe(0);
    expect(moveWithinTie(actors, 'a', -1)).toEqual(actors);
    expect(moveWithinTie(actors, 'd', 1)).toEqual(actors);
  });
  it('starts at first actor, advances, and wraps exactly once per round', () => {
    expect(advanceTurn(actors, 1, null)).toEqual({
      roundNumber: 1,
      currentTurnActorId: 'b',
    });
    expect(advanceTurn(actors, 3, 'b')).toEqual({
      roundNumber: 3,
      currentTurnActorId: 'a',
    });
    expect(advanceTurn(actors, 3, 'f')).toEqual({
      roundNumber: 4,
      currentTurnActorId: 'b',
    });
  });
  it('handles empty, unscheduled, singleton and removed active actor', () => {
    expect(advanceTurn([], 2, null)).toEqual({
      roundNumber: 2,
      currentTurnActorId: null,
    });
    expect(advanceTurn([actors[3]!], 2, null)).toEqual({
      roundNumber: 2,
      currentTurnActorId: null,
    });
    expect(advanceTurn([actors[0]!], 2, 'a')).toEqual({
      roundNumber: 3,
      currentTurnActorId: 'a',
    });
    expect(advanceTurn(actors, 2, 'deleted')).toEqual({
      roundNumber: 2,
      currentTurnActorId: 'b',
    });
  });
  it('keeps turns at zero HP and retains the active ID after a reorder', () => {
    const aliveOrNot = actors.map((a) => ({ ...a, hpCurrent: 0 }));
    expect(advanceTurn(aliveOrNot, 1, 'b').currentTurnActorId).toBe('a');
    expect(
      advanceTurn(moveWithinTie(actors, 'c', -1), 2, 'c').currentTurnActorId,
    ).toBe('a');
  });
  it('does not overflow round counters', () => {
    expect(() =>
      advanceTurn([actors[0]!], Number.MAX_SAFE_INTEGER, 'a'),
    ).toThrow();
  });
});
