import { readFileSync } from 'node:fs';
import { combatLoadoutSchema } from '../src/domain/item';
import { expect, it } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { instantiateEnemy } from '../src/domain/combat';
import { SLOT_IDS } from '../src/domain/encounter';
import { parseStatblockDraft, toStatblockDraft } from '../src/domain/statblock';
it('keeps invalid input and blocks turns/forms, retries failed writes and restores prepared data', async () => {
  const loadout = combatLoadoutSchema.parse(
    JSON.parse(
      readFileSync(new URL('./fixtures/loadout.json', import.meta.url), 'utf8'),
    ),
  );
  const a = instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Stróż',
      category: 'human',
      size: 'Średni',
      tt: 12,
      hpMax: 20,
      speeds: [],
      statblock: parseStatblockDraft(toStatblockDraft()),
      loadout,
    },
    0,
  );
  a.initiativeValue = 10;
  let fail = true;
  const store = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 1,
        currentTurnActorId: null,
        actors: encounterId === 4 ? [a] : [],
      })),
    async (c) => {
      if (fail) throw new Error('disk');
      return c.revision + 1;
    },
  );
  await store.getState().initialize();
  store.getState().openStatblockForm(4, a.id);
  let fields = structuredClone(store.getState().statblockForm!.fields);
  fields.abilityScores.con = 'źle';
  store.getState().editStatblockForm(fields);
  store.getState().submitStatblockForm();
  expect(store.getState().statblockForm!.fields.abilityScores.con).toBe('źle');
  expect(await store.getState().prepareClose()).toBe(false);
  store.getState().nextTurn(4);
  store.getState().openLoadoutForm(4, a.id);
  store.getState().openEnemyForm(4);
  expect(store.getState().drafts[4]!.value.currentTurnActorId).toBeNull();
  expect(store.getState().loadoutForm).toBeNull();
  expect(store.getState().enemyForm).toBeNull();
  fields = {
    ...fields,
    abilityScores: { ...fields.abilityScores, con: '18' },
    damageThreshold: '0',
  };
  store.getState().editStatblockForm(fields);
  store.getState().submitStatblockForm();
  expect(await store.getState().flush(4)).toBe(false);
  expect(
    store.getState().drafts[4]!.value.actors[0]!.enemy!.statblock!.abilityScores
      .con,
  ).toBe(18);
  expect(store.getState().drafts[4]!.value.actors[0]!.enemy!.loadout).toEqual(
    loadout,
  );
  expect(store.getState().drafts[4]!.value.actors[0]!.hpCurrent).toBe('20');
  fail = false;
  expect(await store.getState().flush(4)).toBe(true);
  expect(
    store.getState().slots[3]!.actors[0]!.enemy!.template.statblock!
      .abilityScores.con,
  ).toBeNull();
  store.getState().resetEncounter(4);
  await store.getState().flush(4);
  expect(
    store.getState().slots[3]!.actors[0]!.enemy!.statblock!.abilityScores.con,
  ).toBeNull();
  expect(await store.getState().prepareClose()).toBe(true);
});
