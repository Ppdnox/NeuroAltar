import { expect, it } from 'vitest';
import { experienceProgress } from '../src/domain/character/experience';

it('tracks handbook thresholds from current level and shows a pending advancement', () => {
  expect(experienceProgress(49, 1)).toEqual({
    nextLevel: 2,
    target: 50,
    remaining: 1,
    percent: 98,
  });
  expect(experienceProgress(50, 1)).toEqual({
    nextLevel: 2,
    target: 50,
    remaining: 0,
    percent: 100,
  });
  expect(experienceProgress(100, 2)).toEqual({
    nextLevel: 3,
    target: 150,
    remaining: 50,
    percent: 50,
  });
  expect(experienceProgress(1000, 1).percent).toBe(100);
});
it('handles insufficient experience, corrections and maximum level', () => {
  expect(experienceProgress(-1, 1).percent).toBe(0);
  expect(experienceProgress(49, 2).percent).toBe(0);
  expect(experienceProgress(3399, 11)).toMatchObject({
    remaining: 1,
    target: 3400,
    nextLevel: 12,
  });
  expect(experienceProgress(5000, 12)).toEqual({
    nextLevel: null,
    target: null,
    remaining: 0,
    percent: 100,
  });
});
