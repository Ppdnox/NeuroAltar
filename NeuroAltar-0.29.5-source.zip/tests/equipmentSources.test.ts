import { expect, it } from 'vitest';
import { equipmentSource } from '../src/domain/equipmentSource';
import catalog from '../src/data/equipment/catalog.v1.json';
import handbook from '../src/data/equipment/handbook-sources.v1.json';
it('covers each of the 299 original items exactly once without changing their data', () => {
  const before = JSON.stringify(catalog);
  const ids = handbook.groups.flatMap((g) => Object.keys(g.items));
  expect(ids).toHaveLength(299);
  expect(new Set(ids).size).toBe(299);
  expect(ids.sort()).toEqual(catalog.entries.map((i) => i.id).sort());
  for (const item of catalog.entries) {
    const result = equipmentSource(item);
    expect(result, item.name).toMatch(/^Neuroshima: Ostatnia Era — s\. \d+/);
    expect(result).not.toContain('Suplement');
  }
  expect(JSON.stringify(catalog)).toBe(before);
});
it('points to verified table pages and splits the explosives across their actual pages', () => {
  for (const [name, pages] of [
    ['Kurtka ćwiekowana', '113'],
    ['Bat', '116'],
    ['Bolas', '119'],
    ['B 92', '122'],
    ['HK G3', '123'],
    ['Bełt', '125'],
    ['Broń palna krótka', '126'],
    ['Dynamit (laska)', '126'],
    ['Granat improwizowany', '127'],
    ['Koktajl Mołotowa', '127, 139'],
    ['Plastik C4 (kostka 100 g)', '127'],
    ['Agregat', '130'],
    ['Actinix', '132'],
    ['Akordeon', '132'],
    ['Mały ślusarz', '134'],
    ['Anestix', '137'],
    ['Paliwo dobre (5 l)', '139'],
    ['Chleb (1 kg)', '144'],
    ['Wół', '143'],
  ]) {
    const item = catalog.entries.find((i) => i.name === name)!;
    expect(item, name).toBeDefined();
    expect(equipmentSource(item), name).toContain(`s. ${pages};`);
  }
});
it('preserves user sources and does not guess citations by names or categories', () => {
  const item = catalog.entries[0]!;
  expect(equipmentSource({ ...item, source: 'Moje zasady, s. 4' })).toBe(
    'Moje zasady, s. 4',
  );
  expect(equipmentSource({ ...item, id: crypto.randomUUID() })).toBe(
    item.source,
  );
  expect(equipmentSource({ ...item, source: undefined })).toBeUndefined();
});
