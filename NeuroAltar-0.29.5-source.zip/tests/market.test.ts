import { describe, expect, it } from 'vitest';
import { itemSchema, type Item } from '../src/domain/item';
import {
  BASE_TRADE_CONTEXT as base,
  calculateMarketValues as calc,
  calculateMarketPrice,
  calculateMarketAvailability,
  formatMarketRange,
  marketRulesSchema,
  tradeContextSchema,
  type TradeContext,
} from '../src/domain/market';
import raw from '../src/data/equipment/market-rules.v1.json';
import catalog from '../src/data/equipment/catalog.v1.json';
const rules = marketRulesSchema.parse(raw);
const item: Item = {
  ...itemSchema.parse(catalog.entries[0]),
  type: 'weapon',
  basePrice: { min: 10.125, max: 35.375 },
  baseAvailability: { min: 20, max: 70 },
};
const color = (color: TradeContext['color']): TradeContext => ({
  ...base,
  color,
});
describe('market values', () => {
  it('returns exact independent ranges and leaves Item untouched in none/none/none without any catalogs', () => {
    const before = structuredClone(item);
    const result = calc(item, base, { regions: {}, locations: {} });
    expect(result).toEqual({
      price: item.basePrice,
      availability: item.baseAvailability,
    });
    expect(result.price).not.toBe(item.basePrice);
    expect(item).toEqual(before);
    expect(calculateMarketPrice(item, base, rules)).toEqual(item.basePrice);
    expect(calculateMarketAvailability(item, base, rules)).toEqual(
      item.baseAvailability,
    );
  });
  it.each([
    ['none', 1, 1],
    ['rust', 2, 0.5],
    ['mercury', 1, 1],
    ['steel', 0.5, 2],
    ['chrome', 1, 2],
  ] as const)(
    'applies %s to each endpoint without rounding',
    (c, price, availability) => {
      expect(calc(item, color(c), rules)).toEqual({
        price: { min: 10.125 * price, max: 35.375 * price },
        availability: {
          min: 20 * availability,
          max: Math.min(100, 70 * availability),
        },
      });
    },
  );
  it.each([
    'weapon',
    'armor',
    'ammunition',
    'tool',
    'electronics',
    'food',
    'fuel',
    'other',
  ] as const)(
    'Stal tests Item.type %s, never economic category or presence of profile',
    (type) => {
      const i = { ...item, type, economicCategory: 'BROŃ' };
      const applies = type === 'weapon' || type === 'ammunition';
      expect(calc(i, color('steel'), rules).price?.min).toBe(
        10.125 * (applies ? 0.5 : 1),
      );
      expect(calc(i, color('steel'), rules).availability?.min).toBe(
        20 * (applies ? 2 : 1),
      );
    },
  );
  it('adds location before color and clamps only at the end', () => {
    expect(
      calc(
        item,
        { ...color('rust'), location: { kind: 'location', id: 'city' } },
        rules,
      ).availability,
    ).toEqual({ min: 15, max: 40 });
    expect(
      calc(
        item,
        {
          ...color('chrome'),
          location: { kind: 'location', id: 'wilderness' },
        },
        rules,
      ).availability,
    ).toEqual({ min: 0, max: 40 });
    expect(
      calc(
        { ...item, baseAvailability: { min: 90, max: 100 } },
        { ...color('rust'), location: { kind: 'location', id: 'city' } },
        rules,
      ).availability,
    ).toEqual({ min: 50, max: 55 });
  });
  it('retains region and location for armor under Stal', () => {
    expect(
      calc(
        { ...item, type: 'armor' },
        {
          color: 'steel',
          region: { kind: 'region', id: 'detroit' },
          location: { kind: 'location', id: 'city' },
        },
        rules,
      ),
    ).toEqual({
      price: { min: 15.1875, max: 53.0625 },
      availability: { min: 30, max: 80 },
    });
  });
  it('propagates absent values independently and retains valid zero', () => {
    expect(calc({ ...item, basePrice: null }, base, rules)).toEqual({
      price: null,
      availability: item.baseAvailability,
    });
    expect(calc({ ...item, baseAvailability: null }, base, rules)).toEqual({
      price: item.basePrice,
      availability: null,
    });
    expect(
      calc({ ...item, basePrice: null, baseAvailability: null }, base, rules),
    ).toEqual({ price: null, availability: null });
    expect(
      calc(
        {
          ...item,
          basePrice: { min: 0, max: 0 },
          baseAvailability: { min: 0, max: 0 },
        },
        base,
        rules,
      ),
    ).toEqual({ price: { min: 0, max: 0 }, availability: { min: 0, max: 0 } });
  });
  it('rejects unknown choices and missing category instead of a silent fallback', () => {
    expect(() =>
      calc(item, { ...base, region: { kind: 'region', id: 'missing' } }, rules),
    ).toThrow('Region');
    expect(() =>
      calc(
        item,
        { ...base, location: { kind: 'location', id: 'missing' } },
        rules,
      ),
    ).toThrow('Lokalizacja');
    expect(() =>
      calc(
        { ...item, economicCategory: 'missing' },
        { ...base, region: { kind: 'region', id: 'miami' } },
        rules,
      ),
    ).toThrow('kategorii');
    expect(() =>
      calc(
        item,
        { ...base, region: { kind: 'region', id: 'toString' } },
        rules,
      ),
    ).toThrow('Region');
    expect(() =>
      tradeContextSchema.parse({ ...base, color: 'silver' }),
    ).toThrow();
    expect(tradeContextSchema.parse(color('mercury')).color).toBe('mercury');
  });
  it('validates invalid ranges, modifiers and overflow', () => {
    expect(() =>
      calc({ ...item, basePrice: { min: 30, max: 20 } }, base, rules),
    ).toThrow();
    expect(() =>
      calc({ ...item, baseAvailability: { min: 0, max: 101 } }, base, rules),
    ).toThrow();
    expect(() => calc({ ...item, weight: NaN }, base, rules)).toThrow();
    expect(() =>
      calc(
        {
          ...item,
          basePrice: {
            min: Number.MAX_SAFE_INTEGER,
            max: Number.MAX_SAFE_INTEGER,
          },
        },
        color('rust'),
        rules,
      ),
    ).toThrow('zakres');
    expect(() =>
      marketRulesSchema.parse({
        regions: { x: { label: 'X', priceMultipliers: { BROŃ: -1 } } },
        locations: {},
      }),
    ).toThrow();
  });
  it('formats at most two decimals without changing exact boundaries, null or zero', () => {
    expect(formatMarketRange({ min: 1.126, max: 2.224 }, 'gb')).toBe(
      '1,13–2,22 gb',
    );
    expect(formatMarketRange({ min: 0, max: 0 }, '%')).toBe('0 %');
    expect(formatMarketRange(null, 'gb')).toBe('N/D');
  });
});

it('applies the approved Chrom healing exception without touching other categories or paid values', () => {
  const healing = {
    ...item,
    type: 'other' as const,
    category: 'Prochy i używki / Środki lecznicze',
  };
  expect(calc(healing, color('chrome'), rules).price).toEqual({
    min: 5.0625,
    max: 17.6875,
  });
  expect(calc(healing, base, rules).price).toEqual(healing.basePrice);
  expect(
    calc({ ...healing, category: 'Inne' }, color('chrome'), rules).price,
  ).toEqual(healing.basePrice);
});
it('adds Gambling availability before the color multiplier and clamps after both operations', () => {
  expect(calculateMarketAvailability(item, color('rust'), rules, 5)).toEqual({
    min: 12.5,
    max: 37.5,
  });
  expect(calc(item, color('chrome'), rules, 5).availability).toEqual({
    min: 50,
    max: 100,
  });
  expect(calc(item, base, rules, 0).availability).toEqual(
    item.baseAvailability,
  );
  expect(() => calc(item, base, rules, NaN)).toThrow();
});
