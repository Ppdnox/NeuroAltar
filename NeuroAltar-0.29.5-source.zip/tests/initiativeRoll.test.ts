import { afterEach, expect, it, vi } from 'vitest';
import { enemyInitiative } from '../src/domain/enemyInitiative';
import {
  instantiateEnemy,
  toActorDraft,
  type Combat,
} from '../src/domain/combat';
import { enemyTemplateSchema } from '../src/domain/enemy';
import { newStatusDraft, parseStatusDraft } from '../src/domain/status';
import { createCombatStore } from '../src/stores/combatStore';
import { createEncounterStore } from '../src/stores/encounterStore';
import { createDiceStore } from '../src/stores/diceStore';
import { createInitiativeStore } from '../src/stores/initiativeStore';
import { useCombatLogStore } from '../src/stores/combatLogStore';
import { SLOT_IDS } from '../src/domain/encounter';
import { rollDice, diceRollSchema, type DiceRoll } from '../src/domain/dice';
import { initiativeOrder } from '../src/domain/initiative';
import humans from '../src/data/bestiary/humans.v1.json';
import machines from '../src/data/bestiary/machines.v1.json';
import monsters from '../src/data/bestiary/monsters.v1.json';
import mutants from '../src/data/bestiary/mutants.v1.json';
import animals from '../src/data/bestiary/animals.v2.json';
const template = enemyTemplateSchema.parse(humans.entries[0]!.template);
afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});
it('uses every handbook initiative bonus, never the parenthesized value, and preserves unknowns', () => {
  for (const e of [
    ...humans.entries,
    ...machines.entries,
    ...monsters.entries,
    ...mutants.entries,
    ...animals.entries,
  ]) {
    const t = enemyTemplateSchema.parse(e.template);
    const actor = toActorDraft(instantiateEnemy(t, 0));
    const line = t.statblock!.traits!.find((t) => /^Inicjatywa/.test(t))!;
    expect(enemyInitiative(actor)?.base, t.name).toBe(
      Number(line.match(/:\s*([+-]?\d+)/)![1]),
    );
  }
  const actor = toActorDraft(instantiateEnemy(template, 0));
  actor.enemy!.statblock!.traits = ['Inicjatywa z podręcznika: +3 (12).'];
  expect(enemyInitiative(actor)?.base).toBe(3);
  actor.effects = [
    parseStatusDraft(
      { ...newStatusDraft(), systemKey: 'exhaustion', level: '2' },
      false,
    ),
  ];
  expect(enemyInitiative(actor)).toMatchObject({
    base: 3,
    penalty: 4,
    modifier: -1,
    formula: '1k20-1',
  });
  actor.enemy!.statblock!.traits = ['Inicjatywa: N/D'];
  expect(enemyInitiative(actor)).toBeNull();
  actor.effects = [];
  actor.enemy!.statblock!.traits = [];
  actor.enemy!.statblock!.abilityScores.dex = 16;
  expect(enemyInitiative(actor)?.base).toBe(3);
  actor.enemy!.statblock!.abilityScores.dex = null;
  expect(enemyInitiative(actor)).toBeNull();
  actor.enemy!.statblock!.traits = ['Inicjatywa: +3', 'Inicjatywa: +5'];
  expect(enemyInitiative(actor)).toBeNull();
});
async function fixture() {
  vi.useFakeTimers();
  vi.spyOn(useCombatLogStore.getState(), 'refresh').mockResolvedValue();
  const actor = instantiateEnemy(template, 0),
    sibling = instantiateEnemy(template, 1);
  actor.initiativeValue = 2;
  sibling.initiativeValue = 10;
  const slots: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 3,
    currentTurnActorId: encounterId === 2 ? sibling.id : null,
    actors: encounterId === 2 ? [actor, sibling] : [],
  }));
  const load = vi.fn(async () => structuredClone(slots));
  const combat = createCombatStore(load, async (c) => {
    const rev = slots[c.encounterId - 1]!.revision;
    if (c.revision !== rev) throw Error('conflict');
    slots[c.encounterId - 1] = structuredClone({ ...c, revision: rev + 1 });
    return rev + 1;
  });
  const encounters = createEncounterStore(
    async () =>
      SLOT_IDS.map((id) => ({
        id,
        name: `Potyczka ${id}`,
        notes: '',
        roundNumber: 1,
        currentTurnActorId: null,
        partyLevels: [],
        createdAt: '2026-09-12T00:00:00.000Z',
        updatedAt: '2026-09-12T00:00:00.000Z',
      })),
    async () => '2026-09-12T00:00:00.000Z',
  );
  const history: DiceRoll[] = [];
  const dice = createDiceStore({
    read: async () => history,
    write: async () => {},
  });
  const save = vi.fn(async (r: DiceRoll, revision: number) => {
    if (history.some((v) => v.id === r.id)) return;
    const slot = slots[r.context!.encounterId - 1]!;
    if (slot.revision !== revision) throw Error('conflict');
    slot.actors.find((a) => a.id === r.context!.actorId)!.initiativeValue =
      r.total;
    slot.revision++;
    history.unshift(r);
  });
  const execute = vi.fn((input: string) => rollDice(input, () => 20));
  await combat.getState().initialize();
  await encounters.getState().initialize();
  const store = createInitiativeStore(
    encounters,
    combat,
    dice,
    save,
    load,
    execute,
  );
  return {
    store,
    combat,
    encounters,
    dice,
    save,
    load,
    execute,
    actor,
    sibling,
  };
}
it('flushes edits before rolling, saves only this actor, sorts the queue and keeps turn, round and prepared state', async () => {
  const f = await fixture();
  f.combat.getState().editActor(2, f.actor.id, { hpCurrent: '1' });
  const pending = f.store.getState().roll(2, f.actor.id);
  expect(f.combat.getState().closing).toBe(true);
  expect(await f.store.getState().roll(2, f.actor.id)).toBe(false);
  expect(await pending).toBe(true);
  const slot = f.combat.getState().slots[1]!;
  const rolled = slot.actors[0]!;
  expect(rolled.initiativeValue).toBe(f.dice.getState().history[0]!.total);
  expect(rolled.hpCurrent).toBe(1);
  expect(rolled.prepared).toEqual(f.actor.prepared);
  expect(slot.actors[1]).toEqual(f.sibling);
  expect(slot.currentTurnActorId).toBe(f.sibling.id);
  expect(slot.roundNumber).toBe(3);
  expect(initiativeOrder(slot.actors)[0]!.id).toBe(f.actor.id);
  expect(f.execute).toHaveBeenCalledTimes(1);
  expect(f.encounters.getState().closing).toBe(false);
  f.combat.getState().editActor(2, f.actor.id, { initiativeValue: '7' });
  await f.combat.getState().flush(2);
  expect(f.combat.getState().slots[1]!.actors[0]!.initiativeValue).toBe(7);
});
it('retains the exact result on write failure, blocks close and retries without rolling again', async () => {
  const f = await fixture();
  f.save.mockRejectedValueOnce(Error('disk'));
  expect(await f.store.getState().roll(2, f.actor.id)).toBe(false);
  const result = f.store.getState().pending;
  expect(result).not.toBeNull();
  expect(await f.store.getState().prepareClose()).toBe(false);
  expect(f.combat.getState().closing).toBe(true);
  expect(await f.store.getState().retry()).toBe(true);
  expect(f.save.mock.calls[1]).toEqual(f.save.mock.calls[0]);
  expect(f.execute).toHaveBeenCalledTimes(1);
  expect(f.dice.getState().history).toEqual([result]);
  expect(await f.store.getState().prepareClose()).toBe(true);
});
it('recovers an uncertain committed write by reading the slot and history, without another roll', async () => {
  const f = await fixture();
  f.load.mockRejectedValueOnce(Error('read'));
  expect(await f.store.getState().roll(2, f.actor.id)).toBe(false);
  expect(await f.store.getState().reload()).toBe(true);
  expect(f.dice.getState().history).toHaveLength(1);
  expect(f.combat.getState().slots[1]!.actors[0]!.initiativeValue).toBe(
    f.dice.getState().history[0]!.total,
  );
  expect(f.execute).toHaveBeenCalledTimes(1);
});
it('does not roll through unfinished forms or invalid drafts and validates single k20 context', async () => {
  const f = await fixture();
  f.combat.getState().openEnemyForm(2);
  expect(await f.store.getState().roll(2, f.actor.id)).toBe(false);
  expect(f.execute).not.toHaveBeenCalled();
  f.combat.setState({ enemyForm: null });
  f.combat.getState().editActor(2, f.actor.id, { hpCurrent: '' });
  expect(await f.store.getState().roll(2, f.actor.id)).toBe(false);
  expect(f.execute).not.toHaveBeenCalled();
  expect(f.combat.getState().closing).toBe(false);
  const r = {
    ...rollDice('2k20', () => 10),
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    context: {
      encounterId: 2,
      actorId: f.actor.id,
      actorName: 'Test',
      roundNumber: 3,
      label: 'Inicjatywa',
      purpose: 'initiative',
      sourceKey: 'initiative',
    },
  };
  expect(diceRollSchema.safeParse(r).success).toBe(false);
});
