import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/animals.v2.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { templateDraft } from '../src/domain/bestiary';
import { calculateWeaponAttackProfile } from '../src/domain/item';
import {
  instantiateEnemy,
  parseActorDraft,
  toActorDraft,
  prepareCombat,
  resetEncounter,
} from '../src/domain/combat';
import { consumeCapability } from '../src/domain/capabilities';
import {
  capabilitySetupSchema,
  instantiateCapabilities,
  parseCapabilityDraft,
  toCapabilityDraft,
} from '../src/domain/capabilitySchema';
import { applyInjuryLevel, setInjuryEnabled } from '../src/domain/injury';
import { newStatusDraft, parseStatusDraft } from '../src/domain/status';
const entries = batch.entries.map((e) => ({
  ...e,
  template: enemyTemplateSchema.parse(e.template),
}));
const get = (key: string) => entries.find((e) => e.key === key)!.template;
it('inventories twelve animals with exact handbook stats and editable round trips', () => {
  expect(
    entries.map(({ source, template: t }) => [
      t.name,
      source.pdfPage,
      t.tt,
      t.hpMax,
      t.sp,
      t.loadout!.pb,
      t.injuryTrack!.enabled,
    ]),
  ).toEqual([
    ['Gigamut', 246, 10, 192, 24, 6, true],
    ['Gigantyczny pająk', 246, 15, 64, 15, 3, true],
    ['Koń (skażony)', 247, 10, 18, 1, 1, false],
    ['Koń (teksańczyk)', 247, 11, 32, 3, 3, false],
    ['Koń (zdrowy)', 247, 10, 32, 2, 2, false],
    ['Mrokoszczur', 248, 12, 15, 4, 2, false],
    ['Myślący szczur', 249, 14, 12, 7, 2, false],
    ['Neokot', 250, 15, 8, 3, 2, false],
    ['Neogator', 251, 19, 72, 18, 4, true],
    ['Neoniedźwiedź', 251, 16, 120, 23, 4, true],
    ['Pies bojowy', 252, 11, 20, 3, 2, false],
    ['Rój szczurów', 253, 14, 32, 9, 3, false],
  ]);
  for (const { template: t, source } of entries) {
    expect(t.category).toBe('animal');
    expect(source.printedPage + 2).toBe(source.pdfPage);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toEqual(t);
    expect(instantiateEnemy(t, 0).initiativeValue).toBeNull();
  }
  expect(new Set(entries.map((e) => e.template.id)).size).toBe(12);
});
it('keeps printed attack bonuses, source anomalies and conditional rules without invented damage profiles', () => {
  const expected = [
    [13, 13],
    [6, 6],
    [3],
    [7],
    [5],
    [3],
    [6, 6],
    [7],
    [9, 9],
    [9, 9],
    [5],
    [5, 5],
  ];
  entries.forEach(({ template: t }, i) =>
    expect(
      t
        .loadout!.items.filter((e) => e.item.weaponProfile)
        .map((e) => calculateWeaponAttackProfile(e, t.loadout!).attack),
    ).toEqual(expected[i]),
  );
  expect(
    get('myslacy-szczur').loadout!.items.map(
      (e) => e.item.weaponProfile!.damageModes[0]!.average,
    ),
  ).toEqual([5, 4]);
  expect(get('gigamut').statblock!.traits!.join(' ')).toContain('-3 (6)');
  expect(get('gigantyczny-pajak').statblock!.damageImmunities).toBeNull();
  expect(get('neogator').statblock!.senses).toContain(
    'Ślepowidzenie 18 m — tylko w wodzie',
  );
  expect(
    get('neoniedzwiedz').loadout!.items[2]!.item.weaponProfile,
  ).toBeUndefined();
  expect(get('neogator').loadout!.items[2]!.item.weaponProfile).toBeUndefined();
  expect(get('roj-szczurow').statblock!.traits!.join(' ')).toContain(
    'dokładnie 50%',
  );
  expect(get('roj-szczurow').statblock!.traits!.join(' ')).toContain(
    'równocześnie',
  );
});
it('records unlimited reactions repeatedly without changing HP, copies, finite budget or prepared state', () => {
  const t = get('roj-szczurow'),
    b = instantiateEnemy(t, 1);
  let a = instantiateEnemy(t, 0);
  for (let i = 0; i < 5; i++) a = consumeCapability(a, 'reaction');
  expect(a.enemy!.capabilities).toMatchObject({
    unlimitedReactions: true,
    usageNumber: 5,
    budget: { reaction: 1 },
    lastUse: { override: false },
  });
  expect(a.hpCurrent).toBe(32);
  expect(a.effects).toEqual(b.effects);
  expect(b.enemy!.capabilities!.usageNumber).toBe(0);
  expect(a.enemy!.template).toEqual(t);
  expect(parseActorDraft(toActorDraft(a))).toEqual(a);
  const c = prepareCombat({
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [a, b],
  });
  const changed = {
    ...c,
    actors: [consumeCapability(c.actors[0]!, 'reaction'), b],
  };
  expect(resetEncounter(changed).actors[0]!.enemy!.capabilities).toEqual(
    a.enemy!.capabilities,
  );
});
it('turning unlimited reactions on and off preserves depleted budget and legacy JSON remains unchanged', () => {
  let a = consumeCapability(instantiateEnemy(get('neokot'), 0), 'reaction');
  expect(() => consumeCapability(a, 'reaction')).toThrow();
  const previous = a.enemy!.capabilities!;
  expect(JSON.stringify(previous)).not.toContain('unlimitedReactions');
  expect(parseCapabilityDraft(toCapabilityDraft(previous), previous)).toEqual(
    previous,
  );
  a.enemy!.capabilities = parseCapabilityDraft(
    { ...toCapabilityDraft(previous), unlimitedReactions: true },
    previous,
  );
  a = consumeCapability(a, 'reaction');
  expect(a.enemy!.capabilities!.budget.reaction).toBe(0);
  a.enemy!.capabilities = parseCapabilityDraft(
    { ...toCapabilityDraft(a.enemy!.capabilities!), unlimitedReactions: false },
    a.enemy!.capabilities!,
  );
  expect(() => consumeCapability(a, 'reaction')).toThrow();
  expect(
    capabilitySetupSchema.safeParse({
      ...get('roj-szczurow').capabilities,
      unlimitedReactions: 'true',
    }).success,
  ).toBe(false);
});
it('unlimited reactions still obey injury, incapacitation and linked resource costs', () => {
  let a = instantiateEnemy(get('roj-szczurow'), 0);
  expect(() =>
    consumeCapability(
      applyInjuryLevel(setInjuryEnabled(a, true), 3),
      'reaction',
    ),
  ).toThrow();
  expect(() =>
    consumeCapability(
      {
        ...a,
        effects: [
          parseStatusDraft(
            { ...newStatusDraft(), systemKey: 'stunned' },
            false,
          ),
        ],
      },
      'reaction',
    ),
  ).toThrow();
  const rid = crypto.randomUUID(),
    aid = crypto.randomUUID();
  a.enemy!.capabilities = instantiateCapabilities({
    unlimitedReactions: true,
    legendaryMax: 0,
    resources: [{ id: rid, name: 'Test', maxValue: 2, refreshRule: 'manual' }],
    abilities: [
      {
        id: aid,
        name: 'Kosztowna reakcja',
        kind: 'reaction',
        description: '',
        legendaryCost: 1,
        resourceId: rid,
        resourceCost: 1,
      },
    ],
  });
  a = consumeCapability(consumeCapability(a, aid), aid);
  expect(a.enemy!.capabilities!.resources[0]!.currentValue).toBe(0);
  expect(() => consumeCapability(a, aid, true)).toThrow('Za mało');
});
