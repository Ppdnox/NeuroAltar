import { expect, it, vi } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import type { Combat } from '../src/domain/combat';
it('queues critical/death/reduction through a failed save, retains invalid percent on close, and restores prepared effects after restart', async () => {
  let data: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [],
  }));
  const load = async () => structuredClone(data);
  const save = vi.fn(async (c: Combat) => {
    data = data.map((v) =>
      v.encounterId === c.encounterId
        ? structuredClone({ ...c, revision: c.revision + 1 })
        : v,
    );
    return c.revision + 1;
  });
  const store = createCombatStore(load, save);
  await store.getState().initialize();
  store.getState().addEnemy(3, {
    id: '00000000-0000-4000-8000-000000000099',
    name: 'Żółw',
    category: 'beast',
    size: 'Duży',
    tt: 15,
    hpMax: 88,
    speeds: [],
    injuryTrack: { enabled: true, initialLevel: 3 },
    cowardicePercent: 50,
  });
  await store.getState().flush(3);
  const id = store.getState().slots[2]!.actors[0]!.id;
  save.mockRejectedValueOnce(new Error('disk'));
  store.getState().setInjuryLevel(3, id, 4);
  await store.getState().flush(3);
  expect(store.getState().drafts[3]!.status).toBe('error');
  expect(store.getState().slots[2]!.actors[0]!.enemy!.injury!.level).toBe(3);
  await store.getState().flush(3);
  store.getState().prepareEncounter(3);
  await store.getState().flush(3);
  store.getState().setInjuryLevel(3, id, 5);
  store.getState().setInjuryLevel(3, id, 4);
  store.getState().setInjuryLevel(3, id, 3);
  await store.getState().flush(3);
  expect(
    save.mock.calls.map(([c]) => c.actors[0]?.enemy?.injury?.deathWarning),
  ).toContain(true);
  store.getState().editActor(3, id, { cowardicePercentText: '101' });
  expect(await store.getState().prepareClose()).toBe(false);
  expect(
    store.getState().drafts[3]!.value.actors[0]!.cowardicePercentText,
  ).toBe('101');
  store.getState().editActor(3, id, { cowardicePercentText: '' });
  await store.getState().flush(3);
  const restarted = createCombatStore(load, save);
  await restarted.getState().initialize();
  restarted.getState().resetEncounter(3);
  await restarted.getState().flush(3);
  expect(restarted.getState().slots[2]!.actors[0]!.enemy).toMatchObject({
    injury: { level: 4, deathWarning: false },
    cowardicePercent: 50,
  });
  expect(restarted.getState().slots[2]!.actors[0]!.effects![0]!.level).toBe(1);
  expect(restarted.getState().slots[1]!.actors).toEqual([]);
  expect(await restarted.getState().prepareClose()).toBe(true);
});
