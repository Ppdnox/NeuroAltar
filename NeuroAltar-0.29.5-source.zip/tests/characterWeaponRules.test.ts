import { expect, it } from 'vitest';
import { complete, fixture } from './helpers/character';
import { deriveCharacter } from '../src/domain/character/derive';
import {
  deriveEquipment,
  deriveInventoryWeapon,
} from '../src/domain/character/equipped';
import { catalogEntry } from '../src/domain/character/inventoryCatalog';
import { emptyInventory } from '../src/domain/character/inventoryModel';
import { itemSchema } from '../src/domain/item';
import catalog from '../src/data/equipment/catalog.v1.json';
const get = (name: string) =>
  catalogEntry(itemSchema.parse(catalog.entries.find((e) => e.name === name)));
function feat(id: string) {
  const s = fixture('twardziel');
  s.levels[0]!.choices.start = [id];
  complete(s);
  expect(deriveCharacter(s).activeFeats).toContain(id);
  return s;
}
it('Szturmowiec removes only the normal-range short-burst penalty', () => {
  const s = feat('assault'),
    w = get('AR');
  w.slot = 'bothHands';
  expect(deriveInventoryWeapon(s, w, 'short')!.disadvantage).toBe(false);
  expect(
    deriveInventoryWeapon(
      s,
      w,
      'short',
      3,
      'auto',
      undefined,
      undefined,
      'long',
    )!.disadvantage,
  ).toBe(true);
  expect(
    deriveInventoryWeapon(complete(fixture('twardziel')), w, 'short')!
      .disadvantage,
  ).toBe(true);
});
it('CKM doubles long-burst dice without changing short bursts or ammo count', () => {
  const s = feat('mobile'),
    w = get('AR');
  expect(deriveInventoryWeapon(s, w, 'long', 20)!.damage).toBe('16k6');
  expect(deriveInventoryWeapon(s, w, 'short', 3)!.damage).toBe('6k6');
  expect(deriveInventoryWeapon(s, w, 'massive', 50)!.damage).toBe('10k6');
});
it('Rzeźnik requires no other weapon in the other hand', () => {
  const s = fixture('twardziel');
  s.levels[0]!.choices.veteran = ['butcher'];
  complete(s);
  const w = get('AR');
  w.slot = 'bothHands';
  const inv = { ...emptyInventory(), entries: [w] };
  expect(
    deriveInventoryWeapon(s, w, 'single', 1, 'auto', undefined, inv)!.damage,
  ).toBe('2k6 + 7');
  const other = get('Peacemaker');
  other.slot = 'offHand';
  w.slot = 'mainHand';
  inv.entries.push(other);
  expect(
    deriveInventoryWeapon(s, w, 'single', 1, 'auto', undefined, inv)!.damage,
  ).toBe('2k6 + 4');
});
it('Clint adds one revolver die and does not affect ordinary pistols', () => {
  const s = fixture('twardziel', 3);
  s.levels[2]!.choices.profession = ['cowboy'];
  s.levels[2]!.choices['profession-ability'] = ['cowboy.0'];
  complete(s);
  expect(
    deriveCharacter(s).rules.some((r) => r.id === 'profession.cowboy.0'),
  ).toBe(true);
  const w = get('Peacemaker');
  w.item.name = 'Moja spluwa';
  expect(deriveInventoryWeapon(s, w)!.damage).toBe('2k8 + 4');
  expect(deriveInventoryWeapon(s, get('B 92'))!.damage).toBe('1k6 + 4');
});
it('Samuraj grants TT only while holding a finesse slashing weapon', () => {
  const s = feat('samurai'),
    w = get('Katana');
  w.slot = 'mainHand';
  w.location = 'body';
  const inv = { ...emptyInventory(), entries: [w] };
  const without = deriveEquipment(s, emptyInventory()).armor[0]!.value!;
  expect(deriveEquipment(s, inv).armor[0]!.value).toBe(without + 1);
  w.slot = 'none';
  expect(deriveEquipment(s, inv).armor[0]!.value).toBe(without);
});
it('Snajper doubles only far range and removes its penalty', () => {
  const s = feat('sniper'),
    w = get('AR');
  w.slot = 'bothHands';
  const p = deriveInventoryWeapon(
    s,
    w,
    'single',
    1,
    'auto',
    undefined,
    undefined,
    'long',
  )!;
  expect(p.range.normal).toBe(w.item.weaponProfile!.range.normal);
  expect(p.range.long).toBe(w.item.weaponProfile!.range.long! * 2);
  expect(p.disadvantage).toBe(false);
});
it('Pulp Fiction covers pistols and SMGs but not assault rifles', () => {
  const s = feat('pulp');
  expect(deriveInventoryWeapon(s, get('B 92'))!.disadvantage).toBe(false);
  expect(deriveInventoryWeapon(s, get('Empepiątka'))!.disadvantage).toBe(false);
  expect(deriveInventoryWeapon(s, get('AR'))!.disadvantage).toBe(true);
});

it('Mistrz broni białej adds a die only to the selected weapon', () => {
  const s = fixture('twardziel');
  s.levels[0]!.choices.start = ['blademaster'];
  s.levels[0]!.choices['start-weapon'] = ['Katana'];
  complete(s);
  expect(deriveInventoryWeapon(s, get('Katana'))!.damage).toBe('2k10 + 4');
  expect(deriveInventoryWeapon(s, get('Maczeta'))!.damage).toBe('1k8 + 4');
});
it('Miotacz improves thrown knives, not bows in the same proficiency category', () => {
  const s = feat('thrower'),
    knife = get('Nóż do rzucania'),
    bow = get('Łuk bloczkowy');
  expect(deriveInventoryWeapon(s, knife)!.range).toEqual({
    normal: 12,
    long: 24,
    unit: 'm',
  });
  expect(deriveInventoryWeapon(s, bow)!.range).toEqual(
    bow.item.weaponProfile!.range,
  );
  const base = complete(fixture('twardziel'));
  expect(deriveInventoryWeapon(s, knife)!.attack).toBe(
    deriveInventoryWeapon(base, knife)!.attack! + 2,
  );
});
it('Spec 11 adds INT once, including to burst damage', () => {
  const s = complete(fixture('spec', 11)),
    w = get('AR');
  const intel = deriveCharacter(s).modifiers.int!;
  expect(deriveInventoryWeapon(s, w, 'long', 10)!.damage).toBe(
    '4k6 + ' + intel,
  );
});

it('explicit custom weapon family applies only the chosen weapon trait', () => {
  const s = fixture('twardziel', 3);
  s.levels[2]!.choices.profession = ['cowboy'];
  s.levels[2]!.choices['profession-ability'] = ['cowboy.0'];
  complete(s);
  const custom = get('B 92');
  custom.weapon!.model = custom.id;
  custom.item.name = 'Własny rewolwer';
  expect(deriveInventoryWeapon(s, custom)!.damage).toBe('1k6 + 4');
  custom.weapon!.family = 'revolver';
  expect(deriveInventoryWeapon(s, custom)!.damage).toBe('2k6 + 4');
  custom.item.name = 'Przemianowana broń';
  expect(deriveInventoryWeapon(s, custom)!.damage).toBe('2k6 + 4');
});
