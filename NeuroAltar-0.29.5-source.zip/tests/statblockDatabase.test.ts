import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { expect, it } from 'vitest';
import { createCombatRepository } from '../src/db/combatRepository';
import { createBestiaryRepository } from '../src/db/bestiaryRepository';
import { instantiateEnemy } from '../src/domain/combat';
import { statblockSchema } from '../src/domain/statblock';
it('reads old and extended catalog/runtime/prepared JSON together after all unchanged migrations', async () => {
  const db = new DatabaseSync(':memory:');
  try {
    const dir = new URL('../src-tauri/migrations/', import.meta.url);
    for (const name of readdirSync(dir)
      .filter((n) => n.endsWith('.sql'))
      .sort())
      db.exec(readFileSync(new URL(name, dir), 'utf8'));
    const block = statblockSchema.parse(
      JSON.parse(
        readFileSync(
          new URL('./fixtures/statblock.json', import.meta.url),
          'utf8',
        ),
      ),
    );
    const template = {
      id: crypto.randomUUID(),
      name: 'Wartownik — Ż',
      category: 'human' as const,
      size: 'Średni',
      tt: 14,
      hpMax: 42,
      speeds: [],
      statblock: block,
    };
    const a = instantiateEnemy(template, 0);
    db.prepare(
      'INSERT INTO enemy_templates(id,name,category,size,tt,hp_max,statblock_json) VALUES (?,?,?,?,?,?,?)',
    ).run(
      template.id,
      template.name,
      template.category,
      template.size,
      14,
      42,
      JSON.stringify({ speeds: [], statblock: block }),
    );
    const legacy = {
      ...template,
      id: crypto.randomUUID(),
      name: 'Stary',
      statblock: undefined,
    };
    db.prepare(
      'INSERT INTO enemy_templates(id,name,category,size,tt,hp_max,statblock_json) VALUES (?,?,?,?,?,?,?)',
    ).run(
      legacy.id,
      legacy.name,
      legacy.category,
      legacy.size,
      14,
      42,
      JSON.stringify({ speeds: [] }),
    );
    db.prepare(
      "INSERT INTO encounter_actors(id,encounter_id,kind,template_id,display_name,tt_current,hp_current,hp_max_current,initiative_tie_order,prepared_snapshot_json,reset_snapshot_json,runtime_overrides_json) VALUES (?,2,'enemy',?,?,14,42,42,0,?,?,?)",
    ).run(
      a.id,
      template.id,
      a.displayName,
      JSON.stringify(a.prepared),
      JSON.stringify(a.prepared),
      JSON.stringify({ manualStatuses: [], enemy: a.enemy }),
    );
    const connection = {
      selectRows: async (
        sql: string,
        values: (string | number | null)[] = [],
      ) => db.prepare(sql).all(...values),
      execute: async (
        sql: string,
        values: (string | number | null)[] = [],
      ) => ({ rowsAffected: Number(db.prepare(sql).run(...values).changes) }),
    };
    const catalog = await createBestiaryRepository(connection).list();
    expect(
      catalog.find((e) => e.template.id === template.id)!.template.statblock,
    ).toEqual(block);
    expect(
      catalog.find((e) => e.template.id === legacy.id)!.template.statblock,
    ).toBeUndefined();
    const loaded = await createCombatRepository(connection).listSlots();
    expect(loaded).toHaveLength(5);
    expect(loaded[1]!.actors[0]!.enemy!.statblock).toEqual(block);
    expect(loaded[1]!.actors[0]!.prepared!.enemy!.statblock).toEqual(block);
    expect(db.prepare('pragma foreign_key_check').all()).toEqual([]);
  } finally {
    db.close();
  }
});
