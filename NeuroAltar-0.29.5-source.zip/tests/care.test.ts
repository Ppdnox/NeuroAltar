import { expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { newCharacter, type Character } from '../src/domain/character/model';
import { complete, fixture } from './helpers/character';
import {
  previewCondition,
  conditionView,
} from '../src/domain/character/condition';
import type { ConditionAction } from '../src/domain/character/conditionModel';
import {
  emptyInventory,
  newInventoryEntry,
} from '../src/domain/character/inventoryModel';
import { customItem } from '../src/domain/character/inventoryCatalog';
import { nutritionNeeds } from '../src/domain/character/care';
import { productionValues } from '../src/domain/character/downtime';
const cases: unknown[] = [];
function record(): Character {
  const c = newCharacter();
  c.sheet = complete(fixture('brutal', 3));
  c.draft = null;
  c.sheet.hpCurrent = 1;
  return c;
}
function apply(c: Character, a: ConditionAction) {
  const operationId = crypto.randomUUID(),
    p = previewCondition(c, a, operationId);
  cases.push(
    structuredClone({
      before: c,
      action: a,
      operationId,
      context: p.context,
      after: p.state,
      inventory: p.inventory ?? c.inventory ?? null,
    }),
  );
  return {
    ...c,
    condition: p.state,
    ...(p.inventory ? { inventory: p.inventory } : {}),
  };
}
const time = (c: Character, minutes = 1440) =>
  apply(c, { type: 'worldTime', minutes });
it('chronic selection grants the correct three doses once; taking medicine and its stock commit together', () => {
  let c = record();
  const med = newInventoryEntry(customItem('Aspiryna K'));
  med.quantityMilli = 3000;
  med.unit = 'dawka';
  med.catalogId = null;
  const a: ConditionAction = {
    type: 'care',
    command: {
      kind: 'start',
      group: 'disease',
      choice: 1,
      ability: 'cha',
      id: crypto.randomUUID(),
      medicine: med,
    },
  };
  c = apply(c, a);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(3000);
  expect(c.inventory!.entries[0]!.weightMg).toBe(0);
  expect(() => apply(c, a)).toThrow();
  const id = c.condition!.care!.diseases[0]!.id;
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'medicine',
      id,
      entryId: med.id,
      doses: 1,
      treatment: 'daily',
      sideSave: null,
    },
  });
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(2000);
  expect(() =>
    apply(c, {
      type: 'care',
      command: {
        kind: 'diseaseCheck',
        id,
        natural: 1,
        total: 20,
        chronicRoll: null,
      },
    }),
  ).toThrow();
  c = time(c);
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 1,
      total: 20,
      chronicRoll: null,
    },
  });
  expect(c.condition!.care!.diseases[0]!.stage).toBe(2);
  c = time(c);
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 20,
      total: 1,
      chronicRoll: null,
    },
  });
  expect(c.condition!.care!.diseases[0]!.stage).toBe(0);
});
it('Thurman affects effective INT while illness survives a long rest', () => {
  let c = record();
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'disease',
      id,
      disease: 'thurman',
      details: 'Próba',
      onsetMinutes: 0,
    },
  });
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 1,
      total: 30,
      chronicRoll: null,
    },
  });
  expect(conditionView(c).derived.scores.int.value).toBe(2);
  c = apply(c, { type: 'worldTime', minutes: 1 });
  expect(conditionView(c).derived.scores.int.value).toBe(2);
});
it('phobia success streak resets on failure; breakthrough uses game time and three successes cure', () => {
  let c = record();
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'care',
    command: { kind: 'phobia', id, phobia: 'spiders' },
  });
  const check = (total: number) => ({
    type: 'care' as const,
    command: {
      kind: 'phobiaCheck' as const,
      id,
      total,
      turn: '',
      trigger: true,
    },
  });
  for (const total of [15, 15, 1, 15, 15, 15]) {
    c = apply(c, check(total));
    if (c.condition!.care!.phobias[0]!.active) c = time(c, 60);
  }
  expect(c.condition!.care!.phobias[0]!.active).toBe(false);
});
it('radiation failures preserve sources, block rest and convert to a selected chronic disease on success', () => {
  let c = record();
  for (let i = 0; i < 3; i++)
    c = apply(c, {
      type: 'care',
      command: {
        kind: 'environment',
        id: 'Godzina ' + i,
        hazard: 'radiation',
        total: 1,
        dc: 10,
        diseaseId: crypto.randomUUID(),
      },
    });
  expect(c.condition!.care!.diseases).toHaveLength(1);
  c = time(c);
  const id = c.condition!.care!.diseases[0]!.id;
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 2,
      total: 2,
      chronicRoll: null,
    },
  });
  expect(c.condition!.care!.diseases[0]!.blocked).toBe(true);
  c = time(c);
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 20,
      total: 20,
      chronicRoll: 1,
    },
  });
  expect(
    c.condition!.care!.diseases.filter((d) => d.active).map((d) => d.kind),
  ).toEqual(['hemophilia']);
});
it('exactly half food/water creates no shortage; fifth zero-food day creates one hunger source and advances game time', () => {
  let c = record();
  const day = (id: string, foodMg: number, waterMl: number) => ({
    type: 'care' as const,
    command: {
      kind: 'day' as const,
      id,
      foodMg,
      waterMl,
      hungerSave: 10,
      foodEntryId: null,
      foodQuantity: 0,
      waterEntryId: null,
      waterQuantity: 0,
    },
  });
  c = apply(c, day('Połowa', 250000, 1000));
  expect(c.condition!.exhaustion).toHaveLength(0);
  expect(c.condition!.worldMinutes).toBe(1440);
  for (let i = 0; i < 5; i++) c = apply(c, day('Bez jedzenia ' + i, 0, 2000));
  expect(
    c.condition!.exhaustion.filter((e) => e.cause === 'hunger'),
  ).toHaveLength(1);
  const s = fixture('brutal');
  s.originId = 'desert';
  s.levels[0]!.choices.origin = ['diet'];
  expect(nutritionNeeds(complete(s))).toEqual({
    foodMg: 250000,
    waterMl: 1000,
  });
});
it('fabricator halves production time and supplies halves material cost without altering time', () => {
  expect(productionValues(6, false, [])).toEqual({
    cost: 3,
    minutes: 360,
    dc: 5,
  });
  expect(productionValues(6, false, ['fabricator'])).toEqual({
    cost: 3,
    minutes: 180,
    dc: 5,
  });
  expect(productionValues(6, false, ['fabricator', 'supplies'])).toEqual({
    cost: 1,
    minutes: 180,
    dc: 5,
  });
});
it('production failure keeps materials; later success consumes once and creates exactly one product', () => {
  let c = record();
  const material = newInventoryEntry(customItem('Surowce'));
  material.quantityMilli = 3000;
  c.inventory = { ...emptyInventory(), entries: [material] };
  const id = crypto.randomUUID(),
    output = newInventoryEntry(customItem('Narzędzie'));
  c = apply(c, {
    type: 'downtime',
    command: {
      kind: 'project',
      project: {
        id,
        label: 'Narzędzie',
        output,
        price: 2,
        singleUse: true,
        repairId: null,
        tools: 'Kowal',
        proficient: true,
        schematic: true,
        materials: [{ id: material.id, quantity: 1000, valueGb: 1 }],
        override: null,
      },
    },
  });
  c = apply(c, {
    type: 'downtime',
    command: { kind: 'work', id, minutes: 60, finish: true, total: 1 },
  });
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(3000);
  expect(c.condition!.downtime!.projects[0]!.progress).toBe(0);
  c = apply(c, {
    type: 'downtime',
    command: { kind: 'work', id, minutes: 60, finish: true, total: 5 },
  });
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(2000);
  expect(c.inventory!.entries).toHaveLength(2);
  expect(() =>
    apply(c, {
      type: 'downtime',
      command: { kind: 'work', id, minutes: 60, finish: true, total: 5 },
    }),
  ).toThrow();
});
it('medpak uses cap at two per game day, stock and HP update together; next day restores allowance only', () => {
  let c = record();
  const e = newInventoryEntry(customItem('Medpak'));
  e.quantityMilli = 4000;
  c.inventory = { ...emptyInventory(), entries: [e] };
  const a: ConditionAction = {
    type: 'downtime',
    command: {
      kind: 'healingItem',
      entryId: e.id,
      formula: 'medpak',
      rolls: [2, 3],
      wisSave: null,
    },
  };
  c = apply(c, a);
  expect(c.condition!.hp).toBe(8);
  c = apply(c, a);
  expect(c.condition!.hp).toBe(15);
  expect(() => apply(c, a)).toThrow();
  c = time(c);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(2000);
  c = apply(c, a);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(1000);
});
it('completed training grants proficiency and a work day cannot exceed ten hours', () => {
  let c = record();
  const id = crypto.randomUUID();
  for (let i = 0; i < 30; i++) {
    c = apply(c, {
      type: 'downtime',
      command: {
        kind: 'training',
        id,
        target: 'tool:cook',
        minutes: 600,
        teacher: true,
        paid: 10,
      },
    });
    expect(() =>
      apply(c, {
        type: 'downtime',
        command: {
          kind: 'training',
          id,
          target: 'tool:cook',
          minutes: 1,
          teacher: true,
          paid: 1,
        },
      }),
    ).toThrow();
    c = time(c, 840);
  }
  expect(c.condition!.downtime!.training[0]!.completed).toBe(true);
  expect(conditionView(c).derived.rank('tool:cook')).toBe(1);
});

it('rat fever blocks all rest benefits and successful cure removes the block without erasing exhaustion', () => {
  let c = record();
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'disease',
      id,
      disease: 'rat',
      details: 'Gorączka',
      onsetMinutes: 0,
    },
  });
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 2,
      total: 2,
      chronicRoll: null,
    },
  });
  c = apply(c, {
    type: 'use',
    resourceId: 'berserk',
    amount: 1,
    healingRoll: null,
  });
  c = apply(c, { type: 'restStart', id: crypto.randomUUID(), kind: 'long' });
  const a: ConditionAction = {
    type: 'restApply',
    sessionId: c.condition!.rest!.id,
    outcome: 'complete',
    elapsed: 1440,
    sleep: 360,
    armored: false,
    consecutive: true,
    food: true,
    water: true,
    warm: true,
    exhaustionId: null,
    medicProficient: false,
    medicTools: false,
    healingSave: null,
    rolls6: [],
    rolls8: [],
    kolejkaLevel: 0,
    kolejkaRolls: [],
  };
  c = apply(c, a);
  expect(c.condition!.hp).toBe(1);
  expect(c.condition!.spent.berserk).toBe(1);
  c = time(c);
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'diseaseCheck',
      id,
      natural: 15,
      total: 15,
      chronicRoll: null,
    },
  });
  expect(c.condition!.care!.diseases[0]!.blocked).toBe(false);
  expect(c.condition!.exhaustion).toHaveLength(1);
});
it('cooking consumes ingredients, grants a timed Fuks only outside Mercury and prevents more than one hour work during short rest', () => {
  let c = record();
  const food = newInventoryEntry(customItem('Składniki'));
  food.quantityMilli = 4000;
  c.inventory = { ...emptyInventory(), entries: [food] };
  const a: ConditionAction = {
    type: 'downtime',
    command: {
      kind: 'cook',
      tools: true,
      ingredients: [{ id: food.id, quantity: 1000, valueGb: 0 }],
      total: 20,
    },
  };
  c = apply(c, a);
  expect(c.condition!.fuks).toHaveLength(1);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(3000);
  c.sheet!.rulesContext.gameColor = 'mercury';
  c = apply(c, a);
  expect(c.condition!.fuks).toHaveLength(1);
  c = apply(c, { type: 'restStart', id: crypto.randomUUID(), kind: 'short' });
  expect(() => apply(c, a)).toThrow(/godzinę/);
  c = time(c);
  expect(c.condition!.fuks).toHaveLength(0);
});
it('repair restores an existing armor without duplicating it, moving it or changing stock on failure', () => {
  let c = record();
  const armor = newInventoryEntry(customItem('Pancerz')),
    material = newInventoryEntry(customItem('Części'));
  armor.armorDamage = 3;
  c.inventory = { ...emptyInventory(), entries: [armor, material] };
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'downtime',
    command: {
      kind: 'project',
      project: {
        id,
        label: 'Naprawa',
        output: { ...armor, armorDamage: 0 },
        repairId: armor.id,
        price: 10,
        singleUse: false,
        tools: 'Kowal',
        proficient: true,
        schematic: true,
        materials: [{ id: material.id, quantity: 1000, valueGb: 1 }],
        override: {
          cost: 1,
          minutes: 2,
          dc: 10,
          source: 'Neuroshima: Ostatnia Era, s. 146',
        },
      },
    },
  });
  c = apply(c, {
    type: 'downtime',
    command: { kind: 'work', id, minutes: 2, finish: true, total: 10 },
  });
  expect(c.inventory!.entries).toHaveLength(2);
  expect(c.inventory!.entries[0]!.id).toBe(armor.id);
  expect(c.inventory!.entries[0]!.armorDamage).toBe(0);
});

it('starting illness bonus does not invalidate the originally assigned score array', () => {
  let c = record();
  const sheet = fixture('brutal', 1);
  sheet.method = 'array-a';
  sheet.baseScores = { str: 15, dex: 14, con: 13, int: 12, wis: 10, cha: 8 };
  c.sheet = complete(sheet);
  const medicine = newInventoryEntry(customItem('Aspiryna K'));
  medicine.quantityMilli = 3000;
  medicine.unit = 'dawka';
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'start',
      group: 'disease',
      choice: 1,
      ability: 'cha',
      id: crypto.randomUUID(),
      medicine,
    },
  });
  expect(conditionView(c).derived.scores.cha.value).toBe(9);
  expect(conditionView(c).derived.issues).toHaveLength(0);
});
it('direct starting choice can decline an illness once for minus one without doses', () => {
  let c = record();
  const before = conditionView(c).derived.scores.cha.value!;
  const action: ConditionAction = {
    type: 'care',
    command: {
      kind: 'start',
      group: 'disease',
      choice: -1,
      ability: 'cha',
      id: crypto.randomUUID(),
      medicine: null,
    },
  };
  c = apply(c, action);
  expect(conditionView(c).derived.scores.cha.value).toBe(before - 1);
  expect(c.condition!.care!.diseases).toHaveLength(0);
  expect(c.inventory!.entries).toHaveLength(0);
  expect(() => apply(c, action)).toThrow();
});

it('sztuka is a dose and RadOff treats exposure without any illness', () => {
  let c = record();
  const med = newInventoryEntry(customItem('RadOff'));
  med.quantityMilli = 2000;
  c.inventory = { ...emptyInventory(), entries: [med] };
  c = apply(c, {
    type: 'exhaustion',
    entry: {
      id: crypto.randomUUID(),
      cause: 'radiation',
      source: 'Ekspozycja',
      level: 2,
    },
  });
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'medicine',
      id: crypto.randomUUID(),
      entryId: med.id,
      doses: 1,
      treatment: 'exposure',
      sideSave: 10,
    },
  });
  expect(c.condition!.exhaustion).toHaveLength(0);
  expect(c.condition!.care!.diseases).toHaveLength(0);
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(1000);
  expect(c.condition!.downtime!.benefits[0]!.expiresAt).toBe(1);
});
it('Mercury rejects both instant healing items without consuming doses', () => {
  for (const formula of ['medpak', 'ar23'] as const) {
    const c = record();
    c.sheet!.rulesContext.gameColor = 'mercury';
    const med = newInventoryEntry(
      customItem(formula === 'medpak' ? 'Medpak' : 'AR-23'),
    );
    c.inventory = { ...emptyInventory(), entries: [med] };
    expect(() =>
      apply(c, {
        type: 'downtime',
        command: {
          kind: 'healingItem',
          entryId: med.id,
          formula,
          rolls: formula === 'medpak' ? [3, 4] : [3, 4, 2, 2],
          wisSave: 15,
        },
      }),
    ).toThrow(/Rtęć/);
    expect(c.inventory.entries[0]!.quantityMilli).toBe(1000);
  }
});
it('chronic medicine from a generic piece stock works without editing its unit', () => {
  let c = record();
  const med = newInventoryEntry(customItem('Aspiryna K'));
  c.inventory = { ...emptyInventory(), entries: [med] };
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'disease',
      id,
      disease: 'circulation',
      details: 'test',
      onsetMinutes: 0,
    },
  });
  c = apply(c, {
    type: 'care',
    command: {
      kind: 'medicine',
      id,
      entryId: med.id,
      doses: 1,
      treatment: 'daily',
      sideSave: null,
    },
  });
  expect(c.inventory!.entries[0]!.quantityMilli).toBe(0);
  expect(c.condition!.care!.diseases[0]!.treatedDay).toBe(0);
});
it('exports native health and downtime parity fixtures', () => {
  expect(cases.length).toBeGreaterThan(90);
  if (process.env.GENERATE_CARE_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-care.json',
      JSON.stringify(cases) + '\n',
    );
});
