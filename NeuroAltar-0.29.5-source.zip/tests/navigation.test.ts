import { useDiceStore } from '../src/stores/diceStore';
import { afterEach, expect, it } from 'vitest';
import { useNavigationStore } from '../src/stores/navigationStore';
import { useBestiaryStore } from '../src/stores/bestiaryStore';
import { combatWorkspaceActive } from '../src/services/workspaceShortcuts';

afterEach(() => {
  useDiceStore.getState().setOpen(false);
  useNavigationStore.getState().navigate('home');
  useBestiaryStore.setState({ view: 'combat', form: null });
});
it('enables combat keyboard actions only in the visible combat workspace', () => {
  for (const page of ['home', 'gm', 'character'] as const) {
    for (const view of [
      'combat',
      'bestiary',
      'equipment',
      'reference',
    ] as const) {
      useNavigationStore.getState().navigate(page);
      useBestiaryStore.setState({ view });
      expect(combatWorkspaceActive()).toBe(page === 'gm' && view === 'combat');
    }
  }
});
it('keeps an unfinished catalog form and chosen module across home and BG navigation', () => {
  useBestiaryStore.getState().open();
  useBestiaryStore
    .getState()
    .edit({ name: 'Żółty konwojent', hpMax: 'niepełne' });
  const before = useBestiaryStore.getState().form;
  for (const page of ['home', 'character', 'gm'] as const)
    useNavigationStore.getState().navigate(page);
  expect(useBestiaryStore.getState().form).toBe(before);
});

it('blocks combat shortcuts while the floating dice panel is expanded', () => {
  useNavigationStore.getState().navigate('gm');
  useBestiaryStore.setState({ view: 'combat' });
  useDiceStore.getState().setOpen(true);
  expect(combatWorkspaceActive()).toBe(false);
  useDiceStore.getState().setOpen(false);
  expect(combatWorkspaceActive()).toBe(true);
});
