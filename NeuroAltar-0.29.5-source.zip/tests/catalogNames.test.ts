import { describe, expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import { itemSchema } from '../src/domain/item';
import {
  itemDisplayName,
  withItemDisplayName,
} from '../src/domain/catalogNames';
import { filterEquipment } from '../src/domain/equipment';
import { catalogEntry } from '../src/domain/character/inventoryCatalog';
const items = catalog.entries.map((i) => itemSchema.parse(i));
describe('magazine display names', () => {
  it.each([
    ['Broń palna krótka', 'BPK'],
    ['Broń palna pośrednia', 'BPP'],
    ['Broń palna długa', 'BPD'],
    ['Broń palna ciężka', 'BPC'],
  ])(
    'renames %s without changing source IDs, price, quantity or the original snapshot',
    (name, code) => {
      const source = items.find((i) => i.name === name)!;
      const before = structuredClone(source);
      const display = withItemDisplayName(source);
      expect(display).toEqual({ ...source, name: `Magazynek (${code})` });
      expect(filterEquipment(items, `magazynek ${code}`, '', '')).toEqual([
        display,
      ]);
      const copy = catalogEntry(source);
      expect(copy.item.name).toBe(display.name);
      expect(copy.catalogId).toBe(source.id);
      expect(itemDisplayName(before)).toBe(display.name);
      expect(source).toEqual(before);
      expect(
        itemDisplayName({ ...source, name: 'Mój zapasowy magazynek' }),
      ).toBe('Mój zapasowy magazynek');
      expect(withItemDisplayName(display)).toBe(display);
    },
  );
  it('does not rename weapons, custom items or the quiver', () => {
    for (const source of items.filter(
      (i) => i.type === 'weapon' || i.name.includes('Kołczan'),
    ))
      expect(itemDisplayName(source)).toBe(source.name);
    expect(
      itemDisplayName({ id: crypto.randomUUID(), name: 'Broń palna długa' }),
    ).toBe('Broń palna długa');
  });
});
