import { expect, it } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { listKnowledge } from '../src/data/knowledge/catalog';
import handbook from '../src/data/knowledge/handbook-tables.v1.json';
import { EquipmentReferenceTables } from '../src/features/equipment/EquipmentReferenceTables';
import { VehicleWorkspace } from '../src/features/vehicles/VehicleWorkspace';

const entries = listKnowledge();
function rows(title: string) {
  const entry = entries.find((candidate) => candidate.title === title)!;
  const table = entry.blocks.find((block) => block.kind === 'table')!;
  if (table.kind !== 'table') throw new Error(`Brak tabeli: ${title}`);
  return table.rows.map((row) => row.cells.map((cell) => cell.text));
}

it('adds the 29 identified handbook tables without class progression tables', () => {
  expect(handbook.entries).toHaveLength(29);
  expect(rows('Tabela obrażeń miażdżącej serii')).toHaveLength(4);
  expect(rows('Broń specjalna')).toHaveLength(2);
  expect(rows('Broń palna ciężka')).toHaveLength(9);
  expect(rows('Tabela surowców')).toHaveLength(5);
  expect(rows('Tabela awarii pojazdów silnikowych')).toHaveLength(20);
  expect(rows('Tabela bebeszenia bestii')).toHaveLength(5);
  expect(entries.some((entry) => entry.title.includes('rozwoju klasy'))).toBe(
    false,
  );
});

it('shows all weapon upgrades, complete loot roll coverage and source gap 85', () => {
  expect(rows('Ulepszenia broni białej')).toHaveLength(7);
  expect(rows('Ulepszenia broni dystansowej')).toHaveLength(22);
  const loot = rows('Tabela Fantów');
  const covered = new Set<number>();
  for (const [range] of loot) {
    const match = range!.match(/^(\d+)(?:[-–](\d+))?$/)!;
    for (
      let roll = Number(match[1]);
      roll <= Number(match[2] ?? match[1]);
      roll++
    )
      covered.add(roll);
  }
  expect([...covered].sort((a, b) => a - b)).toEqual(
    Array.from({ length: 100 }, (_, index) => index + 1),
  );
  expect(loot.find((row) => row[0] === '85')).toEqual([
    '85',
    'Brak pozycji w drukowanym podręczniku',
    '—',
  ]);
  const upgradesHtml = renderToStaticMarkup(
    createElement(EquipmentReferenceTables, { section: 'upgrades' }),
  );
  expect(upgradesHtml).toContain('Granatnik podwieszany');
  const lootHtml = renderToStaticMarkup(
    createElement(EquipmentReferenceTables, { section: 'loot' }),
  );
  expect(lootHtml).toContain('Papier toaletowy');
});

it('lists all 14 handbook vehicles as a table with their source page', () => {
  const vehicles = rows('Tabela statystyk wybranych pojazdów');
  expect(vehicles).toHaveLength(14);
  expect(vehicles.map((row) => row[0])).toContain('Motocykl');
  expect(vehicles.map((row) => row[0])).toContain('Czołg');
  const html = renderToStaticMarkup(createElement(VehicleWorkspace));
  expect(html).toContain('Tabela statystyk wybranych pojazdów');
  expect(html).toContain('Ładowność');
  expect(html).toContain('Neuroshima: Ostatnia Era · s. 262');
});
