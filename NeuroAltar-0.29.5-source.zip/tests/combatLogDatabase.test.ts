import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { expect, it } from 'vitest';
import { createCombatLogRepository } from '../src/db/combatLogRepository';
import { createCombatRepository } from '../src/db/combatRepository';
import { LOG_PAGE_SIZE } from '../src/domain/combatLog';
const migrations = [
  '001_initial.sql',
  '002_pc_initiative.sql',
  '003_enemy_instances.sql',
  '004_combat_log.sql',
].map((file) =>
  readFileSync(
    new URL(`../src-tauri/migrations/${file}`, import.meta.url),
    'utf8',
  ),
);
function connection(db: DatabaseSync) {
  return {
    selectRows: async (sql: string, values: (string | number)[] = []) =>
      db.prepare(sql).all(...values),
    execute: async (sql: string, values: (string | number)[]) => ({
      rowsAffected: Number(db.prepare(sql).run(...values).changes),
    }),
  };
}
it('adds an empty log without changing existing actors, turns, notes or prepared snapshots', async () => {
  const db = new DatabaseSync(':memory:');
  try {
    migrations.slice(0, 3).forEach((sql) => db.exec(sql));
    const actor = {
      id: '00000000-0000-4000-8000-000000000001',
      displayName: 'Żaneta',
      ttCurrent: 14,
      hpCurrent: 12,
      hpMaxCurrent: 20,
      initiativeValue: 7,
      initiativeTieOrder: 0,
      statuses: ['Zatrucie'],
    };
    db.prepare(
      `INSERT INTO encounter_actors (id,encounter_id,kind,display_name,initiative_value,initiative_tie_order,tt_current,hp_current,hp_max_current,prepared_snapshot_json,runtime_overrides_json) VALUES (?,1,'pc',?,7,0,14,12,20,?,?)`,
    ).run(
      actor.id,
      actor.displayName,
      JSON.stringify(actor),
      JSON.stringify({ manualStatuses: actor.statuses }),
    );
    db.prepare(
      'UPDATE encounters SET round_number=4,current_turn_actor_id=?,notes=? WHERE id=1',
    ).run(actor.id, 'Notatki\nZażółć');
    const rows = db.prepare('SELECT * FROM encounters').all();
    const actors = db.prepare('SELECT * FROM encounter_actors').all();
    db.exec(
      readFileSync(
        new URL(
          '../src-tauri/migrations/005_actor_statuses.sql',
          import.meta.url,
        ),
        'utf8',
      ),
    );
    const before = await createCombatRepository(connection(db)).listSlots();
    db.exec('BEGIN');
    db.exec(migrations[3]!);
    db.exec('COMMIT');
    expect(db.prepare('SELECT * FROM encounters').all()).toEqual(rows);
    expect(db.prepare('SELECT * FROM encounter_actors').all()).toEqual(actors);
    expect(await createCombatRepository(connection(db)).listSlots()).toEqual(
      before,
    );
    expect(await createCombatLogRepository(connection(db)).page(1)).toEqual({
      entries: [],
      hasMore: false,
    });
    expect(db.prepare('PRAGMA integrity_check').get()).toEqual({
      integrity_check: 'ok',
    });
  } finally {
    db.close();
  }
});
it('reads stable pages across a real restart, retains removed actor names and isolates slots', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'neuroaltar-log-'));
  const path = join(dir, 'log.sqlite');
  let db = new DatabaseSync(path);
  try {
    migrations.forEach((sql) => db.exec(sql));
    const insert = db.prepare(
      "INSERT INTO combat_log (encounter_id,round_number,actor_id,event_type,message,payload_json,created_at) VALUES (?,2,?,'hp_changed',?,?,'2026-09-07T10:00:00.000Z')",
    );
    for (let i = 1; i <= LOG_PAGE_SIZE + 2; i++)
      insert.run(
        1,
        '00000000-0000-4000-8000-000000000001',
        `Żaneta ${i} — PW: 20/20 → 19/20.`,
        JSON.stringify({
          before: { current: 20, max: 20 },
          after: { current: 19, max: 20 },
        }),
      );
    insert.run(
      2,
      null,
      'Tylko drugi slot',
      JSON.stringify({ before: null, after: null }),
    );
    let repo = createCombatLogRepository(connection(db));
    const first = await repo.page(1);
    expect(first.entries).toHaveLength(LOG_PAGE_SIZE);
    expect(first.hasMore).toBe(true);
    expect(first.entries[0]!.id).toBe(LOG_PAGE_SIZE + 2);
    db.close();
    db = new DatabaseSync(path);
    repo = createCombatLogRepository(connection(db));
    expect(await repo.page(1)).toEqual(first);
    const second = await repo.page(1, first.entries.at(-1)!.id);
    expect(second.entries.map((e) => e.id)).toEqual([2, 1]);
    expect(second.hasMore).toBe(false);
    expect((await repo.page(2)).entries[0]!.message).toBe('Tylko drugi slot');
    await expect(repo.page(6)).rejects.toThrow();
    await expect(repo.page(1, -1)).rejects.toThrow();
    expect(() =>
      db.exec("UPDATE combat_log SET payload_json='[]' WHERE id=1"),
    ).toThrow();
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
