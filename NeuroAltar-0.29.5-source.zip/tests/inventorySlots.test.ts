import { describe, expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import { itemSchema } from '../src/domain/item';
import {
  catalogEntry,
  customItem,
} from '../src/domain/character/inventoryCatalog';
import {
  emptyInventory,
  newInventoryEntry,
  type InventoryEntry,
} from '../src/domain/character/inventoryModel';
import {
  applyInventoryAction,
  countRounds,
  validateInventory,
} from '../src/domain/character/inventory';
import {
  allowedSlots,
  availableSlotOptions,
  displayedSlot,
  isReadyWeapon,
  weaponGrip,
  weaponSlotKind,
} from '../src/domain/character/inventorySlots';
import {
  deriveEquipment,
  deriveInventoryWeapon,
} from '../src/domain/character/equipped';
import { inventoryFixture } from './helpers/inventory';
import { complete, fixture } from './helpers/character';
const get = (name: string) =>
  catalogEntry(itemSchema.parse(catalog.entries.find((e) => e.name === name)));
const prepared = (name: string, slot: InventoryEntry['slot']) => ({
  ...get(name),
  slot,
  location: 'body' as const,
});
const handy = (name: string, slot: InventoryEntry['slot']) => ({
  ...newInventoryEntry(customItem(name)),
  slot,
  location: 'handy' as const,
});

describe('numbered character-sheet storage slots', () => {
  it('holds four melee weapons, three ranged weapons and three handy items independently', () => {
    const inv = {
      ...emptyInventory(),
      entries: [
        prepared('Maczeta', 'melee1'),
        prepared('Katana', 'melee2'),
        prepared('Maczeta', 'melee3'),
        prepared('Katana', 'melee4'),
        prepared('AR', 'ranged1'),
        prepared('AR', 'ranged2'),
        prepared('M14', 'ranged3'),
        handy('Medpak', 'handy1'),
        handy('Zapasowy magazynek', 'handy2'),
        handy('Lina', 'handy3'),
      ],
    };
    expect(validateInventory(inv)).toEqual(inv);
    expect(inv.entries.slice(0, 7).every(isReadyWeapon)).toBe(true);
    const duplicate = structuredClone(inv.entries[0]!);
    duplicate.id = crypto.randomUUID();
    expect(() =>
      validateInventory({ ...inv, entries: [...inv.entries, duplicate] }),
    ).toThrow('zajęte');
  });
  it('rejects wrong categories, backpack locations and container placement', () => {
    const gun = prepared('AR', 'melee1');
    const inv = { ...emptyInventory(), entries: [gun] };
    expect(() => validateInventory(inv)).toThrow('Typ broni');
    gun.slot = 'ranged1';
    gun.location = 'backpack' as 'body';
    expect(isReadyWeapon(gun)).toBe(false);
    expect(() => validateInventory(inv)).toThrow('przy sobie');
    gun.location = 'body';
    gun.slot = 'handy1';
    expect(() => validateInventory(inv)).toThrow('podręcznego');
    gun.slot = 'ranged1';
    gun.parentId = crypto.randomUUID();
    expect(isReadyWeapon(gun)).toBe(false);
    expect(() => validateInventory(inv)).toThrow();
  });
  it('keeps thrown melee weapons in melee storage and permits grenades under hand', () => {
    const knife = prepared('Maczeta', 'melee1');
    knife.item.weaponProfile!.properties.push('rzucana');
    expect(weaponSlotKind(knife)).toBe('melee');
    const grenade = handy('Granat testowy', 'handy1');
    grenade.item.type = 'weapon';
    expect(allowedSlots(grenade)).toEqual(['handy1', 'handy2', 'handy3']);
    expect(
      validateInventory({ ...emptyInventory(), entries: [grenade] }),
    ).toBeDefined();
    grenade.quantityMilli = 2000;
    expect(() =>
      validateInventory({ ...emptyInventory(), entries: [grenade] }),
    ).toThrow('ilości 1');
  });
  it('projects old hands into available numbered slots without changing saved values', () => {
    const { i, w, m } = inventoryFixture();
    w.installedMagazineId = m.id;
    m.location = 'handy';
    const newer = prepared('AR', 'ranged1');
    const oldHandy = handy('Latarka', 'none');
    i.entries.push(newer, oldHandy);
    const before = structuredClone(i);
    expect(displayedSlot(i, w)).toBe('ranged2');
    expect(displayedSlot(i, oldHandy)).toBe('handy1');
    expect(displayedSlot(i, m)).toBe('none');
    expect(
      availableSlotOptions(i, w).find((x) => x.slot === 'ranged1')?.occupiedBy,
    ).toBe('AR');
    expect(
      availableSlotOptions(i, w).find((x) => x.slot === 'ranged2')?.occupiedBy,
    ).toBeUndefined();
    expect(weaponGrip(w)).toBe('twoHanded');
    expect(i).toEqual(before);
    oldHandy.quantityMilli = 2000;
    expect(displayedSlot(i, oldHandy)).toBe('none');
  });
  it('supports new shield storage and rejects duplicate legacy/new shields', () => {
    const shield = get('Hełm');
    shield.item.name = 'Tarcza testowa';
    shield.armor!.kind = 'shield';
    shield.slot = 'shield';
    shield.location = 'body';
    expect(
      validateInventory({ ...emptyInventory(), entries: [shield] }),
    ).toBeDefined();
    const legacy = structuredClone(shield);
    legacy.id = crypto.randomUUID();
    legacy.slot = 'offHand';
    expect(() =>
      validateInventory({ ...emptyInventory(), entries: [legacy, shield] }),
    ).toThrow('zajęte');
    expect(
      displayedSlot({ ...emptyInventory(), entries: [legacy] }, legacy),
    ).toBe('shield');
  });
  it('fires from a numbered slot and preserves cartridge and magazine references', () => {
    const { i, w, m, a } = inventoryFixture();
    let next = applyInventoryAction(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 3 },
      'none',
    );
    next = applyInventoryAction(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    const updated = {
      ...next.entries[0]!,
      slot: 'ranged2' as const,
      grip: 'twoHanded' as const,
    };
    next = applyInventoryAction(
      next,
      { kind: 'edit', entry: updated, reason: 'Zmiana miejsca' },
      'none',
    );
    const fired = applyInventoryAction(
      next,
      { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
      'none',
    );
    expect(countRounds(fired.entries[1]!)).toBe(2);
    expect(fired.entries[0]!.installedMagazineId).toBe(m.id);
    expect(fired.entries[1]!.magazine!.rounds[0]!.ammoId).toBe(a.id);
    expect(next.entries[0]!.slot).toBe('ranged2');
    expect(countRounds(next.entries[1]!)).toBe(3);
  });
  it('reloads from a handy slot and transfers that place to the outgoing magazine without moving rounds', () => {
    const { i, w, m, a } = inventoryFixture();
    w.slot = 'ranged1';
    const spare = structuredClone(m);
    spare.id = crypto.randomUUID();
    spare.item.name = 'Zapasowy magazynek';
    spare.slot = 'handy2';
    spare.location = 'handy';
    i.entries.push(spare);
    let next = applyInventoryAction(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 2 },
      'none',
    );
    next = applyInventoryAction(
      next,
      { kind: 'load', magazineId: spare.id, ammoId: a.id, count: 3 },
      'none',
    );
    next = applyInventoryAction(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    const loaded = applyInventoryAction(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: spare.id },
      'none',
    );
    expect(loaded.entries[0]!.installedMagazineId).toBe(spare.id);
    expect(loaded.entries.find((e) => e.id === m.id)).toMatchObject({
      slot: 'handy2',
      location: 'handy',
      parentId: null,
    });
    expect(loaded.entries.find((e) => e.id === spare.id)).toMatchObject({
      slot: 'none',
      parentId: null,
    });
    expect(countRounds(loaded.entries.find((e) => e.id === m.id)!)).toBe(2);
    expect(countRounds(loaded.entries.find((e) => e.id === spare.id)!)).toBe(3);
    expect(loaded.entries.find((e) => e.id === a.id)!.quantityMilli).toBe(
      25000,
    );
    expect(
      applyInventoryAction(
        loaded,
        { kind: 'attach', weaponId: w.id, magazineId: spare.id },
        'none',
      ),
    ).toEqual(loaded);
    expect(next.entries.find((e) => e.id === spare.id)!.slot).toBe('handy2');
  });
  it('clears the spare slot when attaching the first magazine and does not free slots of incompatible magazines', () => {
    const { i, w, m } = inventoryFixture();
    w.slot = 'ranged1';
    m.slot = 'handy1';
    m.location = 'handy';
    const loaded = applyInventoryAction(
      i,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    expect(loaded.entries[1]!.slot).toBe('none');
    expect(i.entries[1]!.slot).toBe('handy1');
    m.magazine!.model = 'Inny model';
    expect(() =>
      applyInventoryAction(
        i,
        { kind: 'attach', weaponId: w.id, magazineId: m.id },
        'none',
      ),
    ).toThrow('nie pasuje');
    expect(m.slot).toBe('handy1');
  });
  it('separates firearm grip from storage and supports explicit versatile damage choices', () => {
    const sheet = complete(fixture('twardziel'));
    const gun = prepared('AR', 'ranged1');
    expect(deriveInventoryWeapon(sheet, gun)!.disadvantage).toBe(false);
    expect(
      deriveInventoryWeapon(
        sheet,
        gun,
        'single',
        1,
        'auto',
        undefined,
        undefined,
        'normal',
        'oneHanded',
      )!.disadvantage,
    ).toBe(true);
    const sword = prepared('Katana', 'melee1');
    const mode = sword.item.weaponProfile!.damageModes.find(
      (m) => m.id === 'two-hands',
    );
    expect(mode).toBeDefined();
    expect(
      deriveInventoryWeapon(sheet, sword, 'single', 1, 'auto', mode!.id)!
        .damageModeId,
    ).toBe('two-hands');
    sword.grip = 'twoHanded';
    expect(deriveInventoryWeapon(sheet, sword)!.damageModeId).toBe('two-hands');
    expect(
      deriveInventoryWeapon(
        sheet,
        sword,
        'single',
        1,
        'auto',
        sword.item.weaponProfile!.damageModes[0]!.id,
      )!.damageModeId,
    ).toBe(sword.item.weaponProfile!.damageModes[0]!.id);
  });
  it('required two-handed weapons override stale one-handed UI and saved grip values', () => {
    const sheet = complete(fixture('twardziel'));
    const gun = prepared('AR', 'ranged1');
    gun.weapon!.twoHanded = true;
    gun.grip = 'oneHanded';
    expect(
      deriveInventoryWeapon(
        sheet,
        gun,
        'single',
        1,
        'auto',
        undefined,
        undefined,
        'normal',
        'oneHanded',
      )!.disadvantage,
    ).toBe(false);
    expect(
      deriveInventoryWeapon(
        sheet,
        gun,
        'single',
        1,
        'auto',
        undefined,
        undefined,
        'long',
        'oneHanded',
      )!.disadvantage,
    ).toBe(true);
    const sword = prepared('Katana', 'melee1');
    sword.weapon!.twoHanded = true;
    sword.grip = 'oneHanded';
    expect(
      deriveInventoryWeapon(
        sheet,
        sword,
        'single',
        1,
        'auto',
        undefined,
        undefined,
        'normal',
        'oneHanded',
      )!.damageModeId,
    ).toBe('two-hands');
  });
  it('does not infer a wielding bonus merely from carrying prepared weapons', () => {
    const sheet = fixture('twardziel');
    sheet.levels[0]!.choices.start = ['samurai'];
    complete(sheet);
    const sword = prepared('Katana', 'melee1');
    const inv = { ...emptyInventory(), entries: [sword] };
    const base = deriveEquipment(sheet, emptyInventory()).armor;
    expect(deriveEquipment(sheet, inv).armor).toEqual(base);
    sword.slot = 'mainHand';
    expect(deriveEquipment(sheet, inv).armor[0]!.value).toBe(
      base[0]!.value! + 1,
    );
    const soldier = fixture('twardziel');
    soldier.levels[0]!.choices.veteran = ['butcher'];
    complete(soldier);
    const gun = prepared('AR', 'ranged1');
    const single = { ...emptyInventory(), entries: [gun] };
    expect(
      deriveInventoryWeapon(
        soldier,
        gun,
        'single',
        1,
        'auto',
        undefined,
        single,
      )!.damage,
    ).toBe('2k6 + 4');
  });
});
