import { describe, expect, it } from 'vitest';
import {
  newCharacter,
  characterSchema,
  type Character,
} from '../src/domain/character/model';
import {
  conditionView,
  previewCondition,
} from '../src/domain/character/condition';
import { complete, fixture } from './helpers/character';
import type { DowntimeCommand } from '../src/domain/character/downtimeModel';

function character() {
  const record = newCharacter();
  record.sheet = complete(fixture('brutal', 3));
  record.draft = null;
  return record;
}
function training(record: Character, command: DowntimeCommand): Character {
  const result = previewCondition(
    record,
    { type: 'downtime', command },
    crypto.randomUUID(),
  );
  return { ...record, condition: result.state };
}

describe('persisted training progress', () => {
  it('continues the same course after serializing without granting an unfinished proficiency', () => {
    const command = {
      kind: 'training' as const,
      id: crypto.randomUUID(),
      target: 'tool:cook',
      minutes: 60,
      teacher: true,
      paid: 1,
    };
    const first = training(character(), command);
    const reopened = characterSchema.parse(JSON.parse(JSON.stringify(first)));
    const next = training(reopened, { ...command, minutes: 90, paid: 1.5 });
    expect(next.condition!.downtime!.training).toHaveLength(1);
    expect(next.condition!.downtime!.training[0]).toMatchObject({
      id: command.id,
      minutes: 150,
      completed: false,
    });
    expect(conditionView(next).derived.rank('tool:cook')).toBe(0);
    expect(next.condition!.worldMinutes).toBe(150);
    expect(reopened.condition!.downtime!.training[0]!.minutes).toBe(60);
  });

  it('requires both the teacher and payment and rejects changing a continued target', () => {
    const command = {
      kind: 'training' as const,
      id: crypto.randomUUID(),
      target: 'tool:cook',
      minutes: 60,
      teacher: true,
      paid: 1,
    };
    const first = training(character(), command);
    expect(() => training(first, { ...command, teacher: false })).toThrow(
      /trenera/,
    );
    expect(() => training(first, { ...command, paid: 0 })).toThrow(/1 gb/);
    expect(() => training(first, { ...command, target: 'tool:medic' })).toThrow(
      /inny cel/,
    );
    expect(first.condition!.downtime!.training[0]!.minutes).toBe(60);
  });
});
