import { describe, expect, it, vi } from 'vitest';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import {
  templateDraft,
  filterCatalog,
  type CatalogEntry,
} from '../src/domain/bestiary';
import { parseEnemyTemplateDraft } from '../src/domain/enemy';
import { createBestiaryStore } from '../src/stores/bestiaryStore';
import { createBestiaryRepository } from '../src/db/bestiaryRepository';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import { parseCombatDraft } from '../src/domain/combat';
const entry: CatalogEntry = {
  revision: 0,
  template: {
    id: crypto.randomUUID(),
    name: 'Żmija Łąkowa',
    category: 'beast',
    size: 'Średni',
    tt: 15,
    hpMax: 88,
    speeds: [{ mode: 'Chód', meters: 4.5 }],
    capabilities: {
      legendaryMax: 2,
      resources: [
        {
          id: crypto.randomUUID(),
          name: 'Jad',
          maxValue: 3,
          refreshRule: 'encounter',
        },
      ],
      abilities: [],
    },
  },
};
describe('Bestiary', () => {
  it('round-trips setup without runtime counts and searches Polish text with combined filters', () => {
    const t = parseEnemyTemplateDraft(
      templateDraft(entry.template),
      entry.template.id,
    );
    expect(t.capabilities).toEqual(entry.template.capabilities);
    expect(t.speeds).toEqual(entry.template.speeds);
    expect(filterCatalog([entry], 'zmija lakowa', 'beast', 'Średni')).toEqual([
      entry,
    ]);
    expect(filterCatalog([entry], 'ŻMIJA', 'human', '')).toEqual([]);
    expect(filterCatalog([entry], '', 'beast', 'Duży')).toEqual([]);
  });
  it('keeps invalid and failed forms on close, retries the exact mutation and clears only after success', async () => {
    const save = vi
      .fn()
      .mockRejectedValueOnce(new Error('offline'))
      .mockResolvedValue(1);
    const store = createBestiaryStore(
      async () => [structuredClone(entry)],
      save,
    );
    await store.getState().load();
    store.getState().open(entry);
    store.getState().edit({ hpMax: '' });
    await store.getState().submit();
    expect(save).not.toHaveBeenCalled();
    expect(await store.getState().prepareClose()).toBe(false);
    store.getState().edit({ hpMax: '99' });
    await store.getState().submit();
    expect(store.getState().form?.fields.hpMax).toBe('99');
    expect(await store.getState().prepareClose()).toBe(false);
    await store.getState().retry();
    expect(save.mock.calls[0]).toEqual(save.mock.calls[1]);
    expect(store.getState().entries[0]?.template.hpMax).toBe(99);
    expect(await store.getState().prepareClose()).toBe(true);
  });
  it('duplicates into a new identity and never mutates source resources', async () => {
    const save = vi.fn().mockResolvedValue(0);
    const store = createBestiaryStore(
      async () => [structuredClone(entry)],
      save,
    );
    await store.getState().load();
    store.getState().open(entry, true);
    expect(store.getState().form?.id).not.toBe(entry.template.id);
    store.getState().edit({ name: 'Duplikat' });
    await store.getState().submit();
    expect(store.getState().entries).toHaveLength(2);
    expect(entry.template.name).toBe('Żmija Łąkowa');
    expect(save.mock.calls[0]?.[0].expectedRevision).toBeNull();
  });
  it('waits for in-flight writes during close and keeps a failed delete retryable', async () => {
    let resolve!: (n: number) => void;
    const store = createBestiaryStore(
      async () => [entry],
      () =>
        new Promise<number>((r) => {
          resolve = r;
        }),
    );
    await store.getState().load();
    const deleting = store.getState().remove(entry);
    const closing = store.getState().prepareClose();
    expect(store.getState().busy).toBe(true);
    resolve(1);
    await deleting;
    expect(await closing).toBe(true);
    expect(store.getState().entries).toEqual([]);
    const fail = createBestiaryStore(
      async () => [entry],
      async () => {
        throw new Error('write failed');
      },
    );
    await fail.getState().load();
    await fail.getState().remove(entry);
    expect(fail.getState().entries).toEqual([entry]);
    expect(await fail.getState().prepareClose()).toBe(false);
  });
  it('adds N in one combat checkpoint with independent full counters, blank initiatives and snapshots', async () => {
    const saved: unknown[] = [];
    const store = createCombatStore(
      async () =>
        SLOT_IDS.map((encounterId) => ({
          encounterId,
          revision: 0,
          roundNumber: 1,
          currentTurnActorId: null,
          actors: [],
        })),
      async (c) => {
        saved.push(structuredClone(c));
        return c.revision + 1;
      },
    );
    await store.getState().initialize();
    expect(store.getState().addEnemies(3, entry.template, 3)).toBe(true);
    await store.getState().flush(3);
    const c = store.getState().slots.find((c) => c.encounterId === 3)!;
    expect(saved).toHaveLength(1);
    expect(c.actors).toHaveLength(3);
    expect(new Set(c.actors.map((a) => a.id)).size).toBe(3);
    for (const a of c.actors) {
      expect(a.initiativeValue).toBeNull();
      expect(a.hpCurrent).toBe(88);
      expect(a.enemy?.capabilities?.resources[0]?.currentValue).toBe(3);
      expect(a.prepared?.enemy?.capabilities?.resources[0]?.currentValue).toBe(
        3,
      );
    }
    store.getState().editActor(3, c.actors[0]!.id, { hpCurrent: '1' });
    await store.getState().flush(3);
    expect(
      parseCombatDraft(
        store.getState().drafts[3]!.value,
        store.getState().slots.find((c) => c.encounterId === 3)!,
      ).actors[1]?.hpCurrent,
    ).toBe(88);
    store.getState().editActor(3, c.actors[0]!.id, { hpCurrent: '' });
    expect(store.getState().addEnemies(3, entry.template, 2)).toBe(false);
    expect(store.getState().addEnemies(1, entry.template, 0)).toBe(false);
    expect(store.getState().addEnemies(1, entry.template, 101)).toBe(false);
    store.getState().editActor(3, c.actors[0]!.id, { hpCurrent: '1' });
    await store.getState().prepareClose();
  });
  it('reads canonical catalog fields and hides tombstones while retaining their physical row', async () => {
    const db = new DatabaseSync(':memory:');
    for (const file of [
      '001_initial',
      '002_pc_initiative',
      '003_enemy_instances',
      '004_combat_log',
      '005_actor_statuses',
      '006_bestiary',
      '007_bestiary_seed',
      '008_enemy_categories',
    ])
      db.exec(
        readFileSync(
          new URL(`../src-tauri/migrations/${file}.sql`, import.meta.url),
          'utf8',
        ),
      );
    db.prepare(
      'INSERT INTO enemy_templates(id,name,category,size,tt,hp_max,statblock_json) VALUES(?,?,?,?,?,?,?)',
    ).run(
      entry.template.id,
      entry.template.name,
      'beast',
      'Średni',
      15,
      88,
      JSON.stringify({
        speeds: entry.template.speeds,
        capabilities: entry.template.capabilities,
      }),
    );
    const repo = createBestiaryRepository({
      selectRows: async (q, v = []) => db.prepare(q).all(...v),
      execute: async (q, v) => ({
        rowsAffected: Number(db.prepare(q).run(...v).changes),
      }),
    });
    expect(await repo.list()).toEqual([entry]);
    db.prepare('UPDATE enemy_templates SET deleted=1 WHERE id=?').run(
      entry.template.id,
    );
    expect(await repo.list()).toEqual([]);
    expect(
      db.prepare('SELECT count(*) as n FROM enemy_templates').get()?.n,
    ).toBe(1);
    db.close();
  });
});

it('searches ability descriptions and preserves linked resource costs through editing', () => {
  const withAbility = structuredClone(entry);
  withAbility.template.capabilities!.abilities.push({
    id: crypto.randomUUID(),
    name: 'Żądło',
    description: 'Zażółć gęślą jaźń.\nJad paraliżuje według decyzji MG.',
    kind: 'action',
    legendaryCost: 1,
    resourceId: withAbility.template.capabilities!.resources[0]!.id,
    resourceCost: 2,
  });
  const parsed = parseEnemyTemplateDraft(
    templateDraft(withAbility.template),
    withAbility.template.id,
  );
  expect(parsed.capabilities).toEqual(withAbility.template.capabilities);
  expect(filterCatalog([withAbility], 'gesla paraliżuje', '', '')).toEqual([
    withAbility,
  ]);
});
