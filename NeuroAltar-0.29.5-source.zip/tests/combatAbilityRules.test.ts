import { expect, it } from 'vitest';
import {
  checkContext,
  combatEffectSchema,
} from '../src/domain/character/participation';
import {
  abilityApplicationSchema,
  hasCombatAbilityPath,
} from '../src/domain/character/combatAbility';
import { createDiceStore } from '../src/stores/diceStore';
import { rollDice } from '../src/domain/dice';
const effect = () =>
  combatEffectSchema.parse({
    id: crypto.randomUUID(),
    label: 'Łaska',
    target: 'attackSave',
    checkDice: '1k4',
    remaining: 1,
    phase: 'start',
    modifier: 2,
    mode: 'normal',
  });
it('combat selector exposes supported mechanics, not narrative or unimplemented rules', () => {
  expect(hasCombatAbilityPath('resource:motivation')).toBe(true);
  expect(hasCombatAbilityPath('profession.star.1')).toBe(true);
  expect(hasCombatAbilityPath('feat.neo')).toBe(true);
  expect(hasCombatAbilityPath('profession.courier.2')).toBe(false);
  expect(hasCombatAbilityPath('profession.mercenary.1')).toBe(false);
  expect(hasCombatAbilityPath('class.brutal.2.0')).toBe(false);
  expect(hasCombatAbilityPath('resource:production')).toBe(false);
  expect(hasCombatAbilityPath('resource:manual-mg')).toBe(false);
});
it('attack/save effects exclude ordinary checks and damage', () => {
  const e = effect();
  expect(checkContext([e], ['attack']).modifier).toBe(2);
  expect(checkContext([e], ['save']).modifier).toBe(2);
  expect(checkContext([e], ['skill']).modifier).toBe(0);
  expect(checkContext([e], ['damage']).modifier).toBe(0);
});
it('INT/tools includes tools using DEX but not unrelated DEX checks', () => {
  const e = { ...effect(), target: 'intTools' as const };
  expect(checkContext([e], ['dex', 'tool']).modifier).toBe(2);
  expect(checkContext([e], ['int', 'skill']).modifier).toBe(2);
  expect(checkContext([e], ['dex', 'skill']).modifier).toBe(0);
});
it('remote NPC effects never change the caster roll', () => {
  const e = { ...effect(), recipientActorId: crypto.randomUUID() };
  expect(checkContext([e], ['attack']).modifier).toBe(0);
});
it('accepts old applications and revisioned multi-target applications', () => {
  const a = {
    ruleId: 'profession.preacher.1',
    label: 'Łaska',
    page: 75,
    cost: 'bonus',
    once: 'none',
    confirmed: true,
    targetId: crypto.randomUUID(),
    targetRevision: 2,
    effect: effect(),
  };
  expect(abilityApplicationSchema.parse(a).additionalTargets).toBeUndefined();
  expect(
    abilityApplicationSchema.parse({
      ...a,
      additionalTargets: [{ id: crypto.randomUUID(), revision: 3 }],
    }).additionalTargets,
  ).toHaveLength(1);
});
it('forced reroll keeps worse result and modifier once, preserves exact write on retry', async () => {
  let fail = true;
  const written: unknown[] = [];
  const store = createDiceStore(
    {
      read: async () => [],
      write: async (r) => {
        written.push(r);
        if (fail) {
          fail = false;
          throw Error('disk');
        }
      },
    },
    (s) => rollDice(s, () => 18),
  );
  expect(
    await store
      .getState()
      .roll('1k20+4', undefined, undefined, { keepWorseThan: 9 }),
  ).toBe(false);
  expect(store.getState().pending?.total).toBe(13);
  expect(await store.getState().retry()).toBe(true);
  expect(written[0]).toEqual(written[1]);
  expect(store.getState().history[0]?.checkDice?.values).toEqual([9, 18]);
});
it('forced reroll retains a new worse result', async () => {
  const store = createDiceStore(
    { read: async () => [], write: async () => {} },
    (s) => rollDice(s, () => 2),
  );
  expect(
    await store
      .getState()
      .roll('1k20-3', undefined, undefined, { keepWorseThan: 16 }),
  ).toBe(true);
  expect(store.getState().history[0]?.total).toBe(-1);
});
