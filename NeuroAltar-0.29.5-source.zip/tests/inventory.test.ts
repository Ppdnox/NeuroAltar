import { inventoryFixture } from './helpers/inventory';
import { describe, it, expect } from 'vitest';
import {
  catalogEntry,
  customItem,
  starterPack,
} from '../src/domain/character/inventoryCatalog';
import {
  emptyInventory,
  newInventoryEntry,
} from '../src/domain/character/inventoryModel';
import {
  applyInventoryAction as apply,
  calculateCarriedWeight,
  calculateEncumbrance,
  validateInventory,
  countRounds,
} from '../src/domain/character/inventory';
import {
  deriveEquipment,
  deriveInventoryWeapon,
} from '../src/domain/character/equipped';
import { itemSchema } from '../src/domain/item';
import catalog from '../src/data/equipment/catalog.v1.json';
import { fixture, complete } from './helpers/character';
const get = (name: string) =>
  catalogEntry(itemSchema.parse(catalog.entries.find((e) => e.name === name)));
describe('BG inventory integrity and mass', () => {
  it('keeps every catalog snapshot independent and accepts all 299 unmodified imports', () => {
    for (const item of catalog.entries) {
      const e = catalogEntry(itemSchema.parse(item));
      expect(
        () => validateInventory({ ...emptyInventory(), entries: [e] }),
        item.name,
      ).not.toThrow();
      if (e.item.weaponProfile) e.item.weaponProfile.attackModifier = 7;
      expect(item).not.toHaveProperty('weaponProfile');
    }
  });
  it('ignores loose and loaded ammunition mass while counting the empty magazine', () => {
    const { i, w, m, a } = inventoryFixture();
    const before = structuredClone(i);
    expect(calculateCarriedWeight(i).kg).toBe(3.2);
    let next = apply(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 30 },
      'none',
    );
    next = apply(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    expect(calculateCarriedWeight(next).kg).toBe(3.2);
    next = apply(
      next,
      { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
      'none',
    );
    expect(calculateCarriedWeight(next).kg).toBe(3.2);
    expect(next.entries[2]!.quantityMilli).toBe(0);
    next = apply(next, { kind: 'unload', magazineId: m.id }, 'none');
    expect(next.entries[2]!.quantityMilli).toBe(29000);
    expect(i).toEqual(before);
  });
  it('ammunition without mass never makes encumbrance incomplete, including loaded rounds', () => {
    const { i, m, a } = inventoryFixture();
    a.location = 'external';
    a.weightMg = null;
    expect(calculateCarriedWeight(i).complete).toBe(true);
    const loaded = apply(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 1 },
      'none',
    );
    expect(calculateCarriedWeight(loaded).unknownIds).toEqual([]);
    expect(calculateEncumbrance(3, false, 10, 20, 9).speed).toBeNull();
  });
  it.each([
    [70, 9, false],
    [70.01, 4.5, true],
    [139.99, 4.5, true],
    [140, 0, true],
  ])('respects exact thresholds %s', (kg, speed, disadvantage) => {
    expect(calculateEncumbrance(kg as number, true, 70, 140, 9)).toMatchObject({
      speed,
      attackDisadvantage: disadvantage,
    });
  });
  it('counts aggregate packs once, blocks cycles and extracting uncertain mass, and grants only one starter', () => {
    const pack = starterPack('brutal'),
      child = newInventoryEntry(customItem('Składnik'));
    child.parentId = pack.id;
    child.weightMg = 5000000;
    child.weightReason = 'Test';
    const i = { ...emptyInventory(), entries: [pack, child] };
    expect(calculateCarriedWeight(i).kg).toBe(22);
    expect(() =>
      apply(
        i,
        {
          kind: 'edit',
          entry: { ...child, parentId: null },
          reason: 'Wyjmuję',
        },
        'none',
      ),
    ).toThrow('Najpierw');
    pack.parentId = child.id;
    child.container = true;
    expect(() => validateInventory(i)).toThrow('cykl');
    const starter = apply(
      emptyInventory(),
      {
        kind: 'starter',
        key: 'initial-equipment',
        entries: [starterPack('brutal')],
      },
      'none',
    );
    expect(() =>
      apply(
        starter,
        {
          kind: 'starter',
          key: 'initial-equipment',
          entries: [starterPack('spec')],
        },
        'none',
      ),
    ).toThrow();
  });
  it('rejects incompatible ammo, overfill, fractional cartridges, shared magazines and occupied hands', () => {
    const { i, w, m, a } = inventoryFixture();
    expect(() =>
      apply(
        i,
        { kind: 'load', magazineId: m.id, ammoId: a.id, count: 31 },
        'none',
      ),
    ).toThrow();
    a.caliber = '9 mm';
    expect(() =>
      apply(
        i,
        { kind: 'load', magazineId: m.id, ammoId: a.id, count: 1 },
        'none',
      ),
    ).toThrow();
    a.quantityMilli = 1500;
    expect(() => validateInventory(i)).toThrow();
    a.quantityMilli = 30000;
    const second = structuredClone(w);
    second.id = crypto.randomUUID();
    i.entries.push(second);
    expect(() => validateInventory(i)).toThrow('zajęte');
    second.slot = 'none';
    w.installedMagazineId = m.id;
    second.installedMagazineId = m.id;
    expect(() => validateInventory(i)).toThrow('innej broni');
  });
  it('fifth ready melee weapon can be put into backpack', () => {
    const entries = Array.from({ length: 5 }, () => {
      const e = get('Maczeta');
      e.location = 'body';
      return e;
    });
    expect(() => validateInventory({ ...emptyInventory(), entries })).toThrow();
    entries[4]!.location = 'backpack';
    expect(() =>
      validateInventory({ ...emptyInventory(), entries }),
    ).not.toThrow();
  });
  it('preserves tracked ammo through Chrom empty/reload and mode changes', () => {
    const { i, w, m, a } = inventoryFixture();
    let next = apply(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 3 },
      'none',
    );
    next = apply(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    const exact = structuredClone(next);
    expect(() =>
      apply(
        next,
        { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
        'chrome',
      ),
    ).toThrow('Pusta');
    next = apply(
      next,
      { kind: 'cinematic', weaponId: w.id, loaded: true },
      'chrome',
    );
    next = apply(
      next,
      { kind: 'shot', weaponId: w.id, mode: 'short', count: 3 },
      'chrome',
    );
    next = apply(
      next,
      { kind: 'cinematic', weaponId: w.id, loaded: false },
      'chrome',
    );
    expect(countRounds(next.entries[1]!)).toBe(3);
    expect(next.entries[2]).toEqual(exact.entries[2]);
    expect(() =>
      apply(
        next,
        { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
        'chrome',
      ),
    ).toThrow();
    next = apply(next, { kind: 'mode', mode: 'tracked' }, 'chrome');
    expect(
      countRounds(
        apply(
          next,
          { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
          'chrome',
        ).entries[1]!,
      ),
    ).toBe(2);
  });
  it('rejects empty shots and non-table series, respects cycle and Szybkie palce', () => {
    const { i, w, m, a } = inventoryFixture();
    let next = apply(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 30 },
      'none',
    );
    next = apply(
      next,
      { kind: 'attach', weaponId: w.id, magazineId: m.id },
      'none',
    );
    expect(() =>
      apply(
        next,
        { kind: 'shot', weaponId: w.id, mode: 'long', count: 12 },
        'none',
      ),
    ).toThrow();
    next.entries[0]!.weapon!.cycle = true;
    next = apply(
      next,
      { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
      'none',
    );
    expect(() =>
      apply(
        next,
        { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
        'none',
      ),
    ).toThrow('mechanizm');
    expect(
      apply(
        next,
        { kind: 'shot', weaponId: w.id, mode: 'single', count: 1 },
        'none',
        true,
      ).entries[0]!.needsCycle,
    ).toBe(false);
  });
  it('prevents deleting referenced ammunition and changing loaded counts through edits', () => {
    const { i, m, a } = inventoryFixture();
    const next = apply(
      i,
      { kind: 'load', magazineId: m.id, ammoId: a.id, count: 2 },
      'none',
    );
    expect(() =>
      apply(next, { kind: 'remove', entryId: a.id, reason: 'Usuwam' }, 'none'),
    ).toThrow();
    const forged = structuredClone(next.entries[1]!);
    forged.magazine!.rounds = [];
    expect(() =>
      apply(next, { kind: 'edit', entry: forged, reason: 'Korekta' }, 'none'),
    ).toThrow('przenoś');
  });
});
describe('equipment calculations', () => {
  it('disables bare chest and bulletproof with a helmet and applies one armor base', () => {
    const sheet = complete(fixture()),
      empty = deriveEquipment(sheet, emptyInventory());
    expect(empty.armor.some((a) => a.label === 'Goła klata')).toBe(true);
    const helmet = get('Hełm');
    helmet.slot = 'helmet';
    helmet.location = 'body';
    const withHelmet = deriveEquipment(sheet, {
      ...emptyInventory(),
      entries: [helmet],
    });
    expect(withHelmet.armor.some((a) => a.label === 'Goła klata')).toBe(false);
    const armor = get('Ciężka zbroja śmieciowa');
    armor.slot = 'armor';
    armor.location = 'body';
    sheet.baseScores.dex = 8;
    expect(
      deriveEquipment(sheet, { ...emptyInventory(), entries: [armor] }).armor,
    ).toEqual([{ label: armor.item.name, value: 16 }]);
  });
  it('does not add ability damage bonuses to any series and retains them once in dublet', () => {
    const sheet = complete(fixture('twardziel')),
      w = get('AR');
    expect(deriveInventoryWeapon(sheet, w, 'short', 3)?.damage).toBe('6k6');
    expect(deriveInventoryWeapon(sheet, w, 'long', 20)?.damage).toBe('8k6');
    expect(deriveInventoryWeapon(sheet, w, 'massive', 50)?.damage).toBe('10k6');
    const shotgun = get('Obrzyn');
    expect(deriveInventoryWeapon(sheet, shotgun, 'double', 2)?.damage).toBe(
      '4k4 + 4',
    );
  });
  it('does not ignore a negative DEX modifier in medium armor', () => {
    const sheet = complete(fixture());
    sheet.baseScores.dex = 8;
    const armor = get('Plate carrier typ III');
    armor.slot = 'armor';
    armor.location = 'body';
    expect(
      deriveEquipment(sheet, { ...emptyInventory(), entries: [armor] })
        .armor[0]!.value,
    ).toBe(13);
  });
});

it('Gambling we krwi belongs to the selected New York ability, not Vegas', () => {
  const sheet = fixture('cwaniak');
  sheet.originId = 'newyork';
  sheet.levels[0]!.choices['origin'] = ['gamble'];
  const ready = complete(sheet);
  expect(deriveEquipment(ready, emptyInventory()).availabilityBonus).toBe(5);
  const vegas = fixture('cwaniak');
  vegas.originId = 'vegas';
  expect(
    deriveEquipment(complete(vegas), emptyInventory()).availabilityBonus,
  ).toBe(0);
});

it('medicine without handbook mass is zero in new and legacy inventory; explicit mass is preserved', () => {
  const medicine = newInventoryEntry(customItem('Aspiryna K'));
  expect(medicine.weightMg).toBe(0);
  const legacy: typeof medicine = {
    ...medicine,
    weightMg: null,
    weightReason: '',
  };
  const inv = { ...emptyInventory(), entries: [legacy] };
  expect(calculateCarriedWeight(inv)).toMatchObject({
    kg: 0,
    complete: true,
    unknownIds: [],
  });
  legacy.weightMg = 250000;
  legacy.weightReason = 'Masa własna MG';
  expect(calculateCarriedWeight(inv).kg).toBe(0.25);
  const other = newInventoryEntry(customItem('Nieznany przedmiot'));
  expect(
    calculateCarriedWeight({ ...emptyInventory(), entries: [other] }).complete,
  ).toBe(false);
  const catalogMedicine = catalog.entries.filter(
    (e) => e.category === 'Prochy i używki / Środki lecznicze',
  );
  expect(catalogMedicine.length).toBeGreaterThan(0);
  for (const item of catalogMedicine)
    if (item.weight === null)
      expect(catalogEntry(itemSchema.parse(item)).weightMg).toBe(0);
});
