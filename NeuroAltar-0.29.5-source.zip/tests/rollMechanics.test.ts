import { expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { newCharacter, type ClassId } from '../src/domain/character/model';
import { complete, fixture } from './helpers/character';
import { conditionView } from '../src/domain/character/condition';
import { emptyDowntime } from '../src/domain/character/downtimeModel';
import { characterRollConditions } from '../src/domain/character/rollConditions';
import { rollBonusOptions } from '../src/services/characterRollBonus';
import { rollDice, diceRollSchema, type DiceRoll } from '../src/domain/dice';
import {
  activeAbilityCommand,
  availableActiveAbilities,
  resolutionSummary,
} from '../src/domain/character/activeAbilities';
import { participationSchema } from '../src/domain/character/participation';
function character(id: ClassId, n: number) {
  const c = newCharacter();
  c.sheet = complete(fixture(id, n));
  c.draft = null;
  c.condition = conditionView(c).state;
  return c;
}
function check(c: ReturnType<typeof character>, targets: string[]): DiceRoll {
  return diceRollSchema.parse({
    ...rollDice('1k20+4', () => 1),
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    context: null,
    characterContext: { characterId: c.id, name: 'Próba', label: 'Test' },
    characterCheck: { characterId: c.id, targets },
  });
}
it('permanent class advantages apply only to the matching checks', () => {
  const brutal = character('brutal', 9),
    scout = character('zwiadowca', 7);
  expect(
    characterRollConditions(brutal, ['dex', 'initiative']).advantage,
  ).toContain('Paranoja Brutala');
  expect(characterRollConditions(brutal, ['dex', 'save']).advantage).toEqual(
    [],
  );
  expect(
    characterRollConditions(scout, ['wis', 'skill:perception']).advantage,
  ).toContain('Wyczulone zmysły');
  expect(characterRollConditions(scout, ['wis', 'save']).advantage).toEqual([]);
});
it('meal and AR23 effects support existing saves, expiration and precise consumption', () => {
  const c = character('brutal', 1),
    meal = crypto.randomUUID();
  c.condition!.downtime = {
    ...emptyDowntime(),
    benefits: [
      {
        id: meal,
        kind: 'mealSave',
        label: 'Posiłek',
        refresh: 'long',
        expiresAt: null,
      },
      {
        id: crypto.randomUUID(),
        kind: 'ar23Social',
        label: 'AR-23',
        refresh: 'manual',
        expiresAt: 60,
      },
    ],
  };
  expect(
    characterRollConditions(c, ['cha', 'skill:persuasion']).disadvantage,
  ).toContain('AR-23');
  expect(characterRollConditions(c, ['con', 'save']).consumedBenefits).toEqual([
    meal,
  ]);
  expect(characterRollConditions(c, ['con']).consumedBenefits).toEqual([]);
  c.condition!.worldMinutes = 60;
  expect(
    characterRollConditions(c, ['cha', 'skill:persuasion']).disadvantage,
  ).toEqual([]);
  c.condition!.downtime!.benefits[0]!.kind = undefined;
  c.condition!.downtime!.benefits[0]!.label =
    'Posiłek: Ułatwienie najbliższego dowolnego RO';
  expect(characterRollConditions(c, ['con', 'save']).consumedBenefits).toEqual([
    meal,
  ]);
});
it('Twardość and Kocie kości respect check type, level and available pool', () => {
  const tough = character('twardziel', 12),
    cat = character('zlodziej', 9);
  expect(rollBonusOptions(tough, check(tough, ['con', 'save']))).toContainEqual(
    { id: 'toughness', label: 'Twardość', sides: 10, requiresFailure: true },
  );
  expect(rollBonusOptions(tough, check(tough, ['str', 'attack']))).toEqual([]);
  expect(rollBonusOptions(cat, check(cat, ['dex', 'save']))[0]?.sides).toBe(8);
  expect(
    rollBonusOptions(
      character('zlodziej', 3),
      check(cat, ['dex', 'initiative']),
    ),
  ).toEqual([]);
  cat.condition!.spent.cat = 100;
  expect(rollBonusOptions(cat, check(cat, ['dex', 'save']))).toEqual([]);
});
it('active ability previews have fixed effects, correct reaction and bounded level', () => {
  const c = character('zlodziej', 9);
  const p = participationSchema.parse({
    id: crypto.randomUUID(),
    characterId: c.id,
    encounterId: 1,
    actorId: crypto.randomUUID(),
    revision: 0,
    state: 'active',
    budget: {
      action: 1,
      bonus: 1,
      reaction: 1,
      interaction: 1,
      attacks: 0,
      use: 0,
    },
    effects: [],
    usedRound: [],
    weapons: {},
    legacy: null,
  });
  const self = { id: p.id, revision: 0 };
  const cat = activeAbilityCommand(c, p, 'catDefense', self, {
    kind: 'catDefense',
    die: 8,
  });
  expect(cat.combatApplication?.cost).toBe('reaction');
  expect(cat.combatApplication?.effect).toMatchObject({
    target: 'tt',
    modifier: 8,
    phase: 'start',
    remaining: 1,
  });
  expect(() =>
    activeAbilityCommand(c, p, 'catDefense', self, {
      kind: 'catDefense',
      die: 9,
    }),
  ).toThrow();
  expect(availableActiveAbilities(character('zlodziej', 2))).toEqual([]);
  expect(
    resolutionSummary({
      kind: 'matrix',
      incomingDamage: 15,
      saveSucceeded: false,
    }),
  ).toContain('15 → 7');
  expect(resolutionSummary({ kind: 'dodge', incomingDamage: 15 })).toContain(
    '15 → 7',
  );
  const target = { id: crypto.randomUUID(), revision: 0 };
  const slow = activeAbilityCommand(c, p, 'sneakSlow', target, {
    kind: 'sneakSlow',
    die: 3,
  });
  expect(slow.combatApplication?.effect).toMatchObject({
    speedReduction: 4.5,
    phase: 'end',
    remaining: 2,
  });
});
it('exports valid cards for atomic native roll tests', () => {
  const tough = character('twardziel', 3),
    meal = character('brutal', 1);
  meal.condition!.downtime = {
    ...emptyDowntime(),
    benefits: [
      {
        id: crypto.randomUUID(),
        kind: 'mealSave',
        label: 'Posiłek',
        refresh: 'long',
        expiresAt: null,
      },
    ],
  };
  if (process.env.GENERATE_ROLL_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-roll-mechanics.json',
      JSON.stringify({ tough, meal }),
    );
});
