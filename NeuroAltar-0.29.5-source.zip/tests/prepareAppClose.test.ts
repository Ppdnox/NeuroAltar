import { useNavigationStore } from '../src/stores/navigationStore';
import { expect, it } from 'vitest';
import { DatabaseSync } from 'node:sqlite';
import { createEncounterStore } from '../src/stores/encounterStore';
import { createCombatStore } from '../src/stores/combatStore';
import { prepareAppClose } from '../src/services/prepareAppClose';
import { SLOT_IDS } from '../src/domain/encounter';
import { migrate, repositoryFor } from './helpers/database';

it('keeps both editors usable and reveals the invalid BG after a failed close', async () => {
  const db = new DatabaseSync(':memory:');
  migrate(db);
  try {
    const repo = repositoryFor(db);
    const encounters = createEncounterStore(repo.listSlots, repo.updateDetails);
    const combat = createCombatStore(
      async () =>
        SLOT_IDS.map((encounterId) => ({
          encounterId,
          revision: 0,
          roundNumber: 1,
          currentTurnActorId: null,
          actors: [],
        })),
      async (snapshot) => snapshot.revision + 1,
    );
    await Promise.all([
      encounters.getState().initialize(),
      combat.getState().initialize(),
    ]);
    encounters.getState().edit(1, { notes: 'Zachowaj przed zamknięciem' });
    combat.getState().addActor(4);
    const actor = combat.getState().drafts[4]!.value.actors[0]!;
    combat.getState().editActor(4, actor.id, { displayName: '' });
    useNavigationStore.getState().navigate('home');
    expect(await prepareAppClose(encounters, combat)).toBe(false);
    expect(useNavigationStore.getState().page).toBe('gm');
    expect(encounters.getState()).toMatchObject({
      closing: false,
      activeId: 4,
    });
    expect(combat.getState().closing).toBe(false);
    expect((await repo.listSlots())[0]!.notes).toBe(
      'Zachowaj przed zamknięciem',
    );
    combat.getState().editActor(4, actor.id, { displayName: 'Poprawione' });
    expect(await prepareAppClose(encounters, combat)).toBe(true);
  } finally {
    db.close();
  }
});

it('reveals the slot containing an unfinished enemy form and allows closing after cancellation', async () => {
  const db = new DatabaseSync(':memory:');
  migrate(db);
  try {
    const repo = repositoryFor(db);
    const encounters = createEncounterStore(repo.listSlots, repo.updateDetails);
    const combat = createCombatStore(
      async () =>
        SLOT_IDS.map((encounterId) => ({
          encounterId,
          revision: 0,
          roundNumber: 1,
          currentTurnActorId: null,
          actors: [],
        })),
      async (c) => c.revision + 1,
    );
    await Promise.all([
      encounters.getState().initialize(),
      combat.getState().initialize(),
    ]);
    combat.getState().openEnemyForm(5);
    combat.getState().editEnemyForm({ name: 'Przeciwnik Ż' });
    expect(await prepareAppClose(encounters, combat)).toBe(false);
    expect(encounters.getState().activeId).toBe(5);
    expect(combat.getState().closing).toBe(false);
    combat.getState().cancelEnemyForm();
    expect(await prepareAppClose(encounters, combat)).toBe(true);
  } finally {
    db.close();
  }
});

it.each(['equipment', 'reference'] as const)(
  'reveals Bestiary while retaining combat drafts, and closes after the catalog form is resolved from %s',
  async (view) => {
    const { createBestiaryStore } = await import('../src/stores/bestiaryStore');
    const db = new DatabaseSync(':memory:');
    migrate(db);
    try {
      const repo = repositoryFor(db);
      const encounters = createEncounterStore(
        repo.listSlots,
        repo.updateDetails,
      );
      const combat = createCombatStore(
        async () =>
          SLOT_IDS.map((encounterId) => ({
            encounterId,
            revision: 0,
            roundNumber: 1,
            currentTurnActorId: null,
            actors: [],
          })),
        async (c) => c.revision + 1,
      );
      const bestiary = createBestiaryStore(
        async () => [],
        async () => 0,
      );
      await Promise.all([
        encounters.getState().initialize(),
        combat.getState().initialize(),
      ]);
      bestiary.getState().open();
      bestiary.getState().edit({ name: 'Niepełny wzorzec' });
      bestiary.getState().setView(view);
      useNavigationStore.getState().navigate('gm');
      expect(await prepareAppClose(encounters, combat, bestiary)).toBe(false);
      expect(bestiary.getState().view).toBe('bestiary');
      expect(useNavigationStore.getState().page).toBe('gm');
      expect(bestiary.getState().form?.fields.name).toBe('Niepełny wzorzec');
      expect(encounters.getState().closeError).toBeNull();
      expect(combat.getState().closing).toBe(false);
      bestiary.getState().edit({ tt: '12', hpMax: '20' });
      await bestiary.getState().submit();
      expect(await prepareAppClose(encounters, combat, bestiary)).toBe(true);
    } finally {
      db.close();
    }
  },
);

it('reveals the slot of a hidden statblock form without losing invalid ability input', async () => {
  const { instantiateEnemy } = await import('../src/domain/combat');
  const actor = instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Strażnik',
      category: 'human',
      size: 'Średni',
      tt: 12,
      hpMax: 20,
      speeds: [],
    },
    0,
  );
  const db = new DatabaseSync(':memory:');
  migrate(db);
  try {
    const repo = repositoryFor(db),
      encounters = createEncounterStore(repo.listSlots, repo.updateDetails);
    const combat = createCombatStore(
      async () =>
        SLOT_IDS.map((encounterId) => ({
          encounterId,
          revision: 0,
          roundNumber: 1,
          currentTurnActorId: null,
          actors: encounterId === 3 ? [actor] : [],
        })),
      async (c) => c.revision + 1,
    );
    await encounters.getState().initialize();
    await combat.getState().initialize();
    combat.getState().openStatblockForm(3, actor.id);
    const fields = structuredClone(combat.getState().statblockForm!.fields);
    fields.abilityScores.str = 'nieznane?';
    combat.getState().editStatblockForm(fields);
    useNavigationStore.getState().navigate('character');
    expect(await prepareAppClose(encounters, combat)).toBe(false);
    expect(useNavigationStore.getState().page).toBe('gm');
    expect(encounters.getState().activeId).toBe(3);
    expect(combat.getState().selected[3]).toBe(actor.id);
    expect(combat.getState().statblockForm!.fields.abilityScores.str).toBe(
      'nieznane?',
    );
    combat.getState().cancelStatblockForm();
    expect(await prepareAppClose(encounters, combat)).toBe(true);
  } finally {
    db.close();
  }
});
