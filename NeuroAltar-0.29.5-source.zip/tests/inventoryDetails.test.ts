import { describe, expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import { itemSchema } from '../src/domain/item';
import {
  catalogEntry,
  customItem,
} from '../src/domain/character/inventoryCatalog';
import { newInventoryEntry } from '../src/domain/character/inventoryModel';
import { inventoryDetails } from '../src/features/character/inventoryDetails';

describe('inventory reference presentation', () => {
  it('separates M14 facts without losing fire modes, features or decimal caliber', () => {
    const entry = catalogEntry(
      itemSchema.parse(catalog.entries.find((i) => i.name === 'M14')),
    );
    const before = structuredClone(entry);
    const result = inventoryDetails(entry);
    expect(result.fields).toEqual([
      { kind: 'magazine', label: 'Pojemność magazynka', value: '20' },
      { kind: 'range', label: 'Zasięg', value: '90/780' },
      { kind: 'weight', label: 'Masa', value: '4 kg' },
      { kind: 'damage', label: 'Obrażenia bazowe', value: '2k8 kłute' },
      { kind: 'ammo', label: 'Nabój', value: '7,62 mm' },
    ]);
    expect(result.properties).toEqual(['P, DS; długa, SM']);
    expect(entry).toEqual(before);
  });

  it('preserves narrative paragraphs, conditional damage and unknown rules', () => {
    const entry = newInventoryEntry(customItem());
    entry.item.description =
      'Działa po aktywacji; zużywa ładunek.\nDrugi akapit, z przecinkiem.';
    entry.item.properties = [
      'Obrażenia: 1k10; oburącz 1k12',
      'Przepalająca: ignoruje TT wynikające z pancerza.',
      'Rzut: 6/18 m',
    ];
    const result = inventoryDetails(entry);
    expect(result.description).toBe(entry.item.description);
    expect(result.fields[0]!.value).toBe('1k10; oburącz 1k12');
    expect(result.properties).toEqual(entry.item.properties.slice(1));
  });

  it('retains extra conditions in a custom mass property of a known weapon', () => {
    const entry = catalogEntry(
      itemSchema.parse(catalog.entries.find((i) => i.name === 'M14')),
    );
    entry.item.properties = ['Waga: 4 kg; z dodatkowym modułem 5 kg'];
    expect(
      inventoryDetails(entry).fields.find((f) => f.kind === 'weight')?.value,
    ).toBe('4 kg; z dodatkowym modułem 5 kg');
  });

  it('does not display an ammunition mass even when old source data contains one', () => {
    const entry = newInventoryEntry(customItem());
    entry.item.type = 'ammunition';
    entry.item.properties = ['Waga: 0,1 kg', 'Nabój: 5,56 mm'];
    entry.weightMg = 100000;
    expect(inventoryDetails(entry).fields).toEqual([
      { kind: 'ammo', label: 'Nabój', value: '5,56 mm' },
    ]);
  });
});
