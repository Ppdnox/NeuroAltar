import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, it } from 'vitest';
import { createCombatRepository } from '../src/db/combatRepository';
import { newStatusDraft, parseStatusDraft } from '../src/domain/status';
const migrations = [
  '001_initial.sql',
  '002_pc_initiative.sql',
  '003_enemy_instances.sql',
  '004_combat_log.sql',
  '005_actor_statuses.sql',
].map((f) =>
  readFileSync(
    new URL(`../src-tauri/migrations/${f}`, import.meta.url),
    'utf8',
  ),
);
const id = '00000000-0000-4000-8000-000000000001';
const read = (db: DatabaseSync) =>
  createCombatRepository({
    selectRows: async (q, v = []) => db.prepare(q).all(...v),
    execute: async (q, v) => ({
      rowsAffected: Number(db.prepare(q).run(...v).changes),
    }),
  }).listSlots();
it('adds empty structured statuses without rewriting legacy runtime, baselines, log or five slots, then survives reopen', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'neuroaltar-stage5-'));
  let db = new DatabaseSync(join(dir, 'test.db'));
  try {
    db.exec('PRAGMA foreign_keys=ON');
    migrations.slice(0, 4).forEach((m) => db.exec(m));
    const actor = {
      id,
      displayName: 'Żaneta',
      hpCurrent: 10,
      hpMaxCurrent: 20,
      ttCurrent: 12,
      initiativeValue: 7,
      initiativeTieOrder: 0,
      statuses: ['Podpalenie', 'Krwawienie — efekt broni'],
    };
    db.prepare(
      "INSERT INTO encounter_actors(id,encounter_id,kind,display_name,hp_current,hp_max_current,tt_current,initiative_value,initiative_tie_order,prepared_snapshot_json,reset_snapshot_json,runtime_overrides_json) VALUES (?,1,'pc',?,10,20,12,7,0,?,?,?)",
    ).run(
      id,
      actor.displayName,
      JSON.stringify(actor),
      JSON.stringify(actor),
      JSON.stringify({ manualStatuses: actor.statuses }),
    );
    db.prepare(
      "UPDATE encounters SET notes='Zażółć\nNotatki',round_number=3,current_turn_actor_id=? WHERE id=1",
    ).run(id);
    db.exec(
      "INSERT INTO combat_log(encounter_id,round_number,event_type,message,payload_json) VALUES(1,3,'prepared','Dawny wpis','{\"before\":null,\"after\":null}')",
    );
    const tables = ['encounters', 'encounter_actors', 'combat_log'];
    const before = tables.map((t) => db.prepare(`SELECT * FROM ${t}`).all());
    db.exec('BEGIN');
    db.exec(migrations[4]!);
    db.exec('COMMIT');
    expect(tables.map((t) => db.prepare(`SELECT * FROM ${t}`).all())).toEqual(
      before,
    );
    const loaded = await read(db);
    expect(loaded[0]!.actors[0]!.statuses).toEqual(actor.statuses);
    expect(loaded[0]!.actors[0]!.effects).toBeUndefined();
    const effect = parseStatusDraft(
      {
        ...newStatusDraft(),
        systemKey: null,
        name: 'Dym',
        description: 'Pierwsza\nDruga',
        durationType: 'rounds',
        rounds: '3',
      },
      false,
    );
    db.prepare(
      'INSERT INTO actor_statuses(id,actor_id,status_json) VALUES(?,?,?)',
    ).run(effect.id, id, JSON.stringify(effect));
    db.close();
    db = new DatabaseSync(join(dir, 'test.db'));
    db.exec('PRAGMA foreign_keys=ON');
    const restarted = await read(db);
    expect(restarted[0]!.actors[0]!.effects).toEqual([effect]);
    expect(restarted[0]!.actors[0]!.prepared).toEqual(actor);
    expect(restarted[1]!.actors).toEqual([]);
    db.prepare(
      'UPDATE encounters SET current_turn_actor_id=NULL WHERE id=1',
    ).run();
    db.prepare('DELETE FROM encounter_actors WHERE id=?').run(id);
    expect(
      db.prepare('SELECT count(*) AS n FROM actor_statuses').get(),
    ).toEqual({ n: 0 });
    expect(db.prepare('SELECT count(*) AS n FROM combat_log').get()).toEqual({
      n: 1,
    });
    expect(db.prepare('PRAGMA integrity_check').get()).toEqual({
      integrity_check: 'ok',
    });
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
