import { expect, it } from 'vitest';
import {
  newStatusDraft,
  parseStatusDraft,
  statusSchema,
  statusListSchema,
  exhaustionEffects,
  systemStatuses,
  tickStatuses,
  type DurationType,
} from '../src/domain/status';
import {
  nextCombatTurn,
  prepareCombat,
  resetEncounter,
  type Combat,
} from '../src/domain/combat';
function effect(type: DurationType, active = false) {
  return parseStatusDraft(
    {
      ...newStatusDraft(),
      systemKey: null,
      name: 'Żółta mgła',
      description: 'Pierwsza\nDruga',
      sourceText: 'Rura',
      durationType: type,
      rounds: '2',
    },
    active,
  );
}
function combat(): Combat {
  return {
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [0, 1].map((i) => ({
      id: `00000000-0000-4000-8000-00000000000${i + 1}`,
      displayName: `BG${i}`,
      hpCurrent: 10,
      hpMaxCurrent: 10,
      ttCurrent: 12,
      initiativeValue: 10 - i,
      initiativeTieOrder: i,
      statuses: ['Krwawienie — opis broni'],
      effects: [],
    })),
  };
}
it('validates all system keys, Polish custom text and rejects malformed durations and exhaustion levels', () => {
  expect(Object.keys(systemStatuses)).toHaveLength(15);
  for (const systemKey of Object.keys(systemStatuses) as Array<
    keyof typeof systemStatuses
  >) {
    const s = parseStatusDraft({ ...newStatusDraft(), systemKey }, false);
    expect(s.name).toBe(systemStatuses[systemKey][0]);
  }
  const s = effect('rounds');
  expect(s.description).toBe('Pierwsza\nDruga');
  for (const patch of [
    { remaining: 0 },
    { remaining: 3 },
    { durationValue: 0 },
    { durationType: 'manual' },
    { level: 1 },
    { name: ' ' },
  ])
    expect(() => statusSchema.parse({ ...s, ...patch })).toThrow();
  for (const rounds of ['', '0', '1.5', '1000', '-2', 'Infinity'])
    expect(() =>
      parseStatusDraft(
        { ...newStatusDraft(), durationType: 'rounds', rounds },
        false,
      ),
    ).toThrow();
  const exhaustion = parseStatusDraft(
    { ...newStatusDraft(), systemKey: 'exhaustion', level: '6' },
    false,
  );
  expect(exhaustionEffects([exhaustion])).toEqual({
    level: 6,
    testPenalty: 12,
    speedPenalty: 9,
    deathWarning: true,
  });
  expect(exhaustionEffects([])).toEqual({
    level: 0,
    testPenalty: 0,
    speedPenalty: 0,
    deathWarning: false,
  });
  expect(() => statusSchema.parse({ ...exhaustion, level: 7 })).toThrow();
  expect(() =>
    statusListSchema.parse([
      exhaustion,
      { ...exhaustion, id: crypto.randomUUID() },
    ]),
  ).toThrow();
  const burning = parseStatusDraft(newStatusDraft(), false);
  expect(
    statusListSchema.parse([burning, { ...burning, id: crypto.randomUUID() }]),
  ).toHaveLength(2);
});
it('ticks exact start and end boundaries independently per owner, without modifying HP or legacy text', () => {
  let c = combat();
  const original = structuredClone(c);
  c.actors[0]!.effects = [
    effect('manual'),
    effect('until_start_of_turn'),
    effect('until_end_of_turn'),
  ];
  c.actors[1]!.effects = [effect('until_start_of_turn')];
  c = nextCombatTurn(c); // initial start A
  expect(c.roundNumber).toBe(1);
  expect(c.actors[0]!.effects!.map((s) => s.durationType)).toEqual([
    'manual',
    'until_end_of_turn',
  ]);
  expect(c.actors[1]!.effects).toHaveLength(1);
  c = nextCombatTurn(c); // end A, start B
  expect(c.actors[0]!.effects!.map((s) => s.durationType)).toEqual(['manual']);
  expect(c.actors[1]!.effects).toEqual([]);
  expect(c.actors[0]!.hpCurrent).toBe(original.actors[0]!.hpCurrent);
  expect(c.actors[0]!.statuses).toEqual(original.actors[0]!.statuses);
});
it('next end skips the current owner turn, but lasts one full upcoming turn when applied off-turn', () => {
  const current = effect('until_end_of_next_turn', true);
  const next = tickStatuses([current], true, false, false);
  expect(next[0]!.remaining).toBe(1);
  expect(tickStatuses(next, false, true, true)).toEqual(next);
  expect(tickStatuses(next, true, false, false)).toEqual([]);
  expect(current.remaining).toBe(2);
  expect(
    tickStatuses([effect('until_end_of_next_turn', false)], true, false, false),
  ).toEqual([]);
});
it('counts rounds at global wrap, including owners without initiative; start does not consume a round', () => {
  let c = combat();
  c.actors[1]!.initiativeValue = null;
  c.actors[1]!.effects = [effect('rounds')];
  c = nextCombatTurn(c);
  expect(c.actors[1]!.effects![0]!.remaining).toBe(2);
  c = nextCombatTurn(c);
  expect(c.roundNumber).toBe(2);
  expect(c.actors[1]!.effects![0]!.remaining).toBe(1);
  c = nextCombatTurn(c);
  expect(c.actors[1]!.effects).toEqual([]);
  c.actors[0]!.initiativeValue = null;
  c.currentTurnActorId = null;
  c.actors[1]!.effects = [effect('rounds')];
  expect(nextCombatTurn(c).actors).toEqual(c.actors);
});
it('single actor completes end, wrap and start exactly once; coincident expiry precedes reminders', () => {
  let c = combat();
  c.actors = c.actors.slice(0, 1);
  c.currentTurnActorId = c.actors[0]!.id;
  c.actors[0]!.effects = [
    effect('until_end_of_turn'),
    effect('until_start_of_turn'),
    effect('until_end_of_next_turn', true),
  ];
  c = nextCombatTurn(c);
  expect(c.roundNumber).toBe(2);
  expect(c.actors[0]!.effects).toHaveLength(1);
  expect(c.actors[0]!.effects![0]!.remaining).toBe(1);
  c = nextCombatTurn(c);
  expect(c.actors[0]!.effects).toEqual([]);
});
it('prepare and reset restore independent status data and counters while preserving legacy snapshots', () => {
  let c = combat();
  c.actors[0]!.effects = [
    effect('rounds'),
    parseStatusDraft(
      { ...newStatusDraft(), systemKey: 'exhaustion', level: '3' },
      false,
    ),
  ];
  c = prepareCombat(c);
  const before = structuredClone(c);
  c = nextCombatTurn(nextCombatTurn(nextCombatTurn(c)));
  expect(c.actors[0]!.effects![0]!.remaining).toBe(1);
  const reset = resetEncounter(c);
  expect(reset.actors[0]!.effects).toEqual(before.actors[0]!.effects);
  reset.actors[0]!.effects![0]!.description = 'changed';
  expect(reset.actors[0]!.prepared!.effects).toEqual(before.actors[0]!.effects);
  expect(before.actors[1]!.effects).toEqual([]);
});
