import type { SaveReason } from '../src/domain/combatLog';
import { beforeEach, afterEach, expect, it, vi } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import type { Combat } from '../src/domain/combat';
import { useParticipationStore } from '../src/stores/participationStore';
import { PARTICIPATION_RESET_REJECTION } from '../src/services/combat';

beforeEach(() => {
  vi.useFakeTimers();
  useParticipationStore.setState({ entries: [] });
});
afterEach(() => {
  useParticipationStore.setState({ entries: [] });
  vi.useRealTimers();
});
export function combatFixture() {
  let slots: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [],
  }));
  const load = vi.fn(async () => structuredClone(slots));
  const save = vi.fn<(combat: Combat, reason?: SaveReason) => Promise<number>>(
    async (combat) => {
      if (slots[combat.encounterId - 1]!.revision !== combat.revision)
        throw new Error('Version conflict');
      slots = slots.map((s) =>
        s.encounterId === combat.encounterId
          ? structuredClone({ ...combat, revision: combat.revision + 1 })
          : s,
      );
      return combat.revision + 1;
    },
  );
  return { load, save, store: createCombatStore(load, save) };
}
it('autosaves BG, statuses, independent initiative and turn across all five slots', async () => {
  const { store, load, save } = combatFixture();
  await store.getState().initialize();
  for (const id of SLOT_IDS) {
    store.getState().addActor(id);
    const pc = store.getState().drafts[id]!.value.actors[0]!;
    store.getState().editActor(id, pc.id, {
      displayName: `Żaneta ${id}`,
      hpCurrent: '12',
      hpMaxCurrent: '20',
      initiativeValue: String(10 + id),
      statusesText: 'Przerażenie\nZatrucie',
    });
    await store.getState().flush(id);
    store.getState().nextTurn(id);
    await store.getState().flush(id);
  }
  const restarted = createCombatStore(load, save);
  await restarted.getState().initialize();
  for (const slot of restarted.getState().slots) {
    expect(slot.actors[0]).toMatchObject({
      displayName: `Żaneta ${slot.encounterId}`,
      hpCurrent: 12,
      statuses: ['Przerażenie', 'Zatrucie'],
    });
    expect(slot.currentTurnActorId).toBe(slot.actors[0]!.id);
  }
  expect(
    new Set(
      restarted.getState().slots.flatMap((s) => s.actors.map((a) => a.id)),
    ).size,
  ).toBe(5);
});
it('coalesces input, retains invalid numeric drafts, blocks exit and retries corrected values', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(3);
  await store.getState().flush(3);
  save.mockClear();
  const id = store.getState().drafts[3]!.value.actors[0]!.id;
  store.getState().editActor(3, id, { ttCurrent: '1' });
  store.getState().editActor(3, id, { ttCurrent: '' });
  await vi.advanceTimersByTimeAsync(500);
  expect(save).not.toHaveBeenCalled();
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().closing).toBe(false);
  expect(store.getState().drafts[3]!.value.actors[0]!.ttCurrent).toBe('');
  store.getState().editActor(3, id, { ttCurrent: '17' });
  expect(await store.getState().prepareClose()).toBe(true);
  expect(store.getState().slots[2]!.actors[0]!.ttCurrent).toBe(17);
});
it('does not lose newer edits during a pending save or advance before closing has saved them', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  await store.getState().flush(1);
  const id = store.getState().drafts[1]!.value.actors[0]!.id;
  const original = save.getMockImplementation()!;
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  save.mockImplementationOnce(async (snapshot) => {
    await gate;
    return original(snapshot);
  });
  store.getState().editActor(1, id, { displayName: 'Stare' });
  const first = store.getState().flush(1);
  await Promise.resolve();
  store
    .getState()
    .editActor(1, id, { displayName: 'Najnowsze', initiativeValue: '18' });
  const done = vi.fn();
  const close = store.getState().prepareClose().then(done);
  await Promise.resolve();
  expect(done).not.toHaveBeenCalled();
  store
    .getState()
    .editActor(1, id, { displayName: 'Zablokowane przy zamykaniu' });
  release();
  await first;
  await close;
  expect(done).toHaveBeenCalledWith(true);
  expect(store.getState().slots[0]!.actors[0]!.displayName).toBe('Najnowsze');
});
it('preserves draft and stays open on an IPC string error, then retries', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  await store.getState().flush(1);
  const id = store.getState().drafts[1]!.value.actors[0]!.id;
  save.mockRejectedValueOnce('Dysk pełny');
  store.getState().editActor(1, id, { displayName: 'Nie zgub' });
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().drafts[1]).toMatchObject({
    status: 'error',
    error: 'Dysk pełny',
  });
  expect(await store.getState().flush(1)).toBe(true);
  expect(store.getState().slots[0]!.actors[0]!.displayName).toBe('Nie zgub');
});
it('clamps HP, preserves active identity after manual ties and clears a removed active actor', async () => {
  const { store } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  store.getState().addActor(1);
  const [a, b] = store.getState().drafts[1]!.value.actors;
  for (const pc of [a!, b!])
    store.getState().editActor(1, pc.id, {
      initiativeValue: '12',
      hpMaxCurrent: '20',
      hpCurrent: '10',
    });
  store.getState().adjustHp(1, a!.id, -100);
  expect(store.getState().drafts[1]!.value.actors[0]!.hpCurrent).toBe('0');
  store.getState().adjustHp(1, a!.id, 100);
  expect(store.getState().drafts[1]!.value.actors[0]!.hpCurrent).toBe('20');
  store.getState().setCurrent(1, a!.id);
  store.getState().moveTie(1, b!.id, -1);
  expect(store.getState().drafts[1]!.value.currentTurnActorId).toBe(a!.id);
  store.getState().removeActor(1, a!.id);
  await store.getState().flush(1);
  expect(store.getState().slots[0]!.currentTurnActorId).toBeNull();
  expect(store.getState().slots[0]!.actors).toHaveLength(1);
});
it('clearing active initiative releases the current turn without changing the round', async () => {
  const { store } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(2);
  const id = store.getState().drafts[2]!.value.actors[0]!.id;
  store.getState().editActor(2, id, { initiativeValue: '-1' });
  store.getState().nextTurn(2);
  store.getState().editActor(2, id, { initiativeValue: '' });
  await store.getState().flush(2);
  expect(store.getState().slots[1]).toMatchObject({
    currentTurnActorId: null,
    roundNumber: 1,
  });
});
it('rejects incomplete initial slot data and permits a retry', async () => {
  const { store, load } = combatFixture();
  load.mockResolvedValueOnce([]);
  await store.getState().initialize();
  expect(store.getState().status).toBe('error');
  await store.getState().initialize();
  expect(store.getState().status).toBe('ready');
});

const enemyTemplate = {
  id: '00000000-0000-4000-8000-000000000099',
  name: 'Maszyna Żuk',
  category: 'machine' as const,
  size: 'Średni',
  tt: 16,
  hpMax: 30,
  speeds: [{ mode: 'Chód', meters: 9 }],
};
it('persists mixed actors, explicit preparation and reset through retries and a restarted store', async () => {
  const { store, load, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  store.getState().addEnemy(1, enemyTemplate);
  store.getState().addEnemy(2, enemyTemplate);
  const enemy = store.getState().drafts[1]!.value.actors[1]!;
  store.getState().editActor(1, enemy.id, {
    hpCurrent: '24',
    speedsText: 'Chód: 4,5',
    initiativeValue: '10',
  });
  store.getState().prepareEncounter(1);
  await store.getState().flush(1);
  await store.getState().flush(2);
  const other = structuredClone(store.getState().slots[1]);
  store.getState().adjustHp(1, enemy.id, -10);
  store.getState().editActor(1, enemy.id, { speedsText: 'Chód: 0' });
  store.getState().nextTurn(1);
  await store.getState().flush(1);
  const restarted = createCombatStore(load, save);
  await restarted.getState().initialize();
  expect(restarted.getState().slots[0]!.actors[1]!.hpCurrent).toBe(14);
  save.mockRejectedValueOnce('Dysk pełny');
  restarted.getState().resetEncounter(1);
  expect(await restarted.getState().flush(1)).toBe(false);
  expect(restarted.getState().drafts[1]!.value.actors[1]!.hpCurrent).toBe('24');
  const uncertainReset = structuredClone(save.mock.calls.at(-1));
  expect(uncertainReset?.[1]).toBe('reset');
  expect(await restarted.getState().flush(1)).toBe(true);
  expect(save.mock.calls.at(-1)).toEqual(uncertainReset);
  expect(restarted.getState().slots[0]).toMatchObject({
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [
      {},
      {
        hpCurrent: 24,
        initiativeValue: 10,
        enemy: { speeds: [{ mode: 'Chód', meters: 4.5 }] },
      },
    ],
  });
  expect(restarted.getState().slots[1]).toEqual(other);
});
it('keeps incomplete enemy movement and a new template form available across close attempts', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().openEnemyForm(4);
  store.getState().editEnemyForm({
    name: 'Łowca',
    tt: '14',
    hpMax: '',
    speedsText: 'Chód: 4,5',
  });
  store.getState().submitEnemyForm();
  expect(store.getState().enemyForm?.error).toBeTruthy();
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().enemyForm!.fields.name).toBe('Łowca');
  expect(save).not.toHaveBeenCalled();
  store.getState().editEnemyForm({ hpMax: '20' });
  store.getState().submitEnemyForm();
  expect(store.getState().enemyForm).toBeNull();
  await store.getState().flush(4);
  const actor = store.getState().drafts[4]!.value.actors[0]!;
  store.getState().editActor(4, actor.id, { speedsText: 'Chód:' });
  expect(await store.getState().prepareClose()).toBe(false);
  store.getState().editActor(4, actor.id, { speedsText: 'Chód: 3' });
  expect(await store.getState().prepareClose()).toBe(true);
});

it('preserves every rapid HP and turn action instead of coalescing a return to the initial value', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  const id = store.getState().drafts[1]!.value.actors[0]!.id;
  store.getState().editActor(1, id, {
    hpCurrent: '20',
    hpMaxCurrent: '20',
    initiativeValue: '10',
  });
  await store.getState().flush(1);
  save.mockClear();
  store.getState().adjustHp(1, id, -10);
  store.getState().adjustHp(1, id, 10);
  store.getState().nextTurn(1);
  store.getState().nextTurn(1);
  await store.getState().flush(1);
  expect(
    save.mock.calls.map(([s]) => [
      s.actors[0]!.hpCurrent,
      s.roundNumber,
      s.currentTurnActorId,
    ]),
  ).toEqual([
    [10, 1, null],
    [20, 1, null],
    [20, 1, id],
    [20, 2, id],
  ]);
});
it('retains ordered action snapshots through a write failure before queued clear and resumes without duplicates', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(1);
  const id = store.getState().drafts[1]!.value.actors[0]!.id;
  store.getState().editActor(1, id, { hpCurrent: '20', hpMaxCurrent: '20' });
  await store.getState().flush(1);
  save.mockClear();
  save.mockRejectedValueOnce('Dysk pełny');
  store.getState().adjustHp(1, id, -5);
  store.getState().adjustHp(1, id, -5);
  store.getState().clearLog(1);
  expect(await store.getState().flush(1)).toBe(false);
  expect(store.getState().drafts[1]!.value.actors[0]!.hpCurrent).toBe('10');
  expect(await store.getState().flush(1)).toBe(true);
  expect(save.mock.calls.map(([s]) => s.actors[0]!.hpCurrent)).toEqual([
    15, 15, 10, 10,
  ]);
  expect(save.mock.calls.at(-1)?.[1]).toBe('clear_log');
});

it('refuses a known active participation reset before changing the draft or save queue', async () => {
  const { store, save } = combatFixture();
  await store.getState().initialize();
  store.getState().addActor(4);
  await store.getState().flush(4);
  const actorId = store.getState().drafts[4]!.value.actors[0]!.id;
  store.getState().editActor(4, actorId, { displayName: 'Niezapisana nazwa' });
  const before = structuredClone(store.getState().drafts[4]!.value);
  useParticipationStore.setState({
    entries: [
      {
        id: crypto.randomUUID(),
        characterId: crypto.randomUUID(),
        actorId,
        encounterId: 4,
        revision: 0,
        state: 'active',
        budget: {
          action: 1,
          bonus: 1,
          reaction: 1,
          interaction: 1,
          attacks: 0,
          use: 0,
        },
        effects: [],
        usedRound: [],
        weapons: {},
        legacy: {},
      },
    ],
  });
  save.mockClear();
  store.getState().resetEncounter(4);
  expect(store.getState().drafts[4]!.value).toEqual(before);
  expect(store.getState().drafts[4]!.error).toBe(PARTICIPATION_RESET_REJECTION);
  expect(await store.getState().flush(4)).toBe(true);
  expect(save.mock.calls.map(([, reason]) => reason)).toEqual(['edit']);
  expect(store.getState().slots[3]!.actors[0]!.displayName).toBe(
    'Niezapisana nazwa',
  );
});

async function resetRecoveryFixture() {
  const fixture = combatFixture();
  const { store } = fixture;
  await store.getState().initialize();
  store.getState().addActor(1);
  const actorId = store.getState().drafts[1]!.value.actors[0]!.id;
  store.getState().editActor(1, actorId, {
    hpMaxCurrent: '20',
    hpCurrent: '20',
    ttCurrent: '14',
    initiativeValue: '8',
    statusesText: 'Stan przygotowany',
  });
  store.getState().prepareEncounter(1);
  await store.getState().flush(1);
  store.getState().editActor(1, actorId, {
    hpCurrent: '5',
    ttCurrent: '12',
    initiativeValue: '16',
    statusesText: 'Stan podczas walki',
  });
  store.getState().nextTurn(1);
  store.getState().nextTurn(1);
  await store.getState().flush(1);
  fixture.save.mockClear();
  return { ...fixture, actorId };
}

it('drops only a definitively rejected reset and restores HP, statuses, initiative and turn', async () => {
  const { store, save } = await resetRecoveryFixture();
  const before = structuredClone(store.getState().slots[0]);
  save.mockRejectedValueOnce(PARTICIPATION_RESET_REJECTION);
  store.getState().resetEncounter(1);
  expect(await store.getState().flush(1)).toBe(false);
  expect(store.getState().drafts[1]!.value).toMatchObject({
    roundNumber: 2,
    currentTurnActorId: before!.currentTurnActorId,
    actors: [
      {
        hpCurrent: '5',
        ttCurrent: '12',
        initiativeValue: '16',
        statusesText: 'Stan podczas walki',
      },
    ],
  });
  expect(await store.getState().flush(1)).toBe(true);
  expect(store.getState().slots[0]).toEqual(before);
  expect(save).toHaveBeenCalledTimes(1);
});

it('preserves later edits and queued actions without leaking a rejected reset into autosave', async () => {
  const { store, save, actorId } = await resetRecoveryFixture();
  let reject!: (reason: unknown) => void;
  save.mockImplementationOnce(
    () =>
      new Promise((_resolve, rejectSave) => {
        reject = rejectSave;
      }),
  );
  store.getState().resetEncounter(1);
  const pending = store.getState().flush(1);
  await Promise.resolve();
  store.getState().editActor(1, actorId, {
    displayName: 'Późniejsza nazwa',
    ttCurrent: '17',
  });
  store.getState().setCurrent(1, actorId);
  store.getState().editActor(1, actorId, { initiativeValue: '19' });
  reject(new Error(PARTICIPATION_RESET_REJECTION));
  expect(await pending).toBe(false);
  expect(await store.getState().flush(1)).toBe(true);
  expect(store.getState().slots[0]).toMatchObject({
    roundNumber: 2,
    currentTurnActorId: actorId,
    actors: [
      {
        displayName: 'Późniejsza nazwa',
        hpCurrent: 5,
        ttCurrent: 17,
        initiativeValue: 19,
        statuses: ['Stan podczas walki'],
      },
    ],
  });
  expect(
    save.mock.calls.filter(([, reason]) => reason === 'reset'),
  ).toHaveLength(1);
  expect(
    save.mock.calls
      .slice(1)
      .every(
        ([value]) =>
          value.actors[0]!.hpCurrent === 5 &&
          value.actors[0]!.statuses[0] === 'Stan podczas walki' &&
          value.roundNumber === 2,
      ),
  ).toBe(true);
});

it('keeps incomplete input typed after a rejected reset instead of replacing or saving it', async () => {
  const { store, save, actorId } = await resetRecoveryFixture();
  let reject!: (reason: unknown) => void;
  save.mockImplementationOnce(
    () =>
      new Promise((_resolve, rejectSave) => {
        reject = rejectSave;
      }),
  );
  store.getState().resetEncounter(1);
  const pending = store.getState().flush(1);
  await Promise.resolve();
  store.getState().editActor(1, actorId, { hpCurrent: '' });
  reject(PARTICIPATION_RESET_REJECTION);
  expect(await pending).toBe(false);
  expect(await store.getState().flush(1)).toBe(false);
  expect(store.getState().drafts[1]!.value.actors[0]).toMatchObject({
    hpCurrent: '',
    initiativeValue: '16',
  });
  store.getState().editActor(1, actorId, { hpCurrent: '7' });
  expect(await store.getState().flush(1)).toBe(true);
  expect(store.getState().slots[0]!.actors[0]!.hpCurrent).toBe(7);
  expect(
    save.mock.calls.filter(([, reason]) => reason === 'reset'),
  ).toHaveLength(1);
});
