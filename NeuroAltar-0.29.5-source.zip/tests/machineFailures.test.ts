import { describe, expect, it } from 'vitest';
import {
  instantiateEnemy,
  prepareCombat,
  resetEncounter,
  nextCombatTurn,
  actorSchema,
  type Actor,
  type Combat,
} from '../src/domain/combat';
import {
  applyMachineFailure,
  repairMachineFailure,
  effectiveMachineTT,
  failureModifiers,
  failureAttackWarning,
} from '../src/domain/machineFailures';
import {
  newFailureDraft,
  parseFailureThreshold,
  machineFailuresSchema,
} from '../src/domain/machineFailureSchema';
import { injuryConsequences } from '../src/domain/injury';
import {
  actionRestriction,
  consumeCapability,
} from '../src/domain/capabilities';
import { newWeaponDraft, parseLoadoutDraft } from '../src/domain/itemDraft';
import { calculateWeaponAttackProfile } from '../src/domain/item';
function machine() {
  const w = newWeaponDraft();
  w.name = 'Działo Żółw';
  w.profile!.damageModes[0]!.dice = '2k8 + 3';
  w.profile!.damageModes[0]!.damageType = 'kłute';
  return instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Żółw',
      category: 'machine',
      size: 'Duży',
      tt: 16,
      hpMax: 88,
      speeds: [
        { mode: 'Chód', meters: 9 },
        { mode: 'Lot', meters: 4.5 },
      ],
      failureThreshold: 20,
      loadout: parseLoadoutDraft({
        pb: '4',
        strModifier: '2',
        dexModifier: '5',
        items: [w],
      }),
    },
    0,
  );
}
const apply = (a: Actor, n: number, active = false) =>
  applyMachineFailure(
    a,
    {
      ...newFailureDraft(),
      result: String(n),
      weaponId: a.enemy!.loadout!.items[0]!.item.id,
      blockedAction: 'bonus',
      note: 'Zażółć\nNaprawa MG',
    },
    active,
  );
const combat = (a: Actor): Combat => ({
  encounterId: 1,
  revision: 0,
  roundNumber: 1,
  currentTurnActorId: a.id,
  actors: [{ ...a, initiativeValue: 10 }],
});
describe('machine failures', () => {
  it.each(Array.from({ length: 20 }, (_, i) => i + 1))(
    'applies result %i only to the actor and preserves a validated prepared/template copy',
    (n) => {
      const a = machine(),
        before = structuredClone(a);
      const b = apply(a, n);
      expect(actorSchema.safeParse(b).success).toBe(true);
      expect(a).toEqual(before);
      expect(b.enemy!.template).toEqual(before.enemy!.template);
      expect(b.prepared).toEqual(before.prepared);
      expect(b.enemy!.machineFailures![0]!.result).toBe(n);
      expect(b.hpCurrent).toBe(n === 6 ? 38 : n === 20 ? 0 : 88);
    },
  );
  it('accepts absent/zero thresholds and rejects malformed numbers and out-of-range results', () => {
    expect(parseFailureThreshold('')).toBeNull();
    expect(parseFailureThreshold('0')).toBe(0);
    for (const bad of ['-1', '1.5', 'abc', '9007199254740992'])
      expect(() => parseFailureThreshold(bad)).toThrow();
    for (const bad of ['', '0', '21', '1.5'])
      expect(() =>
        applyMachineFailure(
          machine(),
          { ...newFailureDraft(), result: bad },
          false,
        ),
      ).toThrow();
    expect(() =>
      applyMachineFailure(
        machine(),
        { ...newFailureDraft(), result: '1' },
        false,
      ),
    ).toThrow();
    expect(() =>
      applyMachineFailure(
        machine(),
        { ...newFailureDraft(), result: '4' },
        false,
      ),
    ).toThrow();
    const fs = apply(machine(), 13).enemy!.machineFailures!;
    expect(() => machineFailuresSchema.parse([...fs, ...fs])).toThrow();
  });
  it('requires a machine and does not treat typed damage as another HP subtraction', () => {
    const a = machine();
    a.enemy!.template.category = 'human';
    expect(() => apply(a, 6)).toThrow();
    const b = applyMachineFailure(
      machine(),
      { ...newFailureDraft(), result: '6', damage: '50' },
      false,
    );
    expect(b.hpCurrent).toBe(38);
  });
  it('13 lowers effective TT; 2 halves every speed; repair restores modifiers without mutating base fields', () => {
    const a = machine();
    let b = apply(apply(a, 13), 2);
    expect(effectiveMachineTT(b)).toBe(14);
    expect(b.ttCurrent).toBe(16);
    expect(injuryConsequences(b).speeds.map((s) => s.meters)).toEqual([
      4.5, 2.25,
    ]);
    expect(b.enemy!.speeds).toEqual(a.enemy!.speeds);
    b = repairMachineFailure(b, b.enemy!.machineFailures![1]!.id);
    expect(injuryConsequences(b).speeds).toEqual(a.enemy!.speeds);
    expect(effectiveMachineTT(b)).toBe(14);
    b = repairMachineFailure(b, b.enemy!.machineFailures![0]!.id);
    expect(effectiveMachineTT(b)).toBe(16);
  });
  it('applies cumulative attack penalties in domain calculations and restores only the repaired fault', () => {
    let a = apply(apply(machine(), 3), 14);
    const l = a.enemy!.loadout!;
    expect(
      calculateWeaponAttackProfile(l.items[0]!, l, a.enemy!.machineFailures)
        .attack,
    ).toBe(3);
    a = repairMachineFailure(a, a.enemy!.machineFailures![0]!.id);
    expect(
      calculateWeaponAttackProfile(l.items[0]!, l, a.enemy!.machineFailures)
        .attack,
    ).toBe(5);
    expect(l.items[0]!.item.weaponProfile!.attackModifier).toBe(0);
  });
  it('weapon destruction targets the chosen Item ID; other/new weapons remain available', () => {
    const a = apply(machine(), 1),
      fs = a.enemy!.machineFailures!,
      id = a.enemy!.loadout!.items[0]!.item.id;
    expect(failureAttackWarning(fs, id, 'ranged')).toContain('zniszczona');
    expect(failureAttackWarning(fs, crypto.randomUUID(), 'ranged')).toBeNull();
    expect(a.enemy!.loadout!.items).toHaveLength(1);
  });
  it('action blocks integrate with the existing explicit GM exception without spending extra resources', () => {
    const a = apply(machine(), 4);
    expect(actionRestriction(a, 'bonus')).toContain('Awaria');
    expect(actionRestriction(a, 'reaction')).toBeNull();
    expect(() => consumeCapability(a, 'bonus')).toThrow();
    expect(
      consumeCapability(a, 'bonus', true).enemy!.capabilities!.budget.bonus,
    ).toBe(0);
    expect(actionRestriction(apply(machine(), 9), 'reaction')).toContain(
      'Awaria',
    );
    const ten = apply(machine(), 10);
    expect(actionRestriction(ten, 'action')).toContain('Awaria');
    expect(actionRestriction(ten, 'bonus')).toContain('Awaria');
    expect(actionRestriction(ten, 'reaction')).toBeNull();
  });
  it.each([5, 10, 12])(
    'result %i expires at next own turn end, skips current end and survives neutral prepare/reset',
    (n) => {
      const initial = combat(apply(machine(), n, true));
      const first = nextCombatTurn(initial);
      expect(first.actors[0]!.enemy!.machineFailures![0]!.remainingEnds).toBe(
        1,
      );
      if (n !== 10) expect(first.actors[0]!.effects![0]!.remaining).toBe(1);
      const second = nextCombatTurn(first);
      expect(second.actors[0]!.enemy!.machineFailures).toEqual([]);
      if (n !== 10) expect(second.actors[0]!.effects).toEqual([]);
      const prepared = prepareCombat(first);
      expect(
        resetEncounter(prepared).actors[0]!.enemy!.machineFailures![0]!
          .remainingEnds,
      ).toBe(1);
      const inactive = nextCombatTurn(combat(apply(machine(), n, false)));
      expect(inactive.actors[0]!.enemy!.machineFailures).toEqual([]);
    },
  );
  it('6 and 20 clamp HP, repair does not heal; destructive warnings never remove or skip the actor', () => {
    let a = apply(apply(machine(), 6), 6);
    expect(a.hpCurrent).toBe(0);
    a = repairMachineFailure(a, a.enemy!.machineFailures![0]!.id);
    expect(a.hpCurrent).toBe(0);
    const destroyed = apply(machine(), 20);
    expect(failureModifiers(destroyed.enemy!.machineFailures).off).toBe(true);
    expect(nextCombatTurn(combat(destroyed)).actors).toHaveLength(1);
    expect(actionRestriction(destroyed, 'action')).toContain('wyłączona');
    expect(resetEncounter(combat(destroyed)).actors[0]!.hpCurrent).toBe(88);
  });
  it('15–18 remain reminders with explicit melee restrictions and no forced target/HP changes', () => {
    const a = apply(apply(apply(apply(machine(), 15), 16), 17), 18);
    const m = failureModifiers(a.enemy!.machineFailures);
    expect(m.halfMelee).toBe(true);
    expect(m.noMelee).toBe(true);
    expect(a.hpCurrent).toBe(88);
    expect(
      failureAttackWarning(a.enemy!.machineFailures!, 'any', 'melee'),
    ).toContain('wręcz');
  });
  it('repair removes only its own status; independent burning remains and prepared reset is exact', () => {
    let a = apply(apply(machine(), 11), 11);
    expect(a.effects).toHaveLength(2);
    a = repairMachineFailure(a, a.enemy!.machineFailures![0]!.id);
    expect(a.effects).toHaveLength(1);
    const saved = prepareCombat(combat(a));
    const repaired = repairMachineFailure(
      saved.actors[0]!,
      a.enemy!.machineFailures![0]!.id,
    );
    expect(
      resetEncounter({ ...saved, actors: [repaired] }).actors[0]!.effects,
    ).toEqual(a.effects);
  });
});
