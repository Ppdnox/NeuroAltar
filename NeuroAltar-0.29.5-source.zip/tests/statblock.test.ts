import { readFileSync } from 'node:fs';
import { expect, it } from 'vitest';
import {
  abilityModifier,
  parseStatblockDraft,
  statblockSchema,
  toStatblockDraft,
} from '../src/domain/statblock';
import {
  enemyTemplateSchema,
  newEnemyTemplateDraft,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import {
  instantiateEnemy,
  prepareCombat,
  resetEncounter,
  parseActorDraft,
  toActorDraft,
} from '../src/domain/combat';
import { templateDraft } from '../src/domain/bestiary';
import { validationIssues } from '../src/domain/validation';
const fixture = statblockSchema.parse(
  JSON.parse(
    readFileSync(new URL('./fixtures/statblock.json', import.meta.url), 'utf8'),
  ),
);
const template = {
  id: crypto.randomUUID(),
  name: 'Wartownik Ż',
  category: 'human' as const,
  size: 'Średni',
  tt: 14,
  hpMax: 42,
  speeds: [],
  failureThreshold: 18,
  statblock: fixture,
};
it('roundtrips the shared statblock, nulls, explicit empty lists and final bonuses', () => {
  expect(parseStatblockDraft(toStatblockDraft(fixture))).toEqual(fixture);
  expect(
    parseEnemyTemplateDraft(templateDraft(template), template.id).statblock,
  ).toEqual(fixture);
  expect(abilityModifier(15)).toBe(2);
  expect(abilityModifier(9)).toBe(-1);
  expect(abilityModifier(null)).toBeNull();
  expect(parseStatblockDraft(toStatblockDraft()).abilityScores.str).toBeNull();
  expect(parseStatblockDraft(toStatblockDraft()).resistances).toBeNull();
  expect(fixture.vulnerabilities).toEqual([]);
  expect(fixture.savingThrows.str).toBe(5);
});
it('keeps old templates absent and runtime, template, original and prepared independent', () => {
  const legacy = { ...template, statblock: undefined };
  expect(enemyTemplateSchema.parse(legacy).statblock).toBeUndefined();
  const a = instantiateEnemy(template, 0),
    b = instantiateEnemy(template, 1);
  expect(parseActorDraft(toActorDraft(a))).toEqual(a);
  a.enemy!.statblock!.abilityScores.str = 20;
  a.enemy!.statblock!.damageThreshold = 0;
  expect(b.enemy!.statblock).toEqual(fixture);
  expect(a.enemy!.template.statblock).toEqual(fixture);
  expect(a.prepared!.enemy!.statblock).toEqual(fixture);
  const c = {
    encounterId: 1 as const,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [a, b],
  };
  expect(resetEncounter(c).actors[0]!.enemy!.statblock).toEqual(fixture);
  const prepared = prepareCombat(c);
  prepared.actors[0]!.enemy!.statblock!.damageThreshold = 8;
  expect(
    resetEncounter(prepared).actors[0]!.enemy!.statblock!.damageThreshold,
  ).toBe(0);
  expect(template.failureThreshold).toBe(18);
});
it('reports exact nested fields, rejects fractions, negatives, unsafe numbers and oversized text', () => {
  const d = {
    ...newEnemyTemplateDraft(),
    name: 'Test',
    tt: '10',
    hpMax: '20',
    statblock: toStatblockDraft(fixture),
  };
  d.statblock.abilityScores.dex = '12,5';
  d.statblock.damageThreshold = '-1';
  try {
    parseEnemyTemplateDraft(d, template.id);
    expect.fail('invalid accepted');
  } catch (e) {
    expect(validationIssues(e).map((i) => i.path)).toEqual(
      expect.arrayContaining([
        'statblock.abilityScores.dex',
        'statblock.damageThreshold',
      ]),
    );
  }
  for (const bad of [-1, 1.5, Number.MAX_SAFE_INTEGER + 1]) {
    expect(
      statblockSchema.safeParse({
        ...fixture,
        abilityScores: { ...fixture.abilityScores, str: bad },
      }).success,
    ).toBe(false);
  }
  expect(
    statblockSchema.safeParse({ ...fixture, subtype: 'x'.repeat(201) }).success,
  ).toBe(false);
  expect(
    statblockSchema.safeParse({ ...fixture, skills: ['x'.repeat(1001)] })
      .success,
  ).toBe(false);
  expect(
    statblockSchema.safeParse({
      ...fixture,
      senses: Array(101).fill('Widzenie'),
    }).success,
  ).toBe(false);
  expect(
    statblockSchema.safeParse({
      ...fixture,
      abilityScores: { ...fixture.abilityScores, luck: 2 },
    }).success,
  ).toBe(false);
});
