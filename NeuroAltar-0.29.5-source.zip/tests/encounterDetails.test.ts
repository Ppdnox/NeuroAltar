import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, it } from 'vitest';
import { migrate, repositoryFor } from './helpers/database';
import { createEncounterRepository } from '../src/db/encounterRepository';
it('persists details after reopening the SQLite file and preserves other state', async () => {
  const directory = mkdtempSync(join(tmpdir(), 'neuroaltar-details-'));
  let db = new DatabaseSync(join(directory, 'test.db'));
  try {
    migrate(db);
    db.exec(
      "UPDATE encounters SET round_number=7, party_levels_json='[3,4]' WHERE id=2",
    );
    const before = await repositoryFor(db).listSlots();
    await repositoryFor(db).updateDetails(2, {
      name: '  Zasadzka  ',
      notes: 'Zażółć\nDrugi wiersz',
    });
    db.close();
    db = new DatabaseSync(join(directory, 'test.db'));
    const after = await repositoryFor(db).listSlots();
    expect(after[1]).toMatchObject({
      ...before[1],
      name: '  Zasadzka  ',
      notes: 'Zażółć\nDrugi wiersz',
      updatedAt: after[1]!.updatedAt,
    });
    expect(after.filter((slot) => slot.id !== 2)).toEqual(
      before.filter((slot) => slot.id !== 2),
    );
    await expect(
      repositoryFor(db).updateDetails(2, { name: '  ', notes: 'Invalid' }),
    ).rejects.toThrow();
    expect(await repositoryFor(db).listSlots()).toEqual(after);
  } finally {
    db.close();
    rmSync(directory, { recursive: true });
  }
});
it('rejects a write affecting no slot instead of claiming success', async () => {
  const repo = createEncounterRepository({
    selectRows: async () => [],
    execute: async () => ({ rowsAffected: 0 }),
  });
  await expect(repo.updateDetails(1, { name: 'A', notes: '' })).rejects.toThrow(
    'Nie znaleziono',
  );
});
