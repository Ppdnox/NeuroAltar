import { expect, it } from 'vitest';
import { changesHistory, describeSheet } from '../src/domain/character/review';
import { withGameColor } from '../src/domain/character/model';
import { fixture, complete } from './helpers/character';

it('detects historical development changes separately from new levels, color preview and current HP', () => {
  const original = complete(fixture());
  expect(changesHistory(null, original)).toBe(false);
  expect(
    changesHistory(original, {
      ...original,
      hpCurrent: 1,
      notes: 'Bieżąca notatka',
    }),
  ).toBe(false);
  const advance = structuredClone(original);
  advance.levels.push({
    classId: 'brutal',
    color: 'rust',
    contextRevision: 1,
    choices: {},
  });
  expect(changesHistory(original, advance)).toBe(false);
  expect(changesHistory(original, withGameColor(advance, 'chrome', true))).toBe(
    false,
  );
  const changed = structuredClone(original);
  changed.levels[0]!.choices.start = ['instinct'];
  expect(changesHistory(original, changed)).toBe(true);
  expect(changesHistory(original, { ...original, originId: 'miami' })).toBe(
    true,
  );
});
it('compares notes, base values, choices, XP and corrections in readable groups', () => {
  const s = complete(fixture());
  s.notes = 'Żółty szlak';
  s.xp = [{ id: crypto.randomUUID(), amount: 50, reason: 'Wyprawa' }];
  const rows = describeSheet(s);
  expect(rows).toContainEqual(['Notatki', 'Żółty szlak']);
  expect(rows).toContainEqual(['Dziennik PD', '50: Wyprawa']);
  expect(rows.find(([label]) => label === 'Poziom 1')?.[1]).toContain('Brutal');
});
