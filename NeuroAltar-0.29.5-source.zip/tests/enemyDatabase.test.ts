import { instantiateCapabilities } from '../src/domain/capabilitySchema';
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, it } from 'vitest';
import { createCombatRepository } from '../src/db/combatRepository';
import {
  resetEncounter,
  instantiateEnemy,
  type Actor,
} from '../src/domain/combat';
const migrations = [
  '001_initial.sql',
  '002_pc_initiative.sql',
  '003_enemy_instances.sql',
].map((name) =>
  readFileSync(
    new URL(`../src-tauri/migrations/${name}`, import.meta.url),
    'utf8',
  ),
);
const read = (db: DatabaseSync) =>
  createCombatRepository({
    selectRows: async (sql, values = []) => db.prepare(sql).all(...values),
    execute: async (sql, values = []) => ({
      rowsAffected: Number(db.prepare(sql).run(...values).changes),
    }),
  }).listSlots();
it('migrates actual Stage 2 actor records without modifying any previous columns, names, notes or snapshots', async () => {
  const db = new DatabaseSync(':memory:');
  try {
    db.exec(migrations[0]!);
    db.exec(migrations[1]!);
    const pc: Actor = {
      id: '00000000-0000-4000-8000-000000000001',
      displayName: 'Żaneta',
      ttCurrent: 15,
      hpCurrent: 12,
      hpMaxCurrent: 20,
      initiativeValue: 0,
      initiativeTieOrder: 0,
      statuses: ['Zatrucie'],
    };
    db.prepare(
      `INSERT INTO encounter_actors (id,encounter_id,kind,display_name,tt_current,hp_current,hp_max_current,initiative_value,initiative_tie_order,prepared_snapshot_json,runtime_overrides_json) VALUES (?,1,'pc',?,15,12,20,0,0,?,?)`,
    ).run(
      pc.id,
      pc.displayName,
      JSON.stringify(pc),
      JSON.stringify({ manualStatuses: pc.statuses }),
    );
    db.prepare(
      'UPDATE encounters SET current_turn_actor_id = ?, round_number = 7, combat_revision = 12, notes = ? WHERE id = 1',
    ).run(pc.id, 'Zażółć\nDrugi wiersz');
    const beforeSlots = db.prepare('SELECT * FROM encounters').all();
    const beforeActors = db.prepare('SELECT * FROM encounter_actors').all();
    db.exec('BEGIN');
    db.exec(migrations[2]!);
    db.exec(
      readFileSync(
        new URL(
          '../src-tauri/migrations/005_actor_statuses.sql',
          import.meta.url,
        ),
        'utf8',
      ),
    );
    db.exec('COMMIT');
    expect(db.prepare('SELECT * FROM encounters').all()).toEqual(beforeSlots);
    const after = db
      .prepare('SELECT * FROM encounter_actors')
      .all()
      .map(({ reset_snapshot_json: baseline, ...row }) => {
        expect(baseline).toBeNull();
        return row;
      });
    expect(after).toEqual(beforeActors);
    const slots = await read(db);
    expect(slots[0]!.actors[0]!.prepared).toEqual(pc);
    expect(resetEncounter(slots[0]!).actors[0]!.hpCurrent).toBe(12);
    expect(slots[0]!.roundNumber).toBe(7);
    expect(db.prepare('PRAGMA integrity_check').get()).toEqual({
      integrity_check: 'ok',
    });
  } finally {
    db.close();
  }
});
it('reads enemy movement and explicit reset baseline after closing and reopening the SQLite file', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'neuroaltar-stage3-'));
  const path = join(dir, 'test.sqlite');
  let db = new DatabaseSync(path);
  try {
    migrations.forEach((sql) => db.exec(sql));
    db.exec(
      readFileSync(
        new URL(
          '../src-tauri/migrations/005_actor_statuses.sql',
          import.meta.url,
        ),
        'utf8',
      ),
    );
    const t = {
      id: '00000000-0000-4000-8000-000000000099',
      name: 'Żuk',
      capabilities: {
        resources: [
          {
            id: '00000000-0000-4000-8000-000000000055',
            name: 'Impuls',
            maxValue: 3,
            refreshRule: 'round' as const,
          },
        ],
        abilities: [],
        legendaryMax: 3,
      },
      injuryTrack: { enabled: true, initialLevel: 3 },
      cowardicePercent: 50,
      category: 'machine' as const,
      size: 'Średni',
      tt: 16,
      hpMax: 30,
      speeds: [{ mode: 'Chód', meters: 4.5 }],
    };
    const actor = instantiateEnemy(t, 0);
    db.prepare(
      'INSERT INTO enemy_templates (id,name,category,size,tt,hp_max,statblock_json) VALUES (?,?,?,?,?,?,?)',
    ).run(
      t.id,
      t.name,
      t.category,
      t.size,
      t.tt,
      t.hpMax,
      JSON.stringify({ speeds: t.speeds }),
    );
    db.prepare(
      `INSERT INTO encounter_actors (id,encounter_id,kind,template_id,display_name,tt_current,hp_current,hp_max_current,initiative_value,initiative_tie_order,prepared_snapshot_json,runtime_overrides_json,reset_snapshot_json) VALUES (?,3,'enemy',?,?,16,0,30,12,0,?,?,?)`,
    ).run(
      actor.id,
      t.id,
      t.name,
      JSON.stringify(actor.prepared),
      JSON.stringify({
        manualStatuses: ['Powalenie'],
        enemy: {
          template: t,
          capabilities: {
            ...instantiateCapabilities(t.capabilities),
            budget: { action: 0, bonus: 1, reaction: 0, legendary: 1 },
          },
          speeds: [{ mode: 'Chód', meters: 0 }],
          injury: { enabled: true, level: 4, deathWarning: true },
          cowardicePercent: 25,
        },
      }),
      JSON.stringify({ ...actor.prepared, hpCurrent: 24 }),
    );
    db.prepare(
      'UPDATE encounters SET current_turn_actor_id = ?, round_number = 3 WHERE id = 3',
    ).run(actor.id);
    const before = await read(db);
    expect(before[2]!.actors[0]!.enemy!.capabilities!.budget.action).toBe(0);
    db.close();
    db = new DatabaseSync(path);
    expect(await read(db)).toEqual(before);
    const reset = resetEncounter((await read(db))[2]!);
    expect(reset.actors[0]).toMatchObject({
      hpCurrent: 24,
      statuses: [],
      enemy: {
        speeds: [{ mode: 'Chód', meters: 4.5 }],
        injury: { enabled: true, level: 3, deathWarning: false },
        cowardicePercent: 50,
      },
    });
    expect(reset.actors[0]!.enemy!.capabilities!.budget.action).toBe(1);
    expect(reset.currentTurnActorId).toBeNull();
    expect(() =>
      db.prepare('DELETE FROM enemy_templates WHERE id = ?').run(t.id),
    ).toThrow();
    expect(() =>
      db
        .prepare('UPDATE encounter_actors SET template_id = NULL WHERE id = ?')
        .run(actor.id),
    ).toThrow();
    db.exec(`UPDATE encounter_actors SET reset_snapshot_json = '{}'`);
    await expect(read(db)).rejects.toThrow('stan przygotowany');
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
