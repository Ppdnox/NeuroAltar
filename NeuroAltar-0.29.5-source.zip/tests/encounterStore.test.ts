import { parseEncounterDetailsDraft } from '../src/domain/encounterDetails';
import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createEncounterStore } from '../src/stores/encounterStore';
import { migrate, repositoryFor } from './helpers/database';

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}
describe('encounter autosave', () => {
  let db: DatabaseSync;
  beforeEach(() => {
    vi.useFakeTimers();
    db = new DatabaseSync(':memory:');
    migrate(db);
  });
  afterEach(() => {
    vi.useRealTimers();
    db.close();
  });
  const setup = async () => {
    const repo = repositoryFor(db);
    const save = vi.fn(repo.updateDetails);
    const store = createEncounterStore(repo.listSlots, save);
    await store.getState().initialize();
    return { store, save, repo };
  };
  it('coalesces typing and persists exact unicode, quotes and multiline notes', async () => {
    const { store, save, repo } = await setup();
    store.getState().edit(1, { name: 'Z' });
    store.getState().edit(1, {
      name: "Zażółć '); DROP TABLE encounters; --",
      notes: 'Pierwszy\nDrugi 🛠',
    });
    expect(save).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(400);
    expect(save).toHaveBeenCalledTimes(1);
    expect((await repo.listSlots())[0]).toMatchObject(
      parseEncounterDetailsDraft(store.getState().drafts[1]!.details),
    );
    expect(store.getState().drafts[1]!.status).toBe('saved');
  });
  it('switches and flushes without mixing independent drafts', async () => {
    const { store, repo } = await setup();
    store.getState().edit(1, { name: 'Most' });
    store.getState().selectSlot(2);
    store.getState().edit(2, { notes: 'Tylko drugi slot' });
    await vi.advanceTimersByTimeAsync(400);
    const slots = await repo.listSlots();
    expect(slots[0]).toMatchObject({ name: 'Most', notes: '' });
    expect(slots[1]).toMatchObject({
      name: 'Potyczka 2',
      notes: 'Tylko drugi slot',
    });
    expect(slots.slice(2).every((slot) => slot.notes === '')).toBe(true);
  });
  it('serializes writes and saves newer text after an older response', async () => {
    const repo = repositoryFor(db);
    const gate = deferred<string>();
    const save = vi
      .fn(repo.updateDetails)
      .mockImplementationOnce((id, details, expected) =>
        gate.promise.then(() => repo.updateDetails(id, details, expected)),
      );
    const store = createEncounterStore(repo.listSlots, save);
    await store.getState().initialize();
    store.getState().edit(1, { name: 'Starsza' });
    const flush = store.getState().flush(1);
    await Promise.resolve();
    store.getState().edit(1, { name: 'Najnowsza' });
    store.getState().selectSlot(2);
    expect(save).toHaveBeenCalledTimes(1);
    gate.resolve(new Date().toISOString());
    await flush;
    expect(save).toHaveBeenCalledTimes(2);
    expect(store.getState().drafts[1]!.details.name).toBe('Najnowsza');
    expect((await repo.listSlots())[0]!.name).toBe('Najnowsza');
  });
  it('retains draft on failure and retries the latest values', async () => {
    const { store, save, repo } = await setup();
    save.mockRejectedValueOnce(new Error('Disk full'));
    store.getState().edit(3, { notes: 'Nie zgub mnie' });
    expect(await store.getState().flush(3)).toBe(false);
    expect(store.getState().drafts[3]).toMatchObject({
      status: 'error',
      error: 'Disk full',
      details: { notes: 'Nie zgub mnie' },
    });
    expect((await repo.listSlots())[2]!.notes).toBe('');
    expect(await store.getState().flush(3)).toBe(true);
    expect((await repo.listSlots())[2]!.notes).toBe('Nie zgub mnie');
  });
  it('blocks exit for an empty name and keeps pending notes until corrected', async () => {
    const { store, save, repo } = await setup();
    store.getState().edit(4, { name: '   ', notes: 'Draft' });
    expect(await store.getState().prepareClose()).toBe(false);
    expect(save).not.toHaveBeenCalled();
    expect(store.getState()).toMatchObject({ closing: false, activeId: 4 });
    store.getState().edit(4, { name: 'Czwarta' });
    expect(await store.getState().prepareClose()).toBe(true);
    expect((await repo.listSlots())[3]).toMatchObject({
      name: 'Czwarta',
      notes: 'Draft',
    });
  });
  it('waits for an in-flight write and latest edits before allowing exit', async () => {
    const repo = repositoryFor(db);
    const gate = deferred<string>();
    const save = vi
      .fn(repo.updateDetails)
      .mockImplementationOnce((id, details, expected) =>
        gate.promise.then(() => repo.updateDetails(id, details, expected)),
      );
    const store = createEncounterStore(repo.listSlots, save);
    await store.getState().initialize();
    store.getState().edit(1, { notes: 'A' });
    void store.getState().flush(1);
    await Promise.resolve();
    store.getState().edit(1, { notes: 'B' });
    const closed = vi.fn();
    const closing = store.getState().prepareClose().then(closed);
    await Promise.resolve();
    expect(closed).not.toHaveBeenCalled();
    store.getState().edit(1, { notes: 'Blocked while closing' });
    gate.resolve(new Date().toISOString());
    await closing;
    expect(closed).toHaveBeenCalledWith(true);
    expect((await repo.listSlots())[0]!.notes).toBe('B');
  });
  it('does not report success or allow exit after a failed write', async () => {
    const { store, save } = await setup();
    save.mockRejectedValue(new Error('Read only'));
    store.getState().edit(5, { notes: 'Draft' });
    expect(await store.getState().prepareClose()).toBe(false);
    expect(store.getState().drafts[5]!.status).toBe('error');
    expect(store.getState().closing).toBe(false);
  });
  it('reloading a store restores all five independent names and notes', async () => {
    const { store, repo } = await setup();
    for (const slot of store.getState().slots)
      store.getState().edit(slot.id, {
        name: `Starcie ${slot.id}`,
        notes: `Notatka ${slot.id}\nDalszy ciąg`,
      });
    await store.getState().prepareClose();
    const restarted = createEncounterStore(repo.listSlots, repo.updateDetails);
    await restarted.getState().initialize();
    expect(restarted.getState().slots).toEqual(await repo.listSlots());
    expect(restarted.getState().slots.map((slot) => slot.name)).toEqual([
      'Starcie 1',
      'Starcie 2',
      'Starcie 3',
      'Starcie 4',
      'Starcie 5',
    ]);
  });
  it('retries initialization errors and deduplicates concurrent loading', async () => {
    const repo = repositoryFor(db);
    const load = vi
      .fn(repo.listSlots)
      .mockRejectedValueOnce(new Error('Unavailable'));
    const store = createEncounterStore(load, repo.updateDetails);
    await store.getState().initialize();
    expect(store.getState().status).toBe('error');
    await Promise.all([
      store.getState().initialize(),
      store.getState().initialize(),
    ]);
    expect(load).toHaveBeenCalledTimes(2);
    expect(store.getState().status).toBe('ready');
  });
  it('persists independent party levels, retains invalid text across slots and close, and preserves legacy detail writes', async () => {
    const { store, repo, save } = await setup();
    store.getState().edit(1, { partyLevelsText: '4\n4 4 4' });
    store.getState().edit(2, { partyLevelsText: '3 5' });
    await vi.advanceTimersByTimeAsync(400);
    store.getState().edit(2, { partyLevelsText: '3 0' });
    store.getState().selectSlot(1);
    expect(await store.getState().prepareClose()).toBe(false);
    expect(store.getState().activeId).toBe(2);
    expect(store.getState().drafts[2]!.details.partyLevelsText).toBe('3 0');
    expect((await repo.listSlots())[1]!.partyLevels).toEqual([3, 5]);
    save.mockRejectedValueOnce(new Error('Disk full'));
    store.getState().edit(2, { partyLevelsText: '6 7' });
    expect(await store.getState().flush(2)).toBe(false);
    expect(store.getState().drafts[2]!.details.partyLevelsText).toBe('6 7');
    expect(await store.getState().flush(2)).toBe(true);
    await repo.updateDetails(1, {
      name: 'Żółta brama',
      notes: 'Pierwszy\nDrugi',
    });
    const restarted = createEncounterStore(repo.listSlots, repo.updateDetails);
    await restarted.getState().initialize();
    expect(restarted.getState().slots.map((s) => s.partyLevels)).toEqual([
      [4, 4, 4, 4],
      [6, 7],
      [],
      [],
      [],
    ]);
    expect(restarted.getState().drafts[1]!.details.partyLevelsText).toBe(
      '4\n4\n4\n4',
    );
    expect(await restarted.getState().prepareClose()).toBe(true);
  });
  it('does not lose newer levels while an earlier metadata save is in flight', async () => {
    const repo = repositoryFor(db);
    const gate = deferred<string>();
    const save = vi
      .fn(repo.updateDetails)
      .mockImplementationOnce((id, details, expected) =>
        gate.promise.then(() => repo.updateDetails(id, details, expected)),
      );
    const store = createEncounterStore(repo.listSlots, save);
    await store.getState().initialize();
    store.getState().edit(1, { partyLevelsText: '4 4' });
    const writing = store.getState().flush(1);
    await Promise.resolve();
    store.getState().edit(1, { partyLevelsText: '5 5', notes: 'Najnowsze' });
    gate.resolve(new Date().toISOString());
    await writing;
    expect((await repo.listSlots())[0]).toMatchObject({
      partyLevels: [5, 5],
      notes: 'Najnowsze',
    });
  });
  it('rejects an incomplete slot set', async () => {
    const repo = repositoryFor(db);
    const store = createEncounterStore(
      async () => (await repo.listSlots()).slice(0, 4),
      repo.updateDetails,
    );
    await store.getState().initialize();
    expect(store.getState().status).toBe('error');
    expect(store.getState().slots).toEqual([]);
  });
});

it('metadata compare-and-save rejects a stale window after clear and accepts an identical retry', async () => {
  const db = new DatabaseSync(':memory:');
  try {
    migrate(db);
    const repo = repositoryFor(db);
    await repo.updateDetails(1, {
      name: 'Most',
      notes: 'Stare',
      partyLevels: [4],
    });
    const expected = { name: 'Most', notes: 'Stare', partyLevels: [4] };
    db.exec("UPDATE encounters SET notes='' WHERE id=1");
    await expect(
      repo.updateDetails(1, { ...expected, name: 'Nowszy szkic' }, expected),
    ).rejects.toThrow('innym oknie');
    expect((await repo.listSlots())[0]!.notes).toBe('');
    const next = { ...expected, notes: 'Nowe' };
    const empty = { ...expected, notes: '' };
    const stamp = await repo.updateDetails(1, next, empty);
    expect(await repo.updateDetails(1, next, empty)).toBe(stamp);
  } finally {
    db.close();
  }
});
