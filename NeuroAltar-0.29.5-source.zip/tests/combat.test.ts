import { expect, it } from 'vitest';
import {
  combatSchema,
  parseActorDraft,
  toActorDraft,
  type Actor,
} from '../src/domain/combat';

const pc: Actor = {
  id: '00000000-0000-4000-8000-000000000001',
  displayName: 'Łowca',
  ttCurrent: 12,
  hpCurrent: 20,
  hpMaxCurrent: 20,
  initiativeValue: null,
  initiativeTieOrder: 0,
  statuses: [],
};
it.each(['', ' ', '1.5', 'NaN', 'Infinity', '1e2', '-1', '9007199254740992'])(
  'rejects invalid current HP text %s without treating empty input as zero',
  (value) => {
    expect(() =>
      parseActorDraft({ ...toActorDraft(pc), hpCurrent: value }),
    ).toThrow();
  },
);
it('keeps a missing initiative distinct from zero, normalizes manual statuses and preserves names', () => {
  expect(parseActorDraft(toActorDraft(pc)).initiativeValue).toBeNull();
  expect(
    parseActorDraft({
      ...toActorDraft(pc),
      initiativeValue: '0',
      displayName: '  Żaneta  ',
      statusesText: ' Przerażenie\n\nPrzerażenie\nZatrucie',
    }),
  ).toMatchObject({
    initiativeValue: 0,
    displayName: '  Żaneta  ',
    statuses: ['Przerażenie', 'Zatrucie'],
  });
  expect(() =>
    parseActorDraft({ ...toActorDraft(pc), hpMaxCurrent: '19' }),
  ).toThrow();
});
it('rejects duplicate identity/order, invalid active actor and active actor without initiative', () => {
  const combat = {
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [pc],
  };
  expect(combatSchema.safeParse(combat).success).toBe(true);
  expect(combatSchema.safeParse({ ...combat, actors: [pc, pc] }).success).toBe(
    false,
  );
  expect(
    combatSchema.safeParse({ ...combat, currentTurnActorId: pc.id }).success,
  ).toBe(false);
  expect(
    combatSchema.safeParse({
      ...combat,
      actors: [pc, { ...pc, id: '00000000-0000-4000-8000-000000000002' }],
    }).success,
  ).toBe(false);
});
