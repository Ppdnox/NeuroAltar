import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/moloch-city.v1.json';
import equipment from '../src/data/equipment/moloch-city.v1.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { templateDraft } from '../src/domain/bestiary';
import { itemSchema, calculateWeaponAttackProfile } from '../src/domain/item';
import { fixedHandbookSp } from '../src/domain/presentation';
import { doubleDamageDice } from '../src/domain/dice';
import { catalogEntry } from '../src/domain/character/inventoryCatalog';
import base from '../src/data/equipment/catalog.v1.json';
it('preserves eleven complete supplement statblocks, source pages and manual TT', () => {
  expect(
    batch.entries.map((e) => [
      e.template.name,
      e.source.printedPage,
      e.template.hpMax,
      e.template.sp,
    ]),
  ).toEqual([
    ['Glut', 37, 60, 9],
    ['Thinboy', 38, 24, 7],
    ['Mutkornica', 39, 96, 12],
    ['Modliszka', 40, 96, 11],
    ['Matka (ATOM-A)', 41, 140, 20],
    ['Żuk', 42, 408, 80],
    ['Lekarz Asgardu', 43, 9, 0.5],
    ['Strażnik Asgardu', 43, 25, 3],
    ['Autonomiczne działko laserowe (ADL)', 43, 20, 1],
    ['Generacja II. Genotyp kreci (Kretolud)', 44, 16, 2],
    ['Generacja III. Krecia Mutamać', 45, 56, 9],
  ]);
  for (const e of batch.entries) {
    const t = enemyTemplateSchema.parse(e.template);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toEqual(t);
    expect(fixedHandbookSp(t)).toBe(true);
    expect(e.source.pdfPage).toBeNull();
  }
  expect(batch.entries[2]!.template.tt).toBe(12);
  const expected = [
    [7],
    [7],
    [7],
    [8, 8],
    [],
    [12, 12],
    [],
    [4, 4],
    [8],
    [5],
    [8, 3],
  ];
  batch.entries.forEach((e, i) => {
    const t = enemyTemplateSchema.parse(e.template);
    expect(
      t
        .loadout!.items.filter((x) => x.item.weaponProfile)
        .map((x) => calculateWeaponAttackProfile(x, t.loadout!).attack),
    ).toEqual(expected[i]);
  });
});
it('keeps encounter/day limits and unusual attacks without invented damage rolls', () => {
  expect(
    batch.entries[0]!.template.capabilities.resources.map((r) => [
      r.maxValue,
      r.refreshRule,
    ]),
  ).toEqual([
    [2, 'encounter'],
    [4, 'encounter'],
  ]);
  expect(
    batch.entries[5]!.template.capabilities.resources.map((r) => [
      r.maxValue,
      r.refreshRule,
    ]),
  ).toEqual([
    [2, 'day'],
    [16, 'day'],
  ]);
  expect(
    batch.entries[9]!.template.loadout.items[1]!.item.weaponProfile,
  ).toBeUndefined();
  expect(doubleDamageDice('1k4+4', 3)).toBe('3k4+4');
  expect(doubleDamageDice('1k4+4')).toBe('2k4+4');
});
it('adds two laser weapons with user availability and retains dose package value', () => {
  const items = equipment.entries.map((x) => itemSchema.parse(x));
  expect(
    items.map((x) => [
      x.name,
      x.weight,
      x.basePrice?.min,
      x.baseAvailability?.min,
    ]),
  ).toEqual([
    ['Beamgun', 1, 200, 0],
    ['BigBeamgun', 5, 400, 0],
  ]);
  expect(items[1]!.weaponProfile!.range).toEqual({
    normal: 200,
    long: 600,
    unit: 'm',
  });
  const antibiotic = itemSchema.parse(
    base.entries.find((x) => x.name === 'Antybiotyk (10 dawek)'),
  );
  const entry = catalogEntry(antibiotic);
  expect(entry.quantityMilli).toBe(10000);
  expect(entry.unit).toBe('szt.');
  expect(entry.item.basePrice!.min * 10).toBe(antibiotic.basePrice!.min);
});

it('uses handbook firearm masses in both new and legacy inventory copies', async () => {
  const { inventoryWeight, fixedWeaponWeight } =
    await import('../src/domain/medicineWeight');
  for (const [name, kg] of [
    ['B 92', 1],
    ['AK (Kałach)', 3],
  ] as const) {
    const item = itemSchema.parse(base.entries.find((x) => x.name === name));
    expect(fixedWeaponWeight(item)).toBe(kg);
    const entry = catalogEntry(item);
    expect(entry.weightMg).toBe(kg * 1_000_000);
    expect(inventoryWeight({ ...entry, weightMg: null })).toBe(kg * 1_000_000);
  }
});
