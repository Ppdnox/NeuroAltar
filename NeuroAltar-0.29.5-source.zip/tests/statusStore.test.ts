import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { createEncounterStore } from '../src/stores/encounterStore';
import { prepareAppClose } from '../src/services/prepareAppClose';
import { SLOT_IDS } from '../src/domain/encounter';
import type { Combat } from '../src/domain/combat';
import type { SaveReason } from '../src/domain/combatLog';
beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());
async function fixture() {
  let data: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [],
  }));
  const load = async () => structuredClone(data);
  const save = vi.fn<(c: Combat, reason?: SaveReason) => Promise<number>>(
    async (c) => {
      data = data.map((v) =>
        v.encounterId === c.encounterId
          ? structuredClone({ ...c, revision: c.revision + 1 })
          : v,
      );
      return c.revision + 1;
    },
  );
  const store = createCombatStore(load, save);
  await store.getState().initialize();
  store.getState().addActor(3);
  await store.getState().flush(3);
  const id = store.getState().slots[2]!.actors[0]!.id;
  store.getState().editActor(3, id, { initiativeValue: '12' });
  await store.getState().flush(3);
  return { store, id, save, load };
}
it('retains incomplete status form, reveals its slot on quit and allows correction or cancellation', async () => {
  const { store, id } = await fixture();
  store.getState().openStatusForm(3, id);
  store.getState().editStatusForm({
    systemKey: null,
    name: '',
    description: 'Zażółć\nDruga linia',
    durationType: 'rounds',
    rounds: '0',
  });
  store.getState().submitStatusForm();
  expect(store.getState().statusForm?.error).toBeTruthy();
  const encounters = createEncounterStore();
  encounters.getState().prepareClose = vi.fn(async () => true);
  expect(await prepareAppClose(encounters, store)).toBe(false);
  expect(encounters.getState().activeId).toBe(3);
  expect(store.getState().statusForm!.fields.description).toBe(
    'Zażółć\nDruga linia',
  );
  store.getState().editStatusForm({ name: 'Żółty dym', rounds: '2' });
  store.getState().submitStatusForm();
  await store.getState().flush(3);
  expect(store.getState().statusForm).toBeNull();
  expect(store.getState().slots[2]!.actors[0]!.effects![0]!.name).toBe(
    'Żółty dym',
  );
  store.getState().openStatusForm(3, id);
  store.getState().cancelStatusForm();
  expect(await store.getState().prepareClose()).toBe(true);
});
it('preserves expiry and rapid actions through save failure, neutral turn correction, restart and reset', async () => {
  const { store, id, save, load } = await fixture();
  store.getState().openStatusForm(3, id);
  store.getState().editStatusForm({ durationType: 'until_end_of_turn' });
  store.getState().submitStatusForm();
  await store.getState().flush(3);
  store.getState().prepareEncounter(3);
  await store.getState().flush(3);
  store.getState().setCurrent(3, id);
  await store.getState().flush(3);
  expect(store.getState().slots[2]!.actors[0]!.effects).toHaveLength(1);
  save.mockRejectedValueOnce(new Error('disk'));
  store.getState().nextTurn(3);
  await store.getState().flush(3);
  expect(store.getState().drafts[3]!.status).toBe('error');
  expect(store.getState().slots[2]!.actors[0]!.effects).toHaveLength(1);
  await store.getState().flush(3);
  expect(store.getState().slots[2]!.actors[0]!.effects).toEqual([]);
  expect(save.mock.calls.at(-1)![1]).toBe('advance');
  const restarted = createCombatStore(load, save);
  await restarted.getState().initialize();
  expect(restarted.getState().slots[2]!.actors[0]!.effects).toEqual([]);
  restarted.getState().resetEncounter(3);
  await restarted.getState().flush(3);
  expect(restarted.getState().slots[2]!.actors[0]!.effects).toHaveLength(1);
  expect(restarted.getState().slots[1]!.actors).toEqual([]);
});
it('exhaustion increments one counter, clamps at six, is reduced explicitly, and never changes actor HP or TT', async () => {
  const { store, id } = await fixture();
  for (let i = 0; i < 8; i++) store.getState().adjustExhaustion(3, id, 1);
  await store.getState().flush(3);
  const actor = store.getState().slots[2]!.actors[0]!;
  expect(actor.effects).toHaveLength(1);
  expect(actor.effects![0]!.level).toBe(6);
  expect(actor.hpCurrent).toBe(1);
  expect(actor.ttCurrent).toBe(10);
  for (let i = 0; i < 7; i++) store.getState().adjustExhaustion(3, id, -1);
  await store.getState().flush(3);
  expect(store.getState().slots[2]!.actors[0]!.effects).toEqual([]);
});
