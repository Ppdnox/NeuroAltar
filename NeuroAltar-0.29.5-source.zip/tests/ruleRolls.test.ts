import { expect, it } from 'vitest';
import { ruleRolls } from '../src/domain/ruleRolls';
it('recognizes attack bonus and full damage formula without treating a target DC as an attacker roll', () => {
  const text = 'Atak wręcz +9; zasięg 1,5 m; 8 (1k6 + 5) kłute. RO SIŁ ST 13.';
  const rolls = ruleRolls(text);
  expect(rolls.map((r) => [r.formula, r.kind])).toEqual([
    ['1k20+9', 'attack'],
    ['1k6+5', 'damage'],
  ]);
  expect(rolls.map((r) => text.slice(r.start, r.end))).toEqual([
    '+9',
    '1k6 + 5',
  ]);
  expect(
    ruleRolls('RO ZRC ST 14; porażka: 9 (3k6) kłute.').map((r) => r.formula),
  ).toEqual(['3k6']);
});
it('preserves compound, unsupported and malformed dice expressions rather than rolling fragments', () => {
  for (const text of ['101k6', 'k3', '2k6*2', 'abc2k6', '2k6+10001'])
    expect(ruleRolls(text), text).toEqual([]);
  expect(
    ruleRolls('1k6 obrażeń i dodatkowo 2k8 obrażeń').map((r) => r.formula),
  ).toEqual(['1k6', '2k8']);
  expect(
    ruleRolls('Atak dystansowy −2; 2k6 − 1 obrażeń.').map((r) => r.formula),
  ).toEqual(['1k20-2', '2k6-1']);
});

it('makes mixed damage and alternate machine attack phrasing clickable as complete expressions', () => {
  expect(
    ruleRolls('Atak wręcz +8; 18 (2k8 + 2k6 + 4) obrażeń.').map(
      (r) => r.formula,
    ),
  ).toEqual(['1k20+8', '2k8+2k6+4']);
  expect(
    ruleRolls('Jeden atak piłą: +16, 3 m; 32 (4k12 + 10) cięte.').map(
      (r) => r.formula,
    ),
  ).toEqual(['1k20+16', '4k12+10']);
  expect(
    ruleRolls('Trzy ataki w jeden lub więcej celów: +9, 3 m.')[0]?.formula,
  ).toBe('1k20+9');
});

it('covers explicit attacks and dice in every bundled enemy ability without changing its text', async () => {
  const { readFileSync, readdirSync } = await import('node:fs');
  const { createElement } = await import('react');
  const { renderToStaticMarkup } = await import('react-dom/server');
  const { RuleText } = await import('../src/features/statblocks/RuleText');
  const root = new URL('../src/data/bestiary/', import.meta.url);
  let tested = 0;
  let templates = 0;
  for (const file of readdirSync(root).filter((f) => f.endsWith('.json'))) {
    const data = JSON.parse(readFileSync(new URL(file, root), 'utf8'));
    for (const entry of data.entries ?? []) {
      templates++;
      for (const ability of entry.template.capabilities?.abilities ?? []) {
        const text = ability.description as string;
        const html = renderToStaticMarkup(
          createElement(RuleText, {
            text,
            label: ability.name,
            onRoll: () => {},
          }),
        );
        for (const roll of ruleRolls(text))
          expect(html, `${entry.template.name}: ${ability.name}`).toContain(
            `(${roll.formula})`,
          );
        if (/\batak(?:i)?\b[^.;]*\+\d+/i.test(text))
          expect(
            ruleRolls(text).some((r) => r.kind === 'attack'),
            text,
          ).toBe(true);
        tested++;
      }
    }
  }
  expect(tested).toBeGreaterThan(100);
  expect(templates).toBe(62);
});
