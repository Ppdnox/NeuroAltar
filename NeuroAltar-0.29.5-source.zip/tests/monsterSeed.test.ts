import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/monsters.v1.json';
import machines from '../src/data/bestiary/machines.v1.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
  currentCategories,
  categoryOptions,
} from '../src/domain/enemy';
import { templateDraft, filterCatalog } from '../src/domain/bestiary';
import { calculateWeaponAttackProfile } from '../src/domain/item';
import { instantiateEnemy, resetEncounter } from '../src/domain/combat';
import {
  consumeCapability,
  refreshCapabilities,
  adjustResource,
} from '../src/domain/capabilities';
import { prepareDeathBreath } from '../src/domain/deathBreath';
const entries = batch.entries.map((e) => ({
  ...e,
  template: enemyTemplateSchema.parse(e.template),
}));
const get = (key: string) => entries.find((e) => e.key === key)!.template;
it('inventories twelve complete monsters plus the separate host-dependent overlay, preserving source values', () => {
  const expected = [
    ['alahama', 234, 14, 102, 23],
    ['bit-boys', 235, 12, 24, 5],
    ['bit-boy-przewodnik', 236, 16, 60, 13],
    ['kitchin', 236, 15, 8, 2],
    ['harpie', 237, 12, 48, 12],
    ['korzec', 238, 18, 144, 27],
    ['megator', 239, 21, 240, 102],
    ['pies-mutek', 240, 12, 28, 4],
    ['szczekowij', 241, 16, 96, 25],
    ['taran', 242, 18, 104, 25],
    ['techmorwa-malutka', 243, 13, 16, 10],
    ['techmorwa-srednia', 244, 10, 84, 20],
  ];
  expect(
    entries.map((e) => [
      e.key,
      e.source.pdfPage,
      e.template.tt,
      e.template.hpMax,
      e.template.sp,
    ]),
  ).toEqual(expected);
  expect(
    new Set([...entries, ...machines.entries].map((e) => e.template.id)).size,
  ).toBe(23);
  expect(batch.sourceSha256).toBe(machines.sourceSha256);
  for (const { template: t, source } of entries) {
    expect(t.category).toBe('monster');
    expect(source.pdfPage).toBe(source.printedPage + 2);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toEqual(t);
    expect(Object.values(t.statblock!.abilityScores)).not.toContain(null);
    expect(Object.values(t.statblock!.savingThrows)).toEqual(
      Array(6).fill(null),
    );
    expect(t.failureThreshold).toBeNull();
  }
  expect(get('taran').statblock!.damageThreshold).toBe(10);
  expect(get('korzec').statblock).toMatchObject({
    resistances: ['kłute'],
    damageImmunities: ['obuchowe'],
    vulnerabilities: ['cięte', 'od ognia'],
  });
  expect(get('harpie').speeds).toContainEqual({ mode: 'Chód', meters: 4.5 });
  expect(
    get('kitchin').loadout!.items[0]!.item.weaponProfile!.range.normal,
  ).toBe(0);
  expect(
    get('alahama').loadout!.items[1]!.item.weaponProfile!.damageModes[0],
  ).toMatchObject({ average: 18, dice: '6k6' });
  expect(get('szczekowij').loadout!.items[1]!.item.description).toContain(
    '9 (3k6)',
  );
  expect(
    get('techmorwa-srednia').loadout!.items[0]!.item.description,
  ).toContain('8 (2k8)');
});
it('calculates all printed attack bonuses once, retaining attacks without a roll as descriptions', () => {
  const totals = [
    [9, 9],
    [4, 4],
    [6],
    [7],
    [6, 6],
    [9, 9],
    [13, 13],
    [5],
    [8, 8],
    [8],
    [5],
    [5],
  ];
  for (const [i, { template: t }] of entries.entries())
    expect(
      t
        .loadout!.items.filter((e) => e.item.weaponProfile)
        .map((e) => calculateWeaponAttackProfile(e, t.loadout!).attack),
    ).toEqual(totals[i]);
  expect(get('alahama').loadout!.items[2]!.item.weaponProfile).toBeUndefined();
  expect(
    get('bit-boy-przewodnik').loadout!.items[1]!.item.description,
  ).toContain('ST 13');
});
it('separates encounter breath, daily resistance, daily eggs, action and legendary budgets and independent copies', () => {
  const t = get('megator'),
    b = instantiateEnemy(t, 1);
  let a = instantiateEnemy(t, 0);
  const breath = t.capabilities!.abilities.find(
    (a) => a.name === 'Zionięcie',
  )!.id;
  const resistance = t.capabilities!.resources.find(
    (r) => r.name === 'Legendarna odporność',
  )!.id;
  a = adjustResource(a, resistance, -1);
  expect(a.enemy!.capabilities!.budget.reaction).toBe(1);
  a = consumeCapability(a, breath);
  a = refreshCapabilities(a, 'turn');
  a = consumeCapability(a, breath);
  a = refreshCapabilities(a, 'turn');
  expect(() => consumeCapability(a, breath)).toThrow();
  expect(
    refreshCapabilities(a, 'round').enemy!.capabilities!.resources.map(
      (r) => r.currentValue,
    ),
  ).toEqual([2, 0]);
  expect(
    refreshCapabilities(a, 'encounter').enemy!.capabilities!.resources.map(
      (r) => r.currentValue,
    ),
  ).toEqual([2, 2]);
  expect(
    refreshCapabilities(a, 'day').enemy!.capabilities!.resources.map(
      (r) => r.currentValue,
    ),
  ).toEqual([3, 0]);
  expect(a.hpCurrent).toBe(240);
  expect(b.enemy!.capabilities!.resources.map((r) => r.currentValue)).toEqual([
    3, 2,
  ]);
  const reset = resetEncounter({
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [a, b],
  });
  expect(
    reset.actors[0]!.enemy!.capabilities!.resources.map((r) => r.currentValue),
  ).toEqual([3, 2]);
  expect(get('techmorwa-malutka').capabilities!.resources[0]).toMatchObject({
    maxValue: 10,
    refreshRule: 'day',
  });
  expect(get('techmorwa-srednia').capabilities!.resources).toEqual([]);
  expect(t.capabilities!.legendaryMax).toBe(3);
});
it('offers five explicit categories and retains legacy values only for existing entries', () => {
  expect(currentCategories).toEqual([
    'human',
    'machine',
    'mutant',
    'monster',
    'animal',
  ]);
  expect(categoryOptions()).toHaveLength(5);
  expect(categoryOptions(['beast']).map(([key]) => key)).toContain('beast');
  for (const category of [...currentCategories, 'beast', 'other'])
    expect(
      enemyTemplateSchema.parse({ ...get('taran'), category }).category,
    ).toBe(category);
  expect(
    filterCatalog(
      entries.map((e) => ({ template: e.template, revision: 0 })),
      '',
      'monster',
      '',
    ),
  ).toHaveLength(12);
  expect(
    filterCatalog(
      entries.map((e) => ({ template: e.template, revision: 0 })),
      '',
      'animal',
      '',
    ),
  ).toHaveLength(0);
});
it('prepares a reviewed Zombie from a host without altering host/copies or inventing unknown host values', () => {
  const host = structuredClone(get('bit-boy-przewodnik'));
  host.category = 'mutant';
  const before = structuredClone(host),
    actor = instantiateEnemy(host, 0);
  const claw = host.capabilities!.abilities.find(
    (a) => a.name === 'Pazury',
  )!.id;
  const d = prepareDeathBreath(host, [claw]);
  const zombie = parseEnemyTemplateDraft(d, crypto.randomUUID());
  expect(zombie).toMatchObject({
    tt: 14,
    hpMax: 60,
    sp: 15,
    category: 'monster',
    statblock: { abilityScores: { str: 16, int: 4, cha: 2 } },
  });
  expect(zombie.speeds).toEqual(host.speeds);
  expect(zombie.capabilities!.abilities.map((a) => a.name)).toEqual([
    'Pazury',
    'Atak wielokrotny',
    'Macka',
    'Ugryzienie',
  ]);
  expect(zombie.capabilities!.abilities[2]!.description).toContain('ST 6');
  expect(zombie.loadout!.items).toHaveLength(1);
  expect(host).toEqual(before);
  expect(actor.enemy!.template).toEqual(before);
  expect(instantiateEnemy(zombie, 1).initiativeValue).toBeNull();
  expect(() => prepareDeathBreath(get('megator'), [])).toThrow();
  expect(() => prepareDeathBreath(host, [crypto.randomUUID()])).toThrow();
  delete host.loadout;
  delete host.statblock;
  delete host.sp;
  const unknown = prepareDeathBreath(host, []);
  expect(unknown.sp).toBe('');
  expect(unknown.capabilities!.abilities.at(-1)!.description).toContain('N/D');
  host.tt = 1;
  expect(() =>
    parseEnemyTemplateDraft(prepareDeathBreath(host, []), crypto.randomUUID()),
  ).toThrow();
});
