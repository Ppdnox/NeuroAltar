import { expect, it, vi } from 'vitest';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import {
  parseDiceFormula,
  randomDie,
  rollDice,
  diceRollSchema,
} from '../src/domain/dice';
import { createDiceStore } from '../src/stores/diceStore';
import { DiceResult } from '../src/features/dice/DiceWorkspace';
import { RollValue } from '../src/features/dice/ActorRoll';
it('parses count, all supported dice and signed modifiers without arbitrary expressions', () => {
  expect(parseDiceFormula(' 3k8 + 2 ')).toEqual({
    count: 3,
    sides: 8,
    modifier: 2,
    formula: '3k8+2',
  });
  for (const sides of [4, 6, 8, 10, 12, 20, 100])
    expect(parseDiceFormula(`k${sides}`).sides).toBe(sides);
  expect(parseDiceFormula('2D6-3').formula).toBe('2k6-3');
  for (const input of [
    '0k6',
    '101k6',
    'k3',
    'k0',
    'k1000',
    '2k6+10001',
    '1 0k6',
    '2k6*2',
    'Math.random()',
    'k6;alert(1)',
    '(2k6)',
    'k6+'.padEnd(65, '1'),
  ])
    expect(() => parseDiceFormula(input), input).toThrow();
});
it('uses inclusive face bounds with unbiased uint32 rejection sampling', () => {
  expect(randomDie(8, () => 0)).toBe(1);
  expect(randomDie(8, () => 2 ** 32 - 1)).toBe(8);
  const next = vi
    .fn()
    .mockReturnValueOnce(2 ** 32 - 1)
    .mockReturnValueOnce(99);
  expect(randomDie(100, next)).toBe(100);
  expect(next).toHaveBeenCalledTimes(2);
  expect(() => randomDie(6, () => -1)).toThrow();
  expect(() => randomDie(6, () => 2 ** 32 - 1)).toThrow();
});
it('shows every die and adds the modifier exactly once, including negative totals', () => {
  const values = [1, 4, 8];
  const result = rollDice('3k8+2', () => values.shift()!);
  expect(result.total).toBe(15);
  expect(result.values).toEqual([1, 4, 8]);
  expect(rollDice('k4-10', () => 1).total).toBe(-9);
  expect(() => rollDice('k6', () => 7)).toThrow();
  const roll = {
    ...result,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    context: null,
  };
  expect(diceRollSchema.parse(roll)).toEqual(roll);
  expect(() => diceRollSchema.parse({ ...roll, total: 18 })).toThrow();
  const html = renderToStaticMarkup(createElement(DiceResult, { roll }));
  expect(html).toContain('15');
  expect(html).toContain('Wyniki poszczególnych kości');
});
it('does not roll on load or edit, persists explicit rolls, and retries the exact failed write once', async () => {
  const write = vi
    .fn()
    .mockRejectedValueOnce(Error('disk'))
    .mockResolvedValue(undefined);
  const execute = vi.fn((input: string) => rollDice(input, () => 4));
  const s = createDiceStore({ read: async () => [], write }, execute);
  await s.getState().load();
  s.getState().edit({ count: '3', sides: 8, modifier: '2' });
  expect(execute).not.toHaveBeenCalled();
  expect(await s.getState().roll()).toBe(false);
  const pending = s.getState().pending;
  expect(pending?.total).toBe(14);
  expect(await s.getState().roll()).toBe(false);
  expect(execute).toHaveBeenCalledTimes(1);
  expect(await s.getState().prepareClose()).toBe(true);
  expect(write.mock.calls[0]?.[0]).toEqual(write.mock.calls[1]?.[0]);
  expect(s.getState().history[0]).toEqual(pending);
  const reopened = createDiceStore({
    read: async () => s.getState().history,
    write,
  });
  await reopened.getState().load();
  expect(reopened.getState().history[0]).toEqual(pending);
});
it('waits for a roll started before close, rejects concurrent rolls and retains context', async () => {
  let finish!: () => void;
  const write = vi.fn(
    () =>
      new Promise<void>((resolve) => {
        finish = resolve;
      }),
  );
  const s = createDiceStore({ read: async () => [], write }, (input) =>
    rollDice(input, () => 2),
  );
  const context = {
    encounterId: 3 as const,
    actorId: crypto.randomUUID(),
    actorName: 'Gangus Ż',
    roundNumber: 2,
    label: 'Atak — nóż',
  };
  const rolling = s.getState().roll('k20+4', context);
  const closing = s.getState().prepareClose();
  let closed = false;
  void closing.then(() => {
    closed = true;
  });
  await vi.waitFor(() => expect(write).toHaveBeenCalledTimes(1));
  expect(closed).toBe(false);
  expect(await s.getState().roll('k6')).toBe(false);
  finish();
  expect(await rolling).toBe(true);
  expect(await closing).toBe(true);
  expect(s.getState().history[0]?.context).toEqual(context);
});
it('retains corrupt history and blocks a roll until it can be read', async () => {
  const read = vi
    .fn()
    .mockRejectedValueOnce(Error('corrupt'))
    .mockResolvedValue([]);
  const write = vi.fn();
  const execute = vi.fn((input: string) => rollDice(input, () => 1));
  const s = createDiceStore({ read, write }, execute);
  expect(await s.getState().roll('k6')).toBe(false);
  expect(execute).not.toHaveBeenCalled();
  expect(write).not.toHaveBeenCalled();
  expect(await s.getState().roll('k6')).toBe(true);
});
it('limits the displayed history to 100 without changing previous results', async () => {
  const records: unknown[] = [];
  const s = createDiceStore(
    {
      read: async () => [],
      write: async (r) => {
        records.push(r);
      },
    },
    (input) => rollDice(input, () => 1),
  );
  for (let i = 0; i < 102; i++)
    expect(await s.getState().roll('k6')).toBe(true);
  expect(s.getState().history).toHaveLength(100);
  expect(records).toHaveLength(102);
  expect(new Set(s.getState().history.map((r) => r.id)).size).toBe(100);
});
it('offers a clickable roll only when the entire supplied formula is supported', () => {
  const onRoll = vi.fn();
  const html = renderToStaticMarkup(
    createElement(RollValue, {
      formula: '2k6+3',
      label: 'Obrażenia — nóż',
      onRoll,
      children: '2k6+3',
    }),
  );
  expect(html).toContain('<button');
  expect(html).toContain('Rzuć:');
  expect(onRoll).not.toHaveBeenCalled();
  const invalid = renderToStaticMarkup(
    createElement(RollValue, {
      formula: 'N/D',
      label: 'Test',
      onRoll,
      children: 'N/D',
    }),
  );
  expect(invalid).not.toContain('<button');
});

it('rolls a failure into the draft only, permits a manual override and applies exactly on explicit submit', async () => {
  const { createCombatStore } = await import('../src/stores/combatStore');
  const { instantiateEnemy } = await import('../src/domain/combat');
  const { SLOT_IDS } = await import('../src/domain/encounter');
  const { rollFailure } = await import('../src/services/failureDice');
  const actor = instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Maszyna Ż',
      category: 'machine',
      size: 'Duży',
      tt: 16,
      hpMax: 88,
      speeds: [],
      failureThreshold: 20,
    },
    0,
  );
  const save = vi.fn(async (c: { revision: number }) => c.revision + 1);
  const combat = createCombatStore(
    async () =>
      SLOT_IDS.map((encounterId) => ({
        encounterId,
        revision: 0,
        roundNumber: 2,
        currentTurnActorId: null,
        actors: encounterId === 4 ? [actor] : [],
      })),
    save,
  );
  await combat.getState().initialize();
  const before = structuredClone(combat.getState().drafts[4]!.value);
  const dice = createDiceStore(
    { read: async () => [], write: async () => {} },
    (input) => rollDice(input, () => 20),
  );
  combat.getState().openFailureForm(4, actor.id);
  await rollFailure(4, dice, combat);
  expect(combat.getState().failureForm!.fields.result).toBe('20');
  expect(dice.getState().history[0]?.context).toMatchObject({
    encounterId: 4,
    actorId: actor.id,
    label: 'Tabela awarii k20',
  });
  expect(combat.getState().drafts[4]!.value).toEqual(before);
  expect(save).not.toHaveBeenCalled();
  combat.getState().editFailureForm({ result: '6' });
  expect(combat.getState().drafts[4]!.value).toEqual(before);
  combat.getState().submitFailureForm();
  await combat.getState().flush(4);
  // Existing combat actions checkpoint the previous state before the effect.
  expect(save).toHaveBeenCalledTimes(2);
  expect(combat.getState().slots[3]!.actors[0]!.hpCurrent).toBe(38);
  expect(
    combat.getState().slots[3]!.actors[0]!.enemy!.machineFailures,
  ).toHaveLength(1);
});

it('blocks closing on an unsaved roll and exposes the retained result for exact retry', async () => {
  const { createCombatStore } = await import('../src/stores/combatStore');
  const { createEncounterStore } = await import('../src/stores/encounterStore');
  const { createBestiaryStore } = await import('../src/stores/bestiaryStore');
  const { prepareAppClose } = await import('../src/services/prepareAppClose');
  const { useNavigationStore } = await import('../src/stores/navigationStore');
  let fail = true;
  const execute = vi.fn((input) => rollDice(input, () => 4));
  const dice = createDiceStore(
    {
      read: async () => [],
      write: async () => {
        if (fail) throw Error('disk');
      },
    },
    execute,
  );
  await dice.getState().roll('k6');
  const pending = dice.getState().pending;
  const combat = createCombatStore(
    async () => [],
    async () => 1,
  );
  const encounters = createEncounterStore(
    async () => [],
    async () => '2026-09-12',
  );
  const bestiary = createBestiaryStore(
    async () => [],
    async () => 0,
  );
  useNavigationStore.getState().navigate('home');
  expect(await prepareAppClose(encounters, combat, bestiary, dice)).toBe(false);
  expect(useNavigationStore.getState().page).toBe('gm');
  expect(dice.getState().open).toBe(true);
  expect(dice.getState().pending).toEqual(pending);
  fail = false;
  expect(await prepareAppClose(encounters, combat, bestiary, dice)).toBe(true);
  expect(execute).toHaveBeenCalledTimes(1);
});

it('rolls mixed damage as one result, validates per-die bounds and retains legacy records', () => {
  const r = rollDice('2k8+2k6+4', (sides) => sides);
  expect(r.values).toEqual([8, 8, 6, 6]);
  expect(r.total).toBe(32);
  const record = {
    ...r,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    context: null,
  };
  expect(diceRollSchema.parse(record)).toEqual(record);
  expect(
    diceRollSchema.safeParse({ ...record, values: [8, 8, 8, 4] }).success,
  ).toBe(false);
  expect(
    diceRollSchema.safeParse({ ...record, groups: undefined }).success,
  ).toBe(false);
  expect(() => parseDiceFormula('99k8+2k6')).toThrow();
});

it('colors natural k20 results independently of positive or negative modifiers, including log entries', async () => {
  const { naturalRollClass } = await import('../src/domain/dicePresentation');
  const { RollLogMessage } =
    await import('../src/features/dice/RollLogMessage');
  for (const [face, modifier, tone] of [
    [20, -19, 'natural-twenty'],
    [20, 5, 'natural-twenty'],
    [1, 19, 'natural-one'],
    [1, -5, 'natural-one'],
    [15, 5, ''],
    [6, -5, ''],
  ] as const) {
    const roll = {
      ...rollDice(`k20${modifier >= 0 ? '+' : ''}${modifier}`, () => face),
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      context: null,
    };
    expect(naturalRollClass(roll)).toBe(tone);
    const html = renderToStaticMarkup(createElement(DiceResult, { roll }));
    expect(html).toContain(`<strong class="${tone}">${roll.total}</strong>`);
    const entry = {
      id: 1,
      encounterId: 1 as const,
      roundNumber: 1,
      actorId: null,
      eventType: 'dice_rolled' as const,
      message: `Wynik ${roll.total}`,
      payload: { before: null, after: roll },
      createdAt: roll.createdAt,
    };
    const log = renderToStaticMarkup(createElement(RollLogMessage, { entry }));
    expect(log).toContain(`class="${tone}"`);
  }
});
it('colors each k20 in multi-die rolls while keeping totals and other dice neutral', async () => {
  const { naturalDieClass, naturalRollClass } =
    await import('../src/domain/dicePresentation');
  const values = [20, 1];
  const roll = {
    ...rollDice('2k20+10', () => values.shift()!),
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    context: null,
  };
  expect(naturalRollClass(roll)).toBe('');
  const html = renderToStaticMarkup(createElement(DiceResult, { roll }));
  expect(html).toContain('<span class="natural-twenty">20</span>');
  expect(html).toContain('<span class="natural-one">1</span>');
  expect(naturalDieClass(6, 1)).toBe('');
  expect(naturalDieClass(100, 20)).toBe('');
});

it('doubles only dice once after the matching attack and retries identical critical damage', async () => {
  const { doubleDamageDice } = await import('../src/domain/dice');
  expect(doubleDamageDice('2k6+3')).toBe('4k6+3');
  expect(doubleDamageDice('2k8+2k6-4')).toBe('4k8+4k6-4');
  const attackId = crypto.randomUUID();
  let spent = false,
    fail = true;
  const write = vi.fn(async () => {
    if (fail) throw Error('disk');
    spent = true;
  });
  const execute = vi.fn((input: string) => rollDice(input, () => 3));
  const repo = {
    read: async () => [],
    write,
    criticalAttack: async () => (spent ? null : attackId),
  };
  const store = createDiceStore(repo, execute);
  const context = {
    encounterId: 1 as const,
    actorId: crypto.randomUUID(),
    actorName: 'Cyngiel',
    roundNumber: 1,
    label: 'Obrażenia — Szabla',
    purpose: 'damage' as const,
    sourceKey: 'szabla',
  };
  expect(await store.getState().roll('1k8+5', context)).toBe(false);
  expect(store.getState().pending?.formula).toBe('2k8+5');
  expect(store.getState().pending?.critical?.attackRollId).toBe(attackId);
  fail = false;
  expect(await store.getState().retry()).toBe(true);
  expect(execute).toHaveBeenCalledTimes(1);
  expect(await store.getState().roll('1k8+5', context)).toBe(true);
  expect(store.getState().history[0]?.formula).toBe('1k8+5');
  expect(store.getState().history[0]?.critical).toBeUndefined();
  const latest = store.getState().history[1]!;
  expect(
    diceRollSchema.safeParse({
      ...latest,
      critical: { ...latest.critical, originalFormula: '2k8+5' },
    }).success,
  ).toBe(false);
});

it('triples Thinboy critical dice once while keeping its damage modifier', async () => {
  let spent = false;
  const store = createDiceStore(
    {
      read: async () => [],
      write: async () => {
        spent = true;
      },
      criticalAttack: async () =>
        spent ? null : 'a426983d-36cc-4e4c-8a6a-000000000009',
    },
    (input) => rollDice(input, () => 2),
  );
  const context = {
    encounterId: 1 as const,
    actorId: crypto.randomUUID(),
    actorName: 'Thinboy',
    roundNumber: 1,
    label: 'Obrażenia — Atak ostrzami',
    purpose: 'damage' as const,
    sourceKey: 'ostrza',
    criticalMultiplier: 3 as const,
  };
  expect(await store.getState().roll('1k4+4', context)).toBe(true);
  expect(store.getState().history[0]?.formula).toBe('3k4+4');
  expect(store.getState().history[0]?.total).toBe(10);
  expect(await store.getState().roll('1k4+4', context)).toBe(true);
  expect(store.getState().history[0]?.formula).toBe('1k4+4');
});

it('persists standalone BG test identity without an encounter context', async () => {
  const write = vi.fn(async () => {});
  const store = createDiceStore({ read: async () => [], write }, (input) =>
    rollDice(input, () => 20),
  );
  const characterContext = {
    characterId: crypto.randomUUID(),
    name: 'Anna',
    label: 'Rzut Obronny — Siła',
  };
  expect(await store.getState().roll('1k20+4', null, characterContext)).toBe(
    true,
  );
  const result = store.getState().history[0]!;
  expect(result.total).toBe(24);
  expect(result.context).toBeNull();
  expect(result.characterContext).toEqual(characterContext);
  expect(diceRollSchema.parse(JSON.parse(JSON.stringify(result)))).toEqual(
    result,
  );
});
