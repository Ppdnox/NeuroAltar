import { expect, it } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { SLOT_IDS } from '../src/domain/encounter';
import { instantiateEnemy, type Combat } from '../src/domain/combat';
it('retains failed form, reveals correct slot, retries one application and reloads unchanged data', async () => {
  const a = instantiateEnemy(
    {
      id: crypto.randomUUID(),
      name: 'Żółw',
      category: 'machine',
      size: 'Duży',
      tt: 16,
      hpMax: 88,
      speeds: [],
      failureThreshold: 20,
    },
    0,
  );
  let disk: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: encounterId === 4 ? [a] : [],
  }));
  let fail = true;
  const load = async () => structuredClone(disk);
  const save = async (c: Combat) => {
    if (fail) throw new Error('Test awarii zapisu');
    const saved = { ...structuredClone(c), revision: c.revision + 1 };
    disk = disk.map((s) => (s.encounterId === c.encounterId ? saved : s));
    return saved.revision;
  };
  const store = createCombatStore(load, save);
  await store.getState().initialize();
  store.getState().openFailureForm(4, a.id);
  store
    .getState()
    .editFailureForm({ result: '21', note: 'Zażółć\nDwa wiersze' });
  store.getState().submitFailureForm();
  expect(await store.getState().prepareClose()).toBe(false);
  expect(store.getState().failureForm!.fields.result).toBe('21');
  expect(store.getState().selected[4]).toBe(a.id);
  store.getState().editFailureForm({ result: '6' });
  store.getState().submitFailureForm();
  expect(await store.getState().flush(4)).toBe(false);
  expect(disk[3]!.actors[0]!.hpCurrent).toBe(88);
  fail = false;
  expect(await store.getState().flush(4)).toBe(true);
  expect(disk[3]!.actors[0]!.hpCurrent).toBe(38);
  expect(disk[3]!.actors[0]!.enemy!.machineFailures).toHaveLength(1);
  const reopen = createCombatStore(load, save);
  await reopen.getState().initialize();
  expect(reopen.getState().slots).toEqual(disk);
  reopen.getState().resetEncounter(4);
  await reopen.getState().flush(4);
  expect(disk[3]!.actors[0]!.hpCurrent).toBe(88);
  expect(disk[3]!.actors[0]!.enemy!.machineFailures).toBeUndefined();
  expect(await reopen.getState().prepareClose()).toBe(true);
});
