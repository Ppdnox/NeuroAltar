import { feats } from '../src/domain/character/feats';
import { origins } from '../src/domain/character/catalog';
import { readFileSync } from 'node:fs';
import { it, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
import {
  newCharacter,
  type Character,
  type ClassId,
  type GameColor,
} from '../src/domain/character/model';
import {
  previewCondition,
  conditionView,
  initialCondition,
  restDuration,
} from '../src/domain/character/condition';
import { deriveResources } from '../src/domain/character/resources';
import type {
  ConditionAction,
  RestInput,
} from '../src/domain/character/conditionModel';
import { complete, fixture } from './helpers/character';
function character(cls: ClassId = 'brutal', level = 2): Character {
  const c = newCharacter();
  c.sheet = complete(fixture(cls, level));
  c.sheet.hpCurrent = 1;
  c.draft = null;
  return c;
}
const apply = (c: Character, a: ConditionAction) => ({
  ...c,
  condition: previewCondition(c, a, crypto.randomUUID()).state,
});
function start(c: Character, kind: 'short' | 'long' = 'short') {
  return apply(c, { type: 'restStart', kind, id: crypto.randomUUID() });
}
function rest(c: Character, values: Partial<RestInput> = {}): RestInput {
  return {
    type: 'restApply',
    sessionId: c.condition!.rest!.id,
    outcome: 'complete',
    elapsed: restDuration(c.sheet!.rulesContext.gameColor)[
      c.condition!.rest!.kind
    ],
    sleep: c.condition!.rest!.kind === 'long' ? 360 : 0,
    armored: false,
    consecutive: true,
    food: false,
    water: false,
    warm: false,
    exhaustionId: null,
    medicProficient: false,
    medicTools: false,
    healingSave: null,
    rolls6: [],
    rolls8: [],
    kolejkaLevel: 0,
    kolejkaRolls: [],
    ...values,
  };
}
it('creates every class pool only at its threshold and extends short refresh to long', () => {
  const checks: [ClassId, number, string, string][] = [
    ['brutal', 1, 'berserk', 'long'],
    ['brutal', 2, 'rage', 'long'],
    ['cwaniak', 1, 'motivation', 'short'],
    ['cwaniak', 2, 'heckle', 'short'],
    ['cwaniak', 5, 'insult', 'short'],
    ['spec', 2, 'brain', 'long'],
    ['spec', 3, 'production', 'short'],
    ['spec', 4, 'hands', 'short'],
    ['spec', 7, 'trajectory', 'long'],
    ['twardziel', 1, 'stamina', 'long'],
    ['twardziel', 2, 'surge', 'short'],
    ['twardziel', 3, 'toughness', 'long'],
    ['zlodziej', 2, 'cat', 'long'],
    ['zlodziej', 7, 'matrix', 'long'],
    ['zlodziej', 11, 'sapper', 'short'],
  ];
  for (const [cls, l, id, refresh] of checks) {
    expect(
      deriveResources(character(cls, l).sheet!).find((r) => r.id === id)
        ?.refresh,
    ).toBe(refresh);
    if (l > 1)
      expect(
        deriveResources(character(cls, l - 1).sheet!).some((r) => r.id === id),
      ).toBe(false);
  }
});
it('Saper once, short and long restore it; opening/deriving does nothing', () => {
  let c = character('zlodziej', 11);
  c = apply(c, {
    type: 'use',
    resourceId: 'sapper',
    amount: 1,
    healingRoll: null,
  });
  expect(() =>
    apply(c, {
      type: 'use',
      resourceId: 'sapper',
      amount: 1,
      healingRoll: null,
    }),
  ).toThrow();
  expect(conditionView(c).state.spent.sapper).toBe(1);
  for (const kind of ['short', 'long'] as const) {
    const x = start(c, kind);
    expect(apply(x, rest(x)).condition.spent.sapper).toBe(0);
  }
  expect(c.condition!.spent.sapper).toBe(1);
});
it('short healing adds CON per die, caps at effective maximum and preserves injuries/reductions', () => {
  let c = character();
  c.sheet!.baseScores.con = 14;
  c.condition = initialCondition(c);
  c.condition.injury = 2;
  c.condition.effects = [
    {
      id: crypto.randomUUID(),
      source: 'Radiacja',
      target: 'hpMax',
      amount: 2,
      refresh: 'manual',
    },
  ];
  c = start(c);
  const ctx = conditionView(c);
  expect(ctx.derived.modifiers.con).toBe(2);
  const out = apply(c, rest(c, { rolls8: [3, 5] }));
  expect(out.condition.hp).toBe(13);
  expect(out.condition.hitDiceSpent[8]).toBe(2);
  expect(out.condition.injury).toBe(2);
  expect(out.condition.effects).toEqual(c.condition!.effects);
  expect(() => apply(out, rest(c))).toThrow();
});
it('minimum one healing applies to sum, not each die; no roll is no healing', () => {
  let c = character();
  c.sheet!.baseScores.con = 1;
  c = start(c);
  expect(apply(c, rest(c, { rolls8: [1, 1] })).condition.hp).toBe(2);
  expect(apply(c, rest(c)).condition.hp).toBe(1);
  expect(() => apply(c, rest(c, { rolls8: [1, 1, 1] }))).toThrow();
});
it('Kolejka uses one correct-sized bonus per spent die', () => {
  const c = start(character());
  expect(() =>
    apply(c, rest(c, { rolls8: [2], kolejkaLevel: 2, kolejkaRolls: [5] })),
  ).toThrow();
  expect(
    apply(c, rest(c, { rolls8: [2], kolejkaLevel: 2, kolejkaRolls: [4] }))
      .condition.hp,
  ).toBe(11);
});
it('armor restores half of maximum per pool, floor, capped at spent; blocks injury/exhaustion', () => {
  let c = character('brutal', 6);
  c.condition = initialCondition(c);
  c.condition.hitDiceSpent[8] = 2;
  c.condition.injury = 2;
  c.condition.exhaustion = [
    {
      id: crypto.randomUUID(),
      cause: 'ordinary',
      source: 'Zmęczenie',
      level: 2,
    },
  ];
  c = start(c, 'long');
  const out = apply(
    c,
    rest(c, {
      armored: true,
      exhaustionId: c.condition!.exhaustion[0]!.id,
      medicProficient: true,
      medicTools: true,
    }),
  );
  expect(out.condition.hitDiceSpent[8]).toBe(0);
  expect(out.condition.injury).toBe(2);
  expect(out.condition.exhaustion[0]?.level).toBe(2);
});
it.each(['none', 'rust', 'mercury', 'steel', 'chrome'] as GameColor[])(
  'respects %s rest durations, interruption threshold and extra hour',
  (color) => {
    let c = character();
    c.sheet!.rulesContext.gameColor = color;
    c = start(c, 'long');
    const threshold = restDuration(color).short;
    const bad = apply(
      c,
      rest(c, { outcome: 'interrupt', elapsed: threshold - 1, sleep: 0 }),
    );
    expect(bad.condition.spent.berserk).toBeUndefined();
    const partial = apply(
      c,
      rest(c, { outcome: 'interrupt', elapsed: threshold, sleep: 0 }),
    );
    expect(partial.condition.rest?.interruptions).toBe(1);
    expect(() =>
      apply(partial, rest(partial, { elapsed: restDuration(color).long })),
    ).toThrow();
    expect(
      apply(partial, rest(partial, { elapsed: restDuration(color).long + 60 }))
        .condition.rest,
    ).toBeNull();
  },
);
it('disease block prevents HP, hit dice, injury and all class refresh; manual/ammo never refilled', () => {
  let c = character();
  c.condition = initialCondition(c);
  c.condition.spent.berserk = 2;
  c.condition.hitDiceSpent[8] = 2;
  c.condition.restBlocks = [
    { id: crypto.randomUUID(), source: 'Szczurza gorączka — nieudany RO' },
  ];
  c = start(c, 'long');
  const out = apply(c, rest(c));
  expect(out.condition.hp).toBe(1);
  expect(out.condition.hitDiceSpent[8]).toBe(2);
  expect(out.condition.spent.berserk).toBe(2);
});
it('long refresh includes short, preserves manual and encounter pools and source effects', () => {
  let c = character('twardziel', 3);
  const id = crypto.randomUUID();
  c = apply(c, {
    type: 'manual',
    entry: { id, label: 'Baterie', max: 3 },
    reason: 'Zapas',
  });
  c = apply(c, { type: 'use', resourceId: id, amount: 2, healingRoll: null });
  c = apply(c, {
    type: 'use',
    resourceId: 'surge',
    amount: 1,
    healingRoll: null,
  });
  c = apply(c, {
    type: 'effect',
    entry: {
      id: crypto.randomUUID(),
      source: 'Trwałe',
      target: 'hpMax',
      amount: 3,
      refresh: 'manual',
    },
  });
  c = start(c, 'long');
  const out = apply(c, rest(c));
  expect(out.condition.spent[id]).toBe(2);
  expect(out.condition.spent.surge).toBe(0);
  expect(out.condition.hp).toBe(conditionView(out).max);
  expect(out.condition.effects).toHaveLength(1);
});
it('healing requires three consecutive long rests, armor and Rust/Mercury block natural healing', () => {
  let c = character();
  c.condition = initialCondition(c);
  c.condition.injury = 2;
  for (let i = 0; i < 2; i++) {
    c = start(c, 'long');
    c = apply(c, rest(c));
  }
  c = start(c, 'long');
  expect(apply(c, rest(c, { healingSave: 15 })).condition.injury).toBe(1);
  const fail = apply(c, rest(c, { healingSave: 14 }));
  expect(fail.condition.injury).toBe(2);
  expect(fail.condition.longStreak).toBe(3);
});
it('Fuks identity, session idempotency, world time and full Mercury ban', () => {
  let c = character();
  c.sheet!.rulesContext.gameColor = 'chrome';
  c = apply(c, { type: 'session', id: 'Sesja 1' });
  expect(() => apply(c, { type: 'session', id: 'Sesja 1' })).toThrow();
  const token = {
    id: crypto.randomUUID(),
    source: 'Muzyk',
    kind: 'song' as const,
    expiresAt: 1440,
    session: null,
  };
  c = apply(c, { type: 'fuksGrant', entry: token });
  c = apply(c, { type: 'worldTime', minutes: 1440 });
  expect(c.condition!.fuks).toHaveLength(1);
  c.sheet!.rulesContext.gameColor = 'mercury';
  expect(() =>
    apply(c, { type: 'fuksUse', id: c.condition!.fuks[0]!.id }),
  ).toThrow();
  expect(() =>
    apply(c, {
      type: 'fuksGrant',
      entry: { ...token, id: crypto.randomUUID(), expiresAt: 2880 },
    }),
  ).toThrow();
});
it('old state lazily preserves HP; no health changes on derive, draft or lowered maximum', () => {
  const c = character();
  const old = JSON.stringify(c);
  conditionView(c);
  expect(JSON.stringify(c)).toBe(old);
  expect(conditionView(c).state.hp).toBe(1);
  expect(() =>
    previewCondition(
      { ...c, draft: c.sheet },
      { type: 'restStart', kind: 'short', id: crypto.randomUUID() },
      crypto.randomUUID(),
    ),
  ).toThrow();
});
it('native parity fixture uses concrete authorized transitions', () => {
  const cases: unknown[] = [];
  let c = character('twardziel', 6);
  for (const action of [
    { type: 'use', resourceId: 'stamina', amount: 1, healingRoll: 3 },
    {
      type: 'correct',
      hp: 5,
      injury: 2,
      hitDiceSpent: { 6: 0, 8: 2 },
      reason: 'Próba migracji',
    },
    { type: 'restStart', kind: 'long', id: crypto.randomUUID() },
  ] as ConditionAction[]) {
    const id = crypto.randomUUID(),
      p = previewCondition(c, action, id);
    cases.push({
      before: c,
      action,
      context: p.context,
      operationId: id,
      after: p.state,
    });
    c = { ...c, condition: p.state };
  }
  const action = rest(c, { armored: true }),
    id = crypto.randomUUID(),
    p = previewCondition(c, action, id);
  cases.push({
    before: c,
    action,
    context: p.context,
    operationId: id,
    after: p.state,
  });
  if (process.env.GENERATE_CONDITION_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-condition.json',
      JSON.stringify(cases, null, 2) + '\n',
    );
  expect(p.state.hitDiceSpent[8]).toBe(0);
});

it('restoring different hit-dice pools uses their separate maxima, not a combined rounded pool', () => {
  let c = character('brutal', 3);
  const other = fixture('cwaniak', 3).levels;
  c.sheet!.levels.push(...other);
  c.sheet = complete(c.sheet!);
  c.condition = initialCondition(c);
  c.condition.hitDiceSpent = { 6: 3, 8: 3 };
  c = start(c, 'long');
  const out = apply(c, rest(c, { armored: true }));
  expect(out.condition.hitDiceSpent).toEqual({ 6: 2, 8: 2 });
});
it('temporary reductions restore on long, permanent reductions remain, and multiple effects stop at score 1', () => {
  let c = character();
  for (const refresh of ['long', 'manual'] as const)
    c = apply(c, {
      type: 'effect',
      entry: {
        id: crypto.randomUUID(),
        source: refresh,
        target: 'con',
        amount: 20,
        refresh,
      },
    });
  expect(conditionView(c).derived.scores.con.value).toBe(1);
  c = start(c, 'long');
  const out = apply(c, rest(c));
  expect(out.condition.effects).toHaveLength(1);
  expect(out.condition.effects[0]!.refresh).toBe('manual');
});
it('warm rest removes only cold exhaustion; hunger needs food and other causes remain', () => {
  let c = character();
  c.condition = initialCondition(c);
  const cold = crypto.randomUUID(),
    hunger = crypto.randomUUID();
  c.condition.exhaustion = [
    { id: cold, cause: 'cold', source: 'Mróz', level: 2 },
    { id: hunger, cause: 'hunger', source: 'Głód', level: 1 },
  ];
  c = start(c, 'long');
  expect(() => apply(c, rest(c, { exhaustionId: hunger }))).toThrow();
  const out = apply(c, rest(c, { warm: true, exhaustionId: cold }));
  expect(out.condition.exhaustion.map((e) => e.id)).toEqual([hunger]);
  expect(
    apply(c, rest(c, { warm: true, food: true, exhaustionId: hunger }))
      .condition.exhaustion,
  ).toHaveLength(0);
});
it('injury four adds exhaustion once and a rest never removes an unrelated source', () => {
  let c = character();
  const correction: ConditionAction = {
    type: 'correct',
    hp: 1,
    injury: 4,
    hitDiceSpent: { 6: 0, 8: 0 },
    reason: 'Zranienie',
  };
  c = apply(c, correction);
  expect(c.condition!.exhaustion).toHaveLength(1);
  c = apply(c, correction);
  expect(c.condition!.exhaustion).toHaveLength(1);
});
it('a session ending expires only its token and cannot grant it twice', () => {
  let c = character();
  c.sheet!.rulesContext.gameColor = 'steel';
  c = apply(c, {
    type: 'fuksGrant',
    entry: {
      id: crypto.randomUUID(),
      kind: 'fant',
      source: 'Komiks',
      expiresAt: null,
      session: null,
    },
  });
  c = apply(c, { type: 'session', id: 'A' });
  expect(c.condition!.fuks).toHaveLength(2);
  c = apply(c, { type: 'sessionEnd' });
  expect(c.condition!.fuks).toHaveLength(1);
  expect(() => apply(c, { type: 'session', id: 'A' })).toThrow();
});
it('lowering class maximum does not restore spent uses and nonpositive stat pools never get an invented minimum', () => {
  let c = character('cwaniak', 4);
  c = apply(c, {
    type: 'use',
    resourceId: 'luck',
    amount: 1,
    healingRoll: null,
  });
  c.sheet!.levels = c.sheet!.levels.slice(0, 1);
  expect(conditionView(c).state.spent.luck).toBe(1);
  expect(() =>
    apply(c, { type: 'use', resourceId: 'luck', amount: 1, healingRoll: null }),
  ).toThrow();
  c.sheet!.baseScores.cha = 1;
  expect(
    conditionView(c).resources.find((r) => r.id === 'motivation')?.max,
  ).toBe(0);
});

it('native constants track the authoritative creation catalog', () => {
  const constants = {
    origins: Object.fromEntries(origins.map((o) => [o.id, o.abilities])),
    feats: Object.fromEntries(feats.map((f) => [f.id, f.increase])),
  };
  if (process.env.GENERATE_CONDITION_FIXTURES)
    writeFileSync(
      'src/data/character/condition-constants.v1.json',
      JSON.stringify(constants, null, 2) + '\n',
    );
  expect(
    JSON.parse(
      readFileSync('src/data/character/condition-constants.v1.json', 'utf8'),
    ),
  ).toEqual(constants);
});

it('exports native parity cases for every class, origin and color with temporary and permanent effects', () => {
  const cases: unknown[] = [];
  for (const cls of [
    'brutal',
    'cwaniak',
    'spec',
    'twardziel',
    'zlodziej',
    'zwiadowca',
  ] as ClassId[])
    for (const level of [1, 3, 6, 9, 12])
      for (const origin of origins) {
        const c = newCharacter();
        const sheet = fixture(cls, level);
        sheet.originId = origin.id;
        sheet.baseScores = {
          str: 15,
          dex: 14,
          con: 13,
          int: 12,
          wis: 10,
          cha: 8,
        };
        sheet.rulesContext.gameColor = (
          ['none', 'rust', 'mercury', 'steel', 'chrome'] as GameColor[]
        )[level % 5]!;
        sheet.levels.forEach(
          (l, i) =>
            (l.color = (
              ['none', 'rust', 'mercury', 'steel', 'chrome'] as GameColor[]
            )[i % 5]!),
        );
        c.sheet = complete(sheet);
        c.draft = null;
        c.condition = initialCondition(c);
        c.condition.effects = [
          {
            id: crypto.randomUUID(),
            source: 'Test KON',
            target: 'con',
            amount: 2,
            refresh: 'long',
          },
          {
            id: crypto.randomUUID(),
            source: 'Test limitu',
            target: 'hpMax',
            amount: 1,
            refresh: 'manual',
          },
        ];
        const action: ConditionAction = { type: 'worldTime', minutes: 1 };
        const operationId = crypto.randomUUID();
        const p = previewCondition(c, action, operationId);
        cases.push({
          before: c,
          action,
          context: p.context,
          operationId,
          after: p.state,
        });
      }
  if (process.env.GENERATE_CONDITION_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-condition-parity.json',
      JSON.stringify(cases) + '\n',
    );
  expect(cases.length).toBe(30 * origins.length);
});

it('rest advances game time, expires timed Fuks and does not count manual time twice', () => {
  let c = character();
  c.condition = initialCondition(c);
  c.condition.fuks.push({
    id: crypto.randomUUID(),
    kind: 'meal',
    source: 'Posiłek',
    expiresAt: 1440,
    session: null,
  });
  c = start(c, 'long');
  const elapsedManually = apply(c, { type: 'worldTime', minutes: 600 });
  const done = apply(elapsedManually, rest(elapsedManually));
  expect(done.condition.worldMinutes).toBe(1440);
  expect(done.condition.fuks).toHaveLength(0);
  const beyond = apply(c, { type: 'worldTime', minutes: 2000 });
  expect(apply(beyond, rest(beyond)).condition.worldMinutes).toBe(2000);
});
it('interrupted rest counts only its remaining time and old rest state still loads', () => {
  let c = start(character(), 'long');
  c = apply(c, rest(c, { outcome: 'interrupt', elapsed: 240, sleep: 0 }));
  expect(c.condition!.worldMinutes).toBe(240);
  c = apply(c, rest(c, { elapsed: 1500 }));
  expect(c.condition!.worldMinutes).toBe(1500);
  const old = start(character());
  delete old.condition!.rest!.startedAt;
  expect(apply(old, rest(old)).condition.worldMinutes).toBe(240);
});
