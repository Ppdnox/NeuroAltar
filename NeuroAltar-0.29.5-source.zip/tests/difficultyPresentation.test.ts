import { expect, it } from 'vitest';
import {
  formatDifficultyNumber,
  difficultyFromDrafts,
} from '../src/domain/difficulty';
it('formats at most two decimal places without changing band calculations', () => {
  expect(formatDifficultyNumber(123.4567)).toBe('123,46');
  expect(formatDifficultyNumber(16)).toBe('16');
  expect(formatDifficultyNumber(null)).toBe('N/D');
  const v = difficultyFromDrafts('10000', [
    { displayName: 'Konwojent', spText: '12599,6', enemy: {} },
  ]);
  expect(v.result!.label).toBe('Łatwa');
  expect(formatDifficultyNumber(v.result!.percent)).toBe('126');
  expect(v.result!.percent).toBeCloseTo(125.996);
});
it('returns separate live slot results and identifies invalid levels and the affected actor', () => {
  expect(
    difficultyFromDrafts('4 4', [
      { displayName: 'BG' },
      { displayName: 'Konwojent', spText: '20', enemy: {} },
    ]).result!.percent,
  ).toBe(250);
  expect(difficultyFromDrafts('6 7', []).result!.sd).toBe(13);
  expect(difficultyFromDrafts('0', []).error).toContain('Poziomy BG');
  expect(
    difficultyFromDrafts('4', [
      { displayName: 'Konwojent', spText: '2,', enemy: {} },
    ]).error,
  ).toContain('Konwojent — Aktualne SP');
  expect(
    difficultyFromDrafts('4', [
      { displayName: 'Konwojent', spText: '', enemy: {} },
    ]).result!.missingSP,
  ).toBe(1);
});
