import { expect, it } from 'vitest';
import batch from '../src/data/bestiary/machines.v1.json';
import {
  enemyTemplateSchema,
  parseEnemyTemplateDraft,
} from '../src/domain/enemy';
import { templateDraft, filterCatalog } from '../src/domain/bestiary';
import { calculateWeaponAttackProfile } from '../src/domain/item';
import { instantiateEnemy, resetEncounter } from '../src/domain/combat';
import { consumeCapability } from '../src/domain/capabilities';
import { toStatblockDraft, parseStatblockDraft } from '../src/domain/statblock';
import { validationIssues } from '../src/domain/validation';
const entries = batch.entries.map((e) => ({
  ...e,
  template: enemyTemplateSchema.parse(e.template),
}));
const get = (key: string) => entries.find((e) => e.key === key)!.template;
it('validates exactly eleven handbook types and roundtrips every editable field', () => {
  expect(new Set(entries.map((e) => e.template.id)).size).toBe(11);
  expect(entries.map((e) => e.key).sort()).toEqual([
    'biodroid',
    'gladiator',
    'juggernaut',
    'kidnaper',
    'kurczak',
    'lowca',
    'mobsprzet',
    'obronca',
    'pajak',
    'pulser',
    'spawacz',
  ]);
  for (const { template: t, source } of entries) {
    expect(source.pdfPage).toBe(source.printedPage + 2);
    expect(t.category).toBe('machine');
    expect(t.injuryTrack?.enabled).not.toBe(true);
    expect(parseEnemyTemplateDraft(templateDraft(t), t.id)).toMatchObject(t);
    expect(parseStatblockDraft(toStatblockDraft(t.statblock))).toEqual(
      t.statblock,
    );
  }
});
it('keeps all six random weapons and conditional movement in one Mobsprzet statblock', () => {
  const t = get('mobsprzet');
  expect(t.loadout!.items.map((e) => e.item.name)).toEqual([
    '1. Karabin',
    '2. Miotacz ognia',
    '3. Karabin (długa seria)',
    '4. Kurczaki',
    '5. Mina zbliżeniowa',
    '6. Broń chemiczna',
  ]);
  expect(
    t.statblock!.traits!.some((s) => s.includes('rzuć 1k6 i wybierz JEDNĄ')),
  ).toBe(true);
  expect(t.speeds.map((s) => s.meters)).toEqual([36, 12, 9, 6]);
  expect(t.loadout!.items[1]!.item.weaponProfile).toBeUndefined();
  expect(t.loadout!.items[1]!.item.description).toContain('ST 13');
  expect(t.capabilities!.abilities).toHaveLength(1);
  expect(get('spawacz').speeds).toContainEqual({
    mode: 'Lot (tylko SMART)',
    meters: 36,
  });
  expect(get('spawacz').capabilities!.abilities.map((a) => a.name)).toEqual([
    'Naprawianie',
    'Spawanie',
  ]);
  expect(get('spawacz').statblock!.subtype).toBe('Molocha lub Smarta');
});
it('matches printed attack totals and preserves source discrepancies without double PB', () => {
  const totals: Record<string, number[]> = {
    biodroid: [5, 6],
    juggernaut: [16, 6, 6],
    pajak: [5],
    kidnaper: [6, 6],
    lowca: [4, 4],
    gladiator: [9, 9],
    obronca: [9, 5],
    kurczak: [5],
    mobsprzet: [5, 5],
  };
  for (const [key, values] of Object.entries(totals)) {
    const t = get(key);
    expect(
      t
        .loadout!.items.filter((e) => e.item.weaponProfile)
        .map((e) => calculateWeaponAttackProfile(e, t.loadout!).attack),
    ).toEqual(values);
  }
  expect(
    get('juggernaut').loadout!.items[1]!.item.weaponProfile!.damageModes[0],
  ).toMatchObject({ average: 20, dice: '4k20' });
  expect(get('biodroid').sp).toBe(20);
  expect(
    get('biodroid').statblock!.traits!.some((s) => s.includes('+3 (12)')),
  ).toBe(true);
  for (const key of ['pajak', 'lowca', 'kurczak'])
    expect(get(key).failureThreshold).toBeNull();
  expect(get('juggernaut').statblock!.damageThreshold).toBe(15);
  expect(get('juggernaut').failureThreshold).toBe(40);
  expect(get('pajak').statblock!.abilityScores.cha).toBeNull();
  expect(get('pajak').statblock!.savingThrows.str).toBeNull();
});
it('keeps catalog, resources, descriptions and prepared state independent with initiative unset', () => {
  const t = get('pulser'),
    a = instantiateEnemy(t, 0),
    b = instantiateEnemy(t, 1);
  expect(a.initiativeValue).toBeNull();
  const used = consumeCapability(a, t.capabilities!.abilities[0]!.id);
  expect(used.enemy!.capabilities!.resources[0]!.currentValue).toBe(9);
  expect(b.enemy!.capabilities!.resources[0]!.currentValue).toBe(10);
  expect(used.hpCurrent).toBe(a.hpCurrent);
  used.enemy!.statblock!.traits!.push('MG: Żółć');
  expect(t.statblock!.traits).not.toContain('MG: Żółć');
  const reset = resetEncounter({
    encounterId: 1,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [used, b],
  });
  expect(reset.actors[0]!.enemy!.capabilities!.resources[0]!.currentValue).toBe(
    10,
  );
  expect(reset.actors[0]!.enemy!.statblock).toEqual(t.statblock);
  expect(get('juggernaut').capabilities!.legendaryMax).toBe(3);
  expect(t.capabilities!.resources[0]!.refreshRule).toBe('day');
  const mob = get('mobsprzet'),
    copy = instantiateEnemy(mob, 0);
  copy.enemy!.loadout!.items = copy.enemy!.loadout!.items.slice(0, 1);
  expect(mob.loadout!.items).toHaveLength(6);
  expect(copy.prepared!.enemy!.loadout!.items).toHaveLength(6);
});
it('searches passives, identifies exact error paths and retains absent/null/empty lists', () => {
  const catalog = entries.map((e) => ({ template: e.template, revision: 0 }));
  expect(
    filterCatalog(catalog, 'regeneracja', 'machine', '').map(
      (e) => e.template.name,
    ),
  ).toContain('Biodroid');
  const t = structuredClone(get('pulser')),
    d = templateDraft(t);
  d.statblock!.traits = 'x'.repeat(1001);
  try {
    parseEnemyTemplateDraft(d, t.id);
    expect.fail('accepted invalid');
  } catch (e) {
    expect(validationIssues(e).map((i) => i.path)).toContain(
      'statblock.traits.0',
    );
  }
  delete t.statblock!.traits;
  expect(
    parseStatblockDraft(toStatblockDraft(t.statblock)).traits,
  ).toBeUndefined();
  for (const traits of [null, []])
    expect(
      parseStatblockDraft(toStatblockDraft({ ...t.statblock!, traits })).traits,
    ).toEqual(traits);
});
