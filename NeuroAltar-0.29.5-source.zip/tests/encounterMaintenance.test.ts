import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { createCombatStore } from '../src/stores/combatStore';
import { createEncounterStore } from '../src/stores/encounterStore';
import { createEncounterMaintenanceStore } from '../src/stores/encounterMaintenanceStore';
import { SLOT_IDS, type Encounter } from '../src/domain/encounter';
import type { Combat } from '../src/domain/combat';
import { useParticipationStore } from '../src/stores/participationStore';
import { PARTICIPATION_RESET_REJECTION } from '../src/services/combat';

beforeEach(() => {
  vi.useFakeTimers();
  useParticipationStore.setState({ entries: [] });
});
afterEach(() => {
  useParticipationStore.setState({ entries: [] });
  vi.useRealTimers();
});
async function setup() {
  const date = '2026-09-10T00:00:00.000Z';
  const details: Encounter[] = SLOT_IDS.map((id) => ({
    id,
    name: `Most ${id}`,
    notes: 'Żółć\nDruga linia',
    partyLevels: [4, 5],
    roundNumber: 1,
    currentTurnActorId: null,
    createdAt: date,
    updatedAt: date,
  }));
  const values: Combat[] = SLOT_IDS.map((encounterId) => ({
    encounterId,
    revision: 0,
    roundNumber: 1,
    currentTurnActorId: null,
    actors: [],
  }));
  const saveDetails = vi.fn(async () => date);
  const saveCombat = vi.fn(async (value: Combat) => value.revision + 1);
  const encounters = createEncounterStore(
    async () => structuredClone(details),
    saveDetails,
  );
  const combat = createCombatStore(
    async () => structuredClone(values),
    saveCombat,
  );
  const clear = vi.fn(async (request: { revision: number }) => ({
    revision: request.revision + 1,
    updatedAt: date,
  }));
  const maintenance = createEncounterMaintenanceStore(
    encounters,
    combat,
    clear,
    async () => details,
    async () => values,
  );
  await Promise.all([
    encounters.getState().initialize(),
    combat.getState().initialize(),
  ]);
  return { encounters, combat, clear, maintenance, saveCombat, saveDetails };
}
it('drains pending combat and metadata before clearing, keeps slots and never resurrects data', async () => {
  const { encounters, combat, clear, maintenance, saveCombat, saveDetails } =
    await setup();
  combat.getState().addActor(1);
  encounters.getState().edit(1, { notes: 'Najnowsze\nZażółć' });
  const run = maintenance.getState().clear(1);
  expect(encounters.getState().closing).toBe(true);
  combat.getState().addActor(1);
  encounters.getState().edit(1, { notes: 'Nie wolno nadpisać' });
  await run;
  expect(clear).toHaveBeenCalledWith(
    expect.objectContaining({ notes: 'Najnowsze\nZażółć', revision: 1 }),
  );
  expect(clear.mock.invocationCallOrder[0]).toBeGreaterThan(
    saveCombat.mock.invocationCallOrder[0]!,
  );
  expect(clear.mock.invocationCallOrder[0]).toBeGreaterThan(
    saveDetails.mock.invocationCallOrder[0]!,
  );
  await vi.advanceTimersByTimeAsync(1000);
  expect(combat.getState().drafts[1]!.value.actors).toEqual([]);
  expect(encounters.getState().drafts[1]!.details).toEqual({
    name: 'Most 1',
    notes: '',
    partyLevelsText: '4\n5',
  });
  expect(encounters.getState().slots).toHaveLength(5);
  expect(encounters.getState().drafts[2]!.details.notes).toBe(
    'Żółć\nDruga linia',
  );
  expect(saveCombat).toHaveBeenCalledTimes(1);
  expect(saveDetails).toHaveBeenCalledTimes(1);
  expect(combat.getState().closing).toBe(false);
});
it('preserves drafts and locks edits after uncertain result; exact retry runs once', async () => {
  const { encounters, combat, clear, maintenance } = await setup();
  combat.getState().addActor(1);
  clear.mockRejectedValueOnce(new Error('Niepewna odpowiedź'));
  await maintenance.getState().clear(1);
  expect(maintenance.getState().error).toContain('Niepewna');
  expect(combat.getState().drafts[1]!.value.actors).toHaveLength(1);
  expect(await combat.getState().prepareClose()).toBe(false);
  expect(await encounters.getState().prepareClose()).toBe(false);
  const pending = clear.mock.calls[0];
  await maintenance.getState().retry();
  expect(clear.mock.calls[1]).toEqual(pending);
  expect(maintenance.getState().slotId).toBeNull();
});
it('blocks reset, prepare and clear with unfinished forms or invalid drafts', async () => {
  const { combat, encounters, clear, maintenance, saveCombat } = await setup();
  combat.getState().openEnemyForm(1);
  combat.getState().resetEncounter(1);
  combat.getState().prepareEncounter(1);
  await maintenance.getState().clear(1);
  expect(clear).not.toHaveBeenCalled();
  expect(saveCombat).not.toHaveBeenCalled();
  combat.setState({ enemyForm: null });
  encounters.getState().edit(1, { name: '' });
  await maintenance.getState().clear(1);
  expect(clear).not.toHaveBeenCalled();
  expect(encounters.getState().drafts[1]!.details.name).toBe('');
  expect(encounters.getState().closing).toBe(false);
});
it('reload resolves a conflict without overwriting another slot draft', async () => {
  const { combat, encounters, clear, maintenance } = await setup();
  encounters.getState().edit(2, { notes: 'Szkic drugiego' });
  clear.mockRejectedValueOnce(new Error('Konflikt'));
  await maintenance.getState().clear(1);
  await maintenance.getState().reload();
  expect(maintenance.getState().slotId).toBeNull();
  expect(combat.getState().closing).toBe(false);
  expect(encounters.getState().drafts[2]!.details.notes).toBe('Szkic drugiego');
});

it('blocks clear before locking for an active participation or unresolved effects', async () => {
  const { combat, encounters, clear, maintenance } = await setup();
  const participation = {
    id: crypto.randomUUID(),
    characterId: crypto.randomUUID(),
    actorId: crypto.randomUUID(),
    encounterId: 1,
    revision: 0,
    state: 'active' as const,
    budget: {
      action: 1,
      bonus: 1,
      reaction: 1,
      interaction: 1,
      attacks: 0,
      use: 0,
    },
    effects: [],
    usedRound: [],
    weapons: {},
    legacy: {},
  };
  for (const entry of [
    participation,
    {
      ...participation,
      state: 'ended' as const,
      effects: [
        {
          id: crypto.randomUUID(),
          label: 'Do rozliczenia',
          remaining: 1,
          phase: 'manual' as const,
          target: 'attack' as const,
          modifier: 1,
          mode: 'normal' as const,
        },
      ],
    },
  ]) {
    useParticipationStore.setState({ entries: [entry] });
    await maintenance.getState().clear(1);
    expect(clear).not.toHaveBeenCalled();
    expect(maintenance.getState()).toMatchObject({
      slotId: null,
      busy: false,
      error: PARTICIPATION_RESET_REJECTION,
    });
    expect(combat.getState().closing).toBe(false);
    expect(encounters.getState().closing).toBe(false);
    expect(combat.getState().drafts[1]!.error).toBe(
      PARTICIPATION_RESET_REJECTION,
    );
  }
});

it('unlocks a clear rejected before commit without losing data or retrying the stale request', async () => {
  const { combat, encounters, clear, maintenance } = await setup();
  combat.getState().addActor(1);
  encounters.getState().edit(1, { notes: 'Zachowaj te notatki' });
  clear.mockRejectedValueOnce(PARTICIPATION_RESET_REJECTION);
  await maintenance.getState().clear(1);
  expect(maintenance.getState()).toMatchObject({
    slotId: null,
    busy: false,
    error: PARTICIPATION_RESET_REJECTION,
  });
  expect(combat.getState().closing).toBe(false);
  expect(encounters.getState().closing).toBe(false);
  expect(combat.getState().drafts[1]!.value.actors).toHaveLength(1);
  expect(combat.getState().drafts[1]!.error).toBe(
    PARTICIPATION_RESET_REJECTION,
  );
  expect(encounters.getState().drafts[1]!.details.notes).toBe(
    'Zachowaj te notatki',
  );
  await maintenance.getState().retry();
  expect(clear).toHaveBeenCalledTimes(1);
  const actorId = combat.getState().drafts[1]!.value.actors[0]!.id;
  combat
    .getState()
    .editActor(1, actorId, { displayName: 'Można edytować dalej' });
  expect(await combat.getState().flush(1)).toBe(true);
  expect(combat.getState().slots[0]!.actors[0]!.displayName).toBe(
    'Można edytować dalej',
  );
});
