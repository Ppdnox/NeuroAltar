import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import ruleIcons from '../src/features/character/rule-icons.json';
import manifest from '../public/icons/fvtt-noe/manifest.json';

describe('bundled dedicated icons', () => {
  it('ships every attributed asset locally and preserves its upstream bytes', () => {
    for (const [path, expectedHash] of Object.entries(manifest.files)) {
      expect(path).toMatch(/^[a-zA-Z0-9_/-]+\.svg$/);
      const bytes = readFileSync(`public/icons/fvtt-noe/${path}`);
      expect(createHash('sha256').update(bytes).digest('hex'), path).toBe(
        expectedHash,
      );
      const svg = bytes.toString('utf8');
      expect(svg, path).not.toMatch(/<script|<foreignObject|\bon\w+=/i);
      expect(svg, path).not.toMatch(/(?:href|src)=["']https?:/i);
    }
  });

  it('has a local asset for every character rule mapping', () => {
    for (const path of Object.values(ruleIcons)) {
      expect(Object.hasOwn(manifest.files, path), path).toBe(true);
    }
  });
});
