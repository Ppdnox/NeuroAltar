import {
  initialCondition,
  conditionSheet,
} from '../src/domain/character/condition';
import { emptyDowntime } from '../src/domain/character/downtimeModel';
import { deriveCharacter } from '../src/domain/character/derive';
import { afterEach, expect, it, vi } from 'vitest';
import { createCharacterStore } from '../src/stores/characterStore';
import {
  newCharacter,
  characterJournal,
  type Character,
  type CharacterMutation,
} from '../src/domain/character/model';
import { useNavigationStore } from '../src/stores/navigationStore';
import { useParticipationStore } from '../src/stores/participationStore';
import type { Participation } from '../src/domain/character/participation';
import { fixture, complete } from './helpers/character';
afterEach(() => {
  vi.useRealTimers();
  useParticipationStore.setState({ entries: [] });
});
function repository() {
  const records = new Map<string, Character>();
  const operations = new Map<string, Character>();
  const save = vi.fn(async (m: CharacterMutation) => {
    const retry = operations.get(m.operationId);
    if (retry) return structuredClone(retry);
    const old = records.get(m.character.id);
    if ((old?.revision ?? null) !== m.expectedRevision)
      throw Error('Konflikt wersji karty.');
    const c = {
      ...structuredClone(m.character),
      revision: (m.expectedRevision ?? -1) + 1,
    };
    records.set(c.id, c);
    operations.set(m.operationId, c);
    return structuredClone(c);
  });
  return {
    records,
    operations,
    save,
    list: async () => [...records.values()].map((c) => structuredClone(c)),
  };
}
function activeParticipation(characterId: string): Participation {
  return {
    id: crypto.randomUUID(),
    characterId,
    encounterId: 1,
    actorId: crypto.randomUUID(),
    revision: 1,
    state: 'active',
    budget: {
      use: 0,
      attacks: 1,
      action: 1,
      bonus: 1,
      reaction: 1,
      interaction: 1,
    },
    effects: [],
    usedRound: [],
    weapons: {},
    legacy: null,
  };
}
it.each(['publish', 'archive'] as const)(
  'saves the draft but does not lock participation when active combat blocks %s',
  async (kind) => {
    vi.useFakeTimers();
    const repo = repository(),
      store = createCharacterStore(repo);
    await store.getState().initialize();
    await store.getState().create();
    store.getState().update(complete(fixture()));
    expect(await store.getState().publish()).toBe(true);
    const original = structuredClone(store.getState().records[0]!);
    store.getState().edit();
    store
      .getState()
      .update({ ...original.sheet!, notes: 'Rozwój zapisany podczas walki' });
    const p = activeParticipation(original.id);
    useParticipationStore.setState({ entries: [p] });
    repo.save.mockClear();
    expect(
      await (kind === 'publish'
        ? store.getState().publish()
        : store.getState().archive(true)),
    ).toBe(false);
    expect(store.getState().locked).toBe(false);
    expect(repo.save.mock.calls.map(([m]) => m.kind)).toEqual(['draft']);
    const saved = repo.records.get(original.id)!;
    expect(saved.sheet).toEqual(original.sheet);
    expect(saved.draft?.notes).toBe('Rozwój zapisany podczas walki');
    expect(saved.archived).toBe(false);
    expect(await store.getState().prepareClose()).toBe(true);
    expect(repo.save).toHaveBeenCalledTimes(1);
    useParticipationStore.setState({ entries: [{ ...p, state: 'ended' }] });
    expect(await store.getState().publish()).toBe(true);
    const published = repo.records.get(original.id)!;
    expect(published.sheet?.notes).toBe(saved.draft?.notes);
    expect(published.inventory).toEqual(original.inventory);
    expect(published.condition).toEqual(original.condition);
    expect(published.draft).toBeNull();
  },
);
it.each(['publish', 'archive'] as const)(
  'releases an uncommitted %s rejected by the backend when the participation cache is stale',
  async (kind) => {
    vi.useFakeTimers();
    const repo = repository(),
      store = createCharacterStore(repo);
    await store.getState().initialize();
    await store.getState().create();
    store.getState().update(complete(fixture()));
    await store.getState().publish();
    store.getState().edit();
    const c = store.getState().records[0]!;
    store.getState().update({ ...c.draft!, notes: 'Nie zgub szkicu' });
    await store.getState().flush();
    const saved = structuredClone(repo.records.get(c.id));
    repo.save.mockClear();
    // Tauri rejects with a string; an Error object is also supported.
    repo.save.mockRejectedValueOnce(
      kind === 'publish'
        ? 'Najpierw zakończ aktywny udział tej postaci w walce.'
        : Error('Najpierw zakończ aktywny udział tej postaci w walce.'),
    );
    expect(
      await (kind === 'publish'
        ? store.getState().publish()
        : store.getState().archive(true)),
    ).toBe(false);
    expect(store.getState().locked).toBe(false);
    expect(store.getState().error).toContain('Szkic jest zapisany');
    expect(repo.records.get(c.id)).toEqual(saved);
    expect(store.getState().records[0]).toEqual(saved);
    expect(await store.getState().flush()).toBe(true);
    expect(await store.getState().prepareClose()).toBe(true);
    expect(repo.save).toHaveBeenCalledTimes(1);
    // After the participation ends, explicit publication is a new operation.
    expect(await store.getState().publish()).toBe(true);
    expect(repo.save.mock.calls[1]![0].operationId).not.toBe(
      repo.save.mock.calls[0]![0].operationId,
    );
    expect(repo.records.get(c.id)?.sheet?.notes).toBe('Nie zgub szkicu');
  },
);
it('retains exact publication retries for an ambiguous lost response', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().flush();
  const save = repo.save.getMockImplementation()!;
  let lose = true;
  repo.save.mockImplementation(async (m) => {
    const saved = await save(m);
    if (m.kind === 'publish' && lose) {
      lose = false;
      throw Error('Utrata odpowiedzi');
    }
    return saved;
  });
  expect(await store.getState().publish()).toBe(false);
  const failed = repo.save.mock.calls.at(-1)![0];
  expect(store.getState().locked).toBe(true);
  expect(await store.getState().flush()).toBe(true);
  expect(repo.save.mock.calls.at(-1)![0]).toEqual(failed);
  expect(store.getState().locked).toBe(false);
  expect(store.getState().records[0]?.draft).toBeNull();
});
it('persists an incomplete draft through close and restart, without a finished sheet', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  const c = store.getState().records[0]!;
  store.getState().update({
    ...c.draft!,
    identity: { ...c.draft!.identity, name: 'Żółty szlak' },
  });
  expect(await store.getState().prepareClose()).toBe(true);
  expect(repo.records.get(c.id)?.sheet).toBeNull();
  const restarted = createCharacterStore(repo);
  await restarted.getState().initialize();
  expect(restarted.getState().records[0]?.draft?.identity.name).toBe(
    'Żółty szlak',
  );
});
it('publishes all choices atomically, preserves canonical data while editing and does not heal', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  expect(await store.getState().publish()).toBe(true);
  const c = store.getState().records[0]!;
  expect(c.draft).toBeNull();
  expect(c.sheet?.hpCurrent).not.toBeNull();
  store.getState().edit();
  store
    .getState()
    .update({ ...store.getState().records[0]!.draft!, hpCurrent: 5 });
  expect(await store.getState().publish()).toBe(true);
  store.getState().edit();
  const draft = store.getState().records[0]!.draft!;
  store
    .getState()
    .update({ ...draft, baseScores: { ...draft.baseScores, con: 16 } });
  await store.getState().flush();
  expect(repo.records.get(c.id)?.sheet?.baseScores.con).toBe(18);
  expect(await store.getState().publish()).toBe(true);
  expect(repo.records.get(c.id)?.sheet?.baseScores.con).toBe(16);
  expect(repo.records.get(c.id)?.draft).toBeNull();
  expect(repo.save.mock.calls.at(-1)?.[0].correctionReason).toBeUndefined();
  expect(repo.records.get(c.id)?.sheet?.hpCurrent).toBe(5);
});
it('retries the exact lost response before saving newer edits', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    save = repo.save;
  let lost = true;
  const store = createCharacterStore({
    ...repo,
    save: async (m) => {
      const c = await save(m);
      if (lost) {
        lost = false;
        throw Error('Utrata odpowiedzi');
      }
      return c;
    },
  });
  await store.getState().initialize();
  await store.getState().create();
  const first = save.mock.calls[0]![0];
  const c = store.getState().records[0]!;
  store.getState().update({ ...c.draft!, notes: 'Nowszy szkic' });
  expect(await store.getState().flush()).toBe(true);
  expect(save.mock.calls[1]![0]).toEqual(first);
  expect(repo.operations.size).toBe(2);
  expect(repo.records.get(c.id)?.draft?.notes).toBe('Nowszy szkic');
});
it('retains edits made while a save is in flight', async () => {
  vi.useFakeTimers();
  const repo = repository();
  const store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  const c = store.getState().records[0]!;
  let done!: (c: Character) => void;
  const realSave = repo.save.getMockImplementation()!;
  repo.save.mockImplementationOnce(
    (m) =>
      new Promise((r) => {
        done = () => {
          void realSave(m).then(r);
        };
      }),
  );
  store.getState().update({ ...c.draft!, notes: 'Pierwszy' });
  const flight = store.getState().flush();
  await Promise.resolve();
  store.getState().update({ ...c.draft!, notes: 'Drugi' });
  done(c);
  await flight;
  expect(repo.records.get(c.id)?.draft?.notes).toBe('Drugi');
});
it('blocks closing for invalid numeric text, then clears the block after correction', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  const id = store.getState().selectedId!;
  store.getState().invalidInput(id + ':ability-str', 'abc');
  useNavigationStore.getState().navigate('gm');
  expect(await store.getState().prepareClose()).toBe(false);
  expect(useNavigationStore.getState().page).toBe('character');
  expect(store.getState().invalid[id + ':ability-str']).toBe('abc');
  store.getState().invalidInput(id + ':ability-str', null);
  expect(await store.getState().prepareClose()).toBe(true);
});
it('keeps the local draft on a conflict until explicit comparison and rebase', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    c = newCharacter();
  repo.records.set(c.id, c);
  const store = createCharacterStore(repo);
  await store.getState().initialize();
  repo.records.set(c.id, {
    ...c,
    revision: 1,
    draft: { ...c.draft!, notes: 'Zdalna zmiana' },
  });
  store.getState().update({ ...c.draft!, notes: 'Moja zmiana' });
  expect(await store.getState().flush()).toBe(false);
  expect(repo.records.get(c.id)?.draft?.notes).toBe('Zdalna zmiana');
  await store.getState().compareConflict();
  expect(store.getState().conflict?.revision).toBe(1);
  store.getState().acceptRebase();
  expect(await store.getState().flush()).toBe(true);
  expect(repo.records.get(c.id)?.draft?.notes).toBe('Moja zmiana');
});
it('discards an editing draft without altering the published card and archives without deletion', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  const before = structuredClone(store.getState().records[0]!.sheet);
  store.getState().edit();
  store.getState().update({ ...before!, notes: 'Odrzuć' });
  await store.getState().discard();
  expect(store.getState().records[0]!.sheet).toEqual(before);
  expect(store.getState().records[0]!.draft).toBeNull();
  expect(await store.getState().archive(true)).toBe(true);
  expect(repo.records.size).toBe(1);
  expect(store.getState().records[0]!.archived).toBe(true);
});

it('retries an inventory write exactly and discarding advancement never rewinds the inventory', async () => {
  vi.useFakeTimers();
  const repo = repository();
  let lose = false;
  const store = createCharacterStore({
    ...repo,
    save: async (m) => {
      const saved = await repo.save(m);
      if (lose) {
        lose = false;
        throw Error('Utrata odpowiedzi');
      }
      return saved;
    },
  });
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  const { starterPack } =
    await import('../src/domain/character/inventoryCatalog');
  const pack = starterPack('brutal');
  lose = true;
  expect(
    await store.getState().mutateInventory({
      kind: 'starter',
      key: 'initial-equipment',
      entries: [pack],
    }),
  ).toBe(false);
  const failed = repo.save.mock.calls.at(-1)![0];
  expect(store.getState().locked).toBe(true);
  expect(await store.getState().flush()).toBe(true);
  expect(repo.save.mock.calls.at(-1)![0]).toEqual(failed);
  store.getState().edit();
  store.getState().update({
    ...store.getState().records[0]!.draft!,
    notes: 'Szkic do odrzucenia',
  });
  await store.getState().discard();
  expect(store.getState().records[0]!.inventory?.entries).toEqual([pack]);
  const reopened = createCharacterStore(repo);
  await reopened.getState().initialize();
  expect(reopened.getState().records[0]!.inventory?.starterClaims).toEqual([
    'initial-equipment',
  ]);
  reopened
    .getState()
    .invalidInput(
      reopened.getState().selectedId + ':inventory-dialog',
      'Edytowany przedmiot',
    );
  expect(await reopened.getState().prepareClose()).toBe(false);
});

it('condition commands preserve exact retry, close guard and health on development discard', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture('brutal', 2)));
  await store.getState().publish();
  let c = store.getState().records[0]!;
  repo.save.mockRejectedValueOnce(Error('Próba awarii'));
  const action = {
    type: 'use' as const,
    resourceId: 'berserk',
    amount: 1,
    healingRoll: null,
  };
  expect(await store.getState().mutateCondition(action, c.revision)).toBe(
    false,
  );
  const failed = repo.save.mock.calls.at(-1)![0];
  expect(store.getState().locked).toBe(true);
  expect(await store.getState().flush()).toBe(true);
  expect(repo.save.mock.calls.at(-1)![0]).toEqual(failed);
  c = store.getState().records[0]!;
  expect(c.condition!.spent.berserk).toBe(1);
  store.getState().edit();
  store
    .getState()
    .update({ ...store.getState().records[0]!.draft!, notes: 'Szkic' });
  await store.getState().discard();
  expect(store.getState().records[0]!.condition!.spent.berserk).toBe(1);
  store
    .getState()
    .invalidInput(c.id + ':condition-dialog', 'Niedokończony odpoczynek');
  expect(await store.getState().prepareClose()).toBe(false);
  store.getState().invalidInput(c.id + ':condition-dialog', null);
  expect(await store.getState().prepareClose()).toBe(true);
});
it('stale condition preview and conflict cannot overwrite newer health with a development draft', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  const c = store.getState().records[0]!,
    a = {
      type: 'restStart' as const,
      id: crypto.randomUUID(),
      kind: 'short' as const,
    };
  expect(await store.getState().mutateCondition(a, c.revision - 1)).toBe(false);
  repo.records.set(c.id, { ...c, revision: c.revision + 1 });
  expect(await store.getState().mutateCondition(a, c.revision)).toBe(false);
  await store.getState().compareConflict();
  expect(store.getState().conflictIsInventory).toBe(true);
  store.getState().acceptRebase();
  expect(store.getState().records[0]!.draft).toBeNull();
  expect(store.getState().dirty).toEqual([]);
  expect(store.getState().records[0]!.revision).toBe(c.revision + 1);
});

it('publishes advancement unlocked by completed training without copying runtime effects into the sheet', async () => {
  const repo = repository(),
    c = newCharacter();
  c.sheet = complete(fixture('brutal', 3));
  c.condition = initialCondition(c);
  c.condition.downtime = emptyDowntime();
  c.condition.downtime.training.push({
    id: crypto.randomUUID(),
    target: 'skill:medicine',
    minutes: 18000,
    completed: true,
    afterLevel: 3,
  });
  c.draft = complete({
    ...structuredClone(c.sheet),
    levels: [
      ...structuredClone(c.sheet.levels),
      { classId: 'brutal', color: 'none', contextRevision: 0, choices: {} },
    ],
  });
  c.draft.levels[3]!.choices.feat = ['immunity'];
  for (const choice of deriveCharacter(conditionSheet(c.draft, c.condition))
    .choices) {
    if (choice.level === 3 && choice.key !== 'feat')
      c.draft.levels[3]!.choices[choice.key] = choice.options
        .slice(0, choice.count)
        .map((x) => x.id);
  }
  expect(
    deriveCharacter(conditionSheet(c.draft, c.condition)).issues,
  ).toHaveLength(0);
  repo.records.set(c.id, c);
  const store = createCharacterStore(repo);
  await store.getState().initialize();
  expect(await store.getState().publish()).toBe(true);
  const saved = repo.records.get(c.id)!;
  expect(saved.sheet!.levels[3]!.choices.feat).toEqual(['immunity']);
  expect(saved.condition!.downtime!.training).toHaveLength(1);
  expect(saved.sheet).not.toHaveProperty('learned');
});

it('publishes a level advance with XP and no explanation', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  expect(await store.getState().publish()).toBe(true);
  store.getState().edit();
  const next = complete(fixture('brutal', 2));
  next.advancementMode = 'xp';
  next.xp = [{ id: crypto.randomUUID(), amount: 50, reason: '' }];
  store.getState().update(next);
  expect(await store.getState().publish()).toBe(true);
  const saved = store.getState().records[0]!;
  expect(saved.sheet?.levels).toHaveLength(2);
  expect(saved.sheet?.xp[0]?.reason).toBe('');
  expect(saved.draft).toBeNull();
});

it('autosaves journal during combat without opening or publishing a development draft', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  const before = structuredClone(store.getState().records[0]!);
  useParticipationStore.setState({ entries: [activeParticipation(before.id)] });
  store.getState().updateJournal('notes', 'Wskazówka z sesji');
  store.getState().updateJournal('contacts', 'Iwan');
  await store.getState().flush();
  const saved = repo.records.get(before.id)!;
  expect(saved.sheet).toEqual(before.sheet);
  expect(saved.draft).toBeNull();
  expect(saved.inventory).toEqual(before.inventory);
  expect(saved.condition).toEqual(before.condition);
  expect(characterJournal(saved)).toMatchObject({
    notes: 'Wskazówka z sesji',
    contacts: 'Iwan',
  });
  const reopened = createCharacterStore(repo);
  await reopened.getState().initialize();
  expect(characterJournal(reopened.getState().records[0]!)).toEqual(
    characterJournal(saved),
  );
});

it('keeps journal outside an unfinished or discarded draft, including incomplete numeric input', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  store.getState().edit();
  const c = store.getState().records[0]!;
  store.getState().update({
    ...c.draft!,
    identity: { ...c.draft!.identity, name: 'Niedokończona edycja' },
  });
  store.getState().invalidInput(c.id + ':ability-str', 'x');
  store.getState().updateJournal('discoveries', 'Tunel pod stacją');
  expect(await store.getState().flush()).toBe(true);
  expect(repo.records.get(c.id)?.sheet?.identity.name).toBe(
    c.sheet!.identity.name,
  );
  expect(await store.getState().discard()).toBe(true);
  expect(characterJournal(store.getState().records[0]!).discoveries).toBe(
    'Tunel pod stacją',
  );
});

it('rebases notes without manufacturing a development draft', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  store.getState().update(complete(fixture()));
  await store.getState().publish();
  const c = structuredClone(store.getState().records[0]!);
  repo.records.set(c.id, { ...c, revision: c.revision + 1 });
  store.getState().updateJournal('notes', 'Mój wpis');
  expect(await store.getState().flush()).toBe(false);
  await store.getState().compareConflict();
  store.getState().acceptRebase();
  expect(await store.getState().flush()).toBe(true);
  expect(repo.records.get(c.id)?.draft).toBeNull();
  expect(repo.records.get(c.id)?.sheet).toEqual(c.sheet);
  expect(repo.records.get(c.id)?.journal?.notes).toBe('Mój wpis');
});

it('retains newer journal input while an earlier autosave is in flight', async () => {
  vi.useFakeTimers();
  const repo = repository(),
    store = createCharacterStore(repo);
  await store.getState().initialize();
  await store.getState().create();
  const save = repo.save.getMockImplementation()!;
  let release!: () => void;
  repo.save.mockImplementationOnce(async (m) => {
    await new Promise<void>((resolve) => {
      release = resolve;
    });
    return save(m);
  });
  store.getState().updateJournal('notes', 'A');
  const flight = store.getState().flush();
  await Promise.resolve();
  store.getState().updateJournal('notes', 'AB');
  release();
  expect(await flight).toBe(true);
  expect(repo.records.get(store.getState().selectedId!)?.journal?.notes).toBe(
    'AB',
  );
  expect(store.getState().dirty).toEqual([]);
});
