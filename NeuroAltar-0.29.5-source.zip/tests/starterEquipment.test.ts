import { describe, expect, it } from 'vitest';
import catalog from '../src/data/equipment/catalog.v1.json';
import { itemSchema } from '../src/domain/item';
import { emptyInventory } from '../src/domain/character/inventoryModel';
import { starterPack } from '../src/domain/character/inventoryCatalog';
import {
  applyInventoryAction,
  validateInventory,
} from '../src/domain/character/inventory';
import {
  starterComplete,
  starterEquipmentAction,
  starterOptions,
  starterRules,
} from '../src/domain/character/starterEquipment';
import type { ClassId } from '../src/domain/character/model';
const items = catalog.entries.map((i) => itemSchema.parse(i));
const byName = (name: string) => items.find((i) => i.name === name)!;
const selected = (id: ClassId) =>
  id === 'cwaniak'
    ? byName('Akordeon').id
    : id === 'spec'
      ? byName('Mały chemik').id
      : '';
const make = (
  id: ClassId,
  choice: 'equipment' | 'gamble',
  inv = emptyInventory(),
) =>
  starterEquipmentAction(
    inv,
    items,
    id,
    choice,
    selected(id),
    byName('Zapalniczka plastikowa').id,
  );
describe('handbook starting equipment', () => {
  for (const id of Object.keys(starterRules) as ClassId[]) {
    for (const choice of ['equipment', 'gamble'] as const) {
      it(`${id}: ${choice} is valid, granted once, and excludes the other choice`, () => {
        const action = make(id, choice);
        const first = applyInventoryAction(emptyInventory(), action, 'none');
        expect(validateInventory(first)).toEqual(first);
        expect(starterComplete(first)).toBe(true);
        expect(
          first.entries.filter((e) => e.massMode === 'aggregate'),
        ).toHaveLength(1);
        expect(new Set(first.entries.map((e) => e.id)).size).toBe(
          first.entries.length,
        );
        expect(first.starterClaims).toEqual([
          'initial-equipment',
          `initial-loadout:${choice}`,
        ]);
        expect(() => applyInventoryAction(first, action, 'none')).toThrow();
        expect(() =>
          applyInventoryAction(
            first,
            make(id, choice === 'equipment' ? 'gamble' : 'equipment'),
            'none',
          ),
        ).toThrow();
        expect(() =>
          applyInventoryAction(
            first,
            {
              kind: 'starter',
              key: 'initial-equipment',
              entries: [starterPack(id)],
            },
            'none',
          ),
        ).toThrow();
      });
    }
  }
  it('keeps tools and instrument with starting gambles; does not grant optional equipment or a wallet item', () => {
    expect(make('spec', 'gamble').entries.map((e) => e.item.name)).toEqual([
      'Zestaw startowy — Plecak naukowca',
      'Mały chemik',
    ]);
    expect(make('cwaniak', 'gamble').entries.map((e) => e.item.name)).toEqual([
      'Zestaw startowy — Plecak oszusta',
      'Akordeon',
    ]);
    expect(
      make('zlodziej', 'gamble').entries.map((e) => e.item.name),
    ).toContain('Mały ślusarz');
    expect(
      make('zwiadowca', 'gamble').entries.map((e) => e.item.name),
    ).toContain('Mały kłusownik');
    expect(make('brutal', 'gamble').entries).toHaveLength(1);
    expect(Object.values(starterRules).map((r) => r.gamble)).toEqual([
      150, 150, 170, 200, 150, 150,
    ]);
  });
  it('gives the exact cartridge quantities and separate instances for multiple weapons', () => {
    for (const [id, ammo, count] of [
      ['brutal', '.12 Ga (b - breneka)', 10],
      ['cwaniak', '.38 SPL', 12],
      ['spec', '9 mm', 15],
      ['twardziel', '9 mm', 30],
      ['zlodziej', 'Strzała', 20],
      ['zwiadowca', '.30-06', 10],
    ] as const) {
      expect(
        make(id, 'equipment').entries.find((e) => e.item.name === ammo)
          ?.quantityMilli,
      ).toBe(count * 1000);
    }
    expect(
      make('brutal', 'equipment').entries.filter(
        (e) => e.item.name === 'Oszczep',
      ),
    ).toHaveLength(3);
    expect(
      make('zlodziej', 'equipment').entries.filter(
        (e) => e.item.name === 'Nóż do rzucania',
      ),
    ).toHaveLength(2);
    expect(
      make('twardziel', 'equipment').entries.find(
        (e) => e.item.name === 'Rura stalowa',
      )?.weapon,
    ).not.toBeNull();
  });
  it('requires a valid explicit instrument/tool and lighter selection', () => {
    expect(starterOptions(items, 'cwaniak').map((i) => i.name)).not.toContain(
      'Gitara elektryczna',
    );
    expect(() =>
      starterEquipmentAction(
        emptyInventory(),
        items,
        'cwaniak',
        'gamble',
        byName('Gitara elektryczna').id,
      ),
    ).toThrow('50 G');
    expect(() =>
      starterEquipmentAction(
        emptyInventory(),
        items,
        'spec',
        'gamble',
        byName('Kafar').id,
      ),
    ).toThrow('narzędzi');
    expect(() =>
      starterEquipmentAction(
        emptyInventory(),
        items,
        'cwaniak',
        'equipment',
        byName('Akordeon').id,
      ),
    ).toThrow('zapalniczkę');
    expect(() =>
      starterEquipmentAction(
        emptyInventory(),
        items.filter((i) => i.name !== 'Kafar'),
        'brutal',
        'equipment',
      ),
    ).toThrow('Kafar');
  });
  it('completes an old backpack grant without duplicating it or overwriting existing items', () => {
    const old = applyInventoryAction(
      emptyInventory(),
      {
        kind: 'starter',
        key: 'initial-equipment',
        entries: [starterPack('spec')],
      },
      'none',
    );
    const action = make('spec', 'equipment', old);
    expect(action.entries.every((e) => e.massMode !== 'aggregate')).toBe(true);
    const next = applyInventoryAction(old, action, 'none');
    expect(next.entries[0]).toEqual(old.entries[0]);
    expect(next.entries.filter((e) => e.massMode === 'aggregate')).toHaveLength(
      1,
    );
    // A legacy character can mark manually received items as already granted.
    const claimed = applyInventoryAction(
      old,
      { ...action, entries: [] },
      'none',
    );
    expect(claimed.entries).toEqual(old.entries);
    expect(starterComplete(claimed)).toBe(true);
    expect(() =>
      applyInventoryAction(
        emptyInventory(),
        { ...action, entries: [] },
        'none',
      ),
    ).toThrow();
    expect(() =>
      applyInventoryAction(old, { ...action, key: 'unknown' }, 'none'),
    ).toThrow();
  });
});
