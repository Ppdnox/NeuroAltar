import { it, expect } from 'vitest';
import { writeFileSync } from 'node:fs';
import { complete, fixture } from './helpers/character';
import { newCharacter, type Character } from '../src/domain/character/model';
import {
  initialCondition,
  previewCondition,
} from '../src/domain/character/condition';
import { checkContext } from '../src/domain/character/participation';
import { applyCombatHealth } from '../src/domain/character/combatHealth';
import { inventoryFixture } from './helpers/inventory';
import { applyInventoryAction } from '../src/domain/character/inventory';
import type { ConditionAction } from '../src/domain/character/conditionModel';
import type {
  Inventory,
  InventoryAction,
} from '../src/domain/character/inventoryModel';
const character = () => {
  const c = newCharacter();
  c.sheet = complete(fixture());
  c.draft = null;
  c.sheet.hpCurrent = 20;
  c.sheet.rulesContext.gameColor = 'rust';
  c.condition = initialCondition(c);
  return c;
};
it('counts simultaneous injury triggers once and bleeding once, with no passive HP mutations', () => {
  const c = character(),
    s = c.condition!;
  applyCombatHealth(
    s,
    { kind: 'damage', amount: 20, critical: true, melee: false },
    30,
    18,
    'rust',
    crypto.randomUUID(),
  );
  expect(s.hp).toBe(0);
  expect(s.injury).toBe(1);
  expect(s.combatHealth?.bleeding).toBe(true);
  s.hp = 20;
  applyCombatHealth(
    s,
    { kind: 'damage', amount: 1, critical: true, melee: false },
    30,
    18,
    'rust',
    crypto.randomUUID(),
  );
  expect(s.injury).toBe(2);
  expect(s.hp).toBe(19);
  applyCombatHealth(s, { kind: 'bleed' }, 30, 18, 'rust', crypto.randomUUID());
  expect(s.hp).toBe(18);
  applyCombatHealth(
    s,
    { kind: 'stopBleeding' },
    30,
    18,
    'rust',
    crypto.randomUUID(),
  );
  expect(() =>
    applyCombatHealth(
      s,
      { kind: 'bleed' },
      30,
      18,
      'rust',
      crypto.randomUUID(),
    ),
  ).toThrow();
});
it('death saves use only the natural die, stabilize on three successes and natural20 restores one HP', () => {
  const s = character().condition!;
  s.hp = 0;
  applyCombatHealth(
    s,
    { kind: 'deathSave', face: 1 },
    30,
    18,
    'none',
    crypto.randomUUID(),
  );
  expect(s.combatHealth?.failures).toBe(2);
  applyCombatHealth(
    s,
    { kind: 'deathSave', face: 20 },
    30,
    18,
    'none',
    crypto.randomUUID(),
  );
  expect(s.hp).toBe(1);
  expect(s.combatHealth?.failures).toBe(0);
  s.hp = 0;
  for (let i = 0; i < 3; i++)
    applyCombatHealth(
      s,
      { kind: 'deathSave', face: 10 },
      30,
      18,
      'none',
      crypto.randomUUID(),
    );
  expect(s.combatHealth?.stable).toBe(true);
  expect(() =>
    applyCombatHealth(
      s,
      { kind: 'deathSave', face: 20 },
      30,
      18,
      'none',
      crypto.randomUUID(),
    ),
  ).toThrow();
});
it('multiple advantages still cancel with one disadvantage and test modifiers never leak to damage', () => {
  const e = {
    id: crypto.randomUUID(),
    label: 'Efekt',
    remaining: 1,
    phase: 'manual' as const,
    target: 'all' as const,
    modifier: 3,
    mode: 'advantage' as const,
  };
  expect(checkContext([e, e], ['str'], false, true)).toEqual({
    modifier: 6,
    mode: 'normal',
  });
  expect(checkContext([e], ['damage'])).toEqual({
    modifier: 0,
    mode: 'normal',
  });
});
it('generates cross-language health previews including all three simultaneous triggers', () => {
  let c: Character = character();
  const cases = [];
  const actions: ConditionAction[] = [
    {
      type: 'combatHealth',
      command: { kind: 'damage', amount: 20, critical: true, melee: false },
    },
    { type: 'combatHealth', command: { kind: 'deathSave', face: 1 } },
    { type: 'combatHealth', command: { kind: 'deathSave', face: 20 } },
    { type: 'combatHealth', command: { kind: 'healing', amount: 8 } },
    { type: 'combatHealth', command: { kind: 'bleed' } },
    { type: 'combatHealth', command: { kind: 'stopBleeding' } },
  ];
  for (const action of actions) {
    const op = crypto.randomUUID(),
      p = previewCondition(c, action, op);
    cases.push({ before: c, action, op, context: p.context, after: p.state });
    c = { ...c, condition: p.state };
  }
  if (process.env.GENERATE_COMBAT_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-combat-health.json',
      JSON.stringify(cases, null, 2) + '\n',
    );
});
it('Chrom retains overheating but cannot jam and never consumes exact saved ammunition', () => {
  const { i, w } = inventoryFixture();
  w.cinematicLoaded = true;
  let inv = i;
  const cases: {
    before: Inventory;
    action: InventoryAction;
    after: Inventory;
  }[] = [];
  const actions: InventoryAction[] = [
    { kind: 'shot', weaponId: w.id, mode: 'long', count: 10 },
    {
      kind: 'weaponState',
      weaponId: w.id,
      operation: 'heat',
      face: 1,
      reason: '',
    },
    {
      kind: 'weaponState',
      weaponId: w.id,
      operation: 'cool',
      face: null,
      reason: 'Postój po walce',
    },
  ];
  for (const action of actions) {
    const next = applyInventoryAction(inv, action, 'chrome');
    cases.push({ before: inv, action, after: next });
    inv = next;
  }
  expect(() =>
    applyInventoryAction(
      inv,
      {
        kind: 'weaponState',
        weaponId: w.id,
        operation: 'jam',
        face: null,
        reason: '',
      },
      'chrome',
    ),
  ).toThrow();
  expect(cases[1]!.after.entries[0]!.combatState?.overheated).toBe(true);
  expect(() =>
    applyInventoryAction(cases[1]!.after, actions[0]!, 'chrome'),
  ).toThrow();
  expect(inv.entries.map((e) => e.quantityMilli)).toEqual(
    i.entries.map((e) => e.quantityMilli),
  );
  if (process.env.GENERATE_COMBAT_FIXTURES)
    writeFileSync(
      'tests/fixtures/character-combat-weapon.json',
      JSON.stringify(cases, null, 2) + '\n',
    );
});
