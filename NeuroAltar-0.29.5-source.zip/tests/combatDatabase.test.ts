import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { expect, it } from 'vitest';
import { migrate, repositoryFor } from './helpers/database';
import { createCombatRepository } from '../src/db/combatRepository';
const migration2 = readFileSync(
  new URL('../src-tauri/migrations/002_pc_initiative.sql', import.meta.url),
  'utf8',
);
const migration3 = readFileSync(
  new URL('../src-tauri/migrations/003_enemy_instances.sql', import.meta.url),
  'utf8',
);
const actorId = '00000000-0000-4000-8000-000000000001';
function repository(db: DatabaseSync) {
  return createCombatRepository({
    selectRows: async (sql, values = []) => db.prepare(sql).all(...values),
    execute: async (sql, values) => ({
      rowsAffected: Number(db.prepare(sql).run(...values).changes),
    }),
  });
}
it('adds the schema without resetting existing five-slot names, notes, rounds or timestamps', async () => {
  const db = new DatabaseSync(':memory:');
  try {
    migrate(db);
    for (let id = 1; id <= 5; id++)
      db.prepare(
        'UPDATE encounters SET name = ?, notes = ?, round_number = ? WHERE id = ?',
      ).run(`Potyczka ż ${id}`, `Pierwsza\nDruga ${id}`, id, id);
    const before = await repositoryFor(db).listSlots();
    db.exec('BEGIN');
    db.exec(migration2);
    db.exec(migration3);
    db.exec(
      readFileSync(
        new URL(
          '../src-tauri/migrations/005_actor_statuses.sql',
          import.meta.url,
        ),
        'utf8',
      ),
    );
    db.exec('COMMIT');
    expect(await repositoryFor(db).listSlots()).toEqual(before);
    expect(
      (await repository(db).listSlots()).map((s) => ({
        actors: s.actors,
        revision: s.revision,
      })),
    ).toEqual(Array.from({ length: 5 }, () => ({ actors: [], revision: 0 })));
    expect(() => db.exec('DELETE FROM encounters WHERE id = 1')).toThrow();
    expect(() =>
      db.exec(
        `UPDATE encounters SET current_turn_actor_id = '${actorId}' WHERE id = 1`,
      ),
    ).toThrow();
    expect(db.prepare('PRAGMA integrity_check').get()).toEqual({
      integrity_check: 'ok',
    });
  } finally {
    db.close();
  }
});
it('reads persisted characters and turn state after a real database restart', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'neuroaltar-stage2-db-'));
  const path = join(dir, 'test.sqlite');
  let db = new DatabaseSync(path);
  try {
    migrate(db);
    db.exec(migration2);
    db.exec(migration3);
    db.exec(
      readFileSync(
        new URL(
          '../src-tauri/migrations/005_actor_statuses.sql',
          import.meta.url,
        ),
        'utf8',
      ),
    );
    db.prepare(
      `INSERT INTO encounter_actors (id, encounter_id, kind, display_name, initiative_value, initiative_tie_order, tt_current, hp_current, hp_max_current, prepared_snapshot_json, runtime_overrides_json) VALUES (?, 2, 'pc', ?, 0, 0, 14, 0, 20, '{}', ?)`,
    ).run(
      actorId,
      "Żaneta '); --",
      JSON.stringify({ manualStatuses: ['Przerażenie', 'Zatrucie'] }),
    );
    db.prepare(
      'UPDATE encounters SET round_number = 4, current_turn_actor_id = ?, combat_revision = 7 WHERE id = 2',
    ).run(actorId);
    const before = await repository(db).listSlots();
    db.close();
    db = new DatabaseSync(path);
    expect(await repository(db).listSlots()).toEqual(before);
    expect(before[1]).toMatchObject({
      roundNumber: 4,
      revision: 7,
      currentTurnActorId: actorId,
      actors: [
        {
          displayName: "Żaneta '); --",
          hpCurrent: 0,
          initiativeValue: 0,
          statuses: ['Przerażenie', 'Zatrucie'],
        },
      ],
    });
    expect(
      before
        .filter((s) => s.encounterId !== 2)
        .every((s) => s.actors.length === 0),
    ).toBe(true);
    expect(() =>
      db
        .prepare('UPDATE encounter_actors SET encounter_id = 3 WHERE id = ?')
        .run(actorId),
    ).toThrow();
    expect(() =>
      db
        .prepare(
          'UPDATE encounter_actors SET prepared_snapshot_json = \'{"hp":3}\' WHERE id = ?',
        )
        .run(actorId),
    ).toThrow();
    expect(() =>
      db
        .prepare('UPDATE encounters SET current_turn_actor_id = ? WHERE id = 3')
        .run(actorId),
    ).toThrow();
    db.exec("UPDATE encounter_actors SET runtime_overrides_json = '{}' ");
    await expect(repository(db).listSlots()).rejects.toThrow();
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
