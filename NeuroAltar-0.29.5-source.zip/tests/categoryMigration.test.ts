import { it, expect } from 'vitest';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
const sql = (name: string) =>
  readFileSync(
    new URL(`../src-tauri/migrations/${name}.sql`, import.meta.url),
    'utf8',
  );
it('adds taxonomy without rewriting legacy templates, timestamps, tombstones, ledger or encounter snapshots', () => {
  const db = new DatabaseSync(':memory:');
  for (const name of [
    '001_initial',
    '002_pc_initiative',
    '003_enemy_instances',
    '004_combat_log',
    '005_actor_statuses',
    '006_bestiary',
    '007_bestiary_seed',
  ])
    db.exec(sql(name));
  db.exec(
    "INSERT INTO enemy_templates (id,name,category,size,tt,hp_max,statblock_json,revision,deleted) VALUES ('old','Żółć','other','Średni',12,30,'{}',7,1)",
  );
  const before = db.prepare('SELECT * FROM enemy_templates').all();
  const encounters = db.prepare('SELECT * FROM encounters').all();
  db.exec('BEGIN');
  db.exec(sql('008_enemy_categories'));
  db.exec('COMMIT');
  const row = db.prepare('SELECT * FROM enemy_templates').get()!;
  const { official_category, ...rest } = row;
  expect(official_category).toBeNull();
  expect(rest).toEqual(before[0]);
  expect(db.prepare('SELECT * FROM encounters').all()).toEqual(encounters);
  expect(
    db.prepare('SELECT count(*) AS n FROM bestiary_seed_entries').get()!.n,
  ).toBe(0);
  expect(() =>
    db.exec("UPDATE enemy_templates SET official_category='invalid'"),
  ).toThrow();
  expect(db.prepare('PRAGMA integrity_check').get()!.integrity_check).toBe(
    'ok',
  );
  expect(db.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
  db.close();
});
