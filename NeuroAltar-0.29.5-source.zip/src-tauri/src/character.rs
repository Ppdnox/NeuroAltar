#[path = "character_condition.rs"]
mod condition;
#[path = "character_inventory.rs"]
mod inventory;
#[path = "character_participation.rs"]
pub mod participation;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sqlx::{Row, SqlitePool};
use tauri_plugin_sql::DbInstances;

#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Character {
    id: String,
    schema_version: i64,
    revision: i64,
    created_at: String,
    updated_at: String,
    archived: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    inventory: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    condition: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    journal: Option<Value>,
    sheet: Option<Value>,
    draft: Option<Value>,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Mutation {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    participation_revision: Option<i64>,
    operation_id: String,
    expected_revision: Option<i64>,
    character: Character,
    kind: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    correction_reason: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    inventory_action: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    condition_action: Option<Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    condition_context: Option<Value>,
}
const ABILITIES: [&str; 6] = ["str", "dex", "con", "int", "wis", "cha"];
const CLASSES: [&str; 6] = [
    "brutal",
    "cwaniak",
    "spec",
    "twardziel",
    "zlodziej",
    "zwiadowca",
];
const COLORS: [&str; 5] = ["none", "rust", "mercury", "steel", "chrome"];

pub(crate) fn apply_roll_resource(
    raw: &Value,
    resource: &str,
    targets: &[String],
    sides: i64,
    failed: bool,
    operation: &str,
) -> Result<Value, String> {
    let mut c: Character = serde_json::from_value(raw.clone()).map_err(|e| e.to_string())?;
    c.condition = Some(condition::spend_roll_resource(
        &c, resource, targets, sides, failed, operation,
    )?);
    serde_json::to_value(c).map_err(|e| e.to_string())
}

pub(crate) fn validate_roll_character(raw: &Value) -> Result<(), String> {
    let c: Character = serde_json::from_value(raw.clone()).map_err(|e| e.to_string())?;
    if c.archived || c.draft.is_some() || c.sheet.is_none() {
        return Err("Zatwierdź kartę przed użyciem zdolności.".into());
    }
    if let Some(s) = &c.condition {
        condition::validate(s)?;
    }
    Ok(())
}
fn fail() -> String {
    "Niepoprawne dane karty BG. Wróć do zaznaczonej sekcji formularza.".into()
}
fn string(v: &Value, max: usize) -> Result<&str, String> {
    v.as_str()
        .filter(|s| s.chars().count() <= max)
        .ok_or_else(fail)
}
fn integer(v: &Value, min: i64, max: i64) -> Result<i64, String> {
    v.as_i64()
        .filter(|n| (min..=max).contains(n))
        .ok_or_else(fail)
}
fn keys(v: &Value, expected: &[&str]) -> Result<(), String> {
    let o = v.as_object().ok_or_else(fail)?;
    if o.len() != expected.len() || expected.iter().any(|k| !o.contains_key(*k)) {
        return Err(fail());
    }
    Ok(())
}
fn choice(v: &Value, allowed: &[&str]) -> Result<(), String> {
    if !allowed.contains(&string(v, 100)?) {
        return Err(fail());
    }
    Ok(())
}
fn validate_sheet(v: &Value, ready: bool) -> Result<(), String> {
    keys(
        v,
        &[
            "identity",
            "method",
            "methodReason",
            "baseScores",
            "originId",
            "levels",
            "rulesContext",
            "advancementMode",
            "xp",
            "hpCurrent",
            "notes",
            "contacts",
            "discoveries",
            "overrides",
        ],
    )?;
    keys(
        &v["identity"],
        &[
            "name",
            "description",
            "age",
            "height",
            "bodyWeight",
            "size",
            "portrait",
        ],
    )?;
    let name = string(&v["identity"]["name"], 300)?;
    if ready && name.trim().is_empty() {
        return Err("Uzupełnij imię postaci.".into());
    }
    string(&v["identity"]["description"], 20000)?;
    let portrait = string(&v["identity"]["portrait"], 1500000)?;
    if !portrait.is_empty()
        && ![
            "data:image/png;base64,",
            "data:image/jpeg;base64,",
            "data:image/webp;base64,",
        ]
        .iter()
        .any(|p| portrait.starts_with(p))
    {
        return Err(fail());
    }
    for (field, max) in [("age", 1000.0), ("height", 1000.0), ("bodyWeight", 10000.0)] {
        let n = &v["identity"][field];
        if !n.is_null()
            && !n.as_f64().is_some_and(|x| {
                x.is_finite() && (0.0..=max).contains(&x) && (field != "age" || x.fract() == 0.0)
            })
        {
            return Err(fail());
        }
    }
    choice(
        &v["identity"]["size"],
        &["tiny", "small", "medium", "large", "huge", "gargantuan"],
    )?;
    choice(
        &v["method"],
        &["array-a", "array-b", "array-c", "points", "gm"],
    )?;
    string(&v["methodReason"], 300)?;
    keys(&v["baseScores"], &ABILITIES)?;
    for a in ABILITIES {
        if ready || !v["baseScores"][a].is_null() {
            integer(&v["baseScores"][a], 1, 30)?;
        }
    }
    let origin = string(&v["originId"], 300)?;
    if !origin.is_empty()
        && ![
            "asgard",
            "desert",
            "detroit",
            "appalachia",
            "miami",
            "mississippi",
            "newyork",
            "hegemony",
            "outpost",
            "saltlake",
            "texas",
            "vegas",
        ]
        .contains(&origin)
    {
        return Err(fail());
    }
    if ready && origin.is_empty() {
        return Err("Wybierz pochodzenie.".into());
    }
    let levels = v["levels"]
        .as_array()
        .filter(|l| !l.is_empty() && l.len() <= 12)
        .ok_or_else(fail)?;
    for l in levels {
        keys(l, &["classId", "color", "contextRevision", "choices"])?;
        choice(&l["classId"], &CLASSES)?;
        choice(&l["color"], &COLORS)?;
        integer(&l["contextRevision"], 0, 1_000_000_000)?;
        let map = l["choices"]
            .as_object()
            .filter(|m| m.len() <= 100)
            .ok_or_else(fail)?;
        for (k, values) in map {
            if k.len() > 100 {
                return Err(fail());
            }
            for s in values
                .as_array()
                .filter(|a| a.len() <= 30)
                .ok_or_else(fail)?
            {
                string(s, 300)?;
            }
        }
    }
    keys(
        &v["rulesContext"],
        &["gameColor", "revision", "sourceFingerprint"],
    )?;
    choice(&v["rulesContext"]["gameColor"], &COLORS)?;
    integer(&v["rulesContext"]["revision"], 0, 1_000_000_000)?;
    if v["rulesContext"]["sourceFingerprint"]
        != "714c3af5418036991a9a3e6e1ae03ff6826a5a41de51f69004a0ab41ad02bf34"
    {
        return Err(fail());
    }
    choice(&v["advancementMode"], &["xp", "milestones"])?;
    let mut xp = 0;
    let mut ids = std::collections::HashSet::new();
    for e in v["xp"]
        .as_array()
        .filter(|a| a.len() <= 1000)
        .ok_or_else(fail)?
    {
        keys(e, &["id", "amount", "reason"])?;
        let id = string(&e["id"], 100)?;
        uuid::Uuid::parse_str(id).map_err(|_| fail())?;
        if !ids.insert(id) {
            return Err("Powtórzony identyfikator nagrody PD.".into());
        }
        xp += integer(&e["amount"], -100000, 100000)?;
        string(&e["reason"], 300)?;
    }
    if ready
        && (xp < 0
            || (v["advancementMode"] == "xp"
                && xp
                    < [
                        0, 50, 150, 300, 500, 800, 1100, 1400, 1900, 2400, 2900, 3400,
                    ][levels.len() - 1]))
    {
        return Err("Za mało PD na wskazany poziom.".into());
    }
    if !v["hpCurrent"].is_null() {
        integer(&v["hpCurrent"], 0, 100000)?;
    }
    for field in ["notes", "contacts", "discoveries"] {
        string(&v[field], 20000)?;
    }
    for o in v["overrides"]
        .as_array()
        .filter(|a| a.len() <= 100)
        .ok_or_else(fail)?
    {
        keys(o, &["id", "target", "mode", "value", "reason"])?;
        uuid::Uuid::parse_str(string(&o["id"], 100)?).map_err(|_| fail())?;
        string(&o["target"], 300)?;
        choice(&o["mode"], &["add", "replace"])?;
        if !o["value"]
            .as_f64()
            .is_some_and(|n| n.is_finite() && (-10000.0..=10000.0).contains(&n))
        {
            return Err(fail());
        }
        let r = string(&o["reason"], 300)?;
        if ready && r.trim().is_empty() {
            return Err(fail());
        }
    }
    Ok(())
}
pub async fn save_to_pool(pool: &SqlitePool, change: Mutation) -> Result<Character, String> {
    uuid::Uuid::parse_str(&change.operation_id).map_err(|_| fail())?;
    uuid::Uuid::parse_str(&change.character.id).map_err(|_| fail())?;
    if change.character.schema_version != 1
        || change
            .expected_revision
            .is_some_and(|r| !(0..1_000_000_000).contains(&r))
        || ![
            "draft",
            "publish",
            "discard",
            "archive",
            "inventory",
            "condition",
        ]
        .contains(&change.kind.as_str())
    {
        return Err(fail());
    }
    if change.character.sheet.is_none() && change.character.draft.is_none() {
        return Err(fail());
    }
    if let Some(journal) = &change.character.journal {
        keys(journal, &["notes", "contacts", "discoveries"])?;
        for key in ["notes", "contacts", "discoveries"] {
            string(&journal[key], 20000)?;
        }
    }
    if let Some(s) = &change.character.sheet {
        validate_sheet(s, true)?;
    }
    if let Some(d) = &change.character.draft {
        validate_sheet(d, false)?;
    }
    if let Some(i) = &change.character.inventory {
        inventory::validate(i)?;
    }
    if (change.kind == "inventory") != change.inventory_action.is_some() {
        return Err(fail());
    }
    if let Some(v) = &change.character.condition {
        condition::validate(v)?;
    }
    if (change.kind == "condition") != change.condition_action.is_some()
        || (change.kind == "condition") != change.condition_context.is_some()
    {
        return Err(fail());
    }
    let request = serde_json::to_value(&change).map_err(|e| e.to_string())?;
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    sqlx::query("UPDATE characters SET revision=revision WHERE id=?")
        .bind(&change.character.id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    if let Some(row) = sqlx::query(
        "SELECT request_json,result_json FROM character_operations WHERE operation_id=?",
    )
    .bind(&change.operation_id)
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| e.to_string())?
    {
        let old: Value =
            serde_json::from_str(row.get::<&str, _>("request_json")).map_err(|e| e.to_string())?;
        if old != request {
            return Err("Identyfikator operacji został już użyty z innymi danymi.".into());
        }
        return serde_json::from_str(row.get("result_json")).map_err(|e| e.to_string());
    }
    let old: Option<String> = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
        .bind(&change.character.id)
        .fetch_optional(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let previous: Option<Character> = old
        .map(|s| serde_json::from_str(&s))
        .transpose()
        .map_err(|e| e.to_string())?;
    if previous.as_ref().map(|c| c.revision) != change.expected_revision {
        return Err(
            "Konflikt wersji karty. Szkic zachowano. Odczytaj aktualną kartę i porównaj zmiany."
                .into(),
        );
    }
    if let Some(reason) = &change.correction_reason {
        if reason.trim().is_empty() || reason.chars().count() > 300 {
            return Err(fail());
        }
    }
    if let Some(old) = &previous {
        if change.kind != "draft" && old.journal != change.character.journal {
            return Err("Zapisz notatki przed wykonaniem innej operacji.".into());
        }
        if change.kind == "condition" {
            if old.sheet != change.character.sheet
                || old.draft != change.character.draft
                || old.archived != change.character.archived
            {
                return Err(fail());
            }
            condition::apply(
                old,
                change.condition_action.as_ref().unwrap(),
                change.condition_context.as_ref().unwrap(),
                &change.operation_id,
                change.character.condition.as_ref().ok_or_else(fail)?,
            )?;
        } else if old.condition != change.character.condition {
            return Err("Rozwój ani inwentarz nie mogą zmieniać zdrowia i zasobów.".into());
        }
        if old.condition.is_some()
            && change.kind == "publish"
            && old.sheet.as_ref().map(|s| &s["hpCurrent"])
                != change.character.sheet.as_ref().map(|s| &s["hpCurrent"])
        {
            return Err("Aktualne PW zmieniaj w sekcji Zdrowie, nie w szkicu rozwoju.".into());
        }

        if change.kind == "inventory" {
            if old.archived
                || old.sheet.is_none()
                || old.draft.is_some()
                || change.character.sheet != old.sheet
                || change.character.draft != old.draft
                || change.character.archived != old.archived
            {
                return Err("Zatwierdź lub odrzuć szkic przed zmianą inwentarza.".into());
            }
            let expected = inventory::apply(
                &old.inventory.clone().unwrap_or_else(inventory::empty),
                change.inventory_action.as_ref().unwrap(),
                old.sheet.as_ref().unwrap()["rulesContext"]["gameColor"]
                    .as_str()
                    .unwrap_or("none"),
                old.sheet.as_ref().unwrap()["levels"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|l| {
                        ["start", "feat", "profession-feat"].iter().any(|k| {
                            l["choices"][*k]
                                .as_array()
                                .is_some_and(|a| a.contains(&serde_json::json!("fingers")))
                        })
                    }),
            )?;
            if !change
                .character
                .inventory
                .as_ref()
                .is_some_and(|v| inventory::same(v, &expected))
            {
                return Err("Wynik operacji inwentarza nie zgadza się z podglądem.".into());
            }
        } else if change.kind == "condition" {
            let expected = condition::expected_inventory(
                old,
                change.condition_action.as_ref().unwrap(),
                &change.operation_id,
                change.condition_context.as_ref().unwrap(),
            )?;
            if !match (&change.character.inventory, &expected) {
                (Some(a), Some(b)) => inventory::same(a, b),
                (None, None) => true,
                _ => false,
            } {
                return Err("Stan środków nie zgadza się z leczeniem.".into());
            }
        } else if !match (&change.character.inventory, &old.inventory) {
            (Some(a), Some(b)) => inventory::same(a, b),
            (None, None) => true,
            _ => false,
        } {
            return Err(
                "Rozwój, archiwizacja i odrzucenie szkicu nie mogą zmieniać inwentarza.".into(),
            );
        }

        if change.kind == "draft" && old.sheet != change.character.sheet {
            return Err("Autozapis szkicu nie może zmienić zatwierdzonej karty.".into());
        }
        if change.kind == "publish"
            && (change.character.draft.is_some() || change.character.sheet != old.draft)
        {
            return Err(
                "Najpierw zapisz pełny szkic, następnie zatwierdź dokładnie jego podgląd.".into(),
            );
        }
        if change.kind == "discard"
            && (change.character.sheet != old.sheet || change.character.draft.is_some())
        {
            return Err(fail());
        }
        if change.kind == "archive"
            && (change.character.sheet != old.sheet || change.character.draft != old.draft)
        {
            return Err(fail());
        }
    } else if change.kind != "draft"
        || change.character.sheet.is_some()
        || change.character.inventory.is_some()
        || change.character.condition.is_some()
    {
        return Err("Nowa karta zaczyna się od szkicu.".into());
    }
    participation::character_change(&mut tx, &change).await?;
    let mut saved = change.character;
    saved.revision = change.expected_revision.map_or(0, |r| r + 1);
    let now: String = sqlx::query_scalar("SELECT strftime('%Y-%m-%dT%H:%M:%fZ','now')")
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    saved.created_at = previous.map_or_else(|| now.clone(), |p| p.created_at);
    saved.updated_at = now;
    let payload = serde_json::to_string(&saved).map_err(|e| e.to_string())?;
    sqlx::query("INSERT INTO characters(id,revision,archived,payload_json,created_at,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET revision=excluded.revision,archived=excluded.archived,payload_json=excluded.payload_json,updated_at=excluded.updated_at")
       .bind(&saved.id).bind(saved.revision).bind(saved.archived).bind(&payload).bind(&saved.created_at).bind(&saved.updated_at).execute(&mut *tx).await.map_err(|e|e.to_string())?;
    sqlx::query("INSERT INTO character_operations(operation_id,character_id,kind,request_json,result_json) VALUES(?,?,?,?,?)").bind(change.operation_id).bind(&saved.id).bind(change.kind).bind(request.to_string()).bind(&payload).execute(&mut *tx).await.map_err(|e|e.to_string())?;
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(saved)
}
#[tauri::command]
pub async fn save_character(
    databases: tauri::State<'_, DbInstances>,
    change: Mutation,
) -> Result<Character, String> {
    let pool = {
        let instances = databases.0.read().await;
        if let Some(tauri_plugin_sql::DbPool::Sqlite(pool)) =
            instances.get("sqlite:combat-tracker.db")
        {
            pool.clone()
        } else {
            return Err("Baza nie jest otwarta.".into());
        }
    };
    save_to_pool(&pool, change).await
}

#[cfg(test)]
#[path = "character_tests.rs"]
mod tests;
