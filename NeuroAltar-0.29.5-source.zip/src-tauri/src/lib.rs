mod character;
mod combat;
use std::sync::atomic::{AtomicBool, Ordering};
use tauri::{Emitter, Manager};
use tauri_plugin_sql::{Migration, MigrationKind};

#[derive(Default)]
struct CloseGuard {
    ready: AtomicBool,
    approved: AtomicBool,
}

#[tauri::command]
fn enable_close_guard(state: tauri::State<'_, CloseGuard>) {
    state.ready.store(true, Ordering::SeqCst);
}

#[tauri::command]
fn finish_exit(app: tauri::AppHandle, state: tauri::State<'_, CloseGuard>) {
    state.approved.store(true, Ordering::SeqCst);
    app.exit(0);
}

fn needs_save(state: &CloseGuard) -> bool {
    state.ready.load(Ordering::SeqCst) && !state.approved.load(Ordering::SeqCst)
}

pub fn run() {
    let migrations = vec![
        Migration {
            version: 1,
            description: "initial_encounter_slots",
            sql: include_str!("../migrations/001_initial.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 2,
            description: "pc_initiative",
            sql: include_str!("../migrations/002_pc_initiative.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 3,
            description: "enemy_instances",
            sql: include_str!("../migrations/003_enemy_instances.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 4,
            description: "combat_log",
            sql: include_str!("../migrations/004_combat_log.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 5,
            description: "actor_statuses",
            sql: include_str!("../migrations/005_actor_statuses.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 6,
            description: "bestiary_catalog",
            sql: include_str!("../migrations/006_bestiary.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 7,
            description: "bestiary_seed_ledger",
            sql: include_str!("../migrations/007_bestiary_seed.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 8,
            description: "enemy_categories",
            sql: include_str!("../migrations/008_enemy_categories.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 9,
            description: "equipment_catalog",
            sql: include_str!("../migrations/009_equipment.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 10,
            description: "dice_history",
            sql: include_str!("../migrations/010_dice_history.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 11,
            description: "persistent_characters",
            sql: include_str!("../migrations/011_characters.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 12,
            description: "character_inventory",
            sql: include_str!("../migrations/012_character_inventory.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 13,
            description: "character_condition",
            sql: include_str!("../migrations/013_character_condition.sql"),
            kind: MigrationKind::Up,
        },
        Migration {
            version: 14,
            description: "character_participation",
            sql: include_str!("../migrations/014_character_participation.sql"),
            kind: MigrationKind::Up,
        },
    ];

    tauri::Builder::default()
        .menu(|app| {
            use tauri::menu::{Menu, MenuItem, PredefinedMenuItem, Submenu};
            let quit = MenuItem::with_id(
                app,
                "save-and-quit",
                "Zakończ NeuroAltar",
                true,
                Some("CmdOrCtrl+Q"),
            )?;
            let app_menu = Submenu::with_items(
                app,
                "NeuroAltar",
                true,
                &[
                    &PredefinedMenuItem::about(app, Some("O NeuroAltar"), None)?,
                    &PredefinedMenuItem::separator(app)?,
                    #[cfg(target_os = "macos")]
                    &PredefinedMenuItem::hide(app, Some("Ukryj NeuroAltar"))?,
                    #[cfg(target_os = "macos")]
                    &PredefinedMenuItem::hide_others(app, Some("Ukryj pozostałe"))?,
                    &quit,
                ],
            )?;
            let edit_menu = Submenu::with_items(
                app,
                "Edycja",
                true,
                &[
                    &PredefinedMenuItem::undo(app, Some("Cofnij"))?,
                    &PredefinedMenuItem::redo(app, Some("Ponów"))?,
                    &PredefinedMenuItem::separator(app)?,
                    &PredefinedMenuItem::cut(app, Some("Wytnij"))?,
                    &PredefinedMenuItem::copy(app, Some("Kopiuj"))?,
                    &PredefinedMenuItem::paste(app, Some("Wklej"))?,
                    &PredefinedMenuItem::select_all(app, Some("Zaznacz wszystko"))?,
                ],
            )?;
            let window_menu = Submenu::with_items(
                app,
                "Okno",
                true,
                &[
                    &PredefinedMenuItem::minimize(app, Some("Minimalizuj"))?,
                    &PredefinedMenuItem::close_window(app, Some("Zamknij"))?,
                ],
            )?;
            Menu::with_items(app, &[&app_menu, &edit_menu, &window_menu])
        })
        .on_menu_event(|app, event| {
            if event.id().as_ref() == "save-and-quit" {
                if needs_save(&app.state::<CloseGuard>()) {
                    let _ = app.emit("neuroaltar-close-requested", ());
                } else {
                    app.exit(0);
                }
            }
        })
        .manage(CloseGuard::default())
        .invoke_handler(tauri::generate_handler![
            enable_close_guard,
            character::save_character,
            character::participation::participation_command,
            finish_exit,
            combat::save_combat,
            combat::dice::save_dice_roll,
            combat::dice::save_initiative_roll,
            combat::encounter_clear::clear_encounter,
            combat::bestiary_seed::seed_bestiary,
            combat::equipment::seed_equipment,
            combat::bestiary::save_bestiary
        ])
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                if needs_save(&window.state::<CloseGuard>()) {
                    api.prevent_close();
                    let _ = window.emit("neuroaltar-close-requested", ());
                }
            }
        })
        .plugin(
            tauri_plugin_sql::Builder::default()
                .add_migrations("sqlite:combat-tracker.db", migrations)
                .build(),
        )
        .build(tauri::generate_context!())
        .expect("Nie udało się uruchomić NeuroAltar")
        .run(|app, event| {
            if let tauri::RunEvent::ExitRequested { api, .. } = event {
                if needs_save(&app.state::<CloseGuard>()) {
                    api.prevent_exit();
                    let _ = app.emit("neuroaltar-close-requested", ());
                }
            }
        });
}
