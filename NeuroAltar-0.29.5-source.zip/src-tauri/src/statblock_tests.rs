use super::{
    log::SaveReason,
    save_to_pool, save_with_reason,
    statblock::{self, Statblock},
    tests::{database, enemy_state, reset_saved},
    validate,
};
fn fixture() -> Statblock {
    serde_json::from_str(include_str!("../../tests/fixtures/statblock.json")).unwrap()
}
#[test]
fn validates_shared_statblock_and_legacy_in_all_three_locations() {
    let s = fixture();
    assert!(statblock::valid(&s));
    let json = serde_json::to_value(&s).unwrap();
    assert_eq!(
        json,
        serde_json::from_str::<serde_json::Value>(include_str!(
            "../../tests/fixtures/statblock.json"
        ))
        .unwrap()
    );
    let legacy = enemy_state();
    assert!(validate(&legacy).is_ok());
    for path in [
        "/actors/1/enemy/statblock",
        "/actors/1/enemy/template/statblock",
        "/actors/1/prepared/enemy/statblock",
    ] {
        let mut data = serde_json::json!({"encounterId":legacy.encounter_id,"revision":legacy.revision,"roundNumber":legacy.round_number,"currentTurnActorId":legacy.current_turn_actor_id,"actors":legacy.actors});
        let parent = path.rsplit_once('/').unwrap().0;
        data.pointer_mut(parent).unwrap()["statblock"] = json.clone();
        if parent.ends_with("template") {
            data["actors"][1]["prepared"]["enemy"]["template"]["statblock"] = json.clone();
        }
        let valid_state = serde_json::from_value(data.clone()).unwrap();
        assert!(validate(&valid_state).is_ok());
        data.pointer_mut(path).unwrap()["abilityScores"]["str"] = serde_json::json!(-1);
        assert!(validate(&serde_json::from_value(data).unwrap()).is_err());
    }
    for bad in [-1, 9_007_199_254_740_992] {
        let mut s = fixture();
        s.damage_threshold = Some(bad);
        assert!(!statblock::valid(&s));
    }
    let mut s = fixture();
    s.subtype = Some("x".repeat(201));
    assert!(!statblock::valid(&s));
    s = fixture();
    s.skills = Some(vec!["x".repeat(1001)]);
    assert!(!statblock::valid(&s));
    s = fixture();
    s.senses = Some(vec!["Widzenie".into(); 101]);
    assert!(!statblock::valid(&s));
    let mut invalid = json.clone();
    invalid["abilityScores"]["dex"] = serde_json::json!(1.5);
    assert!(serde_json::from_value::<Statblock>(invalid).is_err());
    let mut invalid = json.clone();
    invalid["abilityScores"]["luck"] = serde_json::json!(1);
    assert!(serde_json::from_value::<Statblock>(invalid).is_err());
    let mut invalid = json;
    invalid.as_object_mut().unwrap().remove("skills");
    assert!(serde_json::from_value::<Statblock>(invalid).is_err());
}
#[test]
fn statblock_and_log_are_atomic_and_catalog_snapshots_and_siblings_stay_independent() {
    tauri::async_runtime::block_on(async {
        let pool = database().await;
        let mut state = enemy_state();
        for actor in &mut state.actors {
            if let Some(e) = &mut actor.enemy {
                e.statblock = Some(fixture());
                e.template.statblock = Some(fixture());
                e.failure_threshold = Some(18);
                e.template.failure_threshold = Some(18);
                let mut p = actor.clone();
                p.prepared = None;
                actor.prepared = Some(Box::new(p));
            }
        }
        state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
        let read="SELECT json_extract(runtime_overrides_json,'$.enemy.statblock.damageThreshold') FROM encounter_actors WHERE id=?";
        let catalog_before: String =
            sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap();
        let snapshot_before: String =
            sqlx::query_scalar("SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?")
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap();
        state.actors[1]
            .enemy
            .as_mut()
            .unwrap()
            .statblock
            .as_mut()
            .unwrap()
            .damage_threshold = Some(0);
        sqlx::raw_sql("CREATE TRIGGER fail_statblock BEFORE INSERT ON combat_log WHEN NEW.event_type='statblock_changed' BEGIN SELECT RAISE(ABORT,'disk'); END;").execute(&pool).await.unwrap();
        assert!(save_to_pool(&pool, state.clone()).await.is_err());
        assert_eq!(
            sqlx::query_scalar::<_, i64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            10
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                .fetch_one(&pool)
                .await
                .unwrap(),
            state.revision
        );
        sqlx::raw_sql("DROP TRIGGER fail_statblock")
            .execute(&pool)
            .await
            .unwrap();
        state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            0
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(read)
                .bind(&state.actors[2].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            10
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            catalog_before
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>(
                "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?"
            )
            .bind(&state.actors[1].id)
            .fetch_one(&pool)
            .await
            .unwrap(),
            snapshot_before
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM combat_log WHERE event_type='statblock_changed'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            1
        );
        let reset = reset_saved(&pool, 1).await;
        save_with_reason(&pool, reset, SaveReason::Reset)
            .await
            .unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            10
        );
        assert_eq!(sqlx::query_scalar::<_,i64>("SELECT json_extract(runtime_overrides_json,'$.enemy.failureThreshold') FROM encounter_actors WHERE id=?").bind(&state.actors[1].id).fetch_one(&pool).await.unwrap(),18);
        pool.close().await;
    });
}
