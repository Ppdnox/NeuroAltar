use serde::{Deserialize, Serialize};
use std::collections::HashSet;
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct ValueRange {
    min: f64,
    max: f64,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct WeaponRange {
    normal: Option<f64>,
    long: Option<f64>,
    unit: String,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct DamageMode {
    id: String,
    label: String,
    dice: String,
    average: Option<f64>,
    damage_type: String,
    condition: Option<String>,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Variant {
    id: String,
    label: String,
    attack_modifier: i64,
    damage_mode_id: Option<String>,
    range: Option<WeaponRange>,
    effect: String,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct WeaponProfile {
    attack_kind: String,
    ability_rule: String,
    attack_modifier: i64,
    range: WeaponRange,
    damage_modes: Vec<DamageMode>,
    properties: Vec<String>,
    fire_modes: Vec<Variant>,
    ammo_variants: Vec<Variant>,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(crate) struct Item {
    pub(super) id: String,
    name: String,
    #[serde(rename = "type")]
    kind: String,
    category: String,
    economic_category: String,
    base_price: Option<ValueRange>,
    base_availability: Option<ValueRange>,
    weight: Option<f64>,
    description: String,
    properties: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    weapon_profile: Option<WeaponProfile>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    source: Option<String>,
    created_at: String,
    updated_at: String,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct EquippedItem {
    item: Item,
    damage_mode_id: Option<String>,
    fire_mode_id: Option<String>,
    ammo_variant_id: Option<String>,
}
#[derive(Debug, Clone, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Loadout {
    pb: Option<i64>,
    str_modifier: Option<i64>,
    dex_modifier: Option<i64>,
    items: Vec<EquippedItem>,
}
fn text(s: &str) -> bool {
    !s.trim().is_empty()
}
fn finite(n: f64) -> bool {
    n.is_finite() && (0.0..=9_007_199_254_740_991.0).contains(&n)
}
fn bonus(n: i64) -> bool {
    (-99..=99).contains(&n)
}
fn range(r: &WeaponRange) -> bool {
    r.unit == "m"
        && r.normal.is_none_or(finite)
        && r.long
            .is_none_or(|l| finite(l) && r.normal.is_some_and(|n| n <= l))
}
fn values(r: &ValueRange) -> bool {
    finite(r.min) && finite(r.max) && r.min <= r.max
}
fn unique<'a>(ids: impl Iterator<Item = &'a str>) -> bool {
    let mut seen = HashSet::new();
    ids.into_iter().all(|s| text(s) && seen.insert(s))
}
fn valid_variant(v: &Variant, p: &WeaponProfile) -> bool {
    text(&v.id)
        && text(&v.label)
        && bonus(v.attack_modifier)
        && v.range.as_ref().is_none_or(range)
        && v.damage_mode_id
            .as_ref()
            .is_none_or(|id| p.damage_modes.iter().any(|d| &d.id == id))
}
fn profile(p: &WeaponProfile) -> bool {
    ["melee", "ranged"].contains(&p.attack_kind.as_str())
        && ["str", "dex", "finesse"].contains(&p.ability_rule.as_str())
        && bonus(p.attack_modifier)
        && range(&p.range)
        && !p.damage_modes.is_empty()
        && unique(p.damage_modes.iter().map(|d| d.id.as_str()))
        && p.damage_modes.iter().all(|d| {
            text(&d.label) && text(&d.dice) && text(&d.damage_type) && d.average.is_none_or(finite)
        })
        && p.properties.iter().all(|s| text(s))
        && unique(p.fire_modes.iter().map(|d| d.id.as_str()))
        && unique(p.ammo_variants.iter().map(|d| d.id.as_str()))
        && p.fire_modes
            .iter()
            .chain(&p.ammo_variants)
            .all(|v| valid_variant(v, p))
}
pub(super) fn valid(l: &Loadout) -> bool {
    l.pb.is_none_or(|p| (0..=99).contains(&p))
        && l.str_modifier.is_none_or(bonus)
        && l.dex_modifier.is_none_or(bonus)
        && unique(l.items.iter().map(|e| e.item.id.as_str()))
        && l.items.iter().all(|e| {
            let i = &e.item;
            uuid::Uuid::parse_str(&i.id).is_ok()
                && text(&i.name)
                && text(&i.created_at)
                && text(&i.updated_at)
                && [
                    "weapon",
                    "armor",
                    "ammunition",
                    "tool",
                    "electronics",
                    "food",
                    "fuel",
                    "other",
                ]
                .contains(&i.kind.as_str())
                && i.base_price.as_ref().is_none_or(values)
                && i.base_availability
                    .as_ref()
                    .is_none_or(|r| values(r) && r.max <= 100.0)
                && i.weight.is_none_or(finite)
                && i.properties.iter().all(|s| text(s))
                && match &i.weapon_profile {
                    None => {
                        e.damage_mode_id.is_none()
                            && e.fire_mode_id.is_none()
                            && e.ammo_variant_id.is_none()
                    }
                    Some(p) => {
                        i.kind == "weapon"
                            && profile(p)
                            && e.damage_mode_id
                                .as_ref()
                                .is_some_and(|id| p.damage_modes.iter().any(|d| &d.id == id))
                            && e.fire_mode_id
                                .as_ref()
                                .is_none_or(|id| p.fire_modes.iter().any(|v| &v.id == id))
                            && e.ammo_variant_id
                                .as_ref()
                                .is_none_or(|id| p.ammo_variants.iter().any(|v| &v.id == id))
                    }
                }
        })
}

// Reuse the combat Item validator without inventing an attack or mutating the Item.
pub(crate) fn valid_catalog_item(item: &Item) -> bool {
    valid(&Loadout {
        pb: None,
        str_modifier: None,
        dex_modifier: None,
        items: vec![EquippedItem {
            item: item.clone(),
            damage_mode_id: item
                .weapon_profile
                .as_ref()
                .and_then(|p| p.damage_modes.first().map(|d| d.id.clone())),
            fire_mode_id: None,
            ammo_variant_id: None,
        }],
    })
}

#[cfg(test)]
mod tests {
    use super::super::{
        log::SaveReason,
        save_to_pool, save_with_reason,
        tests::{database, enemy_state},
    };
    use super::*;
    fn fixture() -> Loadout {
        serde_json::from_str(include_str!("../../tests/fixtures/loadout.json")).unwrap()
    }
    #[test]
    fn validates_item_ranges_variants_and_preserves_general_item_without_profile() {
        let value = fixture();
        assert!(valid(&value));
        let mut bad = value.clone();
        bad.items[0].item.base_availability.as_mut().unwrap().max = 101.0;
        assert!(!valid(&bad));
        let mut bad = value.clone();
        bad.items[0].item.base_price.as_mut().unwrap().min = 30.0;
        assert!(!valid(&bad));
        let mut bad = value.clone();
        bad.items[0]
            .item
            .weapon_profile
            .as_mut()
            .unwrap()
            .range
            .long = Some(10.0);
        assert!(!valid(&bad));
        let mut bad = value.clone();
        bad.items[0].ammo_variant_id = Some("unknown".into());
        assert!(!valid(&bad));
        let mut bad = value.clone();
        bad.items[0]
            .item
            .weapon_profile
            .as_mut()
            .unwrap()
            .fire_modes[0]
            .damage_mode_id = Some("unknown".into());
        assert!(!valid(&bad));
        let mut bad = value.clone();
        bad.items.push(bad.items[0].clone());
        assert!(!valid(&bad));
        let mut general = value;
        general.items[0].item.weapon_profile = None;
        general.items[0].item.kind = "tool".into();
        general.items[0].damage_mode_id = None;
        assert!(valid(&general));
    }
    #[test]
    fn equipment_log_and_reset_are_atomic_and_do_not_mutate_templates_or_siblings() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.actors[1].enemy.as_mut().unwrap().loadout = Some(fixture());
            let mut prepared = state.actors[1].clone();
            prepared.prepared = None;
            state.actors[1].prepared = Some(Box::new(prepared));
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let original: String = sqlx::query_scalar(
                "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?",
            )
            .bind(&state.actors[1].id)
            .fetch_one(&pool)
            .await
            .unwrap();
            let template: String = sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap();
            state.actors[1]
                .enemy
                .as_mut()
                .unwrap()
                .loadout
                .as_mut()
                .unwrap()
                .items[0]
                .item
                .name = "Podmieniony karabin".into();
            sqlx::raw_sql("CREATE TRIGGER fail_equipment_log BEFORE INSERT ON combat_log WHEN NEW.event_type='equipment_changed' BEGIN SELECT RAISE(ABORT,'log failure'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, state.clone()).await.is_err());
            let stored:String=sqlx::query_scalar("SELECT json_extract(runtime_overrides_json,'$.enemy.loadout.items[0].item.name') FROM encounter_actors WHERE id=?").bind(&state.actors[1].id).fetch_one(&pool).await.unwrap();
            assert_eq!(stored, "Karabin Żółw");
            sqlx::raw_sql("DROP TRIGGER fail_equipment_log")
                .execute(&pool)
                .await
                .unwrap();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='equipment_changed'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            state.actors[1] = *state.actors[1].prepared.clone().unwrap();
            state.round_number = 1;
            state.current_turn_actor_id = None;
            state = super::super::tests::reset_saved(&pool, 1).await;
            state.revision = save_with_reason(&pool, state.clone(), SaveReason::Reset)
                .await
                .unwrap();
            assert_eq!(sqlx::query_scalar::<_,String>("SELECT json_extract(runtime_overrides_json,'$.enemy.loadout.items[0].item.name') FROM encounter_actors WHERE id=?").bind(&state.actors[1].id).fetch_one(&pool).await.unwrap(),"Karabin Żółw");
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?"
                )
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                original
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT statblock_json FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                template
            );
            assert!(state.actors[2].enemy.as_ref().unwrap().loadout.is_none());
            pool.close().await;
        });
    }
    #[test]
    fn new_template_with_item_round_trips_through_catalog_and_combat() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            for a in &mut state.actors {
                if let Some(e) = &mut a.enemy {
                    e.template.loadout = Some(fixture());
                    e.loadout = Some(fixture());
                    a.prepared = None;
                }
            }
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let json: String = sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap();
            let value: serde_json::Value = serde_json::from_str(&json).unwrap();
            let loaded: Loadout = serde_json::from_value(value["loadout"].clone()).unwrap();
            assert_eq!(loaded, fixture());
            pool.close().await;
        });
    }
}
