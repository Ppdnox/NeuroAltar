use serde::{Deserialize, Serialize};
use sqlx::{Row, Sqlite, Transaction};
use std::collections::HashSet;

#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Status {
    pub id: String,
    pub system_key: Option<String>,
    pub name: String,
    pub description: String,
    pub source_text: String,
    pub duration_type: String,
    pub duration_value: Option<i64>,
    pub remaining: Option<i64>,
    pub level: Option<i64>,
}
pub fn validate(statuses: &[Status]) -> Result<(), String> {
    let names = [
        ("unconscious", "Nieprzytomność"),
        ("invisible", "Niewidoczność"),
        ("incapacitated", "Obezwładnienie"),
        ("deafened", "Ogłuchnięcie"),
        ("stunned", "Ogłuszenie"),
        ("blinded", "Oślepienie"),
        ("grappled", "Pochwycenie"),
        ("prone", "Powalenie"),
        ("frightened", "Przerażenie"),
        ("paralyzed", "Sparaliżowanie"),
        ("restrained", "Unieruchomienie"),
        ("exhaustion", "Wyczerpanie"),
        ("poisoned", "Zatrucie"),
        ("charmed", "Zauroczenie"),
        ("burning", "Podpalenie"),
    ];
    let mut ids = HashSet::new();
    let mut exhaustion = false;
    for s in statuses {
        let system_ok = s
            .system_key
            .as_ref()
            .is_none_or(|key| names.iter().any(|(k, n)| key == k && &s.name == n));
        let level_ok = if s.system_key.as_deref() == Some("exhaustion") {
            let ok = !exhaustion
                && s.level.is_some_and(|v| (1..=6).contains(&v))
                && s.duration_type == "manual";
            exhaustion = true;
            ok
        } else {
            s.level.is_none()
        };
        let time_ok = match s.duration_type.as_str() {
            "manual" | "until_start_of_turn" => s.duration_value.is_none() && s.remaining.is_none(),
            "rounds" => s.duration_value.is_some_and(|v| {
                (1..=999).contains(&v) && s.remaining.is_some_and(|r| (1..=v).contains(&r))
            }),
            "until_end_of_turn" => s.duration_value.is_none() && s.remaining == Some(1),
            "until_end_of_next_turn" => {
                s.duration_value.is_none() && s.remaining.is_some_and(|r| (1..=2).contains(&r))
            }
            _ => false,
        };
        if uuid::Uuid::parse_str(&s.id).is_err()
            || !ids.insert(&s.id)
            || s.name.trim().is_empty()
            || !system_ok
            || !level_ok
            || !time_ok
        {
            return Err("Niepoprawny status, poziom Wyczerpania lub czas trwania.".into());
        }
    }
    Ok(())
}
pub async fn read(tx: &mut Transaction<'_, Sqlite>, actor_id: &str) -> Result<Vec<Status>, String> {
    let rows = sqlx::query("SELECT status_json FROM actor_statuses WHERE actor_id=? ORDER BY id")
        .bind(actor_id)
        .fetch_all(&mut **tx)
        .await
        .map_err(|e| e.to_string())?;
    let list = rows
        .iter()
        .map(|row| {
            serde_json::from_str::<Status>(row.get("status_json")).map_err(|e| e.to_string())
        })
        .collect::<Result<Vec<_>, _>>()?;
    validate(&list)?;
    Ok(list)
}
pub async fn save(
    tx: &mut Transaction<'_, Sqlite>,
    actor_id: &str,
    statuses: &[Status],
) -> Result<(), String> {
    for s in statuses {
        let result=sqlx::query("INSERT INTO actor_statuses (id,actor_id,status_json) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET status_json=excluded.status_json WHERE actor_statuses.actor_id=excluded.actor_id")
            .bind(&s.id).bind(actor_id).bind(serde_json::to_string(s).map_err(|e|e.to_string())?)
            .execute(&mut **tx).await.map_err(|e|e.to_string())?;
        if result.rows_affected() != 1 {
            return Err("Status należy do innej postaci.".into());
        }
    }
    let ids = serde_json::to_string(&statuses.iter().map(|s| &s.id).collect::<Vec<_>>())
        .map_err(|e| e.to_string())?;
    sqlx::query("DELETE FROM actor_statuses WHERE actor_id=? AND id NOT IN (SELECT value FROM json_each(?))")
        .bind(actor_id).bind(ids).execute(&mut **tx).await.map_err(|e|e.to_string())?;
    Ok(())
}
