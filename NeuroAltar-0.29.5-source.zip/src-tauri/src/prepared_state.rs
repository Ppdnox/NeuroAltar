use super::*;

fn core(actor: &Actor) -> serde_json::Value {
    let mut value = actor.clone();
    value.prepared = None;
    value.effects.sort_by(|a, b| a.id.cmp(&b.id));
    serde_json::to_value(value).expect("validated actor")
}
fn baseline(actor: &Actor) -> Option<serde_json::Value> {
    actor.prepared.as_ref().map(|a| core(a))
}
pub fn validate_transition(
    before: &Combat,
    after: &Combat,
    reason: SaveReason,
) -> Result<(), String> {
    let error = || {
        "Stan przygotowany można zmienić tylko jawnym przygotowaniem; reset musi dokładnie odtwarzać zapisany punkt powrotu.".to_string()
    };
    if matches!(reason, SaveReason::Prepare | SaveReason::Reset) {
        if before.actors.len() != after.actors.len()
            || before
                .actors
                .iter()
                .any(|a| !after.actors.iter().any(|b| a.id == b.id))
        {
            return Err(error());
        }
    }
    if reason == SaveReason::Prepare {
        if before.round_number != after.round_number
            || before.current_turn_actor_id != after.current_turn_actor_id
        {
            return Err(error());
        }
        for actor in &after.actors {
            let old = before
                .actors
                .iter()
                .find(|a| a.id == actor.id)
                .ok_or_else(error)?;
            if core(old) != core(actor) || baseline(actor) != Some(core(actor)) {
                return Err(error());
            }
        }
    } else {
        for actor in &after.actors {
            if let Some(old) = before.actors.iter().find(|a| a.id == actor.id) {
                // Legacy callers may omit a baseline; SQL preserves it in that case.
                if actor.prepared.is_some() && baseline(old) != baseline(actor) {
                    return Err(error());
                }
            }
        }
    }
    if reason == SaveReason::Reset {
        if after.round_number != 1 || after.current_turn_actor_id.is_some() {
            return Err(error());
        }
        let mut ordered: Vec<_> = before.actors.iter().collect();
        if ordered.iter().any(|a| a.prepared.is_none()) {
            return Err(error());
        }
        ordered.sort_by(|a, b| {
            a.prepared
                .as_ref()
                .unwrap()
                .initiative_tie_order
                .cmp(&b.prepared.as_ref().unwrap().initiative_tie_order)
                .then(a.id.cmp(&b.id))
        });
        for (index, old) in ordered.iter().enumerate() {
            let mut expected = *old.prepared.clone().unwrap();
            expected.initiative_tie_order = index as i64;
            let actor = after
                .actors
                .iter()
                .find(|a| a.id == old.id)
                .ok_or_else(error)?;
            if core(&expected) != core(actor) {
                return Err(error());
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_forged_baseline_partial_reset_and_roster_changes_without_writes() {
        tauri::async_runtime::block_on(async {
            let pool = super::super::tests::database().await;
            let mut state = super::super::tests::enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut forged = state.clone();
            forged.actors[1].prepared.as_mut().unwrap().hp_current = 1;
            assert!(save_with_reason(&pool, forged, SaveReason::Edit)
                .await
                .is_err());
            state.actors[1].hp_current = 0;
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            assert!(save_with_reason(&pool, state.clone(), SaveReason::Reset)
                .await
                .is_err());
            let mut reset = super::super::tests::reset_saved(&pool, 1).await;
            reset.actors.pop();
            assert!(save_with_reason(&pool, reset, SaveReason::Reset)
                .await
                .is_err());
            let reset = super::super::tests::reset_saved(&pool, 1).await;
            let expected = reset.actors[1].hp_current;
            assert!(expected > 0);
            let revision = save_with_reason(&pool, reset, SaveReason::Reset)
                .await
                .unwrap();
            assert_eq!(revision, state.revision + 1);
        });
    }
}
