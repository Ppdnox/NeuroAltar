use super::*;
use sqlx::Row;

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ClearRequest {
    pub encounter_id: i64,
    pub revision: i64,
    pub name: String,
    pub notes: String,
    pub party_levels: Vec<i64>,
}
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClearResult {
    pub revision: i64,
    pub updated_at: String,
}

pub async fn clear(pool: &SqlitePool, request: ClearRequest) -> Result<ClearResult, String> {
    if !(1..=5).contains(&request.encounter_id)
        || request.revision < 0
        || request.revision >= 9_007_199_254_740_991
        || request.name.trim().is_empty()
        || request
            .party_levels
            .iter()
            .any(|n| *n <= 0 || *n > 9_007_199_254_740_991)
    {
        return Err("Nieprawidłowe dane potwierdzenia czyszczenia.".into());
    }
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    // Obtain a write lock before checking either metadata or combat.
    sqlx::query("UPDATE encounters SET id = id WHERE id = ?")
        .bind(request.encounter_id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let row = sqlx::query("SELECT * FROM encounters WHERE id = ?")
        .bind(request.encounter_id)
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let revision: i64 = row.get("combat_revision");
    let levels: Vec<i64> =
        serde_json::from_str(row.get("party_levels_json")).map_err(|e| e.to_string())?;
    if row.get::<String, _>("name") != request.name || levels != request.party_levels {
        return Err("Dane slotu zmieniły się od potwierdzenia. Czyszczenie przerwano.".into());
    }
    // An uncertain response can be retried, but only while the exact cleared state remains.
    if revision == request.revision + 1
        && row.get::<String, _>("notes").is_empty()
        && row.get::<i64, _>("round_number") == 1
        && row
            .get::<Option<String>, _>("current_turn_actor_id")
            .is_none()
    {
        let count: i64 = sqlx::query_scalar("SELECT (SELECT COUNT(*) FROM encounter_actors WHERE encounter_id = ?) + (SELECT COUNT(*) FROM combat_log WHERE encounter_id = ?)")
            .bind(request.encounter_id).bind(request.encounter_id).fetch_one(&mut *tx).await.map_err(|e| e.to_string())?;
        if count == 0 {
            return Ok(ClearResult {
                revision,
                updated_at: row.get("updated_at"),
            });
        }
    }
    if revision != request.revision || row.get::<String, _>("notes") != request.notes {
        return Err("Potyczka zmieniła się od potwierdzenia. Nie usunięto nowszych danych; ponownie otwórz aplikację, aby je odczytać.".into());
    }
    crate::character::participation::ensure_inactive(&mut tx, request.encounter_id).await?;
    sqlx::query("UPDATE encounters SET notes = '', round_number = 1, current_turn_actor_id = NULL, combat_revision = combat_revision + 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
        .bind(request.encounter_id).execute(&mut *tx).await.map_err(|e| e.to_string())?;
    sqlx::query("DELETE FROM encounter_actors WHERE encounter_id = ?")
        .bind(request.encounter_id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    sqlx::query("DELETE FROM combat_log WHERE encounter_id = ?")
        .bind(request.encounter_id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let updated_at = sqlx::query_scalar("SELECT updated_at FROM encounters WHERE id = ?")
        .bind(request.encounter_id)
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(ClearResult {
        revision: request.revision + 1,
        updated_at,
    })
}

#[tauri::command]
pub async fn clear_encounter(
    databases: tauri::State<'_, DbInstances>,
    request: ClearRequest,
) -> Result<ClearResult, String> {
    let pool = {
        let instances = databases.0.read().await;
        let Some(tauri_plugin_sql::DbPool::Sqlite(pool)) =
            instances.get("sqlite:combat-tracker.db")
        else {
            return Err("Baza nie jest jeszcze otwarta.".into());
        };
        pool.clone()
    };
    clear(&pool, request).await
}

#[cfg(test)]
mod tests {
    use super::*;
    async fn request(pool: &SqlitePool) -> ClearRequest {
        let row = sqlx::query("SELECT * FROM encounters WHERE id=1")
            .fetch_one(pool)
            .await
            .unwrap();
        ClearRequest {
            encounter_id: 1,
            revision: row.get("combat_revision"),
            name: row.get("name"),
            notes: row.get("notes"),
            party_levels: serde_json::from_str(row.get("party_levels_json")).unwrap(),
        }
    }
    async fn dump(pool: &SqlitePool) -> Vec<String> {
        let mut result = Vec::new();
        for table in [
            "encounters",
            "encounter_actors",
            "actor_statuses",
            "combat_log",
            "enemy_templates",
        ] {
            let rows = sqlx::query(&format!("SELECT * FROM {table} ORDER BY rowid"))
                .fetch_all(pool)
                .await
                .unwrap();
            // Snapshot every persisted column through SQLite's quote representation.
            let columns: Vec<String> = sqlx::query(&format!("PRAGMA table_info({table})"))
                .fetch_all(pool)
                .await
                .unwrap()
                .iter()
                .map(|r| format!("quote(\"{}\")", r.get::<String, _>("name")))
                .collect();
            let sql = format!(
                "SELECT {} AS snapshot FROM {table} ORDER BY rowid",
                columns.join(" || '|' || ")
            );
            result.push(format!(
                "{table}:{}:{:?}",
                rows.len(),
                sqlx::query_scalar::<_, String>(&sql)
                    .fetch_all(pool)
                    .await
                    .unwrap()
            ));
        }
        result
    }
    #[test]
    fn clear_is_atomic_scoped_idempotent_and_rejects_stale_autosave() {
        tauri::async_runtime::block_on(async {
            let pool = super::super::tests::database().await;
            let mut state = super::super::tests::enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            sqlx::query("UPDATE encounters SET party_levels_json='[4,5]' WHERE id=1")
                .execute(&pool)
                .await
                .unwrap();
            sqlx::query("UPDATE encounters SET notes='Drugi slot' WHERE id=2")
                .execute(&pool)
                .await
                .unwrap();
            let effect: status::Status = serde_json::from_value(serde_json::json!({"id":"00000000-0000-4000-8000-000000000077","systemKey":null,"name":"Test","description":"Zażółć\nDrugi","sourceText":"MG","durationType":"manual","durationValue":null,"remaining":null,"level":null})).unwrap();
            state.actors[0].effects = vec![effect];
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut other = state.clone();
            other.encounter_id = 2;
            other.revision = 0;
            other.current_turn_actor_id = None;
            other.actors.truncate(1);
            other.actors[0].id = "00000000-0000-4000-8000-000000000088".into();
            other.actors[0].prepared = None;
            other.actors[0].effects[0].id = "00000000-0000-4000-8000-000000000089".into();
            save_to_pool(&pool, other).await.unwrap();
            let other_before: Vec<String> = sqlx::query_scalar("SELECT prepared_snapshot_json || runtime_overrides_json FROM encounter_actors WHERE encounter_id=2").fetch_all(&pool).await.unwrap();
            let req = request(&pool).await;
            let before = dump(&pool).await;
            sqlx::raw_sql("CREATE TRIGGER block_clear BEFORE DELETE ON combat_log BEGIN SELECT RAISE(ABORT,'disk full'); END;").execute(&pool).await.unwrap();
            assert!(clear(&pool, req.clone()).await.is_err());
            assert_eq!(dump(&pool).await, before);
            sqlx::raw_sql("DROP TRIGGER block_clear")
                .execute(&pool)
                .await
                .unwrap();
            let result = clear(&pool, req.clone()).await.unwrap();
            assert_eq!(result.revision, state.revision + 1);
            assert_eq!(
                clear(&pool, req.clone()).await.unwrap().revision,
                result.revision
            );
            assert!(save_to_pool(&pool, state).await.is_err());
            let counts: (i64,i64,i64,i64,i64) = sqlx::query_as("SELECT (SELECT count(*) FROM encounters), (SELECT count(*) FROM encounter_actors), (SELECT count(*) FROM actor_statuses), (SELECT count(*) FROM combat_log), (SELECT count(*) FROM enemy_templates)").fetch_one(&pool).await.unwrap();
            assert_eq!((counts.0, counts.1, counts.2, counts.4), (5, 1, 1, 1));
            assert!(counts.3 > 0);
            assert_eq!(sqlx::query_scalar::<_,String>("SELECT prepared_snapshot_json || runtime_overrides_json FROM encounter_actors WHERE encounter_id=2").fetch_all(&pool).await.unwrap(), other_before);
            let row = sqlx::query("SELECT * FROM encounters WHERE id=1")
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(row.get::<String, _>("name"), req.name);
            assert_eq!(row.get::<String, _>("party_levels_json"), "[4,5]");
            assert_eq!(row.get::<String, _>("notes"), "");
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT notes FROM encounters WHERE id=2")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                "Drugi slot"
            );
            sqlx::query("UPDATE encounters SET notes='Nowe dane' WHERE id=1")
                .execute(&pool)
                .await
                .unwrap();
            assert!(clear(&pool, req).await.is_err());
        });
    }
    #[test]
    fn changed_metadata_and_revision_abort_before_any_delete() {
        tauri::async_runtime::block_on(async {
            let pool = super::super::tests::database().await;
            save_to_pool(&pool, super::super::tests::enemy_state())
                .await
                .unwrap();
            let req = request(&pool).await;
            for sql in [
                "UPDATE encounters SET notes='Nowsze' WHERE id=1",
                "UPDATE encounters SET name='Inna nazwa' WHERE id=1",
                "UPDATE encounters SET party_levels_json='[8]' WHERE id=1",
                "UPDATE encounters SET combat_revision=combat_revision+2 WHERE id=1",
            ] {
                sqlx::query(sql).execute(&pool).await.unwrap();
                let before = dump(&pool).await;
                assert!(clear(&pool, req.clone()).await.is_err());
                assert_eq!(dump(&pool).await, before);
            }
        });
    }
}
