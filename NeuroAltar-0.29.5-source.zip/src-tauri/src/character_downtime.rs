use super::*;
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Material {
    id: String,
    quantity: i64,
    #[serde(rename = "valueGb")]
    value_gb: f64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Recipe {
    cost: i64,
    minutes: i64,
    dc: i64,
    source: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Project {
    id: String,
    label: String,
    output: Value,
    price: f64,
    single_use: bool,
    #[serde(default)]
    repair_id: Option<String>,
    tools: String,
    proficient: bool,
    schematic: bool,
    materials: Vec<Material>,
    #[serde(rename = "override")]
    special: Option<Recipe>,
    cost: i64,
    minutes: i64,
    dc: i64,
    progress: i64,
    status: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Training {
    id: String,
    target: String,
    minutes: i64,
    completed: bool,
    #[serde(rename = "afterLevel")]
    after_level: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Benefit {
    id: String,
    label: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    kind: Option<String>,
    expires_at: Option<i64>,
    refresh: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Default)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Downtime {
    projects: Vec<Project>,
    work: std::collections::BTreeMap<String, i64>,
    rest_work: std::collections::BTreeMap<String, i64>,
    cleaned: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    medic_kit_uses: Option<std::collections::BTreeMap<String, i64>>,
    medpak_uses: std::collections::BTreeMap<String, i64>,
    training: Vec<Training>,
    benefits: Vec<Benefit>,
}
fn num(v: &Value, k: &str) -> Result<i64, String> {
    v[k].as_i64().ok_or_else(|| format!("Brak liczby: {k}"))
}
fn string<'a>(v: &'a Value, k: &str) -> Result<&'a str, String> {
    v[k].as_str().ok_or_else(|| format!("Brak tekstu: {k}"))
}
pub(super) fn has_feat(sheet: &Value, f: &str) -> bool {
    sheet["levels"].as_array().unwrap().iter().any(|l| {
        ["start", "feat", "profession-feat"].iter().any(|k| {
            l["choices"][*k]
                .as_array()
                .is_some_and(|a| a.contains(&json!(f)))
        })
    })
}
fn class_level(sheet: &Value, class: &str) -> i64 {
    sheet["levels"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|l| l["classId"] == class)
        .count() as i64
}
fn has_choice(sheet: &Value, value: &str) -> bool {
    sheet["levels"].as_array().unwrap().iter().any(|l| {
        l["choices"]
            .as_object()
            .unwrap()
            .values()
            .any(|v| v.as_array().is_some_and(|a| a.contains(&json!(value))))
    })
}
fn has_profession(sheet: &Value, value: &str) -> bool {
    sheet["levels"].as_array().unwrap().iter().any(|l| {
        l["choices"]["profession-ability"]
            .as_array()
            .is_some_and(|a| a.contains(&json!(value)))
    })
}
fn medic_kit(inv: &Value, idv: &str) -> Result<(), String> {
    let e = inv["entries"]
        .as_array()
        .unwrap()
        .iter()
        .find(|e| e["id"] == idv)
        .ok_or("Brak narzędzi medyka.")?;
    let name = string(&e["item"], "name")?.to_lowercase();
    need(name.contains("medyk") && !name.contains("uzupełnienie"))
}
fn materials(m: &[Material]) -> Result<(), String> {
    need(m.len() <= 50)?;
    unique(m.iter().map(|m| m.id.as_str()))?;
    for x in m {
        id(&x.id)?;
        need((1..=1000000000).contains(&x.quantity) && (0.0..=1000000.0).contains(&x.value_gb))?;
    }
    Ok(())
}
pub(super) fn validate(d: &Downtime) -> Result<(), String> {
    need(
        d.projects.len() <= 100
            && d.training.len() <= 100
            && d.benefits.len() <= 100
            && d.cleaned.len() <= 5000,
    )?;
    unique(d.projects.iter().map(|p| p.id.as_str()))?;
    unique(d.training.iter().map(|p| p.id.as_str()))?;
    unique(d.benefits.iter().map(|p| p.id.as_str()))?;
    unique(d.cleaned.iter().map(String::as_str))?;
    for p in &d.projects {
        id(&p.id)?;
        text(&p.label)?;
        text(&p.tools)?;
        need(
            (0.0..=1000000.0).contains(&p.price)
                && (0..=100).contains(&p.dc)
                && ["working", "complete", "cancelled"].contains(&p.status.as_str()),
        )?;
        for n in [p.cost, p.minutes, p.progress] {
            need((0..=1000000000).contains(&n))?;
        }
        materials(&p.materials)?;
        let inv = json!({"entries":[p.output],"ammoMode":"auto","starterClaims":[]});
        if p.repair_id.is_none() {
            super::super::inventory::validate(&inv)?;
        }
        if let Some(r) = &p.special {
            text(&r.source)?;
            need(r.cost >= 0 && r.minutes >= 0 && (0..=100).contains(&r.dc))?;
        }
    }
    for t in &d.training {
        id(&t.id)?;
        text(&t.target)?;
        need((0..=1000000000).contains(&t.minutes))?;
    }
    if let Some(uses) = &d.medic_kit_uses {
        for (key, count) in uses {
            id(key)?;
            need((0..=5).contains(count))?;
        }
    }
    for b in &d.benefits {
        need(
            b.kind
                .as_deref()
                .is_none_or(|k| ["mealSave", "ar23Social"].contains(&k)),
        )?;
        id(&b.id)?;
        text(&b.label)?;
        need(["manual", "long"].contains(&b.refresh.as_str()))?;
        if let Some(n) = b.expires_at {
            need((0..=1000000000).contains(&n))?;
        }
    }
    for n in d
        .work
        .values()
        .chain(d.rest_work.values())
        .chain(d.medpak_uses.values())
    {
        need((0..=1000000000).contains(n))?;
    }
    for x in &d.cleaned {
        id(x)?;
    }
    Ok(())
}
fn work(d: &mut Downtime, s: &mut State, day: &str, minutes: i64) -> Result<(), String> {
    need(minutes > 0 && d.work.get(day).unwrap_or(&0) + minutes <= 600)?;
    if let Some(r) = &s.rest {
        let n = d.rest_work.get(&r.id).copied().unwrap_or(0);
        need(r.kind != "short" || n + minutes <= 60)?;
        d.rest_work.insert(r.id.clone(), n + minutes);
    }
    *d.work.entry(day.into()).or_default() += minutes;
    if s.rest.is_none() {
        need(s.world_minutes / 1440 == (s.world_minutes + minutes - 1) / 1440)?;
        s.world_minutes += minutes;
    }
    Ok(())
}
fn consume(i: &mut Value, idv: &str, qty: i64) -> Result<(), String> {
    let e = i["entries"]
        .as_array_mut()
        .unwrap()
        .iter_mut()
        .find(|e| e["id"] == idv)
        .ok_or("Brak materiału.")?;
    let n = num(e, "quantityMilli")?;
    need(
        qty > 0
            && qty <= n
            && e["weapon"].is_null()
            && e["magazine"].is_null()
            && e["container"] == false,
    )?;
    e["quantityMilli"] = json!(n - qty);
    Ok(())
}
pub(super) fn expire(d: &mut Option<Downtime>, now: i64, long: bool) {
    if let Some(d) = d {
        d.benefits
            .retain(|b| b.expires_at.is_none_or(|t| t > now) && !(long && b.refresh == "long"));
    }
}
pub(super) fn apply(
    old: &Character,
    s: &mut State,
    a: &Value,
    op: &str,
    hp_max: i64,
) -> Result<Value, String> {
    let mut d = s.downtime.clone().unwrap_or_default();
    validate(&d)?;
    let mut inv = old
        .inventory
        .clone()
        .unwrap_or_else(super::super::inventory::empty);
    let sheet = old.sheet.as_ref().unwrap();
    let day = (s.world_minutes / 1440).to_string();
    let kind = string(a, "kind")?;
    let keys: &[&str] = match kind {
        "quickProduction" => &[
            "kind",
            "products",
            "tools",
            "proficient",
            "schematic",
            "materials",
        ],
        "medicalAid" => &[
            "kind",
            "patient",
            "kitId",
            "inReach",
            "handsFree",
            "total",
            "rolls",
        ],
        "refillMedicKit" => &["kind", "kitId", "entryId"],
        "resuscitate" => &[
            "kind",
            "patient",
            "minutesSincePulse",
            "massiveDamage",
            "total",
        ],
        "project" => &["kind", "project"],
        "work" => &["kind", "id", "minutes", "finish", "total"],
        "cancelProject" => &["kind", "id", "reason"],
        "clean" => &["kind", "weaponId", "tools"],
        "cook" => &["kind", "tools", "ingredients", "total"],
        "healingItem" => &["kind", "entryId", "formula", "rolls", "wisSave"],
        "training" => &["kind", "id", "target", "minutes", "teacher", "paid"],
        "removeBenefit" => &["kind", "id", "reason"],
        _ => return Err("Nieznana czynność postoju.".into()),
    };
    need(
        a.as_object()
            .is_some_and(|o| o.len() == keys.len() && o.keys().all(|k| keys.contains(&k.as_str()))),
    )?;
    match kind {
        "quickProduction" => {
            let level = class_level(sheet, "spec");
            need(level >= 3 && s.spent.get("production").copied().unwrap_or(0) < 1)?;
            text(string(a, "tools")?)?;
            need(a["proficient"] == true && a["schematic"] == true)?;
            let products = a["products"].as_array().ok_or("Brak produktów.")?;
            need(!products.is_empty() && products.len() <= 50)?;
            let mut price = 0.;
            let mut ids = std::collections::HashSet::new();
            for p in products {
                need(p.as_object().is_some_and(|o| {
                    o.len() == 2 && o.contains_key("output") && o.contains_key("price")
                }))?;
                let cost = p["price"].as_f64().ok_or("Brak ceny.")?;
                need(cost > 0. && cost <= 50.)?;
                price += cost;
                let output = &p["output"];
                let eid = string(output, "id")?;
                need(
                    ids.insert(eid)
                        && !inv["entries"]
                            .as_array()
                            .unwrap()
                            .iter()
                            .any(|e| e["id"] == eid),
                )?;
                need(
                    output["quantityMilli"] == 1000
                        && output["container"] == false
                        && output["parentId"].is_null()
                        && output["slot"] == "none",
                )?;
                if let Some(range) = output["item"]["basePrice"].as_object() {
                    need(
                        cost >= range["min"].as_f64().unwrap()
                            && cost <= range["max"].as_f64().unwrap(),
                    )?;
                }
            }
            need(price <= if level >= 11 { 50. } else { 25. })?;
            let m: Vec<Material> =
                serde_json::from_value(a["materials"].clone()).map_err(|e| e.to_string())?;
            materials(&m)?;
            let cost =
                ((price / 2.).floor() * if has_feat(sheet, "supplies") { 0.5 } else { 1. }).floor();
            need(!m.is_empty() && m.iter().map(|m| m.value_gb).sum::<f64>() >= cost)?;
            let minutes = (price
                * if has_feat(sheet, "fabricator") {
                    0.5
                } else {
                    1.
                })
            .floor() as i64;
            if minutes > 0 {
                work(&mut d, s, &day, minutes)?;
            }
            for material in &m {
                consume(&mut inv, &material.id, material.quantity)?;
            }
            for p in products {
                inv["entries"]
                    .as_array_mut()
                    .unwrap()
                    .push(p["output"].clone());
            }
            *s.spent.entry("production".into()).or_default() += 1;
        }
        "medicalAid" => {
            text(string(a, "patient")?)?;
            let kit_id = string(a, "kitId")?;
            medic_kit(&inv, kit_id)?;
            let trained = has_choice(sheet, "tool:medic")
                || d.training
                    .iter()
                    .any(|t| t.completed && t.target == "tool:medic");
            need(trained && a["inReach"] == true && a["handsFree"] == true)?;
            let total = num(a, "total")?;
            need((-100..=200).contains(&total))?;
            let base = if total < 5 {
                0
            } else if total < 15 {
                1
            } else {
                (total / 5 - 1).min(4)
            };
            let count = base
                + if base > 0 && has_feat(sheet, "plaster") {
                    1
                } else {
                    0
                };
            let sides = if has_profession(sheet, "medic.1") {
                6 + 2 * (class_level(sheet, "spec") / 3 - 1).clamp(0, 3)
            } else {
                4
            };
            let rolls = a["rolls"].as_array().ok_or("Brak rzutów.")?;
            need(
                rolls.len() as i64 == count
                    && rolls
                        .iter()
                        .all(|r| r.as_i64().is_some_and(|n| n >= 1 && n <= sides)),
            )?;
            let uses = d.medic_kit_uses.get_or_insert_with(Default::default);
            let spent = uses.get(kit_id).copied().unwrap_or(0);
            need(spent < 5)?;
            uses.insert(kit_id.into(), spent + 1);
        }
        "refillMedicKit" => {
            let kit_id = string(a, "kitId")?;
            medic_kit(&inv, kit_id)?;
            let eid = string(a, "entryId")?;
            let entry = inv["entries"]
                .as_array()
                .unwrap()
                .iter()
                .find(|e| e["id"] == eid)
                .ok_or("Brak uzupełnienia.")?;
            let name = string(&entry["item"], "name")?.to_lowercase();
            need(name.contains("uzupełnienie") && name.contains("medyk"))?;
            let uses = d.medic_kit_uses.get_or_insert_with(Default::default);
            let spent = uses.get(kit_id).copied().unwrap_or(0);
            need(spent > 0)?;
            consume(&mut inv, eid, 1000)?;
            uses.insert(kit_id.into(), spent - 1);
        }
        "resuscitate" => {
            text(string(a, "patient")?)?;
            need(has_profession(sheet, "medic.2") && a["massiveDamage"] == false)?;
            let elapsed = a["minutesSincePulse"].as_f64().ok_or("Brak czasu.")?;
            need(elapsed > 0. && elapsed <= 8. && (-100..=200).contains(&num(a, "total")?))?;
            work(&mut d, s, &day, 1)?;
        }
        "project" => {
            let mut raw = a["project"].clone();
            let price = raw["price"].as_f64().ok_or("Brak ceny.")?;
            let single = raw["singleUse"].as_bool().ok_or("Brak rodzaju.")?;
            let (cost, minutes, dc) = if raw["override"].is_null() {
                (
                    ((price / 2.).floor() * if has_feat(sheet, "supplies") { 0.5 } else { 1. })
                        .floor() as i64,
                    (price
                        * if single { 30. } else { 60. }
                        * if has_feat(sheet, "fabricator") {
                            0.5
                        } else {
                            1.
                        })
                    .floor() as i64,
                    if price <= 10. {
                        5
                    } else if price <= 25. {
                        10
                    } else if price <= 50. {
                        15
                    } else if price <= 75. {
                        20
                    } else if price <= 100. {
                        25
                    } else {
                        30
                    },
                )
            } else {
                (
                    num(&raw["override"], "cost")?,
                    num(&raw["override"], "minutes")?,
                    num(&raw["override"], "dc")?,
                )
            };
            for k in ["cost", "minutes", "dc", "progress", "status"] {
                need(raw.get(k).is_none())?;
            }
            raw["cost"] = json!(cost);
            raw["minutes"] = json!(minutes);
            raw["dc"] = json!(dc);
            raw["progress"] = json!(0);
            raw["status"] = json!("working");
            let p: Project = serde_json::from_value(raw).map_err(|e| e.to_string())?;
            need(
                !d.projects.iter().any(|x| x.id == p.id)
                    && p.proficient
                    && !p.tools.trim().is_empty()
                    && (p.price <= 10. || p.schematic),
            )?;
            if let Some(range) = p.output["item"]["basePrice"].as_object() {
                need(
                    p.price >= range["min"].as_f64().unwrap()
                        && p.price <= range["max"].as_f64().unwrap(),
                )?;
            }
            if let Some(rid) = &p.repair_id {
                let mut old = inv["entries"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|e| e["id"] == *rid)
                    .ok_or("Brak naprawianego egzemplarza.")?
                    .clone();
                old["armorDamage"] = json!(0);
                need(super::super::inventory::same(&old, &p.output) && p.special.is_some())?;
            } else {
                need(
                    p.output["quantityMilli"] == 1000
                        && p.output["container"] == false
                        && p.output["parentId"].is_null()
                        && p.output["slot"] == "none",
                )?;
            }
            need(p.materials.iter().map(|m| m.value_gb).sum::<f64>() >= p.cost as f64)?;
            for m in &p.materials {
                let e = inv["entries"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|e| e["id"] == m.id)
                    .ok_or("Brak materiału.")?;
                need(m.quantity > 0 && num(e, "quantityMilli")? >= m.quantity)?;
            }
            d.projects.push(p);
        }
        "work" => {
            let idx = d
                .projects
                .iter()
                .position(|p| p.id == a["id"] && p.status == "working")
                .ok_or("Brak projektu.")?;
            let minutes = num(a, "minutes")?;
            work(&mut d, s, &day, minutes)?;
            let p = &mut d.projects[idx];
            p.progress += minutes;
            let finish = a["finish"].as_bool().ok_or("Brak wyniku.")?;
            if finish {
                let total = num(a, "total")?;
                need((-100..=200).contains(&total) && p.progress >= p.minutes)?;
                if total >= p.dc {
                    for m in &p.materials {
                        consume(&mut inv, &m.id, m.quantity)?;
                    }
                    if let Some(rid) = &p.repair_id {
                        let e = inv["entries"]
                            .as_array_mut()
                            .unwrap()
                            .iter_mut()
                            .find(|e| e["id"] == *rid)
                            .ok_or("Brak egzemplarza.")?;
                        let mut adjusted = e.clone();
                        adjusted["armorDamage"] = json!(0);
                        need(super::super::inventory::same(&adjusted, &p.output))?;
                        *e = p.output.clone();
                    } else {
                        need(
                            !inv["entries"]
                                .as_array()
                                .unwrap()
                                .iter()
                                .any(|e| e["id"] == p.output["id"]),
                        )?;
                        inv["entries"]
                            .as_array_mut()
                            .unwrap()
                            .push(p.output.clone());
                    }
                    p.status = "complete".into();
                } else {
                    p.progress = 0;
                }
            }
        }
        "cancelProject" => {
            text(string(a, "reason")?)?;
            let p = d
                .projects
                .iter_mut()
                .find(|p| p.id == a["id"] && p.status == "working")
                .ok_or("Brak projektu.")?;
            p.status = "cancelled".into();
        }
        "clean" => {
            let wid = string(a, "weaponId")?;
            let e = inv["entries"]
                .as_array()
                .unwrap()
                .iter()
                .find(|e| e["id"] == wid)
                .ok_or("Brak broni.")?;
            need(
                e["weapon"].is_object()
                    && !["melee", "thrown", "improvised"]
                        .contains(&e["weapon"]["category"].as_str().unwrap_or("melee"))
                    && a["tools"] == true,
            )?;
            work(&mut d, s, &day, 60)?;
            if !d.cleaned.contains(&wid.into()) {
                d.cleaned.push(wid.into());
            }
        }
        "cook" => {
            need(a["tools"] == true)?;
            work(&mut d, s, &day, 120)?;
            let m: Vec<Material> =
                serde_json::from_value(a["ingredients"].clone()).map_err(|e| e.to_string())?;
            materials(&m)?;
            need(!m.is_empty())?;
            for x in m {
                consume(&mut inv, &x.id, x.quantity)?;
            }
            let total = num(a, "total")?;
            need((-100..=200).contains(&total))?;
            if total >= 10 {
                d.benefits.push(Benefit {
                    id: op.into(),
                    label: "Posiłek: Ułatwienie najbliższego dowolnego RO".into(),
                    kind: Some("mealSave".into()),
                    expires_at: None,
                    refresh: "manual".into(),
                });
            }
            if total >= 20 && sheet["rulesContext"]["gameColor"] != "mercury" {
                s.fuks.push(Fuks {
                    id: op.into(),
                    source: format!("Posiłek — wynik {total}"),
                    kind: "meal".into(),
                    expires_at: Some(s.world_minutes + 1440),
                    session: None,
                });
            }
        }
        "healingItem" => {
            need(sheet["rulesContext"]["gameColor"] != "mercury")?;
            let eid = string(a, "entryId")?;
            let formula = string(a, "formula")?;
            need(["medpak", "ar23"].contains(&formula))?;
            let ar = formula == "ar23";
            let e = inv["entries"]
                .as_array()
                .unwrap()
                .iter()
                .find(|e| e["id"] == eid)
                .ok_or("Brak środka.")?;
            let name = string(&e["item"], "name")?.to_lowercase();
            need(if ar {
                ["ar23", "ar-23", "ar 23"].contains(&name.as_str())
            } else {
                name == "medpak"
            })?;
            let rolls = a["rolls"].as_array().ok_or("Brak rzutów.")?;
            need(
                rolls.len()
                    == (if ar { 4 } else { 2 }) + if has_feat(sheet, "plaster") { 1 } else { 0 }
                    && rolls
                        .iter()
                        .all(|r| r.as_i64().is_some_and(|n| (1..=6).contains(&n)))
                    && d.medpak_uses.get(&day).copied().unwrap_or(0) < 2,
            )?;
            consume(&mut inv, eid, 1000)?;
            *d.medpak_uses.entry(day.clone()).or_default() += 1;
            let diet = sheet["originId"] == "desert"
                && sheet["levels"].as_array().unwrap().iter().any(|l| {
                    l["choices"].as_object().unwrap().iter().any(|(k, v)| {
                        k.contains("origin")
                            && v.as_array().is_some_and(|a| a.contains(&json!("diet")))
                    })
                });
            let hp = (rolls.iter().map(|v| v.as_i64().unwrap()).sum::<i64>()
                + if ar { 4 } else { 2 })
                * if diet { 2 } else { 1 };
            s.hp = (s.hp + hp).min(hp_max);
            if ar {
                let total = num(a, "wisSave")?;
                need((-100..=200).contains(&total))?;
                if total < 15 {
                    d.benefits.push(Benefit {
                        id: op.into(),
                        label: "AR-23: Utrudnienie Perswazji i Oszustwa".into(),
                        kind: Some("ar23Social".into()),
                        expires_at: None,
                        refresh: "long".into(),
                    });
                }
            }
        }
        "training" => {
            let minutes = num(a, "minutes")?;
            let target = string(a, "target")?;
            let paid = a["paid"].as_f64().ok_or("Brak kosztu.")?;
            need(a["teacher"] == true && paid >= minutes as f64 / 60. && paid <= 10000.)?;
            let parts: Vec<_> = target.split(':').collect();
            need(
                parts.len() == 2
                    && ["skill", "tool", "weapon", "armor"].contains(&parts[0])
                    && !parts[1].is_empty()
                    && parts[1].chars().all(|c| c.is_ascii_lowercase()),
            )?;
            work(&mut d, s, &day, minutes)?;
            let idv = string(a, "id")?;
            id(idv)?;
            if !d.training.iter().any(|t| t.id == idv) {
                d.training.push(Training {
                    id: idv.into(),
                    target: target.into(),
                    minutes: 0,
                    completed: false,
                    after_level: sheet["levels"].as_array().unwrap().len() as i64,
                });
            }
            let t = d.training.iter_mut().find(|t| t.id == idv).unwrap();
            need(!t.completed && t.target == target)?;
            t.minutes += minutes;
            t.completed = t.minutes >= 18000;
            if t.completed {
                t.after_level = sheet["levels"].as_array().unwrap().len() as i64;
            }
        }
        "removeBenefit" => {
            text(string(a, "reason")?)?;
            need(d.benefits.iter().any(|b| b.id == a["id"]))?;
            d.benefits.retain(|b| b.id != a["id"]);
        }
        _ => unreachable!(),
    }
    validate(&d)?;
    super::super::inventory::validate(&inv)?;
    s.downtime = Some(d);
    Ok(inv)
}

pub(super) fn rad_off(s: &mut State, op: &str, failed: bool) {
    if failed {
        let d = s.downtime.get_or_insert_with(Downtime::default);
        d.benefits.push(Benefit {
            id: op.into(),
            label: "RadOff: przez minutę nie możesz wykonywać akcji".into(),
            kind: None,
            expires_at: Some(s.world_minutes + 1),
            refresh: "manual".into(),
        });
    }
}
