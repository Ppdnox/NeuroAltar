#[path = "character_care.rs"]
mod care;
#[path = "character_downtime.rs"]
mod downtime;
use super::Character;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Effect {
    id: String,
    source: String,
    target: String,
    amount: i64,
    refresh: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Exhaustion {
    id: String,
    cause: String,
    source: String,
    level: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Manual {
    id: String,
    label: String,
    max: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Block {
    id: String,
    source: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Fuks {
    id: String,
    source: String,
    kind: String,
    expires_at: Option<i64>,
    session: Option<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Rest {
    id: String,
    kind: String,
    color: String,
    context_revision: i64,
    hp_at_start: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    started_at: Option<i64>,
    elapsed: i64,
    last_short_at: i64,
    interruptions: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Journal {
    id: String,
    text: String,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Dice {
    #[serde(rename = "6")]
    six: i64,
    #[serde(rename = "8")]
    eight: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct State {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    combat_health: Option<CombatHealth>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    care: Option<care::Care>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    downtime: Option<downtime::Downtime>,
    hp: i64,
    hit_dice_spent: Dice,
    spent: std::collections::BTreeMap<String, i64>,
    manual: Vec<Manual>,
    effects: Vec<Effect>,
    injury: i64,
    exhaustion: Vec<Exhaustion>,
    rest_blocks: Vec<Block>,
    rest: Option<Rest>,
    completed_rests: Vec<String>,
    long_streak: i64,
    fuks: Vec<Fuks>,
    start_fuks_claimed: bool,
    session: Option<String>,
    sessions: Vec<String>,
    world_minutes: i64,
    journal: Vec<Journal>,
}
#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Resource {
    id: String,
    label: String,
    max: i64,
    refresh: String,
    page: i64,
    cost_max: i64,
    note: String,
    unresolved: bool,
}
#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Context {
    hp_max: i64,
    long_hp_max: i64,
    con: i64,
    hit_dice: Dice,
    resources: Vec<Resource>,
    long_resources: Vec<Resource>,
    tough_level: i64,
}
#[derive(Clone, Debug, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase", deny_unknown_fields)]
enum Action {
    CombatHealth {
        command: Value,
    },
    Downtime {
        command: Value,
    },
    Care {
        command: Value,
    },
    CombatAbility {
        #[serde(rename = "combatApplication")]
        combat_application: Value,
    },
    Use {
        #[serde(rename = "combatApplication", default)]
        combat_application: Option<Value>,
        #[serde(rename = "combatChoice", default)]
        combat_choice: Option<String>,
        #[serde(rename = "resourceId")]
        resource_id: String,
        amount: i64,
        #[serde(rename = "healingRoll")]
        healing_roll: Option<i64>,
    },
    Correct {
        hp: i64,
        injury: i64,
        #[serde(rename = "hitDiceSpent")]
        hit_dice_spent: Dice,
        reason: String,
    },
    ResourceStep {
        id: String,
        direction: String,
    },
    Resource {
        id: String,
        spent: i64,
        reason: String,
    },
    Manual {
        entry: Manual,
        reason: String,
    },
    Effect {
        entry: Effect,
    },
    Exhaustion {
        entry: Exhaustion,
    },
    ExhaustionReduce {
        id: String,
    },
    Block {
        id: String,
        source: String,
    },
    Remove {
        group: String,
        id: String,
        reason: String,
    },
    RestStart {
        id: String,
        kind: String,
    },
    RestCancel {
        reason: String,
    },
    RestApply {
        #[serde(rename = "sessionId")]
        session_id: String,
        outcome: String,
        elapsed: i64,
        sleep: i64,
        armored: bool,
        consecutive: bool,
        food: bool,
        water: bool,
        warm: bool,
        #[serde(rename = "exhaustionId")]
        exhaustion_id: Option<String>,
        #[serde(rename = "medicProficient")]
        medic_proficient: bool,
        #[serde(rename = "medicTools")]
        medic_tools: bool,
        #[serde(rename = "healingSave")]
        healing_save: Option<i64>,
        rolls6: Vec<i64>,
        rolls8: Vec<i64>,
        #[serde(rename = "kolejkaLevel")]
        kolejka_level: i64,
        #[serde(rename = "kolejkaRolls")]
        kolejka_rolls: Vec<i64>,
    },
    FuksGrant {
        entry: Fuks,
    },
    FuksUse {
        id: String,
    },
    Session {
        id: String,
    },
    SessionEnd,
    WorldTime {
        minutes: i64,
    },
}
fn need(ok: bool) -> Result<(), String> {
    if ok {
        Ok(())
    } else {
        Err(
            "Zdrowie lub odpoczynek: niepoprawne dane albo niespełnione warunki. Sprawdź podgląd."
                .into(),
        )
    }
}
fn count(n: i64) -> Result<(), String> {
    need((0..=100000).contains(&n))
}
fn text(s: &str) -> Result<(), String> {
    need(!s.trim().is_empty() && s.chars().count() <= 300)
}
fn id(s: &str) -> Result<(), String> {
    uuid::Uuid::parse_str(s)
        .map(|_| ())
        .map_err(|_| "Niepoprawny identyfikator zdrowia.".into())
}
fn unique<'a>(ids: impl Iterator<Item = &'a str>) -> Result<(), String> {
    let mut seen = std::collections::HashSet::new();
    for v in ids {
        need(seen.insert(v))?;
    }
    Ok(())
}
fn parse(v: &Value) -> Result<State, String> {
    serde_json::from_value(v.clone()).map_err(|e| format!("Niepoprawny stan zdrowia: {e}"))
}
pub(super) fn spend_roll_resource(
    c: &Character,
    resource: &str,
    targets: &[String],
    sides: i64,
    failed: bool,
    operation: &str,
) -> Result<Value, String> {
    need(c.sheet.is_some() && c.draft.is_none() && !c.archived)?;
    let sheet = c.sheet.as_ref().unwrap();
    let levels = sheet["levels"].as_array().ok_or("Brak poziomów.")?;
    let n = |name: &str| levels.iter().filter(|l| l["classId"] == name).count() as i64;
    let has = |target: &str| targets.iter().any(|t| t == target);
    let (ability, expected) = match resource {
        "toughness" => {
            need(n("twardziel") >= 3 && has("save") && failed)?;
            ("con", 2 + 2 * (n("twardziel") / 3))
        }
        "amen" => {
            need(
                failed
                    && levels.iter().any(|l| {
                        l["choices"]["profession-ability"]
                            .as_array()
                            .is_some_and(|v| v.contains(&json!("preacher.0")))
                    }),
            )?;
            ("cha", 6)
        }
        "cat" => {
            let level = n("zlodziej");
            need(
                level >= 2
                    && (has("skill:acrobatics")
                        || (level >= 5 && has("initiative"))
                        || (level >= 9 && has("save"))),
            )?;
            ("dex", 4 + 2 * ((level - 2) / 3))
        }
        _ => return Err("Nieznana kość zdolności.".into()),
    };
    need(sides == expected)?;
    let max = current_modifier(c, ability)?.max(0);
    let mut state = c
        .condition
        .as_ref()
        .map(parse)
        .transpose()?
        .unwrap_or_else(|| empty(c));
    let spent = state.spent.entry(resource.into()).or_default();
    need(*spent < max)?;
    *spent += 1;
    state.journal.push(Journal {
        id: operation.into(),
        text: format!("Dodatkowa kość {resource}: 1k{sides}; zużyto 1 użycie."),
    });
    check(&state)?;
    serde_json::to_value(state).map_err(|e| e.to_string())
}

pub fn validate(v: &Value) -> Result<(), String> {
    let s = parse(v)?;
    check(&s)
}
fn check(s: &State) -> Result<(), String> {
    if let Some(h) = &s.combat_health {
        need((0..=3).contains(&h.successes) && (0..=3).contains(&h.failures))?;
    }
    if let Some(d) = &s.downtime {
        downtime::validate(d)?;
    }
    if let Some(c) = &s.care {
        care::validate(c)?;
    }
    for n in [
        s.hp,
        s.hit_dice_spent.six,
        s.hit_dice_spent.eight,
        s.long_streak,
    ] {
        count(n)?;
    }
    need((0..=1000000000).contains(&s.world_minutes))?;
    need(
        (0..=5).contains(&s.injury)
            && s.manual.len() <= 100
            && s.effects.len() <= 100
            && s.exhaustion.len() <= 100
            && s.rest_blocks.len() <= 30
            && s.fuks.len() <= 100
            && s.completed_rests.len() <= 10000
            && s.sessions.len() <= 10000
            && s.journal.len() <= 10000
            && s.spent.len() <= 200,
    )?;
    for (k, n) in &s.spent {
        text(k)?;
        need(k.len() <= 100)?;
        count(*n)?;
    }
    for e in &s.manual {
        id(&e.id)?;
        text(&e.label)?;
        count(e.max)?;
    }
    unique(s.manual.iter().map(|e| e.id.as_str()))?;
    for e in &s.effects {
        id(&e.id)?;
        text(&e.source)?;
        need(
            ["hpMax", "str", "dex", "con", "int", "wis", "cha"].contains(&e.target.as_str())
                && ["long", "manual"].contains(&e.refresh.as_str()),
        )?;
        count(e.amount)?;
    }
    unique(s.effects.iter().map(|e| e.id.as_str()))?;
    for e in &s.exhaustion {
        id(&e.id)?;
        text(&e.source)?;
        need(
            [
                "ordinary",
                "hunger",
                "thirst",
                "cold",
                "radiation",
                "suffocation",
                "disease",
                "manual",
            ]
            .contains(&e.cause.as_str())
                && (1..=6).contains(&e.level),
        )?;
    }
    unique(s.exhaustion.iter().map(|e| e.id.as_str()))?;
    for e in &s.rest_blocks {
        id(&e.id)?;
        text(&e.source)?;
    }
    unique(s.rest_blocks.iter().map(|e| e.id.as_str()))?;
    for e in &s.fuks {
        id(&e.id)?;
        text(&e.source)?;
        need(["start", "fant", "song", "meal", "session", "manual"].contains(&e.kind.as_str()))?;
        if let Some(n) = e.expires_at {
            need((0..=1000000000).contains(&n))?;
        }
        if let Some(x) = &e.session {
            text(x)?;
        }
    }
    unique(s.fuks.iter().map(|e| e.id.as_str()))?;
    for x in &s.completed_rests {
        id(x)?;
    }
    unique(s.completed_rests.iter().map(String::as_str))?;
    for x in &s.sessions {
        text(x)?;
    }
    unique(s.sessions.iter().map(String::as_str))?;
    for j in &s.journal {
        id(&j.id)?;
        need(!j.text.trim().is_empty() && j.text.chars().count() <= 3000)?;
    }
    unique(s.journal.iter().map(|j| j.id.as_str()))?;
    if let Some(r) = &s.rest {
        id(&r.id)?;
        need(
            r.started_at
                .is_none_or(|n| (0..=s.world_minutes).contains(&n)),
        )?;
        need(
            ["short", "long"].contains(&r.kind.as_str())
                && super::COLORS.contains(&r.color.as_str())
                && r.hp_at_start > 0,
        )?;
        for n in [
            r.context_revision,
            r.hp_at_start,
            r.elapsed,
            r.last_short_at,
            r.interruptions,
        ] {
            count(n)?;
        }
    }
    Ok(())
}
fn empty(c: &Character) -> State {
    serde_json::from_value(json!({"hp":c.sheet.as_ref().and_then(|s|s["hpCurrent"].as_i64()).unwrap_or(0),"hitDiceSpent":{"6":0,"8":0},"spent":{},"manual":[],"effects":[],"injury":0,"exhaustion":[],"restBlocks":[],"rest":null,"completedRests":[],"longStreak":0,"fuks":[],"startFuksClaimed":false,"session":null,"sessions":[],"worldMinutes":0,"journal":[]})).unwrap()
}
fn duration(color: &str) -> (i64, i64) {
    match color {
        "rust" => (1440, 4320),
        "chrome" => (60, 480),
        _ => (240, 1440),
    }
}

fn choice<'a>(choices: &'a Value, key: &str) -> Option<&'a str> {
    choices[key]
        .as_array()
        .and_then(|a| a.first())
        .and_then(Value::as_str)
}
fn increase(
    scores: &mut std::collections::BTreeMap<String, f64>,
    ability: &str,
    amount: f64,
    cap: f64,
) {
    if let Some(v) = scores.get_mut(ability) {
        *v = (*v + amount).min(cap);
    }
}
fn score_values(
    sheet: &Value,
    state: &State,
    long: bool,
) -> Result<std::collections::BTreeMap<String, f64>, String> {
    let adapted = state.care.as_ref().map(|c| care::sheet(sheet, c));
    let sheet = adapted.as_ref().unwrap_or(sheet);
    let constants: Value = serde_json::from_str(include_str!(
        "../../src/data/character/condition-constants.v1.json"
    ))
    .unwrap();
    let mut scores = std::collections::BTreeMap::new();
    for a in super::ABILITIES {
        scores.insert(
            a.to_string(),
            sheet["baseScores"][a].as_f64().ok_or("Brak cechy.")?,
        );
    }
    for a in constants["origins"][sheet["originId"].as_str().unwrap()]
        .as_array()
        .ok_or("Brak pochodzenia.")?
    {
        increase(&mut scores, a.as_str().unwrap(), 1., 18.);
    }
    let mut levels = std::collections::BTreeMap::<String, i64>::new();
    let mut seen = std::collections::HashSet::new();
    let feat = |key: &str,
                choices: &Value,
                scores: &mut std::collections::BTreeMap<String, f64>,
                seen: &mut std::collections::HashSet<String>,
                first: bool|
     -> Result<(), String> {
        if let Some(f) = choice(choices, key) {
            if f == "money" {
                return Ok(());
            }
            if f != "practice" && !seen.insert(f.to_string()) {
                return Ok(());
            }
            let cap = if first { 18. } else { 20. };
            if f == "practice" {
                let count = if choice(choices, &format!("{key}-mode")) == Some("one") {
                    2.
                } else {
                    1.
                };
                if let Some(list) = choices[format!("{key}-abilities")].as_array() {
                    for a in list {
                        increase(scores, a.as_str().unwrap_or(""), count, cap);
                    }
                }
            } else if let Some(a) = choice(choices, &format!("{key}-ability")) {
                if constants["feats"][f]
                    .as_array()
                    .is_some_and(|list| list.contains(&json!(a)))
                {
                    increase(scores, a, 1., cap);
                }
            }
        }
        Ok(())
    };
    for (i, l) in sheet["levels"].as_array().unwrap().iter().enumerate() {
        let class = l["classId"].as_str().unwrap();
        let n = levels.entry(class.to_string()).or_default();
        *n += 1;
        let c = &l["choices"];
        if i == 0 {
            feat("start", c, &mut scores, &mut seen, true)?;
        }
        let prof = *n == 3
            || if class == "twardziel" {
                [7, 11].contains(n)
            } else {
                [6, 10].contains(n) && choice(c, "profession-or-feat") == Some("profession")
            };
        if prof && choice(c, "profession-ability") == Some("medic.0") {
            if let Some(cost) = choice(c, "profession-ability-brain") {
                increase(&mut scores, "int", 4., 20.);
                increase(&mut scores, cost, -2., 20.);
            }
        }
        if class != "twardziel"
            && [6, 10].contains(n)
            && choice(c, "profession-or-feat") == Some("feat")
        {
            feat("profession-feat", c, &mut scores, &mut seen, i == 0)?;
        }
        if if class == "twardziel" {
            [4, 6, 8, 10, 12].contains(n)
        } else {
            [4, 8, 12].contains(n)
        } {
            feat("feat", c, &mut scores, &mut seen, i == 0)?;
        }
    }
    for a in super::ABILITIES {
        let target = format!("score:{a}");
        let value = apply_overrides(sheet, &target, scores[a]);
        let reduction: i64 = state
            .effects
            .iter()
            .filter(|e| e.target == a && (!long || e.refresh != "long"))
            .map(|e| e.amount)
            .sum();
        scores.insert(
            a.to_string(),
            value - (reduction as f64).min((value - 1.).max(0.)),
        );
    }
    Ok(scores)
}
fn apply_overrides(sheet: &Value, target: &str, base: f64) -> f64 {
    let corrections: Vec<_> = sheet["overrides"]
        .as_array()
        .unwrap()
        .iter()
        .filter(|o| {
            o["target"] == target && o["reason"].as_str().is_some_and(|r| !r.trim().is_empty())
        })
        .collect();
    let value = corrections
        .iter()
        .find(|o| o["mode"] == "replace")
        .and_then(|o| o["value"].as_f64())
        .unwrap_or(base);
    value
        + corrections
            .iter()
            .filter(|o| o["mode"] == "add")
            .filter_map(|o| o["value"].as_f64())
            .sum::<f64>()
}
fn expected_hp(
    sheet: &Value,
    state: &State,
    scores: &std::collections::BTreeMap<String, f64>,
    long: bool,
) -> i64 {
    let con = ((scores["con"] - 10.) / 2.).floor();
    let base = sheet["levels"]
        .as_array()
        .unwrap()
        .iter()
        .enumerate()
        .map(|(i, l)| {
            let eight =
                ["brutal", "twardziel", "zwiadowca"].contains(&l["classId"].as_str().unwrap());
            let initial = if i == 0 {
                if eight {
                    16.
                } else {
                    12.
                }
            } else if eight {
                4.
            } else {
                3.
            };
            let color = if i == 0 {
                0.
            } else {
                match l["color"].as_str().unwrap() {
                    "rust" => -2.,
                    "mercury" => -3.,
                    "steel" => 1.,
                    "chrome" => 2.,
                    _ => 0.,
                }
            };
            if i == 0 {
                initial + con
            } else {
                (initial + con + color).max(0.)
            }
        })
        .sum();
    let reduction: i64 = state
        .effects
        .iter()
        .filter(|e| e.target == "hpMax" && (!long || e.refresh != "long"))
        .map(|e| e.amount)
        .sum();
    (apply_overrides(sheet, "hpMax", base).floor() as i64 - reduction).max(0)
}
pub(super) fn current_modifier(c: &Character, ability: &str) -> Result<i64, String> {
    let state = match &c.condition {
        Some(v) => parse(v)?,
        None => empty(c),
    };
    let sheet = c.sheet.as_ref().ok_or("Brak zatwierdzonej karty.")?;
    let scores = score_values(sheet, &state, false)?;
    let score = scores.get(ability).ok_or("Nieznana cecha.")?;
    Ok(((score - 10.) / 2.).floor() as i64)
}

fn validate_context(ctx: &Context, c: &Character, s: &State) -> Result<(), String> {
    count(ctx.hp_max)?;
    count(ctx.long_hp_max)?;
    need((-5..=10).contains(&ctx.con))?;
    let sheet = c.sheet.as_ref().unwrap();
    let scores = score_values(sheet, s, false)?;
    let long_scores = score_values(sheet, s, true)?;
    need(
        ctx.hp_max == expected_hp(sheet, s, &scores, false)
            && ctx.long_hp_max == expected_hp(sheet, s, &long_scores, true)
            && ctx.con == ((scores["con"] - 10.) / 2.).floor() as i64,
    )?;

    let levels = sheet["levels"].as_array().unwrap();
    let n = |class: &str| levels.iter().filter(|l| l["classId"] == class).count() as i64;
    need(
        ctx.hit_dice.six == n("cwaniak") + n("spec") + n("zlodziej")
            && ctx.hit_dice.eight == n("brutal") + n("twardziel") + n("zwiadowca")
            && ctx.tough_level == n("twardziel"),
    )?;
    for (index, list) in [&ctx.resources, &ctx.long_resources].iter().enumerate() {
        let modifiers = if index == 0 { &scores } else { &long_scores };
        need(list.len() <= 140)?;
        unique(list.iter().map(|r| r.id.as_str()))?;
        for r in *list {
            text(&r.id)?;
            text(&r.label)?;
            count(r.max)?;
            need(
                (1..=100000).contains(&r.cost_max)
                    && r.page >= 0
                    && r.page <= 281
                    && r.note.len() <= 3000,
            )?;
            let _ = r.unresolved;
            let expected = match r.id.as_str() {
                "berserk" | "rage" | "luck" | "brain" | "trajectory" | "stamina" | "toughness"
                | "cat" | "matrix" | "amen" | "patriot" | "stubborn" | "believe" | "song" => "long",
                "motivation" | "heckle" | "insult" | "advice" | "defense" | "production"
                | "hands" | "surge" | "sapper" | "fart" => "short",
                "clint" => "encounter",
                "concert" => "day",
                _ => {
                    let m = s
                        .manual
                        .iter()
                        .find(|m| m.id == r.id)
                        .ok_or("Nieznany zasób.")?;
                    need(r.max == m.max && r.cost_max == 100000)?;
                    "manual"
                }
            };
            need(r.refresh == expected)?;
            let level = match r.id.as_str() {
                "berserk" | "rage" => n("brutal"),
                "motivation" | "heckle" | "insult" | "luck" => n("cwaniak"),
                "advice" | "defense" | "brain" | "production" | "hands" | "trajectory" => n("spec"),
                "stamina" | "surge" | "toughness" => n("twardziel"),
                "cat" | "matrix" | "sapper" => n("zlodziej"),
                _ => 1,
            };
            let minimum = match r.id.as_str() {
                "rage" | "heckle" | "brain" | "surge" | "cat" => 2,
                "production" | "toughness" => 3,
                "hands" => 4,
                "insult" => 5,
                "trajectory" | "matrix" => 7,
                "sapper" => 11,
                _ => 1,
            };
            need(level >= minimum)?;
            let pb = 2 + (levels.len() as i64 - 1) / 4;
            let max = match r.id.as_str() {
                "berserk" => Some(2 + (level - 1) / 3),
                "luck" => Some(1 + (level - 1) / 3),
                "rage" => Some(level),
                "advice" | "insult" | "brain" | "trajectory" | "matrix" => Some(pb),
                "production" | "surge" | "sapper" | "clint" | "patriot" | "stubborn"
                | "believe" | "fart" | "song" | "concert" => Some(1),
                _ => None,
            };
            if let Some(max) = max {
                need(r.max == max)?;
            }
            let ability = match r.id.as_str() {
                "motivation" | "heckle" | "amen" => Some("cha"),
                "defense" => Some("int"),
                "hands" | "cat" => Some("dex"),
                "stamina" | "toughness" => Some("con"),
                _ => None,
            };
            if let Some(a) = ability {
                need(r.max == (((modifiers[a] - 10.) / 2.).floor() as i64).max(0))?;
            }
            let selected = |key: &str, value: &str| {
                levels.iter().any(|l| {
                    l["choices"][key]
                        .as_array()
                        .is_some_and(|a| a.contains(&json!(value)))
                })
            };
            match r.id.as_str() {
                "amen" => need(selected("profession-ability", "preacher.0"))?,
                "clint" => need(selected("profession-ability", "cowboy.0"))?,
                "concert" => need(selected("profession-ability", "star.3"))?,
                "song" => need(
                    ["start", "feat", "profession-feat"]
                        .iter()
                        .any(|k| selected(k, "musician")),
                )?,
                "patriot" | "stubborn" | "believe" | "fart" => {
                    let (origin, ability) = match r.id.as_str() {
                        "patriot" => ("newyork", "patriot"),
                        "stubborn" => ("hegemony", "stubborn"),
                        "believe" => ("saltlake", "believe"),
                        _ => ("vegas", "luck"),
                    };
                    need(
                        sheet["originId"] == origin
                            && levels.iter().any(|l| {
                                l["choices"].as_object().unwrap().iter().any(|(k, v)| {
                                    k.contains("origin")
                                        && v.as_array().is_some_and(|a| a.contains(&json!(ability)))
                                })
                            }),
                    )?;
                }
                _ => {}
            }

            let cost = match r.id.as_str() {
                "rage" => 3,
                "cat" => 12,
                _ if expected == "manual" => 100000,
                _ => 1,
            };
            need(r.cost_max == cost)?;
        }
    }
    Ok(())
}
pub fn apply(
    old: &Character,
    raw: &Value,
    context: &Value,
    operation: &str,
    proposed: &Value,
) -> Result<Value, String> {
    need(old.sheet.is_some() && old.draft.is_none() && !old.archived)?;
    let mut s = match &old.condition {
        Some(v) => parse(v)?,
        None => empty(old),
    };
    check(&s)?;
    let ctx: Context = serde_json::from_value(context.clone()).map_err(|e| e.to_string())?;
    validate_context(&ctx, old, &s)?;
    let a: Action = serde_json::from_value(raw.clone()).map_err(|e| e.to_string())?;
    let sheet = old.sheet.as_ref().unwrap();
    let color = sheet["rulesContext"]["gameColor"].as_str().unwrap();
    let resource = |id: &str| {
        ctx.resources
            .iter()
            .find(|r| r.id == id)
            .ok_or_else(|| "Brak tej zdolności.".to_string())
    };
    match a {
        Action::CombatAbility { combat_application } => {
            need(combat_application.is_object())?;
        }
        Action::CombatHealth { command } => {
            let con = score_values(sheet, &s, false)?["con"] as i64;
            combat_health(&mut s, &command, ctx.hp_max, con, color, operation)?;
        }
        Action::Downtime { command } => {
            downtime::apply(old, &mut s, &command, operation, ctx.hp_max)?;
        }
        Action::Care { command } => {
            care::apply(old, &mut s, &command, operation)?;
        }
        Action::Use {
            combat_application,
            combat_choice,
            resource_id,
            amount,
            healing_roll,
        } => {
            if let Some(application) = combat_application {
                need(application.is_object())?;
            }
            if let Some(choice) = combat_choice {
                need(resource_id == "surge" && ["action", "bonus"].contains(&choice.as_str()))?;
            }
            let r = resource(&resource_id)?;
            need(
                amount >= 1
                    && amount <= r.cost_max
                    && amount <= (r.max - s.spent.get(&resource_id).copied().unwrap_or(0)).max(0),
            )?;
            *s.spent.entry(resource_id.clone()).or_default() += amount;
            if let Some(roll) = healing_roll {
                need(resource_id == "stamina" && (1..=8).contains(&roll))?;
                s.hp = ctx.hp_max.min(s.hp + roll + ctx.tough_level);
            }
        }
        Action::Correct {
            hp,
            injury,
            hit_dice_spent,
            reason,
        } => {
            text(&reason)?;
            s.hp = hp;
            if s.injury < 4 && injury >= 4 {
                s.exhaustion.push(Exhaustion {
                    id: operation.into(),
                    cause: "ordinary".into(),
                    source: "Czwarte Zranienie".into(),
                    level: 1,
                });
            }
            s.injury = injury;
            s.hit_dice_spent = hit_dice_spent;
        }
        Action::ResourceStep { id, direction } => {
            let r = resource(&id)?;
            let spent = s.spent.get(&id).copied().unwrap_or(0);
            let next = match direction.as_str() {
                "use" => {
                    if spent >= r.max {
                        return Err("Brak pozostałych użyć.".into());
                    }
                    spent + 1
                }
                "restore" => {
                    if spent == 0 {
                        return Err("Wszystkie użycia są już dostępne.".into());
                    }
                    spent - 1
                }
                _ => return Err("Nieznana zmiana zasobu.".into()),
            };
            s.spent.insert(id, next);
        }
        Action::Resource { id, spent, reason } => {
            text(&reason)?;
            resource(&id)?;
            s.spent.insert(id, spent);
        }
        Action::Manual { entry, reason } => {
            text(&reason)?;
            if let Some(e) = s.manual.iter_mut().find(|e| e.id == entry.id) {
                *e = entry;
            } else {
                s.manual.push(entry);
            }
        }
        Action::Effect { entry } => s.effects.push(entry),
        Action::Exhaustion { entry } => s.exhaustion.push(entry),
        Action::ExhaustionReduce { id } => {
            let e = s
                .exhaustion
                .iter_mut()
                .find(|e| e.id == id)
                .ok_or_else(|| "Wskaż istniejącą przyczynę Wyczerpania.".to_string())?;
            e.level -= 1;
            s.exhaustion.retain(|e| e.level > 0);
        }
        Action::Block { id, source } => s.rest_blocks.push(Block { id, source }),
        Action::Remove { group, id, reason } => {
            text(&reason)?;
            match group.as_str() {
                "effects" => {
                    need(s.effects.iter().any(|e| e.id == id))?;
                    s.effects.retain(|e| e.id != id);
                }
                "exhaustion" => {
                    need(s.exhaustion.iter().any(|e| e.id == id))?;
                    s.exhaustion.retain(|e| e.id != id);
                }
                "restBlocks" => {
                    need(s.rest_blocks.iter().any(|e| e.id == id))?;
                    s.rest_blocks.retain(|e| e.id != id);
                }
                _ => return Err("Nieznana grupa zdrowia.".into()),
            }
        }
        Action::RestStart { id, kind } => {
            need(s.rest.is_none() && s.hp >= 1 && !s.completed_rests.contains(&id))?;
            s.rest = Some(Rest {
                id,
                kind,
                color: color.into(),
                context_revision: sheet["rulesContext"]["revision"].as_i64().unwrap(),
                hp_at_start: s.hp,
                started_at: Some(s.world_minutes),
                elapsed: 0,
                last_short_at: 0,
                interruptions: 0,
            });
        }
        Action::RestCancel { reason } => {
            text(&reason)?;
            let rest = s.rest.take().ok_or("Brak odpoczynku.")?;
            s.completed_rests.push(rest.id);
            s.long_streak = 0;
        }
        Action::RestApply {
            session_id,
            outcome,
            elapsed,
            sleep,
            armored,
            consecutive,
            food,
            water,
            warm,
            exhaustion_id,
            medic_proficient,
            medic_tools,
            healing_save,
            rolls6,
            rolls8,
            kolejka_level,
            kolejka_rolls,
        } => {
            let mut rest = s.rest.clone().ok_or("Brak odpoczynku.")?;
            need(
                rest.id == session_id
                    && !s.completed_rests.contains(&session_id)
                    && rest.color == color
                    && rest.context_revision == sheet["rulesContext"]["revision"].as_i64().unwrap()
                    && elapsed >= rest.elapsed
                    && sleep <= elapsed,
            )?;
            count(elapsed)?;
            count(sleep)?;
            need(
                ["complete", "interrupt"].contains(&outcome.as_str())
                    && (0..=12).contains(&kolejka_level),
            )?;
            if let Some(n) = healing_save {
                need((-100..=100).contains(&n))?;
            }
            let start = rest
                .started_at
                .unwrap_or((s.world_minutes - rest.elapsed).max(0));
            need((0..=1000000000).contains(&start))?;
            s.world_minutes = s.world_minutes.max(start + elapsed);
            rest.started_at = Some(start);
            let (short, long) = duration(color);
            let mut benefit = "";
            if outcome == "complete" {
                need(
                    elapsed
                        >= if rest.kind == "short" {
                            short
                        } else {
                            long + rest.interruptions * 60
                        },
                )?;
                if rest.kind == "long" {
                    need(sleep >= 360)?;
                }
                benefit = &rest.kind;
            } else if rest.kind == "long" && elapsed - rest.last_short_at >= short {
                benefit = "short";
            }
            if !s.rest_blocks.is_empty() || s.care.as_ref().is_some_and(care::blocked) {
                benefit = "";
            }
            let dice = rolls6.len() + rolls8.len();
            if benefit == "short" {
                need(
                    rolls6.len() <= 12
                        && rolls8.len() <= 12
                        && rolls6.iter().all(|n| (1..=6).contains(n))
                        && rolls8.iter().all(|n| (1..=8).contains(n)),
                )?;
                need(
                    rolls6.len() as i64 <= (ctx.hit_dice.six - s.hit_dice_spent.six).max(0)
                        && rolls8.len() as i64
                            <= (ctx.hit_dice.eight - s.hit_dice_spent.eight).max(0),
                )?;
                s.hit_dice_spent.six += rolls6.len() as i64;
                s.hit_dice_spent.eight += rolls8.len() as i64;
                if kolejka_level > 0 {
                    let sides = if kolejka_level >= 9 {
                        8
                    } else if kolejka_level >= 5 {
                        6
                    } else {
                        4
                    };
                    need(
                        kolejka_level >= 2
                            && kolejka_rolls.len() == dice
                            && kolejka_rolls.iter().all(|n| (1..=sides).contains(n)),
                    )?;
                } else {
                    need(kolejka_rolls.is_empty())?;
                }
                if dice > 0 {
                    s.hp = ctx.hp_max.min(
                        s.hp + (rolls6
                            .iter()
                            .chain(&rolls8)
                            .chain(&kolejka_rolls)
                            .sum::<i64>()
                            + dice as i64 * ctx.con)
                            .max(1),
                    );
                }
            } else {
                need(dice == 0 && kolejka_rolls.is_empty())?;
            }
            if benefit == "long" {
                downtime::expire(&mut s.downtime, s.world_minutes, true);
                s.effects.retain(|e| e.refresh != "long");
                s.hp = ctx.long_hp_max;
                s.hit_dice_spent.six -= if armored {
                    s.hit_dice_spent.six.min(ctx.hit_dice.six / 2)
                } else {
                    s.hit_dice_spent.six
                };
                s.hit_dice_spent.eight -= if armored {
                    s.hit_dice_spent.eight.min(ctx.hit_dice.eight / 2)
                } else {
                    s.hit_dice_spent.eight
                };
                s.long_streak = if consecutive { s.long_streak + 1 } else { 1 };
                if !armored {
                    let removed_cold = warm
                        && s.exhaustion
                            .iter()
                            .any(|e| Some(&e.id) == exhaustion_id.as_ref() && e.cause == "cold");
                    if warm {
                        s.exhaustion.retain(|e| e.cause != "cold");
                    }
                    if let Some(id) = exhaustion_id.filter(|_| !removed_cold) {
                        let e = s
                            .exhaustion
                            .iter_mut()
                            .find(|e| e.id == id)
                            .ok_or("Brak przyczyny Wyczerpania.")?;
                        need(
                            e.cause == "ordinary"
                                || e.cause == "cold"
                                || (e.cause == "hunger" && food)
                                || (e.cause == "thirst" && water),
                        )?;
                        e.level -= 1;
                        s.exhaustion.retain(|e| e.level > 0);
                    }
                    if healing_save.is_some() {
                        need(s.long_streak >= 3)?;
                    }
                    let natural = s.long_streak >= 3
                        && healing_save.is_some_and(|n| n >= 15)
                        && color != "rust"
                        && color != "mercury";
                    if s.injury > 0 && ((medic_proficient && medic_tools) || natural) {
                        s.injury -= 1;
                        s.long_streak = 0;
                    }
                }
            }
            let list = if benefit == "long" {
                &ctx.long_resources
            } else {
                &ctx.resources
            };
            if !benefit.is_empty() {
                for r in list {
                    if r.refresh == "short" || (benefit == "long" && r.refresh == "long") {
                        s.spent.insert(r.id.clone(), 0);
                    }
                }
            }
            if outcome == "interrupt" && rest.kind == "long" {
                rest.elapsed = elapsed;
                rest.last_short_at = elapsed;
                rest.interruptions += 1;
                s.rest = Some(rest);
            } else {
                s.completed_rests.push(rest.id);
                s.rest = None;
                if benefit != "long" && rest.kind == "long" {
                    s.long_streak = 0;
                }
            }
        }
        Action::FuksGrant { entry } => {
            need(color != "mercury" && entry.kind != "session")?;
            if entry.kind == "start" {
                need(!s.start_fuks_claimed)?;
                s.start_fuks_claimed = true;
            }
            if entry.kind == "fant" {
                need(s.fuks.iter().filter(|f| f.kind == "fant").count() < 3)?;
            }
            if entry.kind == "song" || entry.kind == "meal" {
                need(entry.expires_at == Some(s.world_minutes + 1440))?;
            }
            s.fuks.push(entry);
        }
        Action::FuksUse { id } => {
            need(color != "mercury" && s.fuks.iter().any(|f| f.id == id))?;
            s.fuks.retain(|f| f.id != id);
        }
        Action::Session { id } => {
            text(&id)?;
            need(!s.sessions.contains(&id))?;
            s.sessions.push(id.clone());
            s.session = Some(id.clone());
            s.fuks.retain(|f| f.kind != "session");
            if color == "steel" || color == "chrome" {
                s.fuks.push(Fuks {
                    id: operation.into(),
                    source: format!("Kolor gry — sesja {id}"),
                    kind: "session".into(),
                    session: Some(id),
                    expires_at: None,
                });
            }
        }
        Action::SessionEnd => {
            need(s.session.is_some())?;
            s.fuks.retain(|f| f.kind != "session");
            s.session = None;
        }
        Action::WorldTime { minutes } => {
            count(minutes)?;
            need(minutes > 0)?;
            s.world_minutes += minutes;
            downtime::expire(&mut s.downtime, s.world_minutes, false);
            s.fuks
                .retain(|f| f.expires_at.is_none_or(|t| t > s.world_minutes));
        }
    }
    // Counting uses must not normalize unrelated health, effects or expiring resources.
    if raw["type"] != "resourceStep" && raw["type"] != "exhaustionReduce" {
        if let Some(c) = &mut s.care {
            care::set_day(c, s.world_minutes);
        }
        if s.hp > 0 {
            if let Some(h) = s.combat_health.as_mut() {
                h.successes = 0;
                h.failures = 0;
                h.stable = false;
                if raw["type"] == "correct" && s.injury < 5 {
                    h.dead = false;
                }
            }
        }
        s.fuks
            .retain(|f| f.expires_at.is_none_or(|t| t > s.world_minutes));
        downtime::expire(&mut s.downtime, s.world_minutes, false);
    }
    // The human-readable journal text is supplied by the preview; its append-only identity is checked here.
    let p = parse(proposed)?;
    need(
        p.journal.len() == s.journal.len() + 1
            && p.journal[..s.journal.len()] == s.journal
            && p.journal.last().is_some_and(|j| j.id == operation),
    )?;
    s.journal = p.journal.clone();
    check(&s)?;
    let out = serde_json::to_value(s).map_err(|e| e.to_string())?;
    need(super::inventory::same(&out, proposed))?;
    Ok(out)
}

pub(super) fn expected_inventory(
    old: &Character,
    raw: &Value,
    op: &str,
    context: &Value,
) -> Result<Option<Value>, String> {
    if raw["type"] != "care" && raw["type"] != "downtime" {
        return Ok(old.inventory.clone());
    }
    let mut s = match &old.condition {
        Some(v) => parse(v)?,
        None => empty(old),
    };
    let inv = if raw["type"] == "care" {
        care::apply(old, &mut s, &raw["command"], op)?
    } else {
        downtime::apply(
            old,
            &mut s,
            &raw["command"],
            op,
            context["hpMax"].as_i64().ok_or("Brak maksimum PW.")?,
        )?
    };
    Ok(Some(inv))
}

#[derive(Clone, Debug, Default, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct CombatHealth {
    bleeding: bool,
    successes: i64,
    failures: i64,
    stable: bool,
    dead: bool,
}
fn combat_health(
    s: &mut State,
    a: &Value,
    max: i64,
    con: i64,
    color: &str,
    op: &str,
) -> Result<(), String> {
    let h = s.combat_health.get_or_insert_with(CombatHealth::default);
    if h.dead {
        return Err("Postać nie żyje. Sprawdź stan w sekcji Zdrowie.".into());
    }
    let kind = a["kind"]
        .as_str()
        .ok_or("Brak rodzaju rozliczenia zdrowia.")?;
    match kind {
        "damage" | "bleed" => {
            let n = if kind == "bleed" {
                super::keys(a, &["kind"])?;
                need(h.bleeding)?;
                1
            } else {
                super::keys(a, &["kind", "amount", "critical", "melee"])?;
                need(a["critical"].is_boolean() && a["melee"].is_boolean())?;
                super::integer(&a["amount"], 0, 100000)?
            };
            let before = s.hp;
            if n > 0 {
                s.hp = (before - n).max(0);
                if before == 0 {
                    h.failures = (h.failures
                        + if kind == "damage" && a["melee"] == true {
                            2
                        } else {
                            1
                        })
                    .min(3);
                    h.stable = false;
                }
                if kind == "damage"
                    && (a["critical"] == true
                        || (before > 0 && s.hp == 0)
                        || (color == "rust" && n >= con))
                {
                    let previous = s.injury;
                    s.injury = (s.injury + 1).min(5);
                    if previous < 4 && s.injury >= 4 {
                        s.exhaustion.push(Exhaustion {
                            id: op.into(),
                            cause: "ordinary".into(),
                            source: "Czwarte Zranienie".into(),
                            level: 1,
                        });
                    }
                    if ["rust", "mercury"].contains(&color) {
                        h.bleeding = true;
                    }
                }
                if n >= 2 * max {
                    h.dead = true;
                }
            }
        }
        "healing" => {
            super::keys(a, &["kind", "amount"])?;
            s.hp = (s.hp + super::integer(&a["amount"], 0, 100000)?).min(max);
        }
        "deathSave" => {
            super::keys(a, &["kind", "face"])?;
            need(s.hp == 0 && !h.stable)?;
            let face = super::integer(&a["face"], 1, 20)?;
            if face == 20 {
                s.hp = 1;
            } else if face >= 10 {
                h.successes = (h.successes + 1).min(3);
            } else {
                h.failures = (h.failures + if face == 1 { 2 } else { 1 }).min(3);
            }
        }
        "stopBleeding" => {
            super::keys(a, &["kind"])?;
            h.bleeding = false;
        }
        "stabilize" => {
            super::keys(a, &["kind"])?;
            need(s.hp == 0)?;
            h.stable = true;
        }
        _ => return Err("Nieznane rozliczenie zdrowia.".into()),
    }
    if s.hp > 0 {
        h.successes = 0;
        h.failures = 0;
        h.stable = false;
    }
    if h.successes >= 3 {
        h.stable = true;
        h.successes = 0;
        h.failures = 0;
    }
    if h.failures >= 3 || s.injury >= 5 || max == 0 {
        h.dead = true;
    }
    if h.stable {
        h.successes = 0;
        h.failures = 0;
    }
    Ok(())
}

#[cfg(test)]
mod exhaustion_step_tests {
    use super::*;
    #[test]
    fn exhaustion_decrement_preserves_causes_and_rejects_forged_or_stale_source() {
        let cases: Vec<Value> = serde_json::from_str(include_str!(
            "../../tests/fixtures/character-condition.json"
        ))
        .unwrap();
        let mut c: Character = serde_json::from_value(cases[1]["before"].clone()).unwrap();
        let ctx = &cases[1]["context"];
        let id = "00000000-0000-4000-8000-000000001111";
        let other = "00000000-0000-4000-8000-000000001112";
        let op = "00000000-0000-4000-8000-000000001113";
        let s = c.condition.as_mut().unwrap();
        s["exhaustion"] = json!([{ "id":id,"source":"Marsz","cause":"ordinary","level":2 },{ "id":other,"source":"Głód","cause":"hunger","level":1 }]);
        s["combatHealth"] =
            json!({"bleeding":true,"successes":1,"failures":1,"stable":false,"dead":false});
        let original = c.condition.clone().unwrap();
        let mut expected = original.clone();
        expected["exhaustion"][0]["level"] = json!(1);
        expected["journal"]
            .as_array_mut()
            .unwrap()
            .push(json!({"id":op,"text":"Wyczerpanie −1: Marsz"}));
        let action = json!({"type":"exhaustionReduce","id":id});
        assert_eq!(apply(&c, &action, ctx, op, &expected).unwrap(), expected);
        assert_eq!(c.condition.as_ref().unwrap(), &original);
        let mut forged = expected.clone();
        forged["exhaustion"][1]["level"] = json!(2);
        assert!(apply(&c, &action, ctx, op, &forged).is_err());
        assert!(apply(
            &c,
            &json!({"type":"exhaustionReduce","id":op}),
            ctx,
            op,
            &expected
        )
        .is_err());
        c.condition = Some(expected.clone());
        expected["exhaustion"].as_array_mut().unwrap().remove(0);
        let op2 = "00000000-0000-4000-8000-000000001114";
        expected["journal"]
            .as_array_mut()
            .unwrap()
            .push(json!({"id":op2,"text":"Wyczerpanie −1: Marsz"}));
        assert_eq!(
            apply(&c, &action, ctx, op2, &expected).unwrap()["exhaustion"],
            json!([{ "id":other,"source":"Głód","cause":"hunger","level":1 }])
        );
    }
}
