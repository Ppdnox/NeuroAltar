use super::*;
use serde_json::Value;
use sqlx::{Sqlite, Transaction};

fn need(ok: bool, message: &str) -> Result<(), String> {
    if ok {
        Ok(())
    } else {
        Err(message.into())
    }
}

pub(super) fn validate(r: &Roll) -> Result<(), String> {
    if let Some(c) = &r.character_check {
        need(
            uuid::Uuid::parse_str(&c.character_id).is_ok()
                && !c.targets.is_empty()
                && c.targets.len() <= 12
                && c.targets.iter().all(|t| !t.is_empty() && t.len() <= 80)
                && r.count == 1
                && r.sides == 20
                && r.supplement.is_none(),
            "Nieprawidłowy test postaci.",
        )?;
        if let Some(ids) = &c.consumed_benefits {
            need(
                ids.len() == 1
                    && uuid::Uuid::parse_str(&ids[0]).is_ok()
                    && c.expected_revision.is_some_and(|n| n >= 0),
                "Nieprawidłowy efekt postoju.",
            )?;
        }
    }
    if let Some(s) = &r.supplement {
        need(
            uuid::Uuid::parse_str(&s.original_roll_id).is_ok()
                && uuid::Uuid::parse_str(&s.character_id).is_ok()
                && s.expected_revision >= 0
                && ["cat", "toughness", "amen"].contains(&s.resource_id.as_str())
                && r.count == 1
                && [4, 6, 8, 10, 12].contains(&r.sides)
                && r.modifier == s.original_total
                && (1..=20).contains(&s.original_natural)
                && !s.original_label.is_empty()
                && s.original_label.chars().count() <= 500
                && r.critical.is_none()
                && r.check_dice.is_none()
                && r.context.as_ref().is_none_or(|c| {
                    c.purpose.is_none() && c.consumed_effects.is_none() && c.reroll_of.is_none()
                }),
            "Nieprawidłowa dodatkowa kość.",
        )?;
    }
    Ok(())
}

async fn owner(tx: &mut Transaction<'_, Sqlite>, r: &Roll) -> Result<Option<String>, String> {
    if let Some(c) = &r.character_context {
        return Ok(Some(c.character_id.clone()));
    }
    if let Some(c) = &r.context {
        return sqlx::query_scalar(
            "SELECT character_id FROM character_participations WHERE actor_id=? AND encounter_id=?",
        )
        .bind(&c.actor_id)
        .bind(c.encounter_id)
        .fetch_optional(&mut **tx)
        .await
        .map_err(|e| e.to_string());
    }
    Ok(None)
}

pub(super) async fn apply(tx: &mut Transaction<'_, Sqlite>, roll: &Roll) -> Result<(), String> {
    if roll.character_check.is_none() && roll.supplement.is_none() {
        return Ok(());
    }
    let id = owner(tx, roll).await?.ok_or("Brak właściciela testu.")?;
    if let Some(c) = &roll.character_check {
        need(c.character_id == id, "Test należy do innej postaci.")?;
    }
    let effects = roll
        .character_check
        .as_ref()
        .and_then(|c| c.consumed_benefits.as_ref());
    if roll.supplement.is_none() && effects.is_none() {
        return Ok(());
    }
    let raw: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
        .bind(&id)
        .fetch_one(&mut **tx)
        .await
        .map_err(|e| e.to_string())?;
    let mut character: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    crate::character::validate_roll_character(&character)?;
    let revision = character["revision"]
        .as_i64()
        .ok_or("Brak rewizji karty.")?;
    if let Some(s) = &roll.supplement {
        need(
            s.character_id == id && s.expected_revision == revision,
            "Karta zmieniła się przed użyciem kości. Odczytaj aktualne dane.",
        )?;
        let raw: String = sqlx::query_scalar("SELECT payload_json FROM dice_rolls WHERE id=?")
            .bind(&s.original_roll_id)
            .fetch_one(&mut **tx)
            .await
            .map_err(|e| e.to_string())?;
        let original: Roll = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
        need(
            owner(tx, &original).await?.as_deref() == Some(id.as_str())
                && original.count == 1
                && original.sides == 20
                && original.supplement.is_none()
                && original.total == s.original_total
                && original.values[0] == s.original_natural,
            "Wybierz pierwotny test tej postaci.",
        )?;
        need(
            original
                .context
                .as_ref()
                .map(|c| c.label.as_str())
                .or(original
                    .character_context
                    .as_ref()
                    .map(|c| c.label.as_str()))
                == Some(s.original_label.as_str()),
            "Opis nie odpowiada pierwotnemu testowi.",
        )?;
        let targets = original
            .character_check
            .as_ref()
            .map(|c| c.targets.clone())
            .or_else(|| {
                original
                    .context
                    .as_ref()
                    .filter(|c| c.purpose.as_deref() == Some("initiative"))
                    .map(|_| vec!["dex".into(), "initiative".into()])
            })
            .ok_or("Ten starszy rzut nie ma informacji o rodzaju testu.")?;
        need(
            !targets.iter().any(|t| t == "damage"),
            "Kość zdolności dotyczy testu, nie obrażeń.",
        )?;
        let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM dice_rolls WHERE id<>? AND json_extract(payload_json,'$.supplement.originalRollId')=? AND json_extract(payload_json,'$.supplement.resourceId')=?")
            .bind(&roll.id).bind(&s.original_roll_id).bind(&s.resource_id).fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
        need(count == 0, "Ta zdolność została już użyta do tego testu.")?;
        if let Some(old) = &original.context {
            let current = roll.context.as_ref().ok_or("Zachowaj kontekst potyczki.")?;
            let round: i64 = sqlx::query_scalar("SELECT round_number FROM encounters WHERE id=?")
                .bind(old.encounter_id)
                .fetch_one(&mut **tx)
                .await
                .map_err(|e| e.to_string())?;
            need(
                current.actor_id == old.actor_id
                    && current.encounter_id == old.encounter_id
                    && current.round_number == old.round_number
                    && round == old.round_number,
                "Wybierz test z bieżącej rundy.",
            )?;
            if old.purpose.as_deref() == Some("initiative") {
                let latest: String = sqlx::query_scalar("SELECT id FROM dice_rolls WHERE json_extract(payload_json,'$.context.actorId')=? AND json_extract(payload_json,'$.context.encounterId')=? AND json_extract(payload_json,'$.context.purpose')='initiative' ORDER BY sequence DESC LIMIT 1").bind(&old.actor_id).bind(old.encounter_id).fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
                need(
                    latest == original.id,
                    "Inicjatywa została już ponownie rzucona.",
                )?;
                let changed = sqlx::query("UPDATE encounter_actors SET initiative_value=? WHERE id=? AND encounter_id=? AND initiative_value=?").bind(roll.total).bind(&old.actor_id).bind(old.encounter_id).bind(original.total).execute(&mut **tx).await.map_err(|e|e.to_string())?.rows_affected();
                need(changed == 1, "Inicjatywa została zmieniona ręcznie.")?;
                sqlx::query("UPDATE encounters SET combat_revision=combat_revision+1 WHERE id=?")
                    .bind(old.encounter_id)
                    .execute(&mut **tx)
                    .await
                    .map_err(|e| e.to_string())?;
            }
        }
        character = crate::character::apply_roll_resource(
            &character,
            &s.resource_id,
            &targets,
            roll.sides,
            s.failed,
            &roll.id,
        )?;
    }
    if let Some(ids) = effects {
        let c = roll.character_check.as_ref().unwrap();
        need(
            c.expected_revision == Some(revision) && c.targets.iter().any(|t| t == "save"),
            "Efekt posiłku wymaga aktualnego Rzutu Obronnego.",
        )?;
        let now = character["condition"]["worldMinutes"].as_i64().unwrap_or(0);
        let benefits = character["condition"]["downtime"]["benefits"]
            .as_array_mut()
            .ok_or("Brak efektów postoju.")?;
        for id in ids {
            need(
                benefits.iter().any(|b| {
                    b["id"] == *id
                        && (b["kind"] == "mealSave"
                            || (b["kind"].is_null()
                                && b["label"] == "Posiłek: Ułatwienie najbliższego dowolnego RO"))
                        && (b["expiresAt"].is_null()
                            || b["expiresAt"].as_i64().is_some_and(|n| n > now))
                }),
                "Posiłek został już rozliczony.",
            )?;
        }
        benefits.retain(|b| !ids.iter().any(|id| b["id"] == *id));
    }
    character["revision"] = json!(revision + 1);
    character["updatedAt"] = json!(roll.created_at);
    crate::character::validate_roll_character(&character)?;
    let changed = sqlx::query(
        "UPDATE characters SET revision=?,payload_json=?,updated_at=? WHERE id=? AND revision=?",
    )
    .bind(revision + 1)
    .bind(character.to_string())
    .bind(&roll.created_at)
    .bind(&id)
    .bind(revision)
    .execute(&mut **tx)
    .await
    .map_err(|e| e.to_string())?
    .rows_affected();
    need(changed == 1, "Konflikt zapisu karty.")?;
    sqlx::query("INSERT INTO character_operations(operation_id,character_id,kind,request_json,result_json) VALUES(?,?,'condition',?,?)").bind(&roll.id).bind(&id).bind(json!({"event":"rollEffects","roll":roll}).to_string()).bind(character.to_string()).execute(&mut **tx).await.map_err(|e|e.to_string())?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn next_id() -> String {
        static NEXT: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(1);
        format!(
            "00000000-0000-4000-8000-{:012x}",
            NEXT.fetch_add(1, std::sync::atomic::Ordering::SeqCst)
        )
    }
    async fn fixture(key: &str) -> (SqlitePool, Value) {
        let p = sqlx::sqlite::SqlitePoolOptions::new()
            .max_connections(1)
            .connect("sqlite::memory:")
            .await
            .unwrap();
        for sql in [
            include_str!("../migrations/001_initial.sql"),
            include_str!("../migrations/011_characters.sql"),
            include_str!("../migrations/013_character_condition.sql"),
            include_str!("../migrations/010_dice_history.sql"),
        ] {
            sqlx::raw_sql(sql).execute(&p).await.unwrap();
        }
        let cases: Value = serde_json::from_str(include_str!(
            "../../tests/fixtures/character-roll-mechanics.json"
        ))
        .unwrap();
        let c = cases[key].clone();
        sqlx::query("INSERT INTO characters(id,revision,payload_json,created_at,updated_at) VALUES(?,?,?,?,?)").bind(c["id"].as_str().unwrap()).bind(c["revision"].as_i64().unwrap()).bind(c.to_string()).bind(c["createdAt"].as_str().unwrap()).bind(c["updatedAt"].as_str().unwrap()).execute(&p).await.unwrap();
        (p, c)
    }
    fn check(c: &Value) -> Roll {
        serde_json::from_value(json!({"id":next_id(),"createdAt":"2026-10-21T12:00:00.000Z","formula":"1k20+4","count":1,"sides":20,"modifier":4,"values":[1],"total":5,"context":null,"characterContext":{"characterId":c["id"],"name":"Test","label":"RO Kondycji"},"characterCheck":{"characterId":c["id"],"targets":["con","save"]}})).unwrap()
    }
    fn bonus(c: &Value, original: &Roll) -> Roll {
        serde_json::from_value(json!({"id":next_id(),"createdAt":"2026-10-21T12:01:00.000Z","formula":"1k4+5","count":1,"sides":4,"modifier":5,"values":[3],"total":8,"context":null,"characterContext":{"characterId":c["id"],"name":"Test","label":"Twardość"},"supplement":{"originalRollId":original.id,"characterId":c["id"],"expectedRevision":c["revision"],"resourceId":"toughness","originalTotal":5,"originalNatural":1,"originalLabel":"RO Kondycji","failed":true}})).unwrap()
    }
    async fn saved(p: &SqlitePool, c: &Value) -> Value {
        let raw: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
            .bind(c["id"].as_str().unwrap())
            .fetch_one(p)
            .await
            .unwrap();
        serde_json::from_str(&raw).unwrap()
    }
    #[test]
    fn resource_roll_is_atomic_retry_safe_and_rejects_second_use_on_same_check() {
        tauri::async_runtime::block_on(async {
            let (p, c) = fixture("tough").await;
            let r = check(&c);
            save_to_pool(&p, r.clone()).await.unwrap();
            let b = bonus(&c, &r);
            sqlx::raw_sql("CREATE TRIGGER fail_bonus BEFORE INSERT ON character_operations BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
            assert!(save_to_pool(&p, b.clone()).await.is_err());
            assert_eq!(saved(&p, &c).await, c);
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM dice_rolls")
                    .fetch_one(&p)
                    .await
                    .unwrap(),
                1
            );
            sqlx::raw_sql("DROP TRIGGER fail_bonus")
                .execute(&p)
                .await
                .unwrap();
            save_to_pool(&p, b.clone()).await.unwrap();
            let after = saved(&p, &c).await;
            assert_eq!(after["condition"]["spent"]["toughness"], 1);
            assert_eq!(after["condition"]["hp"], c["condition"]["hp"]);
            save_to_pool(&p, b).await.unwrap();
            assert_eq!(saved(&p, &c).await, after);
            assert!(save_to_pool(&p, bonus(&after, &r)).await.is_err());
            let mut other = r.clone();
            other.id = next_id();
            save_to_pool(&p, other.clone()).await.unwrap();
            assert!(save_to_pool(&p, bonus(&c, &other)).await.is_err());
            let mut invalid = bonus(&after, &other);
            invalid.supplement.as_mut().unwrap().failed = false;
            assert!(save_to_pool(&p, invalid).await.is_err());
            assert_eq!(saved(&p, &c).await, after);
        });
    }
    #[test]
    fn meal_consumption_is_saved_with_the_roll_once_and_stale_requests_roll_back() {
        tauri::async_runtime::block_on(async {
            let (p, c) = fixture("meal").await;
            let mut r = check(&c);
            let meta = r.character_check.as_mut().unwrap();
            meta.expected_revision = c["revision"].as_i64();
            meta.consumed_benefits = Some(vec![c["condition"]["downtime"]["benefits"][0]["id"]
                .as_str()
                .unwrap()
                .into()]);
            save_to_pool(&p, r.clone()).await.unwrap();
            let after = saved(&p, &c).await;
            assert_eq!(after["condition"]["downtime"]["benefits"], json!([]));
            save_to_pool(&p, r.clone()).await.unwrap();
            assert_eq!(saved(&p, &c).await, after);
            r.id = next_id();
            assert!(save_to_pool(&p, r).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM dice_rolls")
                    .fetch_one(&p)
                    .await
                    .unwrap(),
                1
            );
        });
    }
}
