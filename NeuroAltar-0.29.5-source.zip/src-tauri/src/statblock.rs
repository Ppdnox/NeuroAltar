use serde::{Deserialize, Deserializer, Serialize};
const MAX: i64 = 9_007_199_254_740_991;
fn required_nullable<'de, D, T>(deserializer: D) -> Result<Option<T>, D::Error>
where
    D: Deserializer<'de>,
    T: Deserialize<'de>,
{
    Option::<T>::deserialize(deserializer)
}
fn optional_nullable_lines<'de, D: Deserializer<'de>>(
    d: D,
) -> Result<Option<Option<Vec<String>>>, D::Error> {
    Option::<Vec<String>>::deserialize(d).map(Some)
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(deny_unknown_fields)]
pub(super) struct Abilities {
    #[serde(deserialize_with = "required_nullable")]
    pub str: Option<i64>,
    #[serde(deserialize_with = "required_nullable")]
    pub dex: Option<i64>,
    #[serde(deserialize_with = "required_nullable")]
    pub con: Option<i64>,
    #[serde(deserialize_with = "required_nullable")]
    pub int: Option<i64>,
    #[serde(deserialize_with = "required_nullable")]
    pub wis: Option<i64>,
    #[serde(deserialize_with = "required_nullable")]
    pub cha: Option<i64>,
}
impl Abilities {
    fn valid(&self, min: i64) -> bool {
        [self.str, self.dex, self.con, self.int, self.wis, self.cha]
            .iter()
            .all(|n| n.is_none_or(|v| (min..=MAX).contains(&v)))
    }
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Statblock {
    #[serde(deserialize_with = "required_nullable")]
    pub subtype: Option<String>,
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "optional_nullable_lines"
    )]
    pub traits: Option<Option<Vec<String>>>,
    pub ability_scores: Abilities,
    pub saving_throws: Abilities,
    #[serde(deserialize_with = "required_nullable")]
    pub skills: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub senses: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub resistances: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub vulnerabilities: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub damage_immunities: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub condition_immunities: Option<Vec<String>>,
    #[serde(deserialize_with = "required_nullable")]
    pub damage_threshold: Option<i64>,
}
fn text(s: &str, max: usize) -> bool {
    !s.trim().is_empty() && s.trim().encode_utf16().count() <= max
}
pub(super) fn valid(s: &Statblock) -> bool {
    s.traits.as_ref().is_none_or(|v| {
        v.as_ref()
            .is_none_or(|lines| lines.len() <= 100 && lines.iter().all(|s| text(s, 1000)))
    }) && s.subtype.as_ref().is_none_or(|s| text(s, 200))
        && s.ability_scores.valid(0)
        && s.saving_throws.valid(-MAX)
        && s.damage_threshold.is_none_or(|n| (0..=MAX).contains(&n))
        && [
            &s.skills,
            &s.senses,
            &s.resistances,
            &s.vulnerabilities,
            &s.damage_immunities,
            &s.condition_immunities,
        ]
        .iter()
        .all(|list| {
            list.as_ref()
                .is_none_or(|lines| lines.len() <= 100 && lines.iter().all(|s| text(s, 1000)))
        })
}
