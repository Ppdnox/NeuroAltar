use super::item::{valid_catalog_item, Item};
use serde::Deserialize;
use sqlx::{Row, SqlitePool};
use std::collections::HashSet;
use tauri_plugin_sql::DbInstances;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Batch {
    batch_id: String,
    source_sha256: String,
    entries: Vec<Item>,
}
fn bundled() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/equipment/catalog.v1.json"))
        .map_err(|e| format!("Dane Ekwipunku: {e}"))
}
fn moloch_city() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/equipment/moloch-city.v1.json"))
        .map_err(|e| format!("Ekwipunek Moloch City: {e}"))
}
async fn apply(pool: &SqlitePool, batch: &Batch) -> Result<(), String> {
    let mut ids = HashSet::new();
    if !((batch.batch_id == "excel-equipment-v1" && batch.entries.len() == 299)
        || (batch.batch_id == "moloch-city-equipment-v1" && batch.entries.len() == 2))
        || batch.source_sha256.len() != 64
        || !batch.source_sha256.bytes().all(|b| b.is_ascii_hexdigit())
        || batch
            .entries
            .iter()
            .any(|i| !valid_catalog_item(i) || !ids.insert(&i.id))
    {
        return Err("Niepoprawny zestaw Ekwipunku.".into());
    }
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    // Acquire the write lock before checking the ledger, also for concurrent startup.
    sqlx::query("UPDATE equipment_seed_batches SET entry_count=entry_count WHERE 0")
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    if let Some(row) =
        sqlx::query("SELECT source_sha256,entry_count FROM equipment_seed_batches WHERE batch_id=?")
            .bind(&batch.batch_id)
            .fetch_optional(&mut *tx)
            .await
            .map_err(|e| e.to_string())?
    {
        if row.get::<String, _>("source_sha256") != batch.source_sha256
            || row.get::<i64, _>("entry_count") != batch.entries.len() as i64
        {
            return Err("Zmieniono tożsamość jednorazowego zestawu Ekwipunku.".into());
        }
        // Never restore missing/deleted items or overwrite later MG edits.
        tx.commit().await.map_err(|e| e.to_string())?;
        return Ok(());
    }
    for item in &batch.entries {
        sqlx::query("INSERT INTO items (id,item_json) VALUES (?,?) ON CONFLICT(id) DO NOTHING")
            .bind(&item.id)
            .bind(serde_json::to_string(item).map_err(|e| e.to_string())?)
            .execute(&mut *tx)
            .await
            .map_err(|e| e.to_string())?;
    }
    sqlx::query(
        "INSERT INTO equipment_seed_batches (batch_id,source_sha256,entry_count) VALUES (?,?,?)",
    )
    .bind(&batch.batch_id)
    .bind(&batch.source_sha256)
    .bind(batch.entries.len() as i64)
    .execute(&mut *tx)
    .await
    .map_err(|e| e.to_string())?;
    tx.commit().await.map_err(|e| e.to_string())
}
#[tauri::command]
pub async fn seed_equipment(db_instances: tauri::State<'_, DbInstances>) -> Result<(), String> {
    let databases = db_instances.0.read().await;
    let pool = match databases.get("sqlite:combat-tracker.db") {
        Some(tauri_plugin_sql::DbPool::Sqlite(pool)) => pool.clone(),
        _ => return Err("Baza nie jest otwarta.".into()),
    };
    drop(databases);
    apply(&pool, &bundled()?).await?;
    apply(&pool, &moloch_city()?)
        .await
        .map_err(|e| format!("Nie udało się przygotować Ekwipunku: {e}"))
}

#[cfg(test)]
mod tests {
    use super::super::{
        save_to_pool,
        tests::{database, enemy_state},
    };
    use super::*;
    async fn setup() -> SqlitePool {
        let pool = database().await;
        sqlx::raw_sql(include_str!("../migrations/009_equipment.sql"))
            .execute(&pool)
            .await
            .unwrap();
        pool
    }
    async fn count(pool: &SqlitePool, table: &str) -> i64 {
        sqlx::query_scalar(&format!("SELECT count(*) FROM {table}"))
            .fetch_one(pool)
            .await
            .unwrap()
    }
    #[test]
    fn supplement_equipment_adds_two_without_replacing_catalog() {
        tauri::async_runtime::block_on(async {
            let pool = setup().await;
            apply(&pool, &bundled().unwrap()).await.unwrap();
            let before: Vec<(String, String)> =
                sqlx::query_as("SELECT id,item_json FROM items ORDER BY id")
                    .fetch_all(&pool)
                    .await
                    .unwrap();
            apply(&pool, &moloch_city().unwrap()).await.unwrap();
            apply(&pool, &moloch_city().unwrap()).await.unwrap();
            let after: Vec<(String, String)> =
                sqlx::query_as("SELECT id,item_json FROM items ORDER BY id")
                    .fetch_all(&pool)
                    .await
                    .unwrap();
            assert_eq!(after.len(), before.len() + 2);
            for row in before {
                assert!(after.contains(&row));
            }
        });
    }
    #[test]
    fn migration_and_seed_preserve_existing_five_slots_actors_snapshots_and_logs() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            save_to_pool(&pool, enemy_state()).await.unwrap();
            async fn snapshot(
                pool: &SqlitePool,
            ) -> (
                Vec<(String, String, String, String)>,
                Vec<(i64, String)>,
                Vec<(i64, String)>,
                Vec<(String, String)>,
            ) {
                (sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(pool).await.unwrap(),
                 sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id").fetch_all(pool).await.unwrap(),
                 sqlx::query_as("SELECT id,name FROM encounters ORDER BY id").fetch_all(pool).await.unwrap(),
                 sqlx::query_as("SELECT id,statblock_json FROM enemy_templates ORDER BY id").fetch_all(pool).await.unwrap())
            }
            let before = snapshot(&pool).await;
            sqlx::raw_sql(include_str!("../migrations/009_equipment.sql"))
                .execute(&pool)
                .await
                .unwrap();
            let batch = bundled().unwrap();
            apply(&pool, &batch).await.unwrap();
            apply(&pool, &batch).await.unwrap();
            assert_eq!(count(&pool, "items").await, 299);
            assert_eq!(count(&pool, "equipment_seed_batches").await, 1);
            assert_eq!(snapshot(&pool).await, before);
            assert_eq!(count(&pool, "encounters").await, 5);
            pool.close().await;
        });
    }
    #[test]
    fn failure_rolls_back_whole_seed_and_retry_is_safe() {
        tauri::async_runtime::block_on(async {
            let pool = setup().await;
            sqlx::raw_sql("CREATE TRIGGER fail_equipment BEFORE INSERT ON items WHEN (SELECT count(*) FROM items)=5 BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
            assert!(apply(&pool, &bundled().unwrap()).await.is_err());
            assert_eq!(count(&pool, "items").await, 0);
            assert_eq!(count(&pool, "equipment_seed_batches").await, 0);
            sqlx::raw_sql("DROP TRIGGER fail_equipment")
                .execute(&pool)
                .await
                .unwrap();
            apply(&pool, &bundled().unwrap()).await.unwrap();
            assert_eq!(count(&pool, "items").await, 299);
            pool.close().await;
        });
    }
    #[test]
    fn collisions_later_edits_tombstones_and_missing_rows_are_never_overwritten() {
        tauri::async_runtime::block_on(async {
            let pool = setup().await;
            let batch = bundled().unwrap();
            sqlx::query("INSERT INTO items(id,item_json,revision) VALUES (?,'{}',4)")
                .bind(&batch.entries[0].id)
                .execute(&pool)
                .await
                .unwrap();
            apply(&pool, &batch).await.unwrap();
            sqlx::query("UPDATE items SET item_json='{}',revision=1 WHERE id=?")
                .bind(&batch.entries[1].id)
                .execute(&pool)
                .await
                .unwrap();
            sqlx::query("UPDATE items SET deleted=1 WHERE id=?")
                .bind(&batch.entries[2].id)
                .execute(&pool)
                .await
                .unwrap();
            sqlx::query("DELETE FROM items WHERE id=?")
                .bind(&batch.entries[3].id)
                .execute(&pool)
                .await
                .unwrap();
            async fn rows(pool: &SqlitePool) -> Vec<(String, String, i64, i64)> {
                sqlx::query_as("SELECT id,item_json,revision,deleted FROM items ORDER BY id")
                    .fetch_all(pool)
                    .await
                    .unwrap()
            }
            let before = rows(&pool).await;
            apply(&pool, &batch).await.unwrap();
            assert_eq!(rows(&pool).await, before);
            assert_eq!(count(&pool, "items").await, 298);
            pool.close().await;
        });
    }
    #[test]
    fn invalid_catalog_and_duplicate_identity_do_not_write() {
        tauri::async_runtime::block_on(async {
            let pool = setup().await;
            let mut batch = bundled().unwrap();
            batch.entries[1] = batch.entries[0].clone();
            assert!(apply(&pool, &batch).await.is_err());
            assert_eq!(count(&pool, "items").await, 0);
            pool.close().await;
        });
    }
}
