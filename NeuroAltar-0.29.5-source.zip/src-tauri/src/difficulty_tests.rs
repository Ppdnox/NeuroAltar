use super::{
    log::SaveReason,
    save_to_pool, save_with_reason,
    tests::{database, enemy_state},
    validate,
};
#[test]
fn validates_legacy_zero_decimal_and_invalid_sp_in_runtime_template_and_prepared() {
    let mut state = enemy_state();
    assert!(validate(&state).is_ok());
    for n in [0.0, 2.5, 9_007_199_254_740_991.0] {
        state.actors[1].enemy.as_mut().unwrap().sp = Some(n);
        assert!(validate(&state).is_ok());
    }
    for n in [-1.0, f64::NAN, f64::INFINITY, 9_007_199_254_740_992.0] {
        state.actors[1].enemy.as_mut().unwrap().sp = Some(n);
        assert!(validate(&state).is_err());
    }
    state = enemy_state();
    state.actors[1].enemy.as_mut().unwrap().template.sp = Some(-1.0);
    assert!(validate(&state).is_err());
    state = enemy_state();
    state.actors[1]
        .prepared
        .as_mut()
        .unwrap()
        .enemy
        .as_mut()
        .unwrap()
        .sp = Some(-1.0);
    assert!(validate(&state).is_err());
}
#[test]
fn sp_and_log_are_atomic_retry_once_and_reset_preserves_catalog_siblings_and_levels() {
    tauri::async_runtime::block_on(async {
        let pool = database().await;
        let mut state = enemy_state();
        for actor in &mut state.actors {
            if let Some(enemy) = &mut actor.enemy {
                enemy.sp = Some(8.0);
                enemy.template.sp = Some(8.0);
                let mut p = actor.clone();
                p.prepared = None;
                actor.prepared = Some(Box::new(p));
            }
        }
        sqlx::query("UPDATE encounters SET party_levels_json='[4,4,4,4]' WHERE id=1")
            .execute(&pool)
            .await
            .unwrap();
        state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
        state.actors[1].enemy.as_mut().unwrap().sp = Some(2.5);
        sqlx::raw_sql("CREATE TRIGGER fail_sp_log BEFORE INSERT ON combat_log WHEN NEW.event_type='sp_changed' BEGIN SELECT RAISE(ABORT,'blocked'); END;").execute(&pool).await.unwrap();
        assert!(save_to_pool(&pool, state.clone()).await.is_err());
        let read="SELECT json_extract(runtime_overrides_json,'$.enemy.sp') FROM encounter_actors WHERE id=?";
        assert_eq!(
            sqlx::query_scalar::<_, f64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            8.0
        );
        sqlx::raw_sql("DROP TRIGGER fail_sp_log")
            .execute(&pool)
            .await
            .unwrap();
        state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, f64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            2.5
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM combat_log WHERE event_type='sp_changed'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, f64>(
                "SELECT json_extract(statblock_json,'$.sp') FROM enemy_templates"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            8.0
        );
        assert_eq!(
            sqlx::query_scalar::<_, f64>(read)
                .bind(&state.actors[2].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            8.0
        );
        state.actors[1] = *state.actors[1].prepared.clone().unwrap();
        state.round_number = 1;
        state.current_turn_actor_id = None;
        state = super::tests::reset_saved(&pool, 1).await;
        save_with_reason(&pool, state.clone(), SaveReason::Reset)
            .await
            .unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, f64>(read)
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            8.0
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("SELECT party_levels_json FROM encounters WHERE id=1")
                .fetch_one(&pool)
                .await
                .unwrap(),
            "[4,4,4,4]"
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                .fetch_one(&pool)
                .await
                .unwrap(),
            5
        );
        pool.close().await;
    });
}
