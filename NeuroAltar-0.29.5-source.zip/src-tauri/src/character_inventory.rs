use super::{choice, integer, keys, string};
use serde_json::{json, Value};
use std::collections::HashSet;
fn err(s: &str) -> String {
    format!("Inwentarz: {s}")
}
fn uuid(v: &Value) -> Result<(), String> {
    uuid::Uuid::parse_str(string(v, 100)?)
        .map(|_| ())
        .map_err(|_| err("niepoprawny identyfikator"))
}
fn boolean(v: &Value) -> Result<(), String> {
    v.as_bool()
        .map(|_| ())
        .ok_or_else(|| err("niepoprawna wartość logiczna"))
}
fn array(v: &Value, max: usize) -> Result<&Vec<Value>, String> {
    v.as_array()
        .filter(|a| a.len() <= max)
        .ok_or_else(|| err("niepoprawna lista"))
}
fn n(v: &Value) -> i64 {
    v.as_i64().unwrap_or(0)
}
fn s(v: &Value) -> &str {
    v.as_str().unwrap_or("")
}
pub(super) fn empty() -> Value {
    json!({"entries":[],"ammoMode":"auto","starterClaims":[]})
}
fn index(entries: &[Value], id: &Value) -> Result<usize, String> {
    entries
        .iter()
        .position(|e| e["id"] == *id)
        .ok_or_else(|| err("nie znaleziono przedmiotu"))
}
fn parent(entries: &[Value], idx: usize) -> Option<usize> {
    entries
        .iter()
        .position(|e| e["installedMagazineId"] == entries[idx]["id"])
        .or_else(|| {
            entries
                .iter()
                .position(|e| e["id"] == entries[idx]["parentId"])
        })
}
fn ancestors(entries: &[Value], idx: usize) -> Result<Vec<usize>, String> {
    let mut seen = HashSet::from([idx]);
    let mut out = vec![];
    let mut p = parent(entries, idx);
    while let Some(x) = p {
        if !seen.insert(x) {
            return Err(err("cykl pojemników"));
        }
        out.push(x);
        p = parent(entries, x);
    }
    Ok(out)
}
fn rounds(e: &Value) -> i64 {
    e["magazine"]["rounds"]
        .as_array()
        .map_or(0, |a| a.iter().map(|l| n(&l["count"])).sum())
}
const MELEE_SLOTS: [&str; 4] = ["melee1", "melee2", "melee3", "melee4"];
const RANGED_SLOTS: [&str; 3] = ["ranged1", "ranged2", "ranged3"];
const HANDY_SLOTS: [&str; 3] = ["handy1", "handy2", "handy3"];
const LEGACY_HANDS: [&str; 3] = ["mainHand", "offHand", "bothHands"];
fn normalized(text: &str) -> String {
    text.to_lowercase()
        .chars()
        .filter_map(|c| {
            Some(match c {
                '\u{0300}'..='\u{036f}' => return None,
                'ą' => 'a',
                'ć' => 'c',
                'ę' => 'e',
                'ł' => 'l',
                'ń' => 'n',
                'ó' => 'o',
                'ś' => 's',
                'ź' | 'ż' => 'z',
                other => other,
            })
        })
        .collect()
}
fn weapon_slot_kind(e: &Value) -> Option<&'static str> {
    if e["item"]["type"] != "weapon" {
        return None;
    }
    if !e["weapon"].is_null() {
        return Some(
            if ["melee", "improvised"].contains(&s(&e["weapon"]["category"])) {
                "melee"
            } else {
                "ranged"
            },
        );
    }
    if !e["item"]["weaponProfile"].is_null() {
        return Some(if e["item"]["weaponProfile"]["attackKind"] == "melee" {
            "melee"
        } else {
            "ranged"
        });
    }
    let category = normalized(s(&e["item"]["category"]));
    if ["biala", "wrecz"]
        .iter()
        .any(|part| category.contains(part))
    {
        Some("melee")
    } else if [
        "palna", "dystans", "miotana", "laser", "granat", "wybuch", "miny",
    ]
    .iter()
    .any(|part| category.contains(part))
    {
        Some("ranged")
    } else {
        None
    }
}
fn handy_eligible(e: &Value) -> bool {
    if !e["armor"].is_null() || e["item"]["type"] == "armor" {
        return false;
    }
    if e["item"]["type"] != "weapon" {
        return true;
    }
    if !e["weapon"].is_null() {
        return e["weapon"]["system"] == "singleUse";
    }
    let category = normalized(s(&e["item"]["category"]));
    let name = normalized(s(&e["item"]["name"]));
    ["granat", "wybuch", "miny"]
        .iter()
        .any(|part| category.contains(part))
        || name.strip_prefix("granat").is_some_and(|rest| {
            rest.chars()
                .next()
                .is_none_or(|c| !c.is_ascii_alphanumeric() && c != '_')
        })
}
fn numbered_weapon_slot(slot: &str) -> bool {
    MELEE_SLOTS.contains(&slot) || RANGED_SLOTS.contains(&slot)
}
fn compatible_weapon_slot(e: &Value, slot: &str) -> bool {
    match weapon_slot_kind(e) {
        Some("melee") => MELEE_SLOTS.contains(&slot),
        Some("ranged") => RANGED_SLOTS.contains(&slot),
        _ => false,
    }
}
/// Prepared storage is independent of the number of hands used for an attack.
pub(super) fn ready_weapon(e: &Value) -> bool {
    if e["weapon"].is_null()
        || e["item"]["type"] != "weapon"
        || !e["parentId"].is_null()
        || !["body", "handy"].contains(&s(&e["location"]))
    {
        return false;
    }
    let slot = s(&e["slot"]);
    LEGACY_HANDS.contains(&slot)
        || (e["location"] == "body" && compatible_weapon_slot(e, slot))
        || (e["location"] == "handy" && HANDY_SLOTS.contains(&slot) && handy_eligible(e))
}
fn validate_entry(e: &Value) -> Result<(), String> {
    let mut legacy = e.clone();
    if let Some(o) = legacy.as_object_mut() {
        o.remove("combatState");
        o.remove("grip");
    }
    keys(
        &legacy,
        &[
            "id",
            "item",
            "catalogId",
            "quantityMilli",
            "unit",
            "weightMg",
            "weightReason",
            "massMode",
            "container",
            "location",
            "parentId",
            "slot",
            "paidMilli",
            "notes",
            "caliber",
            "weapon",
            "armor",
            "magazine",
            "installedMagazineId",
            "needsCycle",
            "cinematicLoaded",
            "spent",
            "armorDamage",
        ],
    )?;
    if let Some(v) = e.get("combatState") {
        keys(v, &["jammed", "overheated", "heatPending"])?;
        for k in ["jammed", "overheated", "heatPending"] {
            boolean(&v[k])?;
        }
    }
    if let Some(grip) = e.get("grip") {
        choice(grip, &["oneHanded", "twoHanded"])?;
    }
    uuid(&e["id"])?;
    for k in ["catalogId", "parentId", "installedMagazineId"] {
        if !e[k].is_null() {
            uuid(&e[k])?;
        }
    }
    let item: crate::combat::item::Item =
        serde_json::from_value(e["item"].clone()).map_err(|_| err("niepoprawny przedmiot"))?;
    if !crate::combat::item::valid_catalog_item(&item) {
        return Err(err("niepoprawny przedmiot"));
    }
    integer(&e["quantityMilli"], 0, 1_000_000_000)?;
    for k in ["weightMg", "paidMilli"] {
        if !e[k].is_null() {
            integer(&e[k], 0, 1_000_000_000)?;
        }
    }
    integer(&e["armorDamage"], 0, 100)?;
    for k in ["unit", "weightReason", "caliber"] {
        string(&e[k], 300)?;
    }
    if s(&e["unit"]).is_empty() {
        return Err(err("brak jednostki"));
    }
    string(&e["notes"], 10000)?;
    for k in ["container", "needsCycle", "cinematicLoaded", "spent"] {
        boolean(&e[k])?;
    }
    choice(&e["massMode"], &["unit", "aggregate"])?;
    choice(&e["location"], &["body", "handy", "backpack", "external"])?;
    choice(
        &e["slot"],
        &[
            "none",
            "armor",
            "helmet",
            "arms",
            "legs",
            "mainHand",
            "offHand",
            "bothHands",
            "melee1",
            "melee2",
            "melee3",
            "melee4",
            "ranged1",
            "ranged2",
            "ranged3",
            "handy1",
            "handy2",
            "handy3",
            "shield",
        ],
    )?;
    let w = &e["weapon"];
    if !w.is_null() {
        let mut legacy_weapon = w.clone();
        if let Some(object) = legacy_weapon.as_object_mut() {
            object.remove("family");
        }
        keys(
            &legacy_weapon,
            &[
                "category",
                "model",
                "caliber",
                "system",
                "capacity",
                "modes",
                "cycle",
                "twoHanded",
                "handy",
                "source",
            ],
        )?;
        choice(
            &w["category"],
            &[
                "melee",
                "thrown",
                "short",
                "intermediate",
                "long",
                "heavy",
                "special",
                "improvised",
            ],
        )?;
        if let Some(family) = w.get("family") {
            choice(family, &["revolver", "smg", "axe"])?;
            let category = s(&w["category"]);
            if ((family == "revolver" || family == "smg") && category != "short")
                || (family == "axe" && !["melee", "thrown"].contains(&category))
            {
                return Err(err("rodzaj broni nie pasuje do kategorii"));
            }
        }
        choice(
            &w["system"],
            &["none", "detachable", "internal", "loading", "singleUse"],
        )?;
        for k in ["model", "caliber", "source"] {
            string(&w[k], 300)?;
        }
        if s(&w["model"]).is_empty() || s(&w["source"]).is_empty() {
            return Err(err("brak źródła lub modelu broni"));
        }
        integer(&w["capacity"], 0, 10000)?;
        for k in ["cycle", "twoHanded", "handy"] {
            boolean(&w[k])?;
        }
        let modes = array(&w["modes"], 100)?;
        if modes.is_empty() {
            return Err(err("brak trybu ognia"));
        }
        for m in modes {
            choice(m, &["single", "double", "short", "long", "massive"])?;
        }
    }
    let a = &e["armor"];
    if !a.is_null() {
        keys(
            a,
            &[
                "kind",
                "base",
                "dexCap",
                "strength",
                "penalty",
                "threshold",
                "source",
            ],
        )?;
        choice(
            &a["kind"],
            &[
                "light", "medium", "heavy", "helmet", "arms", "legs", "shield",
            ],
        )?;
        for k in ["base", "threshold"] {
            integer(&a[k], 0, 100)?;
        }
        integer(&a["strength"], 0, 30)?;
        if !a["dexCap"].is_null() {
            integer(&a["dexCap"], 0, 30)?;
        }
        choice(&a["penalty"], &["none", "disadvantage", "impossible"])?;
        if string(&a["source"], 300)?.is_empty() {
            return Err(err("brak źródła pancerza"));
        }
    }
    let m = &e["magazine"];
    if !m.is_null() {
        keys(m, &["capacity", "caliber", "model", "rounds"])?;
        integer(&m["capacity"], 1, 10000)?;
        for k in ["caliber", "model"] {
            if string(&m[k], 300)?.is_empty() {
                return Err(err("brak kalibru lub modelu magazynka"));
            }
        }
        for l in array(&m["rounds"], 1000)? {
            keys(l, &["ammoId", "count"])?;
            uuid(&l["ammoId"])?;
            integer(&l["count"], 1, 10000)?;
        }
    }
    Ok(())
}
pub(super) fn validate(v: &Value) -> Result<(), String> {
    keys(v, &["entries", "ammoMode", "starterClaims"])?;
    choice(&v["ammoMode"], &["auto", "tracked", "cinematic"])?;
    let mut claims = HashSet::new();
    for c in array(&v["starterClaims"], 100)? {
        let c = string(c, 300)?;
        if c.is_empty() || !claims.insert(c) {
            return Err(err("powtórzony lub pusty zestaw"));
        }
    }
    let es = array(&v["entries"], 5000)?;
    let mut ids = HashSet::new();
    let mut slots = HashSet::new();
    let (mut melee, mut ranged, mut handy) = (0, 0, 0);
    for (idx, e) in es.iter().enumerate() {
        validate_entry(e)?;
        let check = |bad: bool, message: &str| -> Result<(), String> {
            if bad {
                Err(format!("{} — {}", s(&e["item"]["name"]), message))
            } else {
                Ok(())
            }
        };
        check(!ids.insert(s(&e["id"])), "powtórzone ID")?;
        check(
            !e["weightMg"].is_null() && s(&e["weightReason"]).trim().is_empty(),
            "podaj uzasadnienie masy",
        )?;
        check(
            e["massMode"] == "aggregate"
                && (e["container"] != true || n(&e["quantityMilli"]) != 1000),
            "masa całego zestawu wymaga jednego pojemnika",
        )?;
        check(
            (!e["weapon"].is_null()
                || !e["magazine"].is_null()
                || e["slot"] != "none"
                || e["container"] == true)
                && n(&e["quantityMilli"]) != 1000,
            "egzemplarz wymaga ilości 1",
        )?;
        check(
            !s(&e["caliber"]).is_empty()
                && (n(&e["quantityMilli"]) % 1000 != 0
                    || !e["weapon"].is_null()
                    || !e["magazine"].is_null()
                    || e["item"]["type"] != "ammunition"),
            "nieprawidłowy zapas naboi",
        )?;
        check(
            !e["weapon"].is_null() && e["item"]["type"] != "weapon",
            "nieprawidłowy typ broni",
        )?;
        check(
            !e["armor"].is_null() && e["item"]["type"] != "armor",
            "nieprawidłowy typ pancerza",
        )?;
        if !e["parentId"].is_null() {
            check(
                es[index(es, &e["parentId"])?]["container"] != true,
                "rodzic nie jest pojemnikiem",
            )?;
        }
        let an = ancestors(es, idx)?;
        let place = an.last().map_or(&e["location"], |p| &es[*p]["location"]);
        check(
            an.iter().any(|p| es[*p]["massMode"] == "aggregate")
                && (!s(&e["caliber"]).is_empty()
                    || !e["magazine"].is_null()
                    || !e["weapon"].is_null()
                    || e["slot"] != "none"),
            "najpierw wyodrębnij wyposażenie z masy zestawu",
        )?;
        let slot = s(&e["slot"]);
        if slot != "none" {
            check(
                place == "external" || place == "backpack" || !e["parentId"].is_null(),
                "wyposażenie musi być przy sobie",
            )?;
            // The legacy shield used offHand; it still occupies the one shield place.
            let unique_slot = if e["armor"]["kind"] == "shield" {
                "shield"
            } else {
                slot
            };
            check(
                slots.contains(unique_slot)
                    || (LEGACY_HANDS[..2].contains(&slot) && slots.contains("bothHands"))
                    || (slot == "bothHands"
                        && (slots.contains("mainHand") || slots.contains("offHand"))),
                "miejsce wyposażenia jest zajęte",
            )?;
            slots.insert(unique_slot);
            // Retain the hand collision marker for historical shields.
            if slot == "offHand" {
                slots.insert(slot);
            }
            if numbered_weapon_slot(slot) {
                check(
                    place != "body" || !compatible_weapon_slot(e, slot),
                    "typ broni nie pasuje do slotu",
                )?;
                check(
                    e["weapon"]["twoHanded"] == true && e["grip"] == "oneHanded",
                    "broń wymaga obu rąk",
                )?;
            } else if HANDY_SLOTS.contains(&slot) {
                check(
                    place != "handy" || !handy_eligible(e),
                    "przedmiot nie pasuje do slotu podręcznego",
                )?;
                check(
                    e["weapon"]["twoHanded"] == true && e["grip"] == "oneHanded",
                    "broń wymaga obu rąk",
                )?;
            } else {
                let armor_slot = match s(&e["armor"]["kind"]) {
                    "light" | "medium" | "heavy" => "armor",
                    "helmet" => "helmet",
                    "arms" => "arms",
                    "legs" => "legs",
                    "shield" => {
                        if slot == "offHand" {
                            "offHand"
                        } else {
                            "shield"
                        }
                    }
                    _ => "",
                };
                check(
                    (["armor", "helmet", "arms", "legs", "shield"].contains(&slot)
                        || !e["armor"].is_null())
                        && armor_slot != slot,
                    "profil nie pasuje do miejsca wyposażenia",
                )?;
                check(
                    e["weapon"]["twoHanded"] == true && slot != "bothHands",
                    "broń wymaga obu rąk",
                )?;
            }
        }
        let installed = es.iter().any(|w| w["installedMagazineId"] == e["id"]);
        if HANDY_SLOTS.contains(&slot) {
            handy += 1000;
        } else if place == "handy" && e["weapon"].is_null() && e["parentId"].is_null() && !installed
        {
            handy += n(&e["quantityMilli"]);
        }
        if numbered_weapon_slot(slot) {
            if MELEE_SLOTS.contains(&slot) {
                melee += 1;
            } else {
                ranged += 1;
            }
        } else if !HANDY_SLOTS.contains(&slot)
            && (place == "body" || place == "handy")
            && !e["weapon"].is_null()
            && e["parentId"].is_null()
        {
            // Preserve the counting rule of existing snapshots.
            if e["weapon"]["category"] == "melee" {
                melee += 1;
            } else {
                ranged += 1;
            }
        }
        if !e["installedMagazineId"].is_null() {
            let m = &es[index(es, &e["installedMagazineId"])?];
            let w = &e["weapon"];
            check(
                w["system"] != "detachable"
                    || m["magazine"].is_null()
                    || !m["weapon"].is_null()
                    || !m["parentId"].is_null()
                    || m["slot"] != "none"
                    || m["id"] == e["id"],
                "nieprawidłowy magazynek",
            )?;
            for k in ["model", "caliber", "capacity"] {
                check(m["magazine"][k] != w[k], "magazynek nie pasuje do broni")?;
            }
            check(
                es.iter()
                    .filter(|w| w["installedMagazineId"] == m["id"])
                    .count()
                    != 1,
                "magazynek jest już w innej broni",
            )?;
        }
        if !e["weapon"].is_null() {
            let w = &e["weapon"];
            if ["internal", "loading"].contains(&s(&w["system"])) {
                check(e["magazine"].is_null(), "brak magazynka wewnętrznego")?;
                for k in ["model", "caliber", "capacity"] {
                    check(e["magazine"][k] != w[k], "niezgodny magazynek wewnętrzny")?;
                }
            } else {
                check(
                    !e["magazine"].is_null(),
                    "broń nie ma magazynka wewnętrznego",
                )?;
            }
        }
        if !e["magazine"].is_null() {
            check(
                rounds(e) > n(&e["magazine"]["capacity"]),
                "przekroczona pojemność",
            )?;
            for l in e["magazine"]["rounds"].as_array().unwrap() {
                let a = &es[index(es, &l["ammoId"])?];
                check(
                    s(&a["caliber"]).is_empty()
                        || a["caliber"] != e["magazine"]["caliber"]
                        || !a["weapon"].is_null()
                        || !a["magazine"].is_null()
                        || a["item"]["type"] != "ammunition",
                    "niekompatybilny nabój",
                )?;
            }
        }
    }
    if handy > 3000 || melee > 4 || ranged > 3 {
        return Err(err(
            "przekroczony limit przedmiotów pod ręką lub przygotowanych broni",
        ));
    }
    if es
        .iter()
        .any(|e| e["slot"] == "armor" && e["armor"]["kind"] == "heavy")
        && es
            .iter()
            .any(|e| e["slot"] == "arms" || e["slot"] == "legs")
    {
        return Err(err("ciężki pancerz nie łączy się z ochraniaczami"));
    }
    Ok(())
}
pub(super) fn apply(
    before: &Value,
    a: &Value,
    color: &str,
    ignore_cycle: bool,
) -> Result<Value, String> {
    validate(before)?;
    let mut i = before.clone();
    let movie = i["ammoMode"] == "cinematic" || (i["ammoMode"] == "auto" && color == "chrome");
    let kind = string(&a["kind"], 100)?;
    let fields: &[&str] = match kind {
        "weaponState" => &["kind", "weaponId", "operation", "face", "reason"],
        "edit" => &["kind", "entry", "reason"],
        "remove" => &["kind", "entryId", "reason"],
        "load" => &["kind", "magazineId", "ammoId", "count"],
        "unload" => &["kind", "magazineId"],
        "attach" => &["kind", "weaponId", "magazineId"],
        "cycle" => &["kind", "weaponId"],
        "shot" => &["kind", "weaponId", "mode", "count"],
        "cinematic" => &["kind", "weaponId", "loaded"],
        "mode" => &["kind", "mode"],
        "starter" => &["kind", "key", "entries"],
        _ => return Err(err("nieznana operacja")),
    };
    let mut checked = a.clone();
    if kind == "shot" {
        if let Some(value) = checked.as_object_mut().unwrap().remove("favoriteBonus") {
            if !value.is_boolean() {
                return Err(err("niepoprawny tryb Ulubionej broni"));
            }
        }
    }
    keys(&checked, fields)?;
    if ["edit", "remove"].contains(&kind) && string(&a["reason"], 300)?.trim().is_empty() {
        return Err(err("podaj powód nabycia lub korekty"));
    }
    if kind == "mode" {
        i["ammoMode"] = a["mode"].clone();
        validate(&i)?;
        return Ok(i);
    }
    if kind == "starter" {
        let complete = ["initial-loadout:equipment", "initial-loadout:gamble"]
            .contains(&a["key"].as_str().unwrap_or(""));
        let claims = i["starterClaims"].as_array().unwrap();
        if (!complete && a["key"] != "initial-equipment")
            || claims.contains(&a["key"])
            || (complete
                && claims.iter().any(|key| {
                    ["initial-loadout:equipment", "initial-loadout:gamble"]
                        .contains(&key.as_str().unwrap_or(""))
                }))
        {
            return Err(err("wyposażenie startowe przyznaje się raz"));
        }
        let es = array(&a["entries"], 5000)?;
        if es.is_empty() && (!complete || !claims.contains(&json!("initial-equipment"))) {
            return Err(err("brak zestawu"));
        }
        for e in es {
            validate_entry(e)?;
            if i["entries"]
                .as_array()
                .unwrap()
                .iter()
                .any(|x| x["id"] == e["id"])
                || rounds(e) > 0
                || !e["installedMagazineId"].is_null()
            {
                return Err(err("nieprawidłowy nowy egzemplarz"));
            }
            i["entries"].as_array_mut().unwrap().push(e.clone());
        }
        if complete
            && !i["starterClaims"]
                .as_array()
                .unwrap()
                .contains(&json!("initial-equipment"))
        {
            i["starterClaims"]
                .as_array_mut()
                .unwrap()
                .push(json!("initial-equipment"));
        }
        i["starterClaims"]
            .as_array_mut()
            .unwrap()
            .push(a["key"].clone());
        validate(&i)?;
        return Ok(i);
    }
    let es = i["entries"].as_array_mut().unwrap();
    if kind == "edit" {
        let e = &a["entry"];
        validate_entry(e)?;
        if let Ok(idx) = index(es, &e["id"]) {
            let old = &es[idx];
            let empty = json!([]);
            let old_rounds = old["magazine"].get("rounds").unwrap_or(&empty);
            let new_rounds = e["magazine"].get("rounds").unwrap_or(&empty);
            if old_rounds != new_rounds {
                return Err(err("naboje przenoś poleceniem ładowania"));
            }
            if ancestors(es, idx)?
                .iter()
                .any(|p| es[*p]["massMode"] == "aggregate")
                && (old["parentId"] != e["parentId"] || old["quantityMilli"] != e["quantityMilli"])
            {
                return Err(err("najpierw rozdziel masę zestawu"));
            }
            es[idx] = e.clone();
        } else {
            if rounds(e) > 0 || !e["installedMagazineId"].is_null() {
                return Err(err("nowy magazynek musi być pusty"));
            }
            es.push(e.clone());
        }
    } else if kind == "remove" {
        let idx = index(es, &a["entryId"])?;
        let e = &es[idx];
        if rounds(e) > 0
            || !e["installedMagazineId"].is_null()
            || es.iter().any(|p| {
                p["parentId"] == e["id"]
                    || p["installedMagazineId"] == e["id"]
                    || p["magazine"]["rounds"]
                        .as_array()
                        .is_some_and(|ls| ls.iter().any(|l| l["ammoId"] == e["id"]))
            })
            || ancestors(es, idx)?
                .iter()
                .any(|p| es[*p]["massMode"] == "aggregate")
        {
            return Err(err("najpierw opróżnij, rozładuj i odłącz przedmiot"));
        }
        es.remove(idx);
    } else if kind == "load" {
        let m = index(es, &a["magazineId"])?;
        let stock = index(es, &a["ammoId"])?;
        let count = integer(&a["count"], 1, 10000)?;
        if es[m]["magazine"].is_null()
            || s(&es[stock]["caliber"]).is_empty()
            || es[stock]["caliber"] != es[m]["magazine"]["caliber"]
            || n(&es[stock]["quantityMilli"]) < count * 1000
            || rounds(&es[m]) + count > n(&es[m]["magazine"]["capacity"])
        {
            return Err(err("brakuje kompatybilnych naboi lub miejsca"));
        }
        es[stock]["quantityMilli"] = json!(n(&es[stock]["quantityMilli"]) - count * 1000);
        let lots = es[m]["magazine"]["rounds"].as_array_mut().unwrap();
        if let Some(l) = lots.iter_mut().find(|l| l["ammoId"] == a["ammoId"]) {
            l["count"] = json!(n(&l["count"]) + count);
        } else {
            lots.push(json!({"ammoId":a["ammoId"],"count":count}));
        }
    } else if kind == "unload" {
        let m = index(es, &a["magazineId"])?;
        let lots = array(&es[m]["magazine"]["rounds"], 1000)?.clone();
        for l in lots {
            let stock = index(es, &l["ammoId"])?;
            es[stock]["quantityMilli"] =
                json!(n(&es[stock]["quantityMilli"]) + n(&l["count"]) * 1000);
        }
        es[m]["magazine"]["rounds"] = json!([]);
    } else {
        let w = index(es, &a["weaponId"])?;
        match kind {
            "weaponState" => {
                if es[w]["weapon"].is_null() || es[w]["weapon"]["system"] == "none" {
                    return Err(err("wybierz broń strzelecką"));
                }
                if es[w].get("combatState").is_none() {
                    es[w]["combatState"] =
                        json!({"jammed":false,"overheated":false,"heatPending":false});
                }
                let state = &mut es[w]["combatState"];
                match s(&a["operation"]) {
                    "jam" => {
                        if color == "chrome" || state["jammed"] == true {
                            return Err(err("zacięcie niedostępne"));
                        }
                        state["jammed"] = json!(true);
                    }
                    "clearJam" => {
                        if state["jammed"] != true {
                            return Err(err("brak zacięcia"));
                        }
                        state["jammed"] = json!(false);
                    }
                    "heat" => {
                        if state["heatPending"] != true {
                            return Err(err("brak serii do rozliczenia"));
                        }
                        let face = integer(&a["face"], 1, 6)?;
                        state["heatPending"] = json!(false);
                        state["overheated"] = json!(face < 5);
                    }
                    "cool" => {
                        if string(&a["reason"], 300)?.trim().is_empty() {
                            return Err(err("podaj uzasadnienie ostygnięcia"));
                        }
                        state["overheated"] = json!(false);
                        state["heatPending"] = json!(false);
                    }
                    _ => return Err(err("nieznana operacja broni")),
                }
            }
            "attach" => {
                if es[w]["weapon"]["system"] != "detachable" {
                    return Err(err("broń nie ma wymiennego magazynka"));
                }
                if es[w]["installedMagazineId"] != a["magazineId"] {
                    let incoming = if a["magazineId"].is_null() {
                        None
                    } else {
                        Some(index(es, &a["magazineId"])?)
                    };
                    let handy_place = incoming
                        .filter(|m| HANDY_SLOTS.contains(&s(&es[*m]["slot"])))
                        .map(|m| {
                            (
                                es[m]["slot"].clone(),
                                es[m]["location"].clone(),
                                es[m]["parentId"].clone(),
                            )
                        });
                    if !es[w]["installedMagazineId"].is_null() {
                        let m = index(es, &es[w]["installedMagazineId"])?;
                        if let Some((slot, location, parent_id)) = &handy_place {
                            es[m]["slot"] = slot.clone();
                            es[m]["location"] = location.clone();
                            es[m]["parentId"] = parent_id.clone();
                        } else {
                            let an = ancestors(es, w)?;
                            es[m]["location"] = an
                                .last()
                                .map_or(&es[w]["location"], |p| &es[*p]["location"])
                                .clone();
                            es[m]["parentId"] = es[w]["parentId"].clone();
                        }
                    }
                    if let Some(m) = incoming.filter(|_| handy_place.is_some()) {
                        es[m]["slot"] = json!("none");
                    }
                    es[w]["installedMagazineId"] = a["magazineId"].clone();
                }
            }
            "cycle" => {
                if es[w]["weapon"]["cycle"] != true || es[w]["needsCycle"] != true {
                    return Err(err("broń nie wymaga przeładowania mechanizmu"));
                }
                es[w]["needsCycle"] = json!(false);
            }
            "cinematic" => {
                boolean(&a["loaded"])?;
                if !movie
                    || es[w]["weapon"].is_null()
                    || ["none", "singleUse"].contains(&s(&es[w]["weapon"]["system"]))
                {
                    return Err(err("tryb nieliczonego zapasu nie jest aktywny"));
                }
                es[w]["cinematicLoaded"] = a["loaded"].clone();
            }
            "shot" => {
                if es[w]["combatState"]["jammed"] == true {
                    return Err(err("broń jest zacięta"));
                }
                if ["long", "massive"].contains(&s(&a["mode"]))
                    && (es[w]["combatState"]["overheated"] == true
                        || es[w]["combatState"]["heatPending"] == true)
                {
                    return Err(err("rozlicz przegrzanie przed następną serią"));
                }
                if !ready_weapon(&es[w]) {
                    return Err(err("najpierw przypisz broń do odpowiedniego slotu"));
                }
                let count = integer(&a["count"], 1, 10000)?;
                let allowed: &[i64] = match s(&a["mode"]) {
                    "single" => &[1],
                    "double" => &[2],
                    "short" => &[3],
                    "long" => &[10, 15, 20, 25, 30],
                    "massive" => &[50, 100, 150, 200],
                    _ => &[],
                };
                if !allowed.contains(&count)
                    || es[w]["weapon"]["modes"]
                        .as_array()
                        .is_none_or(|ms| !ms.contains(&a["mode"]))
                    || es[w]["weapon"]["system"] == "none"
                {
                    return Err(err("nieprawidłowy tryb strzału"));
                }
                if es[w]["spent"] == true || (es[w]["needsCycle"] == true && !ignore_cycle) {
                    return Err(err("broń zużyta lub wymaga przeładowania mechanizmu"));
                }
                if es[w]["weapon"]["system"] == "singleUse" {
                    es[w]["spent"] = json!(true);
                } else if movie {
                    if es[w]["cinematicLoaded"] != true {
                        return Err(err("Pusta broń — przeładuj"));
                    }
                } else {
                    let m = if es[w]["installedMagazineId"].is_null() {
                        w
                    } else {
                        index(es, &es[w]["installedMagazineId"])?
                    };
                    if es[m]["magazine"].is_null() || rounds(&es[m]) < count {
                        return Err(err("Pusty magazynek lub za mało naboi — przeładuj"));
                    }
                    let mut left = count;
                    let lots = es[m]["magazine"]["rounds"].as_array_mut().unwrap();
                    for l in lots.iter_mut() {
                        let used = left.min(n(&l["count"]));
                        l["count"] = json!(n(&l["count"]) - used);
                        left -= used;
                    }
                    lots.retain(|l| n(&l["count"]) > 0);
                }
                es[w]["needsCycle"] = json!(es[w]["weapon"]["cycle"] == true && !ignore_cycle);
                if movie && ["long", "massive"].contains(&s(&a["mode"])) {
                    if es[w].get("combatState").is_none() {
                        es[w]["combatState"] =
                            json!({"jammed":false,"overheated":false,"heatPending":false});
                    }
                    es[w]["combatState"]["heatPending"] = json!(true);
                }
            }
            _ => return Err(err("nieznana operacja")),
        }
    }
    validate(&i)?;
    Ok(i)
}

// JSON has one numeric type in the webview; SQLite may retain 40.0 vs 40.
// Compare the values without weakening shape, text, IDs or quantity validation.
pub(super) fn same(a: &Value, b: &Value) -> bool {
    match (a, b) {
        (Value::Number(x), Value::Number(y)) => x.as_f64() == y.as_f64(),
        (Value::Array(x), Value::Array(y)) => {
            x.len() == y.len() && x.iter().zip(y).all(|(a, b)| same(a, b))
        }
        (Value::Object(x), Value::Object(y)) => {
            x.len() == y.len() && x.iter().all(|(k, a)| y.get(k).is_some_and(|b| same(a, b)))
        }
        _ => a == b,
    }
}

#[cfg(test)]
mod starter_tests {
    use super::*;
    fn old_pack() -> Value {
        let fixture: Value = serde_json::from_str(include_str!(
            "../../tests/fixtures/character-inventory.json"
        ))
        .unwrap();
        fixture
    }
    #[test]
    fn starter_choice_completes_legacy_grant_once_without_replacing_entries() {
        let mut before = old_pack();
        before["starterClaims"] = json!(["initial-equipment"]);
        let action = json!({"kind":"starter","key":"initial-loadout:gamble","entries":[]});
        let after = apply(&before, &action, "none", false).unwrap();
        assert_eq!(after["entries"], before["entries"]);
        assert_eq!(
            after["starterClaims"],
            json!(["initial-equipment", "initial-loadout:gamble"])
        );
        assert!(apply(&after, &action, "none", false).is_err());
        assert!(apply(
            &after,
            &json!({"kind":"starter","key":"initial-loadout:equipment","entries":[]}),
            "none",
            false
        )
        .is_err());
        assert!(apply(&empty(), &action, "none", false).is_err());
        assert!(apply(
            &before,
            &json!({"kind":"starter","key":"unknown","entries":[]}),
            "none",
            false
        )
        .is_err());
    }
}
