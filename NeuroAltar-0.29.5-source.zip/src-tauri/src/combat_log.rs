//! Entries describe committed transitions; this module has no UI or dice rules.
use super::{Actor, Combat, EnemyInstance};
use serde::Deserialize;
use serde_json::{json, Value};
use sqlx::{Row, Sqlite, Transaction};

#[derive(Clone, Copy, Debug, Default, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum SaveReason {
    #[default]
    Edit,
    Advance,
    NewDay,
    RenewEncounter,
    Prepare,
    Reset,
    ClearLog,
}

#[derive(Debug)]
pub struct Entry {
    pub round: i64,
    pub actor_id: Option<String>,
    pub kind: &'static str,
    pub message: String,
    pub payload: Value,
}
impl Entry {
    fn new(
        round: i64,
        actor: Option<&Actor>,
        kind: &'static str,
        message: String,
        before: Value,
        after: Value,
    ) -> Self {
        Self {
            round,
            actor_id: actor.map(|a| a.id.clone()),
            kind,
            message,
            payload: json!({"before":before,"after":after}),
        }
    }
}
fn core(actor: &Actor) -> Value {
    let mut copy = actor.clone();
    copy.prepared = None;
    copy.effects.sort_by(|a, b| a.id.cmp(&b.id));
    serde_json::to_value(copy).expect("validated actor is serializable")
}
fn name(combat: &Combat, id: &Option<String>) -> String {
    id.as_ref()
        .and_then(|id| combat.actors.iter().find(|a| &a.id == id))
        .map(|a| a.display_name.clone())
        .unwrap_or_else(|| "brak".into())
}
fn value_text(value: &Value) -> String {
    match value {
        Value::Null => "brak".into(),
        Value::String(text) => text.clone(),
        Value::Array(entries) => {
            if entries.is_empty() {
                "brak".into()
            } else {
                entries
                    .iter()
                    .map(value_text)
                    .collect::<Vec<_>>()
                    .join(", ")
            }
        }
        Value::Object(_) if value.get("mode").is_some() => format!(
            "{}: {} m",
            value["mode"].as_str().unwrap_or(""),
            value["meters"]
        ),
        _ => value.to_string(),
    }
}
fn cowardice(actor: &Actor) -> Option<(i64, bool)> {
    actor
        .enemy
        .as_ref()
        .and_then(|e| e.cowardice_percent)
        .map(|p| {
            let threshold = (i128::from(actor.hp_max_current) * i128::from(p) / 100) as i64;
            (threshold, actor.hp_current <= threshold)
        })
}
pub fn changes(before: &Combat, after: &Combat, reason: SaveReason) -> Vec<Entry> {
    let mut events = Vec::new();
    if matches!(reason, SaveReason::NewDay | SaveReason::RenewEncounter) {
        events.push(Entry::new(
            after.round_number,
            None,
            "resources_refreshed",
            if reason == SaveReason::NewDay {
                "MG odnowił zasoby dzienne tego slotu."
            } else {
                "MG odnowił zasoby na potyczkę tego slotu."
            }
            .into(),
            Value::Null,
            Value::Null,
        ));
    }
    if reason == SaveReason::Reset {
        events.push(Entry::new(
            before.round_number,
            None,
            "reset",
            "Reset potyczki do stanu przygotowanego.".into(),
            json!({"round":before.round_number,"activeActorId":before.current_turn_actor_id}),
            json!({"round":after.round_number,"activeActorId":after.current_turn_actor_id}),
        ));
    }
    if reason == SaveReason::Prepare {
        events.push(Entry::new(
            after.round_number,
            None,
            "prepared",
            format!(
                "Zapisano stan przygotowany: {} postaci.",
                after.actors.len()
            ),
            Value::Null,
            json!({"actorIds":after.actors.iter().map(|a| &a.id).collect::<Vec<_>>()}),
        ));
    }
    for actor in &after.actors {
        let previous = before.actors.iter().find(|a| a.id == actor.id);
        if let Some((threshold, true)) = cowardice(actor) {
            if !previous
                .and_then(cowardice)
                .is_some_and(|(_, active)| active)
            {
                events.push(Entry::new(after.round_number, Some(actor), "cowardice_warning", format!("{} — próg Tchórzliwości osiągnięty (PW ≤ {}). Wycofanie lub poddanie rozstrzyga MG.", actor.display_name, threshold), serde_json::json!(previous.map(|a| a.hp_current)), json!({"hp": actor.hp_current, "threshold": threshold})));
            }
        }
        let Some(old) = before.actors.iter().find(|old| old.id == actor.id) else {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "actor_added",
                format!(
                    "Dodano {}: {}.",
                    if actor.enemy.is_some() {
                        "przeciwnika"
                    } else {
                        "BG"
                    },
                    actor.display_name
                ),
                Value::Null,
                core(actor),
            ));
            continue;
        };
        for effect in &actor.effects {
            let previous = old.effects.iter().find(|s| s.id == effect.id);
            if previous != Some(effect) {
                events.push(Entry::new(
                    after.round_number,
                    Some(actor),
                    if previous.is_some() {
                        "status_updated"
                    } else {
                        "status_added"
                    },
                    format!(
                        "{} — {}: {}{}.",
                        actor.display_name,
                        if previous.is_some() {
                            "zmieniono status"
                        } else {
                            "dodano status"
                        },
                        effect.name,
                        effect
                            .level
                            .map(|v| format!(" (poziom {})", v))
                            .unwrap_or_default()
                    ),
                    serde_json::to_value(previous).unwrap(),
                    serde_json::to_value(effect).unwrap(),
                ));
            }
        }
        for effect in &old.effects {
            if !actor.effects.iter().any(|s| s.id == effect.id) {
                let expired = reason == SaveReason::Advance;
                events.push(Entry::new(
                    after.round_number,
                    Some(actor),
                    if expired {
                        "status_expired"
                    } else {
                        "status_removed"
                    },
                    format!(
                        "{} — {}: {}.",
                        actor.display_name,
                        if expired {
                            "wygasł status"
                        } else {
                            "usunięto status"
                        },
                        effect.name
                    ),
                    serde_json::to_value(effect).unwrap(),
                    Value::Null,
                ));
            }
        }
        let a = core(old);
        let b = core(actor);
        for (field, kind, label) in [
            ("displayName", "name_changed", "nazwa"),
            ("ttCurrent", "tt_changed", "TT"),
            ("initiativeValue", "initiative_changed", "inicjatywa"),
            ("initiativeTieOrder", "tie_changed", "pozycja w remisie"),
            ("statuses", "statuses_changed", "statusy"),
        ] {
            if a[field] != b[field] {
                events.push(Entry::new(
                    after.round_number,
                    Some(actor),
                    kind,
                    format!(
                        "{} — {}: {} → {}.",
                        actor.display_name,
                        label,
                        value_text(&a[field]),
                        value_text(&b[field])
                    ),
                    a[field].clone(),
                    b[field].clone(),
                ));
            }
        }
        if old.hp_current != actor.hp_current || old.hp_max_current != actor.hp_max_current {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "hp_changed",
                format!(
                    "{} — PW: {}/{} → {}/{}.",
                    actor.display_name,
                    old.hp_current,
                    old.hp_max_current,
                    actor.hp_current,
                    actor.hp_max_current
                ),
                json!({"current":old.hp_current,"max":old.hp_max_current}),
                json!({"current":actor.hp_current,"max":actor.hp_max_current}),
            ));
        }
        for (field, kind, label) in [
            ("/enemy/sp", "sp_changed", "SP"),
            ("/enemy/injury", "injury_changed", "Zranienia"),
            (
                "/enemy/cowardicePercent",
                "cowardice_changed",
                "Tchórzliwość (%)",
            ),
        ] {
            let x = a.pointer(field).cloned().unwrap_or(Value::Null);
            let y = b.pointer(field).cloned().unwrap_or(Value::Null);
            if x != y {
                let describe = |v: &Value| {
                    if field.ends_with("injury") {
                        if v["enabled"] == true {
                            format!(
                                "{}/4{}",
                                v["level"],
                                if v["deathWarning"] == true {
                                    " — śmierć (MG)"
                                } else {
                                    ""
                                }
                            )
                        } else {
                            "wyłączone".into()
                        }
                    } else {
                        value_text(v)
                    }
                };
                events.push(Entry::new(
                    after.round_number,
                    Some(actor),
                    kind,
                    format!(
                        "{} — {}: {} → {}.",
                        actor.display_name,
                        label,
                        describe(&x),
                        describe(&y)
                    ),
                    x,
                    y,
                ));
            }
        }
        let ca = a
            .pointer("/enemy/capabilities")
            .cloned()
            .unwrap_or(Value::Null);
        let cb = b
            .pointer("/enemy/capabilities")
            .cloned()
            .unwrap_or(Value::Null);
        let definitions = |c: &Value| json!({"abilities":c["abilities"],"legendaryMax":c["legendaryMax"],"unlimitedReactions":c["unlimitedReactions"].as_bool().unwrap_or(false),"resources":c["resources"].as_array().map(|rs|rs.iter().map(|r|json!({"id":r["id"],"name":r["name"],"maxValue":r["maxValue"],"refreshRule":r["refreshRule"]})).collect::<Vec<_>>())});
        if definitions(&ca) != definitions(&cb) {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "capabilities_changed",
                format!(
                    "{} — zmieniono konfigurację zasobów i akcji.",
                    actor.display_name
                ),
                definitions(&ca),
                definitions(&cb),
            ));
        }
        if ca["budget"] != cb["budget"] {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "budget_changed",
                format!(
                    "{} — pula akcji: A {}, B {}, R {}, L {}.",
                    actor.display_name,
                    value_text(&cb["budget"]["action"]),
                    value_text(&cb["budget"]["bonus"]),
                    value_text(&cb["budget"]["reaction"]),
                    value_text(&cb["budget"]["legendary"])
                ),
                ca["budget"].clone(),
                cb["budget"].clone(),
            ));
        }
        if let Some(rs) = cb["resources"].as_array() {
            for r in rs {
                let prev = ca["resources"]
                    .as_array()
                    .and_then(|rs| rs.iter().find(|v| v["id"] == r["id"]));
                if prev.map(|v| &v["currentValue"]) != Some(&r["currentValue"]) {
                    events.push(Entry::new(
                        after.round_number,
                        Some(actor),
                        "resource_changed",
                        format!(
                            "{} — {}: {} → {} / {}.",
                            actor.display_name,
                            value_text(&r["name"]),
                            value_text(
                                &prev
                                    .map(|v| v["currentValue"].clone())
                                    .unwrap_or(Value::Null)
                            ),
                            r["currentValue"],
                            r["maxValue"]
                        ),
                        prev.cloned().unwrap_or(Value::Null),
                        r.clone(),
                    ));
                }
            }
        }
        if reason != SaveReason::Reset
            && ca["usageNumber"] != cb["usageNumber"]
            && cb["lastUse"].is_object()
        {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "action_used",
                format!(
                    "{} — użyto: {}{}. Efekt rozstrzyga MG.",
                    actor.display_name,
                    value_text(&cb["lastUse"]["name"]),
                    if cb["lastUse"]["override"] == true {
                        " (wyjątek MG)"
                    } else {
                        ""
                    }
                ),
                ca["lastUse"].clone(),
                cb["lastUse"].clone(),
            ));
        }
        for (field, kind, label) in [
            (
                "/enemy/failureThreshold",
                "failure_threshold_changed",
                "próg awarii",
            ),
            (
                "/enemy/machineFailures",
                "machine_failures_changed",
                "awarie maszyny",
            ),
        ] {
            let old_value = a.pointer(field).cloned().unwrap_or(Value::Null);
            let new_value = b.pointer(field).cloned().unwrap_or(Value::Null);
            if old_value != new_value {
                let details = if field.ends_with("machineFailures") {
                    let describe = |v: &Value| -> String {
                        v.as_array()
                            .map(|fs| {
                                fs.iter()
                                    .map(|f| {
                                        format!(
                                            "{}{}{}{}",
                                            f["result"],
                                            f["weaponName"]
                                                .as_str()
                                                .map(|s| format!(" ({s})"))
                                                .unwrap_or_default(),
                                            f["blockedAction"]
                                                .as_str()
                                                .map(|s| format!(
                                                    " [{}]",
                                                    if s == "bonus" {
                                                        "Bonusowe"
                                                    } else {
                                                        "Legendarne"
                                                    }
                                                ))
                                                .unwrap_or_default(),
                                            f["remainingEnds"]
                                                .as_i64()
                                                .map(|n| format!(" [końce tur: {n}]"))
                                                .unwrap_or_default()
                                        )
                                    })
                                    .collect::<Vec<_>>()
                                    .join(", ")
                            })
                            .filter(|s| !s.is_empty())
                            .unwrap_or_else(|| "brak".into())
                    };
                    format!("{} → {}", describe(&old_value), describe(&new_value))
                } else {
                    format!("{} → {}", value_text(&old_value), value_text(&new_value))
                };
                events.push(Entry::new(
                    after.round_number,
                    Some(actor),
                    kind,
                    format!("{} — {}: {}.", actor.display_name, label, details),
                    old_value,
                    new_value,
                ));
            }
        }
        let statblock_before = a
            .pointer("/enemy/statblock")
            .cloned()
            .unwrap_or(Value::Null);
        let statblock_after = b
            .pointer("/enemy/statblock")
            .cloned()
            .unwrap_or(Value::Null);
        if statblock_before != statblock_after {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "statblock_changed",
                format!(
                    "{} — zmieniono statblock (cechy, obrona lub zmysły).",
                    actor.display_name
                ),
                statblock_before,
                statblock_after,
            ));
        }
        let loadout_before = a.pointer("/enemy/loadout").cloned().unwrap_or(Value::Null);
        let loadout_after = b.pointer("/enemy/loadout").cloned().unwrap_or(Value::Null);
        if loadout_before != loadout_after {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "equipment_changed",
                format!(
                    "{} — zmieniono broń, warianty lub dane ataku.",
                    actor.display_name
                ),
                loadout_before,
                loadout_after,
            ));
        }
        let speeds_before = a.pointer("/enemy/speeds").cloned().unwrap_or(Value::Null);
        let speeds_after = b.pointer("/enemy/speeds").cloned().unwrap_or(Value::Null);
        if speeds_before != speeds_after {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "movement_changed",
                format!(
                    "{} — ruch: {} → {}.",
                    actor.display_name,
                    value_text(&speeds_before),
                    value_text(&speeds_after)
                ),
                speeds_before,
                speeds_after,
            ));
        }
    }
    for actor in &before.actors {
        if !after.actors.iter().any(|a| a.id == actor.id) {
            events.push(Entry::new(
                after.round_number,
                Some(actor),
                "actor_removed",
                format!("Usunięto postać: {}.", actor.display_name),
                core(actor),
                Value::Null,
            ));
        }
    }
    if before.round_number != after.round_number {
        events.push(Entry::new(
            after.round_number,
            None,
            "round_changed",
            format!("Runda: {} → {}.", before.round_number, after.round_number),
            json!(before.round_number),
            json!(after.round_number),
        ));
    }
    if before.current_turn_actor_id != after.current_turn_actor_id
        || (before.round_number != after.round_number && after.current_turn_actor_id.is_some())
    {
        let actor = after
            .actors
            .iter()
            .find(|a| Some(&a.id) == after.current_turn_actor_id.as_ref());
        events.push(Entry::new(
            after.round_number,
            actor,
            "turn_changed",
            format!(
                "Tura: {} → {}.",
                name(before, &before.current_turn_actor_id),
                name(after, &after.current_turn_actor_id)
            ),
            json!(before.current_turn_actor_id),
            json!(after.current_turn_actor_id),
        ));
    }
    if reason == SaveReason::Advance {
        if let Some(actor) = after
            .actors
            .iter()
            .find(|a| Some(&a.id) == after.current_turn_actor_id.as_ref())
        {
            if actor
                .effects
                .iter()
                .any(|s| s.system_key.as_deref() == Some("burning"))
            {
                events.push(Entry::new(after.round_number,Some(actor),"burning_reminder",
                    format!("{} — początek tury: Podpalenie, 1k4 obrażeń od ognia do rozstrzygnięcia przez MG.",actor.display_name),Value::Null,json!({"dice":"1k4"})));
            }
        }
    }
    events
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Runtime {
    manual_statuses: Vec<String>,
    enemy: Option<EnemyInstance>,
}
pub async fn read_combat(tx: &mut Transaction<'_, Sqlite>, id: i64) -> Result<Combat, String> {
    let e = sqlx::query(
        "SELECT round_number, current_turn_actor_id, combat_revision FROM encounters WHERE id = ?",
    )
    .bind(id)
    .fetch_one(&mut **tx)
    .await
    .map_err(|e| e.to_string())?;
    let rows = sqlx::query(
        "SELECT * FROM encounter_actors WHERE encounter_id = ? ORDER BY initiative_tie_order, id",
    )
    .bind(id)
    .fetch_all(&mut **tx)
    .await
    .map_err(|e| e.to_string())?;
    let mut actors = Vec::new();
    for row in rows {
        let runtime: Runtime =
            serde_json::from_str(row.get("runtime_overrides_json")).map_err(|e| e.to_string())?;
        let active: Option<String> = row.get("reset_snapshot_json");
        let original: String = row.get("prepared_snapshot_json");
        let prepared = if let Some(active) = active {
            Some(Box::new(
                serde_json::from_str(&active).map_err(|e| e.to_string())?,
            ))
        } else {
            serde_json::from_str::<Actor>(&original).ok().map(Box::new)
        };
        let effects = super::status::read(tx, row.get("id")).await?;
        actors.push(Actor {
            effects,
            id: row.get("id"),
            display_name: row.get("display_name"),
            tt_current: row.get("tt_current"),
            hp_current: row.get("hp_current"),
            hp_max_current: row.get("hp_max_current"),
            initiative_value: row.get("initiative_value"),
            initiative_tie_order: row.get("initiative_tie_order"),
            statuses: runtime.manual_statuses,
            enemy: runtime.enemy,
            prepared,
        });
    }
    Ok(Combat {
        encounter_id: id,
        revision: e.get("combat_revision"),
        round_number: e.get("round_number"),
        current_turn_actor_id: e.get("current_turn_actor_id"),
        actors,
    })
}
pub fn same_for_clear(before: &Combat, after: &Combat) -> bool {
    before.round_number == after.round_number
        && before.current_turn_actor_id == after.current_turn_actor_id
        && before.actors.len() == after.actors.len()
        && after.actors.iter().all(|a| {
            before.actors.iter().any(|b| {
                core(a) == core(b)
                    && (a.prepared.is_none()
                        || serde_json::to_value(&a.prepared).ok()
                            == serde_json::to_value(&b.prepared).ok())
            })
        })
}
pub async fn append(
    tx: &mut Transaction<'_, Sqlite>,
    id: i64,
    entries: Vec<Entry>,
) -> Result<(), String> {
    for entry in entries {
        sqlx::query("INSERT INTO combat_log (encounter_id,round_number,actor_id,event_type,message,payload_json) VALUES (?,?,?,?,?,?)")
            .bind(id).bind(entry.round).bind(entry.actor_id).bind(entry.kind).bind(entry.message).bind(entry.payload.to_string())
            .execute(&mut **tx).await.map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::super::{EnemyTemplate, Speed};
    use super::*;
    fn state() -> Combat {
        Combat {
            encounter_id: 1,
            revision: 0,
            round_number: 1,
            current_turn_actor_id: None,
            actors: vec![Actor {
                id: "00000000-0000-4000-8000-000000000001".into(),
                display_name: "Żmija".into(),
                tt_current: 14,
                hp_current: 20,
                hp_max_current: 20,
                initiative_value: Some(12),
                initiative_tie_order: 0,
                statuses: vec![],
                effects: vec![],
                prepared: None,
                enemy: Some(EnemyInstance {
                    statblock: None,
                    machine_failures: None,
                    failure_threshold: None,
                    sp: None,
                    loadout: None,
                    capabilities: None,
                    injury: None,
                    cowardice_percent: None,
                    template: EnemyTemplate {
                        statblock: None,
                        failure_threshold: None,
                        sp: None,
                        loadout: None,
                        capabilities: None,
                        id: "00000000-0000-4000-8000-000000000099".into(),
                        name: "Żmija".into(),
                        category: "beast".into(),
                        size: "Mały".into(),
                        tt: 14,
                        hp_max: 20,
                        injury_track: None,
                        cowardice_percent: None,
                        speeds: vec![Speed {
                            mode: "Chód".into(),
                            meters: 9.0,
                        }],
                    },
                    speeds: vec![Speed {
                        mode: "Chód".into(),
                        meters: 9.0,
                    }],
                }),
            }],
        }
    }
    #[test]
    fn changed_fields_have_typed_before_after_payloads_and_polish_messages() {
        let before = state();
        let mut after = before.clone();
        after.actors[0].display_name = "Żmija przy bramie".into();
        after.actors[0].hp_current = 7;
        after.actors[0].hp_max_current = 24;
        after.actors[0].tt_current = 16;
        after.actors[0].initiative_value = None;
        after.actors[0].initiative_tie_order = 1;
        after.actors[0].statuses = vec!["Zatrucie".into(), "Przerażenie".into()];
        after.actors[0].enemy.as_mut().unwrap().speeds[0].meters = 4.5;
        let entries = changes(&before, &after, SaveReason::Edit);
        assert_eq!(entries.len(), 7);
        assert!(entries
            .iter()
            .all(|e| e.actor_id.as_ref() == Some(&after.actors[0].id)));
        let hp = entries.iter().find(|e| e.kind == "hp_changed").unwrap();
        assert_eq!(hp.message, "Żmija przy bramie — PW: 20/20 → 7/24.");
        assert_eq!(
            hp.payload,
            json!({"before":{"current":20,"max":20},"after":{"current":7,"max":24}})
        );
        assert!(entries
            .iter()
            .find(|e| e.kind == "statuses_changed")
            .unwrap()
            .message
            .contains("Zatrucie, Przerażenie"));
        assert!(entries
            .iter()
            .find(|e| e.kind == "movement_changed")
            .unwrap()
            .message
            .contains("4.5 m"));
        assert_eq!(before.actors[0].hp_current, 20);
        assert!(changes(&before, &before, SaveReason::Edit).is_empty());
    }
    #[test]
    fn a_single_actor_new_round_still_records_both_round_and_turn() {
        let mut before = state();
        before.current_turn_actor_id = Some(before.actors[0].id.clone());
        let mut after = before.clone();
        after.round_number = 2;
        let entries = changes(&before, &after, SaveReason::Edit);
        assert_eq!(
            entries.iter().map(|e| e.kind).collect::<Vec<_>>(),
            vec!["round_changed", "turn_changed"]
        );
        assert!(entries.iter().all(|e| e.round == 2));
    }
    #[test]
    fn explicit_preparation_and_reset_are_marked_even_without_stat_changes() {
        let before = state();
        assert_eq!(
            changes(&before, &before, SaveReason::Prepare)[0].kind,
            "prepared"
        );
        assert_eq!(
            changes(&before, &before, SaveReason::Reset)[0].kind,
            "reset"
        );
    }
    #[test]
    fn removal_keeps_original_identity_and_name_in_history() {
        let before = state();
        let mut after = before.clone();
        after.actors.clear();
        let entries = changes(&before, &after, SaveReason::Edit);
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0].kind, "actor_removed");
        assert_eq!(entries[0].actor_id.as_ref(), Some(&before.actors[0].id));
        assert_eq!(entries[0].payload["before"]["displayName"], "Żmija");
    }
}
