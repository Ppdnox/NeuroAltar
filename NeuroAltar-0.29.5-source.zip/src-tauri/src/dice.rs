use serde::{Deserialize, Serialize};
use serde_json::json;
use sqlx::{Row, SqlitePool};
use tauri_plugin_sql::DbInstances;
#[path = "dice_supplements.rs"]
mod supplements;
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct CharacterCheck {
    character_id: String,
    targets: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    expected_revision: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    consumed_benefits: Option<Vec<String>>,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Supplement {
    original_roll_id: String,
    character_id: String,
    expected_revision: i64,
    resource_id: String,
    original_total: i64,
    original_natural: i64,
    original_label: String,
    failed: bool,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Context {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    reroll_of: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    effect_owner_actor_id: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    consumed_effects: Option<Vec<String>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    participation_revision: Option<i64>,
    encounter_id: i64,
    actor_id: String,
    actor_name: String,
    round_number: i64,
    label: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    purpose: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    source_key: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    critical_multiplier: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    critical_at: Option<i64>,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Group {
    count: i64,
    sides: i64,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Critical {
    attack_roll_id: String,
    original_formula: String,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct CharacterContext {
    character_id: String,
    name: String,
    label: String,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Roll {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    character_check: Option<CharacterCheck>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    supplement: Option<Supplement>,
    id: String,
    created_at: String,
    formula: String,
    count: i64,
    sides: i64,
    modifier: i64,
    values: Vec<i64>,
    total: i64,
    context: Option<Context>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    character_context: Option<CharacterContext>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    groups: Option<Vec<Group>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    critical: Option<Critical>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    check_dice: Option<CheckDice>,
}
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CheckDice {
    mode: String,
    values: [i64; 2],
}
fn validate(r: &Roll) -> Result<(), String> {
    supplements::validate(r)?;
    if let Some(c) = &r.check_dice {
        let kept = if c.mode == "advantage" {
            *c.values.iter().max().unwrap()
        } else {
            *c.values.iter().min().unwrap()
        };
        if !["advantage", "disadvantage"].contains(&c.mode.as_str())
            || c.values.iter().any(|v| !(1..=20).contains(v))
            || r.count != 1
            || r.sides != 20
            || r.values != vec![kept]
        {
            return Err("Niespójny rzut z Ułatwieniem/Utrudnieniem.".into());
        }
    }
    if r.context
        .as_ref()
        .and_then(|c| c.critical_at)
        .is_some_and(|v| v != 19 && v != 20)
    {
        return Err("Nieprawidłowy próg krytyka.".into());
    }
    if let Some(c) = &r.character_context {
        if r.context.is_some()
            || uuid::Uuid::parse_str(&c.character_id).is_err()
            || c.name.trim().is_empty()
            || c.name.chars().count() > 300
            || c.label.trim().is_empty()
            || c.label.chars().count() > 500
        {
            return Err("Niepoprawny kontekst rzutu BG.".into());
        }
    }
    let default_groups = vec![Group {
        count: r.count,
        sides: r.sides,
    }];
    let groups = r.groups.as_ref().unwrap_or(&default_groups);
    if groups.is_empty()
        || groups.len() > 100
        || (r.groups.is_some() && groups.len() < 2)
        || groups.iter().any(|g| {
            !(1..=100).contains(&g.count) || ![4, 6, 8, 10, 12, 20, 100].contains(&g.sides)
        })
    {
        return Err("Nieprawidłowe grupy kości.".into());
    }
    let count: i64 = groups.iter().map(|g| g.count).sum();
    if count != r.count || count > 100 || groups[0].sides != r.sides {
        return Err("Niespójne grupy kości.".into());
    }
    let bounds: Vec<i64> = groups
        .iter()
        .flat_map(|g| std::iter::repeat_n(g.sides, g.count as usize))
        .collect();
    let formula = groups
        .iter()
        .map(|g| format!("{}k{}", g.count, g.sides))
        .collect::<Vec<_>>()
        .join("+")
        + &if r.modifier == 0 {
            String::new()
        } else {
            format!("{:+}", r.modifier)
        };
    if uuid::Uuid::parse_str(&r.id).is_err()
        || r.created_at.len() != 24
        || !r.created_at.ends_with('Z')
        || r.formula != formula
        || !(1..=100).contains(&r.count)
        || ![4, 6, 8, 10, 12, 20, 100].contains(&r.sides)
        || !(-10000..=10000).contains(&r.modifier)
        || r.values.len() != r.count as usize
        || r.values.iter().zip(bounds).any(|(v, b)| *v < 1 || *v > b)
    {
        return Err("Nieprawidłowe dane rzutu.".into());
    }
    if r.total != r.values.iter().sum::<i64>() + r.modifier {
        return Err("Niespójna suma rzutu.".into());
    }
    let multiplier = r
        .context
        .as_ref()
        .and_then(|c| c.critical_multiplier)
        .unwrap_or(2);
    if multiplier != 2 && multiplier != 3 {
        return Err("Nieprawidłowy mnożnik krytyka.".into());
    }
    if let Some(critical) = &r.critical {
        let original = groups
            .iter()
            .map(|g| format!("{}k{}", g.count / multiplier, g.sides))
            .collect::<Vec<_>>()
            .join("+")
            + &if r.modifier == 0 {
                String::new()
            } else {
                format!("{:+}", r.modifier)
            };
        if groups.iter().any(|g| g.count % multiplier != 0) || original != critical.original_formula
        {
            return Err("Krytyk mnoży wyłącznie kości zgodnie ze zdolnością.".into());
        }
        if uuid::Uuid::parse_str(&critical.attack_roll_id).is_err()
            || critical.original_formula.len() > 64
            || r.context.as_ref().and_then(|c| c.purpose.as_deref()) != Some("damage")
        {
            return Err("Nieprawidłowe dane krytyka.".into());
        }
    }
    if let Some(c) = &r.context {
        if c.purpose.is_some() != c.source_key.is_some()
            || c.purpose
                .as_deref()
                .is_some_and(|p| p != "attack" && p != "damage" && p != "initiative")
            || c.source_key
                .as_ref()
                .is_some_and(|k| k.trim().is_empty() || k.chars().count() > 500)
            || !(1..=5).contains(&c.encounter_id)
            || c.round_number < 1
            || uuid::Uuid::parse_str(&c.actor_id).is_err()
            || c.actor_name.trim().is_empty()
            || c.actor_name.chars().count() > 200
            || c.label.trim().is_empty()
            || c.label.chars().count() > 500
        {
            return Err("Nieprawidłowy opis rzutu.".into());
        }
    }
    Ok(())
}
pub async fn save_to_pool(pool: &SqlitePool, roll: Roll) -> Result<(), String> {
    save_with_initiative(pool, roll, None).await
}
async fn save_with_initiative(
    pool: &SqlitePool,
    roll: Roll,
    revision: Option<i64>,
) -> Result<(), String> {
    validate(&roll)?;
    let initiative = roll
        .context
        .as_ref()
        .is_some_and(|c| c.purpose.as_deref() == Some("initiative"));
    if initiative != revision.is_some()
        || revision.is_some_and(|r| !(0..9007199254740991).contains(&r))
    {
        return Err("Nieprawidłowa rewizja rzutu inicjatywy.".into());
    }
    if initiative
        && (roll.count != 1
            || roll.sides != 20
            || roll.context.as_ref().unwrap().source_key.as_deref() != Some("initiative"))
    {
        return Err("Inicjatywa wymaga pojedynczego k20.".into());
    }
    let payload = serde_json::to_string(&roll).map_err(|e| e.to_string())?;
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    // INSERT acquires the write lock. The stable UUID makes uncertain retries safe.
    let added = sqlx::query(
        "INSERT INTO dice_rolls(id,payload_json) VALUES(?,?) ON CONFLICT(id) DO NOTHING",
    )
    .bind(&roll.id)
    .bind(&payload)
    .execute(&mut *tx)
    .await
    .map_err(|e| e.to_string())?
    .rows_affected();
    if added == 0 {
        let old: String = sqlx::query("SELECT payload_json FROM dice_rolls WHERE id=?")
            .bind(&roll.id)
            .fetch_one(&mut *tx)
            .await
            .map_err(|e| e.to_string())?
            .get(0);
        if old != payload {
            return Err("ID rzutu jest już używane przez inny wynik.".into());
        }
    } else {
        supplements::apply(&mut tx, &roll).await?;
        if let Some(c) = &roll.context {
            if let Some(original_id) = &c.reroll_of {
                let raw: Option<String> =
                    sqlx::query_scalar("SELECT payload_json FROM dice_rolls WHERE id=?")
                        .bind(original_id)
                        .fetch_optional(&mut *tx)
                        .await
                        .map_err(|e| e.to_string())?;
                let original: Roll =
                    serde_json::from_str(&raw.ok_or("Nie znaleziono pierwotnego testu.")?)
                        .map_err(|e| e.to_string())?;
                let old = original
                    .context
                    .as_ref()
                    .ok_or("Przerzut wymaga testu z potyczki.")?;
                let current: i64 =
                    sqlx::query_scalar("SELECT round_number FROM encounters WHERE id=?")
                        .bind(c.encounter_id)
                        .fetch_one(&mut *tx)
                        .await
                        .map_err(|e| e.to_string())?;
                if old.actor_id != c.actor_id
                    || old.encounter_id != c.encounter_id
                    || old.round_number != current
                    || c.round_number != current
                    || original.count != 1
                    || original.sides != 20
                    || roll.formula != original.formula
                    || old.purpose != c.purpose
                    || old.source_key != c.source_key
                    || old.reroll_of.is_some()
                {
                    return Err(
                        "Szczęście: wybierz pierwotny test tej postaci z bieżącej rundy.".into(),
                    );
                }
                let previous_mode = original.check_dice.as_ref().map(|v| &v.mode);
                let heckle = c.effect_owner_actor_id.is_some();
                if !heckle && previous_mode != roll.check_dice.as_ref().map(|v| &v.mode) {
                    return Err("Przerzut zachowuje Ułatwienie lub Utrudnienie testu.".into());
                }
                if heckle
                    && ((old.purpose.as_deref() != Some("attack") && !old.label.starts_with("RO "))
                        || roll.total > original.total
                        || roll.check_dice.as_ref().is_none_or(|v| {
                            v.mode != "disadvantage" || !v.values.contains(&original.values[0])
                        }))
                {
                    return Err(
                        "Spieprzysz to: zachowaj gorszy z pierwotnego i nowego wyniku.".into(),
                    );
                }
                let already:i64=sqlx::query_scalar("SELECT COUNT(*) FROM dice_rolls WHERE json_extract(payload_json,'$.context.rerollOf')=?").bind(original_id).fetch_one(&mut *tx).await.map_err(|e|e.to_string())?;
                if already > 0 {
                    return Err("Ten test został już przerzucony.".into());
                }
                if c.consumed_effects.as_ref().is_none_or(|v| v.len() != 1) {
                    return Err("Szczęście wymaga jednego przygotowanego użycia.".into());
                }
            }
            if let Some(ids) = &c.consumed_effects {
                if ids.is_empty() || ids.len() > 100 {
                    return Err("Niepoprawna lista efektów rzutu.".into());
                }
                let raw:Option<String>=sqlx::query_scalar("SELECT payload_json FROM character_participations WHERE actor_id=? AND encounter_id=? AND state='active'").bind(c.effect_owner_actor_id.as_ref().unwrap_or(&c.actor_id)).bind(c.encounter_id).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
                let mut p: serde_json::Value =
                    serde_json::from_str(&raw.ok_or("Brak aktywnego udziału BG.")?)
                        .map_err(|e| e.to_string())?;
                if p["revision"].as_i64() != c.participation_revision {
                    return Err("Efekty postaci zmieniły się przed zapisaniem rzutu.".into());
                }
                let effects = p["effects"]
                    .as_array_mut()
                    .ok_or("Niepoprawne efekty BG.")?;
                if ids.iter().any(|id| {
                    !effects.iter().any(|e| {
                        e["id"] == *id
                            && e["nextRoll"] == true
                            && (if c.effect_owner_actor_id.is_some() {
                                e["recipientActorId"] == c.actor_id
                            } else {
                                e["recipientActorId"].is_null()
                            })
                    })
                }) {
                    return Err("Efekt został już rozliczony.".into());
                }
                let luck = effects.iter().any(|e| {
                    ids.iter().any(|id| e["id"] == *id) && e["sourceRuleId"] == "resource:luck"
                });
                let heckle = effects.iter().any(|e| {
                    ids.iter().any(|id| e["id"] == *id) && e["sourceRuleId"] == "resource:heckle"
                });
                if (luck || heckle) != c.reroll_of.is_some()
                    || (heckle && c.effect_owner_actor_id.is_none())
                {
                    return Err("Szczęście można zużyć wyłącznie na wskazany przerzut.".into());
                }
                effects.retain(|e| !ids.iter().any(|id| e["id"] == *id));
                p["revision"] = json!(p["revision"].as_i64().unwrap() + 1);
                sqlx::query(
                    "UPDATE character_participations SET revision=?,payload_json=? WHERE id=?",
                )
                .bind(p["revision"].as_i64())
                .bind(p.to_string())
                .bind(p["id"].as_str())
                .execute(&mut *tx)
                .await
                .map_err(|e| e.to_string())?;
            }
            if c.critical_at == Some(19) {
                let allowed:i64=sqlx::query_scalar("SELECT COUNT(*) FROM character_participations p JOIN characters ch ON ch.id=p.character_id WHERE p.actor_id=? AND p.encounter_id=? AND json_extract(ch.payload_json,'$.sheet.rulesContext.gameColor')='steel'").bind(&c.actor_id).bind(c.encounter_id).fetch_one(&mut *tx).await.map_err(|e|e.to_string())?;
                if allowed != 1 {
                    return Err("Krytyk przy 19 jest dostępny dla BG w Stali.".into());
                }
            }
            if c.purpose.as_deref() == Some("attack")
                && roll.values == [1]
                && c.source_key
                    .as_deref()
                    .is_some_and(|k| k.starts_with("weapon:"))
            {
                let raw:Option<String>=sqlx::query_scalar("SELECT ch.payload_json FROM character_participations p JOIN characters ch ON ch.id=p.character_id WHERE p.actor_id=? AND p.encounter_id=?").bind(&c.actor_id).bind(c.encounter_id).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
                if let Some(raw) = raw {
                    let mut character: serde_json::Value =
                        serde_json::from_str(&raw).map_err(|e| e.to_string())?;
                    let movie = character["inventory"]["ammoMode"] == "cinematic"
                        || (character["inventory"]["ammoMode"] == "auto"
                            && character["sheet"]["rulesContext"]["gameColor"] == "chrome");
                    if movie {
                        let weapon_id = c.source_key.as_ref().unwrap().split(':').nth(1).unwrap();
                        if let Some(entry) = character["inventory"]["entries"]
                            .as_array_mut()
                            .and_then(|es| {
                                es.iter_mut().find(|e| {
                                    e["id"] == weapon_id
                                        && e["weapon"]["system"] != "none"
                                        && !e["weapon"].is_null()
                                })
                            })
                        {
                            entry["cinematicLoaded"] = json!(false);
                            character["revision"] =
                                json!(character["revision"].as_i64().unwrap() + 1);
                            sqlx::query("UPDATE characters SET revision=?,payload_json=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?").bind(character["revision"].as_i64()).bind(character.to_string()).bind(character["id"].as_str()).execute(&mut *tx).await.map_err(|e|e.to_string())?;
                            sqlx::query("INSERT INTO character_operations(operation_id,character_id,kind,request_json,result_json) VALUES(?,?,'inventory',?,?)").bind(&roll.id).bind(character["id"].as_str()).bind(json!({"event":"emptyOnNaturalOne","rollId":roll.id}).to_string()).bind(character.to_string()).execute(&mut *tx).await.map_err(|e|e.to_string())?;
                        }
                    }
                }
            }
            if let Some(revision) = revision {
                let changed = sqlx::query("UPDATE encounters SET combat_revision=combat_revision+1 WHERE id=? AND combat_revision=? AND round_number=?")
                .bind(c.encounter_id).bind(revision).bind(c.round_number).execute(&mut *tx).await.map_err(|e|e.to_string())?.rows_affected();
                if changed != 1 {
                    return Err(
                    "Potyczka zmieniła się przed zapisem inicjatywy. Odczytaj jej aktualny stan."
                        .into(),
                );
                }
                let changed = sqlx::query("UPDATE encounter_actors SET initiative_value=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=? AND encounter_id=? AND (kind='enemy' OR id IN (SELECT actor_id FROM character_participations))")
                .bind(roll.total).bind(&c.actor_id).bind(c.encounter_id).execute(&mut *tx).await.map_err(|e|e.to_string())?.rows_affected();
                if changed != 1 {
                    return Err("Nie znaleziono przeciwnika w tej potyczce.".into());
                }
            }
            if c.purpose.as_deref() == Some("damage") {
                let previous:Option<String>=sqlx::query_scalar("SELECT payload_json FROM dice_rolls WHERE id<>? AND json_extract(payload_json,'$.context.encounterId')=? AND json_extract(payload_json,'$.context.actorId')=? AND json_extract(payload_json,'$.context.sourceKey')=? AND json_extract(payload_json,'$.context.purpose') IN ('attack','damage') ORDER BY sequence DESC LIMIT 1")
          .bind(&roll.id).bind(c.encounter_id).bind(&c.actor_id).bind(&c.source_key).fetch_optional(&mut *tx).await.map_err(|e|e.to_string())?;
                let previous: Option<Roll> = previous
                    .map(|p| serde_json::from_str(&p))
                    .transpose()
                    .map_err(|e| e.to_string())?;
                let expected = previous
                    .as_ref()
                    .filter(|p| {
                        p.context.as_ref().and_then(|c| c.purpose.as_deref()) == Some("attack")
                            && p.count == 1
                            && p.sides == 20
                            && p.values[0]
                                >= p.context.as_ref().and_then(|c| c.critical_at).unwrap_or(20)
                    })
                    .map(|p| p.id.as_str());
                if roll.critical.as_ref().map(|c| c.attack_roll_id.as_str()) != expected {
                    return Err("Stan krytyka zmienił się przed zapisem.".into());
                }
            }

            let values = roll
                .values
                .iter()
                .map(ToString::to_string)
                .collect::<Vec<_>>()
                .join(", ");
            let message = format!(
                "{} — {}: {} → [{}] {:+} = {}.",
                c.actor_name, c.label, roll.formula, values, roll.modifier, roll.total
            );
            sqlx::query("INSERT INTO combat_log(encounter_id,round_number,actor_id,event_type,message,payload_json,created_at) VALUES(?,?,?,'dice_rolled',?,?,?)")
            .bind(c.encounter_id).bind(c.round_number).bind(&c.actor_id).bind(message).bind(json!({"before":null,"after":roll}).to_string()).bind(&roll.created_at)
            .execute(&mut *tx).await.map_err(|e|e.to_string())?;
        }
    }
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(())
}
#[tauri::command]
pub async fn save_dice_roll(
    databases: tauri::State<'_, DbInstances>,
    roll: Roll,
) -> Result<(), String> {
    let pool = {
        let instances = databases.0.read().await;
        let Some(tauri_plugin_sql::DbPool::Sqlite(pool)) =
            instances.get("sqlite:combat-tracker.db")
        else {
            return Err("Baza nie jest jeszcze otwarta.".into());
        };
        pool.clone()
    };
    save_to_pool(&pool, roll).await
}
#[tauri::command]
pub async fn save_initiative_roll(
    databases: tauri::State<'_, DbInstances>,
    roll: Roll,
    revision: i64,
) -> Result<(), String> {
    let pool = {
        let instances = databases.0.read().await;
        let Some(tauri_plugin_sql::DbPool::Sqlite(pool)) =
            instances.get("sqlite:combat-tracker.db")
        else {
            return Err("Baza nie jest jeszcze otwarta.".into());
        };
        pool.clone()
    };
    save_with_initiative(&pool, roll, Some(revision)).await
}
#[cfg(test)]
mod tests {
    use super::*;
    fn roll() -> Roll {
        serde_json::from_value(json!({"id":"987c6081-0d1a-48e4-a1e0-4d16407be701","createdAt":"2026-09-12T00:00:00.000Z","formula":"3k8+2","count":3,"sides":8,"modifier":2,"values":[1,4,8],"total":15,"context":{"encounterId":1,"actorId":"987c6081-0d1a-48e4-a1e0-4d16407be702","actorName":"Gangus Ż","roundNumber":2,"label":"Obrażenia — nóż"}})).unwrap()
    }
    async fn initiative_fixture() -> (SqlitePool, Roll, i64) {
        let pool = super::super::tests::database().await;
        sqlx::raw_sql(include_str!("../migrations/010_dice_history.sql"))
            .execute(&pool)
            .await
            .unwrap();
        let state = super::super::tests::enemy_state();
        let mut r = roll();
        r.count = 1;
        r.sides = 20;
        r.modifier = 5;
        r.values = vec![20];
        r.total = 25;
        r.formula = "1k20+5".into();
        let c = r.context.as_mut().unwrap();
        c.actor_id = state.actors[1].id.clone();
        c.encounter_id = state.encounter_id;
        c.round_number = state.round_number;
        c.purpose = Some("initiative".into());
        c.source_key = Some("initiative".into());
        c.label = "Inicjatywa".into();
        let revision = super::super::save_to_pool(&pool, state).await.unwrap();
        (pool, r, revision)
    }
    #[test]
    fn initiative_is_atomic_scoped_and_retry_never_overwrites_a_later_manual_value() {
        tauri::async_runtime::block_on(async {
            let (pool, r, revision) = initiative_fixture().await;
            let id = &r.context.as_ref().unwrap().actor_id;
            let before: String = sqlx::query_scalar(
                "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?",
            )
            .bind(id)
            .fetch_one(&pool)
            .await
            .unwrap();
            let turn: Option<String> =
                sqlx::query_scalar("SELECT current_turn_actor_id FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let prepared: String = sqlx::query_scalar(
                "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?",
            )
            .bind(id)
            .fetch_one(&pool)
            .await
            .unwrap();
            assert!(save_to_pool(&pool, r.clone()).await.is_err());
            save_with_initiative(&pool, r.clone(), Some(revision))
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT initiative_value FROM encounter_actors WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                25
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                revision + 1
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                prepared
            );
            assert_eq!(
                sqlx::query_scalar::<_, Option<String>>(
                    "SELECT current_turn_actor_id FROM encounters WHERE id=1"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                turn
            );
            assert_eq!(sqlx::query_scalar::<_,i64>("SELECT initiative_value FROM encounter_actors WHERE id='00000000-0000-4000-8000-000000000003'").fetch_one(&pool).await.unwrap(),3);
            sqlx::query("UPDATE encounter_actors SET initiative_value=7 WHERE id=?")
                .bind(id)
                .execute(&pool)
                .await
                .unwrap();
            save_with_initiative(&pool, r.clone(), Some(revision))
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT initiative_value FROM encounter_actors WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                7
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM dice_rolls")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='dice_rolled'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    #[test]
    fn initiative_rejects_conflicts_wrong_actor_and_rolls_back_log_failure() {
        tauri::async_runtime::block_on(async {
            let (pool, r, revision) = initiative_fixture().await;
            assert!(save_with_initiative(&pool, r.clone(), Some(revision - 1))
                .await
                .is_err());
            for (actor, slot, round) in [
                (
                    "00000000-0000-4000-8000-000000000001",
                    1,
                    r.context.as_ref().unwrap().round_number,
                ),
                (r.context.as_ref().unwrap().actor_id.as_str(), 2, 1),
                (r.context.as_ref().unwrap().actor_id.as_str(), 1, 99),
            ] {
                let mut bad = r.clone();
                let c = bad.context.as_mut().unwrap();
                c.actor_id = actor.into();
                c.encounter_id = slot;
                c.round_number = round;
                assert!(save_with_initiative(&pool, bad, Some(revision))
                    .await
                    .is_err());
            }
            let mut bad = r.clone();
            bad.count = 2;
            bad.values = vec![10, 10];
            bad.formula = "2k20+5".into();
            assert!(save_with_initiative(&pool, bad, Some(revision))
                .await
                .is_err());
            sqlx::raw_sql("CREATE TRIGGER fail_roll_log BEFORE INSERT ON combat_log BEGIN SELECT RAISE(ABORT,'test'); END;").execute(&pool).await.unwrap();
            assert!(save_with_initiative(&pool, r.clone(), Some(revision))
                .await
                .is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM dice_rolls")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                revision
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT initiative_value FROM encounter_actors WHERE id=?"
                )
                .bind(&r.context.as_ref().unwrap().actor_id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                2
            );
            sqlx::raw_sql("DROP TRIGGER fail_roll_log")
                .execute(&pool)
                .await
                .unwrap();
            save_with_initiative(&pool, r, Some(revision))
                .await
                .unwrap();
            pool.close().await;
        });
    }
    #[test]
    fn character_roll_metadata_roundtrips_without_combat_context() {
        let mut r = roll();
        r.context = None;
        r.character_context = Some(CharacterContext {
            character_id: "987c6081-0d1a-48e4-a1e0-4d16407be702".into(),
            name: "Anna".into(),
            label: "Test Siła".into(),
        });
        assert!(validate(&r).is_ok());
        let decoded: Roll = serde_json::from_str(&serde_json::to_string(&r).unwrap()).unwrap();
        assert_eq!(decoded.character_context.unwrap().name, "Anna");
        r.context = roll().context;
        assert!(validate(&r).is_err());
    }
    #[test]
    fn thinboy_critical_triples_dice_only() {
        let mut r = roll();
        let c = r.context.as_mut().unwrap();
        c.purpose = Some("damage".into());
        c.source_key = Some("blades".into());
        c.critical_multiplier = Some(3);
        r.formula = "3k4+4".into();
        r.count = 3;
        r.sides = 4;
        r.modifier = 4;
        r.values = vec![1, 2, 3];
        r.total = 10;
        r.critical = Some(Critical {
            attack_roll_id: "a426983d-36cc-4e4c-8a6a-000000000009".to_string(),
            original_formula: "1k4+4".into(),
        });
        assert!(validate(&r).is_ok());
        r.context.as_mut().unwrap().critical_multiplier = None;
        assert!(validate(&r).is_err());
    }
    #[test]
    fn critical_damage_is_scoped_consumed_once_and_retry_safe() {
        tauri::async_runtime::block_on(async {
            let pool = super::super::tests::database().await;
            sqlx::raw_sql(include_str!("../migrations/010_dice_history.sql"))
                .execute(&pool)
                .await
                .unwrap();
            let mut attack = roll();
            attack.formula = "1k20+9".into();
            attack.count = 1;
            attack.sides = 20;
            attack.modifier = 9;
            attack.values = vec![20];
            attack.total = 29;
            let c = attack.context.as_mut().unwrap();
            c.purpose = Some("attack".into());
            c.source_key = Some("knife".into());
            save_to_pool(&pool, attack.clone()).await.unwrap();
            let mut damage = attack.clone();
            damage.id = "a426983d-36cc-4e4c-8a6a-000000000001".into();
            damage.context.as_mut().unwrap().purpose = Some("damage".into());
            damage.formula = "2k6+5".into();
            damage.count = 2;
            damage.sides = 6;
            damage.modifier = 5;
            damage.values = vec![3, 4];
            damage.total = 12;
            damage.critical = Some(Critical {
                attack_roll_id: attack.id.clone(),
                original_formula: "1k6+5".into(),
            });
            let mut missing = damage.clone();
            missing.critical = None;
            assert!(save_to_pool(&pool, missing).await.is_err());
            let mut other = damage.clone();
            other.context.as_mut().unwrap().source_key = Some("other".into());
            assert!(save_to_pool(&pool, other).await.is_err());
            save_to_pool(&pool, damage.clone()).await.unwrap();
            save_to_pool(&pool, damage.clone()).await.unwrap();
            let mut duplicate = damage.clone();
            duplicate.id = "a426983d-36cc-4e4c-8a6a-000000000002".into();
            assert!(save_to_pool(&pool, duplicate).await.is_err());
            let mut normal = damage.clone();
            normal.id = "a426983d-36cc-4e4c-8a6a-000000000003".into();
            normal.critical = None;
            normal.formula = "1k6+5".into();
            normal.count = 1;
            normal.values = vec![3];
            normal.total = 8;
            save_to_pool(&pool, normal).await.unwrap();
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM dice_rolls")
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(count, 3);
            let mut invalid = damage;
            invalid.critical.as_mut().unwrap().original_formula = "1k6+10".into();
            assert!(validate(&invalid).is_err());
        });
    }
    #[test]
    fn mixed_dice_validate_each_face_and_roundtrip_without_changing_legacy_payloads() {
        let mut r = roll();
        assert!(serde_json::to_value(&r).unwrap().get("groups").is_none());
        r.groups = Some(vec![
            Group { count: 2, sides: 8 },
            Group { count: 2, sides: 6 },
        ]);
        r.formula = "2k8+2k6+4".into();
        r.count = 4;
        r.sides = 8;
        r.modifier = 4;
        r.values = vec![8, 8, 6, 6];
        r.total = 32;
        assert!(validate(&r).is_ok());
        let encoded = serde_json::to_string(&r).unwrap();
        assert!(validate(&serde_json::from_str(&encoded).unwrap()).is_ok());
        r.values = vec![8, 8, 8, 4];
        assert!(validate(&r).is_err());
        r.values = vec![8, 8, 6, 6];
        r.groups = None;
        assert!(validate(&r).is_err());
    }
    #[test]
    fn validates_bounds_totals_and_context() {
        let r = roll();
        assert!(validate(&r).is_ok());
        for invalid in [
            Roll {
                total: 16,
                ..r.clone()
            },
            Roll {
                count: 101,
                ..r.clone()
            },
            Roll {
                sides: 7,
                ..r.clone()
            },
            Roll {
                values: vec![0, 4, 8],
                ..r.clone()
            },
            Roll {
                formula: "eval()".into(),
                ..r.clone()
            },
        ] {
            assert!(validate(&invalid).is_err());
        }
        let mut r = roll();
        r.context.as_mut().unwrap().encounter_id = 6;
        assert!(validate(&r).is_err());
    }
    #[test]
    fn history_and_log_are_atomic_idempotent_and_leave_combat_unchanged() {
        tauri::async_runtime::block_on(async {
            let pool = super::super::tests::database().await;
            sqlx::raw_sql(include_str!("../migrations/010_dice_history.sql"))
                .execute(&pool)
                .await
                .unwrap();
            let before: String = sqlx::query("SELECT json_group_array(json_object('id',id,'rev',combat_revision,'notes',notes,'round',round_number)) FROM encounters").fetch_one(&pool).await.unwrap().get(0);
            let r = roll();
            save_to_pool(&pool, r.clone()).await.unwrap();
            save_to_pool(&pool, r.clone()).await.unwrap();
            let count: i64 =
                sqlx::query("SELECT count(*) FROM combat_log WHERE event_type='dice_rolled'")
                    .fetch_one(&pool)
                    .await
                    .unwrap()
                    .get(0);
            assert_eq!(count, 1);
            assert!(save_to_pool(
                &pool,
                Roll {
                    values: vec![2, 4, 8],
                    total: 16,
                    ..r.clone()
                }
            )
            .await
            .is_err());
            let after:String=sqlx::query("SELECT json_group_array(json_object('id',id,'rev',combat_revision,'notes',notes,'round',round_number)) FROM encounters").fetch_one(&pool).await.unwrap().get(0);
            assert_eq!(before, after);
            sqlx::query("CREATE TRIGGER fail_dice_log BEFORE INSERT ON combat_log BEGIN SELECT RAISE(ABORT,'test'); END").execute(&pool).await.unwrap();
            let next = Roll {
                id: "987c6081-0d1a-48e4-a1e0-4d16407be703".into(),
                ..r
            };
            assert!(save_to_pool(&pool, next.clone()).await.is_err());
            let count: i64 = sqlx::query("SELECT count(*) FROM dice_rolls")
                .fetch_one(&pool)
                .await
                .unwrap()
                .get(0);
            assert_eq!(count, 1);
            sqlx::query("DROP TRIGGER fail_dice_log")
                .execute(&pool)
                .await
                .unwrap();
            save_to_pool(&pool, next).await.unwrap();
            // Generic rolls belong only to history. Clearing a combat log never recreates it on retry.
            let generic = Roll {
                id: "987c6081-0d1a-48e4-a1e0-4d16407be704".into(),
                context: None,
                ..roll()
            };
            save_to_pool(&pool, generic).await.unwrap();
            sqlx::query("DELETE FROM combat_log WHERE encounter_id=1")
                .execute(&pool)
                .await
                .unwrap();
            save_to_pool(&pool, roll()).await.unwrap();
            let count: i64 = sqlx::query("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap()
                .get(0);
            assert_eq!(count, 0);
        });
    }
}
