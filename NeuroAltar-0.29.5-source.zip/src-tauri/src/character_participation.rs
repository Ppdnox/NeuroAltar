use super::*;
use serde_json::json;
use sqlx::{Sqlite, Transaction};
type Tx<'a> = Transaction<'a, Sqlite>;
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Request {
    operation_id: String,
    actor_id: String,
    encounter_id: i64,
    encounter_revision: i64,
    expected_revision: Option<i64>,
    character_id: String,
    character_revision: i64,
    action: Value,
}
async fn rows(tx: &mut Tx<'_>, slot: i64) -> Result<Vec<Value>, String> {
    let data: Vec<String> = sqlx::query_scalar(
        "SELECT payload_json FROM character_participations WHERE encounter_id=?",
    )
    .bind(slot)
    .fetch_all(&mut **tx)
    .await
    .map_err(|e| e.to_string())?;
    data.into_iter()
        .map(|s| serde_json::from_str(&s).map_err(|e| e.to_string()))
        .collect()
}
async fn put(tx: &mut Tx<'_>, p: &Value) -> Result<(), String> {
    sqlx::query("UPDATE character_participations SET revision=?,state=?,payload_json=? WHERE id=?")
        .bind(p["revision"].as_i64())
        .bind(p["state"].as_str())
        .bind(p.to_string())
        .bind(p["id"].as_str())
        .execute(&mut **tx)
        .await
        .map_err(|e| e.to_string())?;
    Ok(())
}
async fn log(tx: &mut Tx<'_>, p: &Value, message: &str, payload: &Value) -> Result<(), String> {
    sqlx::query("INSERT INTO combat_log(encounter_id,round_number,actor_id,event_type,message,payload_json) SELECT id,round_number,?,'character',?,? FROM encounters WHERE id=?")
        .bind(p["actorId"].as_str()).bind(message).bind(json!({"before":null,"after":payload}).to_string()).bind(p["encounterId"].as_i64())
        .execute(&mut **tx).await.map_err(|e|e.to_string())?;
    Ok(())
}
fn validate_effect(e: &Value) -> Result<(), String> {
    let mut base = e.clone();
    base.as_object_mut().ok_or_else(fail)?.remove("nextRoll");
    base.as_object_mut().unwrap().remove("damageDice");
    base.as_object_mut().unwrap().remove("condition");
    base.as_object_mut().unwrap().remove("speedReduction");
    if !e["condition"].is_null() {
        choice(&e["condition"], &["bleeding", "blinded"])?;
    }
    if !e["speedReduction"].is_null()
        && !e["speedReduction"]
            .as_f64()
            .is_some_and(|v| v.is_finite() && (0.0..=100.0).contains(&v))
    {
        return Err(fail());
    }
    base.as_object_mut().unwrap().remove("checkDice");
    base.as_object_mut().unwrap().remove("recipientActorId");
    if !e["recipientActorId"].is_null() {
        uuid::Uuid::parse_str(string(&e["recipientActorId"], 40)?).map_err(|_| fail())?;
    }
    if !e["checkDice"].is_null()
        && !["1k4", "1k6", "1k8", "1k10", "1k12"].contains(&e["checkDice"].as_str().unwrap_or(""))
    {
        return Err(fail());
    }
    base.as_object_mut().unwrap().remove("clockActorId");
    base.as_object_mut().unwrap().remove("sourceRuleId");
    if !e["clockActorId"].is_null() {
        uuid::Uuid::parse_str(string(&e["clockActorId"], 40)?).map_err(|_| fail())?;
    }
    if !e["sourceRuleId"].is_null() {
        string(&e["sourceRuleId"], 150)?;
    }
    if !e["nextRoll"].is_null() && !e["nextRoll"].is_boolean() {
        return Err(fail());
    }
    if let Some(d) = e["damageDice"].as_str() {
        let parts: Vec<&str> = d.split('k').collect();
        if e["target"] != "damage"
            || parts.len() != 2
            || !parts[0].parse::<i64>().is_ok_and(|n| (1..=99).contains(&n))
            || !["4", "6", "8", "10", "12", "20"].contains(&parts[1])
        {
            return Err(fail());
        }
    } else if !e["damageDice"].is_null() {
        return Err(fail());
    }

    keys(
        &base,
        &[
            "id",
            "label",
            "remaining",
            "phase",
            "target",
            "modifier",
            "mode",
        ],
    )?;
    uuid::Uuid::parse_str(string(&e["id"], 40)?).map_err(|_| fail())?;
    if string(&e["label"], 300)?.trim().is_empty() {
        return Err(fail());
    }
    integer(&e["remaining"], 1, 1000)?;
    integer(&e["modifier"], -100, 100)?;
    choice(&e["phase"], &["start", "end", "round", "manual"])?;
    choice(&e["mode"], &["normal", "advantage", "disadvantage"])?;
    choice(
        &e["target"],
        &[
            "attackSave",
            "intTools",
            "tt",
            "all",
            "attack",
            "damage",
            "str",
            "dex",
            "con",
            "int",
            "wis",
            "cha",
            "save",
            "skill",
        ],
    )?;
    Ok(())
}
fn validate_active_resolution(
    app: &Value,
    c: &Character,
    p: &Value,
    action: &Value,
) -> Result<Option<String>, String> {
    let levels = c.sheet.as_ref().ok_or("Brak karty.")?["levels"]
        .as_array()
        .ok_or_else(fail)?;
    let level = |id: &str| levels.iter().filter(|l| l["classId"] == id).count();
    let e = &app["effect"];
    let self_target = app["targetId"] == p["id"] && e["recipientActorId"].is_null();
    let resource =
        |id: &str| action["type"] == "use" && action["resourceId"] == id && action["amount"] == 1;
    let effect =
        |target: &str, modifier: i64, phase: &str, remaining: i64, next: bool, mode: &str| {
            e["target"] == target
                && e["modifier"] == modifier
                && e["phase"] == phase
                && e["remaining"] == remaining
                && e["nextRoll"] == next
                && e["mode"] == mode
                && e["sourceRuleId"] == app["ruleId"]
                && e["clockActorId"] == p["actorId"]
                && e["damageDice"].is_null()
                && e["checkDice"].is_null()
        };
    if app["ruleId"] == "resource:trajectory" {
        let modifier = super::condition::current_modifier(c, "int")?;
        if level("spec") < 7
            || !resource("trajectory")
            || !self_target
            || app["cost"] != "none"
            || !app["resolution"].is_null()
            || !effect("attack", modifier, "manual", 1, true, "normal")
        {
            return Err("Nieprawidłowe zastosowanie Trajektorii.".into());
        }
    }
    let r = &app["resolution"];
    if r.is_null() {
        if app["ruleId"] == "class.zlodziej.3.0"
            || app["ruleId"] == "resource:cat"
            || app["ruleId"] == "resource:matrix"
            || (app["ruleId"] == "resource:insult" && level("cwaniak") >= 11)
        {
            return Err("Brak rozliczenia efektu zdolności.".into());
        }
        return Ok(None);
    }
    let message = match r["kind"].as_str().unwrap_or("") {
        "catDefense" => {
            keys(r, &["kind", "die"])?;
            let size = 4 + 2 * ((level("zlodziej") as i64 - 2) / 3);
            let die = integer(&r["die"], 1, size)?;
            if level("zlodziej") < 9
                || !resource("cat")
                || app["ruleId"] != "resource:cat"
                || app["cost"] != "reaction"
                || !self_target
                || !effect("tt", die, "start", 1, false, "normal")
            {
                return Err("Nieprawidłowy Koci odskok.".into());
            }
            format!(
                "Koci odskok: k{} = {}; TT +{} do początku następnej tury.",
                size, die, die
            )
        }
        "deadlyInsult" => {
            keys(r, &["kind", "die"])?;
            let die = integer(&r["die"], 1, 6)?;
            if level("cwaniak") < 11
                || !resource("insult")
                || app["ruleId"] != "resource:insult"
                || app["cost"] != "action"
            {
                return Err(
                    "Śmiertelna obelga wymaga 11. poziomu Cwaniaka i użycia Obelgi.".into(),
                );
            }
            let cha = super::condition::current_modifier(c, "cha")?;
            format!(
                "Śmiertelna obelga: k6 = {}; {} × CHA {} = {} obrażeń psychicznych.",
                die,
                die,
                cha,
                (die * cha).max(0)
            )
        }
        "sneakBleed" | "sneakSlow" | "sneakBlind" => {
            if level("zlodziej") < 3
                || app["ruleId"] != "class.zlodziej.3.0"
                || app["cost"] != "none"
                || app["once"] != "turn"
                || self_target
            {
                return Err("Nieprawidłowy Podstępny atak.".into());
            }
            match r["kind"].as_str().unwrap() {
                "sneakBleed" => {
                    keys(r, &["kind"])?;
                    if e["condition"] != "bleeding"
                        || !effect("all", 0, "manual", 1, false, "normal")
                    {
                        return Err(fail());
                    }
                    "Podstępny atak: krwawienie 1k8 na początku tury celu, do opatrzenia; zamiast dodatkowych obrażeń.".into()
                }
                "sneakBlind" => {
                    keys(r, &["kind"])?;
                    if e["condition"] != "blinded"
                        || !effect("attack", 0, "end", 2, false, "disadvantage")
                    {
                        return Err(fail());
                    }
                    "Podstępny atak: Oślepienie do końca następnej tury używającego; zamiast dodatkowych obrażeń.".into()
                }
                _ => {
                    keys(r, &["kind", "die"])?;
                    let die = integer(&r["die"], 1, 6)?;
                    if e["speedReduction"].as_f64() != Some(die as f64 * 1.5)
                        || !effect("all", 0, "end", 2, false, "normal")
                    {
                        return Err(fail());
                    }
                    format!("Podstępny atak: k6 = {}; Szybkość −{} m do końca następnej tury używającego; zamiast dodatkowych obrażeń.",die,die as f64*1.5)
                }
            }
        }
        "matrix" => {
            keys(r, &["kind", "incomingDamage", "saveSucceeded"])?;
            let damage = integer(&r["incomingDamage"], 0, 100000)?;
            let success = r["saveSucceeded"].as_bool().ok_or_else(fail)?;
            if level("zlodziej") < 7
                || !resource("matrix")
                || app["ruleId"] != "resource:matrix"
                || app["cost"] != "none"
                || !self_target
                || !e.is_null()
            {
                return Err("Nieprawidłowe użycie Matrix.".into());
            }
            format!(
                "Matrix: {} → {} obrażeń; {} RO na Zręczność. PW bez zmian.",
                damage,
                if success { 0 } else { damage / 2 },
                if success { "udany" } else { "nieudany" }
            )
        }
        "dodge" => {
            keys(r, &["kind", "incomingDamage"])?;
            let damage = integer(&r["incomingDamage"], 0, 100000)?;
            if level("zlodziej") < 5
                || app["ruleId"] != "class.zlodziej.5.0"
                || app["cost"] != "reaction"
                || !self_target
                || !e.is_null()
            {
                return Err("Nieprawidłowy Odskok.".into());
            }
            format!("Odskok: {} → {} obrażeń. PW bez zmian.", damage, damage / 2)
        }
        _ => return Err("Nieznany efekt zdolności.".into()),
    };
    Ok(Some(message))
}

fn budget() -> Value {
    json!({"action":1,"bonus":1,"reaction":1,"interaction":1,"attacks":0,"use":0})
}
fn spend(p: &mut Value, cost: &str) -> Result<(), String> {
    if cost == "none" {
        return Ok(());
    }
    if !["action", "bonus", "reaction", "interaction", "use"].contains(&cost) {
        return Err("Nieznany koszt czynności.".into());
    }
    let left = p["budget"][cost].as_i64().unwrap_or(0);
    if left < 1 {
        return Err("Ta czynność została już wykorzystana w tej turze.".into());
    }
    p["budget"][cost] = json!(left - 1);
    Ok(())
}
pub async fn ensure_inactive(tx: &mut Tx<'_>, slot: i64) -> Result<(), String> {
    if rows(tx, slot)
        .await?
        .iter()
        .any(|p| p["state"] == "active" || p["effects"].as_array().is_some_and(|es| !es.is_empty()))
    {
        return Err("Najpierw zakończ udział kart BG w tej walce. Reset i czyszczenie nie odnawiają postaci.".into());
    }
    Ok(())
}
pub async fn execute(pool: &SqlitePool, r: Request) -> Result<Value, String> {
    uuid::Uuid::parse_str(&r.operation_id).map_err(|_| fail())?;
    uuid::Uuid::parse_str(&r.actor_id).map_err(|_| fail())?;
    uuid::Uuid::parse_str(&r.character_id).map_err(|_| fail())?;
    let request = serde_json::to_value(&r).map_err(|e| e.to_string())?;
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    sqlx::query("UPDATE encounters SET id=id WHERE id=?")
        .bind(r.encounter_id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    if let Some(row) = sqlx::query(
        "SELECT request_json,result_json FROM participation_operations WHERE operation_id=?",
    )
    .bind(&r.operation_id)
    .fetch_optional(&mut *tx)
    .await
    .map_err(|e| e.to_string())?
    {
        let old: Value =
            serde_json::from_str(row.get("request_json")).map_err(|e| e.to_string())?;
        if old != request {
            return Err("Identyfikator operacji ma już inne dane.".into());
        }
        return serde_json::from_str(row.get("result_json")).map_err(|e| e.to_string());
    }
    let revision: i64 = sqlx::query_scalar("SELECT combat_revision FROM encounters WHERE id=?")
        .bind(r.encounter_id)
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    if revision != r.encounter_revision {
        return Err("Potyczka zmieniła się. Odczytaj ponownie podgląd.".into());
    }
    let raw: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
        .bind(&r.character_id)
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let c: Character = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    if c.revision != r.character_revision {
        return Err("Karta BG zmieniła się. Odczytaj ponownie podgląd.".into());
    }
    let actor =
        sqlx::query("SELECT * FROM encounter_actors WHERE id=? AND encounter_id=? AND kind='pc'")
            .bind(&r.actor_id)
            .bind(r.encounter_id)
            .fetch_one(&mut *tx)
            .await
            .map_err(|_| "Wybierz zapisanego BG w tej potyczce.".to_string())?;
    let mut p = rows(&mut tx, r.encounter_id)
        .await?
        .into_iter()
        .find(|p| p["actorId"] == r.actor_id);
    if p.as_ref().and_then(|v| v["revision"].as_i64()) != r.expected_revision {
        return Err("Udział BG został zmieniony. Odśwież podgląd.".into());
    }
    if p.as_ref()
        .is_some_and(|p| p["characterId"] != r.character_id)
    {
        return Err(fail());
    }
    let kind = r.action["kind"].as_str().ok_or_else(fail)?;
    let message;
    if kind == "link" {
        keys(&r.action, &["kind"])?;
        if p.is_some() || c.archived || c.sheet.is_none() || c.draft.is_some() {
            return Err("Wybierz zatwierdzoną, niearchiwalną kartę bez szkicu.".into());
        }
        let current: Option<String> =
            sqlx::query_scalar("SELECT current_turn_actor_id FROM encounters WHERE id=?")
                .bind(r.encounter_id)
                .fetch_one(&mut *tx)
                .await
                .map_err(|e| e.to_string())?;
        if current.is_some() {
            return Err("Powiąż kartę w przygotowanej potyczce, przed rozpoczęciem tur.".into());
        }
        let prior = json!({"name":actor.get::<String,_>("display_name"),"hp":actor.get::<i64,_>("hp_current"),"hpMax":actor.get::<i64,_>("hp_max_current"),"tt":actor.get::<i64,_>("tt_current"),"runtime":actor.get::<String,_>("runtime_overrides_json"),"prepared":actor.get::<Option<String>,_>("reset_snapshot_json")});
        let value = json!({"id":r.operation_id,"characterId":r.character_id,"encounterId":r.encounter_id,"actorId":r.actor_id,"revision":0,"state":"prepared","budget":budget(),"effects":[],"usedRound":[],"weapons":{},"legacy":prior});
        sqlx::query("INSERT INTO character_participations(id,character_id,encounter_id,actor_id,revision,state,payload_json) VALUES(?,?,?,?,0,'prepared',?)")
            .bind(&r.operation_id).bind(&r.character_id).bind(r.encounter_id).bind(&r.actor_id).bind(value.to_string()).execute(&mut *tx).await.map_err(|_|"Ta karta jest już przypisana do tego slotu.".to_string())?;
        p = Some(value);
        message = "Powiązano pełną kartę BG. Trwałe dane pochodzą z karty.";
    } else {
        let v = p
            .as_mut()
            .ok_or_else(|| "BG nie ma powiązanej karty.".to_string())?;
        match kind {
            "end" => {
                keys(&r.action, &["kind"])?;
                if v["effects"].as_array().is_some_and(|e| !e.is_empty()) {
                    return Err("Rozlicz efekty czasowe przed zakończeniem udziału.".into());
                }
                v["state"] = json!("ended");
                message = "Zakończono udział BG; zdrowie i wyposażenie zachowane.";
            }
            "unlink" => {
                keys(&r.action, &["kind", "hp", "hpMax", "tt", "name"])?;
                if v["state"] == "active" || !v["effects"].as_array().unwrap().is_empty() {
                    return Err("Zakończ udział i rozlicz efekty przed odłączeniem.".into());
                }
                let hp = integer(&r.action["hp"], 0, 100000)?;
                let max = integer(&r.action["hpMax"], 1, 100000)?;
                let tt = integer(&r.action["tt"], 0, 100000)?;
                let name = string(&r.action["name"], 300)?;
                if hp > max || name.trim().is_empty() {
                    return Err(fail());
                }
                // Explicit current snapshot, never overwrite the Character with the legacy actor.
                let runtime: Value = serde_json::from_str(actor.get("runtime_overrides_json"))
                    .map_err(|e| e.to_string())?;
                let effects: Vec<String> = sqlx::query_scalar(
                    "SELECT status_json FROM actor_statuses WHERE actor_id=? ORDER BY id",
                )
                .bind(&r.actor_id)
                .fetch_all(&mut *tx)
                .await
                .map_err(|e| e.to_string())?;
                let effects: Vec<Value> = effects
                    .into_iter()
                    .map(|s| serde_json::from_str(&s))
                    .collect::<Result<_, _>>()
                    .map_err(|e| e.to_string())?;
                let snapshot = json!({"id":r.actor_id,"displayName":name,"hpCurrent":hp,"hpMaxCurrent":max,"ttCurrent":tt,"initiativeValue":actor.get::<Option<i64>,_>("initiative_value"),"initiativeTieOrder":actor.get::<i64,_>("initiative_tie_order"),"statuses":runtime["manualStatuses"],"effects":effects});
                sqlx::query("UPDATE encounter_actors SET display_name=?,hp_current=?,hp_max_current=?,tt_current=?,reset_snapshot_json=? WHERE id=?")
                    .bind(name).bind(hp).bind(max).bind(tt).bind(snapshot.to_string()).bind(&r.actor_id).execute(&mut *tx).await.map_err(|e|e.to_string())?;
                sqlx::query("DELETE FROM character_participations WHERE id=?")
                    .bind(v["id"].as_str())
                    .execute(&mut *tx)
                    .await
                    .map_err(|e| e.to_string())?;
                message = "Odłączono kartę; BG w potyczce zachowuje jawnie zatwierdzone wartości.";
            }
            "spend" => {
                keys(&r.action, &["kind", "cost", "label"])?;
                if v["state"] != "active" {
                    return Err("Rozpocznij walkę przed rozliczeniem akcji.".into());
                }
                let label = string(&r.action["label"], 300)?;
                if label.trim().is_empty() {
                    return Err(fail());
                }
                let cost = string(&r.action["cost"], 20)?;
                allowed_cost(&mut tx, v, &c, cost).await?;
                spend(v, cost)?;
                message = "Rozliczono czynność BG.";
            }
            "weaponAttack" => {
                keys(&r.action, &["kind", "weaponId", "bonus"])?;
                if v["state"] != "active" || !r.action["bonus"].is_boolean() {
                    return Err(fail());
                }
                let weapon = c
                    .inventory
                    .as_ref()
                    .and_then(|i| i["entries"].as_array())
                    .and_then(|es| es.iter().find(|e| e["id"] == r.action["weaponId"]))
                    .ok_or("Wybierz broń z ekwipunku.")?;
                if weapon["item"]["weaponProfile"]["attackKind"] != "melee"
                    || !super::inventory::ready_weapon(weapon)
                {
                    return Err("Wyposaż broń do walki wręcz.".into());
                }
                let levels = c.sheet.as_ref().unwrap()["levels"].as_array().unwrap();
                let model = weapon["weapon"]["model"].as_str().unwrap_or("");
                let marker = format!("actor-turn:attacked:{}", model);
                if r.action["bonus"] == true {
                    let favorite = levels.iter().any(|l| {
                        l["choices"]["favorite-weapon"]
                            .as_array()
                            .is_some_and(|xs| {
                                xs.iter().any(|x| {
                                    x.as_str().is_some_and(|name| {
                                        [model, weapon["item"]["name"].as_str().unwrap_or("")]
                                            .iter()
                                            .any(|n| {
                                                n.trim().to_lowercase()
                                                    == name.trim().to_lowercase()
                                            })
                                    })
                                })
                            })
                    });
                    if !favorite || !v["usedRound"].as_array().unwrap().contains(&json!(marker)) {
                        return Err(
                            "Najpierw wykonaj Atakowanie Ulubioną bronią w tej turze.".into()
                        );
                    }
                    allowed_cost(&mut tx, v, &c, "bonus").await?;
                    spend(v, "bonus")?;
                } else {
                    allowed_cost(&mut tx, v, &c, "action").await?;
                    if v["budget"]["attacks"].as_i64().unwrap_or(0) == 0 {
                        spend(v, "action")?;
                        let count =
                            |class: &str| levels.iter().filter(|l| l["classId"] == class).count();
                        v["budget"]["attacks"] = json!(if count("twardziel") >= 10 {
                            3
                        } else if ["twardziel", "brutal", "zwiadowca"]
                            .iter()
                            .any(|cl| count(cl) >= 5)
                        {
                            2
                        } else {
                            1
                        });
                    }
                    v["budget"]["attacks"] = json!(v["budget"]["attacks"].as_i64().unwrap() - 1);
                    if !v["usedRound"].as_array().unwrap().contains(&json!(marker)) {
                        v["usedRound"].as_array_mut().unwrap().push(json!(marker));
                    }
                }
                message = "Rozliczono atak bronią białą.";
            }
            "effect" => {
                keys(&r.action, &["kind", "effect"])?;
                let e = &r.action["effect"];
                validate_effect(e)?;

                let effects = v["effects"].as_array_mut().unwrap();
                if effects.len() >= 100 || effects.iter().any(|x| x["id"] == e["id"]) {
                    return Err(fail());
                }
                effects.push(e.clone());
                message = "Dodano efekt czasowy BG.";
            }
            "removeEffect" => {
                keys(&r.action, &["kind", "id"])?;
                let effects = v["effects"].as_array_mut().unwrap();
                if let Some(e) = effects
                    .iter_mut()
                    .find(|e| e["id"] == r.action["id"] && e["label"] == "Berserk")
                {
                    e["label"] = json!("Zmęczenie po Berserku");
                    e["remaining"] = json!(2);
                    e["mode"] = json!("normal");
                } else {
                    effects.retain(|e| e["id"] != r.action["id"]);
                }
                message = "Rozliczono i usunięto efekt BG.";
            }
            _ => return Err("Nieznana operacja udziału BG.".into()),
        }
        v["revision"] = json!(v["revision"].as_i64().unwrap() + 1);
        if kind != "unlink" {
            put(&mut tx, v).await?;
        }
    }
    let value = p.unwrap();
    log(&mut tx, &value, message, &request).await?;
    sqlx::query("UPDATE encounters SET combat_revision=combat_revision+1 WHERE id=?")
        .bind(r.encounter_id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    sqlx::query(
        "INSERT INTO participation_operations(operation_id,request_json,result_json) VALUES(?,?,?)",
    )
    .bind(&r.operation_id)
    .bind(request.to_string())
    .bind(value.to_string())
    .execute(&mut *tx)
    .await
    .map_err(|e| e.to_string())?;
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(value)
}
fn claim_health_turn(p: &mut Value, command: &str, current: Option<&str>) -> Result<(), String> {
    if !["bleed", "deathSave"].contains(&command) {
        return Ok(());
    }
    if current != p["actorId"].as_str() {
        return Err("Rozlicz tę czynność w turze tej postaci.".into());
    }
    let key = format!("turn:{command}");
    let used = p["usedRound"].as_array_mut().unwrap();
    if used.contains(&json!(key)) {
        return Err("Ta czynność została już rozliczona w tej turze.".into());
    }
    used.push(json!(key));
    Ok(())
}
fn tick(p: &mut Value, phase: &str, actor: Option<&str>) {
    let owner = p["actorId"].as_str().unwrap().to_string();
    let effects = p["effects"].as_array_mut().unwrap();
    for e in effects.iter_mut().filter(|e| {
        e["phase"] == phase
            && (phase == "round" || actor == Some(e["clockActorId"].as_str().unwrap_or(&owner)))
    }) {
        e["remaining"] = json!(e["remaining"].as_i64().unwrap() - 1);
    }
    let expired = effects
        .iter()
        .find(|e| e["label"] == "Berserk" && e["remaining"].as_i64().unwrap() <= 0)
        .cloned();
    effects.retain(|e| e["remaining"].as_i64().unwrap() > 0);
    if let Some(mut e) = expired {
        e["label"] = json!("Zmęczenie po Berserku");
        e["remaining"] = json!(1);
        e["mode"] = json!("normal");
        effects.push(e);
    }
}
pub async fn combat_change(
    tx: &mut Tx<'_>,
    before: &Value,
    after: &Value,
    advance: bool,
    reset: bool,
) -> Result<(), String> {
    let slot = after["encounterId"].as_i64().ok_or_else(fail)?;
    let participants = rows(tx, slot).await?;
    if reset {
        ensure_inactive(tx, slot).await?;
    }
    for mut p in participants {
        let id = p["actorId"].as_str().unwrap().to_string();
        if !after["actors"]
            .as_array()
            .unwrap()
            .iter()
            .any(|a| a["id"] == id)
            && (p["state"] == "active" || !p["effects"].as_array().unwrap().is_empty())
        {
            return Err(
                "Najpierw zakończ udział BG i rozlicz efekty; karta nie została usunięta.".into(),
            );
        }
        let before_effects = p["effects"].as_array().unwrap().len();
        p["effects"].as_array_mut().unwrap().retain(|e| {
            if e["sourceRuleId"] != "profession.star.1" {
                return true;
            }
            !after["actors"].as_array().unwrap().iter().any(|a| {
                a["id"] == e["clockActorId"]
                    && a["effects"].as_array().is_some_and(|es| {
                        es.iter().any(|status| {
                            ["unconscious", "incapacitated", "deafened"]
                                .contains(&status["systemKey"].as_str().unwrap_or(""))
                        })
                    })
            })
        });
        if !advance {
            if before_effects != p["effects"].as_array().unwrap().len() {
                p["revision"] = json!(p["revision"].as_i64().unwrap() + 1);
                put(tx, &p).await?;
            }
            continue;
        }
        p["usedRound"]
            .as_array_mut()
            .unwrap()
            .retain(|x| !x.as_str().is_some_and(|s| s.starts_with("actor-turn:")));
        if p["state"] != "active" {
            if !before["currentTurnActorId"].is_null() {
                continue;
            }
            let raw: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
                .bind(p["characterId"].as_str())
                .fetch_one(&mut **tx)
                .await
                .map_err(|e| e.to_string())?;
            let c: Character = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
            if c.archived
                || c.sheet.is_none()
                || c.draft.is_some()
                || c.condition.as_ref().is_some_and(|v| !v["rest"].is_null())
            {
                return Err("Zatwierdź kartę BG przed rozpoczęciem walki.".into());
            }
            let other:i64=sqlx::query_scalar("SELECT COUNT(*) FROM character_participations WHERE character_id=? AND state='active' AND encounter_id<>?").bind(&c.id).bind(slot).fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
            if other > 0 {
                return Err("Ta karta BG uczestniczy już w innej walce. Zakończ tam jej udział przed rozpoczęciem tej potyczki.".into());
            }
            if c.condition
                .as_ref()
                .is_some_and(|v| v["spent"]["clint"].as_i64().unwrap_or(0) > 0)
            {
                let mut updated = c.clone();
                updated.revision += 1;
                updated.condition.as_mut().unwrap()["spent"]["clint"] = json!(0);
                let op:String=sqlx::query_scalar("SELECT lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-a'||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))").fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
                let payload = serde_json::to_value(&updated).map_err(|e| e.to_string())?;
                sqlx::query("UPDATE characters SET revision=?,payload_json=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?").bind(updated.revision).bind(payload.to_string()).bind(&c.id).execute(&mut **tx).await.map_err(|e|e.to_string())?;
                sqlx::query("INSERT INTO character_operations(operation_id,character_id,kind,request_json,result_json) VALUES(?,?,'condition',?,?)").bind(op).bind(&c.id).bind(json!({"event":"combatStart","participation":p["id"]}).to_string()).bind(payload.to_string()).execute(&mut **tx).await.map_err(|e|e.to_string())?;
            }
            p["state"] = json!("active");
            p["budget"] = budget();
            p["usedRound"] = json!([]);
        }
        tick(&mut p, "end", before["currentTurnActorId"].as_str());
        if before["roundNumber"] != after["roundNumber"] {
            tick(&mut p, "round", None);
            p["usedRound"]
                .as_array_mut()
                .unwrap()
                .retain(|x| x.as_str().is_some_and(|s| s.starts_with("turn:")));
        }
        tick(&mut p, "start", after["currentTurnActorId"].as_str());
        if after["currentTurnActorId"] == id {
            p["usedRound"]
                .as_array_mut()
                .unwrap()
                .retain(|x| !x.as_str().is_some_and(|s| s.starts_with("turn:")));
            p["budget"] = budget();
        }
        p["revision"] = json!(p["revision"].as_i64().unwrap() + 1);
        put(tx, &p).await?;
    }
    Ok(())
}
// Validate before recording, so rejected repetitions leave the local budget unchanged.
fn claim_series(p: &mut Value, mode: &str, hail: bool) -> Result<(), String> {
    if !["short", "long", "massive"].contains(&mode) {
        return Ok(());
    }
    let used = p["usedRound"].as_array().unwrap();
    if used
        .iter()
        .any(|x| x == "area-series" || (mode != "short" && x == "short-series"))
    {
        return Err("Długa/miażdżąca seria wyklucza pozostałe serie w tej rundzie.".into());
    }
    if mode == "short" && !hail && used.iter().any(|x| x == "short-series") {
        return Err("Krótka seria: tylko raz na rundę bez Gradu ołowiu.".into());
    }
    p["usedRound"]
        .as_array_mut()
        .unwrap()
        .push(json!(if mode == "short" {
            "short-series"
        } else {
            "area-series"
        }));
    Ok(())
}
// Changes on the character sheet participate in the same transaction as their combat costs.
pub async fn character_change(tx: &mut Tx<'_>, m: &Mutation) -> Result<(), String> {
    // Draft and journal autosaves cannot change published mechanics or spend combat actions.
    if ["draft", "discard"].contains(&m.kind.as_str()) {
        return Ok(());
    }
    let raw: Option<String> = sqlx::query_scalar(
        "SELECT payload_json FROM character_participations WHERE character_id=? AND state='active'",
    )
    .bind(&m.character.id)
    .fetch_optional(&mut **tx)
    .await
    .map_err(|e| e.to_string())?;
    let Some(raw) = raw else {
        if m.condition_action
            .as_ref()
            .is_some_and(|a| !a["combatApplication"].is_null())
        {
            return Err("Zdolność bojowa wymaga aktywnego udziału w potyczce.".into());
        }
        if m.inventory_action
            .as_ref()
            .is_some_and(|a| a["favoriteBonus"] == true)
        {
            return Err("Ulubiona broń wymaga aktywnego udziału w walce.".into());
        }
        return Ok(());
    };
    let mut p: Value = serde_json::from_str(&raw).map_err(|e| e.to_string())?;
    if ["condition", "inventory"].contains(&m.kind.as_str())
        && m.participation_revision != p["revision"].as_i64()
    {
        return Err("Udział w walce zmienił się. Przygotuj podgląd ponownie.".into());
    }
    if ["publish", "archive"].contains(&m.kind.as_str()) {
        return Err("Najpierw zakończ aktywny udział tej postaci w walce.".into());
    }
    let c = &m.character;
    let levels = c.sheet.as_ref().unwrap()["levels"].as_array().unwrap();
    let class_level = |name: &str| levels.iter().filter(|l| l["classId"] == name).count();
    let feat = |name: &str| {
        levels.iter().any(|l| {
            ["start", "feat", "profession-feat"].iter().any(|k| {
                l["choices"][*k]
                    .as_array()
                    .is_some_and(|a| a.contains(&json!(name)))
            })
        })
    };
    let mut cost = "none";
    let mut units = 1;
    let mut once = None;
    if let Some(a) = &m.condition_action {
        let kind = a["type"].as_str().unwrap_or("");
        if ["restStart", "restApply", "worldTime", "downtime", "care"].contains(&kind) {
            return Err("Zakończ udział w walce przed czynnościami odpoczynku i postoju.".into());
        }
        if kind == "combatHealth" {
            let current: Option<String> =
                sqlx::query_scalar("SELECT current_turn_actor_id FROM encounters WHERE id=?")
                    .bind(p["encounterId"].as_i64())
                    .fetch_one(&mut **tx)
                    .await
                    .map_err(|e| e.to_string())?;
            claim_health_turn(
                &mut p,
                a["command"]["kind"].as_str().unwrap_or(""),
                current.as_deref(),
            )?;
        }
        if kind == "use" {
            let id = a["resourceId"].as_str().unwrap_or("");
            cost = match id {
                "berserk" | "advice" | "stamina" => "bonus",
                "motivation" | "heckle" | "defense" => "reaction",
                "insult" => "action",
                _ => "none",
            };
            if ["rage", "luck"].contains(&id) {
                once = Some(id);
            }
            if id == "berserk" {
                if p["effects"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|e| e["label"] == "Berserk")
                {
                    return Err("Berserk jest już aktywny.".into());
                }
                p["effects"].as_array_mut().unwrap().push(json!({"id":m.operation_id,"label":"Berserk","remaining":10,"phase":"end","target":"str","modifier":0,"mode":"advantage"}));
            }
            if id == "surge" {
                let key = if a["combatChoice"] == "bonus" {
                    "bonus"
                } else {
                    "action"
                };
                p["budget"][key] = json!(p["budget"][key].as_i64().unwrap() + 1);
            }
            if id == "hands" {
                p["budget"]["use"] = json!(p["budget"]["use"].as_i64().unwrap() + 1);
            }
        }
    }
    if let Some(a) = &m.inventory_action {
        let kind = a["kind"].as_str().unwrap_or("");
        let inv = c.inventory.as_ref().unwrap();
        let weapon = inv["entries"]
            .as_array()
            .unwrap()
            .iter()
            .find(|e| e["id"] == a["weaponId"] || e["id"] == a["magazineId"]);
        let choose = |choices: &[&'static str]| {
            choices
                .iter()
                .copied()
                .find(|key| p["budget"][*key].as_i64().unwrap_or(0) > 0)
                .unwrap_or("action")
        };
        if kind == "attach" || kind == "unload" {
            cost = if feat("fingers") {
                choose(&["bonus", "action"])
            } else {
                "action"
            };
        }
        if kind == "cycle" {
            cost = choose(&["interaction", "bonus"]);
        }
        if kind == "cinematic" && a["loaded"] == true || kind == "load" {
            let system = weapon
                .map(|w| w["weapon"]["system"].as_str().unwrap_or("detachable"))
                .unwrap_or("detachable");
            cost = if system == "loading" {
                if feat("robin") && weapon.is_some_and(|w| w["weapon"]["category"] == "thrown") {
                    choose(&["interaction", "bonus", "action"])
                } else {
                    choose(&["bonus", "action"])
                }
            } else if feat("fingers") {
                choose(&["bonus", "action"])
            } else {
                "action"
            };
            if kind == "load" && system == "internal" {
                units = a["count"].as_i64().unwrap_or(1);
            }
        }
        if ["attach", "unload", "load", "cycle"].contains(&kind)
            || (kind == "cinematic" && a["loaded"] == true)
        {
            if p["budget"]["use"].as_i64().unwrap_or(0) >= units {
                cost = "use";
            }
        }
        if kind == "weaponState" {
            match a["operation"].as_str().unwrap_or("") {
                "jam" | "clearJam" => cost = "action",
                "cool" => {
                    return Err("Ostygnięcie broni rozlicz po zakończeniu udziału w walce.".into())
                }
                _ => (),
            }
        }
        if kind == "shot" {
            let mode = a["mode"].as_str().unwrap_or("");
            let bonus_shot = a["favoriteBonus"] == true;
            let weapon = weapon.ok_or("Nie znaleziono broni.")?;
            let model = weapon["weapon"]["model"].as_str().unwrap_or("");
            let marker = format!("actor-turn:attacked:{}", model);
            if bonus_shot {
                let favorites = levels.iter().flat_map(|l| {
                    l["choices"]["favorite-weapon"]
                        .as_array()
                        .into_iter()
                        .flatten()
                });
                if class_level("twardziel") == 0
                    || !favorites.into_iter().any(|v| {
                        v.as_str().is_some_and(|name| {
                            [model, weapon["item"]["name"].as_str().unwrap_or("")]
                                .iter()
                                .any(|n| n.trim().to_lowercase() == name.trim().to_lowercase())
                        })
                    })
                    || !p["usedRound"].as_array().unwrap().contains(&json!(marker))
                {
                    return Err(
                        "Ulubiona broń: najpierw wykonaj Atakowanie tym modelem w swojej turze."
                            .into(),
                    );
                }
                if !["single", "double"].contains(&mode) {
                    return Err(
                        "Dodatkowy atak Ulubioną bronią nie jest akcją strzelania serią.".into(),
                    );
                }
                cost = "bonus";
            } else {
                claim_series(&mut p, mode, feat("hail"))?;
                allowed_cost(tx, &p, c, "action").await?;
                if ["long", "massive"].contains(&mode) || (mode == "short" && !feat("hail")) {
                    cost = "action";
                    p["budget"]["attacks"] = json!(0);
                } else {
                    if p["budget"]["attacks"].as_i64().unwrap_or(0) == 0 {
                        spend(&mut p, "action")?;
                        let attacks = if class_level("twardziel") >= 10 {
                            3
                        } else if ["twardziel", "brutal", "zwiadowca"]
                            .iter()
                            .any(|x| class_level(x) >= 5)
                        {
                            2
                        } else {
                            1
                        };
                        p["budget"]["attacks"] = json!(attacks);
                    }
                    p["budget"]["attacks"] = json!(p["budget"]["attacks"].as_i64().unwrap() - 1);
                    if !p["usedRound"].as_array().unwrap().contains(&json!(marker)) {
                        p["usedRound"].as_array_mut().unwrap().push(json!(marker));
                    }
                }
            }
        }
    }
    if let Some(app) = m
        .condition_action
        .as_ref()
        .and_then(|a| a.get("combatApplication"))
    {
        let mut checked_app = app.clone();
        checked_app
            .as_object_mut()
            .ok_or_else(fail)?
            .remove("additionalTargets");
        checked_app.as_object_mut().unwrap().remove("resolution");
        keys(
            &checked_app,
            &[
                "ruleId",
                "label",
                "page",
                "cost",
                "once",
                "confirmed",
                "targetId",
                "targetRevision",
                "effect",
            ],
        )?;
        if app["confirmed"] != true {
            return Err("Potwierdź warunki użycia zdolności.".into());
        }
        string(&app["ruleId"], 150)?;
        string(&app["label"], 200)?;
        integer(&app["page"], 1, 1000)?;
        choice(
            &app["cost"],
            &["none", "action", "bonus", "reaction", "interaction", "use"],
        )?;
        choice(&app["once"], &["none", "turn", "round"])?;
        // The named resource's compulsory cost cannot be removed by a situational choice.
        if cost != "none" && app["cost"] != cost {
            return Err("Koszt tej zdolności nie zgadza się z wymaganym rodzajem akcji.".into());
        }
        cost = app["cost"].as_str().unwrap();
        let resolution_message =
            validate_active_resolution(app, c, &p, m.condition_action.as_ref().unwrap())?;
        if app["ruleId"] == "class.zlodziej.3.0" || app["ruleId"] == "resource:trajectory" {
            let current: Option<String> =
                sqlx::query_scalar("SELECT current_turn_actor_id FROM encounters WHERE id=?")
                    .bind(p["encounterId"].as_i64())
                    .fetch_one(&mut **tx)
                    .await
                    .map_err(|e| e.to_string())?;
            if current.as_deref() != p["actorId"].as_str() {
                return Err("Ta zdolność wymaga Twojej tury.".into());
            }
        }
        if let Some(message) = resolution_message {
            log(
                tx,
                &p,
                &message,
                &json!({"operationId":m.operation_id,"resolution":app["resolution"]}),
            )
            .await?;
        }
        if app["once"] != "none" {
            let key = format!(
                "{}ability:{}",
                if app["once"] == "turn" {
                    "actor-turn:"
                } else {
                    ""
                },
                if app["ruleId"] == "class.zlodziej.3.0" {
                    "class.zlodziej.1.1"
                } else {
                    app["ruleId"].as_str().unwrap()
                }
            );
            if p["usedRound"].as_array().unwrap().contains(&json!(key)) {
                return Err("Ta zdolność została już wykorzystana w tym okresie.".into());
            }
            p["usedRound"].as_array_mut().unwrap().push(json!(key));
        }
        let mut selected_targets =
            vec![json!({"id":app["targetId"], "revision":app["targetRevision"]})];
        if let Some(extra) = app.get("additionalTargets") {
            let extra = extra.as_array().ok_or_else(fail)?;
            if extra.len() > 99 {
                return Err(fail());
            }
            selected_targets.extend(extra.iter().cloned());
        }
        let mut unique = std::collections::HashSet::new();
        for selected_target in selected_targets {
            keys(&selected_target, &["id", "revision"])?;
            let target_id = string(&selected_target["id"], 40)?;
            if !unique.insert(target_id.to_owned()) {
                return Err("Cel został wybrany więcej niż raz.".into());
            }
            integer(&selected_target["revision"], 0, i64::MAX)?;
            let mut target = rows(tx, p["encounterId"].as_i64().unwrap())
                .await?
                .into_iter()
                .find(|t| t["id"] == target_id && t["state"] == "active")
                .ok_or("Cel nie uczestniczy w tej walce.")?;
            if target["revision"] != selected_target["revision"] {
                return Err("Stan celu zmienił się. Przygotuj użycie ponownie.".into());
            }
            if !app["effect"].is_null() {
                let e = &app["effect"];
                validate_effect(e)?;
                if let Some(actor_id) = e["recipientActorId"].as_str() {
                    let found:i64=sqlx::query_scalar("SELECT COUNT(*) FROM encounter_actors WHERE id=? AND encounter_id=? AND kind='enemy'").bind(actor_id).bind(p["encounterId"].as_i64()).fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
                    if found != 1 || target["id"] != p["id"] {
                        return Err("Wybierz przeciwnika z bieżącej potyczki.".into());
                    }
                }
                if target["id"] == p["id"] {
                    target = p.clone();
                }
                if app["ruleId"] == "class.zlodziej.3.0" {
                    let existing = rows(tx, p["encounterId"].as_i64().unwrap()).await?;
                    let repeated = existing.iter().any(|owner| {
                        owner["effects"].as_array().is_some_and(|effects| {
                            effects.iter().any(|old| {
                                let same_target = if !e["recipientActorId"].is_null() {
                                    old["recipientActorId"] == e["recipientActorId"]
                                } else {
                                    owner["id"] == target["id"] && old["recipientActorId"].is_null()
                                };
                                same_target
                                    && ((!e["condition"].is_null()
                                        && old["condition"] == e["condition"])
                                        || (!e["speedReduction"].is_null()
                                            && !old["speedReduction"].is_null()))
                            })
                        })
                    });
                    if repeated {
                        return Err("Ten efekt Podstępnego ataku już działa na cel; efekty tego samego rodzaju nie sumują się.".into());
                    }
                }
                let effects = target["effects"].as_array_mut().unwrap();
                if effects.len() >= 100 || effects.iter().any(|x| x["id"] == e["id"]) {
                    return Err(fail());
                }
                effects.push(e.clone());
                if target["id"] == p["id"] {
                    p = target;
                } else {
                    target["revision"] = json!(target["revision"].as_i64().unwrap() + 1);
                    put(tx, &target).await?;
                    log(tx, &target, "Zastosowano zdolność do wskazanego BG.", app).await?;
                }
            }
        }
    }
    allowed_cost(tx, &p, c, cost).await?;
    for _ in 0..units {
        spend(&mut p, cost)?;
    }

    if let Some(id) = once {
        let used = p["usedRound"].as_array_mut().unwrap();
        if used.contains(&json!(id)) {
            return Err("Zdolność została już wykorzystana w tej rundzie.".into());
        }
        used.push(json!(id));
    }
    p["revision"] = json!(p["revision"].as_i64().unwrap() + 1);
    put(tx, &p).await?;
    log(
        tx,
        &p,
        &m.condition_action
            .as_ref()
            .and_then(|a| a.get("combatApplication"))
            .map(|a| {
                format!(
                    "{} — rozliczono koszt, zasób i wskazany efekt.",
                    a["label"].as_str().unwrap_or("Zdolność")
                )
            })
            .unwrap_or_else(|| "Zaktualizowano trwałą kartę BG i koszty czynności.".into()),
        &json!({"operationId":m.operation_id,"cost":cost,"kind":m.kind}),
    )
    .await?;
    Ok(())
}
#[tauri::command]
pub async fn participation_command(
    databases: tauri::State<'_, DbInstances>,
    request: Request,
) -> Result<Value, String> {
    let pool = {
        let instances = databases.0.read().await;
        let Some(tauri_plugin_sql::DbPool::Sqlite(p)) = instances.get("sqlite:combat-tracker.db")
        else {
            return Err("Baza nie jest otwarta.".into());
        };
        p.clone()
    };
    execute(&pool, request).await
}

async fn allowed_cost(tx: &mut Tx<'_>, p: &Value, c: &Character, cost: &str) -> Result<(), String> {
    if cost == "none" {
        return Ok(());
    }
    if p["effects"]
        .as_array()
        .unwrap()
        .iter()
        .any(|e| e["label"] == "Zmęczenie po Berserku")
    {
        return Err("Zmęczenie po Berserku blokuje czynności do końca następnej tury.".into());
    }
    let blocked:i64=sqlx::query_scalar("SELECT COUNT(*) FROM actor_statuses WHERE actor_id=? AND json_extract(status_json,'$.systemKey') IN ('unconscious','incapacitated','stunned','paralyzed')").bind(p["actorId"].as_str()).fetch_one(&mut **tx).await.map_err(|e|e.to_string())?;
    if blocked > 0 {
        return Err("Stan postaci blokuje zwykłe czynności.".into());
    }
    if let Some(reason) = health_action_block(c, cost) {
        return Err(reason.into());
    }
    let current: Option<String> =
        sqlx::query_scalar("SELECT current_turn_actor_id FROM encounters WHERE id=?")
            .bind(p["encounterId"].as_i64())
            .fetch_one(&mut **tx)
            .await
            .map_err(|e| e.to_string())?;
    if cost != "reaction" && current.as_deref() != p["actorId"].as_str() {
        return Err("Tę czynność wykonujesz w swojej turze.".into());
    }
    Ok(())
}
fn health_action_block(c: &Character, cost: &str) -> Option<&'static str> {
    let condition = c.condition.as_ref();
    let injury = condition.map_or(0, |v| v["injury"].as_i64().unwrap_or(0));
    let hp = condition
        .and_then(|v| v["hp"].as_i64())
        .or_else(|| c.sheet.as_ref().and_then(|v| v["hpCurrent"].as_i64()))
        .unwrap_or(0);
    let exhaustion = condition
        .and_then(|v| v["exhaustion"].as_array())
        .map_or(0, |entries| {
            entries
                .iter()
                .map(|e| e["level"].as_i64().unwrap_or(0))
                .sum::<i64>()
        });
    if hp == 0
        || injury >= 5
        || exhaustion >= 6
        || condition.is_some_and(|v| v["combatHealth"]["dead"] == true)
    {
        Some("Stan zdrowia blokuje zwykłe czynności.")
    } else if cost == "reaction" && injury >= 2 || cost == "bonus" && injury >= 3 {
        Some("Zranienia blokują ten rodzaj czynności.")
    } else {
        None
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn wound_reaction_bonus_and_fatal_exhaustion_restrict_actions() {
        let cases: Vec<Value> = serde_json::from_str(include_str!(
            "../../tests/fixtures/character-condition.json"
        ))
        .unwrap();
        let mut c: Character = serde_json::from_value(cases[1]["before"].clone()).unwrap();
        c.condition.as_mut().unwrap()["hp"] = json!(10);
        c.condition.as_mut().unwrap()["exhaustion"] = json!([]);
        for injury in 0..=5 {
            c.condition.as_mut().unwrap()["injury"] = json!(injury);
            assert_eq!(health_action_block(&c, "reaction").is_some(), injury >= 2);
            assert_eq!(health_action_block(&c, "bonus").is_some(), injury >= 3);
            assert_eq!(health_action_block(&c, "action").is_some(), injury >= 5);
        }
        c.condition.as_mut().unwrap()["injury"] = json!(0);
        for level in 0..=6 {
            c.condition.as_mut().unwrap()["exhaustion"] = json!([{"level":level}]);
            assert_eq!(health_action_block(&c, "action").is_some(), level >= 6);
        }
    }

    #[test]
    fn short_burst_requires_hail_to_repeat_and_never_combines_with_area_burst() {
        let mut p = json!({"usedRound":[]});
        claim_series(&mut p, "short", false).unwrap();
        let saved = p.clone();
        assert!(claim_series(&mut p, "short", false).is_err());
        assert_eq!(p, saved);
        claim_series(&mut p, "short", true).unwrap();
        assert!(claim_series(&mut p, "long", true).is_err());
        p["usedRound"] = json!([]);
        claim_series(&mut p, "long", true).unwrap();
        assert!(claim_series(&mut p, "short", true).is_err());
        assert!(claim_series(&mut p, "massive", true).is_err());
    }
    async fn setup() -> (SqlitePool, Character, String) {
        let pool = sqlx::sqlite::SqlitePoolOptions::new()
            .max_connections(1)
            .connect("sqlite::memory:")
            .await
            .unwrap();
        for sql in [
            include_str!("../migrations/001_initial.sql"),
            include_str!("../migrations/002_pc_initiative.sql"),
            include_str!("../migrations/003_enemy_instances.sql"),
            include_str!("../migrations/004_combat_log.sql"),
            include_str!("../migrations/005_actor_statuses.sql"),
            include_str!("../migrations/006_bestiary.sql"),
            include_str!("../migrations/008_enemy_categories.sql"),
            include_str!("../migrations/011_characters.sql"),
            include_str!("../migrations/012_character_inventory.sql"),
            include_str!("../migrations/013_character_condition.sql"),
            include_str!("../migrations/014_character_participation.sql"),
        ] {
            sqlx::raw_sql(sql).execute(&pool).await.unwrap();
        }
        let mut c: Character =
            serde_json::from_str(include_str!("../../tests/fixtures/character.json")).unwrap();
        c.sheet = c.draft.take();
        c.sheet.as_mut().unwrap()["hpCurrent"] = json!(20);
        sqlx::query("INSERT INTO characters(id,revision,payload_json,created_at,updated_at) VALUES(?,0,?,'test','test')").bind(&c.id).bind(serde_json::to_string(&c).unwrap()).execute(&pool).await.unwrap();
        let actor = "987c6081-0d1a-48e4-a1e0-4d16407be711".to_string();
        for slot in [1, 2] {
            let actor = if slot == 1 {
                actor.clone()
            } else {
                "987c6081-0d1a-48e4-a1e0-4d16407be712".into()
            };
            let combat=serde_json::from_value(json!({"encounterId":slot,"revision":0,"roundNumber":1,"currentTurnActorId":null,"actors":[{"id":actor,"displayName":"Stary BG","ttCurrent":10,"hpCurrent":5,"hpMaxCurrent":10,"initiativeValue":10,"initiativeTieOrder":0,"statuses":[]}]})).unwrap();
            crate::combat::save_to_pool(&pool, combat).await.unwrap();
        }
        (pool, c, actor)
    }
    fn req(
        c: &Character,
        actor: &str,
        op: i64,
        revision: i64,
        expected: Option<i64>,
        action: Value,
    ) -> Request {
        Request {
            operation_id: format!("987c6081-0d1a-48e4-a1e0-{:012}", op),
            actor_id: actor.into(),
            encounter_id: 1,
            encounter_revision: revision,
            expected_revision: expected,
            character_id: c.id.clone(),
            character_revision: c.revision,
            action,
        }
    }
    async fn advance(
        pool: &SqlitePool,
        slot: i64,
        actor: &str,
        before: Value,
        round: i64,
    ) -> Result<(), String> {
        let mut tx = pool.begin().await.unwrap();
        combat_change(&mut tx,&before,&json!({"encounterId":slot,"roundNumber":round,"currentTurnActorId":actor,"actors":[{"id":actor}]}),true,false).await?;
        sqlx::query("UPDATE encounters SET current_turn_actor_id=?,round_number=? WHERE id=?")
            .bind(actor)
            .bind(round)
            .bind(slot)
            .execute(&mut *tx)
            .await
            .unwrap();
        tx.commit().await.unwrap();
        Ok(())
    }
    #[test]
    fn numbered_weapon_slots_charge_combat_and_ammunition_once() {
        tauri::async_runtime::block_on(async {
            for melee in [true, false] {
                let (pool, mut c, actor) = setup().await;
                let mut inv: Value = serde_json::from_str(include_str!(
                    "../../tests/fixtures/character-inventory.json"
                ))
                .unwrap();
                let weapon_id = inv["entries"][0]["id"].clone();
                inv["entries"][0]["slot"] = json!(if melee { "melee1" } else { "ranged1" });
                inv["entries"][0]["grip"] = json!("twoHanded");
                if melee {
                    inv["entries"][0]["weapon"]["category"] = json!("melee");
                    inv["entries"][0]["weapon"]["system"] = json!("none");
                    inv["entries"][0]["weapon"]["capacity"] = json!(0);
                    inv["entries"][0]["weapon"]["caliber"] = json!("");
                    inv["entries"][0]["item"]["weaponProfile"]["attackKind"] = json!("melee");
                } else {
                    let magazine_id = inv["entries"][1]["id"].clone();
                    let ammo_id = inv["entries"][2]["id"].clone();
                    inv = super::super::inventory::apply(&inv,
                        &json!({"kind":"load","magazineId":magazine_id,"ammoId":ammo_id,"count":10}),
                        "none", false).unwrap();
                    inv = super::super::inventory::apply(
                        &inv,
                        &json!({"kind":"attach","weaponId":weapon_id,"magazineId":magazine_id}),
                        "none",
                        false,
                    )
                    .unwrap();
                }
                super::super::inventory::validate(&inv).unwrap();
                c.inventory = Some(inv.clone());
                sqlx::query("UPDATE characters SET payload_json=? WHERE id=?")
                    .bind(serde_json::to_string(&c).unwrap())
                    .bind(&c.id)
                    .execute(&pool)
                    .await
                    .unwrap();
                execute(&pool, req(&c, &actor, 1, 1, None, json!({"kind":"link"})))
                    .await
                    .unwrap();
                advance(
                    &pool,
                    1,
                    &actor,
                    json!({"currentTurnActorId":null,"roundNumber":1}),
                    1,
                )
                .await
                .unwrap();
                if melee {
                    let request = req(
                        &c,
                        &actor,
                        2,
                        2,
                        Some(1),
                        json!({"kind":"weaponAttack","weaponId":weapon_id,"bonus":false}),
                    );
                    let first = execute(&pool, request.clone()).await.unwrap();
                    assert_eq!(first["budget"]["action"], 0);
                    assert_eq!(first["budget"]["attacks"], 0);
                    assert_eq!(execute(&pool, request).await.unwrap(), first);
                } else {
                    let action =
                        json!({"kind":"shot","weaponId":weapon_id,"mode":"single","count":1});
                    let mut next = c.clone();
                    next.inventory =
                        Some(super::super::inventory::apply(&inv, &action, "none", false).unwrap());
                    let mutation: Mutation = serde_json::from_value(json!({
                        "operationId":"987c6081-0d1a-48e4-a1e0-000000000902",
                        "expectedRevision":c.revision,"character":next,"kind":"inventory",
                        "participationRevision":1,"inventoryAction":action
                    }))
                    .unwrap();
                    let saved = super::super::save_to_pool(&pool, mutation.clone())
                        .await
                        .unwrap();
                    assert_eq!(
                        saved.inventory.as_ref().unwrap()["entries"][1]["magazine"]["rounds"][0]
                            ["count"],
                        9
                    );
                    assert_eq!(
                        super::super::save_to_pool(&pool, mutation).await.unwrap(),
                        saved
                    );
                }
                let mut tx = pool.begin().await.unwrap();
                let participation = rows(&mut tx, 1).await.unwrap().remove(0);
                assert_eq!(participation["budget"]["action"], 0);
                assert_eq!(participation["budget"]["attacks"], 0);
                tx.commit().await.unwrap();
            }
        });
    }
    #[test]
    fn multicasting_charges_once_and_stale_target_rolls_back_all_effects() {
        tauri::async_runtime::block_on(async {
            let (pool, c, a) = setup().await;
            execute(&pool, req(&c, &a, 1, 1, None, json!({"kind":"link"})))
                .await
                .unwrap();
            advance(
                &pool,
                1,
                &a,
                json!({"currentTurnActorId":null,"roundNumber":1}),
                1,
            )
            .await
            .unwrap();
            let mut tx = pool.begin().await.unwrap();
            let source = rows(&mut tx, 1).await.unwrap().remove(0);
            tx.commit().await.unwrap();
            let second_actor = "987c6081-0d1a-48e4-a1e0-4d16407be713";
            let second_character = "987c6081-0d1a-48e4-a1e0-4d16407be799";
            let mut c2 = c.clone();
            c2.id = second_character.into();
            sqlx::query("INSERT INTO characters(id,revision,payload_json,created_at,updated_at) VALUES(?,0,?,'test','test')").bind(second_character).bind(serde_json::to_string(&c2).unwrap()).execute(&pool).await.unwrap();
            sqlx::query("INSERT INTO encounter_actors(id,encounter_id,kind,display_name,initiative_value,initiative_tie_order,tt_current,hp_current,hp_max_current,prepared_snapshot_json,runtime_overrides_json) VALUES(?,1,'pc','Sojusznik',10,1,10,10,20,'{}','{}')")
                .bind(second_actor)
                .execute(&pool)
                .await
                .unwrap();
            let mut second = source.clone();
            second["id"] = json!("987c6081-0d1a-48e4-a1e0-4d16407be798");
            second["characterId"] = json!(second_character);
            second["actorId"] = json!(second_actor);
            sqlx::query("INSERT INTO character_participations(id,character_id,encounter_id,actor_id,revision,state,payload_json) VALUES(?,?,1,?,?,'active',?)").bind(second["id"].as_str()).bind(second_character).bind(second_actor).bind(second["revision"].as_i64()).bind(second.to_string()).execute(&pool).await.unwrap();
            let app = json!({"ruleId":"test:multi","label":"Premia sojuszników","page":75,"cost":"bonus","once":"none","confirmed":true,"targetId":source["id"],"targetRevision":source["revision"],"additionalTargets":[{"id":second["id"],"revision":second["revision"]}],"effect":{"id":"987c6081-0d1a-48e4-a1e0-4d16407be797","label":"Łaska Boża","target":"attackSave","checkDice":"1k4","modifier":0,"mode":"normal","remaining":1,"phase":"start","clockActorId":a,"nextRoll":false}});
            let mut m:Mutation=serde_json::from_value(json!({"operationId":"987c6081-0d1a-48e4-a1e0-4d16407be796","expectedRevision":0,"character":c,"kind":"condition","participationRevision":source["revision"],"conditionAction":{"type":"combatAbility","combatApplication":app}})).unwrap();
            let mut tx = pool.begin().await.unwrap();
            m.condition_action.as_mut().unwrap()["combatApplication"]["additionalTargets"][0]
                ["revision"] = json!(999);
            assert!(character_change(&mut tx, &m).await.is_err());
            tx.rollback().await.unwrap();
            let mut tx = pool.begin().await.unwrap();
            assert!(rows(&mut tx, 1)
                .await
                .unwrap()
                .iter()
                .all(|p| p["effects"].as_array().unwrap().is_empty()));
            m.condition_action.as_mut().unwrap()["combatApplication"]["additionalTargets"][0]
                ["revision"] = second["revision"].clone();
            character_change(&mut tx, &m).await.unwrap();
            let all = rows(&mut tx, 1).await.unwrap();
            assert!(all
                .iter()
                .all(|p| p["effects"].as_array().unwrap().len() == 1));
            assert_eq!(
                all.iter().find(|p| p["id"] == source["id"]).unwrap()["budget"]["bonus"],
                0
            );
            assert_eq!(
                all.iter().find(|p| p["id"] == second["id"]).unwrap()["budget"]["bonus"],
                1
            );
            tx.commit().await.unwrap();
        });
    }
    #[test]
    fn bleeding_and_death_save_have_separate_once_per_turn_limits() {
        let mut p = json!({"actorId":"hero","usedRound":[]});
        assert!(claim_health_turn(&mut p, "bleed", Some("enemy")).is_err());
        assert_eq!(p["usedRound"], json!([]));
        claim_health_turn(&mut p, "bleed", Some("hero")).unwrap();
        assert!(claim_health_turn(&mut p, "bleed", Some("hero")).is_err());
        claim_health_turn(&mut p, "deathSave", Some("hero")).unwrap();
        assert!(claim_health_turn(&mut p, "deathSave", Some("hero")).is_err());
        claim_health_turn(&mut p, "damage", Some("enemy")).unwrap();
    }
    #[test]
    fn links_retry_one_active_and_reset_preserve_character() {
        tauri::async_runtime::block_on(async {
            let (pool, c, a) = setup().await;
            let x = req(&c, &a, 1, 1, None, json!({"kind":"link"}));
            let linked = execute(&pool, x.clone()).await.unwrap();
            let mut second = req(
                &c,
                "987c6081-0d1a-48e4-a1e0-4d16407be712",
                2,
                1,
                None,
                json!({"kind":"link"}),
            );
            second.encounter_id = 2;
            execute(&pool, second).await.unwrap();
            advance(
                &pool,
                1,
                &a,
                json!({"currentTurnActorId":null,"roundNumber":1}),
                1,
            )
            .await
            .unwrap();
            assert!(advance(
                &pool,
                2,
                "987c6081-0d1a-48e4-a1e0-4d16407be712",
                json!({"currentTurnActorId":null,"roundNumber":1}),
                1
            )
            .await
            .unwrap_err()
            .contains("innej"));
            let mut tx = pool.begin().await.unwrap();
            assert!(ensure_inactive(&mut tx, 1).await.is_err());
            tx.rollback().await.unwrap();
            let spent = execute(
                &pool,
                req(
                    &c,
                    &a,
                    3,
                    2,
                    Some(1),
                    json!({"kind":"spend","cost":"action","label":"Ruch"}),
                ),
            )
            .await
            .unwrap();
            assert_eq!(spent["budget"]["action"], 0);
            assert_eq!(execute(&pool, x).await.unwrap(), linked);
            let raw: String = sqlx::query_scalar(
                "SELECT payload_json FROM character_participations WHERE encounter_id=1",
            )
            .fetch_one(&pool)
            .await
            .unwrap();
            assert_eq!(
                serde_json::from_str::<Value>(&raw).unwrap()["budget"]["action"],
                0
            );
            execute(&pool, req(&c, &a, 4, 3, Some(2), json!({"kind":"end"})))
                .await
                .unwrap();
            execute(
                &pool,
                req(
                    &c,
                    &a,
                    5,
                    4,
                    Some(3),
                    json!({"kind":"unlink","name":"Karta","hp":20,"hpMax":25,"tt":15}),
                ),
            )
            .await
            .unwrap();
            let snapshot: String =
                sqlx::query_scalar("SELECT reset_snapshot_json FROM encounter_actors WHERE id=?")
                    .bind(&a)
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            assert_eq!(
                serde_json::from_str::<Value>(&snapshot).unwrap()["hpCurrent"],
                20
            );
            let raw: String = sqlx::query_scalar("SELECT payload_json FROM characters")
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(serde_json::from_str::<Character>(&raw).unwrap(), c);
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
        });
    }
    #[test]
    fn saved_draft_can_finish_participation_after_publish_is_rejected() {
        tauri::async_runtime::block_on(async {
            for unlink_before_publish in [false, true] {
                let (pool, mut c, a) = setup().await;
                execute(&pool, req(&c, &a, 1, 1, None, json!({"kind":"link"})))
                    .await
                    .unwrap();
                advance(
                    &pool,
                    1,
                    &a,
                    json!({"currentTurnActorId":null,"roundNumber":1}),
                    1,
                )
                .await
                .unwrap();
                c.draft = c.sheet.clone();
                c.draft.as_mut().unwrap()["notes"] = json!("Szkic zachowany podczas walki");
                let draft: Mutation = serde_json::from_value(json!({
                    "operationId":"987c6081-0d1a-48e4-a1e0-000000000020",
                    "expectedRevision":c.revision,"character":c,"kind":"draft"
                }))
                .unwrap();
                c = super::super::save_to_pool(&pool, draft).await.unwrap();
                let saved_draft: String =
                    sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
                        .bind(&c.id)
                        .fetch_one(&pool)
                        .await
                        .unwrap();
                let mut tx = pool.begin().await.unwrap();
                let active = rows(&mut tx, 1).await.unwrap().remove(0);
                tx.commit().await.unwrap();
                assert_eq!(active["state"], "active");
                let effect_id = "987c6081-0d1a-48e4-a1e0-000000000021";
                let with_effect = execute(
                    &pool,
                    req(
                        &c,
                        &a,
                        2,
                        2,
                        active["revision"].as_i64(),
                        json!({"kind":"effect","effect":{
                            "id":effect_id,"label":"Premia do rozliczenia",
                            "remaining":1,"phase":"manual","target":"attack",
                            "modifier":1,"mode":"normal"
                        }}),
                    ),
                )
                .await
                .unwrap();
                let mut published = c.clone();
                published.sheet = published.draft.take();
                let publish: Mutation = serde_json::from_value(json!({
                    "operationId":"987c6081-0d1a-48e4-a1e0-000000000022",
                    "expectedRevision":c.revision,"character":published,"kind":"publish"
                }))
                .unwrap();
                assert_eq!(
                    super::super::save_to_pool(&pool, publish.clone())
                        .await
                        .unwrap_err(),
                    "Najpierw zakończ aktywny udział tej postaci w walce."
                );
                assert_eq!(
                    sqlx::query_scalar::<_, i64>(
                        "SELECT COUNT(*) FROM character_operations WHERE operation_id=?"
                    )
                    .bind(&publish.operation_id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                    0
                );
                assert_eq!(
                    execute(
                        &pool,
                        req(
                            &c,
                            &a,
                            3,
                            3,
                            with_effect["revision"].as_i64(),
                            json!({"kind":"end"})
                        ),
                    )
                    .await
                    .unwrap_err(),
                    "Rozlicz efekty czasowe przed zakończeniem udziału."
                );
                let cleared = execute(
                    &pool,
                    req(
                        &c,
                        &a,
                        4,
                        3,
                        with_effect["revision"].as_i64(),
                        json!({"kind":"removeEffect","id":effect_id}),
                    ),
                )
                .await
                .unwrap();
                assert!(cleared["effects"].as_array().unwrap().is_empty());
                assert_eq!(
                    execute(
                        &pool,
                        req(
                            &c,
                            &a,
                            7,
                            4,
                            cleared["revision"].as_i64(),
                            json!({"kind":"unlink","name":"Karta","hp":20,"hpMax":25,"tt":15}),
                        ),
                    )
                    .await
                    .unwrap_err(),
                    "Zakończ udział i rozlicz efekty przed odłączeniem."
                );
                let ended = execute(
                    &pool,
                    req(
                        &c,
                        &a,
                        5,
                        4,
                        cleared["revision"].as_i64(),
                        json!({"kind":"end"}),
                    ),
                )
                .await
                .unwrap();
                assert_eq!(ended["state"], "ended");
                if unlink_before_publish {
                    execute(
                        &pool,
                        req(
                            &c,
                            &a,
                            6,
                            5,
                            ended["revision"].as_i64(),
                            json!({"kind":"unlink","name":"Karta","hp":20,"hpMax":25,"tt":15}),
                        ),
                    )
                    .await
                    .unwrap();
                }
                assert_eq!(
                    sqlx::query_scalar::<_, String>(
                        "SELECT payload_json FROM characters WHERE id=?"
                    )
                    .bind(&c.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                    saved_draft
                );
                let saved = super::super::save_to_pool(&pool, publish).await.unwrap();
                assert_eq!(saved.sheet, c.draft);
                assert!(saved.draft.is_none());
                let mut tx = pool.begin().await.unwrap();
                let remaining = rows(&mut tx, 1).await.unwrap();
                tx.commit().await.unwrap();
                if unlink_before_publish {
                    assert!(remaining.is_empty());
                } else {
                    assert_eq!(remaining.len(), 1);
                    assert_eq!(remaining[0]["state"], "ended");
                }
            }
        });
    }
    #[test]
    fn failed_log_and_stale_requests_do_not_half_link() {
        tauri::async_runtime::block_on(async {
            let (pool, c, a) = setup().await;
            let x = req(&c, &a, 1, 1, None, json!({"kind":"link"}));
            sqlx::query("CREATE TRIGGER reject_link BEFORE INSERT ON combat_log BEGIN SELECT RAISE(ABORT,'test'); END").execute(&pool).await.unwrap();
            assert!(execute(&pool, x.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM character_participations")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            sqlx::query("DROP TRIGGER reject_link")
                .execute(&pool)
                .await
                .unwrap();
            execute(&pool, x).await.unwrap();
            assert!(
                execute(&pool, req(&c, &a, 2, 1, Some(0), json!({"kind":"end"})))
                    .await
                    .is_err()
            );
        });
    }
    #[test]
    fn journal_save_in_active_combat_does_not_spend_actions_or_advance_participation() {
        tauri::async_runtime::block_on(async {
            let (pool, mut c, a) = setup().await;
            execute(&pool, req(&c, &a, 1, 1, None, json!({"kind":"link"})))
                .await
                .unwrap();
            advance(
                &pool,
                1,
                &a,
                json!({"currentTurnActorId":null,"roundNumber":1}),
                1,
            )
            .await
            .unwrap();
            let before: String = sqlx::query_scalar(
                "SELECT payload_json FROM character_participations WHERE actor_id=?",
            )
            .bind(&a)
            .fetch_one(&pool)
            .await
            .unwrap();
            let logs: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            c.journal = Some(json!({"notes":"Nowa wskazówka","contacts":"","discoveries":"Tunel"}));
            let change: Mutation = serde_json::from_value(json!({"operationId":"987c6081-0d1a-48e4-a1e0-4d16407be798","expectedRevision":c.revision,"character":c,"kind":"draft"})).unwrap();
            let saved = super::super::save_to_pool(&pool, change).await.unwrap();
            assert_eq!(saved.sheet, c.sheet);
            assert!(saved.draft.is_none());
            let after: String = sqlx::query_scalar(
                "SELECT payload_json FROM character_participations WHERE actor_id=?",
            )
            .bind(&a)
            .fetch_one(&pool)
            .await
            .unwrap();
            assert_eq!(before, after);
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                logs
            );
        });
    }
}
