#[path = "bestiary.rs"]
pub mod bestiary;
#[path = "bestiary_seed.rs"]
pub mod bestiary_seed;
#[path = "capability.rs"]
mod capability;
#[path = "dice.rs"]
pub mod dice;
#[cfg(test)]
#[path = "difficulty_tests.rs"]
mod difficulty_tests;
#[path = "encounter_clear.rs"]
pub mod encounter_clear;
#[path = "equipment.rs"]
pub mod equipment;
#[path = "item.rs"]
pub(crate) mod item;
#[path = "combat_log.rs"]
mod log;
#[path = "machine_failure.rs"]
mod machine_failure;
#[path = "prepared_state.rs"]
mod prepared_state;
#[path = "statblock.rs"]
mod statblock;
#[cfg(test)]
#[path = "statblock_tests.rs"]
mod statblock_tests;
#[path = "status.rs"]
mod status;
use log::SaveReason;
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use std::collections::HashSet;
use tauri_plugin_sql::DbInstances;

#[derive(Debug, Deserialize, Serialize, Clone)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Actor {
    id: String,
    display_name: String,
    tt_current: i64,
    hp_current: i64,
    hp_max_current: i64,
    initiative_value: Option<i64>,
    initiative_tie_order: i64,
    statuses: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    effects: Vec<status::Status>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    enemy: Option<EnemyInstance>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    prepared: Option<Box<Actor>>,
}

#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Speed {
    mode: String,
    meters: f64,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct InjuryTrack {
    enabled: bool,
    initial_level: i64,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct InjuryState {
    enabled: bool,
    level: i64,
    death_warning: bool,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct EnemyTemplate {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    statblock: Option<statblock::Statblock>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    failure_threshold: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    sp: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    loadout: Option<item::Loadout>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    capabilities: Option<capability::Setup>,
    id: String,
    name: String,
    category: String,
    size: String,
    tt: i64,
    hp_max: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    injury_track: Option<InjuryTrack>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    cowardice_percent: Option<i64>,
    speeds: Vec<Speed>,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct EnemyInstance {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    statblock: Option<statblock::Statblock>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    failure_threshold: Option<i64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    sp: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    machine_failures: Option<Vec<machine_failure::Failure>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    loadout: Option<item::Loadout>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    capabilities: Option<capability::State>,
    template: EnemyTemplate,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    injury: Option<InjuryState>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    cowardice_percent: Option<i64>,
    speeds: Vec<Speed>,
}

fn valid_speeds(speeds: &[Speed]) -> bool {
    let mut modes = HashSet::new();
    speeds.iter().all(|s| {
        !s.mode.trim().is_empty()
            && modes.insert(s.mode.trim().to_lowercase())
            && s.meters.is_finite()
            && (0.0..=9_007_199_254_740_991.0).contains(&s.meters)
    })
}

#[derive(Debug, Deserialize, Serialize, Clone)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Combat {
    encounter_id: i64,
    revision: i64,
    round_number: i64,
    current_turn_actor_id: Option<String>,
    actors: Vec<Actor>,
}

fn validate(combat: &Combat) -> Result<(), String> {
    const MAX: i64 = 9_007_199_254_740_991;
    let nonnegative = |value: i64| (0..=MAX).contains(&value);
    if !(1..=5).contains(&combat.encounter_id)
        || !nonnegative(combat.revision)
        || combat.revision == MAX
        || !(1..=MAX).contains(&combat.round_number)
    {
        return Err("Niepoprawny slot, wersja lub numer rundy.".into());
    }
    let mut ids = HashSet::new();
    let mut order = HashSet::new();
    let mut effect_ids = HashSet::new();
    for pc in &combat.actors {
        if uuid::Uuid::parse_str(&pc.id).is_err()
            || !ids.insert(&pc.id)
            || !order.insert(pc.initiative_tie_order)
            || pc.display_name.trim().is_empty()
            || !nonnegative(pc.tt_current)
            || !nonnegative(pc.hp_current)
            || !(1..=MAX).contains(&pc.hp_max_current)
            || pc.hp_current > pc.hp_max_current
            || !nonnegative(pc.initiative_tie_order)
            || pc
                .initiative_value
                .is_some_and(|n| !(-MAX..=MAX).contains(&n))
            || pc.statuses.iter().any(|s| s.trim().is_empty())
        {
            return Err("Niepoprawne dane postaci. Sprawdź imię, TT, PW i inicjatywę.".into());
        }
        status::validate(&pc.effects)?;
        if pc.effects.iter().any(|s| !effect_ids.insert(&s.id)) {
            return Err("Powtórzony identyfikator statusu w potyczce.".into());
        }
        if let Some(enemy) = &pc.enemy {
            let t = &enemy.template;
            if t.statblock.as_ref().is_some_and(|s| !statblock::valid(s))
                || enemy
                    .statblock
                    .as_ref()
                    .is_some_and(|s| !statblock::valid(s))
            {
                return Err(
                    "Niepoprawny statblock: sprawdź cechy, końcowe RO, opisy i Próg Obrażeń."
                        .into(),
                );
            }
            let valid_sp = |n: f64| n.is_finite() && (0.0..=MAX as f64).contains(&n);
            if t.sp.is_some_and(|n| !valid_sp(n)) || enemy.sp.is_some_and(|n| !valid_sp(n)) {
                return Err("SP musi być liczbą nieujemną lub brakiem danych.".into());
            }
            if t.failure_threshold.is_some_and(|n| !nonnegative(n))
                || enemy.failure_threshold.is_some_and(|n| !nonnegative(n))
                || enemy.machine_failures.as_ref().is_some_and(|f| {
                    !machine_failure::valid(f) || (!f.is_empty() && t.category != "machine")
                })
            {
                return Err("Niepoprawny próg lub stan awarii maszyny.".into());
            }
            if t.loadout.as_ref().is_some_and(|l| !item::valid(l))
                || enemy.loadout.as_ref().is_some_and(|l| !item::valid(l))
            {
                return Err("Niepoprawny przedmiot lub profil broni.".into());
            }
            if uuid::Uuid::parse_str(&t.id).is_err()
                || t.name.trim().is_empty()
                || t.size.trim().is_empty()
                || ![
                    "human", "beast", "machine", "other", "mutant", "monster", "animal",
                ]
                .contains(&t.category.as_str())
                || !nonnegative(t.tt)
                || !(1..=MAX).contains(&t.hp_max)
                || !valid_speeds(&t.speeds)
                || !valid_speeds(&enemy.speeds)
                || t.capabilities
                    .as_ref()
                    .is_some_and(|s| !capability::valid_setup(s))
                || enemy
                    .capabilities
                    .as_ref()
                    .is_some_and(|s| !capability::valid_state(s))
                || t.cowardice_percent.is_some_and(|p| !(0..=100).contains(&p))
                || enemy
                    .cowardice_percent
                    .is_some_and(|p| !(0..=100).contains(&p))
                || t.injury_track.as_ref().is_some_and(|i| {
                    !(0..=4).contains(&i.initial_level) || (!i.enabled && i.initial_level != 0)
                })
                || enemy.injury.as_ref().is_some_and(|i| {
                    !(0..=4).contains(&i.level)
                        || (i.death_warning && i.level != 4)
                        || (!i.enabled && (i.level != 0 || i.death_warning))
                })
            {
                return Err("Niepoprawny szablon lub ruch przeciwnika.".into());
            }
        }
        if let Some(prepared) = &pc.prepared {
            if prepared.prepared.is_some()
                || prepared.id != pc.id
                || prepared.enemy.as_ref().map(|e| &e.template)
                    != pc.enemy.as_ref().map(|e| &e.template)
            {
                return Err(
                    "Stan przygotowany musi należeć do tej samej postaci i szablonu.".into(),
                );
            }
            validate(&Combat {
                encounter_id: combat.encounter_id,
                revision: combat.revision,
                round_number: 1,
                current_turn_actor_id: None,
                actors: vec![*prepared.clone()],
            })?;
        }
    }
    if let Some(id) = &combat.current_turn_actor_id {
        if !combat
            .actors
            .iter()
            .any(|pc| &pc.id == id && pc.initiative_value.is_some())
        {
            return Err("Aktywna postać musi należeć do potyczki i mieć inicjatywę.".into());
        }
    }
    Ok(())
}

#[cfg(test)]
pub async fn save_to_pool(pool: &SqlitePool, combat: Combat) -> Result<i64, String> {
    save_with_reason(pool, combat, SaveReason::Edit).await
}
pub async fn save_with_reason(
    pool: &SqlitePool,
    combat: Combat,
    reason: SaveReason,
) -> Result<i64, String> {
    validate(&combat)?;
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    // Acquire the write lock and reject stale windows before changing any actors.
    let changed = sqlx::query("UPDATE encounters SET combat_revision = combat_revision + 1 WHERE id = ? AND combat_revision = ?")
        .bind(combat.encounter_id).bind(combat.revision).execute(&mut *tx).await.map_err(|e| e.to_string())?;
    if changed.rows_affected() != 1 {
        return Err("Potyczka została zmieniona w innym oknie. Zachowano szkic; skopiuj niezapisane dane przed ponownym otwarciem aplikacji.".into());
    }
    let before = log::read_combat(&mut tx, combat.encounter_id).await?;
    prepared_state::validate_transition(&before, &combat, reason)?;
    crate::character::participation::combat_change(
        &mut tx,
        &serde_json::to_value(&before).map_err(|e| e.to_string())?,
        &serde_json::to_value(&combat).map_err(|e| e.to_string())?,
        matches!(reason, SaveReason::Advance),
        matches!(reason, SaveReason::Reset),
    )
    .await?;
    if reason == SaveReason::ClearLog {
        if !log::same_for_clear(&before, &combat) {
            return Err("Zapisz zmiany walki przed wyczyszczeniem logu.".into());
        }
        sqlx::query("DELETE FROM combat_log WHERE encounter_id = ?")
            .bind(combat.encounter_id)
            .execute(&mut *tx)
            .await
            .map_err(|e| e.to_string())?;
        tx.commit().await.map_err(|e| e.to_string())?;
        return Ok(combat.revision + 1);
    }
    for pc in &combat.actors {
        let mut original = pc.clone();
        original.prepared = None;
        let prepared = serde_json::to_string(&original).map_err(|e| e.to_string())?;
        let reset = pc
            .prepared
            .as_ref()
            .map(serde_json::to_string)
            .transpose()
            .map_err(|e| e.to_string())?;
        let mut runtime = serde_json::json!({"manualStatuses": pc.statuses});
        let (kind, template_id) = if let Some(enemy) = &pc.enemy {
            let t = &enemy.template;
            bestiary::ensure_instance_template(&mut tx, pc, t).await?;
            runtime["enemy"] = serde_json::to_value(enemy).map_err(|e| e.to_string())?;
            ("enemy", Some(&t.id))
        } else {
            ("pc", None)
        };
        let changed = sqlx::query("INSERT INTO encounter_actors (id, encounter_id, kind, template_id, display_name, tt_current, hp_current, hp_max_current, initiative_value, initiative_tie_order, prepared_snapshot_json, runtime_overrides_json, reset_snapshot_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET display_name = excluded.display_name, tt_current = excluded.tt_current, hp_current = excluded.hp_current, hp_max_current = excluded.hp_max_current, initiative_value = excluded.initiative_value, initiative_tie_order = excluded.initiative_tie_order, runtime_overrides_json = excluded.runtime_overrides_json, reset_snapshot_json = COALESCE(excluded.reset_snapshot_json, encounter_actors.reset_snapshot_json), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE encounter_actors.encounter_id = excluded.encounter_id AND encounter_actors.kind = excluded.kind AND encounter_actors.template_id IS excluded.template_id")
            .bind(&pc.id).bind(combat.encounter_id).bind(kind).bind(template_id).bind(&pc.display_name)
            .bind(pc.tt_current).bind(pc.hp_current).bind(pc.hp_max_current)
            .bind(pc.initiative_value).bind(pc.initiative_tie_order)
            .bind(prepared).bind(runtime.to_string()).bind(reset).execute(&mut *tx).await.map_err(|e| e.to_string())?;
        if changed.rows_affected() != 1 {
            return Err(
                "Identyfikator postaci jest już używany w innej potyczce lub z innym szablonem."
                    .into(),
            );
        }
    }
    for pc in &combat.actors {
        status::save(&mut tx, &pc.id, &pc.effects).await?;
    }
    sqlx::query("UPDATE encounters SET round_number = ?, current_turn_actor_id = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
        .bind(combat.round_number).bind(&combat.current_turn_actor_id).bind(combat.encounter_id)
        .execute(&mut *tx).await.map_err(|e| e.to_string())?;
    let ids = serde_json::to_string(&combat.actors.iter().map(|pc| &pc.id).collect::<Vec<_>>())
        .map_err(|e| e.to_string())?;
    sqlx::query("DELETE FROM encounter_actors WHERE encounter_id = ? AND id NOT IN (SELECT value FROM json_each(?))")
        .bind(combat.encounter_id).bind(ids).execute(&mut *tx).await.map_err(|e| e.to_string())?;
    log::append(
        &mut tx,
        combat.encounter_id,
        log::changes(&before, &combat, reason),
    )
    .await?;
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(combat.revision + 1)
}

#[tauri::command]
pub async fn save_combat(
    databases: tauri::State<'_, DbInstances>,
    combat: Combat,
    reason: Option<SaveReason>,
) -> Result<i64, String> {
    let pool = {
        let instances = databases.0.read().await;
        let Some(tauri_plugin_sql::DbPool::Sqlite(pool)) =
            instances.get("sqlite:combat-tracker.db")
        else {
            return Err("Baza nie jest jeszcze otwarta.".into());
        };
        pool.clone()
    };
    save_with_reason(&pool, combat, reason.unwrap_or_default()).await
}

#[cfg(test)]
mod tests {
    use super::*;
    use sqlx::sqlite::SqlitePoolOptions;

    pub(super) async fn database() -> SqlitePool {
        let pool = SqlitePoolOptions::new()
            .max_connections(1)
            .connect("sqlite::memory:")
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/001_initial.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query(
            "UPDATE encounters SET name = 'Most', notes = 'Zażółć\nDrugi wiersz' WHERE id = 1",
        )
        .execute(&pool)
        .await
        .unwrap();
        sqlx::raw_sql(include_str!("../migrations/002_pc_initiative.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/003_enemy_instances.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/004_combat_log.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/005_actor_statuses.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/006_bestiary.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/007_bestiary_seed.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/008_enemy_categories.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/011_characters.sql"))
            .execute(&pool)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!(
            "../migrations/014_character_participation.sql"
        ))
        .execute(&pool)
        .await
        .unwrap();
        pool
    }
    pub(super) async fn reset_saved(pool: &SqlitePool, id: i64) -> Combat {
        let mut tx = pool.begin().await.unwrap();
        let mut state = log::read_combat(&mut tx, id).await.unwrap();
        state.actors.sort_by(|a, b| {
            a.prepared
                .as_ref()
                .unwrap()
                .initiative_tie_order
                .cmp(&b.prepared.as_ref().unwrap().initiative_tie_order)
                .then(a.id.cmp(&b.id))
        });
        for (i, actor) in state.actors.iter_mut().enumerate() {
            let prepared = actor.prepared.clone().unwrap();
            *actor = *prepared.clone();
            actor.prepared = Some(prepared);
            actor.initiative_tie_order = i as i64;
        }
        state.round_number = 1;
        state.current_turn_actor_id = None;
        state
    }
    pub(super) fn prepare_all(state: &mut Combat) {
        for actor in &mut state.actors {
            let mut copy = actor.clone();
            copy.prepared = None;
            actor.prepared = Some(Box::new(copy));
        }
    }
    fn sample() -> Combat {
        Combat {
            encounter_id: 1,
            revision: 0,
            round_number: 1,
            current_turn_actor_id: Some("00000000-0000-4000-8000-000000000001".into()),
            actors: vec![Actor {
                id: "00000000-0000-4000-8000-000000000001".into(),
                display_name: "Łowca '); DROP TABLE encounters; --".into(),
                tt_current: 14,
                hp_current: 20,
                hp_max_current: 20,
                initiative_value: Some(12),
                initiative_tie_order: 0,
                effects: vec![],
                statuses: vec!["Przerażenie".into()],
                enemy: None,
                prepared: None,
            }],
        }
    }
    #[test]
    fn migration_and_transaction_preserve_slot_data_and_prepared_snapshot() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = sample();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let before: String =
                sqlx::query_scalar("SELECT prepared_snapshot_json FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            state.actors[0].hp_current = 0;
            state.actors[0].statuses.push("Nieprzytomność".into());
            state.round_number = 2;
            assert_eq!(save_to_pool(&pool, state.clone()).await.unwrap(), 2);
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT hp_current FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT notes FROM encounters WHERE id = 1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                "Zażółć\nDrugi wiersz"
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 2")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert!(save_to_pool(&pool, state)
                .await
                .unwrap_err()
                .contains("innym oknie"));
            pool.close().await;
        });
    }
    #[test]
    fn database_failure_rolls_back_actors_round_and_revision() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            sqlx::raw_sql("CREATE TRIGGER fail_save BEFORE UPDATE OF round_number ON encounters BEGIN SELECT RAISE(ABORT, 'simulated full disk'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, sample()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            pool.close().await;
        });
    }
    #[test]
    fn actor_cannot_move_between_slots_and_invalid_active_actor_is_rejected() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            save_to_pool(&pool, sample()).await.unwrap();
            let mut other = sample();
            other.encounter_id = 2;
            assert!(save_to_pool(&pool, other).await.is_err());
            let mut invalid = sample();
            invalid.current_turn_actor_id = Some("absent".into());
            assert!(save_to_pool(&pool, invalid).await.is_err());
            let mut invalid = sample();
            invalid.actors[0].hp_current = 21;
            assert!(save_to_pool(&pool, invalid).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 2")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            pool.close().await;
        });
    }
    #[test]
    fn removal_clears_current_actor_and_cannot_touch_other_slots() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = sample();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            state.actors.clear();
            state.current_turn_actor_id = None;
            save_to_pool(&pool, state).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, Option<String>>(
                    "SELECT current_turn_actor_id FROM encounters WHERE id = 1"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                None
            );
            pool.close().await;
        });
    }
    pub(super) fn enemy_state() -> Combat {
        let mut state = sample();
        let template = EnemyTemplate {
            statblock: None,
            failure_threshold: None,
            sp: None,
            loadout: None,
            capabilities: None,
            id: "00000000-0000-4000-8000-000000000099".into(),
            name: "Żuk".into(),
            category: "machine".into(),
            size: "Średni".into(),
            tt: 16,
            hp_max: 30,
            injury_track: None,
            cowardice_percent: None,
            speeds: vec![
                Speed {
                    mode: "Chód".into(),
                    meters: 9.0,
                },
                Speed {
                    mode: "Lot".into(),
                    meters: 4.5,
                },
            ],
        };
        for i in 2..=4 {
            let mut actor = state.actors[0].clone();
            actor.id = format!("00000000-0000-4000-8000-{:012}", i);
            actor.display_name = format!("Żuk {}", i);
            actor.initiative_tie_order = i;
            actor.initiative_value = Some(i);
            actor.tt_current = template.tt;
            actor.hp_current = template.hp_max;
            actor.hp_max_current = template.hp_max;
            actor.enemy = Some(EnemyInstance {
                statblock: None,
                machine_failures: None,
                failure_threshold: None,
                sp: None,
                loadout: None,
                capabilities: None,
                template: template.clone(),
                injury: None,
                cowardice_percent: None,
                speeds: template.speeds.clone(),
            });
            actor.prepared = Some(Box::new(actor.clone()));
            state.actors.push(actor);
        }
        state
    }
    #[test]
    fn enemy_runtime_and_reset_preserve_template_siblings_and_original_snapshot() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let before: String = sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap();
            let birth: String = sqlx::query_scalar(
                "SELECT prepared_snapshot_json FROM encounter_actors WHERE id = ?",
            )
            .bind(&state.actors[1].id)
            .fetch_one(&pool)
            .await
            .unwrap();
            state.actors[1].hp_current = 24;
            state.actors[1].enemy.as_mut().unwrap().speeds[0].meters = 7.5;
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut baseline = state.actors[1].clone();
            baseline.prepared = None;
            state.actors[1].prepared = Some(Box::new(baseline));
            prepare_all(&mut state);
            state.revision = save_with_reason(&pool, state.clone(), SaveReason::Prepare)
                .await
                .unwrap();
            state.actors[1].hp_current = 0;
            state.actors[1].enemy.as_mut().unwrap().speeds[0].meters = 0.0;
            state.round_number = 4;
            state.current_turn_actor_id = Some(state.actors[1].id.clone());
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let reset: String =
                sqlx::query_scalar("SELECT reset_snapshot_json FROM encounter_actors WHERE id = ?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let restored: Actor = serde_json::from_str(&reset).unwrap();
            assert_eq!(restored.hp_current, 24);
            assert_eq!(restored.enemy.as_ref().unwrap().speeds[0].meters, 7.5);
            state.actors[1] = restored.clone();
            state.actors[1].prepared = Some(Box::new(restored));
            state.round_number = 1;
            state.current_turn_actor_id = None;
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT hp_current FROM encounter_actors WHERE id = ?"
                )
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                24
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT hp_current FROM encounter_actors WHERE id = ?"
                )
                .bind(&state.actors[2].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                30
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT statblock_json FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors WHERE id = ?"
                )
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                birth
            );
            state.actors.remove(1);
            save_to_pool(&pool, state).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                3
            );
            pool.close().await;
        });
    }
    #[test]
    fn enemy_template_collisions_cross_slot_ids_and_foreign_baselines_roll_back() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut collision = state.clone();
            collision.actors[1].enemy.as_mut().unwrap().template.name = "Nadpisany".into();
            collision.actors[1].prepared = None;
            assert!(save_to_pool(&pool, collision)
                .await
                .unwrap_err()
                .contains("Szablon"));
            let mut foreign = state.clone();
            foreign.encounter_id = 2;
            foreign.revision = 0;
            assert!(save_to_pool(&pool, foreign).await.is_err());
            let mut invalid = state.clone();
            invalid.actors[1].prepared.as_mut().unwrap().id = state.actors[2].id.clone();
            assert!(save_to_pool(&pool, invalid).await.is_err());
            let mut invalid = state.clone();
            invalid.actors[1].enemy.as_mut().unwrap().speeds[0].meters = -1.0;
            assert!(save_to_pool(&pool, invalid).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 2")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            pool.close().await;
        });
    }
    #[test]
    fn failed_enemy_write_rolls_back_new_templates_and_prepared_baseline_changes() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let before: String =
                sqlx::query_scalar("SELECT reset_snapshot_json FROM encounter_actors WHERE id = ?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            state.actors[1].prepared.as_mut().unwrap().hp_current = 1;
            let mut new_actor = state.actors[2].clone();
            new_actor.id = "00000000-0000-4000-8000-000000000088".into();
            new_actor.initiative_tie_order = 88;
            new_actor.prepared = None;
            new_actor.enemy.as_mut().unwrap().template.id =
                "00000000-0000-4000-8000-000000000077".into();
            state.actors.push(new_actor);
            sqlx::raw_sql("CREATE TRIGGER fail_save BEFORE UPDATE OF round_number ON encounters BEGIN SELECT RAISE(ABORT, 'simulated full disk'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, state).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT reset_snapshot_json FROM encounter_actors WHERE id = ?"
                )
                .bind(&enemy_state().actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                4
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id = 1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    #[test]
    fn failed_log_insert_rolls_back_combat_and_does_not_duplicate_on_retry() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = sample();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            state.actors[0].hp_current = 3;
            state.round_number = 2;
            sqlx::raw_sql("CREATE TRIGGER fail_log BEFORE INSERT ON combat_log BEGIN SELECT RAISE(ABORT, 'log disk error'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, state.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT hp_current FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                20
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                count
            );
            sqlx::raw_sql("DROP TRIGGER fail_log")
                .execute(&pool)
                .await
                .unwrap();
            save_to_pool(&pool, state.clone()).await.unwrap();
            let final_count: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            assert!(final_count > count);
            assert!(save_to_pool(&pool, state).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                final_count
            );
            pool.close().await;
        });
    }
    #[test]
    fn clear_only_removes_one_slots_log_and_preserves_actors_notes_turn_and_snapshots() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = sample();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut other = sample();
            other.encounter_id = 2;
            other.actors[0].id = "00000000-0000-4000-8000-000000000088".into();
            other.current_turn_actor_id = Some(other.actors[0].id.clone());
            save_to_pool(&pool, other).await.unwrap();
            let before:(String,String,String,String)=sqlx::query_as("SELECT display_name,prepared_snapshot_json,runtime_overrides_json,updated_at FROM encounter_actors WHERE encounter_id=1").fetch_one(&pool).await.unwrap();
            let notes: String = sqlx::query_scalar("SELECT notes FROM encounters WHERE id=1")
                .fetch_one(&pool)
                .await
                .unwrap();
            let count_other: i64 =
                sqlx::query_scalar("SELECT count(*) FROM combat_log WHERE encounter_id=2")
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let mut unsaved = state.clone();
            unsaved.actors[0].hp_current = 1;
            assert!(save_with_reason(&pool, unsaved, SaveReason::ClearLog)
                .await
                .is_err());
            state.revision = save_with_reason(&pool, state.clone(), SaveReason::ClearLog)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE encounter_id=1"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE encounter_id=2"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                count_other
            );
            assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT display_name,prepared_snapshot_json,runtime_overrides_json,updated_at FROM encounter_actors WHERE encounter_id=1").fetch_one(&pool).await.unwrap(),before);
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT notes FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                notes
            );
            assert_eq!(
                sqlx::query_scalar::<_, Option<String>>(
                    "SELECT current_turn_actor_id FROM encounters WHERE id=1"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                state.current_turn_actor_id
            );
            state.actors[0].hp_current = 19;
            save_to_pool(&pool, state).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT event_type FROM combat_log WHERE encounter_id=1"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                "hp_changed"
            );
            pool.close().await;
        });
    }
    #[test]
    fn failure_while_clearing_preserves_log_and_revision() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = sample();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            sqlx::raw_sql("CREATE TRIGGER fail_clear BEFORE DELETE ON combat_log BEGIN SELECT RAISE(ABORT, 'cannot clear'); END;").execute(&pool).await.unwrap();
            assert!(save_with_reason(&pool, state, SaveReason::ClearLog)
                .await
                .is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                count
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    fn effect(key: &str) -> status::Status {
        serde_json::from_value(serde_json::json!({"id":"00000000-0000-4000-8000-000000000077","systemKey":key,"name":if key=="burning"{"Podpalenie"}else{"Wyczerpanie"},"description":"Opis\nDruga linia","sourceText":"Źródło","durationType":"manual","durationValue":null,"remaining":null,"level":if key=="exhaustion"{Some(2)}else{None}})).unwrap()
    }
    #[test]
    fn structured_status_and_expiry_log_are_atomic_with_turn_and_prepared_state() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut c = sample();
            c.actors[0].effects = vec![effect("burning")];
            let mut baseline = c.actors[0].clone();
            baseline.prepared = None;
            c.actors[0].prepared = Some(Box::new(baseline));
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let original: String =
                sqlx::query_scalar("SELECT prepared_snapshot_json FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            c.actors[0].effects.clear();
            c.round_number = 2;
            sqlx::raw_sql("CREATE TRIGGER broken_log BEFORE INSERT ON combat_log BEGIN SELECT RAISE(ABORT,'disk'); END;").execute(&pool).await.unwrap();
            assert!(save_with_reason(&pool, c.clone(), SaveReason::Advance)
                .await
                .is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM actor_statuses")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT round_number FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            sqlx::raw_sql("DROP TRIGGER broken_log")
                .execute(&pool)
                .await
                .unwrap();
            c.revision = save_with_reason(&pool, c.clone(), SaveReason::Advance)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM actor_statuses")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='status_expired'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                original
            );
            c.actors[0].effects = c.actors[0].prepared.as_ref().unwrap().effects.clone();
            c = reset_saved(&pool, 1).await;
            c.revision = save_with_reason(&pool, c.clone(), SaveReason::Reset)
                .await
                .unwrap();
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            assert!(count > 1);
            save_with_reason(&pool, c, SaveReason::ClearLog)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM actor_statuses")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    #[test]
    fn status_write_failure_and_cross_actor_id_cannot_partially_update_combat() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut c = sample();
            c.actors[0].effects = vec![effect("exhaustion")];
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let mut other = sample();
            other.encounter_id = 2;
            other.actors[0].id = "00000000-0000-4000-8000-000000000009".into();
            other.current_turn_actor_id = Some(other.actors[0].id.clone());
            other.actors[0].effects = c.actors[0].effects.clone();
            assert!(save_to_pool(&pool, other).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM encounter_actors WHERE encounter_id=2"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                0
            );
            sqlx::raw_sql("CREATE TRIGGER broken_status BEFORE UPDATE ON actor_statuses BEGIN SELECT RAISE(ABORT,'disk'); END;").execute(&pool).await.unwrap();
            c.actors[0].hp_current = 1;
            c.actors[0].effects[0].level = Some(3);
            assert!(save_to_pool(&pool, c.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT hp_current FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                20
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT json_extract(status_json,'$.level') FROM actor_statuses"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                2
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    #[test]
    fn status_validation_and_burning_reminders_do_not_roll_or_change_hp() {
        let mut c = sample();
        let burn = effect("burning");
        c.actors[0].effects = vec![
            burn.clone(),
            status::Status {
                id: "00000000-0000-4000-8000-000000000078".into(),
                ..burn.clone()
            },
        ];
        assert!(validate(&c).is_ok());
        let entries = log::changes(&c, &c, SaveReason::Advance);
        assert_eq!(
            entries
                .iter()
                .filter(|e| e.kind == "burning_reminder")
                .count(),
            1
        );
        assert!(log::changes(&c, &c, SaveReason::Edit).is_empty());
        assert_eq!(c.actors[0].hp_current, 20);
        let mut expired = c.clone();
        expired.actors[0].effects.clear();
        assert!(!log::changes(&c, &expired, SaveReason::Advance)
            .iter()
            .any(|e| e.kind == "burning_reminder"));
        c.actors[0].effects = vec![effect("exhaustion")];
        c.actors[0].effects[0].level = Some(7);
        assert!(validate(&c).is_err());
        c.actors[0].effects = vec![burn.clone()];
        c.actors[0].effects[0].duration_type = "rounds".into();
        assert!(validate(&c).is_err());
        c.actors[0].effects = vec![burn.clone(), burn];
        assert!(validate(&c).is_err());
    }
    #[test]
    fn injury_cowardice_exhaustion_and_history_commit_atomically_on_legacy_templates() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut c = enemy_state();
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let old_template: String =
                sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let id = c.actors[1].id.clone();
            let before: String = sqlx::query_scalar(
                "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?",
            )
            .bind(&id)
            .fetch_one(&pool)
            .await
            .unwrap();
            c.actors[1].enemy.as_mut().unwrap().injury = Some(InjuryState {
                enabled: true,
                level: 4,
                death_warning: false,
            });
            c.actors[1].enemy.as_mut().unwrap().cowardice_percent = Some(50);
            c.actors[1].hp_max_current = 88;
            c.actors[1].hp_current = 44;
            c.actors[1].effects = vec![effect("exhaustion")];
            sqlx::raw_sql("CREATE TRIGGER fail_injury_log BEFORE INSERT ON combat_log WHEN NEW.event_type='injury_changed' BEGIN SELECT RAISE(ABORT,'disk'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, c.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?"
                )
                .bind(&id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM actor_statuses")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            sqlx::raw_sql("DROP TRIGGER fail_injury_log")
                .execute(&pool)
                .await
                .unwrap();
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let mut tx = pool.begin().await.unwrap();
            let loaded = log::read_combat(&mut tx, 1).await.unwrap();
            tx.commit().await.unwrap();
            let restored = loaded.actors.iter().find(|a| a.id == id).unwrap();
            assert_eq!(restored.enemy, c.actors[1].enemy);
            assert_eq!(restored.effects, c.actors[1].effects);
            assert_eq!(
                restored
                    .prepared
                    .as_ref()
                    .unwrap()
                    .enemy
                    .as_ref()
                    .unwrap()
                    .injury,
                None
            );
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='cowardice_warning'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            c.actors[1].hp_current = 45;
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            c.actors[1].hp_current = 44;
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='cowardice_warning'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                2
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT statblock_json FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                old_template
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounter_actors")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                4
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
            c.actors[1] = *c.actors[1].prepared.clone().unwrap();
            c = reset_saved(&pool, 1).await;
            save_with_reason(&pool, c, SaveReason::Reset).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM actor_statuses")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            pool.close().await;
        });
    }
    #[test]
    fn validates_injury_state_threshold_and_new_template_identity() {
        let mut c = enemy_state();
        for invalid in [
            InjuryState {
                enabled: true,
                level: 5,
                death_warning: true,
            },
            InjuryState {
                enabled: false,
                level: 1,
                death_warning: false,
            },
            InjuryState {
                enabled: true,
                level: 3,
                death_warning: true,
            },
        ] {
            c.actors[1].enemy.as_mut().unwrap().injury = Some(invalid);
            assert!(validate(&c).is_err());
        }
        c.actors[1].enemy.as_mut().unwrap().injury = None;
        c.actors[1].enemy.as_mut().unwrap().cowardice_percent = Some(101);
        assert!(validate(&c).is_err());
        c.actors[1].enemy.as_mut().unwrap().cowardice_percent = Some(0);
        assert!(validate(&c).is_ok());
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            for actor in c.actors.iter_mut().skip(1) {
                actor.enemy.as_mut().unwrap().template.injury_track = Some(InjuryTrack {
                    enabled: true,
                    initial_level: 3,
                });
                actor.enemy.as_mut().unwrap().template.cowardice_percent = Some(50);
                actor.prepared = None;
            }
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            // Re-saving a new optional template must retain the same canonical statblock.
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            c.actors[1]
                .enemy
                .as_mut()
                .unwrap()
                .template
                .cowardice_percent = Some(10);
            assert!(save_to_pool(&pool, c)
                .await
                .unwrap_err()
                .contains("Szablon"));
            pool.close().await;
        });
    }
    #[test]
    fn unlimited_reactions_persist_and_log_each_use_without_spending_budget() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut c = enemy_state();
            let mut cap = capability_state();
            cap.unlimited_reactions = Some(true);
            c.actors[1].enemy.as_mut().unwrap().capabilities = Some(cap);
            c.actors[1].prepared = None;
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let id = c.actors[1].id.clone();
            for n in 1..=3 {
                let cap = c.actors[1]
                    .enemy
                    .as_mut()
                    .unwrap()
                    .capabilities
                    .as_mut()
                    .unwrap();
                cap.usage_number = n;
                cap.last_use = Some(capability::LastUse {
                    name: "Reakcja".into(),
                    kind: "reaction".into(),
                    r#override: false,
                });
                c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            }
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='action_used'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                3
            );
            let mut tx = pool.begin().await.unwrap();
            let loaded = log::read_combat(&mut tx, 1).await.unwrap();
            tx.commit().await.unwrap();
            let actual = loaded.actors.iter().find(|a| a.id == id).unwrap();
            assert_eq!(actual.enemy, c.actors[1].enemy);
            assert_eq!(
                actual
                    .enemy
                    .as_ref()
                    .unwrap()
                    .capabilities
                    .as_ref()
                    .unwrap()
                    .budget
                    .reaction,
                1
            );
            pool.close().await;
        });
    }
    fn capability_state() -> capability::State {
        serde_json::from_value(serde_json::json!({"resources":[{"id":"00000000-0000-4000-8000-000000000091","name":"Impuls","maxValue":3,"currentValue":3,"refreshRule":"round"}],"abilities":[{"id":"00000000-0000-4000-8000-000000000092","name":"Żądło","description":"Zażółć\nMG rozstrzyga","kind":"bonus","legendaryCost":1,"resourceId":"00000000-0000-4000-8000-000000000091","resourceCost":2}],"legendaryMax":3,"budget":{"action":1,"bonus":1,"reaction":1,"legendary":3},"usageNumber":0,"lastUse":null})).unwrap()
    }
    #[test]
    fn resources_action_budget_and_log_are_atomic_and_reset_does_not_fake_a_new_use() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut c = enemy_state();
            c.actors[1].enemy.as_mut().unwrap().capabilities = Some(capability_state());
            c.actors[1].prepared = Some(Box::new(c.actors[1].clone()));
            c.actors[1].prepared.as_mut().unwrap().prepared = None;
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let id = c.actors[1].id.clone();
            let before: String = sqlx::query_scalar(
                "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?",
            )
            .bind(&id)
            .fetch_one(&pool)
            .await
            .unwrap();
            let cap = c.actors[1]
                .enemy
                .as_mut()
                .unwrap()
                .capabilities
                .as_mut()
                .unwrap();
            cap.resources[0].current_value = 1;
            cap.budget.bonus = 0;
            cap.usage_number = 1;
            cap.last_use = Some(capability::LastUse {
                name: "Żądło".into(),
                kind: "bonus".into(),
                r#override: false,
            });
            sqlx::raw_sql("CREATE TRIGGER fail_action BEFORE INSERT ON combat_log WHEN NEW.event_type='action_used' BEGIN SELECT RAISE(ABORT,'disk'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, c.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?"
                )
                .bind(&id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                before
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT combat_revision FROM encounters WHERE id=1")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            sqlx::raw_sql("DROP TRIGGER fail_action")
                .execute(&pool)
                .await
                .unwrap();
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            let mut tx = pool.begin().await.unwrap();
            let loaded = log::read_combat(&mut tx, 1).await.unwrap();
            tx.commit().await.unwrap();
            assert_eq!(
                loaded.actors.iter().find(|a| a.id == id).unwrap().enemy,
                c.actors[1].enemy
            );
            c.revision = save_to_pool(&pool, c.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='action_used'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            c.actors[1] = *c.actors[1].prepared.clone().unwrap();
            c = reset_saved(&pool, 1).await;
            c.revision = save_with_reason(&pool, c.clone(), SaveReason::Reset)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='action_used'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            c.revision = save_with_reason(&pool, c.clone(), SaveReason::NewDay)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='resources_refreshed'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
            pool.close().await;
        });
    }
    #[test]
    fn rejects_bad_resource_links_ranges_duplicates_and_capability_template_collisions() {
        let c = capability_state();
        assert!(capability::valid_state(&c));
        let mut bad = c.clone();
        bad.resources[0].current_value = 4;
        assert!(!capability::valid_state(&bad));
        bad = c.clone();
        bad.abilities[0].resource_id = Some("missing".into());
        assert!(!capability::valid_state(&bad));
        bad = c.clone();
        bad.budget.reaction = 2;
        assert!(!capability::valid_state(&bad));
        bad = c.clone();
        bad.resources.push(c.resources[0].clone());
        assert!(!capability::valid_state(&bad));
        bad = c.clone();
        bad.usage_number = 1;
        assert!(!capability::valid_state(&bad));
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut combat = enemy_state();
            for a in combat.actors.iter_mut().skip(1) {
                a.enemy.as_mut().unwrap().template.capabilities = Some(capability::Setup {
                    resources: vec![],
                    abilities: vec![],
                    legendary_max: 3,
                    unlimited_reactions: None,
                });
                a.prepared = None;
            }
            combat.revision = save_to_pool(&pool, combat.clone()).await.unwrap();
            combat.revision = save_to_pool(&pool, combat.clone()).await.unwrap();
            combat.actors[1]
                .enemy
                .as_mut()
                .unwrap()
                .template
                .capabilities
                .as_mut()
                .unwrap()
                .legendary_max = 4;
            assert!(save_to_pool(&pool, combat)
                .await
                .unwrap_err()
                .contains("Szablon"));
            pool.close().await;
        });
    }
}
