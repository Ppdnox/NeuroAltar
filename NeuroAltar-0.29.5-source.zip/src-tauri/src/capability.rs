use serde::{Deserialize, Serialize};
use std::collections::HashSet;
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ResourceDefinition {
    pub id: String,
    pub name: String,
    pub max_value: i64,
    pub refresh_rule: String,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Resource {
    pub id: String,
    pub name: String,
    pub max_value: i64,
    pub current_value: i64,
    pub refresh_rule: String,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Ability {
    pub id: String,
    pub name: String,
    pub description: String,
    pub kind: String,
    pub legendary_cost: i64,
    pub resource_id: Option<String>,
    pub resource_cost: i64,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Setup {
    pub resources: Vec<ResourceDefinition>,
    pub abilities: Vec<Ability>,
    pub legendary_max: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub unlimited_reactions: Option<bool>,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Budget {
    pub action: i64,
    pub bonus: i64,
    pub reaction: i64,
    pub legendary: i64,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct LastUse {
    pub name: String,
    pub kind: String,
    pub r#override: bool,
}
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct State {
    pub resources: Vec<Resource>,
    pub abilities: Vec<Ability>,
    pub legendary_max: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub unlimited_reactions: Option<bool>,
    pub budget: Budget,
    pub usage_number: i64,
    pub last_use: Option<LastUse>,
}
fn kind(k: &str) -> bool {
    ["action", "bonus", "reaction", "legendary"].contains(&k)
}
pub fn valid_setup(s: &Setup) -> bool {
    let mut ids = HashSet::new();
    let mut actions = HashSet::new();
    (0..=999).contains(&s.legendary_max)
        && s.resources.iter().all(|r| {
            uuid::Uuid::parse_str(&r.id).is_ok()
                && ids.insert(&r.id)
                && !r.name.trim().is_empty()
                && (1..=999).contains(&r.max_value)
                && ["round", "encounter", "day", "manual"].contains(&r.refresh_rule.as_str())
        })
        && s.abilities.iter().all(|a| {
            uuid::Uuid::parse_str(&a.id).is_ok()
                && actions.insert(&a.id)
                && !a.name.trim().is_empty()
                && kind(&a.kind)
                && (1..=999).contains(&a.legendary_cost)
                && (1..=999).contains(&a.resource_cost)
                && (if a.kind == "legendary" {
                    a.legendary_cost <= s.legendary_max
                } else {
                    a.legendary_cost == 1
                })
                && a.resource_id.as_ref().is_none_or(|id| {
                    s.resources
                        .iter()
                        .any(|r| &r.id == id && r.max_value >= a.resource_cost)
                })
        })
}
pub fn valid_state(s: &State) -> bool {
    valid_setup(&Setup {
        resources: s
            .resources
            .iter()
            .map(|r| ResourceDefinition {
                id: r.id.clone(),
                name: r.name.clone(),
                max_value: r.max_value,
                refresh_rule: r.refresh_rule.clone(),
            })
            .collect(),
        abilities: s.abilities.clone(),
        legendary_max: s.legendary_max,
        unlimited_reactions: s.unlimited_reactions,
    }) && s
        .resources
        .iter()
        .all(|r| (0..=r.max_value).contains(&r.current_value))
        && [s.budget.action, s.budget.bonus, s.budget.reaction]
            .iter()
            .all(|v| (0..=1).contains(v))
        && (0..=s.legendary_max).contains(&s.budget.legendary)
        && (0..=9_007_199_254_740_991).contains(&s.usage_number)
        && (s.usage_number == 0) == s.last_use.is_none()
        && s.last_use
            .as_ref()
            .is_none_or(|a| !a.name.trim().is_empty() && kind(&a.kind))
}

#[cfg(test)]
#[test]
fn optional_unlimited_reactions_preserves_legacy_json_and_round_trips() {
    let old = serde_json::json!({"resources":[],"abilities":[],"legendaryMax":0});
    let setup: Setup = serde_json::from_value(old.clone()).unwrap();
    assert_eq!(serde_json::to_value(setup).unwrap(), old);
    for flag in [true, false] {
        let mut new = old.clone();
        new["unlimitedReactions"] = flag.into();
        let setup: Setup = serde_json::from_value(new.clone()).unwrap();
        assert!(valid_setup(&setup));
        assert_eq!(serde_json::to_value(setup).unwrap(), new);
        new["budget"] = serde_json::json!({"action":1,"bonus":1,"reaction":0,"legendary":0});
        new["usageNumber"] = 2.into();
        new["lastUse"] = serde_json::json!({"name":"Reakcja","kind":"reaction","override":false});
        let state: State = serde_json::from_value(new.clone()).unwrap();
        assert!(valid_state(&state));
        assert_eq!(serde_json::to_value(state).unwrap(), new);
    }
    let mut invalid = old;
    invalid["unlimitedReactions"] = "true".into();
    assert!(serde_json::from_value::<Setup>(invalid).is_err());
}
