use super::*;
use serde_json::json;
use sqlx::sqlite::SqlitePoolOptions;
fn fixture() -> Character {
    serde_json::from_str(include_str!("../../tests/fixtures/character.json")).unwrap()
}
fn mutation(c: Character, expected: Option<i64>, id: &str, kind: &str) -> Mutation {
    Mutation {
        participation_revision: None,
        operation_id: id.into(),
        expected_revision: expected,
        character: c,
        kind: kind.into(),
        correction_reason: None,
        inventory_action: None,
        condition_action: None,
        condition_context: None,
    }
}
const X: &str = "987c6081-0d1a-48e4-a1e0-4d16407be701";
const Y: &str = "987c6081-0d1a-48e4-a1e0-4d16407be702";
const Z: &str = "987c6081-0d1a-48e4-a1e0-4d16407be703";
async fn database() -> SqlitePool {
    let p = SqlitePoolOptions::new()
        .max_connections(1)
        .connect("sqlite::memory:")
        .await
        .unwrap();
    sqlx::raw_sql(include_str!("../migrations/001_initial.sql"))
        .execute(&p)
        .await
        .unwrap();
    sqlx::raw_sql(include_str!("../migrations/011_characters.sql"))
        .execute(&p)
        .await
        .unwrap();
    sqlx::raw_sql(include_str!(
        "../migrations/014_character_participation.sql"
    ))
    .execute(&p)
    .await
    .unwrap();
    p
}
#[test]
fn schema_rejects_invalid_nested_data_and_ready_missing_inputs() {
    let s = fixture().draft.unwrap();
    assert!(validate_sheet(&s, true).is_ok());
    for (field, value) in [
        ("levels", serde_json::json!([])),
        ("hpCurrent", serde_json::json!(-1)),
        ("baseScores", serde_json::json!({})),
        ("extra", serde_json::json!(true)),
    ] {
        let mut bad = s.clone();
        bad[field] = value;
        assert!(validate_sheet(&bad, true).is_err(), "{field}");
    }
    let mut s = s;
    s["identity"]["name"] = serde_json::json!("");
    assert!(validate_sheet(&s, false).is_ok());
    assert!(validate_sheet(&s, true).is_err());
    s["identity"]["portrait"] = serde_json::json!("https://example.com/track.png");
    assert!(validate_sheet(&s, false).is_err());
}
#[test]
fn historical_retry_and_optimistic_conflict_preserve_newer_data() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        let x = mutation(fixture(), None, X, "draft");
        let first = save_to_pool(&p, x.clone()).await.unwrap();
        let mut next = first.clone();
        next.draft.as_mut().unwrap()["notes"] = serde_json::json!("Drugi zapis");
        let second = save_to_pool(&p, mutation(next, Some(0), Y, "draft"))
            .await
            .unwrap();
        assert_eq!(second.revision, 1);
        assert_eq!(save_to_pool(&p, x.clone()).await.unwrap(), first);
        let saved: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&saved).unwrap(), second);
        let mut wrong = x;
        wrong.character.draft.as_mut().unwrap()["notes"] = serde_json::json!("Inne dane");
        assert!(save_to_pool(&p, wrong).await.is_err());
        assert!(save_to_pool(&p, mutation(first, Some(0), Z, "draft"))
            .await
            .unwrap_err()
            .contains("Konflikt"));
        let slots: i64 =
            sqlx::query_scalar("SELECT count(*) FROM encounters WHERE id BETWEEN 1 AND 5")
                .fetch_one(&p)
                .await
                .unwrap();
        assert_eq!(slots, 5);
    });
}
#[test]
fn publish_requires_saved_draft_and_draft_cannot_mutate_committed_card() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        let first = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        let mut published = first.clone();
        published.sheet = published.draft.take();
        let second = save_to_pool(&p, mutation(published, Some(0), Y, "publish"))
            .await
            .unwrap();
        let mut bad = second.clone();
        bad.sheet.as_mut().unwrap()["hpCurrent"] = serde_json::json!(0);
        assert!(save_to_pool(&p, mutation(bad, Some(1), Z, "draft"))
            .await
            .is_err());
        let mut next = second.clone();
        next.draft = next.sheet.clone();
        next.draft.as_mut().unwrap()["notes"] = serde_json::json!("Szkic po publikacji");
        let third = save_to_pool(&p, mutation(next, Some(1), Z, "draft"))
            .await
            .unwrap();
        assert_eq!(third.sheet, second.sheet);
    });
}
#[test]
fn rollback_does_not_leave_card_without_operation_history() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql("CREATE TRIGGER fail_history BEFORE INSERT ON character_operations BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
        let m = mutation(fixture(), None, X, "draft");
        assert!(save_to_pool(&p, m.clone()).await.is_err());
        let count: i64 = sqlx::query_scalar("SELECT count(*) FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(count, 0);
        sqlx::raw_sql("DROP TRIGGER fail_history")
            .execute(&p)
            .await
            .unwrap();
        save_to_pool(&p, m).await.unwrap();
        let count: i64 = sqlx::query_scalar("SELECT count(*) FROM character_operations")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(count, 1);
    });
}

#[test]
fn historical_correction_publishes_without_reason_and_preserves_optional_metadata() {
    tauri::async_runtime::block_on(async {
        for reason in [None, Some("Korekta Kondycji MG".to_string())] {
            let p = database().await;
            let first = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
                .await
                .unwrap();
            let mut c = first;
            c.sheet = c.draft.take();
            let second = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
                .await
                .unwrap();
            let mut c = second;
            c.draft = c.sheet.clone();
            c.draft.as_mut().unwrap()["baseScores"]["con"] = serde_json::json!(12);
            let third = save_to_pool(&p, mutation(c, Some(1), Z, "draft"))
                .await
                .unwrap();
            let mut c = third;
            c.sheet = c.draft.take();
            let mut m = mutation(
                c,
                Some(2),
                "987c6081-0d1a-48e4-a1e0-4d16407be704",
                "publish",
            );
            m.correction_reason = reason.clone();
            let saved = save_to_pool(&p, m.clone()).await.unwrap();
            assert_eq!(saved.revision, 3);
            assert_eq!(saved.sheet.as_ref().unwrap()["baseScores"]["con"], 12);
            assert!(saved.draft.is_none());
            assert_eq!(save_to_pool(&p, m).await.unwrap(), saved);
            let recorded: Option<String> = sqlx::query_scalar("SELECT json_extract(request_json,'$.correctionReason') FROM character_operations WHERE operation_id='987c6081-0d1a-48e4-a1e0-4d16407be704'").fetch_one(&p).await.unwrap();
            assert_eq!(recorded, reason);
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM character_operations")
                .fetch_one(&p)
                .await
                .unwrap();
            assert_eq!(count, 4);
        }
    });
}

fn inventory_fixture() -> Value {
    serde_json::from_str(include_str!(
        "../../tests/fixtures/character-inventory.json"
    ))
    .unwrap()
}
fn inventory_command(c: Character, id: &str, a: Value) -> Mutation {
    let mut next = c.clone();
    next.inventory = Some(
        inventory::apply(
            &c.inventory.clone().unwrap_or_else(inventory::empty),
            &a,
            "none",
            false,
        )
        .unwrap(),
    );
    let mut m = mutation(next, Some(c.revision), id, "inventory");
    m.inventory_action = Some(a);
    m
}
#[test]
fn inventory_migration_preserves_the_entire_existing_ledger_and_cards() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        let first = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        let before:Vec<(String,String,String,String,String,String)>=sqlx::query_as("SELECT operation_id,character_id,kind,request_json,result_json,created_at FROM character_operations ORDER BY operation_id").fetch_all(&p).await.unwrap();
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let after:Vec<(String,String,String,String,String,String)>=sqlx::query_as("SELECT operation_id,character_id,kind,request_json,result_json,created_at FROM character_operations ORDER BY operation_id").fetch_all(&p).await.unwrap();
        assert_eq!(before, after);
        assert_eq!(
            save_to_pool(&p, mutation(fixture(), None, X, "draft"))
                .await
                .unwrap(),
            first
        );
        let integrity: String = sqlx::query_scalar("PRAGMA integrity_check")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(integrity, "ok");
        let slots: i64 =
            sqlx::query_scalar("SELECT count(*) FROM encounters WHERE id BETWEEN 1 AND 5")
                .fetch_one(&p)
                .await
                .unwrap();
        assert_eq!(slots, 5);
    });
}
#[test]
fn inventory_transactions_retry_without_rewinding_newer_ammo_and_block_draft_replacement() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let mut first = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        first.sheet = first.draft.take();
        let mut c = save_to_pool(&p, mutation(first, Some(0), Y, "publish"))
            .await
            .unwrap();
        let inv = inventory_fixture();
        for (idx, e) in inv["entries"].as_array().unwrap().iter().enumerate() {
            let id = format!("987c6081-0d1a-48e4-a1e0-4d16407be7{:02}", 10 + idx);
            c = save_to_pool(
                &p,
                inventory_command(
                    c,
                    &id,
                    serde_json::json!({"kind":"edit","entry":e,"reason":"Test"}),
                ),
            )
            .await
            .unwrap();
        }
        let es = inv["entries"].as_array().unwrap();
        let (w, m, a) = (&es[0]["id"], &es[1]["id"], &es[2]["id"]);
        c = save_to_pool(
            &p,
            inventory_command(
                c,
                "987c6081-0d1a-48e4-a1e0-4d16407be720",
                serde_json::json!({"kind":"load","magazineId":m,"ammoId":a,"count":10}),
            ),
        )
        .await
        .unwrap();
        c = save_to_pool(
            &p,
            inventory_command(
                c,
                "987c6081-0d1a-48e4-a1e0-4d16407be721",
                serde_json::json!({"kind":"attach","weaponId":w,"magazineId":m}),
            ),
        )
        .await
        .unwrap();
        let shot = inventory_command(
            c,
            "987c6081-0d1a-48e4-a1e0-4d16407be722",
            serde_json::json!({"kind":"shot","weaponId":w,"mode":"single","count":1}),
        );
        let first_shot = save_to_pool(&p, shot.clone()).await.unwrap();
        let second = save_to_pool(
            &p,
            inventory_command(
                first_shot.clone(),
                "987c6081-0d1a-48e4-a1e0-4d16407be723",
                serde_json::json!({"kind":"shot","weaponId":w,"mode":"single","count":1}),
            ),
        )
        .await
        .unwrap();
        assert_eq!(save_to_pool(&p, shot).await.unwrap(), first_shot);
        let payload: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        let current: Character = serde_json::from_str(&payload).unwrap();
        assert_eq!(current, second);
        assert_eq!(
            current.inventory.as_ref().unwrap()["entries"][1]["magazine"]["rounds"][0]["count"],
            8
        );
        let mut forged = second.clone();
        forged.draft = forged.sheet.clone();
        forged.inventory = first_shot.inventory.clone();
        assert!(
            save_to_pool(&p, mutation(forged, Some(second.revision), Z, "draft"))
                .await
                .is_err()
        );
        let mut draft = second.clone();
        draft.draft = draft.sheet.clone();
        let revision = second.revision;
        let drafted = save_to_pool(&p, mutation(draft, Some(revision), Z, "draft"))
            .await
            .unwrap();
        let mut discard = drafted.clone();
        discard.draft = None;
        let discarded = save_to_pool(
            &p,
            mutation(
                discard,
                Some(drafted.revision),
                "987c6081-0d1a-48e4-a1e0-4d16407be724",
                "discard",
            ),
        )
        .await
        .unwrap();
        assert_eq!(discarded.inventory, second.inventory);
    });
}
#[test]
fn inventory_rejects_tampering_and_rolls_back_with_its_audit_record() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let mut c = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        let c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        let m = inventory_command(
            c.clone(),
            Z,
            serde_json::json!({"kind":"edit","entry":inventory_fixture()["entries"][0],"reason":"Nabycie"}),
        );
        let mut forged = m.clone();
        forged.character.inventory.as_mut().unwrap()["entries"][0]["quantityMilli"] =
            serde_json::json!(0);
        assert!(save_to_pool(&p, forged).await.is_err());
        sqlx::raw_sql("CREATE TRIGGER fail_inventory BEFORE INSERT ON character_operations WHEN NEW.kind='inventory' BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
        assert!(save_to_pool(&p, m.clone()).await.is_err());
        let payload: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&payload).unwrap(), c);
        sqlx::raw_sql("DROP TRIGGER fail_inventory")
            .execute(&p)
            .await
            .unwrap();
        assert_eq!(save_to_pool(&p, m).await.unwrap().revision, 2);
    });
}
#[test]
fn inventory_domain_rejects_bad_links_and_keeps_chrome_exact_stock() {
    let inv = inventory_fixture();
    inventory::validate(&inv).unwrap();
    let es = inv["entries"].as_array().unwrap();
    let (w, m, a) = (&es[0]["id"], &es[1]["id"], &es[2]["id"]);
    let loaded = inventory::apply(
        &inv,
        &serde_json::json!({"kind":"load","magazineId":m,"ammoId":a,"count":30}),
        "none",
        false,
    )
    .unwrap();
    assert!(inventory::apply(
        &loaded,
        &serde_json::json!({"kind":"load","magazineId":m,"ammoId":a,"count":1}),
        "none",
        false
    )
    .is_err());
    let mut next = inventory::apply(
        &loaded,
        &serde_json::json!({"kind":"attach","weaponId":w,"magazineId":m}),
        "none",
        false,
    )
    .unwrap();
    assert!(inventory::apply(
        &next,
        &serde_json::json!({"kind":"shot","weaponId":w,"mode":"long","count":12}),
        "none",
        false
    )
    .is_err());
    assert!(inventory::apply(
        &next,
        &serde_json::json!({"kind":"shot","weaponId":w,"mode":"single","count":1}),
        "chrome",
        false
    )
    .is_err());
    next = inventory::apply(
        &next,
        &serde_json::json!({"kind":"cinematic","weaponId":w,"loaded":true}),
        "chrome",
        false,
    )
    .unwrap();
    next = inventory::apply(
        &next,
        &serde_json::json!({"kind":"shot","weaponId":w,"mode":"short","count":3}),
        "chrome",
        false,
    )
    .unwrap();
    assert_eq!(next["entries"][1], loaded["entries"][1]);
    assert_eq!(next["entries"][2], loaded["entries"][2]);
    for field in ["parentId", "installedMagazineId"] {
        let mut bad = inv.clone();
        bad["entries"][0][field] = serde_json::json!("aaaaaaaa-aaaa-4aaa-aaaa-aaaaaaaaaaaa");
        assert!(inventory::validate(&bad).is_err());
    }
    let mut bad = inv.clone();
    bad["entries"][2]["quantityMilli"] = serde_json::json!(0.5);
    assert!(inventory::validate(&bad).is_err());
}

#[test]
fn inventory_preview_accepts_equivalent_json_numbers_but_not_changed_values() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let mut c = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        let mut c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        for (idx, e) in inventory_fixture()["entries"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
        {
            c = save_to_pool(
                &p,
                inventory_command(
                    c,
                    &format!("987c6081-0d1a-48e4-a1e0-4d16407be8{:02}", idx),
                    serde_json::json!({"kind":"edit","entry":e,"reason":"Fixture"}),
                ),
            )
            .await
            .unwrap();
        }
        let es = c.inventory.as_ref().unwrap()["entries"].as_array().unwrap();
        let action = serde_json::json!({"kind":"load","magazineId":es[1]["id"],"ammoId":es[2]["id"],"count":1});
        let mut m = inventory_command(c, Z, action);
        // The source fixture contains 40.0, while JSON.stringify emits 40.
        m.character.inventory.as_mut().unwrap()["entries"][0]["item"]["baseAvailability"]["min"] =
            serde_json::json!(40);
        assert!(save_to_pool(&p, m).await.is_ok());
        assert!(inventory::same(
            &serde_json::json!({"n":40.0}),
            &serde_json::json!({"n":40})
        ));
        assert!(!inventory::same(
            &serde_json::json!({"n":40}),
            &serde_json::json!({"n":41})
        ));
        assert!(!inventory::same(
            &serde_json::json!({"n":40}),
            &serde_json::json!({"n":"40"})
        ));
    });
}

#[test]
fn condition_domain_matches_preview_and_rejects_tampered_state() {
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-condition.json"
    ))
    .unwrap();
    for case in cases {
        let before: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let out = condition::apply(
            &before,
            &case["action"],
            &case["context"],
            case["operationId"].as_str().unwrap(),
            &case["after"],
        )
        .unwrap();
        assert_eq!(out, case["after"]);
        for key in ["hp", "injury"] {
            let mut bad = case["after"].clone();
            bad[key] = json!(999);
            assert!(condition::apply(
                &before,
                &case["action"],
                &case["context"],
                case["operationId"].as_str().unwrap(),
                &bad
            )
            .is_err());
        }
    }
}
#[test]
fn condition_migration_retry_rollback_and_draft_cannot_rewind_health() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let cases: Vec<Value> = serde_json::from_str(include_str!(
            "../../tests/fixtures/character-condition.json"
        ))
        .unwrap();
        let mut c: Character = serde_json::from_value(cases[0]["before"].clone()).unwrap();
        c.draft = c.sheet.take();
        c = save_to_pool(&p, mutation(c, None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        let old_rows: Vec<(String, String)> = sqlx::query_as(
            "SELECT operation_id,result_json FROM character_operations ORDER BY operation_id",
        )
        .fetch_all(&p)
        .await
        .unwrap();
        sqlx::raw_sql(include_str!("../migrations/013_character_condition.sql"))
            .execute(&p)
            .await
            .unwrap();
        assert_eq!(
            old_rows,
            sqlx::query_as::<_, (String, String)>(
                "SELECT operation_id,result_json FROM character_operations ORDER BY operation_id"
            )
            .fetch_all(&p)
            .await
            .unwrap()
        );
        let cmd = |c: &Character, i: usize| {
            let case = &cases[i];
            let mut next = c.clone();
            next.condition = Some(case["after"].clone());
            let mut m = mutation(
                next,
                Some(c.revision),
                case["operationId"].as_str().unwrap(),
                "condition",
            );
            m.condition_action = Some(case["action"].clone());
            m.condition_context = Some(case["context"].clone());
            m
        };
        let first_cmd = cmd(&c, 0);
        let first = save_to_pool(&p, first_cmd.clone()).await.unwrap();
        let second_cmd = cmd(&first, 1);
        let second = save_to_pool(&p, second_cmd).await.unwrap();
        assert_eq!(save_to_pool(&p, first_cmd).await.unwrap(), first);
        let saved: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
            .bind(&c.id)
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&saved).unwrap(), second);
        let mut rewind = second.clone();
        rewind.condition = first.condition;
        rewind.draft = rewind.sheet.clone();
        assert!(
            save_to_pool(&p, mutation(rewind, Some(second.revision), Z, "draft"))
                .await
                .is_err()
        );
        sqlx::query("CREATE TRIGGER condition_reject BEFORE INSERT ON character_operations WHEN NEW.kind='condition' BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
        assert!(save_to_pool(&p, cmd(&second, 2)).await.is_err());
        let after: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
            .bind(&c.id)
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(saved, after);
    });
}

#[test]
fn condition_context_matches_all_classes_origins_colors_and_rejects_forgery() {
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-condition-parity.json"
    ))
    .unwrap();
    for (index, case) in cases.iter().enumerate() {
        let before: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let run = |context: &Value| {
            condition::apply(
                &before,
                &case["action"],
                context,
                case["operationId"].as_str().unwrap(),
                &case["after"],
            )
        };
        assert!(
            run(&case["context"]).is_ok(),
            "case {index}: {:?}",
            run(&case["context"])
        );
        for key in ["hpMax", "longHpMax", "con"] {
            let mut bad = case["context"].clone();
            bad[key] = json!(bad[key].as_i64().unwrap() + 1);
            assert!(run(&bad).is_err(), "forged {key}, case {index}");
        }
    }
}

#[test]
fn care_and_downtime_match_preview_and_inventory_is_atomic() {
    let cases: Vec<Value> =
        serde_json::from_str(include_str!("../../tests/fixtures/character-care.json")).unwrap();
    for (index, case) in cases.iter().enumerate() {
        let before: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let op = case["operationId"].as_str().unwrap();
        let result = condition::apply(
            &before,
            &case["action"],
            &case["context"],
            op,
            &case["after"],
        );
        assert!(
            result.is_ok(),
            "case {index} {:?}: {:?}",
            case["action"],
            result
        );
        let inventory =
            condition::expected_inventory(&before, &case["action"], op, &case["context"]).unwrap();
        assert_eq!(
            inventory.as_ref().unwrap_or(&Value::Null),
            &case["inventory"],
            "inventory case {index}"
        );
    }
}

#[test]
fn new_health_mechanics_match_typescript_preview() {
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-health-mechanics.json"
    ))
    .unwrap();
    for (index, case) in cases.iter().enumerate() {
        let before: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let op = case["operationId"].as_str().unwrap();
        let result = condition::apply(
            &before,
            &case["action"],
            &case["context"],
            op,
            &case["after"],
        );
        assert!(
            result.is_ok(),
            "health {index} {:?}: {:?}",
            case["action"],
            result
        );
        let inventory =
            condition::expected_inventory(&before, &case["action"], op, &case["context"]).unwrap();
        assert_eq!(
            inventory.as_ref().unwrap_or(&Value::Null),
            &case["inventory"],
            "inventory {index}"
        );
    }
}

#[test]
fn care_medicine_inventory_and_health_retry_and_rollback_together() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        sqlx::raw_sql(include_str!("../migrations/013_character_condition.sql"))
            .execute(&p)
            .await
            .unwrap();
        let cases: Vec<Value> =
            serde_json::from_str(include_str!("../../tests/fixtures/character-care.json")).unwrap();
        let mut c: Character = serde_json::from_value(cases[0]["before"].clone()).unwrap();
        c.draft = c.sheet.take();
        c = save_to_pool(&p, mutation(c, None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        let command = |c: &Character, index: usize| {
            let case = &cases[index];
            let mut next = c.clone();
            next.condition = Some(case["after"].clone());
            next.inventory = Some(case["inventory"].clone());
            let mut m = mutation(
                next,
                Some(c.revision),
                case["operationId"].as_str().unwrap(),
                "condition",
            );
            m.condition_action = Some(case["action"].clone());
            m.condition_context = Some(case["context"].clone());
            m
        };
        let first = command(&c, 0);
        let started = save_to_pool(&p, first).await.unwrap();
        let med = command(&started, 1);
        sqlx::query("CREATE TRIGGER care_reject BEFORE INSERT ON character_operations WHEN NEW.kind='condition' BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
        assert!(save_to_pool(&p, med.clone()).await.is_err());
        let stored: String = sqlx::query_scalar("SELECT payload_json FROM characters WHERE id=?")
            .bind(&c.id)
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&stored).unwrap(), started);
        sqlx::query("DROP TRIGGER care_reject")
            .execute(&p)
            .await
            .unwrap();
        let healed = save_to_pool(&p, med.clone()).await.unwrap();
        assert_eq!(
            healed.inventory.as_ref().unwrap()["entries"][0]["quantityMilli"],
            2000
        );
        assert_eq!(save_to_pool(&p, med).await.unwrap(), healed);
        let mut forged = command(&healed, 2);
        forged.character.inventory.as_mut().unwrap()["entries"][0]["quantityMilli"] = json!(999000);
        assert!(save_to_pool(&p, forged).await.is_err());
    });
}

#[test]
fn combat_health_and_weapon_states_match_typescript_previews() {
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-combat-health.json"
    ))
    .unwrap();
    assert!(!cases.is_empty());
    for case in cases {
        let before: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let out = condition::apply(
            &before,
            &case["action"],
            &case["context"],
            case["op"].as_str().unwrap(),
            &case["after"],
        )
        .unwrap();
        assert!(inventory::same(&out, &case["after"]));
    }
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-combat-weapon.json"
    ))
    .unwrap();
    assert!(!cases.is_empty());
    for case in cases {
        let out = inventory::apply(&case["before"], &case["action"], "chrome", false).unwrap();
        assert!(inventory::same(&out, &case["after"]));
    }
}

#[test]
fn xp_without_explanation_is_valid_but_negative_totals_are_not() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        let mut c = fixture();
        c.draft.as_mut().unwrap()["advancementMode"] = json!("xp");
        c.draft.as_mut().unwrap()["xp"] = json!([{ "id": Z, "amount": 50, "reason": "" }]);
        assert!(validate_sheet(c.draft.as_ref().unwrap(), true).is_ok());
        let mut bad = c.draft.clone().unwrap();
        bad["xp"][0]["amount"] = json!(-1);
        assert!(validate_sheet(&bad, true).is_err());
        let saved = save_to_pool(&p, mutation(c, None, X, "draft"))
            .await
            .unwrap();
        let mut c = saved;
        c.sheet = c.draft.take();
        let result = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        assert_eq!(result.sheet.as_ref().unwrap()["xp"][0]["reason"], "");
    });
}

#[test]
fn numbered_inventory_slots_validate_type_capacity_and_legacy_snapshots() {
    let legacy = inventory_fixture();
    let original = legacy.clone();
    inventory::validate(&legacy).unwrap();
    assert_eq!(legacy, original);
    let mut inv = legacy.clone();
    inv["entries"][0]["slot"] = json!("ranged1");
    inv["entries"][0]["grip"] = json!("twoHanded");
    inventory::validate(&inv).unwrap();
    assert!(inventory::ready_weapon(&inv["entries"][0]));
    for (key, value) in [
        ("slot", json!("melee1")),
        ("slot", json!("ranged4")),
        ("slot", json!("handy1")),
        ("location", json!("backpack")),
        ("grip", json!("invalid")),
        ("quantityMilli", json!(2000)),
    ] {
        let mut bad = inv.clone();
        bad["entries"][0][key] = value;
        assert!(inventory::validate(&bad).is_err(), "{key}: {bad}");
    }
    let mut duplicate = inv.clone();
    let mut second = inv["entries"][0].clone();
    second["id"] = json!(X);
    duplicate["entries"]
        .as_array_mut()
        .unwrap()
        .push(second.clone());
    assert!(inventory::validate(&duplicate)
        .unwrap_err()
        .contains("zajęte"));
    second["slot"] = json!("ranged2");
    *duplicate["entries"]
        .as_array_mut()
        .unwrap()
        .last_mut()
        .unwrap() = second;
    inventory::validate(&duplicate).unwrap();
    let mut required_two = inv.clone();
    required_two["entries"][0]["weapon"]["twoHanded"] = json!(true);
    inventory::validate(&required_two).unwrap();
    required_two["entries"][0]["grip"] = json!("oneHanded");
    assert!(inventory::validate(&required_two).is_err());

    let mut storage = inv.clone();
    storage["entries"][0]["slot"] = json!("none");
    storage["entries"][0]["location"] = json!("backpack");
    inventory::validate(&storage).unwrap();
    assert!(!inventory::ready_weapon(&storage["entries"][0]));
}

#[test]
fn numbered_handy_slots_cover_spare_magazines_and_grenades_without_double_counting() {
    let mut inv = inventory_fixture();
    inv["entries"][0]["slot"] = json!("ranged1");
    inv["entries"][1]["slot"] = json!("handy1");
    inv["entries"][1]["location"] = json!("handy");
    inventory::validate(&inv).unwrap();
    let mut grenade = inv["entries"][0].clone();
    grenade["id"] = json!(X);
    grenade["item"]["name"] = json!("Granat testowy");
    grenade["item"]["category"] = json!("Materiały wybuchowe / Granaty");
    grenade["slot"] = json!("handy2");
    grenade["location"] = json!("handy");
    grenade["weapon"]["system"] = json!("singleUse");
    grenade["weapon"]["capacity"] = json!(0);
    grenade["weapon"]["caliber"] = json!("");
    grenade["weapon"]["modes"] = json!(["single"]);
    inv["entries"].as_array_mut().unwrap().push(grenade.clone());
    inventory::validate(&inv).unwrap();
    assert!(inventory::ready_weapon(&grenade));
    let used = inventory::apply(
        &inv,
        &json!({"kind":"shot","weaponId":X,"mode":"single","count":1}),
        "none",
        false,
    )
    .unwrap();
    assert_eq!(used["entries"][3]["spent"], true);
    assert_eq!(inv["entries"][3]["spent"], false);

    // Unprofiled source grenades still have storage slots without fabricated attacks.
    inv["entries"][3]["weapon"] = Value::Null;
    inv["entries"][3]["item"]
        .as_object_mut()
        .unwrap()
        .remove("weaponProfile");
    inventory::validate(&inv).unwrap();
    assert!(!inventory::ready_weapon(&inv["entries"][3]));
    let mut fourth = grenade.clone();
    fourth["weapon"] = Value::Null;
    fourth["item"]
        .as_object_mut()
        .unwrap()
        .remove("weaponProfile");
    fourth["id"] = json!(Y);
    fourth["slot"] = json!("handy3");
    inv["entries"].as_array_mut().unwrap().push(fourth.clone());
    inventory::validate(&inv).unwrap();
    fourth["id"] = json!(Z);
    fourth["slot"] = json!("none");
    inv["entries"].as_array_mut().unwrap().push(fourth);
    assert!(inventory::validate(&inv).is_err());

    // An installed magazine follows the weapon; it is not a fourth loose item.
    let mut installed = inventory_fixture();
    installed["entries"][0]["slot"] = json!("bothHands");
    installed["entries"][0]["location"] = json!("handy");
    installed["entries"][0]["installedMagazineId"] = installed["entries"][1]["id"].clone();
    let mut ordinary = grenade;
    ordinary["weapon"] = Value::Null;
    ordinary["item"]["type"] = json!("other");
    ordinary["item"]
        .as_object_mut()
        .unwrap()
        .remove("weaponProfile");
    for (id, slot) in [(X, "handy1"), (Y, "handy2"), (Z, "handy3")] {
        ordinary["id"] = json!(id);
        ordinary["slot"] = json!(slot);
        installed["entries"]
            .as_array_mut()
            .unwrap()
            .push(ordinary.clone());
    }
    inventory::validate(&installed).unwrap();
}

#[test]
fn numbered_slot_upgrade_saves_and_retries_without_rewriting_old_operation_snapshots() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let mut c = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        let original = inventory_fixture()["entries"][0].clone();
        let old_command = inventory_command(
            c,
            Z,
            json!({"kind":"edit","entry":original,"reason":"Fixture"}),
        );
        let old_result = save_to_pool(&p, old_command.clone()).await.unwrap();
        let mut upgraded = original.clone();
        upgraded["slot"] = json!("ranged1");
        upgraded["grip"] = json!("twoHanded");
        let new_command = inventory_command(
            old_result.clone(),
            "987c6081-0d1a-48e4-a1e0-000000000901",
            json!({"kind":"edit","entry":upgraded,"reason":"Zmiana miejsca"}),
        );
        let saved = save_to_pool(&p, new_command.clone()).await.unwrap();
        assert_eq!(saved.inventory.as_ref().unwrap()["entries"][0], upgraded);
        assert_eq!(save_to_pool(&p, new_command).await.unwrap(), saved);
        assert_eq!(save_to_pool(&p, old_command).await.unwrap(), old_result);
        let payload: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&payload).unwrap(), saved);
        let history: String =
            sqlx::query_scalar("SELECT result_json FROM character_operations WHERE operation_id=?")
                .bind(Z)
                .fetch_one(&p)
                .await
                .unwrap();
        assert_eq!(
            serde_json::from_str::<Character>(&history)
                .unwrap()
                .inventory
                .as_ref()
                .unwrap()["entries"][0]["slot"],
            "bothHands"
        );
    });
}

fn numbered_reload_fixture() -> Value {
    let mut inv = inventory_fixture();
    inv["entries"][0]["slot"] = json!("ranged1");
    inv["entries"][0]["installedMagazineId"] = inv["entries"][1]["id"].clone();
    let ammo_id = inv["entries"][2]["id"].clone();
    inv["entries"][1]["magazine"]["rounds"] = json!([{"ammoId":ammo_id,"count":4}]);
    inv["entries"][2]["quantityMilli"] = json!(19000);
    let mut spare = inv["entries"][1].clone();
    spare["id"] = json!(X);
    spare["slot"] = json!("handy1");
    spare["location"] = json!("handy");
    spare["magazine"]["rounds"] = json!([{"ammoId":ammo_id,"count":7}]);
    inv["entries"].as_array_mut().unwrap().push(spare.clone());
    for (id, slot) in [(Y, "handy2"), (Z, "handy3")] {
        spare["id"] = json!(id);
        spare["slot"] = json!(slot);
        spare["magazine"] = Value::Null;
        spare["item"]["type"] = json!("other");
        spare["item"]["name"] = json!("Przedmiot podręczny");
        inv["entries"].as_array_mut().unwrap().push(spare.clone());
    }
    inventory::validate(&inv).unwrap();
    inv
}

#[test]
fn numbered_handy_magazine_swaps_preserve_rounds_and_free_the_incoming_slot() {
    let inv = numbered_reload_fixture();
    let before = inv.clone();
    let action = json!({"kind":"attach","weaponId":inv["entries"][0]["id"],"magazineId":X});
    let swapped = inventory::apply(&inv, &action, "none", false).unwrap();
    assert_eq!(inv, before);
    assert_eq!(swapped["entries"][0]["installedMagazineId"], X);
    assert_eq!(swapped["entries"][1]["slot"], "handy1");
    assert_eq!(swapped["entries"][1]["location"], "handy");
    assert_eq!(swapped["entries"][3]["slot"], "none");
    for idx in [1, 3] {
        assert_eq!(
            swapped["entries"][idx]["magazine"],
            before["entries"][idx]["magazine"]
        );
    }
    assert_eq!(swapped["entries"][2]["quantityMilli"], 19000);
    assert_eq!(
        inventory::apply(&swapped, &action, "none", false).unwrap(),
        swapped
    );

    let mut wrong = inv.clone();
    wrong["entries"][3]["magazine"]["model"] = json!("inny model");
    let wrong_before = wrong.clone();
    assert!(inventory::apply(&wrong, &action, "none", false).is_err());
    assert_eq!(wrong, wrong_before);

    let mut first = inv.clone();
    first["entries"][0]["installedMagazineId"] = Value::Null;
    let first_attached = inventory::apply(&first, &action, "none", false).unwrap();
    assert_eq!(first_attached["entries"][3]["slot"], "none");
    assert_eq!(first_attached["entries"][1]["location"], "backpack");
}

#[test]
fn numbered_handy_magazine_swap_persists_atomically_and_retries_once() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        sqlx::raw_sql(include_str!("../migrations/012_character_inventory.sql"))
            .execute(&p)
            .await
            .unwrap();
        let mut c = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        let mut c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        // Seed a valid, fully occupied prepared inventory into the isolated fixture DB.
        c.inventory = Some(numbered_reload_fixture());
        sqlx::query("UPDATE characters SET payload_json=? WHERE id=?")
            .bind(serde_json::to_string(&c).unwrap())
            .bind(&c.id)
            .execute(&p)
            .await
            .unwrap();
        let weapon_id = c.inventory.as_ref().unwrap()["entries"][0]["id"].clone();
        let command = inventory_command(
            c.clone(),
            Z,
            json!({"kind":"attach","weaponId":weapon_id,"magazineId":X}),
        );
        sqlx::raw_sql("CREATE TRIGGER fail_reload BEFORE INSERT ON character_operations WHEN NEW.kind='inventory' BEGIN SELECT RAISE(ABORT,'reload test'); END")
            .execute(&p).await.unwrap();
        assert!(save_to_pool(&p, command.clone()).await.is_err());
        let payload: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&payload).unwrap(), c);
        let count: i64 =
            sqlx::query_scalar("SELECT count(*) FROM character_operations WHERE operation_id=?")
                .bind(Z)
                .fetch_one(&p)
                .await
                .unwrap();
        assert_eq!(count, 0);
        sqlx::raw_sql("DROP TRIGGER fail_reload")
            .execute(&p)
            .await
            .unwrap();
        let saved = save_to_pool(&p, command.clone()).await.unwrap();
        assert_eq!(save_to_pool(&p, command).await.unwrap(), saved);
        let inv = saved.inventory.as_ref().unwrap();
        assert_eq!(inv["entries"][0]["installedMagazineId"], X);
        assert_eq!(inv["entries"][1]["slot"], "handy1");
        assert_eq!(inv["entries"][3]["slot"], "none");
        assert_eq!(inv["entries"][1]["magazine"]["rounds"][0]["count"], 4);
        assert_eq!(inv["entries"][3]["magazine"]["rounds"][0]["count"], 7);
        let payload: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&payload).unwrap(), saved);
    });
}

fn resource_step_fixture() -> (Character, Value) {
    let cases: Vec<Value> = serde_json::from_str(include_str!(
        "../../tests/fixtures/character-condition.json"
    ))
    .unwrap();
    (
        serde_json::from_value(cases[1]["before"].clone()).unwrap(),
        cases[1]["context"].clone(),
    )
}

#[test]
fn concert_daily_counter_matches_frontend_and_is_not_refilled_by_rest() {
    let cases: Vec<Value> =
        serde_json::from_str(include_str!("../../tests/fixtures/character-concert.json")).unwrap();
    for case in &cases {
        let c: Character = serde_json::from_value(case["before"].clone()).unwrap();
        let action = &case["action"];
        let operation = case["operationId"].as_str().unwrap();
        let expected = &case["after"]["condition"];
        let result = super::condition::apply(&c, action, &case["context"], operation, expected);
        assert_eq!(result.unwrap(), *expected);
        if action["type"] == "restApply" || action["type"] == "worldTime" {
            assert_eq!(expected["spent"]["concert"], 1);
            let mut forged = expected.clone();
            forged["spent"]["concert"] = json!(0);
            assert!(
                super::condition::apply(&c, action, &case["context"], operation, &forged).is_err()
            );
        }
    }
    let case = &cases[0];
    let c: Character = serde_json::from_value(case["before"].clone()).unwrap();
    let operation = case["operationId"].as_str().unwrap();
    for (key, value) in [
        ("max", json!(2)),
        ("refresh", json!("long")),
        ("costMax", json!(2)),
    ] {
        let mut context = case["context"].clone();
        for list in ["resources", "longResources"] {
            let resource = context[list]
                .as_array_mut()
                .unwrap()
                .iter_mut()
                .find(|r| r["id"] == "concert")
                .unwrap();
            resource[key] = value.clone();
        }
        assert!(super::condition::apply(
            &c,
            &case["action"],
            &context,
            operation,
            &case["after"]["condition"],
        )
        .is_err());
    }
    let mut unavailable = c;
    unavailable.sheet.as_mut().unwrap()["levels"][2]["choices"]["profession-ability"] =
        json!(["star.0"]);
    assert!(super::condition::apply(
        &unavailable,
        &case["action"],
        &case["context"],
        operation,
        &case["after"]["condition"],
    )
    .is_err());
}
fn resource_step_proposal(c: &Character, id: &str, spent: i64, op: &str) -> Value {
    let mut next = c.condition.clone().unwrap();
    next["spent"][id] = json!(spent);
    next["journal"].as_array_mut().unwrap().push(json!({
        "id": op, "text": "Zmieniono licznik o jedno użycie."
    }));
    next
}

#[test]
fn resource_step_bounds_preserve_other_state_and_spent_above_reduced_limit() {
    let (mut c, ctx) = resource_step_fixture();
    c.condition.as_mut().unwrap()["combatHealth"] = json!({
        "bleeding":true,"successes":1,"failures":1,"stable":false,"dead":false
    });
    let original = c.condition.clone().unwrap();
    for (direction, next_spent) in [("use", 2), ("restore", 0)] {
        let proposed = resource_step_proposal(&c, "stamina", next_spent, X);
        let action = json!({"type":"resourceStep","id":"stamina","direction":direction});
        let out = condition::apply(&c, &action, &ctx, X, &proposed).unwrap();
        assert_eq!(out["hp"], original["hp"]);
        assert_eq!(out["combatHealth"], original["combatHealth"]);
        assert_eq!(out["effects"], original["effects"]);
        assert_eq!(c.condition.as_ref().unwrap(), &original);
    }
    for (spent, direction, id) in [
        (4, "use", "stamina"),
        (0, "restore", "stamina"),
        (1, "reset", "stamina"),
        (1, "use", "unknown"),
        (1, "restore", "unknown"),
    ] {
        c.condition.as_mut().unwrap()["spent"]["stamina"] = json!(spent);
        let proposed = resource_step_proposal(&c, id, spent, X);
        assert!(condition::apply(
            &c,
            &json!({"type":"resourceStep","id":id,"direction":direction}),
            &ctx,
            X,
            &proposed
        )
        .is_err());
    }
    c.condition.as_mut().unwrap()["spent"]["stamina"] = json!(7);
    let next = resource_step_proposal(&c, "stamina", 6, X);
    let out = condition::apply(
        &c,
        &json!({"type":"resourceStep","id":"stamina","direction":"restore"}),
        &ctx,
        X,
        &next,
    )
    .unwrap();
    assert_eq!(out["spent"]["stamina"], 6); // Limit is four; restoring never silently discards debt.
    let mut forged = next;
    forged["hp"] = json!(99);
    assert!(condition::apply(
        &c,
        &json!({"type":"resourceStep","id":"stamina","direction":"restore"}),
        &ctx,
        X,
        &forged
    )
    .is_err());
}

#[test]
fn resource_step_is_atomic_repeat_safe_and_does_not_spend_combat_or_start_effects() {
    tauri::async_runtime::block_on(async {
        for active in [false, true] {
            let p = database().await;
            for sql in [
                include_str!("../migrations/002_pc_initiative.sql"),
                include_str!("../migrations/004_combat_log.sql"),
                include_str!("../migrations/012_character_inventory.sql"),
                include_str!("../migrations/013_character_condition.sql"),
            ] {
                sqlx::raw_sql(sql).execute(&p).await.unwrap();
            }
            let (c, ctx) = resource_step_fixture();
            sqlx::query("INSERT INTO characters(id,revision,payload_json,created_at,updated_at) VALUES(?,0,?,'test','test')")
                .bind(&c.id).bind(serde_json::to_string(&c).unwrap()).execute(&p).await.unwrap();
            let actor = "987c6081-0d1a-48e4-a1e0-4d16407be711";
            let participation = json!({
                "id":"987c6081-0d1a-48e4-a1e0-4d16407be712",
                "characterId":c.id,"encounterId":1,"actorId":actor,"revision":0,"state":"active",
                "budget":{"action":0,"bonus":0,"reaction":0,"interaction":0,"use":0,"attacks":0},
                "effects":[{"id":Z,"label":"Berserk","remaining":4,"phase":"end","target":"str","modifier":0,"mode":"advantage"}],
                "usedRound":["rage"]
            });
            if active {
                sqlx::query("INSERT INTO encounter_actors(id,encounter_id,kind,display_name,initiative_tie_order,tt_current,hp_current,hp_max_current,prepared_snapshot_json,runtime_overrides_json) VALUES(?,1,'pc','Test',0,10,10,20,'{}','{}')")
                    .bind(actor).execute(&p).await.unwrap();
                sqlx::query("INSERT INTO character_participations(id,character_id,encounter_id,actor_id,revision,state,payload_json) VALUES(?,?,1,?,0,'active',?)")
                    .bind(participation["id"].as_str()).bind(&c.id).bind(actor).bind(participation.to_string()).execute(&p).await.unwrap();
            }
            let command = |c: &Character, op: &str, direction: &str, spent, revision| {
                let mut proposed = c.clone();
                proposed.condition = Some(resource_step_proposal(c, "stamina", spent, op));
                let mut m = mutation(proposed, Some(c.revision), op, "condition");
                m.condition_action =
                    Some(json!({"type":"resourceStep","id":"stamina","direction":direction}));
                m.condition_context = Some(ctx.clone());
                m.participation_revision = if active { Some(revision) } else { None };
                m
            };
            let first_cmd = command(&c, X, "use", 2, 0);
            let first = save_to_pool(&p, first_cmd.clone()).await.unwrap();
            let restored = save_to_pool(&p, command(&first, Y, "restore", 1, 1))
                .await
                .unwrap();
            assert_eq!(restored.condition.as_ref().unwrap()["spent"]["stamina"], 1);
            assert_eq!(
                restored.condition.as_ref().unwrap()["hp"],
                c.condition.as_ref().unwrap()["hp"]
            );
            assert_eq!(save_to_pool(&p, first_cmd).await.unwrap(), first);
            let read = || {
                sqlx::query_scalar::<_, String>("SELECT payload_json FROM characters WHERE id=?")
                    .bind(&c.id)
                    .fetch_one(&p)
            };
            assert_eq!(
                serde_json::from_str::<Character>(&read().await.unwrap()).unwrap(),
                restored
            );
            if active {
                let raw: String = sqlx::query_scalar(
                    "SELECT payload_json FROM character_participations WHERE character_id=?",
                )
                .bind(&c.id)
                .fetch_one(&p)
                .await
                .unwrap();
                let mut expected = participation.clone();
                expected["revision"] = json!(2);
                assert_eq!(serde_json::from_str::<Value>(&raw).unwrap(), expected);
            }
            sqlx::query("CREATE TRIGGER fail_counter_history BEFORE INSERT ON character_operations WHEN NEW.kind='condition' BEGIN SELECT RAISE(ABORT,'test'); END").execute(&p).await.unwrap();
            assert!(save_to_pool(&p, command(&restored, Z, "use", 2, 2))
                .await
                .is_err());
            assert_eq!(
                serde_json::from_str::<Character>(&read().await.unwrap()).unwrap(),
                restored
            );
            let count: i64 = sqlx::query_scalar("SELECT count(*) FROM character_operations")
                .fetch_one(&p)
                .await
                .unwrap();
            assert_eq!(count, 2);
            if active {
                let revision: i64 = sqlx::query_scalar(
                    "SELECT revision FROM character_participations WHERE character_id=?",
                )
                .bind(&c.id)
                .fetch_one(&p)
                .await
                .unwrap();
                let logs: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                    .fetch_one(&p)
                    .await
                    .unwrap();
                assert_eq!(revision, 2);
                assert_eq!(logs, 2);
            }
        }
    });
}

#[test]
fn journal_autosave_preserves_published_sheet_draft_and_operation_retry() {
    tauri::async_runtime::block_on(async {
        let p = database().await;
        let mut c = save_to_pool(&p, mutation(fixture(), None, X, "draft"))
            .await
            .unwrap();
        c.sheet = c.draft.take();
        c = save_to_pool(&p, mutation(c, Some(0), Y, "publish"))
            .await
            .unwrap();
        let published = c.sheet.clone();
        c.journal = Some(json!({"notes":"Notatka podczas sesji","contacts":"A","discoveries":"B"}));
        let m = mutation(c, Some(1), Z, "draft");
        let saved = save_to_pool(&p, m.clone()).await.unwrap();
        assert_eq!(saved.sheet, published);
        assert!(saved.draft.is_none());
        assert_eq!(save_to_pool(&p, m).await.unwrap(), saved);
        let stored: String = sqlx::query_scalar("SELECT payload_json FROM characters")
            .fetch_one(&p)
            .await
            .unwrap();
        assert_eq!(serde_json::from_str::<Character>(&stored).unwrap(), saved);
        let mut bad = saved.clone();
        bad.journal.as_mut().unwrap()["hpCurrent"] = json!(100);
        assert!(save_to_pool(
            &p,
            mutation(
                bad,
                Some(2),
                "987c6081-0d1a-48e4-a1e0-4d16407be704",
                "draft"
            )
        )
        .await
        .is_err());
        let mut bad = saved.clone();
        bad.journal.as_mut().unwrap()["notes"] = json!("x".repeat(20001));
        assert!(save_to_pool(
            &p,
            mutation(
                bad,
                Some(2),
                "987c6081-0d1a-48e4-a1e0-4d16407be705",
                "draft"
            )
        )
        .await
        .is_err());
        let mut bad = saved;
        bad.sheet.as_mut().unwrap()["hpCurrent"] = json!(1);
        assert!(save_to_pool(
            &p,
            mutation(
                bad,
                Some(2),
                "987c6081-0d1a-48e4-a1e0-4d16407be706",
                "draft"
            )
        )
        .await
        .is_err());
    });
}
