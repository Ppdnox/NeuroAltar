use serde::{Deserialize, Serialize};
use std::collections::HashSet;
#[derive(Debug, Deserialize, Serialize, Clone, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Failure {
    pub id: String,
    pub result: i64,
    pub weapon_id: Option<String>,
    pub weapon_name: Option<String>,
    pub blocked_action: Option<String>,
    pub remaining_ends: Option<i64>,
    pub note: String,
}
pub(super) fn valid(list: &[Failure]) -> bool {
    let mut ids = HashSet::new();
    list.len() <= 1000
        && list.iter().all(|f| {
            uuid::Uuid::parse_str(&f.id).is_ok()
                && ids.insert(&f.id)
                && (1..=20).contains(&f.result)
                && (if f.result == 1 {
                    f.weapon_id
                        .as_ref()
                        .is_some_and(|id| uuid::Uuid::parse_str(id).is_ok())
                        && f.weapon_name.as_ref().is_some_and(|n| !n.trim().is_empty())
                } else {
                    f.weapon_id.is_none() && f.weapon_name.is_none()
                })
                && (if f.result == 4 {
                    f.blocked_action
                        .as_deref()
                        .is_some_and(|a| a == "bonus" || a == "legendary")
                } else {
                    f.blocked_action.is_none()
                })
                && (if [5, 10, 12].contains(&f.result) {
                    f.remaining_ends.is_some_and(|n| (1..=2).contains(&n))
                } else {
                    f.remaining_ends.is_none()
                })
        })
}

#[cfg(test)]
mod tests {
    use super::super::{
        log::SaveReason,
        save_to_pool, save_with_reason,
        tests::{database, enemy_state},
        validate,
    };
    use super::*;
    fn failure(result: i64) -> Failure {
        Failure {
            id: "00000000-0000-4000-8000-000000000077".into(),
            result,
            weapon_id: if result == 1 {
                Some("00000000-0000-4000-8000-000000000088".into())
            } else {
                None
            },
            weapon_name: if result == 1 {
                Some("Działo Żółw".into())
            } else {
                None
            },
            blocked_action: if result == 4 {
                Some("legendary".into())
            } else {
                None
            },
            remaining_ends: if [5, 10, 12].contains(&result) {
                Some(2)
            } else {
                None
            },
            note: "Zażółć\nNotatka MG".into(),
        }
    }
    #[test]
    fn all_results_round_trip_and_invalid_targets_timers_and_thresholds_are_rejected() {
        for n in 1..=20 {
            let f = failure(n);
            assert!(valid(&[f.clone()]));
            let json = serde_json::to_string(&f).unwrap();
            assert_eq!(serde_json::from_str::<Failure>(&json).unwrap(), f);
        }
        assert!(!valid(&[failure(0)]));
        assert!(!valid(&[failure(21)]));
        assert!(!valid(&[failure(3), failure(3)]));
        let mut f = failure(4);
        f.blocked_action = Some("reaction".into());
        assert!(!valid(&[f]));
        let mut f = failure(1);
        f.weapon_id = None;
        assert!(!valid(&[f]));
        let mut f = failure(10);
        f.remaining_ends = Some(3);
        assert!(!valid(&[f]));
        let mut state = enemy_state();
        state.actors[1].enemy.as_mut().unwrap().failure_threshold = Some(-1);
        assert!(validate(&state).is_err());
        state.actors[1].enemy.as_mut().unwrap().failure_threshold = Some(0);
        assert!(validate(&state).is_ok());
    }
    #[test]
    fn failure_and_hp_log_rollback_together_retry_once_and_reset_keeps_original_catalog_and_sibling(
    ) {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let baseline: String =
                sqlx::query_scalar("SELECT reset_snapshot_json FROM encounter_actors WHERE id=?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let catalog: String = sqlx::query_scalar("SELECT statblock_json FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap();
            state.actors[1].enemy.as_mut().unwrap().machine_failures = Some(vec![failure(6)]);
            state.actors[1].hp_current = 0;
            sqlx::raw_sql("CREATE TRIGGER fail_machine_log BEFORE INSERT ON combat_log WHEN NEW.event_type='machine_failures_changed' BEGIN SELECT RAISE(ABORT,'failure log blocked'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(&pool, state.clone()).await.is_err());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT hp_current FROM encounter_actors WHERE id=?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                30
            );
            sqlx::raw_sql("DROP TRIGGER fail_machine_log")
                .execute(&pool)
                .await
                .unwrap();
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM combat_log WHERE event_type='machine_failures_changed'"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            let persisted: String = sqlx::query_scalar(
                "SELECT runtime_overrides_json FROM encounter_actors WHERE id=?",
            )
            .bind(&state.actors[1].id)
            .fetch_one(&pool)
            .await
            .unwrap();
            let value: serde_json::Value = serde_json::from_str(&persisted).unwrap();
            let loaded: Vec<Failure> =
                serde_json::from_value(value["enemy"]["machineFailures"].clone()).unwrap();
            assert_eq!(loaded, vec![failure(6)]);
            state.actors[1] = *state.actors[1].prepared.clone().unwrap();
            state.round_number = 1;
            state.current_turn_actor_id = None;
            state = super::super::tests::reset_saved(&pool, 1).await;
            save_with_reason(&pool, state.clone(), SaveReason::Reset)
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT hp_current FROM encounter_actors WHERE id=?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                30
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT reset_snapshot_json FROM encounter_actors WHERE id=?"
                )
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                baseline
            );
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT statblock_json FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                catalog
            );
            assert!(state.actors[2]
                .enemy
                .as_ref()
                .unwrap()
                .machine_failures
                .is_none());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
            pool.close().await;
        });
    }
    #[test]
    fn threshold_in_catalog_and_active_timed_failure_survive_storage_and_snapshot() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            for actor in &mut state.actors {
                if let Some(enemy) = &mut actor.enemy {
                    enemy.template.failure_threshold = Some(20);
                    enemy.failure_threshold = Some(20);
                    let mut p = actor.clone();
                    p.prepared = None;
                    actor.prepared = Some(Box::new(p));
                }
            }
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            state.actors[1].enemy.as_mut().unwrap().machine_failures = Some(vec![failure(10)]);
            state.revision = save_to_pool(&pool, state.clone()).await.unwrap();
            let mut prepared = state.actors[1].clone();
            prepared.prepared = None;
            state.actors[1].prepared = Some(Box::new(prepared));
            super::super::tests::prepare_all(&mut state);
            save_with_reason(&pool, state.clone(), SaveReason::Prepare)
                .await
                .unwrap();
            let json: String =
                sqlx::query_scalar("SELECT reset_snapshot_json FROM encounter_actors WHERE id=?")
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap();
            let a: super::super::Actor = serde_json::from_str(&json).unwrap();
            assert_eq!(
                a.enemy.unwrap().machine_failures.unwrap()[0].remaining_ends,
                Some(2)
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT json_extract(statblock_json,'$.failureThreshold') FROM enemy_templates"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                20
            );
            pool.close().await;
        });
    }
}
