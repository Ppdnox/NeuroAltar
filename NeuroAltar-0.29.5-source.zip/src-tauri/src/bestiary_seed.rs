use super::{bestiary, EnemyTemplate};
use serde::{Deserialize, Serialize};
use sqlx::{Row, SqlitePool};
use std::collections::HashSet;
use tauri_plugin_sql::DbInstances;

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Batch {
    batch_id: String,
    version: i64,
    source_sha256: String,
    entries: Vec<Entry>,
}
#[derive(Clone, Deserialize)]
#[serde(deny_unknown_fields)]
struct Entry {
    key: String,
    source: Source,
    template: EnemyTemplate,
}
#[derive(Clone, Deserialize, Serialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Source {
    title: String,
    printed_page: i64,
    pdf_page: Option<i64>,
}
fn bundled() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/machines.v1.json"))
        .map_err(|e| format!("Niepoprawny zestaw maszyn: {e}"))
}

fn monsters() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/monsters.v1.json"))
        .map_err(|e| format!("Niepoprawny zestaw potworów: {e}"))
}
fn animals() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/animals.v2.json"))
        .map_err(|e| format!("Niepoprawny zestaw zwierząt: {e}"))
}
fn mutants() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/mutants.v1.json"))
        .map_err(|e| format!("Niepoprawny zestaw mutantów: {e}"))
}
fn moloch_city() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/moloch-city.v1.json"))
        .map_err(|e| format!("Dane Moloch City: {e}"))
}
fn humans() -> Result<Batch, String> {
    serde_json::from_str(include_str!("../../src/data/bestiary/humans.v1.json"))
        .map_err(|e| format!("Niepoprawny zestaw ludzi: {e}"))
}
async fn apply_bundled(pool: &SqlitePool) -> Result<(), String> {
    let batches = [
        bundled()?,
        monsters()?,
        mutants()?,
        animals()?,
        humans()?,
        moloch_city()?,
    ];
    for batch in batches {
        apply(pool, &batch).await?;
    }
    Ok(())
}

// Called after migrations and before any repository is exposed to the frontend.
// The write lock, catalog mutations and ledger all share one transaction.
async fn apply(pool: &SqlitePool, batch: &Batch) -> Result<(), String> {
    let mut ids = HashSet::new();
    let mut keys = HashSet::new();
    if batch.batch_id.trim().is_empty()
        || batch.version <= 0
        || batch.source_sha256.len() != 64
        || !batch.source_sha256.bytes().all(|b| b.is_ascii_hexdigit())
        || batch.entries.is_empty()
    {
        return Err("Niepoprawne metadane zestawu Bestiariusza.".into());
    }
    for entry in &batch.entries {
        if entry.key.trim().is_empty()
            || !ids.insert(&entry.template.id)
            || !keys.insert(&entry.key)
            || entry.source.printed_page <= 0
            || entry.source.pdf_page.is_some_and(|p| p <= 0)
            || entry.source.title.trim().is_empty()
            || match batch.batch_id.as_str() {
                "noe-machines" => entry.template.category != "machine",
                "noe-monsters" => entry.template.category != "monster",
                "noe-mutants" => entry.template.category != "mutant",
                "noe-animals" => entry.template.category != "animal",
                "noe-humans" => entry.template.category != "human",
                "moloch-city" => !["machine", "human", "mutant", "monster"]
                    .contains(&entry.template.category.as_str()),
                _ => true,
            }
        {
            return Err("Niepoprawny lub powtórzony wpis zestawu Bestiariusza.".into());
        }
        bestiary::validate_template(&entry.template)
            .map_err(|e| format!("{}: {e}", entry.template.name))?;
    }
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    sqlx::query("UPDATE bestiary_seed_entries SET version=version WHERE 0")
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    for entry in &batch.entries {
        let t = &entry.template;
        let offered = serde_json::to_string(t).map_err(|e| e.to_string())?;
        let source = serde_json::json!({"entryKey":entry.key,"source":entry.source,"sha256":batch.source_sha256}).to_string();
        let ledger = sqlx::query("SELECT * FROM bestiary_seed_entries WHERE entry_id=?")
            .bind(&t.id)
            .fetch_optional(&mut *tx)
            .await
            .map_err(|e| e.to_string())?;
        let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
            .bind(&t.id)
            .fetch_optional(&mut *tx)
            .await
            .map_err(|e| e.to_string())?;
        let mut installed = None;
        if let Some(ledger) = ledger {
            if ledger.get::<String, _>("batch_id") != batch.batch_id {
                return Err(format!("Konflikt tożsamości zestawu: {}", t.name));
            }
            let version: i64 = ledger.get("version");
            if version > batch.version {
                continue;
            } // Never downgrade a dataset.
            if version == batch.version {
                let previous: EnemyTemplate =
                    serde_json::from_str(ledger.get("offered_json")).map_err(|e| e.to_string())?;
                if previous != *t || ledger.get::<String, _>("source_json") != source {
                    return Err(format!(
                        "Zmieniono dane zestawu bez zwiększenia wersji: {}",
                        t.name
                    ));
                }
                continue;
            }
            let revision: Option<i64> = ledger.get("installed_revision");
            if let (Some(revision), Some(row)) = (revision, row) {
                let previous: EnemyTemplate =
                    serde_json::from_str(ledger.get("offered_json")).map_err(|e| e.to_string())?;
                // Any MG edit (even edited back), tombstone or out-of-band change opts out.
                if row.get::<i64, _>("deleted") == 0
                    && row.get::<i64, _>("revision") == revision
                    && bestiary::from_row(&row)? == previous
                {
                    if revision >= 9_007_199_254_740_990 {
                        return Err("Limit wersji szablonu.".into());
                    }
                    installed = Some(revision + 1);
                    sqlx::query("UPDATE enemy_templates SET name=?,category=?,official_category=?,size=?,tt=?,hp_max=?,statblock_json=?,revision=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?")
                        .bind(&t.name).bind(bestiary::legacy_category(&t.category)).bind(bestiary::official_category(&t.category)).bind(&t.size).bind(t.tt).bind(t.hp_max)
                        .bind(bestiary::statblock(t)).bind(installed).bind(&t.id)
                        .execute(&mut *tx).await.map_err(|e| e.to_string())?;
                }
            }
            sqlx::query("UPDATE bestiary_seed_entries SET version=?,offered_json=?,source_json=?,installed_revision=? WHERE entry_id=?")
                .bind(batch.version).bind(&offered).bind(&source).bind(installed).bind(&t.id)
                .execute(&mut *tx).await.map_err(|e| e.to_string())?;
        } else {
            // Existing identities, including manually created ones and tombstones, win.
            if row.is_none() {
                sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json) VALUES (?,?,?,?,?,?,?,?)")
                    .bind(&t.id).bind(&t.name).bind(bestiary::legacy_category(&t.category)).bind(bestiary::official_category(&t.category)).bind(&t.size).bind(t.tt).bind(t.hp_max)
                    .bind(bestiary::statblock(t)).execute(&mut *tx).await.map_err(|e| e.to_string())?;
                installed = Some(0_i64);
            }
            sqlx::query("INSERT INTO bestiary_seed_entries (entry_id,batch_id,version,offered_json,source_json,installed_revision) VALUES (?,?,?,?,?,?)")
                .bind(&t.id).bind(&batch.batch_id).bind(batch.version).bind(&offered).bind(&source).bind(installed)
                .execute(&mut *tx).await.map_err(|e| e.to_string())?;
        }
    }
    tx.commit().await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn seed_bestiary(db_instances: tauri::State<'_, DbInstances>) -> Result<(), String> {
    let databases = db_instances.0.read().await;
    let pool = match databases.get("sqlite:combat-tracker.db") {
        Some(tauri_plugin_sql::DbPool::Sqlite(pool)) => pool.clone(),
        _ => return Err("Baza nie jest otwarta.".into()),
    };
    drop(databases);
    apply_bundled(&pool)
        .await
        .map_err(|e| format!("Nie udało się przygotować danych Bestiariusza: {e}"))
}

#[cfg(test)]
mod tests {
    use super::super::tests::{database, enemy_state};
    use super::*;
    #[test]
    fn moloch_supplement_is_additive_and_repeat_safe() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            super::super::save_to_pool(&pool, enemy_state())
                .await
                .unwrap();
            apply(&pool, &bundled().unwrap()).await.unwrap();
            let original = catalog(&pool).await;
            let participants = actors(&pool).await;
            let supplement = moloch_city().unwrap();
            assert_eq!(supplement.entries.len(), 11);
            apply(&pool, &supplement).await.unwrap();
            let once = catalog(&pool).await;
            assert_eq!(once.len(), original.len() + 11);
            apply(&pool, &supplement).await.unwrap();
            assert_eq!(catalog(&pool).await, once);
            for row in original {
                assert!(once.contains(&row));
            }
            assert_eq!(actors(&pool).await, participants);
        });
    }
    async fn catalog(pool: &SqlitePool) -> Vec<(String, String, i64, i64)> {
        sqlx::query_as("SELECT id,statblock_json,revision,deleted FROM enemy_templates ORDER BY id")
            .fetch_all(pool)
            .await
            .unwrap()
    }
    async fn actors(pool: &SqlitePool) -> Vec<(String, String, String, String)> {
        sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(pool).await.unwrap()
    }
    #[test]
    fn complete_batch_retries_and_preserves_all_existing_encounter_data() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            super::super::save_to_pool(&pool, enemy_state())
                .await
                .unwrap();
            let before = actors(&pool).await;
            let logs: Vec<(i64, String)> =
                sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id")
                    .fetch_all(&pool)
                    .await
                    .unwrap();
            let batch = bundled().unwrap();
            assert_eq!(batch.entries.len(), 11);
            apply(&pool, &batch).await.unwrap();
            let first = catalog(&pool).await;
            assert_eq!(first.len(), 12);
            apply(&pool, &batch).await.unwrap();
            assert_eq!(catalog(&pool).await, first);
            assert_eq!(actors(&pool).await, before);
            assert_eq!(
                sqlx::query_as::<_, (i64, String)>(
                    "SELECT id,payload_json FROM combat_log ORDER BY id"
                )
                .fetch_all(&pool)
                .await
                .unwrap(),
                logs
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM encounters WHERE id BETWEEN 1 AND 5"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                5
            );
            pool.close().await;
        });
    }
    #[test]
    fn correction_preserves_edits_tombstones_missing_rows_copies_and_never_downgrades() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut batch = bundled().unwrap();
            batch.entries.truncate(5);
            apply(&pool, &batch).await.unwrap();
            let ids: Vec<_> = batch
                .entries
                .iter()
                .map(|e| e.template.id.clone())
                .collect();
            let id = |n: usize| ids[n].clone();
            // Save a combat copy of a seed that will receive an untouched-catalog correction.
            let mut state = enemy_state();
            state.actors[1].enemy.as_mut().unwrap().template = batch.entries[0].template.clone();
            state.actors[1].prepared = None;
            super::super::save_to_pool(&pool, state).await.unwrap();
            let before = actors(&pool).await;
            sqlx::query("UPDATE enemy_templates SET name='MG Żółć',revision=revision+1 WHERE id=?")
                .bind(id(1))
                .execute(&pool)
                .await
                .unwrap();
            sqlx::query("UPDATE enemy_templates SET deleted=1,revision=revision+1 WHERE id=?")
                .bind(id(2))
                .execute(&pool)
                .await
                .unwrap();
            sqlx::query("DELETE FROM enemy_templates WHERE id=?")
                .bind(id(3))
                .execute(&pool)
                .await
                .unwrap(); // Simulated legacy/external deletion, in-memory only.
            sqlx::query("UPDATE enemy_templates SET name='External edit' WHERE id=?")
                .bind(id(4))
                .execute(&pool)
                .await
                .unwrap();
            let old = batch.clone();
            batch.version = 2;
            for e in &mut batch.entries {
                e.template.tt += 1;
            }
            apply(&pool, &batch).await.unwrap();
            assert_eq!(actors(&pool).await, before);
            for i in [1, 2, 4] {
                assert_eq!(
                    sqlx::query_scalar::<_, i64>("SELECT tt FROM enemy_templates WHERE id=?")
                        .bind(id(i))
                        .fetch_one(&pool)
                        .await
                        .unwrap(),
                    old.entries[i].template.tt
                );
            }
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT tt FROM enemy_templates WHERE id=?")
                    .bind(id(0))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                batch.entries[0].template.tt
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                    .bind(id(2))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates WHERE id=?")
                    .bind(id(3))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM bestiary_seed_entries WHERE installed_revision IS NULL"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                4
            );
            let after = catalog(&pool).await;
            apply(&pool, &batch).await.unwrap();
            apply(&pool, &old).await.unwrap();
            assert_eq!(catalog(&pool).await, after);
            batch.entries[0].template.tt += 1;
            assert!(apply(&pool, &batch).await.is_err());
            assert_eq!(catalog(&pool).await, after);
            pool.close().await;
        });
    }
    #[test]
    fn collision_invalid_payload_and_write_failure_do_not_partially_seed() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut batch = bundled().unwrap();
            sqlx::raw_sql("CREATE TRIGGER fail_seed BEFORE INSERT ON enemy_templates WHEN NEW.name='Juggernaut' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
            assert!(apply(&pool, &batch).await.is_err());
            assert!(catalog(&pool).await.is_empty());
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                0
            );
            sqlx::query("DROP TRIGGER fail_seed")
                .execute(&pool)
                .await
                .unwrap();
            let valid = batch.clone();
            batch.entries[1].template.hp_max = 0;
            assert!(apply(&pool, &batch).await.is_err());
            assert!(catalog(&pool).await.is_empty());
            batch = valid.clone();
            batch.entries.push(batch.entries[0].clone());
            assert!(apply(&pool, &batch).await.is_err());
            let t = &valid.entries[0].template;
            sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json,deleted) VALUES (?,'User original','machine',NULL,'Mała',9,10,'{}',1)").bind(&t.id).execute(&pool).await.unwrap();
            apply(&pool, &valid).await.unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                    .bind(&t.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                "User original"
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                    .bind(&t.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
}

#[cfg(test)]
#[test]
fn additive_migration_and_failed_correction_preserve_legacy_data() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        sqlx::query("DROP TABLE bestiary_seed_entries")
            .execute(&pool)
            .await
            .unwrap();
        super::save_to_pool(&pool, super::tests::enemy_state())
            .await
            .unwrap();
        let before:Vec<(String,String,String,String)>=sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
        sqlx::raw_sql(include_str!("../migrations/007_bestiary_seed.sql"))
            .execute(&pool)
            .await
            .unwrap();
        let mut batch = bundled().unwrap();
        apply(&pool, &batch).await.unwrap();
        let catalog: Vec<(String, String, i64)> =
            sqlx::query_as("SELECT id,statblock_json,revision FROM enemy_templates ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap();
        batch.version = 2;
        for entry in &mut batch.entries {
            entry.template.tt += 1;
        }
        sqlx::raw_sql("CREATE TRIGGER fail_correction BEFORE UPDATE ON enemy_templates WHEN NEW.name='Juggernaut' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
        assert!(apply(&pool, &batch).await.is_err());
        assert_eq!(
            sqlx::query_as::<_, (String, String, i64)>(
                "SELECT id,statblock_json,revision FROM enemy_templates ORDER BY id"
            )
            .fetch_all(&pool)
            .await
            .unwrap(),
            catalog
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT max(version) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap(),before);
        assert!(sqlx::query("PRAGMA foreign_key_check")
            .fetch_all(&pool)
            .await
            .unwrap()
            .is_empty());
        let t = &mut batch.entries[0].template;
        t.statblock.as_mut().unwrap().traits = Some(Some(vec!["x".repeat(1001)]));
        assert!(bestiary::validate_template(t).is_err());
        for value in [Some(None), Some(Some(vec![])), None] {
            t.statblock.as_mut().unwrap().traits = value;
            let json = serde_json::to_string(t).unwrap();
            assert_eq!(serde_json::from_str::<EnemyTemplate>(&json).unwrap(), *t);
            bestiary::validate_template(t).unwrap();
        }
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn monsters_extend_existing_seed_and_preserve_edits_deletions_snapshots_and_retry() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        let machines = bundled().unwrap();
        apply(&pool, &machines).await.unwrap();
        let mut state = super::tests::enemy_state();
        state.actors[1].enemy.as_mut().unwrap().template = machines.entries[0].template.clone();
        state.actors[1].prepared = None;
        super::save_to_pool(&pool, state).await.unwrap();
        sqlx::query("UPDATE enemy_templates SET name='Maszyna MG',revision=1 WHERE id=?")
            .bind(&machines.entries[0].template.id)
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query("UPDATE enemy_templates SET deleted=1,revision=1 WHERE id=?")
            .bind(&machines.entries[1].template.id)
            .execute(&pool)
            .await
            .unwrap();
        let before: Vec<(String,String,String,String)> = sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
        let logs: Vec<(i64, String)> =
            sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM enemy_templates WHERE official_category='monster'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            13
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                .bind(&machines.entries[0].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            "Maszyna MG"
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                .bind(&machines.entries[1].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap(),before);
        assert_eq!(
            sqlx::query_as::<_, (i64, String)>(
                "SELECT id,payload_json FROM combat_log ORDER BY id"
            )
            .fetch_all(&pool)
            .await
            .unwrap(),
            logs
        );
        let mut batch = monsters().unwrap();
        for e in &batch.entries {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&e.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), e.template);
        }
        // Edits and removals in this new batch obey the same correction policy.
        sqlx::query("UPDATE enemy_templates SET name='Potwór MG',revision=1 WHERE id=?")
            .bind(&batch.entries[0].template.id)
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query("UPDATE enemy_templates SET deleted=1,revision=1 WHERE id=?")
            .bind(&batch.entries[1].template.id)
            .execute(&pool)
            .await
            .unwrap();
        batch.version = 2;
        for e in &mut batch.entries {
            e.template.tt += 1;
        }
        apply(&pool, &batch).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[0].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            "Potwór MG"
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[1].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT revision FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[2].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("PRAGMA integrity_check")
                .fetch_one(&pool)
                .await
                .unwrap(),
            "ok"
        );
        pool.close().await;
    });
}
#[cfg(test)]
#[test]
fn failed_monster_batch_rolls_back_only_its_changes_and_can_retry() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        sqlx::raw_sql("CREATE TRIGGER fail_monster BEFORE INSERT ON enemy_templates WHEN NEW.name='Korzec' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
        assert!(apply_bundled(&pool).await.is_err());
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            11
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            11
        );
        sqlx::query("DROP TRIGGER fail_monster")
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn mutants_preserve_prior_batches_and_all_encounter_data_and_protect_mg_changes() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        super::save_to_pool(&pool, super::tests::enemy_state())
            .await
            .unwrap();
        let before: Vec<(String,String,String,String)> = sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
        let logs: Vec<(i64, String)> =
            sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap();
        let catalog: Vec<(String, String, i64, i64)> = sqlx::query_as(
            "SELECT id,statblock_json,revision,deleted FROM enemy_templates ORDER BY id",
        )
        .fetch_all(&pool)
        .await
        .unwrap();
        let mut batch = mutants().unwrap();
        assert_eq!(batch.entries.len(), 7);
        // A pre-existing identity belongs to the user, even if its ID collides.
        let collision = &batch.entries[6].template;
        sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json) VALUES (?,'Mesmeryta MG','other','mutant','Średni',10,10,'{}')").bind(&collision.id).execute(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        for entry in &batch.entries[..6] {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM enemy_templates WHERE official_category='mutant'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            9
        );
        sqlx::query("UPDATE enemy_templates SET name='Ghul MG',revision=revision+1 WHERE id=?")
            .bind(&batch.entries[0].template.id)
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query("UPDATE enemy_templates SET deleted=1,revision=revision+1 WHERE id=?")
            .bind(&batch.entries[1].template.id)
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        let old = batch.clone();
        batch.version = 2;
        for e in &mut batch.entries {
            e.template.tt += 1;
        }
        apply(&pool, &batch).await.unwrap();
        apply(&pool, &old).await.unwrap();
        for (i, name) in [(0, "Ghul MG"), (6, "Mesmeryta MG")] {
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                    .bind(&batch.entries[i].template.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                name
            );
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[1].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT tt FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[2].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            batch.entries[2].template.tt
        );
        for (id, json, revision, deleted) in catalog {
            assert_eq!(
                sqlx::query_as::<_, (String, i64, i64)>(
                    "SELECT statblock_json,revision,deleted FROM enemy_templates WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                (json, revision, deleted)
            );
        }
        assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap(),before);
        assert_eq!(
            sqlx::query_as::<_, (i64, String)>(
                "SELECT id,payload_json FROM combat_log ORDER BY id"
            )
            .fetch_all(&pool)
            .await
            .unwrap(),
            logs
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT id FROM encounters ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap(),
            vec![1, 2, 3, 4, 5]
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("PRAGMA integrity_check")
                .fetch_one(&pool)
                .await
                .unwrap(),
            "ok"
        );
        assert!(sqlx::query("PRAGMA foreign_key_check")
            .fetch_all(&pool)
            .await
            .unwrap()
            .is_empty());
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn failed_mutant_batch_rolls_back_and_retries_without_reinstalling_older_batches() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        sqlx::raw_sql("CREATE TRIGGER fail_mutant BEFORE INSERT ON enemy_templates WHEN NEW.name='Generacja III — Grubas' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
        assert!(apply_bundled(&pool).await.is_err());
        for table in ["enemy_templates", "bestiary_seed_entries"] {
            assert_eq!(
                sqlx::query_scalar::<_, i64>(&format!("SELECT count(*) FROM {table}"))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                23
            );
        }
        sqlx::query("DROP TRIGGER fail_mutant")
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT sum(revision) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            0
        );
        for entry in &mutants().unwrap().entries {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn failed_animal_batch_rolls_back_and_retries_without_reinstalling_older_batches() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        apply(&pool, &mutants().unwrap()).await.unwrap();
        sqlx::raw_sql("CREATE TRIGGER fail_animal BEFORE INSERT ON enemy_templates WHEN NEW.name='Neoniedźwiedź' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
        assert!(apply_bundled(&pool).await.is_err());
        for table in ["enemy_templates", "bestiary_seed_entries"] {
            assert_eq!(
                sqlx::query_scalar::<_, i64>(&format!("SELECT count(*) FROM {table}"))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                30
            );
        }
        sqlx::query("DROP TRIGGER fail_animal")
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT sum(revision) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            0
        );
        for entry in &animals().unwrap().entries {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn animals_preserve_prior_batches_and_all_encounter_data_and_protect_mg_changes() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        apply(&pool, &mutants().unwrap()).await.unwrap();
        super::save_to_pool(&pool, super::tests::enemy_state())
            .await
            .unwrap();
        let before: Vec<(String,String,String,String)> = sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
        let logs: Vec<(i64, String)> =
            sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap();
        let catalog: Vec<(String, String, i64, i64)> = sqlx::query_as(
            "SELECT id,statblock_json,revision,deleted FROM enemy_templates ORDER BY id",
        )
        .fetch_all(&pool)
        .await
        .unwrap();
        let mut batch = animals().unwrap();
        assert_eq!(batch.entries.len(), 12);
        // A pre-existing identity belongs to the user, even if its ID collides.
        let collision = &batch.entries[6].template;
        sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json) VALUES (?,'Szczur MG','other','animal','Średni',10,10,'{}')").bind(&collision.id).execute(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        for entry in &batch.entries[..6] {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM enemy_templates WHERE official_category='animal'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            12
        );
        sqlx::query("UPDATE enemy_templates SET name='Gigamut MG',revision=revision+1 WHERE id=?")
            .bind(&batch.entries[0].template.id)
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query("UPDATE enemy_templates SET deleted=1,revision=revision+1 WHERE id=?")
            .bind(&batch.entries[1].template.id)
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        let old = batch.clone();
        batch.version += 1;
        for e in &mut batch.entries {
            e.template.tt += 1;
        }
        apply(&pool, &batch).await.unwrap();
        apply(&pool, &old).await.unwrap();
        for (i, name) in [(0, "Gigamut MG"), (6, "Szczur MG")] {
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                    .bind(&batch.entries[i].template.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                name
            );
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[1].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT tt FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[2].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            batch.entries[2].template.tt
        );
        for (id, json, revision, deleted) in catalog {
            assert_eq!(
                sqlx::query_as::<_, (String, i64, i64)>(
                    "SELECT statblock_json,revision,deleted FROM enemy_templates WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                (json, revision, deleted)
            );
        }
        assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap(),before);
        assert_eq!(
            sqlx::query_as::<_, (i64, String)>(
                "SELECT id,payload_json FROM combat_log ORDER BY id"
            )
            .fetch_all(&pool)
            .await
            .unwrap(),
            logs
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT id FROM encounters ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap(),
            vec![1, 2, 3, 4, 5]
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("PRAGMA integrity_check")
                .fetch_one(&pool)
                .await
                .unwrap(),
            "ok"
        );
        assert!(sqlx::query("PRAGMA foreign_key_check")
            .fetch_all(&pool)
            .await
            .unwrap()
            .is_empty());
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn humans_preserve_prior_batches_and_all_encounter_data_and_protect_mg_changes() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        apply(&pool, &mutants().unwrap()).await.unwrap();
        apply(&pool, &animals().unwrap()).await.unwrap();
        super::save_to_pool(&pool, super::tests::enemy_state())
            .await
            .unwrap();
        let before: Vec<(String,String,String,String)> = sqlx::query_as("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
        let logs: Vec<(i64, String)> =
            sqlx::query_as("SELECT id,payload_json FROM combat_log ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap();
        let catalog: Vec<(String, String, i64, i64)> = sqlx::query_as(
            "SELECT id,statblock_json,revision,deleted FROM enemy_templates ORDER BY id",
        )
        .fetch_all(&pool)
        .await
        .unwrap();
        let mut batch = humans().unwrap();
        assert_eq!(batch.entries.len(), 9);
        // A pre-existing identity belongs to the user, even if its ID collides.
        let collision = &batch.entries[6].template;
        sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json) VALUES (?,'Kanibal MG','human','human','Średni',10,10,'{}')").bind(&collision.id).execute(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        for entry in &batch.entries[..6] {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>(
                "SELECT count(*) FROM enemy_templates WHERE official_category='human'"
            )
            .fetch_one(&pool)
            .await
            .unwrap(),
            11
        );
        sqlx::query("UPDATE enemy_templates SET name='Cyngiel MG',revision=revision+1 WHERE id=?")
            .bind(&batch.entries[0].template.id)
            .execute(&pool)
            .await
            .unwrap();
        sqlx::query("UPDATE enemy_templates SET deleted=1,revision=revision+1 WHERE id=?")
            .bind(&batch.entries[1].template.id)
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        let old = batch.clone();
        batch.version += 1;
        for e in &mut batch.entries {
            e.template.tt += 1;
        }
        apply(&pool, &batch).await.unwrap();
        apply(&pool, &old).await.unwrap();
        for (i, name) in [(0, "Cyngiel MG"), (6, "Kanibal MG")] {
            assert_eq!(
                sqlx::query_scalar::<_, String>("SELECT name FROM enemy_templates WHERE id=?")
                    .bind(&batch.entries[i].template.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                name
            );
        }
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[1].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT tt FROM enemy_templates WHERE id=?")
                .bind(&batch.entries[2].template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            batch.entries[2].template.tt
        );
        for (id, json, revision, deleted) in catalog {
            assert_eq!(
                sqlx::query_as::<_, (String, i64, i64)>(
                    "SELECT statblock_json,revision,deleted FROM enemy_templates WHERE id=?"
                )
                .bind(id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                (json, revision, deleted)
            );
        }
        assert_eq!(sqlx::query_as::<_,(String,String,String,String)>("SELECT id,runtime_overrides_json,prepared_snapshot_json,reset_snapshot_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap(),before);
        assert_eq!(
            sqlx::query_as::<_, (i64, String)>(
                "SELECT id,payload_json FROM combat_log ORDER BY id"
            )
            .fetch_all(&pool)
            .await
            .unwrap(),
            logs
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT id FROM encounters ORDER BY id")
                .fetch_all(&pool)
                .await
                .unwrap(),
            vec![1, 2, 3, 4, 5]
        );
        assert_eq!(
            sqlx::query_scalar::<_, String>("PRAGMA integrity_check")
                .fetch_one(&pool)
                .await
                .unwrap(),
            "ok"
        );
        assert!(sqlx::query("PRAGMA foreign_key_check")
            .fetch_all(&pool)
            .await
            .unwrap()
            .is_empty());
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn failed_human_batch_rolls_back_and_retries_without_reinstalling_older_batches() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        apply(&pool, &bundled().unwrap()).await.unwrap();
        apply(&pool, &monsters().unwrap()).await.unwrap();
        apply(&pool, &mutants().unwrap()).await.unwrap();
        apply(&pool, &animals().unwrap()).await.unwrap();
        sqlx::raw_sql("CREATE TRIGGER fail_human BEFORE INSERT ON enemy_templates WHEN NEW.name='Szeryf' BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
        assert!(apply_bundled(&pool).await.is_err());
        for table in ["enemy_templates", "bestiary_seed_entries"] {
            assert_eq!(
                sqlx::query_scalar::<_, i64>(&format!("SELECT count(*) FROM {table}"))
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                42
            );
        }
        sqlx::query("DROP TRIGGER fail_human")
            .execute(&pool)
            .await
            .unwrap();
        apply_bundled(&pool).await.unwrap();
        apply_bundled(&pool).await.unwrap();
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM bestiary_seed_entries")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT count(*) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            62
        );
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT sum(revision) FROM enemy_templates")
                .fetch_one(&pool)
                .await
                .unwrap(),
            0
        );
        for entry in &humans().unwrap().entries {
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&entry.template.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(bestiary::from_row(&row).unwrap(), entry.template);
        }
        pool.close().await;
    });
}
