use super::*;
const DISEASES: [&str; 12] = [
    "hemophilia",
    "circulation",
    "dracula",
    "thurman",
    "boston",
    "osteoporosis",
    "paranoia",
    "labyrinth",
    "radiation",
    "rat",
    "infection",
    "death",
];
const PHOBIAS: [&str; 8] = [
    "heights", "spiders", "closed", "mutants", "dark", "fire", "machines", "rats",
];
const MEDICINES: [&str; 11] = [
    "Desmopresyna",
    "Aspiryna K",
    "Dracophen",
    "Reminex",
    "Relanium",
    "Wapniak",
    "Psychotropy",
    "Actinix",
    "RadOff",
    "Antybiotyki",
    "Antybiotyki",
];
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Disease {
    id: String,
    kind: String,
    stage: i64,
    active: bool,
    details: String,
    treated_day: Option<i64>,
    treatment_days: i64,
    last_treatment_day: Option<i64>,
    last_check_day: Option<i64>,
    pub(super) blocked: bool,
    onset_at: i64,
    bleeding: bool,
    successes: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Phobia {
    id: String,
    kind: String,
    successes: i64,
    active: bool,
    fear: bool,
    immune_until: i64,
    attack_until: i64,
    last_check_at: Option<i64>,
    turns: Vec<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
struct Start {
    group: String,
    ability: String,
    delta: i64,
}
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Default)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub(super) struct Care {
    pub(super) diseases: Vec<Disease>,
    phobias: Vec<Phobia>,
    starts: Vec<Start>,
    day: i64,
    days: Vec<String>,
    hungry_days: i64,
    food_satisfied: bool,
    water_satisfied: bool,
    radiation_failures: i64,
    exposures: Vec<String>,
}
fn num(v: &Value, k: &str) -> Result<i64, String> {
    v[k].as_i64().ok_or_else(|| format!("Brak liczby: {k}"))
}
fn string<'a>(v: &'a Value, k: &str) -> Result<&'a str, String> {
    v[k].as_str().ok_or_else(|| format!("Brak tekstu: {k}"))
}
fn bounded(n: i64) -> Result<(), String> {
    need((0..=1000000000).contains(&n))
}
pub(super) fn validate(c: &Care) -> Result<(), String> {
    need(
        c.diseases.len() <= 100
            && c.phobias.len() <= 100
            && c.starts.len() <= 2
            && c.days.len() <= 10000
            && c.exposures.len() <= 10000,
    )?;
    unique(c.diseases.iter().map(|d| d.id.as_str()))?;
    unique(c.phobias.iter().map(|p| p.id.as_str()))?;
    unique(c.starts.iter().map(|s| s.group.as_str()))?;
    unique(c.days.iter().map(String::as_str))?;
    unique(c.exposures.iter().map(String::as_str))?;
    for d in &c.diseases {
        id(&d.id)?;
        text(&d.details)?;
        need(
            DISEASES.contains(&d.kind.as_str())
                && (0..=2).contains(&d.stage)
                && (0..=3).contains(&d.successes),
        )?;
        for n in [
            Some(d.onset_at),
            d.treated_day,
            Some(d.treatment_days),
            d.last_treatment_day,
            d.last_check_day,
        ]
        .into_iter()
        .flatten()
        {
            bounded(n)?;
        }
    }
    for p in &c.phobias {
        id(&p.id)?;
        need(
            PHOBIAS.contains(&p.kind.as_str())
                && (0..=3).contains(&p.successes)
                && p.turns.len() <= 10000,
        )?;
        for n in [Some(p.immune_until), Some(p.attack_until), p.last_check_at]
            .into_iter()
            .flatten()
        {
            bounded(n)?;
        }
        unique(p.turns.iter().map(String::as_str))?;
        for t in &p.turns {
            text(t)?;
        }
    }
    for s in &c.starts {
        need(
            ["disease", "phobia"].contains(&s.group.as_str())
                && super::super::ABILITIES.contains(&s.ability.as_str())
                && (-1..=1).contains(&s.delta),
        )?;
    }
    for n in [c.day, c.hungry_days, c.radiation_failures] {
        bounded(n)?;
    }
    for t in c.days.iter().chain(&c.exposures) {
        text(t)?;
    }
    Ok(())
}
pub(super) fn blocked(c: &Care) -> bool {
    c.diseases.iter().any(|d| d.active && d.blocked)
}
pub(super) fn sheet(original: &Value, care: &Care) -> Value {
    let mut s = original.clone();
    for x in &care.starts {
        if let Some(n) = s["baseScores"][&x.ability].as_i64() {
            s["baseScores"][&x.ability] =
                json!((n + x.delta).clamp(1, if x.delta > 0 { 18 } else { 30 }));
        }
    }
    if let Some(d) = care
        .diseases
        .iter()
        .filter(|d| d.active && d.kind == "thurman" && d.stage > 0)
        .max_by_key(|d| d.stage)
    {
        let o = s["overrides"].as_array_mut().unwrap();
        o.retain(|o| o["target"] != "score:int");
        o.push(json!({"id":d.id,"target":"score:int","mode":"replace","value":if d.stage==2{2}else{6},"reason":"Syndrom Thurmana"}));
    }
    s
}
fn add_disease(
    c: &mut Care,
    idv: &str,
    kind: &str,
    details: &str,
    onset: i64,
) -> Result<(), String> {
    id(idv)?;
    text(details)?;
    need(DISEASES.contains(&kind) && !c.diseases.iter().any(|d| d.id == idv))?;
    c.diseases.push(Disease {
        id: idv.into(),
        kind: kind.into(),
        stage: 0,
        active: true,
        details: details.into(),
        treated_day: None,
        treatment_days: 0,
        last_treatment_day: None,
        last_check_day: None,
        blocked: false,
        onset_at: onset,
        bleeding: false,
        successes: 0,
    });
    Ok(())
}
fn add_phobia(c: &mut Care, idv: &str, kind: &str) -> Result<(), String> {
    id(idv)?;
    need(PHOBIAS.contains(&kind) && !c.phobias.iter().any(|p| p.id == idv))?;
    c.phobias.push(Phobia {
        id: idv.into(),
        kind: kind.into(),
        successes: 0,
        active: true,
        fear: false,
        immune_until: 0,
        attack_until: 0,
        last_check_at: None,
        turns: vec![],
    });
    Ok(())
}
fn consume(inv: &mut Value, idv: &str, qty: i64) -> Result<(), String> {
    let e = inv["entries"]
        .as_array_mut()
        .unwrap()
        .iter_mut()
        .find(|e| e["id"] == idv)
        .ok_or("Brak materiału.")?;
    let amount = num(e, "quantityMilli")?;
    need(
        qty > 0
            && qty <= amount
            && e["weapon"].is_null()
            && e["magazine"].is_null()
            && e["container"] == false,
    )?;
    e["quantityMilli"] = json!(amount - qty);
    Ok(())
}
fn exhaust(s: &mut State, idv: &str, cause: &str, source: &str) {
    s.exhaustion.push(Exhaustion {
        id: idv.into(),
        cause: cause.into(),
        source: source.into(),
        level: 1,
    });
}
fn label(kind: &str) -> &str {
    match kind {
        "hemophilia" => "Hemofilia",
        "circulation" => "Niewydolność krążenia",
        "dracula" => "Syndrom Draculi",
        "thurman" => "Syndrom Thurmana",
        "boston" => "Szaleństwo bostońskie",
        "osteoporosis" => "Osteoporoza",
        "paranoia" => "Paranoja",
        "labyrinth" => "Zaburzenia błędnika",
        "radiation" => "Choroba popromienna",
        "rat" => "Szczurza gorączka",
        "infection" => "Choroba zakaźna",
        _ => "Death Breath",
    }
}
pub(super) fn apply(old: &Character, s: &mut State, a: &Value, op: &str) -> Result<Value, String> {
    let mut c = s.care.clone().unwrap_or_default();
    validate(&c)?;
    let mut inv = old
        .inventory
        .clone()
        .unwrap_or_else(super::super::inventory::empty);
    let sheet = old.sheet.as_ref().unwrap();
    let immune = downtime::has_feat(sheet, "immunity");
    let now = s.world_minutes;
    let day = now / 1440;
    c.day = day;
    let kind = string(a, "kind")?;
    let fields: &[&str] = match kind {
        "start" => &["kind", "group", "choice", "ability", "id", "medicine"],
        "disease" => &["kind", "id", "disease", "details", "onsetMinutes"],
        "diseaseCheck" => &["kind", "id", "natural", "total", "chronicRoll"],
        "medicine" => &["kind", "id", "entryId", "doses", "treatment", "sideSave"],
        "bleeding" => &["kind", "id", "mode", "total", "tools"],
        "phobia" => &["kind", "id", "phobia"],
        "phobiaAway" => &["kind", "id"],
        "phobiaCheck" => &["kind", "id", "total", "turn", "trigger"],
        "day" => &[
            "kind",
            "id",
            "foodMg",
            "waterMl",
            "hungerSave",
            "foodEntryId",
            "foodQuantity",
            "waterEntryId",
            "waterQuantity",
        ],
        "environment" => &["kind", "id", "hazard", "total", "dc", "diseaseId"],
        "careCorrection" => &["kind", "group", "id", "reason"],
        _ => return Err("Nieznana czynność zdrowia.".into()),
    };
    need(a.as_object().is_some_and(|o| {
        o.len() == fields.len() && o.keys().all(|k| fields.contains(&k.as_str()))
    }))?;
    match kind {
        "start" => {
            let group = string(a, "group")?;
            need(
                ["disease", "phobia"].contains(&group)
                    && !c.starts.iter().any(|x| x.group == group),
            )?;
            let ability = string(a, "ability")?;
            need(super::super::ABILITIES.contains(&ability))?;
            let mut base = sheet["baseScores"][ability].as_i64().ok_or("Brak cechy.")?;
            for x in c.starts.iter().filter(|x| x.ability == ability) {
                base = (base + x.delta).clamp(1, if x.delta > 0 { 18 } else { 30 });
            }
            let chosen = num(a, "choice")?;
            need((-1..=7).contains(&chosen))?;
            let delta = if chosen < 0 {
                -1
            } else if base >= 18 {
                0
            } else {
                1
            };
            need(base + delta >= 1)?;
            c.starts.push(Start {
                group: group.into(),
                ability: ability.into(),
                delta,
            });
            if chosen >= 0 {
                let index = chosen as usize;
                let idv = string(a, "id")?;
                if group == "disease" {
                    add_disease(&mut c, idv, DISEASES[index], "Wybór początkowy", now)?;
                    let m = &a["medicine"];
                    need(
                        m["item"]["name"] == MEDICINES[index]
                            && m["quantityMilli"] == 3000
                            && m["unit"] == "dawka"
                            && m["weightMg"] == 0
                            && m["slot"] == "none"
                            && m["weapon"].is_null()
                            && m["armor"].is_null()
                            && m["magazine"].is_null()
                            && m["container"] == false
                            && m["parentId"].is_null(),
                    )?;
                    need(
                        !inv["entries"]
                            .as_array()
                            .unwrap()
                            .iter()
                            .any(|e| e["id"] == m["id"]),
                    )?;
                    inv["entries"].as_array_mut().unwrap().push(m.clone());
                } else {
                    need(a["medicine"].is_null())?;
                    add_phobia(&mut c, idv, PHOBIAS[index])?;
                }
            } else {
                need(a["medicine"].is_null())?;
            }
        }
        "disease" => {
            need(!immune)?;
            let onset = num(a, "onsetMinutes")?;
            bounded(onset)?;
            add_disease(
                &mut c,
                string(a, "id")?,
                string(a, "disease")?,
                string(a, "details")?,
                now + onset,
            )?;
        }
        "diseaseCheck" => {
            let index = c
                .diseases
                .iter()
                .position(|d| d.active && d.id == a["id"])
                .ok_or("Brak choroby.")?;
            let mut d = c.diseases[index].clone();
            let natural = num(a, "natural")?;
            let total = num(a, "total")?;
            need(
                (1..=20).contains(&natural)
                    && (-100..=200).contains(&total)
                    && now >= d.onset_at
                    && d.last_check_day != Some(day)
                    && !["hemophilia", "infection"].contains(&d.kind.as_str()),
            )?;
            if DISEASES[..8].contains(&d.kind.as_str()) {
                need(d.treated_day != Some(day))?;
                d.stage = if natural == 20 {
                    0
                } else {
                    (d.stage
                        + if natural == 1 {
                            2
                        } else if total < 10 {
                            1
                        } else {
                            0
                        })
                    .min(2)
                };
            } else if d.kind == "death" {
                if total < 10 {
                    d.stage = 2;
                } else {
                    d.active = false;
                }
            } else if total >= if d.kind == "radiation" { 20 } else { 15 } {
                d.active = false;
                d.blocked = false;
                if d.kind == "radiation" && !immune {
                    let roll = num(a, "chronicRoll")?;
                    need((1..=8).contains(&roll))?;
                    add_disease(
                        &mut c,
                        op,
                        DISEASES[roll as usize - 1],
                        "Następstwo choroby popromiennej",
                        now,
                    )?;
                }
            } else {
                d.blocked = true;
                exhaust(s, op, "disease", label(&d.kind));
            }
            d.last_check_day = Some(day);
            c.diseases[index] = d;
        }
        "medicine" => {
            if a["treatment"] == "exposure" {
                let eid = string(a, "entryId")?;
                let e = inv["entries"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|e| e["id"] == eid)
                    .ok_or("Brak leku.")?;
                need(
                    string(&e["item"], "name")?.to_lowercase() == "radoff"
                        && (e["unit"] == "dawka" || e["unit"] == "szt."),
                )?;
                let doses = num(a, "doses")?;
                let save = num(a, "sideSave")?;
                need((1..=100).contains(&doses) && (-100..=200).contains(&save))?;
                s.exhaustion.retain(|e| {
                    e.cause != "radiation"
                        && !(e.cause == "disease" && e.source == "Choroba popromienna")
                });
                c.radiation_failures = 0;
                downtime::rad_off(s, op, save < 15);
                consume(&mut inv, eid, doses * 1000)?;
            } else {
                let d = c
                    .diseases
                    .iter_mut()
                    .find(|d| d.active && d.id == a["id"])
                    .ok_or("Brak choroby.")?;
                let eid = string(a, "entryId")?;
                let e = inv["entries"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|e| e["id"] == eid)
                    .ok_or("Brak leku.")?;
                let treatment = string(a, "treatment")?;
                let expected = if treatment == "antibiotic" {
                    "Antybiotyk"
                } else if treatment == "radoff" {
                    "RadOff"
                } else {
                    let index = DISEASES.iter().position(|k| *k == d.kind).unwrap();
                    MEDICINES.get(index).ok_or("Brak leku.")?
                };
                need(
                    string(&e["item"], "name")?
                        .to_lowercase()
                        .contains(&expected.to_lowercase())
                        && (e["unit"] == "dawka" || e["unit"] == "szt."),
                )?;
                let doses = num(a, "doses")?;
                need((1..=100).contains(&doses))?;
                if treatment == "bleeding" {
                    need(d.kind == "hemophilia" && d.bleeding)?;
                    d.bleeding = false;
                    d.successes = 0;
                } else {
                    need(d.treated_day != Some(day))?;
                    d.treated_day = Some(day);
                    if treatment == "daily" {
                        need(DISEASES[..8].contains(&d.kind.as_str()))?;
                    } else {
                        need(
                            (treatment == "radoff" && d.kind == "radiation")
                                || (treatment == "antibiotic"
                                    && ["rat", "infection"].contains(&d.kind.as_str())),
                        )?;
                        d.treatment_days = if d.last_treatment_day == Some(day - 1) {
                            d.treatment_days + 1
                        } else {
                            1
                        };
                        d.last_treatment_day = Some(day);
                        if d.treatment_days >= 10 {
                            d.active = false;
                            d.blocked = false;
                        }
                        if d.kind == "infection" && d.treatment_days >= 3 {
                            d.stage = 0;
                        }
                    }
                }
                if treatment == "radoff" {
                    let save = num(a, "sideSave")?;
                    need((-100..=200).contains(&save))?;
                    s.exhaustion.retain(|e| {
                        e.cause != "radiation"
                            && !(e.cause == "disease" && e.source == "Choroba popromienna")
                    });
                    c.radiation_failures = 0;
                    downtime::rad_off(s, op, save < 15);
                }
                let factor = if downtime::has_feat(sheet, "plaster")
                    && ["daily", "antibiotic", "radoff"].contains(&treatment)
                {
                    500
                } else {
                    1000
                };
                consume(&mut inv, eid, doses * factor)?;
            }
        }
        "bleeding" => {
            let d = c
                .diseases
                .iter_mut()
                .find(|d| d.active && d.id == a["id"])
                .ok_or("Brak choroby.")?;
            need(d.kind == "hemophilia")?;
            let mode = string(a, "mode")?;
            if mode == "start" {
                d.bleeding = true;
                d.successes = 0;
            } else {
                let total = num(a, "total")?;
                need(d.bleeding && (-100..=200).contains(&total))?;
                if mode == "medicineCheck" {
                    need(a["tools"] == true)?;
                    if total >= 15 {
                        d.bleeding = false;
                        d.successes = 0;
                    }
                } else {
                    need(mode == "save")?;
                    d.successes = if total >= 10 { d.successes + 1 } else { 0 };
                    if d.successes >= 3 {
                        d.bleeding = false;
                    }
                }
            }
        }
        "phobia" => add_phobia(&mut c, string(a, "id")?, string(a, "phobia")?)?,
        "phobiaAway" => {
            let p = c
                .phobias
                .iter_mut()
                .find(|p| p.active && p.id == a["id"])
                .ok_or("Brak fobii.")?;
            p.fear = false;
        }
        "phobiaCheck" => {
            let p = c
                .phobias
                .iter_mut()
                .find(|p| p.active && p.id == a["id"])
                .ok_or("Brak fobii.")?;
            need(now >= p.immune_until)?;
            let turn = string(a, "turn")?;
            if !turn.is_empty() {
                text(turn)?;
                need(!p.turns.contains(&turn.into()))?;
                p.turns.push(turn.into());
            } else {
                need(p.last_check_at.is_none_or(|t| now - t >= 10))?;
            }
            let total = num(a, "total")?;
            need((-100..=200).contains(&total))?;
            if total >= 15 {
                p.successes += 1;
                p.fear = false;
                p.immune_until = now
                    + if ["heights", "fire"].contains(&p.kind.as_str()) {
                        480
                    } else {
                        60
                    };
                if ["spiders", "mutants", "machines", "rats"].contains(&p.kind.as_str()) {
                    p.attack_until = now + 1;
                }
                if p.successes >= 3 {
                    p.active = false;
                }
            } else {
                p.successes = 0;
                p.fear = true;
            }
            p.last_check_at = Some(now);
        }
        "day" => {
            let idv = string(a, "id")?;
            text(idv)?;
            need(!c.days.contains(&idv.into()))?;
            let food = num(a, "foodMg")?;
            let water = num(a, "waterMl")?;
            bounded(food)?;
            bounded(water)?;
            let diet = sheet["originId"] == "desert"
                && sheet["levels"].as_array().unwrap().iter().any(|l| {
                    l["choices"].as_object().unwrap().iter().any(|(k, v)| {
                        k.contains("origin")
                            && v.as_array().is_some_and(|a| a.contains(&json!("diet")))
                    })
                });
            let (food_need, water_need) = if diet {
                (250000, 1000)
            } else {
                match sheet["identity"]["size"].as_str().unwrap() {
                    "tiny" => (100000, 500),
                    "small" => (250000, 1000),
                    "large" => (2000000, 30000),
                    "huge" => (8000000, 60000),
                    "gargantuan" => (32000000, 240000),
                    _ => (500000, 2000),
                }
            };
            c.days.push(idv.into());
            c.hungry_days = if food == 0 { c.hungry_days + 1 } else { 0 };
            c.food_satisfied = food >= food_need;
            c.water_satisfied = water >= water_need;
            let hunger = if c.hungry_days >= 5 {
                true
            } else if food < food_need / 2 {
                let total = num(a, "hungerSave")?;
                need((-100..=200).contains(&total))?;
                total < 10
            } else {
                false
            };
            if hunger {
                exhaust(s, op, "hunger", &format!("Niedożywienie — {idv}"));
            }
            if water < water_need / 2 {
                let eid = if hunger {
                    format!(
                        "{}{}",
                        &op[..op.len() - 1],
                        if op.ends_with('0') { '1' } else { '0' }
                    )
                } else {
                    op.into()
                };
                exhaust(s, &eid, "thirst", &format!("Odwodnienie — {idv}"));
            }
            for (key, qty) in [
                ("foodEntryId", "foodQuantity"),
                ("waterEntryId", "waterQuantity"),
            ] {
                if let Some(idv) = a[key].as_str() {
                    consume(&mut inv, idv, num(a, qty)?)?;
                }
            }
            c.day += 1;
            s.world_minutes = c.day * 1440;
        }
        "environment" => {
            let idv = string(a, "id")?;
            text(idv)?;
            need(!c.exposures.contains(&idv.into()))?;
            c.exposures.push(idv.into());
            let h = string(a, "hazard")?;
            need(["cold", "radiation", "suffocation", "breathe", "noSleep"].contains(&h))?;
            if h == "breathe" {
                s.exhaustion.retain(|e| e.cause != "suffocation");
            } else if h == "suffocation" {
                exhaust(s, op, "suffocation", &format!("Duszenie — {idv}"));
            } else {
                let total = num(a, "total")?;
                let dc = if h == "noSleep" { 20 } else { num(a, "dc")? };
                need((-100..=200).contains(&total) && (0..=100).contains(&dc))?;
                if total < dc {
                    exhaust(s, op, if h == "noSleep" { "ordinary" } else { h }, idv);
                    if h == "radiation" {
                        c.radiation_failures += 1;
                        if c.radiation_failures == 3 && !immune {
                            add_disease(
                                &mut c,
                                string(a, "diseaseId")?,
                                "radiation",
                                "Trzy nieudane RO przeciw promieniowaniu",
                                now + 1440,
                            )?;
                        }
                    }
                }
            }
        }
        "careCorrection" => {
            text(string(a, "reason")?)?;
            let group = string(a, "group")?;
            if group == "disease" {
                let d = c
                    .diseases
                    .iter_mut()
                    .find(|d| d.active && d.id == a["id"])
                    .ok_or("Brak choroby.")?;
                d.active = false;
                d.blocked = false;
                d.bleeding = false;
            } else {
                need(group == "phobia")?;
                let p = c
                    .phobias
                    .iter_mut()
                    .find(|p| p.active && p.id == a["id"])
                    .ok_or("Brak fobii.")?;
                p.active = false;
                p.fear = false;
            }
        }
        _ => unreachable!(),
    }
    validate(&c)?;
    super::super::inventory::validate(&inv)?;
    s.care = Some(c);
    Ok(inv)
}

pub(super) fn set_day(c: &mut Care, now: i64) {
    c.day = now / 1440;
}
