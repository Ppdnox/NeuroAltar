use super::*;
use sqlx::{Row, Sqlite, Transaction};

// The original category CHECK remains immutable; this is storage compatibility only.
pub(super) fn legacy_category(category: &str) -> &str {
    match category {
        "animal" => "beast",
        "mutant" | "monster" => "other",
        c => c,
    }
}
pub(super) fn official_category(category: &str) -> Option<&str> {
    match category {
        "beast" | "other" => None,
        c => Some(c),
    }
}
pub(super) fn statblock(t: &EnemyTemplate) -> String {
    let mut v = serde_json::to_value(t).expect("validated template");
    let map = v.as_object_mut().unwrap();
    for key in ["id", "name", "category", "size", "tt", "hpMax"] {
        map.remove(key);
    }
    v.to_string()
}

pub(super) fn from_row(row: &sqlx::sqlite::SqliteRow) -> Result<EnemyTemplate, String> {
    let mut v: serde_json::Value =
        serde_json::from_str(row.get::<&str, _>("statblock_json")).map_err(|e| e.to_string())?;
    for key in ["id", "name", "category", "size"] {
        v[key] = serde_json::json!(row.get::<&str, _>(key));
    }
    if let Some(category) = row
        .try_get::<Option<&str>, _>("official_category")
        .ok()
        .flatten()
    {
        v["category"] = serde_json::json!(category);
    }
    v["tt"] = serde_json::json!(row.get::<i64, _>("tt"));
    v["hpMax"] = serde_json::json!(row.get::<i64, _>("hp_max"));
    serde_json::from_value(v).map_err(|e| e.to_string())
}

pub(super) fn validate_template(t: &EnemyTemplate) -> Result<(), String> {
    validate(&Combat {
        encounter_id: 1,
        revision: 0,
        round_number: 1,
        current_turn_actor_id: None,
        actors: vec![Actor {
            id: t.id.clone(),
            display_name: t.name.clone(),
            tt_current: t.tt,
            hp_current: t.hp_max,
            hp_max_current: t.hp_max,
            initiative_value: None,
            initiative_tie_order: 0,
            statuses: vec![],
            effects: vec![],
            prepared: None,
            enemy: Some(EnemyInstance {
                statblock: None,
                machine_failures: None,
                failure_threshold: None,
                sp: None,
                loadout: None,
                template: t.clone(),
                speeds: t.speeds.clone(),
                capabilities: None,
                injury: None,
                cowardice_percent: None,
            }),
        }],
    })
}

// Existing actors retain their own immutable template copy, even after catalog edits.
// New copies may use either the current catalog or a template held by a saved actor.
pub(super) async fn ensure_instance_template(
    tx: &mut Transaction<'_, Sqlite>,
    actor: &Actor,
    t: &EnemyTemplate,
) -> Result<(), String> {
    let old: Option<String> =
        sqlx::query_scalar("SELECT runtime_overrides_json FROM encounter_actors WHERE id = ?")
            .bind(&actor.id)
            .fetch_optional(&mut **tx)
            .await
            .map_err(|e| e.to_string())?;
    if let Some(old) = old {
        let v: serde_json::Value = serde_json::from_str(&old).map_err(|e| e.to_string())?;
        let saved: EnemyTemplate =
            serde_json::from_value(v["enemy"]["template"].clone()).map_err(|e| e.to_string())?;
        if saved != *t {
            return Err("Szablon zapisany w istniejącej postaci jest niezmienny.".into());
        }
        return Ok(());
    }
    let row = sqlx::query("SELECT * FROM enemy_templates WHERE id = ?")
        .bind(&t.id)
        .fetch_optional(&mut **tx)
        .await
        .map_err(|e| e.to_string())?;
    if let Some(row) = row {
        if from_row(&row)? == *t {
            return Ok(());
        }
        let snapshots: Vec<String> = sqlx::query_scalar(
            "SELECT runtime_overrides_json FROM encounter_actors WHERE template_id = ?",
        )
        .bind(&t.id)
        .fetch_all(&mut **tx)
        .await
        .map_err(|e| e.to_string())?;
        for snapshot in snapshots {
            let v: serde_json::Value =
                serde_json::from_str(&snapshot).map_err(|e| e.to_string())?;
            if serde_json::from_value::<EnemyTemplate>(v["enemy"]["template"].clone())
                .map_err(|e| e.to_string())?
                == *t
            {
                return Ok(());
            }
        }
        return Err("Szablon o tym ID ma inne dane. Nie nadpisano szablonu ani instancji.".into());
    }
    sqlx::query("INSERT INTO enemy_templates (id, name, category, official_category, size, tt, hp_max, statblock_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
        .bind(&t.id).bind(&t.name).bind(legacy_category(&t.category)).bind(official_category(&t.category)).bind(&t.size).bind(t.tt).bind(t.hp_max).bind(statblock(t))
        .execute(&mut **tx).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[derive(Debug, Deserialize, Clone)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Mutation {
    template: EnemyTemplate,
    expected_revision: Option<i64>,
    deleted: bool,
}

async fn save_to_pool(pool: &SqlitePool, change: Mutation) -> Result<i64, String> {
    validate_template(&change.template)?;
    if change
        .expected_revision
        .is_some_and(|r| !(0..9_007_199_254_740_991).contains(&r))
        || (change.deleted && change.expected_revision.is_none())
    {
        return Err("Niepoprawna wersja szablonu.".into());
    }
    let t = &change.template;
    let mut tx = pool.begin().await.map_err(|e| e.to_string())?;
    // Acquire the write lock before checking a version, like combat's transaction.
    sqlx::query("UPDATE enemy_templates SET revision = revision WHERE id = ?")
        .bind(&t.id)
        .execute(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let row = sqlx::query("SELECT * FROM enemy_templates WHERE id = ?")
        .bind(&t.id)
        .fetch_optional(&mut *tx)
        .await
        .map_err(|e| e.to_string())?;
    let revision = change.expected_revision.map_or(0, |r| r + 1);
    if let Some(row) = row {
        let current = row.get::<i64, _>("revision");
        let deleted = row.get::<i64, _>("deleted") != 0;
        // An uncertain IPC result can be retried without a second mutation.
        if current == revision && deleted == change.deleted && from_row(&row)? == *t {
            return Ok(revision);
        }
        if change.expected_revision != Some(current) || deleted {
            return Err("Szablon zmieniono lub usunięto w innym oknie. Zachowano formularz; odczytaj katalog ponownie.".into());
        }
        if change.deleted && from_row(&row)? != *t {
            return Err("Usunięcie nie może zmienić danych szablonu.".into());
        }
        sqlx::query("UPDATE enemy_templates SET name=?, category=?, official_category=?, size=?, tt=?, hp_max=?, statblock_json=?, revision=?, deleted=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?")
            .bind(&t.name).bind(legacy_category(&t.category)).bind(official_category(&t.category)).bind(&t.size).bind(t.tt).bind(t.hp_max).bind(statblock(t)).bind(revision).bind(change.deleted).bind(&t.id)
            .execute(&mut *tx).await.map_err(|e| e.to_string())?;
    } else {
        if change.expected_revision.is_some() {
            return Err("Nie znaleziono szablonu.".into());
        }
        sqlx::query("INSERT INTO enemy_templates (id,name,category,official_category,size,tt,hp_max,statblock_json) VALUES (?,?,?,?,?,?,?,?)")
            .bind(&t.id).bind(&t.name).bind(legacy_category(&t.category)).bind(official_category(&t.category)).bind(&t.size).bind(t.tt).bind(t.hp_max).bind(statblock(t))
            .execute(&mut *tx).await.map_err(|e| e.to_string())?;
    }
    tx.commit().await.map_err(|e| e.to_string())?;
    Ok(revision)
}

#[tauri::command]
pub async fn save_bestiary(
    db_instances: tauri::State<'_, DbInstances>,
    change: Mutation,
) -> Result<i64, String> {
    let databases = db_instances.0.read().await;
    let pool = match databases.get("sqlite:combat-tracker.db") {
        Some(tauri_plugin_sql::DbPool::Sqlite(pool)) => pool.clone(),
        _ => return Err("Baza nie jest otwarta.".into()),
    };
    drop(databases);
    save_to_pool(&pool, change).await
}

#[cfg(test)]
mod tests {
    use super::super::tests::{database, enemy_state};
    use super::*;
    async fn catalog(pool: &SqlitePool, id: &str) -> EnemyTemplate {
        from_row(
            &sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(id)
                .fetch_one(pool)
                .await
                .unwrap(),
        )
        .unwrap()
    }
    #[test]
    fn edits_and_deletion_preserve_runtime_reset_log_and_template_copies() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let mut state = enemy_state();
            state.revision = super::super::save_to_pool(&pool, state.clone())
                .await
                .unwrap();
            let old = state.actors[1].enemy.as_ref().unwrap().template.clone();
            let snapshot: String = sqlx::query_scalar(
                "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?",
            )
            .bind(&state.actors[1].id)
            .fetch_one(&pool)
            .await
            .unwrap();
            let mut edited = old.clone();
            edited.name = "Żmija po edycji".into();
            edited.hp_max = 125;
            assert_eq!(
                save_to_pool(
                    &pool,
                    Mutation {
                        template: edited.clone(),
                        expected_revision: Some(0),
                        deleted: false
                    }
                )
                .await
                .unwrap(),
                1
            );
            state.actors[1].hp_current = 2;
            state.revision = super::super::save_to_pool(&pool, state.clone())
                .await
                .unwrap();
            assert_eq!(catalog(&pool, &old.id).await, edited);
            // Old and current template generations may coexist under one catalog identity.
            let mut copy = state.actors[1].clone();
            copy.id = "00000000-0000-4000-8000-000000000071".to_string();
            copy.initiative_tie_order = 10;
            copy.prepared = None;
            state.actors.push(copy.clone());
            copy.id = "00000000-0000-4000-8000-000000000072".to_string();
            copy.initiative_tie_order = 11;
            copy.enemy.as_mut().unwrap().template = edited.clone();
            state.actors.push(copy);
            state.revision = super::super::save_to_pool(&pool, state.clone())
                .await
                .unwrap();
            let deletion = Mutation {
                template: edited.clone(),
                expected_revision: Some(1),
                deleted: true,
            };
            assert_eq!(save_to_pool(&pool, deletion.clone()).await.unwrap(), 2);
            assert_eq!(save_to_pool(&pool, deletion).await.unwrap(), 2);
            state.actors[1] = *state.actors[1].prepared.clone().unwrap();
            state.revision = super::super::save_to_pool(&pool, state.clone())
                .await
                .unwrap();
            assert_eq!(
                sqlx::query_scalar::<_, String>(
                    "SELECT prepared_snapshot_json FROM encounter_actors WHERE id=?"
                )
                .bind(&state.actors[1].id)
                .fetch_one(&pool)
                .await
                .unwrap(),
                snapshot
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT deleted FROM enemy_templates WHERE id=?")
                    .bind(&old.id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM encounters")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                5
            );
            assert!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap()
                    > 0
            );
            // Catalog edits cannot be smuggled into an existing actor, even with no prepared field.
            state.actors[1].prepared = None;
            state.actors[1].enemy.as_mut().unwrap().template = edited;
            assert!(super::super::save_to_pool(&pool, state).await.is_err());
            pool.close().await;
        });
    }
    #[test]
    fn catalog_creation_retry_conflict_validation_and_transaction_rollback() {
        tauri::async_runtime::block_on(async {
            let pool = database().await;
            let t = enemy_state().actors[1]
                .enemy
                .as_ref()
                .unwrap()
                .template
                .clone();
            let create = Mutation {
                template: t.clone(),
                expected_revision: None,
                deleted: false,
            };
            assert_eq!(save_to_pool(&pool, create.clone()).await.unwrap(), 0);
            assert_eq!(save_to_pool(&pool, create).await.unwrap(), 0);
            let mut edited = t.clone();
            edited.name = "Nowy wzorzec".into();
            let change = Mutation {
                template: edited.clone(),
                expected_revision: Some(0),
                deleted: false,
            };
            assert_eq!(save_to_pool(&pool, change.clone()).await.unwrap(), 1);
            assert_eq!(save_to_pool(&pool, change).await.unwrap(), 1);
            assert!(save_to_pool(
                &pool,
                Mutation {
                    template: t.clone(),
                    expected_revision: Some(0),
                    deleted: false
                }
            )
            .await
            .is_err());
            let mut invalid = t.clone();
            invalid.hp_max = 0;
            assert!(save_to_pool(
                &pool,
                Mutation {
                    template: invalid,
                    expected_revision: Some(1),
                    deleted: false
                }
            )
            .await
            .is_err());
            sqlx::raw_sql("CREATE TRIGGER fail_catalog BEFORE UPDATE OF statblock_json ON enemy_templates BEGIN SELECT RAISE(ABORT,'disk failure'); END;").execute(&pool).await.unwrap();
            assert!(save_to_pool(
                &pool,
                Mutation {
                    template: t,
                    expected_revision: Some(1),
                    deleted: false
                }
            )
            .await
            .is_err());
            assert_eq!(catalog(&pool, &edited.id).await, edited);
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT revision FROM enemy_templates")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                1
            );
            pool.close().await;
        });
    }
    #[test]
    fn migration_six_preserves_legacy_rows_and_snapshots() {
        tauri::async_runtime::block_on(async {
            let pool = sqlx::sqlite::SqlitePoolOptions::new()
                .max_connections(1)
                .connect("sqlite::memory:")
                .await
                .unwrap();
            for sql in [
                include_str!("../migrations/001_initial.sql"),
                include_str!("../migrations/002_pc_initiative.sql"),
                include_str!("../migrations/003_enemy_instances.sql"),
                include_str!("../migrations/004_combat_log.sql"),
                include_str!("../migrations/005_actor_statuses.sql"),
                include_str!("../migrations/008_enemy_categories.sql"),
                include_str!("../migrations/011_characters.sql"),
                include_str!("../migrations/014_character_participation.sql"),
            ] {
                sqlx::raw_sql(sql).execute(&pool).await.unwrap();
            }
            let state = enemy_state();
            super::super::save_to_pool(&pool, state).await.unwrap();
            let before: Vec<(String,String,String,String)>=sqlx::query_as("SELECT id,prepared_snapshot_json,reset_snapshot_json,runtime_overrides_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
            let logs: i64 = sqlx::query_scalar("SELECT count(*) FROM combat_log")
                .fetch_one(&pool)
                .await
                .unwrap();
            sqlx::raw_sql(include_str!("../migrations/006_bestiary.sql"))
                .execute(&pool)
                .await
                .unwrap();
            let after: Vec<(String,String,String,String)>=sqlx::query_as("SELECT id,prepared_snapshot_json,reset_snapshot_json,runtime_overrides_json FROM encounter_actors ORDER BY id").fetch_all(&pool).await.unwrap();
            assert_eq!(before, after);
            assert_eq!(
                sqlx::query_scalar::<_, i64>(
                    "SELECT count(*) FROM enemy_templates WHERE deleted=0 AND revision=0"
                )
                .fetch_one(&pool)
                .await
                .unwrap(),
                1
            );
            assert_eq!(
                sqlx::query_scalar::<_, i64>("SELECT count(*) FROM combat_log")
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                logs
            );
            pool.close().await;
        });
    }
}

#[cfg(test)]
#[test]
fn statblock_catalog_edits_preserve_existing_instance_and_snapshot() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        let mut state = super::tests::enemy_state();
        let block: super::statblock::Statblock =
            serde_json::from_str(include_str!("../../tests/fixtures/statblock.json")).unwrap();
        for actor in &mut state.actors {
            if let Some(enemy) = &mut actor.enemy {
                enemy.template.statblock = Some(block.clone());
                enemy.statblock = Some(block.clone());
                let mut prepared = actor.clone();
                prepared.prepared = None;
                actor.prepared = Some(Box::new(prepared));
            }
        }
        super::save_to_pool(&pool, state.clone()).await.unwrap();
        let mut template = state.actors[1].enemy.as_ref().unwrap().template.clone();
        template.statblock.as_mut().unwrap().ability_scores.str = Some(20);
        assert_eq!(
            save_to_pool(
                &pool,
                Mutation {
                    template: template.clone(),
                    expected_revision: Some(0),
                    deleted: false
                }
            )
            .await
            .unwrap(),
            1
        );
        let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
            .bind(&template.id)
            .fetch_one(&pool)
            .await
            .unwrap();
        assert_eq!(
            from_row(&row)
                .unwrap()
                .statblock
                .unwrap()
                .ability_scores
                .str,
            Some(20)
        );
        for column in [
            "runtime_overrides_json",
            "prepared_snapshot_json",
            "reset_snapshot_json",
        ] {
            let query=format!("SELECT json_extract({column},'$.enemy.statblock.abilityScores.str') FROM encounter_actors WHERE id=?");
            assert_eq!(
                sqlx::query_scalar::<_, i64>(&query)
                    .bind(&state.actors[1].id)
                    .fetch_one(&pool)
                    .await
                    .unwrap(),
                15
            );
        }
        template.statblock.as_mut().unwrap().damage_threshold = Some(-1);
        assert!(save_to_pool(
            &pool,
            Mutation {
                template: template.clone(),
                expected_revision: Some(1),
                deleted: false
            }
        )
        .await
        .is_err());
        assert_eq!(
            sqlx::query_scalar::<_, i64>("SELECT revision FROM enemy_templates WHERE id=?")
                .bind(&template.id)
                .fetch_one(&pool)
                .await
                .unwrap(),
            1
        );
        pool.close().await;
    });
}

#[cfg(test)]
#[test]
fn official_categories_roundtrip_catalog_and_combat_without_rewriting_legacy_copies() {
    tauri::async_runtime::block_on(async {
        let pool = super::tests::database().await;
        let mut state = super::tests::enemy_state();
        let mut t = state.actors[1].enemy.as_ref().unwrap().template.clone();
        t.category = "mutant".into();
        save_to_pool(
            &pool,
            Mutation {
                template: t.clone(),
                expected_revision: None,
                deleted: false,
            },
        )
        .await
        .unwrap();
        for actor in &mut state.actors {
            if let Some(enemy) = &mut actor.enemy {
                enemy.template = t.clone();
                actor.prepared = None;
            }
        }
        super::save_to_pool(&pool, state).await.unwrap();
        for (i, category) in ["animal", "monster", "human", "machine", "beast", "other"]
            .iter()
            .enumerate()
        {
            t.category = category.to_string();
            save_to_pool(
                &pool,
                Mutation {
                    template: t.clone(),
                    expected_revision: Some(i as i64),
                    deleted: false,
                },
            )
            .await
            .unwrap();
            let row = sqlx::query("SELECT * FROM enemy_templates WHERE id=?")
                .bind(&t.id)
                .fetch_one(&pool)
                .await
                .unwrap();
            assert_eq!(from_row(&row).unwrap(), t);
        }
        assert_eq!(sqlx::query_scalar::<_,String>("SELECT json_extract(runtime_overrides_json,'$.enemy.template.category') FROM encounter_actors WHERE kind='enemy'").fetch_one(&pool).await.unwrap(),"mutant");
        t.category = "invalid".into();
        assert!(validate_template(&t).is_err());
        pool.close().await;
    });
}
