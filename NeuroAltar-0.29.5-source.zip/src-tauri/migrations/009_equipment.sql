-- Additive equipment catalog. No links that can cascade into combat snapshots.
CREATE TABLE items (
    id TEXT PRIMARY KEY,
    item_json TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0 CHECK (revision >= 0),
    deleted INTEGER NOT NULL DEFAULT 0 CHECK (deleted IN (0, 1))
);
CREATE TABLE equipment_seed_batches (
    batch_id TEXT PRIMARY KEY,
    source_sha256 TEXT NOT NULL,
    entry_count INTEGER NOT NULL CHECK (entry_count > 0)
);
