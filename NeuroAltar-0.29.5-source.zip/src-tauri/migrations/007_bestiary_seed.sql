-- Additive ledger only. Never rewrite catalog/encounters or recreate a database.
CREATE TABLE bestiary_seed_entries (
    entry_id TEXT PRIMARY KEY,
    batch_id TEXT NOT NULL,
    version INTEGER NOT NULL CHECK (version > 0),
    offered_json TEXT NOT NULL,
    source_json TEXT NOT NULL,
    installed_revision INTEGER CHECK (installed_revision >= 0)
);
-- NULL installed_revision permanently opts a conflicting/edited/deleted entry out
-- of automatic corrections. Missing catalog rows with a ledger are never restored.
