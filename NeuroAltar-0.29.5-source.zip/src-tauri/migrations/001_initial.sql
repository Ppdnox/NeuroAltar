-- Schema changes belong in subsequent numbered migrations.
-- The SQL plugin runs this migration transactionally and records its version.
CREATE TABLE IF NOT EXISTS encounters (
    id INTEGER PRIMARY KEY CHECK (id BETWEEN 1 AND 5),
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    notes TEXT NOT NULL DEFAULT '',
    round_number INTEGER NOT NULL DEFAULT 1 CHECK (typeof(round_number) = 'integer' AND round_number >= 1),
    current_turn_actor_id TEXT,
    party_levels_json TEXT NOT NULL DEFAULT '[]'
        CHECK (json_valid(party_levels_json) AND json_type(party_levels_json) = 'array'),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

INSERT INTO encounters (id, name)
SELECT 1, 'Potyczka 1' WHERE NOT EXISTS (SELECT 1 FROM encounters WHERE id = 1);
INSERT INTO encounters (id, name)
SELECT 2, 'Potyczka 2' WHERE NOT EXISTS (SELECT 1 FROM encounters WHERE id = 2);
INSERT INTO encounters (id, name)
SELECT 3, 'Potyczka 3' WHERE NOT EXISTS (SELECT 1 FROM encounters WHERE id = 3);
INSERT INTO encounters (id, name)
SELECT 4, 'Potyczka 4' WHERE NOT EXISTS (SELECT 1 FROM encounters WHERE id = 4);
INSERT INTO encounters (id, name)
SELECT 5, 'Potyczka 5' WHERE NOT EXISTS (SELECT 1 FROM encounters WHERE id = 5);

CREATE TRIGGER IF NOT EXISTS encounters_preserve_slots
BEFORE DELETE ON encounters
BEGIN
    SELECT RAISE(ABORT, 'Encounter slots are permanent; clear their contents instead');
END;

CREATE TRIGGER IF NOT EXISTS encounters_preserve_ids
BEFORE UPDATE OF id ON encounters WHEN NEW.id != OLD.id
BEGIN
    SELECT RAISE(ABORT, 'Encounter slot IDs are permanent');
END;

-- REPLACE can otherwise bypass delete triggers when recursive_triggers is off.
CREATE TRIGGER IF NOT EXISTS encounters_prevent_replacement
BEFORE INSERT ON encounters WHEN EXISTS (SELECT 1 FROM encounters WHERE id = NEW.id)
BEGIN
    SELECT RAISE(ABORT, 'Encounter slots already exist; use UPDATE');
END;
