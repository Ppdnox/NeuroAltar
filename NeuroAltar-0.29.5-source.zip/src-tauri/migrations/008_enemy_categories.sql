-- Preserve old rows, category CHECK, IDs, revisions, snapshots and seed payloads.
-- New taxonomy overrides the compatibility column only when explicitly assigned.
ALTER TABLE enemy_templates ADD COLUMN official_category TEXT
    CHECK (official_category IS NULL OR official_category IN ('human','machine','mutant','monster','animal'));
