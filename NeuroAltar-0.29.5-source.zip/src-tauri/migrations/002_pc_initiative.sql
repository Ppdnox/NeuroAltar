-- Additive migration; never recreate encounters or modify migration 001.
ALTER TABLE encounters ADD COLUMN combat_revision INTEGER NOT NULL DEFAULT 0
    CHECK (typeof(combat_revision) = 'integer' AND combat_revision >= 0);

CREATE TABLE encounter_actors (
    id TEXT PRIMARY KEY NOT NULL,
    encounter_id INTEGER NOT NULL REFERENCES encounters(id) ON DELETE RESTRICT,
    kind TEXT NOT NULL CHECK (kind IN ('pc', 'enemy')),
    template_id TEXT,
    display_name TEXT NOT NULL CHECK (length(trim(display_name)) > 0),
    initiative_value INTEGER CHECK (initiative_value IS NULL OR typeof(initiative_value) = 'integer'),
    initiative_tie_order INTEGER NOT NULL CHECK (typeof(initiative_tie_order) = 'integer' AND initiative_tie_order >= 0),
    tt_current INTEGER NOT NULL CHECK (typeof(tt_current) = 'integer' AND tt_current >= 0),
    hp_current INTEGER NOT NULL CHECK (typeof(hp_current) = 'integer' AND hp_current >= 0 AND hp_current <= hp_max_current),
    hp_max_current INTEGER NOT NULL CHECK (typeof(hp_max_current) = 'integer' AND hp_max_current >= 1),
    prepared_snapshot_json TEXT NOT NULL CHECK (json_valid(prepared_snapshot_json) AND json_type(prepared_snapshot_json) = 'object'),
    runtime_overrides_json TEXT NOT NULL CHECK (json_valid(runtime_overrides_json) AND json_type(runtime_overrides_json) = 'object'),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX encounter_actors_slot ON encounter_actors(encounter_id);

CREATE TRIGGER encounter_actor_identity
BEFORE UPDATE OF id, encounter_id, kind, prepared_snapshot_json ON encounter_actors
WHEN NEW.id != OLD.id OR NEW.encounter_id != OLD.encounter_id OR NEW.kind != OLD.kind
    OR NEW.prepared_snapshot_json != OLD.prepared_snapshot_json
BEGIN
    SELECT RAISE(ABORT, 'Actor identity and prepared snapshot are immutable');
END;

CREATE TRIGGER encounter_current_actor
BEFORE UPDATE OF current_turn_actor_id ON encounters
WHEN NEW.current_turn_actor_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM encounter_actors WHERE id = NEW.current_turn_actor_id
    AND encounter_id = NEW.id AND initiative_value IS NOT NULL
)
BEGIN
    SELECT RAISE(ABORT, 'Current actor must belong to this encounter and have initiative');
END;
