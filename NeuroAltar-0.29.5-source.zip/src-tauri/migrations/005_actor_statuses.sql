CREATE TABLE actor_statuses (
  id TEXT PRIMARY KEY NOT NULL,
  actor_id TEXT NOT NULL REFERENCES encounter_actors(id) ON DELETE CASCADE,
  status_json TEXT NOT NULL CHECK (json_valid(status_json) AND json_type(status_json) = 'object' AND json_extract(status_json, '$.id') = id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX actor_statuses_actor ON actor_statuses(actor_id, id);
CREATE TRIGGER actor_status_identity BEFORE UPDATE OF id, actor_id ON actor_statuses
WHEN NEW.id != OLD.id OR NEW.actor_id != OLD.actor_id
BEGIN SELECT RAISE(ABORT, 'Status identity is immutable'); END;
