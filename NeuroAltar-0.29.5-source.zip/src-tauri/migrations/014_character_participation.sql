-- Additive links. Persistent character data never lives in encounter reset snapshots.
CREATE TABLE character_participations (
 id TEXT PRIMARY KEY NOT NULL,
 character_id TEXT NOT NULL REFERENCES characters(id) ON DELETE RESTRICT,
 encounter_id INTEGER NOT NULL REFERENCES encounters(id) ON DELETE RESTRICT,
 actor_id TEXT NOT NULL UNIQUE REFERENCES encounter_actors(id) ON DELETE CASCADE,
 revision INTEGER NOT NULL DEFAULT 0 CHECK(revision >= 0),
 state TEXT NOT NULL CHECK(state IN ('prepared','active','ended')),
 payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
 UNIQUE(character_id, encounter_id)
);
CREATE UNIQUE INDEX character_one_active ON character_participations(character_id) WHERE state='active';
CREATE TABLE participation_operations (
 operation_id TEXT PRIMARY KEY NOT NULL,
 request_json TEXT NOT NULL CHECK(json_valid(request_json)),
 result_json TEXT NOT NULL CHECK(json_valid(result_json)),
 created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
