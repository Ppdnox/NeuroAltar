-- No historical events are invented and no existing combat rows are changed.
CREATE TABLE combat_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    encounter_id INTEGER NOT NULL REFERENCES encounters(id) ON DELETE RESTRICT,
    round_number INTEGER NOT NULL CHECK (typeof(round_number) = 'integer' AND round_number >= 1),
    -- Intentionally no actor FK: a removed actor's history keeps its identity/name.
    actor_id TEXT,
    event_type TEXT NOT NULL CHECK (length(event_type) > 0),
    message TEXT NOT NULL CHECK (length(message) > 0),
    payload_json TEXT NOT NULL CHECK (json_valid(payload_json) AND json_type(payload_json) = 'object'),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX combat_log_slot_order ON combat_log(encounter_id, id DESC);
