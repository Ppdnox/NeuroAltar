-- Additive history, independent of actors and the five permanent encounters.
-- No cascade: removing an actor or clearing a slot must not alter past rolls.
CREATE TABLE dice_rolls (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    payload_json TEXT NOT NULL CHECK (json_valid(payload_json) AND json_type(payload_json) = 'object')
);
