-- Preserve migrations 001/002 and the immutable original snapshot.
-- This additional snapshot is replaced only when the GM prepares a new baseline.
ALTER TABLE encounter_actors ADD COLUMN reset_snapshot_json TEXT
    CHECK (reset_snapshot_json IS NULL OR (json_valid(reset_snapshot_json) AND json_type(reset_snapshot_json) = 'object'));

CREATE TABLE enemy_templates (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    category TEXT NOT NULL CHECK (category IN ('human', 'beast', 'machine', 'other')),
    size TEXT NOT NULL CHECK (length(trim(size)) > 0),
    tt INTEGER NOT NULL CHECK (typeof(tt) = 'integer' AND tt >= 0),
    hp_max INTEGER NOT NULL CHECK (typeof(hp_max) = 'integer' AND hp_max >= 1),
    statblock_json TEXT NOT NULL CHECK (json_valid(statblock_json) AND json_type(statblock_json) = 'object'),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE TRIGGER encounter_actor_template_identity
BEFORE UPDATE OF template_id ON encounter_actors
WHEN NEW.template_id IS NOT OLD.template_id
BEGIN SELECT RAISE(ABORT, 'Actor template identity is immutable'); END;
CREATE TRIGGER encounter_actor_template_reference
BEFORE INSERT ON encounter_actors
WHEN (NEW.kind = 'pc' AND NEW.template_id IS NOT NULL)
  OR (NEW.kind = 'enemy' AND (NEW.template_id IS NULL OR NOT EXISTS (SELECT 1 FROM enemy_templates WHERE id = NEW.template_id)))
BEGIN SELECT RAISE(ABORT, 'Enemy must reference an existing template'); END;
CREATE TRIGGER enemy_template_referenced
BEFORE DELETE ON enemy_templates
WHEN EXISTS (SELECT 1 FROM encounter_actors WHERE template_id = OLD.id)
BEGIN SELECT RAISE(ABORT, 'Template is referenced by encounter instances'); END;
