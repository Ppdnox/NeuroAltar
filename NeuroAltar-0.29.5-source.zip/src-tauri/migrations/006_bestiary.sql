-- Retain referenced template identities and every encounter snapshot.
ALTER TABLE enemy_templates ADD COLUMN revision INTEGER NOT NULL DEFAULT 0
    CHECK (typeof(revision) = 'integer' AND revision >= 0);
ALTER TABLE enemy_templates ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0
    CHECK (deleted IN (0, 1));
CREATE INDEX enemy_templates_catalog ON enemy_templates(deleted, name);
