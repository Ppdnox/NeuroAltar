-- Extend the command kind constraint, copying the entire durable ledger unchanged.
-- This migration is transactional; characters and encounters are untouched.
ALTER TABLE character_operations RENAME TO character_operations_before_inventory;
CREATE TABLE character_operations (
  operation_id TEXT PRIMARY KEY NOT NULL,
  character_id TEXT NOT NULL REFERENCES characters(id),
  kind TEXT NOT NULL CHECK(kind IN ('draft','publish','discard','archive','inventory')),
  request_json TEXT NOT NULL CHECK(json_valid(request_json)),
  result_json TEXT NOT NULL CHECK(json_valid(result_json)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
INSERT INTO character_operations SELECT * FROM character_operations_before_inventory;
DROP TABLE character_operations_before_inventory;
CREATE INDEX character_operations_character ON character_operations(character_id, created_at);
