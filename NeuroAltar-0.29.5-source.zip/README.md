# NeuroAltar

Lokalna aplikacja do Neuroshimy: Ostatniej Ery: Panel MG, pięć potyczek,
Bestiariusz, Ekwipunek, Pojazdy, Wiedza MG, roller i trwałe karty BG.

## Aktualny stan — 2026-11-09

Rozwijamy **24E Roboczy**, wersja techniczna **0.29.5**. Mechanika i przebudowa
interfejsu są wdrożone; pełny odbiór sesyjny 24E pozostaje do wykonania.
Rozpoczęto przygotowanie instalatora Windows x64. Nie ma jeszcze zweryfikowanego
pliku Windows ani potwierdzenia działania aplikacji na tym systemie.

Truciciel i Pogromca pozostają opisowi w zakresie produkcji: gracz sam oblicza
koszty, ilości i wpisuje wynik do ekwipunku. Brak automatyzacji tej produkcji
jest przyjętą granicą funkcjonalności, nie zadaniem do domknięcia 24E.

- [Bieżący status i granice zakresu](docs/STATUS.md)
- [Plan dalszych prac](docs/PLAN_DALSZYCH_PRAC.md)
- [Przygotowanie i odbiór Windows](docs/BUILD_WINDOWS.md)
- [Mapa ukończonych etapów](docs/ROADMAP.md)
- [Decyzje mechaniczne](docs/DECISIONS.md)
- [Instrukcje pracy nad kodem](AGENTS.md)

## Uruchamianie i kontrole

Wymagania: Node 24, pnpm 11.19.0 oraz narzędzia Rust/Tauri właściwe dla systemu.
Lockfile pozostaje źródłem wersji zależności.

```sh
pnpm install --frozen-lockfile
pnpm dev
pnpm check
cargo test --manifest-path src-tauri/Cargo.toml --release --lib --locked
cargo fmt --manifest-path src-tauri/Cargo.toml --check
```

`pnpm dev` służy do podglądu interfejsu. Pełna aplikacja z bazą wymaga
`pnpm tauri dev`. Testy aplikacji wykonujemy na osobnej bazie.

Na Macu: `pnpm build:macos`. Na Windows: `pnpm build:windows`.
Instrukcja Windows obejmuje także ręcznie uruchamiany build na GitHub Actions.
Nie zmieniamy identyfikatora istniejącej aplikacji ani bazy przy porządkach
dokumentacji. Katalog `reference/` i bazy użytkowników nie trafiają do Git ani paczek.

## Raporty ostatnich zmian

- [Osiem poprawek karty BG](docs/POPRAWKI_8_2026-11-09.md)
- [Przekazanie pracy na Windows](docs/PRZEKAZANIE_WINDOWS_2026-11-09.md)

- [Przygotowanie Windows i porządek dokumentacji](docs/PRZYGOTOWANIE_WINDOWS_2026-11-08.md)

- [Mechanika i opisy 24E](docs/POPRAWKI_24E_MECHANIKA_3.md)
- [Układ Stół gracza + Tryb sesji](docs/UI_STOL_SESJI_2026-11-04.md)
- [Numerowane sloty ekwipunku](docs/UI_SLOTY_EKWIPUNKU_2026-11-05.md)
- [Zasoby zdolności i zakładki](docs/UI_ZASOBY_I_ZAKLADKI_2026-11-05.md)
- [Audyt limitów zdolności](docs/AUDYT_LIMITOW_ZDOLNOSCI_2026-11-05.md)
- [Zielone dedykowane ikony i ostatni odbiór techniczny macOS](docs/IKONY_DEDYKOWANE_2026-11-05.md)

Starszy rozbudowany README jest dostępny w historii Git, np.
`git show 1aeab92:README.md`. Raporty etapów opisują stan w dniu ich wykonania;
nie są aktualnymi poleceniami rozpoczynania wcześniejszych etapów.
